package com.cardlink.app.util

import com.cardlink.app.data.model.SavedContactEntity

data class FollowUpMessageTemplate(
    val id: String,
    val title: String,
    val subjectTemplate: String,
    val bodyTemplate: String
) {
    fun buildSubject(contact: SavedContactEntity, senderName: String, senderCompany: String): String {
        return replacePlaceholders(subjectTemplate, contact, senderName, senderCompany)
    }

    fun buildBody(contact: SavedContactEntity, senderName: String, senderCompany: String): String {
        return replacePlaceholders(bodyTemplate, contact, senderName, senderCompany)
    }

    private fun replacePlaceholders(
        raw: String,
        contact: SavedContactEntity,
        senderName: String,
        senderCompany: String
    ): String {
        val cName = contact.fullName.ifBlank { "there" }
        val cCompany = contact.companyName.ifBlank { "your organization" }
        val sName = senderName.ifBlank { "CardLink User" }
        val sComp = senderCompany.ifBlank { "our team" }
        return raw
            .replace("{name}", cName)
            .replace("{company}", cCompany)
            .replace("{sender}", sName)
            .replace("{senderCompany}", sComp)
    }
}

object MessageTemplateHelper {
    val defaultTemplates = listOf(
        FollowUpMessageTemplate(
            id = "nice_meeting",
            title = "1. Post-Meeting Thank You (Nice Meeting You)",
            subjectTemplate = "Great connecting with you — {sender}",
            bodyTemplate = "Dear {name},\n\nIt was a pleasure meeting you and learning more about {company}. Let's stay in touch for future collaboration.\n\nBest regards,\n{sender}\n{senderCompany}"
        ),
        FollowUpMessageTemplate(
            id = "proposal_followup",
            title = "2. Proposal / Quotation Follow-up",
            subjectTemplate = "Follow-up on Proposal — {company} & {senderCompany}",
            bodyTemplate = "Dear {name},\n\nHope you are doing well. I wanted to quickly follow up regarding our discussion with {company}. Please let me know if you need any additional details from our end.\n\nWarm regards,\n{sender}\n{senderCompany}"
        ),
        FollowUpMessageTemplate(
            id = "vendor_onboarding",
            title = "3. Vendor / Partner Onboarding",
            subjectTemplate = "Onboarding & Next Steps — {company}",
            bodyTemplate = "Dear {name},\n\nThank you for sharing your details. We are reviewing the documentation for {company} and will reach out shortly with the next steps.\n\nRegards,\n{sender}\n{senderCompany}"
        ),
        FollowUpMessageTemplate(
            id = "schedule_meeting",
            title = "4. Request a 1-on-1 Meeting / Call",
            subjectTemplate = "Meeting Request — {sender} ({senderCompany})",
            bodyTemplate = "Dear {name},\n\nWould you be available for a brief 15-minute call or coffee meeting this week to discuss potential synergies with {company}?\n\nBest regards,\n{sender}\n{senderCompany}"
        ),
        FollowUpMessageTemplate(
            id = "bangla_professional",
            title = "5. বাংলা Professional Return Card / Follow-Up",
            subjectTemplate = "পরিচিত হয়ে ভালো লাগল — {sender}",
            bodyTemplate = "প্রিয় {name},

আজ আপনার সঙ্গে পরিচিত হয়ে ভালো লেগেছে। আমার প্রফেশনাল ডিজিটাল কার্ডটি শেয়ার করলাম। ভবিষ্যতে যোগাযোগ রাখার প্রত্যাশায় রইলাম।

শুভেচ্ছান্তে,
{sender}
{senderCompany}"
        ),
        FollowUpMessageTemplate(
            id = "share_my_card",
            title = "5. Share My Contact Details",
            subjectTemplate = "Contact Details — {sender}",
            bodyTemplate = "Hello {name},\n\nSharing my contact info so you have my direct number and email on hand. Always happy to connect!\n\nBest,\n{sender}\n{senderCompany}"
        )
    )
}
