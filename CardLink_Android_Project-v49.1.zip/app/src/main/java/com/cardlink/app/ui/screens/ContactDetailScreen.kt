package com.cardlink.app.ui.screens

import android.Manifest
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.ui.components.FlippableContactCardViewer
import com.cardlink.app.ui.components.FullScreenContactCardDialog
import com.cardlink.app.ui.components.SmartCardCropDialog
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contact: SavedContactEntity,
    mySenderName: String,
    mySenderCompany: String = "",
    contactFollowUps: List<FollowUpEntity> = emptyList(),
    onSaveContact: (SavedContactEntity, String?) -> Unit,
    onToggleFavorite: (SavedContactEntity) -> Unit = {},
    onSyncToPhone: (SavedContactEntity, Boolean, String?) -> Unit = { _, _, _ -> },
    onAddFollowUp: (FollowUpEntity) -> Unit = {},
    onToggleFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteFollowUp: (FollowUpEntity) -> Unit = {},
    onSendMyCardBack: () -> Unit = {},
    onOpenMeetingBrief: () -> Unit = {},
    onOpenScheduleMeeting: () -> Unit = {},
    onDeleteContact: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // Focused Edit Sheet / Dialog States
    var showEditContactSheet by remember { mutableStateOf(false) }
    var showEditBusinessSheet by remember { mutableStateOf(false) }
    var showDobDatePicker by remember { mutableStateOf(false) }
    var showRawOcrDialog by remember { mutableStateOf(false) }
    var showWaScheduleConfirmDialog by remember { mutableStateOf<SavedContactEntity?>(null) }

    // Non-Destructive Post-Save Crop State
    var cropTargetSideIsBack by remember { mutableStateOf(false) }
    var cropSourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showCropActionsSheet by remember { mutableStateOf(false) }

    var notes by remember(contact) { mutableStateOf(contact.notes) }
    var selectedTag by remember(contact) { mutableStateOf(contact.categoryTag) }
    var currentLat by remember(contact) { mutableStateOf(contact.latitude) }
    var currentLng by remember(contact) { mutableStateOf(contact.longitude) }
    var userGps by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var showTemplateSheetFor by remember { mutableStateOf<String?>(null) }
    var newActionTitle by remember { mutableStateOf("") }

    var showMoreActionSheet by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showFullScreenCard by remember { mutableStateOf(false) }
    var expandBusinessDetails by remember(contact.id) { mutableStateOf(false) }
    var expandPersonalInfo by remember(contact.id) { mutableStateOf(!contact.dateOfBirthIso.isNullOrBlank()) }

    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val whatsAppTarget = contact.whatsapp.ifBlank { contact.phone }
    val hasPhone = primaryPhone.isNotBlank()
    val hasWhatsApp = whatsAppTarget.isNotBlank()
    val hasEmail = contact.email.isNotBlank()
    val hasLocation = contact.officeAddress.isNotBlank() || (currentLat != null && currentLng != null)

    val birthdayInfo = remember(contact.dateOfBirthIso) {
        ContactBirthdayHelper.computeBirthdayInfo(contact.dateOfBirthIso)
    }

    val nextFollowUp = remember(contactFollowUps) {
        contactFollowUps.filterNot { it.isCompleted }.minByOrNull { it.dueAtTimestamp }
    }

    val tagOptions = listOf("General", "Client", "Vendor", "VIP", "Colleague", "Event")
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val shortDateFmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val hasPendingWaSchedules = remember(contactFollowUps) {
        contactFollowUps.any { !it.isCompleted && it.channel == "WHATSAPP" && it.status != "CANCELLED" }
    }

    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
    }

    val replaceCardImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2000) }
                if (bmp != null) {
                    cropSourceBitmap = bmp
                } else {
                    Toast.makeText(context, "Could not open selected image.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    var pendingVoiceTranscript by remember { mutableStateOf<String?>(null) }
    val speechRecognizerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim()
            if (!spokenText.isNullOrBlank()) {
                pendingVoiceTranscript = spokenText
            }
        }
    }

    fun launchAdjustCropForSide(isBack: Boolean) {
        cropTargetSideIsBack = isBack
        val sourceUri = if (isBack) {
            contact.backOriginalPhotoUri ?: contact.backPhotoUri
        } else {
            contact.frontOriginalPhotoUri ?: contact.profilePhotoUri
        }
        if (sourceUri.isNullOrBlank()) {
            Toast.makeText(context, "No card image available for this side.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                VaultCryptoManager.decodeVaultBitmap(context, sourceUri, 2000)
                    ?: ScannedCardStorageHelper.decodeGalleryUri(context, android.net.Uri.parse(sourceUri), 2000)
            }
            if (bmp != null) {
                cropSourceBitmap = bmp
            } else {
                Toast.makeText(context, "Could not load original card image.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(contact.officeAddress) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
        if ((currentLat == null || currentLng == null) && contact.officeAddress.isNotBlank()) {
            GeoLocationHelper.geocodeAddress(context, contact.officeAddress)?.let { (la, lo) ->
                currentLat = la; currentLng = lo
                onSaveContact(contact.copy(latitude = la, longitude = lo), null)
            }
        }
    }

    val distanceKm = remember(userGps, currentLat, currentLng) {
        val u = userGps; val la = currentLat; val lo = currentLng
        if (u != null && la != null && lo != null) GeoLocationHelper.distanceInKm(u.first, u.second, la, lo) else null
    }

    Scaffold(
        topBar = {
            // 1. IDENTITY HEADER (Name, Favorite, ⋮ More)
            TopAppBar(
                title = {
                    Column {
                        Text(contact.fullName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (contact.alternateName.isNotBlank()) {
                            Text(contact.alternateName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onToggleFavorite(contact)
                    }) {
                        Icon(
                            imageVector = if (contact.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (contact.isFavorite) "Remove from Favorites" else "Add to Favorites",
                            tint = if (contact.isFavorite) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showMoreActionSheet = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.action_more))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 2. BUSINESS CARD SECTION (One Interactive Front/Back Card + Full Screen | Adjust Crop)
            if (!contact.profilePhotoUri.isNullOrBlank() || !contact.backPhotoUri.isNullOrBlank()) {
                FlippableContactCardViewer(
                    frontUri = contact.profilePhotoUri,
                    backUri = contact.backPhotoUri,
                    contactName = contact.fullName,
                    onOpenFullScreen = { showFullScreenCard = true },
                    onAdjustCrop = { isBack ->
                        cropTargetSideIsBack = isBack
                        showCropActionsSheet = true
                    }
                )
            }

            // Concise role line
            val roleLine = listOf(contact.designation, contact.companyName).filter { it.isNotBlank() }.joinToString(" • ")
            if (roleLine.isNotBlank()) {
                Text(roleLine, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
            }

            // Upcoming Birthday Callout
            if (birthdayInfo != null && birthdayInfo.isBirthdaySoon) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Cake, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(
                            text = if (birthdayInfo.daysUntilNextBirthday == 0) {
                                stringResource(R.string.contacts_birthday_today)
                            } else {
                                stringResource(R.string.contacts_birthday_in_days, birthdayInfo.daysUntilNextBirthday)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Device-Contact Duplicate Review Banner
            if (contact.deviceContactSyncState == "DUPLICATE_REVIEW") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, Color(0xFFF59E0B))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.contacts_phone_dup_title), fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 13.sp)
                        Text(stringResource(R.string.contacts_phone_dup_msg), style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onSyncToPhone(contact, false, contact.linkedDeviceContactId) }) { Text("Update Existing", fontSize = 11.5.sp) }
                            OutlinedButton(onClick = { onSyncToPhone(contact, true, null) }) { Text("Create New", fontSize = 11.5.sp) }
                            TextButton(onClick = { onSaveContact(contact.copy(deviceContactSyncState = "SKIPPED"), null) }) { Text("Skip", fontSize = 11.5.sp) }
                        }
                    }
                }
            }

            // 3. QUICK ACTIONS (Call | WhatsApp | Email | Map — hidden when data absent + grouped Message Templates)
            if (hasPhone || hasWhatsApp || hasEmail || hasLocation) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hasPhone) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchDialer(context, primaryPhone)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.detail_call), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                    if (hasWhatsApp) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.detail_whatsapp_full), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                    if (hasEmail) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.detail_email), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                    if (hasLocation) {
                        Button(
                            onClick = { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName, currentLat, currentLng) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.detail_map), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                }
            }

            if (hasWhatsApp || hasEmail) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.detail_msg_templates_header), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (hasWhatsApp) {
                            OutlinedButton(onClick = { showTemplateSheetFor = "WA" }, modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.detail_wa_templates), fontSize = 12.sp)
                            }
                        }
                        if (hasEmail) {
                            OutlinedButton(onClick = { showTemplateSheetFor = "EMAIL" }, modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.detail_email_templates), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 4. RELATIONSHIP BRIEF (First Met, Context, Last Contact, Next Follow-Up + View Meeting Brief)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Workspaces, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(stringResource(R.string.relationship_brief_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        }
                        TextButton(onClick = onOpenMeetingBrief, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                            Text(stringResource(R.string.view_meeting_brief_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("First Met: ${shortDateFmt.format(Date(contact.savedAtTimestamp))}", style = MaterialTheme.typography.bodySmall)
                    val ctxText = listOf(contact.meetingContext, contact.categoryTag, contact.receivedVia).filter { it.isNotBlank() }.distinct().joinToString(" • ")
                    if (ctxText.isNotBlank()) Text("Context: $ctxText", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (contact.lastContactedTimestamp > 0L) {
                        Text("Last Contact: ${shortDateFmt.format(Date(contact.lastContactedTimestamp))}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (nextFollowUp != null) {
                        Text(
                            text = "Next Follow-Up: ${nextFollowUp.title} (${dateFmt.format(Date(nextFollowUp.dueAtTimestamp))})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // 5. SEND MY CARD BACK
            OutlinedButton(
                onClick = onSendMyCardBack,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.send_my_card_back_title), fontWeight = FontWeight.Bold)
            }

            // 6. CONTACT INFORMATION (Channels only + Focused Edit button)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_completeness_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { showEditContactSheet = true }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                            Text(stringResource(R.string.action_edit), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("${stringResource(R.string.detail_phone)}: ${contact.phone.ifBlank { stringResource(R.string.detail_not_set) }}", style = MaterialTheme.typography.bodySmall)
                    Text("${stringResource(R.string.detail_whatsapp)}: ${contact.whatsapp.ifBlank { stringResource(R.string.detail_not_set) }}", style = MaterialTheme.typography.bodySmall)
                    Text("${stringResource(R.string.detail_email)}: ${contact.email.ifBlank { stringResource(R.string.detail_not_set) }}", style = MaterialTheme.typography.bodySmall)
                }
            }

            // 7. BUSINESS INFORMATION (Concise summary + Progressive Disclosure + Focused Edit button)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_business_info_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (distanceKm != null) {
                                Text("$distanceKm km", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                Spacer(Modifier.width(6.dp))
                            }
                            TextButton(onClick = { showEditBusinessSheet = true }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                                Text(stringResource(R.string.action_edit), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    if (contact.companyName.isNotBlank()) Text(contact.companyName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    if (contact.designation.isNotBlank()) Text(contact.designation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (contact.department.isNotBlank()) Text("Department: ${contact.department}", style = MaterialTheme.typography.bodySmall)

                    val hasExtraBiz = contact.alternateCompany.isNotBlank() || contact.website.isNotBlank() || contact.officeAddress.isNotBlank() || currentLat != null
                    if (hasExtraBiz) {
                        TextButton(
                            onClick = { expandBusinessDetails = !expandBusinessDetails },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.heightIn(min = 32.dp)
                        ) {
                            Text(if (expandBusinessDetails) "Hide Details" else "View Details", fontSize = 12.sp)
                            Icon(if (expandBusinessDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, modifier = Modifier.size(16.dp))
                        }
                        AnimatedVisibility(visible = expandBusinessDetails) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (contact.alternateCompany.isNotBlank()) Text("Organization (Alt): ${contact.alternateCompany}", style = MaterialTheme.typography.bodySmall)
                                if (contact.website.isNotBlank()) Text("Website: ${contact.website}", style = MaterialTheme.typography.bodySmall)
                                if (contact.officeAddress.isNotBlank()) Text("Address: ${contact.officeAddress}", style = MaterialTheme.typography.bodySmall)
                                if (currentLat != null && currentLng != null) {
                                    Text("GPS Pin: ${GeoLocationHelper.formatCoordinates(currentLat, currentLng)}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { ContactActionLauncher.launchTurnByTurnNavigation(context, currentLat, currentLng, contact.officeAddress) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_directions), fontSize = 12.sp) }
                                    OutlinedButton(onClick = {
                                        locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                        scope.launch {
                                            val coords = (if (contact.officeAddress.isNotBlank()) GeoLocationHelper.geocodeAddress(context, contact.officeAddress) else null) ?: GeoLocationHelper.getCurrentGpsCoordinates(context)
                                            if (coords != null) { currentLat = coords.first; currentLng = coords.second; onSaveContact(contact.copy(latitude = coords.first, longitude = coords.second), null); Toast.makeText(context, "GPS Pinned!", Toast.LENGTH_SHORT).show() }
                                        }
                                    }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_detect_gps), fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }

            // 8. PERSONAL INFORMATION (Collapsed by default when empty, DOB + Dynamic Age + Tags)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { expandPersonalInfo = !expandPersonalInfo },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.detail_personal_info_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Icon(if (expandPersonalInfo) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                    }

                    if (birthdayInfo != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(stringResource(R.string.contacts_dob_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(birthdayInfo.formattedDate, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.contacts_age_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(stringResource(R.string.contacts_age_years, birthdayInfo.ageYears), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    AnimatedVisibility(visible = expandPersonalInfo) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { showDobDatePicker = true }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Cake, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (birthdayInfo == null) stringResource(R.string.contacts_set_dob) else stringResource(R.string.contacts_change_dob), fontSize = 12.sp)
                                }
                                if (birthdayInfo != null) {
                                    TextButton(onClick = { onSaveContact(contact.copy(dateOfBirthIso = null), null) }) {
                                        Text(stringResource(R.string.action_clear), fontSize = 12.sp)
                                    }
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                tagOptions.forEach { tag ->
                                    FilterChip(selected = selectedTag == tag, onClick = { selectedTag = tag; onSaveContact(contact.copy(categoryTag = tag), null) }, label = { Text(tag) })
                                }
                            }
                        }
                    }
                }
            }

            // 9. FOLLOW-UP / MEETING SECTION
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_tasks_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = onOpenScheduleMeeting, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                            Text(stringResource(R.string.meeting_schedule_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newActionTitle, onValueChange = { newActionTitle = it }, label = { Text(stringResource(R.string.detail_add_task)) }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            if (newActionTitle.isNotBlank()) {
                                val item = FollowUpEntity(contactId = contact.id, contactName = contact.fullName, companyName = contact.companyName, title = newActionTitle.trim(), dueAtTimestamp = System.currentTimeMillis() + 24L * 3600_000L)
                                onAddFollowUp(item); FollowUpScheduler.scheduleForItem(context, item); newActionTitle = ""
                            }
                        }) { Text(stringResource(R.string.action_add)) }
                    }
                    contactFollowUps.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(checked = item.isCompleted, onCheckedChange = { onToggleFollowUp(item) })
                                Column {
                                    Text(item.title, fontSize = 13.sp, textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None)
                                    Text(dateFmt.format(Date(item.dueAtTimestamp)), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            IconButton(onClick = { onDeleteFollowUp(item) }) { Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
            }

            // 10. RELATIONSHIP TIMELINE
            val timelineFmt = remember { SimpleDateFormat("dd MMM", Locale.getDefault()) }
            val timelineEvents = remember(contact, contactFollowUps) {
                buildList {
                    val sourceLabel = if (contact.receivedVia.contains("OCR", true) || contact.receivedVia.contains("Scan", true)) {
                        "Business Card scanned"
                    } else "Contact added (${contact.receivedVia.ifBlank { "Manual" }})"
                    add(contact.savedAtTimestamp to sourceLabel)
                    if (contact.meetingContext.isNotBlank()) add(contact.savedAtTimestamp + 1L to "Context: ${contact.meetingContext}")
                    if (contact.notes.isNotBlank()) add(contact.savedAtTimestamp + 2L to "Private note saved")
                    contactFollowUps.forEach { fu ->
                        add(fu.createdAtTimestamp to "Scheduled: ${fu.title}")
                        if (fu.isCompleted) add(fu.dueAtTimestamp to "Completed: ${fu.title}")
                    }
                }.sortedByDescending { it.first }
            }
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Timeline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.relationship_timeline_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                    }
                    timelineEvents.take(8).forEach { (ts, desc) ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(timelineFmt.format(Date(ts)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(desc, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            // 11. PRIVATE NOTES & VOICE NOTE (Strictly user-entered/approved notes — NEVER auto-dumped raw OCR!)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_notes_label), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(
                            onClick = {
                                val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak meeting note for ${contact.fullName}")
                                }
                                runCatching { speechRecognizerLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Speech recognition unavailable", Toast.LENGTH_SHORT).show() }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.Mic, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.voice_note_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        placeholder = { Text("Add private meeting notes…") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    Button(
                        onClick = {
                            onSaveContact(contact.copy(notes = notes.trim()), null)
                            Toast.makeText(context, "Private notes saved", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.detail_save_notes)) }
                }
            }
        }
    }

    // Voice Note Transcript Review Dialog (Never saves unreviewed speech)
    pendingVoiceTranscript?.let { initialTranscript ->
        var editable by remember(initialTranscript) { mutableStateOf(initialTranscript) }
        AlertDialog(
            onDismissRequest = { pendingVoiceTranscript = null },
            title = { Text("Review Voice Note", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(value = editable, onValueChange = { editable = it }, label = { Text("Transcript") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    val clean = editable.trim()
                    if (clean.isNotBlank()) {
                        val ts = dateFmt.format(Date())
                        val updatedNotes = if (notes.isBlank()) "[$ts] $clean" else "$notes\n[$ts] $clean"
                        notes = updatedNotes
                        onSaveContact(contact.copy(notes = updatedNotes), null)
                    }
                    pendingVoiceTranscript = null
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { pendingVoiceTranscript = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    // Focused Editor: Edit Contact Information (Name, Alt Name, Phone, WhatsApp, Email)
    if (showEditContactSheet) {
        var nameD by remember(contact) { mutableStateOf(contact.fullName) }
        var altNameD by remember(contact) { mutableStateOf(contact.alternateName) }
        var phoneD by remember(contact) { mutableStateOf(contact.phone) }
        var waD by remember(contact) { mutableStateOf(contact.whatsapp) }
        var emailD by remember(contact) { mutableStateOf(contact.email) }
        AlertDialog(
            onDismissRequest = { showEditContactSheet = false },
            title = { Text("Edit Contact Information", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nameD, onValueChange = { nameD = it }, label = { Text(stringResource(R.string.edit_full_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = altNameD, onValueChange = { altNameD = it }, label = { Text("বাংলা / Alternate Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phoneD, onValueChange = { phoneD = it }, label = { Text("Phone (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = waD, onValueChange = { waD = it }, label = { Text("WhatsApp (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = emailD, onValueChange = { emailD = it }, label = { Text(stringResource(R.string.edit_email)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val cleanPhone = if (phoneD.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(phoneD)
                    val cleanWa = if (waD.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(waD)
                    val updated = contact.copy(
                        fullName = nameD.trim().ifBlank { contact.fullName },
                        alternateName = altNameD.trim(),
                        phone = cleanPhone,
                        whatsapp = cleanWa,
                        email = emailD.trim()
                    )
                    val waChanged = cleanWa != contact.whatsapp && cleanWa.isNotBlank()
                    showEditContactSheet = false
                    if (waChanged && hasPendingWaSchedules) showWaScheduleConfirmDialog = updated
                    else onSaveContact(updated, if (waChanged) cleanWa else null)
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showEditContactSheet = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    // Focused Editor: Edit Business Information (Company, Alt Company, Designation, Department, Website, Address)
    if (showEditBusinessSheet) {
        var compD by remember(contact) { mutableStateOf(contact.companyName) }
        var altCompD by remember(contact) { mutableStateOf(contact.alternateCompany) }
        var desigD by remember(contact) { mutableStateOf(contact.designation) }
        var deptD by remember(contact) { mutableStateOf(contact.department) }
        var webD by remember(contact) { mutableStateOf(contact.website) }
        var addrD by remember(contact) { mutableStateOf(contact.officeAddress) }
        AlertDialog(
            onDismissRequest = { showEditBusinessSheet = false },
            title = { Text("Edit Business Information", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = compD, onValueChange = { compD = it }, label = { Text(stringResource(R.string.edit_company)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = altCompD, onValueChange = { altCompD = it }, label = { Text("বাংলা / Alternate Organization") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = desigD, onValueChange = { desigD = it }, label = { Text(stringResource(R.string.edit_designation)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = deptD, onValueChange = { deptD = it }, label = { Text("Department") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = webD, onValueChange = { webD = it }, label = { Text(stringResource(R.string.edit_website)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = addrD, onValueChange = { addrD = it }, label = { Text(stringResource(R.string.edit_office_address)) }, minLines = 2, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveContact(
                        contact.copy(
                            companyName = compD.trim(),
                            alternateCompany = altCompD.trim(),
                            designation = desigD.trim(),
                            department = deptD.trim(),
                            website = webD.trim(),
                            officeAddress = addrD.trim()
                        ),
                        null
                    )
                    showEditBusinessSheet = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showEditBusinessSheet = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    // View Original OCR Dialog (Read-Only Reference)
    if (showRawOcrDialog) {
        AlertDialog(
            onDismissRequest = { showRawOcrDialog = false },
            title = { Text(stringResource(R.string.ocr_view_original_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        text = contact.rawOcrText.ifBlank { "No original OCR text recorded for this contact." },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showRawOcrDialog = false }) { Text(stringResource(R.string.action_close)) } }
        )
    }

    // Post-Save Crop Actions Sheet (Auto Crop Again | Adjust Manually | Reset to Original | Replace Image)
    if (showCropActionsSheet) {
        val sideName = if (cropTargetSideIsBack) "Back" else "Front"
        CardLinkActionSheet(
            title = "${stringResource(R.string.crop_adjust_title)} ($sideName)",
            actions = listOf(
                CardLinkSheetAction(Icons.Default.Crop, "Adjust Manually & Rotate") {
                    launchAdjustCropForSide(cropTargetSideIsBack)
                },
                CardLinkSheetAction(Icons.Default.AutoFixHigh, stringResource(R.string.crop_auto_btn)) {
                    scope.launch {
                        val srcUri = if (cropTargetSideIsBack) contact.backOriginalPhotoUri ?: contact.backPhotoUri else contact.frontOriginalPhotoUri ?: contact.profilePhotoUri
                        if (!srcUri.isNullOrBlank()) {
                            val updated = withContext(Dispatchers.IO) {
                                val bmp = VaultCryptoManager.decodeVaultBitmap(context, srcUri, 2000)
                                    ?: ScannedCardStorageHelper.decodeGalleryUri(context, android.net.Uri.parse(srcUri), 2000)
                                    ?: return@withContext null
                                val autoMeta = SmartCardCropEngine.detectAutoCrop(bmp)
                                val cropped = SmartCardCropEngine.applyCropAndPerspective(bmp, autoMeta)
                                val newCropUri = ScannedCardStorageHelper.saveEncryptedScannedCard(context, cropped, if (cropTargetSideIsBack) "card_back_crop" else "card_front_crop")
                                val jsonMeta = CardCropMetadata.toJson(autoMeta)
                                if (cropTargetSideIsBack) {
                                    contact.copy(backPhotoUri = newCropUri, backOriginalPhotoUri = contact.backOriginalPhotoUri ?: srcUri, backCropMetaJson = jsonMeta)
                                } else {
                                    contact.copy(profilePhotoUri = newCropUri, frontOriginalPhotoUri = contact.frontOriginalPhotoUri ?: srcUri, frontCropMetaJson = jsonMeta)
                                }
                            }
                            if (updated != null) {
                                onSaveContact(updated, null)
                                Toast.makeText(context, "Auto crop applied!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                CardLinkSheetAction(Icons.Default.Restore, stringResource(R.string.crop_reset_original)) {
                    val orig = if (cropTargetSideIsBack) contact.backOriginalPhotoUri else contact.frontOriginalPhotoUri
                    if (!orig.isNullOrBlank()) {
                        val resetContact = if (cropTargetSideIsBack) {
                            contact.copy(backPhotoUri = orig, backCropMetaJson = "")
                        } else {
                            contact.copy(profilePhotoUri = orig, frontCropMetaJson = "")
                        }
                        onSaveContact(resetContact, null)
                        Toast.makeText(context, "Reset to original image", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Already showing original image", Toast.LENGTH_SHORT).show()
                    }
                },
                CardLinkSheetAction(Icons.Default.PhotoLibrary, "Replace Image") {
                    replaceCardImageLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            ),
            onDismiss = { showCropActionsSheet = false }
        )
    }

    // Active SmartCardCropDialog for Post-Save Re-Crop
    cropSourceBitmap?.let { srcBmp ->
        val existingMeta = CardCropMetadata.fromJson(if (cropTargetSideIsBack) contact.backCropMetaJson else contact.frontCropMetaJson)
        SmartCardCropDialog(
            sourceBitmap = srcBmp,
            initialMetadata = existingMeta,
            startInManualAdjust = true,
            onConfirm = { croppedBmp, newMeta ->
                cropSourceBitmap = null
                scope.launch {
                    val updated = withContext(Dispatchers.IO) {
                        val sideSlug = if (cropTargetSideIsBack) "back" else "front"
                        val existingOrig = if (cropTargetSideIsBack) contact.backOriginalPhotoUri else contact.frontOriginalPhotoUri
                        val origUri = existingOrig ?: ScannedCardStorageHelper.saveEncryptedScannedCard(context, srcBmp, "card_${sideSlug}_orig")
                        val cropUri = ScannedCardStorageHelper.saveEncryptedScannedCard(context, croppedBmp, "card_${sideSlug}_crop")
                        val metaJson = CardCropMetadata.toJson(newMeta)
                        if (cropTargetSideIsBack) {
                            contact.copy(backPhotoUri = cropUri, backOriginalPhotoUri = origUri, backCropMetaJson = metaJson)
                        } else {
                            contact.copy(profilePhotoUri = cropUri, frontOriginalPhotoUri = origUri, frontCropMetaJson = metaJson)
                        }
                    }
                    onSaveContact(updated, null)
                    Toast.makeText(context, "Card crop updated!", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { cropSourceBitmap = null }
        )
    }

    // DOB Material3 DatePickerDialog
    if (showDobDatePicker) {
        val nowMs = remember { System.currentTimeMillis() }
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = ContactBirthdayHelper.isoDateToMillis(contact.dateOfBirthIso) ?: (nowMs - 30L * 365L * 24L * 3600_000L),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= nowMs
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDobDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { pickedMs ->
                        onSaveContact(contact.copy(dateOfBirthIso = ContactBirthdayHelper.millisToIsoDate(pickedMs)), null)
                        expandPersonalInfo = true
                    }
                    showDobDatePicker = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showDobDatePicker = false }) { Text(stringResource(R.string.action_cancel)) } }
        ) { DatePicker(state = pickerState) }
    }

    // Contact Detail ⋮ More Action Sheet
    if (showMoreActionSheet) {
        val sheetActions = buildList {
            add(CardLinkSheetAction(Icons.Default.Edit, "Edit Contact Information") { showEditContactSheet = true })
            add(CardLinkSheetAction(Icons.Default.Business, "Edit Business Information") { showEditBusinessSheet = true })
            if (!contact.profilePhotoUri.isNullOrBlank() || !contact.backPhotoUri.isNullOrBlank()) {
                add(CardLinkSheetAction(Icons.Default.Crop, stringResource(R.string.crop_adjust_title)) {
                    cropTargetSideIsBack = false
                    showCropActionsSheet = true
                })
                add(CardLinkSheetAction(Icons.Default.ZoomOutMap, stringResource(R.string.card_view_fullscreen)) { showFullScreenCard = true })
            }
            add(CardLinkSheetAction(Icons.Default.Send, stringResource(R.string.send_my_card_back_title), onClick = onSendMyCardBack))
            add(CardLinkSheetAction(Icons.Default.Event, stringResource(R.string.meeting_schedule_btn), onClick = onOpenScheduleMeeting))
            add(CardLinkSheetAction(Icons.Default.Share, stringResource(R.string.share_contact_vcf_btn)) { CardShareHelper.shareSavedContactVcf(context, contact) })
            add(CardLinkSheetAction(Icons.Default.PersonAdd, stringResource(R.string.contacts_save_to_phone_btn)) { CardShareHelper.exportToAndroidContacts(context, contact) })
            if (contact.rawOcrText.isNotBlank()) {
                add(CardLinkSheetAction(Icons.Default.Description, stringResource(R.string.ocr_view_original_title)) { showRawOcrDialog = true })
            }
            add(CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) { showDeleteConfirmDialog = true })
        }
        CardLinkActionSheet(title = contact.fullName, actions = sheetActions, onDismiss = { showMoreActionSheet = false })
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Contact?", fontWeight = FontWeight.Bold) },
            text = { Text("Remove ${contact.fullName} and associated card images from CardLink?") },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirmDialog = false; onDeleteContact() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirmDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showFullScreenCard) {
        FullScreenContactCardDialog(
            frontUri = contact.profilePhotoUri,
            backUri = contact.backPhotoUri,
            contactName = contact.fullName,
            onDismiss = { showFullScreenCard = false }
        )
    }

    val u = showWaScheduleConfirmDialog
    if (u != null) {
        AlertDialog(
            onDismissRequest = { showWaScheduleConfirmDialog = null },
            title = { Text(stringResource(R.string.detail_update_wa_title)) },
            text = { Text("Update scheduled WhatsApp recipients for this contact to ${u.whatsapp}?") },
            confirmButton = { Button(onClick = { onSaveContact(u, u.whatsapp); showWaScheduleConfirmDialog = null }) { Text(stringResource(R.string.detail_update_btn)) } },
            dismissButton = { TextButton(onClick = { onSaveContact(u, null); showWaScheduleConfirmDialog = null }) { Text(stringResource(R.string.detail_keep_existing)) } }
        )
    }

    val mode = showTemplateSheetFor
    if (mode != null) {
        AlertDialog(
            onDismissRequest = { showTemplateSheetFor = null },
            title = { Text(if (mode == "WA") "WhatsApp Templates" else "Email Templates", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MessageTemplateHelper.defaultTemplates.forEach { tmpl ->
                        val body = tmpl.buildBody(contact, mySenderName, mySenderCompany)
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            if (mode == "WA") ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName, body)
                            else ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName, tmpl.buildSubject(contact, mySenderName, mySenderCompany), body)
                            showTemplateSheetFor = null
                        }) { Column(modifier = Modifier.padding(10.dp)) { Text(tmpl.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp); Text(body, style = MaterialTheme.typography.bodySmall, maxLines = 2) } }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTemplateSheetFor = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
