package com.cardlink.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.cardlink.app.R
import com.cardlink.app.util.*

private data class PermissionHealthRow(
    val icon: ImageVector,
    val title: String,
    val purpose: String,
    val isAllowed: Boolean
)

/**
 * Lightweight Protection Status card displayed at the top of Settings -> Privacy & Security.
 * Uses calm, clear language without exposing cryptographic complexity.
 */
@Composable
fun ProtectionStatusCard(
    onOpenPermissions: () -> Unit
) {
    val context = LocalContext.current
    val bioEnabled = BiometricLockHelper.isLockEnabled(context)
    val autoLock = SecurityHardeningManager.getAutoLockDuration(context)
    val reauthEnabled = SensitiveActionAuthenticator.isReauthEnabled(context)
    val vaultActive = VaultCryptoManager.isVaultActive(context)

    val attentionCount = (if (!bioEnabled) 1 else 0) + (if (autoLock == AutoLockDuration.NEVER) 1 else 0)
    val isFullyProtected = attentionCount == 0
    val statusColor = if (isFullyProtected) Color(0xFF10B981) else Color(0xFFF59E0B)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = if (isFullyProtected) Icons.Default.VerifiedUser else Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(22.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.sec_protection_status_title),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (isFullyProtected) stringResource(R.string.sec_protection_active)
                        else "$attentionCount protection(s) need attention",
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        fontSize = 15.sp
                    )
                }
            }

            StatusCheckLine(bioEnabled, "Biometric Lock")
            StatusCheckLine(autoLock != AutoLockDuration.NEVER, "Auto-Lock: ${autoLock.labelKey}")
            StatusCheckLine(reauthEnabled, stringResource(R.string.sec_reauth_title))
            StatusCheckLine(true, "Sensitive Screens Protected")
            StatusCheckLine(vaultActive, "Encrypted Local Storage")

            OutlinedButton(
                onClick = onOpenPermissions,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.sec_permissions_title), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StatusCheckLine(ok: Boolean, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(
            imageVector = if (ok) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (ok) Color(0xFF10B981) else Color(0xFFF59E0B),
            modifier = Modifier.size(16.dp)
        )
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionHealthScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    fun granted(perm: String): Boolean =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    val notifAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        granted(Manifest.permission.POST_NOTIFICATIONS)
    } else true

    val rows = listOf(
        PermissionHealthRow(
            icon = Icons.Default.PhotoCamera,
            title = "Camera",
            purpose = "Used for Scan Card, Universal QR Scanner, Loyalty Cards, and ID capture.",
            isAllowed = granted(Manifest.permission.CAMERA)
        ),
        PermissionHealthRow(
            icon = Icons.Default.Notifications,
            title = "Notifications",
            purpose = "Used for Follow-Ups, ID expiry reminders, and Backup reminders.",
            isAllowed = notifAllowed
        ),
        PermissionHealthRow(
            icon = Icons.Default.Contacts,
            title = "Contacts",
            purpose = "Used only when importing or saving contacts to your device phonebook.",
            isAllowed = granted(Manifest.permission.READ_CONTACTS)
        ),
        PermissionHealthRow(
            icon = Icons.Default.LocationOn,
            title = "Location",
            purpose = "Used only when pinning your office address or creating a Location QR code.",
            isAllowed = granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.sec_permissions_title), fontWeight = FontWeight.Bold)
                        Text(
                            "CardLink requests permissions only when a feature needs them",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
            ) {
                Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhotoLibrary, null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "Photos & Files use Android's scoped Photo Picker and Storage Access Framework — CardLink does not request broad storage access.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            rows.forEach { row ->
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(row.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(row.title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                                Text(
                                    text = if (row.isAllowed) "Allowed" else "Not Allowed",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (row.isAllowed) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(row.purpose, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Button(
                onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                    runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Settings, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.sec_open_settings), fontWeight = FontWeight.Bold)
            }
        }
    }
}
