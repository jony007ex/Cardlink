package com.cardlink.app.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.SystemClock
import android.widget.Toast
import androidx.fragment.app.FragmentActivity

/**
 * Centralized Sensitive Action Re-Authentication with a short 2-minute monotonic trust window.
 * - Never persists `isAuthenticated = true` to disk.
 * - Automatically invalidates when app locks, Auto-Lock triggers, Panic Lock triggers, or process recreates.
 * - Reuses CardLink's existing BiometricLockHelper (BiometricPrompt + Device Credential fallback).
 */
object SensitiveActionAuthenticator {
    private const val PREFS = "cardlink_security_hardening_prefs"
    private const val KEY_REQUIRE_SENSITIVE_REAUTH = "require_sensitive_action_reauth"
    private const val TRUST_WINDOW_MS = 2L * 60_000L // 2 minutes

    @Volatile
    private var lastVerifiedElapsedMs: Long = -1L

    fun isReauthEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_REQUIRE_SENSITIVE_REAUTH, true)

    fun setReauthEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_REQUIRE_SENSITIVE_REAUTH, enabled)
            .apply()
        if (!enabled) invalidateTrustWindow()
        SecurityHardeningManager.logAuditEventAsync(
            context,
            "SENSITIVE_REAUTH_SETTING",
            "Security",
            true,
            if (enabled) "Sensitive Action Verification enabled" else "Sensitive Action Verification disabled"
        )
    }

    fun isWithinTrustWindow(): Boolean {
        val ts = lastVerifiedElapsedMs
        if (ts < 0L) return false
        return (SystemClock.elapsedRealtime() - ts) in 0L..TRUST_WINDOW_MS
    }

    fun markJustVerified() {
        lastVerifiedElapsedMs = SystemClock.elapsedRealtime()
    }

    fun invalidateTrustWindow() {
        lastVerifiedElapsedMs = -1L
    }

    private tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
        is FragmentActivity -> this
        is ContextWrapper -> baseContext.findFragmentActivity()
        else -> null
    }

    /**
     * Guards a genuinely high-risk action.
     * If Biometric Lock / device screen lock is available and the 2-minute trust window has expired,
     * prompts via BiometricLockHelper before executing [onAuthorized].
     */
    fun verifyBeforeSensitiveAction(
        context: Context,
        actionLabel: String,
        forcePrompt: Boolean = false,
        onAuthorized: () -> Unit,
        onCancelledOrFailed: (String) -> Unit = {}
    ) {
        if (!isReauthEnabled(context) && !forcePrompt) {
            onAuthorized()
            return
        }
        if (!forcePrompt && isWithinTrustWindow()) {
            onAuthorized()
            return
        }
        if (!BiometricLockHelper.canAuthenticate(context)) {
            // Device has no screen lock or biometrics enrolled — allow gracefully without locking user out
            onAuthorized()
            return
        }
        val activity = context.findFragmentActivity()
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            onCancelledOrFailed("Authentication context unavailable.")
            return
        }

        BiometricLockHelper.showPrompt(
            activity = activity,
            onSuccess = {
                markJustVerified()
                SecurityHardeningManager.logAuditEventAsync(
                    context,
                    "SENSITIVE_AUTH_OK",
                    "Security",
                    true,
                    "Verified for $actionLabel"
                )
                onAuthorized()
            },
            onFallbackToDeviceCredential = {
                val intent = BiometricLockHelper.createDeviceCredentialIntent(context)
                if (intent == null) {
                    SecurityHardeningManager.logAuditEventAsync(context, "SENSITIVE_AUTH_FAIL", "Security", false, "No credential fallback")
                    onCancelledOrFailed("Device authentication unavailable.")
                } else {
                    Toast.makeText(context, "Please use Biometrics or Device Lock to verify.", Toast.LENGTH_SHORT).show()
                    onCancelledOrFailed("Authentication required.")
                }
            },
            onError = { err ->
                SecurityHardeningManager.logAuditEventAsync(context, "SENSITIVE_AUTH_FAIL", "Security", false, "Verification cancelled or failed")
                onCancelledOrFailed(err)
            }
        )
    }
}
