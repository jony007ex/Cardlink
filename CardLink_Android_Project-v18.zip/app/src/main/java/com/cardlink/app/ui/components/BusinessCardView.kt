package com.cardlink.app.ui.components

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.util.PremiumExtrasHelper

@Composable
fun BusinessCardView(card: BusinessCardEntity, modifier: Modifier = Modifier) {
    val isIvory = card.template == CardTemplate.MINIMAL_IVORY
    val isSplit = card.template == CardTemplate.MODERN_SPLIT
    val isModernMinimal = card.template == CardTemplate.MODERN_MINIMAL
    val isFuturistic = card.template == CardTemplate.FUTURISTIC_PROFESSIONAL

    val bgPrimary = if (isIvory || isModernMinimal) Color(0xFFFAF9F6) else Color(card.primaryColorHex)
    val bgSecondary = if (isIvory || isModernMinimal) Color(0xFFF1EFEA) else Color(card.cardGradientEndHex)
    val accentColor = Color(card.accentColorHex)
    val textColor = if (isIvory || isModernMinimal) Color(0xFF0F172A) else Color(card.textColorHex)

    val fontFamily = when (card.fontFamilyName) {
        "Serif" -> FontFamily.Serif
        "Monospace" -> FontFamily.Monospace
        else -> FontFamily.SansSerif
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 230.dp)
            .border(
                width = if (isFuturistic) 2.dp else 1.5.dp,
                color = if (isFuturistic) accentColor.copy(alpha = 0.85f) else accentColor.copy(alpha = 0.65f),
                shape = RoundedCornerShape(card.cornerRadiusDp.dp)
            ),
        shape = RoundedCornerShape(card.cornerRadiusDp.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isModernMinimal) 4.dp else 12.dp)
    ) {
        when {
            isModernMinimal -> {
                Column(
                    modifier = Modifier.fillMaxWidth().background(bgPrimary).padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProfileAvatar(card, accentColor, textColor, fontFamily, 56)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(card.fullName.ifBlank { "Your Full Name" }, color = textColor, fontSize = 21.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif)
                            Text(
                                listOf(card.designation, card.companyName).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "Professional Profile" },
                                color = textColor.copy(alpha = 0.7f), fontSize = 13.sp, fontFamily = FontFamily.SansSerif
                            )
                        }
                    }
                    HorizontalDivider(thickness = 1.dp, color = accentColor.copy(alpha = 0.45f))
                    ContactLines(card, accentColor, textColor, FontFamily.SansSerif)
                }
            }

            isFuturistic -> {
                Box(
                    modifier = Modifier.fillMaxWidth().background(
                        Brush.linearGradient(listOf(Color(card.primaryColorHex), Color(card.secondaryColorHex), Color(card.cardGradientEndHex)))
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth().padding(10.dp)
                            .clip(RoundedCornerShape((card.cornerRadiusDp - 4).coerceAtLeast(12).dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape((card.cornerRadiusDp - 4).coerceAtLeast(12).dp))
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                ProfileAvatar(card, accentColor, Color.White, fontFamily, 60)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(card.fullName.ifBlank { "Your Full Name" }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = fontFamily)
                                    Text(card.designation.ifBlank { "Designation" }, color = accentColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFamily = fontFamily)
                                    Text(listOf(card.department, card.companyName).filter { it.isNotBlank() }.joinToString(" • "), color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp, fontFamily = fontFamily)
                                }
                            }
                            HorizontalDivider(color = accentColor.copy(alpha = 0.35f))
                            ContactLines(card, accentColor, Color.White, fontFamily)
                        }
                    }
                }
            }

            isSplit -> {
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Column(
                        modifier = Modifier.width(116.dp).fillMaxHeight().background(accentColor).padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) { ProfileAvatar(card, Color(0xFF0A192F), Color.White, fontFamily, 66) }
                    Column(
                        modifier = Modifier.weight(1f).background(bgPrimary).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(card.fullName.ifBlank { "Your Full Name" }, color = textColor, fontSize = 19.sp, fontWeight = FontWeight.Bold, fontFamily = fontFamily)
                        Text(card.designation.ifBlank { "Designation" }, color = accentColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFamily = fontFamily)
                        Text(listOf(card.department, card.companyName).filter { it.isNotBlank() }.joinToString(" • "), color = textColor.copy(alpha = 0.75f), fontSize = 11.sp, fontFamily = fontFamily)
                        HorizontalDivider(color = accentColor.copy(alpha = 0.35f))
                        ContactLines(card, accentColor, textColor, fontFamily)
                    }
                }
            }

            else -> {
                Box(modifier = Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(bgPrimary, bgSecondary)))) {
                    Box(modifier = Modifier.fillMaxWidth().height(5.dp).background(accentColor))
                    Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            ProfileAvatar(card, accentColor, accentColor, fontFamily, 62)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(card.fullName.ifBlank { "Your Full Name" }, color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = fontFamily)
                                Text(card.designation.ifBlank { "Professional Designation" }, color = accentColor, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, fontFamily = fontFamily)
                                Text(listOf(card.department, card.companyName).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "Organization Name" }, color = textColor.copy(alpha = 0.8f), fontSize = 12.sp, fontFamily = fontFamily)
                            }
                        }
                        HorizontalDivider(color = accentColor.copy(alpha = 0.35f))
                        ContactLines(card, accentColor, textColor, fontFamily)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileAvatar(card: BusinessCardEntity, borderColor: Color, initialsColor: Color, fontFamily: FontFamily, sizeDp: Int) {
    if (!card.profilePhotoUri.isNullOrBlank()) {
        AsyncImage(model = Uri.parse(card.profilePhotoUri), contentDescription = "Profile Photo", contentScale = ContentScale.Crop, modifier = Modifier.size(sizeDp.dp).clip(CircleShape).border(2.dp, borderColor, CircleShape))
    } else {
        Surface(modifier = Modifier.size(sizeDp.dp).clip(CircleShape).border(2.dp, borderColor, CircleShape), color = borderColor.copy(alpha = 0.18f)) {
            Box(contentAlignment = Alignment.Center) {
                Text(card.fullName.take(2).uppercase().ifBlank { "CL" }, color = initialsColor, fontWeight = FontWeight.Bold, fontSize = 20.sp, fontFamily = fontFamily)
            }
        }
    }
}

@Composable
private fun ContactLines(card: BusinessCardEntity, accentColor: Color, textColor: Color, fontFamily: FontFamily) {
    val iconTint = Color(card.iconColorHex)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (card.phone.isNotBlank() && card.sharePhone) InfoRow(Icons.Default.Phone, card.phone, iconTint.copy(alpha = 0.9f), textColor, fontFamily)
        if (card.email.isNotBlank() && card.shareEmail) InfoRow(Icons.Default.Email, card.email, iconTint.copy(alpha = 0.9f), textColor, fontFamily)
        if (card.website.isNotBlank()) InfoRow(Icons.Default.Language, card.website, iconTint.copy(alpha = 0.9f), textColor, fontFamily)
        if (card.officeAddress.isNotBlank() && card.shareAddress) InfoRow(Icons.Default.LocationOn, card.officeAddress, iconTint.copy(alpha = 0.9f), textColor, fontFamily)
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, tint: Color, color: Color, fontFamily: FontFamily) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Text(text = text, color = color, fontSize = 13.sp, fontFamily = fontFamily)
    }
}

@Composable
fun FlippableBusinessCardView(card: BusinessCardEntity, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var isFlipped by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(targetValue = if (isFlipped) 180f else 0f, animationSpec = tween(500), label = "card_flip")
    val brandedQr = remember(card) { PremiumExtrasHelper.generateBrandedQrBitmap(context, card, 420) }

    Box(modifier = modifier.fillMaxWidth().clickable { isFlipped = !isFlipped }.graphicsLayer { rotationY = rotation; cameraDistance = 14f * density }) {
        if (rotation <= 90f) {
            BusinessCardView(card = card)
        } else {
            val accentColor = Color(card.accentColorHex)
            Card(
                modifier = Modifier.fillMaxWidth().heightIn(min = 230.dp).graphicsLayer { rotationY = 180f }.border(1.5.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(card.cornerRadiusDp.dp)),
                shape = RoundedCornerShape(card.cornerRadiusDp.dp), elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(card.primaryColorHex), Color(card.cardGradientEndHex)))).padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, modifier = Modifier.size(135.dp)) {
                        Image(bitmap = brandedQr.asImageBitmap(), contentDescription = "Branded QR", modifier = Modifier.fillMaxSize().padding(6.dp))
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(card.companyName.ifBlank { "Card Link" }, color = accentColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (card.bio.isNotBlank()) Text(card.bio, color = Color(card.textColorHex).copy(alpha = 0.88f), fontSize = 12.sp, maxLines = 4)
                        Text("Tap card to flip front", color = accentColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
