package com.cardlink.app.util

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.serialization.Serializable
import kotlin.math.pow

@Serializable
data class AppCustomThemeConfig(
    val primaryHex: Long = 0xFF0A192F,
    val secondaryHex: Long = 0xFFD4AF37,
    val backgroundHex: Long = 0xFF0A192F,
    val surfaceHex: Long = 0xFF112240,
    val textHex: Long = 0xFFF8FAFC,
    val accentHex: Long = 0xFFD4AF37,
    val buttonHex: Long = 0xFFD4AF37,
    val iconHex: Long = 0xFFD4AF37
)

object ThemeContrastHelper {
    private const val PREFS = "cardlink_custom_theme_prefs"

    fun loadAppTheme(context: Context): AppCustomThemeConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AppCustomThemeConfig(
            primaryHex = p.getLong("app_primary", 0xFF0A192F),
            secondaryHex = p.getLong("app_secondary", 0xFFD4AF37),
            backgroundHex = p.getLong("app_bg", 0xFF0A192F),
            surfaceHex = p.getLong("app_surface", 0xFF112240),
            textHex = p.getLong("app_text", 0xFFF8FAFC),
            accentHex = p.getLong("app_accent", 0xFFD4AF37),
            buttonHex = p.getLong("app_button", 0xFFD4AF37),
            iconHex = p.getLong("app_icon", 0xFFD4AF37)
        )
    }

    fun saveAppTheme(context: Context, cfg: AppCustomThemeConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("app_primary", cfg.primaryHex)
            .putLong("app_secondary", cfg.secondaryHex)
            .putLong("app_bg", cfg.backgroundHex)
            .putLong("app_surface", cfg.surfaceHex)
            .putLong("app_text", cfg.textHex)
            .putLong("app_accent", cfg.accentHex)
            .putLong("app_button", cfg.buttonHex)
            .putLong("app_icon", cfg.iconHex)
            .apply()
    }

    fun resetAppTheme(context: Context): AppCustomThemeConfig {
        val def = AppCustomThemeConfig()
        saveAppTheme(context, def)
        return def
    }

    fun parseHexColorOrNull(input: String): Long? {
        val cleaned = input.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
        return when (cleaned.length) {
            6 -> cleaned.toLongOrNull(16)?.let { 0xFF000000L or it }
            8 -> cleaned.toLongOrNull(16)
            else -> null
        }
    }

    fun formatHex(colorLong: Long): String {
        val rgb = colorLong and 0x00FFFFFFL
        return String.format("#%06X", rgb)
    }

    private fun relativeLuminance(color: Color): Double {
        fun channel(v: Float): Double {
            val d = v.toDouble()
            return if (d <= 0.03928) d / 12.92 else ((d + 0.055) / 1.055).pow(2.4)
        }
        return 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
    }

    fun contrastRatio(fgHex: Long, bgHex: Long): Double {
        val l1 = relativeLuminance(Color(fgHex.toInt()))
        val l2 = relativeLuminance(Color(bgHex.toInt()))
        val lighter = maxOf(l1, l2)
        val darker = minOf(l1, l2)
        return (lighter + 0.05) / (darker + 0.05)
    }

    fun lowContrastWarning(fgHex: Long, bgHex: Long, label: String = "Text"): String? {
        val ratio = contrastRatio(fgHex, bgHex)
        return if (ratio < 3.0) {
            "Low contrast (${String.format("%.1f", ratio)}:1) between $label and background — readability may be poor."
        } else null
    }

    fun safeQrForegroundInt(cardPrimaryHex: Long): Int {
        val ratioWithWhite = contrastRatio(cardPrimaryHex, 0xFFFFFFFFL)
        return if (ratioWithWhite >= 4.5) Color(cardPrimaryHex.toInt()).toArgb()
        else android.graphics.Color.parseColor("#0A192F")
    }
}
