package com.cardlink.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.cardlink.app.util.AppCustomThemeConfig

val NavyPrimary = Color(0xFF0A192F)
val NavySurface = Color(0xFF112240)
val CharcoalDark = Color(0xFF1E293B)
val GoldAccent = Color(0xFFD4AF37)
val OffWhite = Color(0xFFF8FAFC)

private val DarkColors = darkColorScheme(
    primary = GoldAccent,
    onPrimary = NavyPrimary,
    secondary = Color(0xFF64FFDA),
    background = NavyPrimary,
    surface = NavySurface,
    onBackground = OffWhite,
    onSurface = OffWhite
)

private val LightColors = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    secondary = GoldAccent,
    background = OffWhite,
    surface = Color.White,
    onBackground = NavyPrimary,
    onSurface = CharcoalDark
)

@Composable
fun CardLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    customConfig: AppCustomThemeConfig? = null,
    content: @Composable () -> Unit
) {
    val scheme = if (customConfig != null && darkTheme) {
        darkColorScheme(
            primary = Color(customConfig.buttonHex.toInt()),
            onPrimary = Color(customConfig.primaryHex.toInt()),
            secondary = Color(customConfig.secondaryHex.toInt()),
            background = Color(customConfig.backgroundHex.toInt()),
            surface = Color(customConfig.surfaceHex.toInt()),
            onBackground = Color(customConfig.textHex.toInt()),
            onSurface = Color(customConfig.textHex.toInt())
        )
    } else if (darkTheme) {
        DarkColors
    } else {
        LightColors
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
