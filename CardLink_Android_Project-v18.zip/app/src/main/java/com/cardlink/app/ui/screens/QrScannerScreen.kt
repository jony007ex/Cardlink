package com.cardlink.app.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cardlink.app.R
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.ContactActionLauncher
import com.cardlink.app.util.ScannedCardStorageHelper
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.atomic.AtomicBoolean

private val NeonCyan = Color(0xFF00E5FF)
private val ElectricBlue = Color(0xFF2563EB)
private val NeonPurple = Color(0xFF9333EA)
private val DetectedGreen = Color(0xFF10B981)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    onSaveContact: (SavedContactEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var hasCam by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var permissionRequested by remember { mutableStateOf(false) }

    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var isTorchOn by remember { mutableStateOf(false) }
    var isZoom2x by remember { mutableStateOf(false) }

    var isDetectedPulse by remember { mutableStateOf(false) }
    var scannedRaw by remember { mutableStateOf<String?>(null) }
    var galleryCandidates by remember { mutableStateOf<List<String>>(emptyList()) }
    var scanErrorMessage by remember { mutableStateOf<String?>(null) }

    // Atomic guard prevents duplicate scan events while sheet or pulse animation is active
    val isScanLocked = remember { AtomicBoolean(false) }

    val camPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCam = granted
        permissionRequested = true
    }

    LaunchedEffect(Unit) {
        if (!hasCam) {
            camPermLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Apply Torch & Zoom safely whenever toggled or camera binds
    LaunchedEffect(cameraRef, isTorchOn) {
        val cam = cameraRef ?: return@LaunchedEffect
        if (cam.cameraInfo.hasFlashUnit()) {
            runCatching { cam.cameraControl.enableTorch(isTorchOn) }
        }
    }
    LaunchedEffect(cameraRef, isZoom2x) {
        val cam = cameraRef ?: return@LaunchedEffect
        val maxZoom = cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 2f
        val targetZoom = if (isZoom2x) 2f.coerceAtMost(maxZoom) else 1f
        runCatching { cam.cameraControl.setZoomRatio(targetZoom) }
    }

    // Clean up torch on exit
    DisposableEffect(Unit) {
        onDispose {
            runCatching { cameraRef?.cameraControl?.enableTorch(false) }
        }
    }

    fun triggerDetectedFeedback(rawValue: String) {
        if (!isScanLocked.compareAndSet(false, true)) return
        scanErrorMessage = null
        isDetectedPulse = true
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        scope.launch {
            delay(320)
            scannedRaw = rawValue
        }
    }

    fun resetScannerState() {
        scannedRaw = null
        galleryCandidates = emptyList()
        scanErrorMessage = null
        isDetectedPulse = false
        isScanLocked.set(false)
    }

    val galleryQrPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scanErrorMessage = null
            scope.launch {
                runCatching {
                    val bmp = ScannedCardStorageHelper.decodeGalleryUri(context, uri)
                        ?: error("Could not read selected image.")
                    val scanner = BarcodeScanning.getClient()
                    val values = scanner.process(InputImage.fromBitmap(bmp, 0)).await()
                        .mapNotNull { it.rawValue?.trim() }
                        .filter { it.isNotBlank() }
                        .distinct()
                    when {
                        values.isEmpty() -> {
                            scanErrorMessage = "No QR code found in the selected photo."
                            isScanLocked.set(false)
                        }
                        values.size == 1 -> {
                            triggerDetectedFeedback(values.first())
                        }
                        else -> {
                            isScanLocked.set(true)
                            isDetectedPulse = true
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            galleryCandidates = values
                        }
                    }
                }.onFailure {
                    scanErrorMessage = "Failed to decode QR: ${it.localizedMessage}"
                    isScanLocked.set(false)
                }
            }
        }
    }

    // Laser animation (runs only when actively scanning)
    val infiniteTransition = rememberInfiniteTransition(label = "qr_laser")
    val laserProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    val framePulseScale by animateFloatAsState(
        targetValue = if (isDetectedPulse) 1.045f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "frame_pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060E24))
    ) {
        if (hasCam) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        runCatching {
                            val provider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            val scanner = BarcodeScanning.getClient()
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()
                                .apply {
                                    setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                        @Suppress("UnsafeOptInUsageError")
                                        val mediaImage = proxy.image
                                        if (mediaImage != null && !isScanLocked.get()) {
                                            val inputImage = InputImage.fromMediaImage(
                                                mediaImage,
                                                proxy.imageInfo.rotationDegrees
                                            )
                                            scanner.process(inputImage)
                                                .addOnSuccessListener { barcodes ->
                                                    val first = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue?.trim()
                                                    if (!first.isNullOrBlank()) {
                                                        triggerDetectedFeedback(first)
                                                    }
                                                }
                                                .addOnCompleteListener {
                                                    proxy.close()
                                                }
                                        } else {
                                            proxy.close()
                                        }
                                    }
                                }
                            provider.unbindAll()
                            cameraRef = provider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                analysis
                            )
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )

            // 60% Dark Scrim + Clear Rounded-Square Cutout + Glowing Neon Corner Brackets + Animated Laser Line
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            ) {
                val baseFrameSize = minOf(size.width, size.height) * 0.68f
                val frameSize = baseFrameSize * framePulseScale
                val left = (size.width - frameSize) / 2f
                val top = (size.height - frameSize) / 2.15f
                val cornerRadiusPx = 28.dp.toPx()

                // 60% dark scrim overlay
                drawRect(color = Color.Black.copy(alpha = 0.60f))

                // Clear rounded-square viewfinder cutout
                drawRoundRect(
                    color = Color.Transparent,
                    topLeft = Offset(left, top),
                    size = Size(frameSize, frameSize),
                    cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
                    blendMode = BlendMode.Clear
                )

                // Subtle thin inner border
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.16f),
                    topLeft = Offset(left, top),
                    size = Size(frameSize, frameSize),
                    cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Animated neon cyan laser scan line + soft trail (stops when detected)
                if (!isDetectedPulse) {
                    val innerPad = 14.dp.toPx()
                    val scanTop = top + innerPad
                    val scanBottom = top + frameSize - innerPad
                    val laserY = scanTop + (scanBottom - scanTop) * laserProgress
                    val trailHeight = 36.dp.toPx()

                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, NeonCyan.copy(alpha = 0.28f), NeonCyan.copy(alpha = 0.65f)),
                            startY = (laserY - trailHeight).coerceAtLeast(scanTop),
                            endY = laserY
                        ),
                        topLeft = Offset(left + innerPad, (laserY - trailHeight).coerceAtLeast(scanTop)),
                        size = Size(frameSize - innerPad * 2, (laserY - (laserY - trailHeight).coerceAtLeast(scanTop)).coerceAtLeast(1f))
                    )
                    drawLine(
                        brush = Brush.horizontalGradient(listOf(Color.Transparent, NeonCyan, Color.White, NeonCyan, Color.Transparent)),
                        start = Offset(left + innerPad, laserY),
                        end = Offset(left + frameSize - innerPad, laserY),
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }

                // Glowing Cyan -> Electric Blue -> Purple Corner Brackets (turns Emerald Green on detection)
                val bracketBrush = if (isDetectedPulse) {
                    Brush.linearGradient(listOf(DetectedGreen, DetectedGreen))
                } else {
                    Brush.linearGradient(
                        colors = listOf(NeonCyan, ElectricBlue, NeonPurple),
                        start = Offset(left, top),
                        end = Offset(left + frameSize, top + frameSize)
                    )
                }

                val arm = 34.dp.toPx()
                val r = cornerRadiusPx
                val strokeWidth = 5.dp.toPx()
                val glowStrokeWidth = 11.dp.toPx()

                fun drawCornerPath(path: Path) {
                    drawPath(
                        path = path,
                        color = if (isDetectedPulse) DetectedGreen.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.28f),
                        style = Stroke(width = glowStrokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                    drawPath(
                        path = path,
                        brush = bracketBrush,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }

                // Top-Left
                drawCornerPath(Path().apply {
                    moveTo(left, top + arm)
                    lineTo(left, top + r)
                    quadraticBezierTo(left, top, left + r, top)
                    lineTo(left + arm, top)
                })
                // Top-Right
                drawCornerPath(Path().apply {
                    moveTo(left + frameSize - arm, top)
                    lineTo(left + frameSize - r, top)
                    quadraticBezierTo(left + frameSize, top, left + frameSize, top + r)
                    lineTo(left + frameSize, top + arm)
                })
                // Bottom-Left
                drawCornerPath(Path().apply {
                    moveTo(left, top + frameSize - arm)
                    lineTo(left, top + frameSize - r)
                    quadraticBezierTo(left, top + frameSize, left + r, top + frameSize)
                    lineTo(left + arm, top + frameSize)
                })
                // Bottom-Right
                drawCornerPath(Path().apply {
                    moveTo(left + frameSize - arm, top + frameSize)
                    lineTo(left + frameSize - r, top + frameSize)
                    quadraticBezierTo(left + frameSize, top + frameSize, left + frameSize, top + frameSize - r)
                    lineTo(left + frameSize, top + frameSize - arm)
                })
            }

            // Helpful subtle status pill above bottom dock
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(top = 340.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF0A192F).copy(alpha = 0.72f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isDetectedPulse) DetectedGreen else NeonCyan.copy(alpha = 0.4f)
                    )
                ) {
                    Text(
                        text = if (isDetectedPulse) stringResource(R.string.qr_detected) else stringResource(R.string.qr_align_hint),
                        color = if (isDetectedPulse) DetectedGreen else Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                    )
                }
            }
        } else {
            // Permission Denied / Prompt State (Gallery scan still available!)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.QrCodeScanner, null, tint = NeonCyan, modifier = Modifier.size(68.dp))
                Spacer(Modifier.height(14.dp))
                Text(stringResource(R.string.qr_cam_required), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Allow camera access to scan live QR codes, or use Scan from Gallery below.",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = { camPermLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = NavyPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.qr_grant_cam), fontWeight = FontWeight.Bold) }
                if (permissionRequested) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.fromParts("package", context.packageName, null)
                                    }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Open App Settings", color = Color.White) }
                }
            }
        }

        // Clean Transparent Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.42f))
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = stringResource(R.string.qr_scan_title),
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Bottom Frosted Glass Floating Control Bar + Optional Error Banner
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (scanErrorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = scanErrorMessage!!,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color(0xFF0A192F).copy(alpha = 0.80f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.55f), NeonPurple.copy(alpha = 0.55f)))
                ),
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Flashlight (Torch) Toggle
                    GlassControlButton(
                        icon = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        label = if (isTorchOn) stringResource(R.string.qr_flash_on) else stringResource(R.string.qr_flash),
                        isActive = isTorchOn,
                        enabled = hasCam && (cameraRef?.cameraInfo?.hasFlashUnit() != false),
                        onClick = { isTorchOn = !isTorchOn }
                    )

                    // Scan from Gallery
                    GlassControlButton(
                        icon = Icons.Default.PhotoLibrary,
                        label = stringResource(R.string.qr_gallery),
                        isActive = false,
                        enabled = true,
                        onClick = {
                            galleryQrPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )

                    // 1x / 2x Zoom Toggle
                    GlassControlButton(
                        icon = Icons.Default.ZoomIn,
                        label = if (isZoom2x) "2x Zoom" else "1x Zoom",
                        isActive = isZoom2x,
                        enabled = hasCam,
                        onClick = { isZoom2x = !isZoom2x }
                    )
                }
            }
        }
    }

    // ModalBottomSheet for Multi-QR Selection OR Scanned QR Preview & Confirmation
    val showSheet = galleryCandidates.isNotEmpty() || scannedRaw != null
    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { resetScannerState() },
            containerColor = Color(0xFF0F1E3A),
            contentColor = Color.White
        ) {
            if (galleryCandidates.isNotEmpty() && scannedRaw == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(stringResource(R.string.qr_multiple_title), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = NeonCyan)
                    Text("Choose which QR code to preview:", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.75f))
                    galleryCandidates.forEachIndexed { idx, candidate ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                scannedRaw = candidate
                                galleryCandidates = emptyList()
                            },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF162A4D)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("QR #${idx + 1}", fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
                                Text(candidate, maxLines = 2, style = MaterialTheme.typography.bodySmall, color = Color.White)
                            }
                        }
                    }
                    OutlinedButton(onClick = { resetScannerState() }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.action_cancel), color = Color.White)
                    }
                    Spacer(Modifier.height(16.dp))
                }
            } else if (scannedRaw != null) {
                val raw = scannedRaw!!
                val isVCard = raw.contains("BEGIN:VCARD", true)
                val isMeCard = raw.startsWith("MECARD:", true)
                val isUrl = raw.startsWith("http://", true) || raw.startsWith("https://", true) || raw.startsWith("www.", true)

                val parsedContact = remember(raw) {
                    when {
                        isVCard -> CardShareHelper.parseVCardToContact(raw, "QR Scan")
                        isMeCard -> CardShareHelper.parseMeCardToContact(raw, "QR Scan")
                        isUrl -> SavedContactEntity(
                            fullName = "Scanned Web Card",
                            website = raw,
                            notes = "Scanned QR Link: $raw",
                            receivedVia = "QR Link"
                        )
                        else -> SavedContactEntity(
                            fullName = "Scanned QR Info",
                            notes = raw,
                            receivedVia = "QR Scan"
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, null, tint = DetectedGreen)
                        Text(stringResource(R.string.qr_preview_title), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF162A4D)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (isVCard || isMeCard) {
                                Text(parsedContact.fullName, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                if (parsedContact.designation.isNotBlank()) Text(parsedContact.designation, color = NeonCyan, fontWeight = FontWeight.SemiBold)
                                if (parsedContact.companyName.isNotBlank()) Text(parsedContact.companyName, color = Color.White.copy(alpha = 0.85f))
                                if (parsedContact.phone.isNotBlank()) Text("Phone: ${parsedContact.phone}", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                                if (parsedContact.email.isNotBlank()) Text("Email: ${parsedContact.email}", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                                if (parsedContact.website.isNotBlank()) Text("Link: ${parsedContact.website}", color = GoldAccent, fontSize = 13.sp)
                            } else {
                                Text(
                                    if (isUrl) "Website / Profile Link (Confirm before opening)" else "QR Text Content",
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyan
                                )
                                Text(raw, color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (isUrl || parsedContact.website.isNotBlank()) {
                        val targetUrl = if (isUrl) raw else parsedContact.website
                        OutlinedButton(
                            onClick = { ContactActionLauncher.launchExternalUrl(context, targetUrl) },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, null, tint = NeonCyan)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.qr_open_link_confirm), color = NeonCyan, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Button(
                        onClick = {
                            onSaveContact(parsedContact)
                            Toast.makeText(context, "Saved to My Contacts!", Toast.LENGTH_SHORT).show()
                            resetScannerState()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_save_to_contacts), fontWeight = FontWeight.Bold)
                    }

                    TextButton(onClick = { resetScannerState() }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.qr_scan_another), color = Color.White.copy(alpha = 0.8f))
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun GlassControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val tint = when {
        !enabled -> Color.White.copy(alpha = 0.35f)
        isActive -> NeonCyan
        else -> Color.White
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = tint, fontSize = 11.sp, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium)
    }
}
