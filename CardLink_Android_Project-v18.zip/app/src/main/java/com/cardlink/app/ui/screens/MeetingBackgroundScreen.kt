package com.cardlink.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoCameraFront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cardlink.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.PremiumExtrasHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeetingBackgroundScreen(
    activeCard: BusinessCardEntity,
    onExported: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val previewBitmap = remember(activeCard) {
        PremiumExtrasHelper.renderMeetingBackgroundBitmap(context, activeCard)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.meeting_bg_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.VideoCameraFront, null, tint = GoldAccent)
                Text(stringResource(R.string.meeting_bg_sub), fontWeight = FontWeight.SemiBold)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .border(1.5.dp, GoldAccent, RoundedCornerShape(14.dp)),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Image(
                    bitmap = previewBitmap.asImageBitmap(),
                    contentDescription = "16:9 Virtual Meeting Background Preview",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Why this layout works great:", fontWeight = FontWeight.Bold, color = GoldAccent)
                    Text("• Full HD 1920×1080 (16:9) widescreen format.", style = MaterialTheme.typography.bodySmall)
                    Text("• Name, Designation & Logo stay visible in the top-left corner.", style = MaterialTheme.typography.bodySmall)
                    Text("• Branded QR code sits in the top-right corner so attendees can scan it live without being blocked by you.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = {
                    onExported()
                    PremiumExtrasHelper.shareMeetingBackground(context, activeCard)
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Share, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.meeting_bg_share_btn), fontWeight = FontWeight.Bold)
            }
        }
    }
}
