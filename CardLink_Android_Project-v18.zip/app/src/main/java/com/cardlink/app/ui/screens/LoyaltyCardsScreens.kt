package com.cardlink.app.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.cardlink.app.R
import com.cardlink.app.data.model.LoyaltyCardEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.LoyaltyCodeHelper
import com.cardlink.app.util.ScannedCardStorageHelper
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

private enum class LoyaltySortOption(val labelRes: Int) {
    RECENTLY_ADDED(R.string.loyalty_sort_added),
    RECENTLY_UPDATED(R.string.loyalty_sort_updated),
    NAME_AZ(R.string.loyalty_sort_az)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun createTempCaptureUri(context: Context, prefix: String): Uri {
    val dir = File(context.cacheDir, "loyalty_capture").apply { if (!exists()) mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardWalletScreen(
    loyaltyCards: List<LoyaltyCardEntity>,
    onAddCard: () -> Unit,
    onOpenCard: (Long) -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf(LoyaltySortOption.RECENTLY_ADDED) }

    val displayedCards = remember(loyaltyCards, searchQuery, sortOption) {
        val q = searchQuery.trim()
        val filtered = if (q.isBlank()) {
            loyaltyCards
        } else {
            loyaltyCards.filter { c ->
                c.brandName.contains(q, true) ||
                    c.cardNickname.contains(q, true) ||
                    c.cardNumber.contains(q, true) ||
                    c.cardholderName.contains(q, true)
            }
        }
        when (sortOption) {
            LoyaltySortOption.RECENTLY_ADDED -> filtered.sortedByDescending { it.createdAtTimestamp }
            LoyaltySortOption.RECENTLY_UPDATED -> filtered.sortedByDescending { it.updatedAtTimestamp }
            LoyaltySortOption.NAME_AZ -> filtered.sortedBy { it.brandName.lowercase() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.loyalty_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.loyalty_wallet_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddCard,
                containerColor = GoldAccent,
                contentColor = NavyPrimary,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.loyalty_add_card))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (loyaltyCards.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = GoldAccent.copy(alpha = 0.16f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.CardMembership, null, tint = GoldAccent, modifier = Modifier.size(34.dp))
                                }
                            }
                            Text(
                                text = stringResource(R.string.loyalty_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.loyalty_empty_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onAddCard,
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.loyalty_add_card), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.loyalty_search_hint)) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, null)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Compact Sort Bar (all 3 options visible in one row)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LoyaltySortOption.values().forEach { opt ->
                        val selected = sortOption == opt
                        Surface(
                            onClick = { sortOption = opt },
                            shape = RoundedCornerShape(10.dp),
                            color = if (selected) GoldAccent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                            modifier = Modifier.weight(1f).heightIn(min = 36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
                                Text(
                                    text = stringResource(opt.labelRes),
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) NavyPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                if (displayedCards.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            stringResource(R.string.loyalty_no_matches),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 154.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 84.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedCards, key = { it.id }) { card ->
                            LoyaltyCardGridTile(card = card, onClick = { onOpenCard(card.id) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LoyaltyCardGridTile(
    card: LoyaltyCardEntity,
    onClick: () -> Unit
) {
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Top thumbnail (Front photo or sleek navy/gold monogram)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .background(NavyPrimary),
                contentAlignment = Alignment.Center
            ) {
                if (!card.frontPhotoUri.isNullOrBlank()) {
                    AsyncImage(
                        model = Uri.parse(card.frontPhotoUri),
                        contentDescription = card.brandName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Icon(Icons.Default.CardMembership, null, tint = GoldAccent, modifier = Modifier.size(30.dp))
                        Text(
                            text = card.brandName.take(18),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Subtle Barcode / QR Indicator badge
                if (hasBarcode || hasQr) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = NavyPrimary.copy(alpha = 0.85f),
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (hasBarcode) Icon(Icons.Default.ViewWeek, null, tint = GoldAccent, modifier = Modifier.size(13.dp))
                            if (hasQr) Icon(Icons.Default.QrCode2, null, tint = GoldAccent, modifier = Modifier.size(13.dp))
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = card.brandName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (card.cardNickname.isNotBlank()) {
                    Text(
                        text = card.cardNickname,
                        style = MaterialTheme.typography.bodySmall,
                        color = GoldAccent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardEditorScreen(
    existingCard: LoyaltyCardEntity?,
    defaultCardholderName: String,
    onSave: (LoyaltyCardEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isEditing = existingCard != null

    var brandName by remember(existingCard) { mutableStateOf(existingCard?.brandName.orEmpty()) }
    var cardNickname by remember(existingCard) { mutableStateOf(existingCard?.cardNickname.orEmpty()) }
    var cardNumber by remember(existingCard) { mutableStateOf(existingCard?.cardNumber.orEmpty()) }
    var cardholderName by remember(existingCard) {
        mutableStateOf(existingCard?.cardholderName ?: defaultCardholderName)
    }
    var notes by remember(existingCard) { mutableStateOf(existingCard?.notes.orEmpty()) }

    var barcodeValue by remember(existingCard) { mutableStateOf(existingCard?.barcodeValue.orEmpty()) }
    var barcodeFormat by remember(existingCard) { mutableStateOf(existingCard?.barcodeFormat.orEmpty()) }
    var qrPayload by remember(existingCard) { mutableStateOf(existingCard?.qrPayload.orEmpty()) }

    var frontPhotoUri by remember(existingCard) { mutableStateOf(existingCard?.frontPhotoUri) }
    var backPhotoUri by remember(existingCard) { mutableStateOf(existingCard?.backPhotoUri) }

    var showManualCodeFields by remember { mutableStateOf(false) }
    var activeScannerMode by remember { mutableStateOf<String?>(null) } // "BARCODE" or "QR"
    var pendingCopyPrompt by remember { mutableStateOf<String?>(null) }

    // Camera photo capture state for Front & Back
    var pendingCaptureSide by remember { mutableStateOf<String?>(null) }
    var pendingCaptureUri by remember { mutableStateOf<Uri?>(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCaptureUri
        val side = pendingCaptureSide
        if (success && uri != null && side != null) {
            val saved = ScannedCardStorageHelper.saveLoyaltyPhotoFromUri(context, uri, side)
            if (saved != null) {
                if (side == "front") frontPhotoUri = saved else backPhotoUri = saved
            } else {
                Toast.makeText(context, "Could not save captured photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val camPermForPhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val side = pendingCaptureSide
        if (granted && side != null) {
            val uri = createTempCaptureUri(context, side)
            pendingCaptureUri = uri
            takePictureLauncher.launch(uri)
        } else {
            Toast.makeText(context, "Camera permission denied — you can pick from Gallery instead.", Toast.LENGTH_LONG).show()
        }
    }

    fun launchCameraForSide(side: String) {
        pendingCaptureSide = side
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            val uri = createTempCaptureUri(context, side)
            pendingCaptureUri = uri
            takePictureLauncher.launch(uri)
        } else {
            camPermForPhotoLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var galleryPickSide by remember { mutableStateOf("front") }
    val galleryPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            val saved = ScannedCardStorageHelper.saveLoyaltyPhotoFromUri(context, uri, galleryPickSide)
            if (saved != null) {
                if (galleryPickSide == "front") frontPhotoUri = saved else backPhotoUri = saved
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) stringResource(R.string.loyalty_edit_card) else stringResource(R.string.loyalty_add_card),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Card Information
            Text(stringResource(R.string.loyalty_section_info), fontWeight = FontWeight.Bold, color = GoldAccent)

            OutlinedTextField(
                value = brandName,
                onValueChange = { brandName = it },
                label = { Text(stringResource(R.string.loyalty_brand_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNickname,
                onValueChange = { cardNickname = it },
                label = { Text(stringResource(R.string.loyalty_nickname_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text(stringResource(R.string.loyalty_card_number_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardholderName,
                onValueChange = { cardholderName = it },
                label = { Text(stringResource(R.string.loyalty_cardholder_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 2. Card Code (Barcode + QR Code + Manual)
            HorizontalDivider()
            Text(stringResource(R.string.loyalty_section_code), fontWeight = FontWeight.Bold, color = GoldAccent)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { activeScannerMode = "BARCODE" },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ViewWeek, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.loyalty_scan_barcode), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Button(
                    onClick = { activeScannerMode = "QR" },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.loyalty_scan_qr), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            OutlinedButton(
                onClick = { showManualCodeFields = !showManualCodeFields },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Keyboard, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.loyalty_enter_manually))
            }

            if (barcodeValue.isNotBlank() || qrPayload.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (barcodeValue.isNotBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${stringResource(R.string.loyalty_barcode_label)} (${LoyaltyCodeHelper.formatDisplayName(barcodeFormat.ifBlank { "CODE_128" })})",
                                        fontWeight = FontWeight.Bold,
                                        color = GoldAccent,
                                        fontSize = 12.sp
                                    )
                                    Text(barcodeValue, style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton(onClick = { barcodeValue = ""; barcodeFormat = "" }) {
                                    Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        if (qrPayload.isNotBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        stringResource(R.string.loyalty_qr_label),
                                        fontWeight = FontWeight.Bold,
                                        color = GoldAccent,
                                        fontSize = 12.sp
                                    )
                                    Text(qrPayload, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { qrPayload = "" }) {
                                    Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            if (showManualCodeFields) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = barcodeValue,
                            onValueChange = { barcodeValue = it },
                            label = { Text(stringResource(R.string.loyalty_barcode_value_label)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(stringResource(R.string.loyalty_barcode_format_label), style = MaterialTheme.typography.labelSmall)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LoyaltyCodeHelper.SUPPORTED_1D_FORMATS.forEach { fmt ->
                                FilterChip(
                                    selected = barcodeFormat == fmt,
                                    onClick = { barcodeFormat = fmt },
                                    label = { Text(LoyaltyCodeHelper.formatDisplayName(fmt), fontSize = 11.sp) }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = qrPayload,
                            onValueChange = { qrPayload = it },
                            label = { Text(stringResource(R.string.loyalty_qr_payload_label)) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            }

            // 3. Front & Back Card Photos
            HorizontalDivider()
            Text(stringResource(R.string.loyalty_section_photos), fontWeight = FontWeight.Bold, color = GoldAccent)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LoyaltyPhotoPickerSlot(
                    label = stringResource(R.string.loyalty_front_photo),
                    photoUri = frontPhotoUri,
                    onCameraClick = { launchCameraForSide("front") },
                    onGalleryClick = {
                        galleryPickSide = "front"
                        galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onRemoveClick = { frontPhotoUri = null },
                    modifier = Modifier.weight(1f)
                )
                LoyaltyPhotoPickerSlot(
                    label = stringResource(R.string.loyalty_back_photo),
                    photoUri = backPhotoUri,
                    onCameraClick = { launchCameraForSide("back") },
                    onGalleryClick = {
                        galleryPickSide = "back"
                        galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onRemoveClick = { backPhotoUri = null },
                    modifier = Modifier.weight(1f)
                )
            }

            // 4. Notes
            HorizontalDivider()
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(stringResource(R.string.loyalty_notes_label)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Button(
                onClick = {
                    val trimmedBrand = brandName.trim()
                    if (trimmedBrand.isBlank()) {
                        Toast.makeText(context, context.getString(R.string.loyalty_brand_required), Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val trimmedBarcodeVal = barcodeValue.trim()
                    val finalBarcodeFmt = if (trimmedBarcodeVal.isNotBlank()) {
                        barcodeFormat.ifBlank { "CODE_128" }
                    } else ""

                    val entity = (existingCard ?: LoyaltyCardEntity(brandName = trimmedBrand)).copy(
                        brandName = trimmedBrand,
                        cardNickname = cardNickname.trim(),
                        cardNumber = cardNumber.trim(),
                        cardholderName = cardholderName.trim(),
                        notes = notes.trim(),
                        barcodeValue = trimmedBarcodeVal,
                        barcodeFormat = finalBarcodeFmt,
                        qrPayload = qrPayload.trim(),
                        frontPhotoUri = frontPhotoUri,
                        backPhotoUri = backPhotoUri
                    )
                    onSave(entity)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_save), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Live CameraX + ML Kit Barcode / QR Scanner Dialog (Reuses existing ML Kit & CameraX stack)
    if (activeScannerMode != null) {
        val mode = activeScannerMode!!
        LoyaltyCodeScannerDialog(
            mode = mode,
            onDetected = { rawValue, formatName ->
                if (mode == "QR") {
                    qrPayload = rawValue
                    Toast.makeText(context, "QR Code captured!", Toast.LENGTH_SHORT).show()
                } else {
                    barcodeValue = rawValue
                    barcodeFormat = formatName
                    Toast.makeText(context, "Barcode captured (${LoyaltyCodeHelper.formatDisplayName(formatName)})", Toast.LENGTH_SHORT).show()
                    if (cardNumber.isBlank()) {
                        pendingCopyPrompt = rawValue
                    }
                }
                activeScannerMode = null
            },
            onDismiss = { activeScannerMode = null }
        )
    }

    // Confirm before copying scanned barcode payload into visible Card Number field
    if (pendingCopyPrompt != null) {
        val candidate = pendingCopyPrompt!!
        AlertDialog(
            onDismissRequest = { pendingCopyPrompt = null },
            title = { Text(stringResource(R.string.loyalty_copy_number_title), fontWeight = FontWeight.Bold) },
            text = { Text("${stringResource(R.string.loyalty_copy_number_msg)}\n\n$candidate") },
            confirmButton = {
                Button(onClick = {
                    cardNumber = candidate
                    pendingCopyPrompt = null
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingCopyPrompt = null }) {
                    Text(stringResource(R.string.action_skip))
                }
            }
        )
    }
}

@Composable
private fun LoyaltyPhotoPickerSlot(
    label: String,
    photoUri: String?,
    onCameraClick: () -> Unit,
    onGalleryClick: () -> Unit,
    onRemoveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier, shape = RoundedCornerShape(14.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = GoldAccent)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(NavyPrimary.copy(alpha = 0.7f))
                    .border(1.dp, GoldAccent.copy(alpha = 0.45f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!photoUri.isNullOrBlank()) {
                    AsyncImage(
                        model = Uri.parse(photoUri),
                        contentDescription = label,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Default.PhotoCamera, null, tint = GoldAccent.copy(alpha = 0.7f), modifier = Modifier.size(28.dp))
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(
                    onClick = onCameraClick,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoCamera, null, modifier = Modifier.size(15.dp))
                }
                OutlinedButton(
                    onClick = onGalleryClick,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(15.dp))
                }
                if (!photoUri.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = onRemoveClick,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.DeleteOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun LoyaltyCodeScannerDialog(
    mode: String, // "BARCODE" or "QR"
    onDetected: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scanDone = remember { AtomicBoolean(false) }

    var hasCam by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    LaunchedEffect(Unit) {
        if (!hasCam) permLauncher.launch(Manifest.permission.CAMERA)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color(0xFF060E24))) {
            if (hasCam) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                val scanner = BarcodeScanning.getClient()
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build().apply {
                                        setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                            @Suppress("UnsafeOptInUsageError")
                                            val img = proxy.image
                                            if (img != null && !scanDone.get()) {
                                                scanner.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                                                    .addOnSuccessListener { list ->
                                                        val match = list.firstOrNull { bc ->
                                                            val raw = bc.rawValue
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(bc.format)
                                                            !raw.isNullOrBlank() && fmtName != null && (
                                                                (mode == "QR" && fmtName == "QR_CODE") ||
                                                                    (mode == "BARCODE" && fmtName != "QR_CODE")
                                                                )
                                                        }
                                                        if (match != null && scanDone.compareAndSet(false, true)) {
                                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                            val rawVal = match.rawValue!!
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(match.format) ?: "CODE_128"
                                                            onDetected(rawVal, fmtName)
                                                        }
                                                    }
                                                    .addOnCompleteListener { proxy.close() }
                                            } else {
                                                proxy.close()
                                            }
                                        }
                                    }
                                provider.unbindAll()
                                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                // Viewfinder guide
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.84f)
                        .height(if (mode == "QR") 250.dp else 150.dp)
                        .border(2.5.dp, GoldAccent, RoundedCornerShape(18.dp))
                )
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text(stringResource(R.string.qr_grant_cam))
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White)
                }
                Surface(shape = RoundedCornerShape(16.dp), color = NavyPrimary.copy(alpha = 0.85f)) {
                    Text(
                        text = if (mode == "QR") stringResource(R.string.loyalty_scan_qr) else stringResource(R.string.loyalty_scan_barcode),
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
                Spacer(Modifier.size(44.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardDetailScreen(
    card: LoyaltyCardEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()

    var activeCodeTab by remember(card.id, hasBarcode, hasQr) {
        mutableStateOf(if (hasBarcode) "BARCODE" else if (hasQr) "QR" else "NONE")
    }
    var showEnlargedCode by remember { mutableStateOf(false) }
    var enlargedPhotoUri by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val barcodeBitmap = remember(card.barcodeValue, card.barcodeFormat) {
        if (hasBarcode) LoyaltyCodeHelper.generateBarcodeBitmap(card.barcodeValue, card.barcodeFormat, 960, 320) else null
    }
    val qrBitmap = remember(card.qrPayload) {
        if (hasQr) LoyaltyCodeHelper.generateQrBitmap(card.qrPayload, 640) else null
    }
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(card.brandName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (card.cardNickname.isNotBlank()) {
                            Text(card.cardNickname, style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.loyalty_edit_card))
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.loyalty_delete_card), tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. DIGITAL CODE CARD (Barcode / QR with switcher if both exist + Tap to Enlarge)
            if (hasBarcode || hasQr) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.2.dp, GoldAccent.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (hasBarcode && hasQr) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = activeCodeTab == "BARCODE",
                                    onClick = { activeCodeTab = "BARCODE" },
                                    label = { Text(stringResource(R.string.loyalty_barcode_label)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = activeCodeTab == "QR",
                                    onClick = { activeCodeTab = "QR" },
                                    label = { Text(stringResource(R.string.loyalty_qr_label)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showEnlargedCode = true }
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (activeCodeTab == "BARCODE") {
                                    if (barcodeBitmap != null) {
                                        Image(
                                            bitmap = barcodeBitmap.asImageBitmap(),
                                            contentDescription = "Loyalty Barcode",
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier.fillMaxWidth().height(110.dp)
                                        )
                                        Text(
                                            text = card.barcodeValue,
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            letterSpacing = 1.2.sp
                                        )
                                        Text(
                                            text = LoyaltyCodeHelper.formatDisplayName(card.barcodeFormat),
                                            color = Color.DarkGray,
                                            fontSize = 11.sp
                                        )
                                    } else {
                                        Text(
                                            stringResource(R.string.loyalty_code_render_fallback),
                                            color = Color.Black,
                                            style = MaterialTheme.typography.bodySmall,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                } else if (activeCodeTab == "QR") {
                                    if (qrBitmap != null) {
                                        Image(
                                            bitmap = qrBitmap.asImageBitmap(),
                                            contentDescription = "Loyalty QR Code",
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier.size(200.dp)
                                        )
                                    } else {
                                        Text(
                                            stringResource(R.string.loyalty_code_render_fallback),
                                            color = Color.Black,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }

                        if (card.cardNumber.isNotBlank()) {
                            Text(
                                text = "${stringResource(R.string.loyalty_card_number_short)}: ${card.cardNumber}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = GoldAccent
                            )
                        }

                        TextButton(onClick = { showEnlargedCode = true }) {
                            Icon(Icons.Default.ZoomOutMap, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.loyalty_tap_to_enlarge), color = GoldAccent, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else if (card.cardNumber.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.loyalty_card_number_short), style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                        Text(card.cardNumber, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }

            // 2. PHYSICAL CARD IMAGES (Front | Back)
            if (!card.frontPhotoUri.isNullOrBlank() || !card.backPhotoUri.isNullOrBlank()) {
                Text(stringResource(R.string.loyalty_section_photos), fontWeight = FontWeight.Bold, color = GoldAccent)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!card.frontPhotoUri.isNullOrBlank()) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(stringResource(R.string.detail_front_side), style = MaterialTheme.typography.labelSmall)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1.586f)
                                    .border(1.2.dp, GoldAccent, RoundedCornerShape(12.dp))
                                    .clickable { enlargedPhotoUri = card.frontPhotoUri },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                AsyncImage(
                                    model = Uri.parse(card.frontPhotoUri),
                                    contentDescription = "Front",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                    if (!card.backPhotoUri.isNullOrBlank()) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(stringResource(R.string.detail_back_side), style = MaterialTheme.typography.labelSmall)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1.586f)
                                    .border(1.2.dp, GoldAccent, RoundedCornerShape(12.dp))
                                    .clickable { enlargedPhotoUri = card.backPhotoUri },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                AsyncImage(
                                    model = Uri.parse(card.backPhotoUri),
                                    contentDescription = "Back",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            // 3. CARD METADATA & NOTES
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (card.cardholderName.isNotBlank()) {
                        Text(stringResource(R.string.loyalty_cardholder_label), style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                        Text(card.cardholderName, fontWeight = FontWeight.SemiBold)
                    }
                    if (card.notes.isNotBlank()) {
                        Text(stringResource(R.string.loyalty_notes_label), style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                        Text(card.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Text(
                        "${stringResource(R.string.loyalty_date_added)}: ${dateFmt.format(Date(card.createdAtTimestamp))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                    Text(
                        "${stringResource(R.string.loyalty_date_updated)}: ${dateFmt.format(Date(card.updatedAtTimestamp))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }
            }
        }
    }

    // Full-Screen Enlarged Barcode / QR Dialog (Keeps screen awake while scanning at checkout!)
    if (showEnlargedCode) {
        DisposableEffect(Unit) {
            val window = context.findActivity()?.window
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            onDispose {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        Dialog(
            onDismissRequest = { showEnlargedCode = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
                    .clickable { showEnlargedCode = false }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(card.brandName, color = NavyPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (activeCodeTab == "BARCODE" && barcodeBitmap != null) {
                        Image(
                            bitmap = barcodeBitmap.asImageBitmap(),
                            contentDescription = "Enlarged Barcode",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth().height(180.dp)
                        )
                        Text(card.barcodeValue, color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    } else if (activeCodeTab == "QR" && qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Enlarged QR Code",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(300.dp)
                        )
                    }
                    if (card.cardNumber.isNotBlank()) {
                        Text(card.cardNumber, color = Color.DarkGray, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedButton(onClick = { showEnlargedCode = false }) {
                        Text(stringResource(R.string.action_close), color = NavyPrimary)
                    }
                }
            }
        }
    }

    // Full-Screen Photo Viewer Dialog
    if (enlargedPhotoUri != null) {
        Dialog(
            onDismissRequest = { enlargedPhotoUri = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.94f))
                    .clickable { enlargedPhotoUri = null }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = Uri.parse(enlargedPhotoUri),
                    contentDescription = "Full Card Image",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.loyalty_delete_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.loyalty_delete_confirm_msg)) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}
