package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

@Serializable
data class CardLinkBackupPayload(
    val schemaVersion: Int = 2,
    val exportedAtTimestamp: Long = System.currentTimeMillis(),
    val myCards: List<BackedUpMyCard>,
    val savedContacts: List<BackedUpContact>
)

@Serializable
data class BackedUpMyCard(
    val card: BusinessCardEntity,
    val profilePhotoBase64: String? = null,
    val companyLogoBase64: String? = null
)

@Serializable
data class BackedUpContact(
    val contact: SavedContactEntity,
    val cardPhotoBase64: String? = null
)

data class RestoreSummary(val profilesRestored: Int, val contactsRestored: Int)

object CardLinkBackupManager {

    private val jsonFormat = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun exportFullBackupToUri(
        context: Context,
        destinationUri: Uri,
        myCards: List<BusinessCardEntity>,
        contacts: List<SavedContactEntity>
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val backedUpCards = myCards.map { card ->
                BackedUpMyCard(
                    card = card,
                    profilePhotoBase64 = encodeLocalUriToBase64(context, card.profilePhotoUri),
                    companyLogoBase64 = encodeLocalUriToBase64(context, card.companyLogoUri)
                )
            }
            val backedUpContacts = contacts.map { contact ->
                BackedUpContact(
                    contact = contact,
                    cardPhotoBase64 = encodeLocalUriToBase64(context, contact.profilePhotoUri)
                )
            }
            val payload = CardLinkBackupPayload(myCards = backedUpCards, savedContacts = backedUpContacts)
            val jsonString = jsonFormat.encodeToString(payload)
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                out.write(jsonString.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: error("Could not open backup output stream.")
            backedUpCards.size + backedUpContacts.size
        }
    }

    suspend fun importFullBackupFromUri(
        context: Context,
        sourceUri: Uri
    ): Result<Pair<List<BusinessCardEntity>, List<SavedContactEntity>>> = withContext(Dispatchers.IO) {
        runCatching {
            val jsonString = context.contentResolver.openInputStream(sourceUri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
            } ?: error("Unable to read backup file.")

            val payload = jsonFormat.decodeFromString<CardLinkBackupPayload>(jsonString)
            val restoredMyCards = payload.myCards.map { item ->
                val photoUri = decodeBase64ToLocalFile(context, item.profilePhotoBase64, "profile_assets", "prof_")
                    ?: item.card.profilePhotoUri
                val logoUri = decodeBase64ToLocalFile(context, item.companyLogoBase64, "profile_assets", "logo_")
                    ?: item.card.companyLogoUri
                item.card.copy(id = 0, profilePhotoUri = photoUri, companyLogoUri = logoUri)
            }
            val restoredContacts = payload.savedContacts.map { item ->
                val cardUri = decodeBase64ToLocalFile(context, item.cardPhotoBase64, "scanned_cards", "card_")
                    ?: item.contact.profilePhotoUri
                item.contact.copy(id = 0, profilePhotoUri = cardUri)
            }
            Pair(restoredMyCards, restoredContacts)
        }
    }

    suspend fun exportContactsToBatchVcf(
        context: Context,
        destinationUri: Uri,
        contacts: List<SavedContactEntity>
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val combinedVcf = buildString {
                contacts.forEach { c ->
                    appendLine("BEGIN:VCARD")
                    appendLine("VERSION:3.0")
                    appendLine("FN:${c.fullName}")
                    appendLine("N:${c.fullName};;;;")
                    if (c.companyName.isNotBlank() || c.department.isNotBlank()) appendLine("ORG:${c.companyName};${c.department}")
                    if (c.designation.isNotBlank()) appendLine("TITLE:${c.designation}")
                    if (c.phone.isNotBlank()) appendLine("TEL;TYPE=WORK,VOICE:${c.phone}")
                    if (c.whatsapp.isNotBlank()) appendLine("TEL;TYPE=CELL,WHATSAPP:${c.whatsapp}")
                    if (c.email.isNotBlank()) appendLine("EMAIL;TYPE=PREF,INTERNET:${c.email}")
                    if (c.officeAddress.isNotBlank()) appendLine("ADR;TYPE=WORK:;;${c.officeAddress};;;;")
                    if (c.website.isNotBlank()) appendLine("URL:${c.website}")
                    appendLine("END:VCARD")
                }
            }
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                out.write(combinedVcf.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: error("Could not open .vcf output stream.")
            contacts.size
        }
    }

    suspend fun importContactsFromBatchVcf(
        context: Context,
        sourceUri: Uri
    ): Result<List<SavedContactEntity>> = withContext(Dispatchers.IO) {
        runCatching {
            val rawVcf = context.contentResolver.openInputStream(sourceUri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
            } ?: error("Unable to read .vcf file.")

            val blocks = Regex("BEGIN:VCARD.*?END:VCARD", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
                .findAll(rawVcf).map { it.value }.toList()
            if (blocks.isEmpty()) error("No valid VCARD entries found.")
            blocks.map { CardShareHelper.parseVCardToContact(it, "vCard Import") }
        }
    }

    private fun encodeLocalUriToBase64(context: Context, uriString: String?): String? {
        if (uriString.isNullOrBlank()) return null
        return runCatching {
            val uri = Uri.parse(uriString)
            val bytes = when (uri.scheme) {
                "file" -> File(uri.path ?: return null).takeIf { it.exists() }?.readBytes()
                "content" -> context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                else -> null
            } ?: return null
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        }.getOrNull()
    }

    private fun decodeBase64ToLocalFile(context: Context, base64: String?, subFolder: String, prefix: String): String? {
        if (base64.isNullOrBlank()) return null
        return runCatching {
            val bytes = Base64.decode(base64, Base64.NO_WRAP)
            val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
            val file = File(dir, "$prefix${System.currentTimeMillis()}_${(100..999).random()}.jpg")
            file.writeBytes(bytes)
            Uri.fromFile(file).toString()
        }.getOrNull()
    }
}
