package com.cardlink.app.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.ContactActionLauncher

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contact: SavedContactEntity,
    mySenderName: String,
    onSaveNotes: (String) -> Unit,
    onDeleteContact: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var notes by remember(contact) { mutableStateOf(contact.notes) }
    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val whatsAppTarget = contact.whatsapp.ifBlank { contact.phone }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { CardShareHelper.exportToAndroidContacts(context, contact) }) {
                        Icon(Icons.Default.PersonAdd, null)
                    }
                    IconButton(onClick = onDeleteContact) {
                        Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!contact.profilePhotoUri.isNullOrBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, GoldAccent, RoundedCornerShape(14.dp)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    AsyncImage(model = Uri.parse(contact.profilePhotoUri), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }

            Text("${contact.designation} • ${contact.companyName}", color = GoldAccent, fontWeight = FontWeight.SemiBold)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ContactActionLauncher.launchDialer(context, primaryPhone) }, modifier = Modifier.weight(1f)) { Text("Call") }
                Button(onClick = { ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName) }, modifier = Modifier.weight(1f)) { Text("WA") }
                Button(onClick = { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) }, modifier = Modifier.weight(1f)) { Text("Email") }
                Button(onClick = { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName) }, modifier = Modifier.weight(1f)) { Text("Map") }
            }

            if (contact.phone.isNotBlank()) ListItem(headlineContent = { Text(contact.phone) }, overlineContent = { Text("Phone") }, modifier = Modifier.clickable { ContactActionLauncher.launchDialer(context, contact.phone) })
            if (contact.whatsapp.isNotBlank()) ListItem(headlineContent = { Text(contact.whatsapp) }, overlineContent = { Text("WhatsApp") }, modifier = Modifier.clickable { ContactActionLauncher.launchWhatsAppChat(context, contact.whatsapp, contact.fullName) })
            if (contact.email.isNotBlank()) ListItem(headlineContent = { Text(contact.email) }, overlineContent = { Text("Email") }, modifier = Modifier.clickable { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) })
            if (contact.officeAddress.isNotBlank()) ListItem(headlineContent = { Text(contact.officeAddress) }, overlineContent = { Text("Address") }, modifier = Modifier.clickable { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName) })
            if (contact.website.isNotBlank()) ListItem(headlineContent = { Text(contact.website) }, overlineContent = { Text("Website / Link") }, modifier = Modifier.clickable { ContactActionLauncher.launchExternalUrl(context, contact.website) })

            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Private Contact Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 3)

            Button(
                onClick = {
                    onSaveNotes(notes)
                    Toast.makeText(context, "Notes saved!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save Notes") }
        }
    }
}
