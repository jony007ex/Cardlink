package com.cardlink.app.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.theme.GoldAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreSection(viewModel: CardLinkViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var replaceOnRestore by remember { mutableStateOf(false) }
    val dateStamp = remember { SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) }

    val exportJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportFullJsonBackup(uri) { res ->
                res.onSuccess { Toast.makeText(context, "Exported $it items!", Toast.LENGTH_LONG).show() }
            }
        }
    }

    val importJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            viewModel.importFullJsonBackup(uri, replaceOnRestore) { res ->
                res.onSuccess { Toast.makeText(context, "Restored ${it.profilesRestored} cards & ${it.contactsRestored} contacts!", Toast.LENGTH_LONG).show() }
            }
        }
    }

    val exportVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportBatchVcf(uri) { res ->
                res.onSuccess { Toast.makeText(context, "Exported $it contacts to .vcf!", Toast.LENGTH_LONG).show() }
            }
        }
    }

    val importVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            viewModel.importBatchVcf(uri) { res ->
                res.onSuccess { Toast.makeText(context, "Imported $it contacts from .vcf!", Toast.LENGTH_LONG).show() }
            }
        }
    }

    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Backup, null, tint = GoldAccent)
                Text("Backup & Restore (JSON + .vcf)", fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportJsonLauncher.launch("CardLink_Backup_$dateStamp.json") }, modifier = Modifier.weight(1f)) { Text("Backup JSON") }
                OutlinedButton(onClick = { importJsonLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Restore JSON") }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Overwrite on Restore", style = MaterialTheme.typography.bodySmall)
                Switch(checked = replaceOnRestore, onCheckedChange = { replaceOnRestore = it })
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportVcfLauncher.launch("CardLink_Contacts_$dateStamp.vcf") }, modifier = Modifier.weight(1f)) { Text("Export .vcf") }
                OutlinedButton(onClick = { importVcfLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Import .vcf") }
            }
        }
    }
}
