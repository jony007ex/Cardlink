package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Dedicated Temporary Secure Export Vault inside private cacheDir/secure_temp_exports/.
 * - Never writes temporary shares into public Downloads, Pictures, or DCIM.
 * - Automatically expires temporary exports after 10 minutes via startup cleanup + WorkManager.
 * - Logs only safe aggregate counts (never sensitive document names).
 */
object TempSecureExportVault {
    private const val DIR_NAME = "secure_temp_exports"
    private const val TEMP_EXPORT_MAX_AGE_MS = 10L * 60_000L // 10 minutes
    private const val CLEANUP_WORK_NAME = "cardlink_temp_export_cleanup"

    fun getVaultDir(context: Context): File =
        File(context.cacheDir, DIR_NAME).apply { if (!exists()) mkdirs() }

    /**
     * Creates a private temporary file with an opaque non-sensitive filename so no personal
     * details leak into the cache filename, and schedules automatic cleanup.
     */
    fun createTempExportFile(context: Context, extension: String): File {
        val dir = getVaultDir(context)
        val cleanExt = extension.trimStart('.').lowercase().ifBlank { "bin" }
        val file = File(dir, "cl_exp_${System.currentTimeMillis()}_${(1000..9999).random()}.$cleanExt")
        scheduleDelayedCleanup(context)
        return file
    }

    fun createNamedTempExportFile(context: Context, safeBaseName: String, extension: String): File {
        val dir = getVaultDir(context)
        val cleanExt = extension.trimStart('.').lowercase().ifBlank { "vcf" }
        val cleanBase = safeBaseName.replace(Regex("[^a-zA-Z0-9_\-]"), "_").trim('_').ifBlank { "CardLink_Contact" }
        val file = File(dir, "$cleanBase.$cleanExt")
        scheduleDelayedCleanup(context)
        return file
    }

    fun toShareUri(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    fun scheduleDelayedCleanup(context: Context) {
        runCatching {
            val req = OneTimeWorkRequestBuilder<TempExportCleanupWorker>()
                .setInitialDelay(10L, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                CLEANUP_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                req
            )
        }
    }

    /**
     * Scans ONLY CardLink's designated temporary secure-export directory and deletes expired files.
     * Never touches user storage or permanent encrypted .clenc vault files.
     */
    fun cleanupExpiredExportsSync(context: Context, forceAll: Boolean = false): Int {
        val dir = File(context.cacheDir, DIR_NAME)
        if (!dir.exists() || !dir.isDirectory) return 0
        val now = System.currentTimeMillis()
        var removed = 0
        dir.listFiles()?.forEach { f ->
            if (f.isFile && (forceAll || (now - f.lastModified() >= TEMP_EXPORT_MAX_AGE_MS))) {
                if (runCatching { f.delete() }.getOrDefault(false)) {
                    removed++
                }
            }
        }
        if (removed > 0) {
            SecurityHardeningManager.logAuditEventAsync(
                context,
                "TEMP_EXPORTS_CLEANED",
                "Security",
                true,
                "$removed expired temporary export(s) removed"
            )
        }
        return removed
    }

    fun cleanupExpiredExportsAsync(context: Context) {
        val appCtx = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { cleanupExpiredExportsSync(appCtx, forceAll = false) }
        }
    }
}

class TempExportCleanupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        TempSecureExportVault.cleanupExpiredExportsSync(applicationContext, forceAll = false)
        return Result.success()
    }
}
