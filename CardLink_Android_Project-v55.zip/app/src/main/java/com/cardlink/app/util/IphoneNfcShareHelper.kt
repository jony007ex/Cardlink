package com.cardlink.app.util

import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import com.cardlink.app.data.model.BusinessCardEntity
import java.net.URI
import java.nio.charset.StandardCharsets

enum class IphoneNfcActionType(val id: String) {
    PROFILE_LINK("PROFILE_LINK"),
    PHONE_CALL("PHONE_CALL"),
    EMAIL("EMAIL"),
    SMS("SMS"),
    WHATSAPP("WHATSAPP"),
    APPLE_MAPS("APPLE_MAPS")
}

data class IphoneNfcPayloadSpec(
    val actionType: IphoneNfcActionType,
    val uriString: String,
    val isAvailable: Boolean,
    val requiresInternetOnIphone: Boolean
)

data class IphoneUrlValidationResult(
    val isValid: Boolean,
    val isHttps: Boolean,
    val errorMessage: String = ""
)

data class PrivacyPreviewItem(
    val fieldId: String,
    val label: String,
    val isShared: Boolean,
    val hasValue: Boolean
)

object IphoneNfcShareHelper {

    /**
     * Pure-JVM local URL validator for Digital Card links (never makes background network calls).
     * Validates non-empty, https/http scheme, valid host structure, no whitespace, and NDEF length cap.
     */
    fun validateDigitalCardUrlLocally(rawUrl: String): IphoneUrlValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) {
            return IphoneUrlValidationResult(false, false, "Enter a Digital Card URL starting with https://")
        }
        if (trimmed.any { it.isWhitespace() }) {
            return IphoneUrlValidationResult(false, false, "URL cannot contain spaces.")
        }
        val lower = trimmed.lowercase()
        val isHttps = lower.startsWith("https://")
        val isHttp = lower.startsWith("http://")
        if (!isHttps && !isHttp) {
            return IphoneUrlValidationResult(false, false, "URL must start with https:// or http://")
        }
        val parsed = runCatching { URI(trimmed) }.getOrNull()
            ?: return IphoneUrlValidationResult(false, false, "URL format is not valid.")
        val host = parsed.host.orEmpty()
        if (host.isBlank() || !host.contains(".")) {
            return IphoneUrlValidationResult(false, false, "URL must include a valid domain name.")
        }
        if (trimmed.toByteArray(StandardCharsets.UTF_8).size > 1024) {
            return IphoneUrlValidationResult(false, isHttps, "URL is too long for standard NFC tags.")
        }
        return IphoneUrlValidationResult(true, isHttps)
    }

    /**
     * Shortens a long HTTPS URL into a readable compact preview (e.g. "1drv.ms/...36568")
     * without modifying the stored canonical URL.
     */
    fun shortenUrlForDisplay(rawUrl: String, maxLen: Int = 28): String {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) return ""
        val withoutScheme = trimmed
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("www.")
        if (withoutScheme.length <= maxLen) return withoutScheme
        val slashIdx = withoutScheme.indexOf('/')
        if (slashIdx in 1 until (maxLen - 8)) {
            val host = withoutScheme.substring(0, slashIdx)
            val tail = withoutScheme.takeLast(6)
            return "$host/...$tail"
        }
        return withoutScheme.take(maxLen - 9) + "..." + withoutScheme.takeLast(6)
    }

    /**
     * Builds an iOS Background Tag Reading compliant NDEF Well-Known URI for the projected
     * BusinessCardEntity (already filtered through SharingProfileManager).
     */
    fun buildUriForAction(card: BusinessCardEntity, actionType: IphoneNfcActionType): IphoneNfcPayloadSpec {
        return when (actionType) {
            IphoneNfcActionType.PROFILE_LINK -> {
                val url = card.resolveNfcShareUrl().trim().ifBlank { "https://cardlink.app" }
                val check = validateDigitalCardUrlLocally(url)
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = url,
                    isAvailable = check.isValid,
                    requiresInternetOnIphone = true
                )
            }
            IphoneNfcActionType.PHONE_CALL -> {
                val rawPhone = if (card.sharePhone) card.phone.trim() else ""
                val clean = rawPhone.filter { it.isDigit() || it == '+' }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (clean.isNotBlank()) "tel:$clean" else "",
                    isAvailable = clean.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.EMAIL -> {
                val email = if (card.shareEmail) card.email.trim() else ""
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (email.isNotBlank()) "mailto:$email" else "",
                    isAvailable = email.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.SMS -> {
                val rawPhone = if (card.sharePhone) card.phone.trim() else ""
                val clean = rawPhone.filter { it.isDigit() || it == '+' }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (clean.isNotBlank()) "sms:$clean" else "",
                    isAvailable = clean.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.WHATSAPP -> {
                val rawWa = when {
                    card.shareWhatsapp && card.whatsapp.isNotBlank() -> card.whatsapp
                    card.sharePhone && card.phone.isNotBlank() -> card.phone
                    else -> ""
                }
                val digits = rawWa.filter { it.isDigit() }
                val e164 = if (digits.startsWith("0") && digits.length == 11) "880" + digits.drop(1) else digits
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (e164.length >= 7) "https://wa.me/$e164" else "",
                    isAvailable = e164.length >= 7,
                    requiresInternetOnIphone = true
                )
            }
            IphoneNfcActionType.APPLE_MAPS -> {
                val lat = card.latitude
                val lng = card.longitude
                val addr = if (card.shareAddress) card.officeAddress.trim() else ""
                val mapUri = when {
                    card.shareAddress && lat != null && lng != null ->
                        "https://maps.apple.com/?q=${Uri.encode(card.companyName.ifBlank { card.fullName })}&ll=$lat,$lng"
                    addr.isNotBlank() ->
                        "https://maps.apple.com/?q=${Uri.encode(addr)}"
                    else -> ""
                }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = mapUri,
                    isAvailable = mapUri.isNotBlank(),
                    requiresInternetOnIphone = true
                )
            }
        }
    }

    /**
     * Standards-first cross-platform NDEF message builder:
     * Record 1: Standard Well-Known URI (HTTPS / tel: / mailto:) for iPhone & Android.
     * Record 2 (Optional): Standard text/x-vcard MIME record for Android Contact Compatibility.
     */
    fun buildStandardsFirstNdefMessage(
        primaryUri: String,
        vcardPayload: String,
        includeAndroidCompatVcard: Boolean
    ): Result<NdefMessage> = runCatching {
        val cleanUri = primaryUri.trim()
        require(cleanUri.isNotBlank()) { "No valid URI available for NFC writing." }
        val r1 = NdefRecord.createUri(cleanUri)
        val records = if (includeAndroidCompatVcard && vcardPayload.isNotBlank()) {
            val r2 = NdefRecord.createMime("text/x-vcard", vcardPayload.trim().toByteArray(StandardCharsets.UTF_8))
            arrayOf(r1, r2)
        } else {
            arrayOf(r1)
        }
        NdefMessage(records)
    }

    /**
     * Builds the exact Privacy Preview checklist from the active Sharing Profile projection.
     */
    fun buildPrivacyPreviewItems(projectedCard: BusinessCardEntity): List<PrivacyPreviewItem> = listOf(
        PrivacyPreviewItem("NAME", "Name", isShared = projectedCard.fullName.isNotBlank(), hasValue = projectedCard.fullName.isNotBlank()),
        PrivacyPreviewItem("DESIGNATION", "Designation", isShared = projectedCard.designation.isNotBlank(), hasValue = projectedCard.designation.isNotBlank()),
        PrivacyPreviewItem("COMPANY", "Company", isShared = projectedCard.companyName.isNotBlank(), hasValue = projectedCard.companyName.isNotBlank()),
        PrivacyPreviewItem("PHONE", "Work Phone", isShared = projectedCard.sharePhone && projectedCard.phone.isNotBlank(), hasValue = projectedCard.phone.isNotBlank()),
        PrivacyPreviewItem("EMAIL", "Work Email", isShared = projectedCard.shareEmail && projectedCard.email.isNotBlank(), hasValue = projectedCard.email.isNotBlank()),
        PrivacyPreviewItem("WHATSAPP", "WhatsApp", isShared = projectedCard.shareWhatsapp && projectedCard.whatsapp.isNotBlank(), hasValue = projectedCard.whatsapp.isNotBlank()),
        PrivacyPreviewItem("ADDRESS", "Office Address", isShared = projectedCard.shareAddress && projectedCard.officeAddress.isNotBlank(), hasValue = projectedCard.officeAddress.isNotBlank()),
        PrivacyPreviewItem(
            "SOCIALS",
            "Social Links",
            isShared = projectedCard.shareSocials && (projectedCard.linkedInUrl.isNotBlank() || projectedCard.facebookUrl.isNotBlank() || projectedCard.website.isNotBlank()),
            hasValue = projectedCard.linkedInUrl.isNotBlank() || projectedCard.facebookUrl.isNotBlank() || projectedCard.website.isNotBlank()
        )
    )

    fun buildProfileSummaryLine(projectedCard: BusinessCardEntity): String =
        buildPrivacyPreviewItems(projectedCard)
            .filter { it.isShared }
            .take(4)
            .joinToString(" • ") { it.label }
            .ifBlank { "Name" }
}
