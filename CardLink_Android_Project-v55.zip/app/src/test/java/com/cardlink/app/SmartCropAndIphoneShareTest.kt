package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.*
import org.junit.Assert.*
import org.junit.Test

class SmartCropAndIphoneShareTest {

    @Test
    fun smartCropQuadValidator_acceptsValidStraightAndSkewedQuads() {
        val straight = CardCropMetadata(0.08f, 0.12f, 0.92f, 0.12f, 0.92f, 0.88f, 0.08f, 0.88f)
        assertTrue(SmartCardCropEngine.isValidQuad(straight))

        val skewed = CardCropMetadata(0.14f, 0.18f, 0.84f, 0.15f, 0.88f, 0.80f, 0.10f, 0.83f)
        assertTrue(SmartCardCropEngine.isValidQuad(skewed))
    }

    @Test
    fun smartCropQuadValidator_rejectsCrossingZeroAreaAndNaNCorners() {
        // Crossing (bowtie) corners: topRight and bottomRight swapped
        val crossing = CardCropMetadata(0.10f, 0.10f, 0.90f, 0.90f, 0.90f, 0.10f, 0.10f, 0.90f)
        assertFalse(SmartCardCropEngine.isValidQuad(crossing))

        // Zero-area collapsed quad
        val zeroArea = CardCropMetadata(0.50f, 0.50f, 0.50f, 0.50f, 0.50f, 0.50f, 0.50f, 0.50f)
        assertFalse(SmartCardCropEngine.isValidQuad(zeroArea))

        // NaN coordinates must be rejected and safely sanitized
        val nanMeta = CardCropMetadata(topLeftX = Float.NaN, bottomRightY = Float.POSITIVE_INFINITY)
        assertFalse(SmartCardCropEngine.isValidQuad(nanMeta))
        val sanitized = SmartCardCropEngine.sanitizeMetadata(nanMeta)
        assertTrue(SmartCardCropEngine.isValidQuad(sanitized))
    }

    @Test
    fun frontAndBackCropState_remainCompletelyIndependent() {
        val frontMeta = CardCropMetadata(0.12f, 0.14f, 0.88f, 0.14f, 0.88f, 0.86f, 0.12f, 0.86f, rotationDegrees = 0, cropRevision = 2)
        val backMeta = CardCropMetadata(0.05f, 0.08f, 0.95f, 0.08f, 0.95f, 0.92f, 0.05f, 0.92f, rotationDegrees = 90, cropRevision = 1)

        val contact = SavedContactEntity(
            id = 7L,
            fullName = "Ariful Hoque",
            profilePhotoUri = "file:///front_crop_2.clenc",
            frontOriginalPhotoUri = "file:///front_orig.clenc",
            frontCropMetaJson = CardCropMetadata.toJson(frontMeta),
            frontCropRevision = 2,
            backPhotoUri = "file:///back_crop_1.clenc",
            backOriginalPhotoUri = "file:///back_orig.clenc",
            backCropMetaJson = CardCropMetadata.toJson(backMeta),
            backCropRevision = 1
        )

        // Updating Back revision must NEVER mutate Front metadata or revision
        val updatedBack = contact.copy(backCropRevision = contact.backCropRevision + 1)
        assertEquals(2, updatedBack.frontCropRevision)
        assertEquals(2, updatedBack.backCropRevision)
        assertEquals(0, CardCropMetadata.fromJson(updatedBack.frontCropMetaJson)?.rotationDegrees)
        assertEquals(90, CardCropMetadata.fromJson(updatedBack.backCropMetaJson)?.rotationDegrees)
    }

    @Test
    fun iphoneShareHelper_shortensLongUrlsAndValidatesLocally() {
        val shortened = IphoneNfcShareHelper.shortenUrlForDisplay("https://1drv.ms/u/s!AmSampleLongTokenString36568")
        assertTrue(shortened.startsWith("1drv.ms/"))
        assertTrue(shortened.endsWith("36568"))
        assertTrue(shortened.length <= 28)

        assertTrue(IphoneNfcShareHelper.validateDigitalCardUrlLocally("https://cardlink.app/u/mazharul").isValid)
        assertTrue(IphoneNfcShareHelper.validateDigitalCardUrlLocally("https://1drv.ms/u/abc").isHttps)
        assertFalse(IphoneNfcShareHelper.validateDigitalCardUrlLocally("http://example.com").isHttps)
        assertFalse(IphoneNfcShareHelper.validateDigitalCardUrlLocally("").isValid)
        assertFalse(IphoneNfcShareHelper.validateDigitalCardUrlLocally("javascript:alert(1)").isValid)
        assertFalse(IphoneNfcShareHelper.validateDigitalCardUrlLocally("https://invalid host/test").isValid)
    }

    @Test
    fun iphoneShareHelper_privacyPreviewMatchesSharingProfileExactly() {
        val base = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            designation = "Manager",
            companyName = "IFIC Bank PLC",
            phone = "+8801711000001",
            whatsapp = "+8801711000002",
            email = "work@ificbank.com",
            officeAddress = "IFIC Tower, Dhaka",
            sharePhone = true,
            shareWhatsapp = true,
            shareEmail = true,
            shareAddress = true,
            shareSocials = true
        )

        val conferenceCard = SharingProfileManager.applyProfile(base, SharingProfileType.CONFERENCE)
        val confPreview = IphoneNfcShareHelper.buildPrivacyPreviewItems(conferenceCard)
        assertTrue(confPreview.first { it.fieldId == "EMAIL" }.isShared)
        assertFalse(confPreview.first { it.fieldId == "PHONE" }.isShared)
        assertFalse(confPreview.first { it.fieldId == "WHATSAPP" }.isShared)
        assertFalse(confPreview.first { it.fieldId == "ADDRESS" }.isShared)

        val bizCard = SharingProfileManager.applyProfile(base, SharingProfileType.BUSINESS)
        val bizPreview = IphoneNfcShareHelper.buildPrivacyPreviewItems(bizCard)
        assertTrue(bizPreview.first { it.fieldId == "PHONE" }.isShared)
        assertTrue(bizPreview.first { it.fieldId == "ADDRESS" }.isShared)
        assertTrue(IphoneNfcShareHelper.buildProfileSummaryLine(bizCard).contains("Name"))
    }
}
