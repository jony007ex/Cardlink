package com.cardlink.app.util

import android.net.Uri
import com.cardlink.app.data.model.SavedContactEntity
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.Locale

enum class UniversalQrType(val label: String) {
    CARDLINK_PAYLOAD("CardLink Payload"),
    VCARD("Contact (vCard)"),
    MECARD("Contact (MECARD)"),
    WIFI("Wi-Fi Network"),
    EVENT("Calendar Event"),
    GS1("GS1 Product Data"),
    PAYMENT("Payment QR"),
    EMAIL("Email"),
    PHONE("Phone Number"),
    SMS("SMS Message"),
    WHATSAPP("WhatsApp"),
    LOCATION("Location"),
    CRYPTO("Cryptocurrency"),
    SOCIAL("Social Profile"),
    FILE_LINK("File Link"),
    URL("Website Link"),
    DEEP_LINK("App / Deep Link"),
    TEXT("Plain Text"),
    BINARY("Binary Data"),
    UNKNOWN("Custom / Unknown QR Content")
}

enum class QrParseConfidence(val label: String) {
    CONFIRMED("Recognized"),
    PARTIAL("Partially Recognized"),
    UNRECOGNIZED("Unknown Content")
}

enum class QrSecurityStatus(val label: String) {
    SAFE_STANDARD("Standard"),
    NON_SECURE_HTTP("Non-Secure HTTP Link"),
    UNRECOGNIZED_SCHEME("Unrecognized Link Scheme"),
    POTENTIAL_RISK("Potential Risk")
}

data class ParsedUniversalQr(
    val rawPayload: String,
    val rawBytes: ByteArray? = null,
    val isBinary: Boolean = false,
    val type: UniversalQrType,
    val confidence: QrParseConfidence,
    val securityStatus: QrSecurityStatus = QrSecurityStatus.SAFE_STANDARD,
    val displayTitle: String,
    val subtitle: String = "",
    val parsedFields: Map<String, String> = emptyMap(),
    val previewRows: List<Pair<String, String>> = emptyList(),
    val isSensitive: Boolean = false,
    val warningMessage: String = "",
    val parsedContact: SavedContactEntity? = null
) {
    fun toStudioContentType(): QrContentType = when (type) {
        UniversalQrType.URL, UniversalQrType.DEEP_LINK -> QrContentType.URL
        UniversalQrType.VCARD, UniversalQrType.MECARD -> QrContentType.VCARD
        UniversalQrType.WIFI -> QrContentType.WIFI
        UniversalQrType.EVENT -> QrContentType.EVENT
        UniversalQrType.EMAIL -> QrContentType.EMAIL
        UniversalQrType.PHONE -> QrContentType.PHONE
        UniversalQrType.SMS -> QrContentType.SMS
        UniversalQrType.WHATSAPP -> QrContentType.WHATSAPP
        UniversalQrType.LOCATION -> QrContentType.LOCATION
        UniversalQrType.SOCIAL -> QrContentType.SOCIAL
        UniversalQrType.PAYMENT -> QrContentType.PAYMENT
        UniversalQrType.CRYPTO -> QrContentType.CRYPTO
        UniversalQrType.FILE_LINK -> QrContentType.FILE_LINK
        UniversalQrType.TEXT -> QrContentType.TEXT
        else -> QrContentType.CUSTOM
    }
}

object UniversalQrParser {

    private val EMAIL_REGEX = Regex("""^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$""")
    private val FILE_EXT_REGEX = Regex("""\.(pdf|jpg|jpeg|png|webp|mp3|mp4|docx|xlsx|pptx|zip|csv)(\?.*)?$""", RegexOption.IGNORE_CASE)
    private val DANGEROUS_SCHEMES = setOf("javascript", "data", "file", "intent", "vbscript")

    fun sha256Hex(raw: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Deterministic priority-based parsing pipeline:
     * 1. Binary check
     * 2. CardLink versioned payload
     * 3. vCard
     * 4. MECARD
     * 5. Wi-Fi
     * 6. Calendar / Event (VEVENT)
     * 7. GS1 / EMV Payment structured payloads
     * 8. Email
     * 9. Phone
     * 10. SMS
     * 11. WhatsApp
     * 12. Geo / Location & Google Maps
     * 13. Cryptocurrency URI
     * 14. HTTP/HTTPS URL (Social, File Link, Standard Web Link)
     * 15. Other App / Deep Link URI
     * 16. Plain Text / Unknown fallback (never rejected!)
     */
    fun parse(rawText: String?, rawBytes: ByteArray? = null): ParsedUniversalQr {
        // 1. Binary / non-text check
        if (rawText.isNullOrEmpty() && rawBytes != null && rawBytes.isNotEmpty()) {
            return ParsedUniversalQr(
                rawPayload = "[Binary Payload: ${rawBytes.size} bytes]",
                rawBytes = rawBytes,
                isBinary = true,
                type = UniversalQrType.BINARY,
                confidence = QrParseConfidence.UNRECOGNIZED,
                displayTitle = "Binary QR Data (${rawBytes.size} bytes)",
                previewRows = listOf("Encoding" to "Binary / Non-Text", "Size" to "${rawBytes.size} bytes"),
                warningMessage = "This QR contains raw binary data. CardLink will not execute it."
            )
        }

        val raw = rawText.orEmpty()
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) {
            return ParsedUniversalQr(
                rawPayload = raw,
                type = UniversalQrType.UNKNOWN,
                confidence = QrParseConfidence.UNRECOGNIZED,
                displayTitle = "Empty QR Payload"
            )
        }

        // 2. CardLink versioned payload (cardlink://v1/...)
        if (trimmed.startsWith("cardlink://", ignoreCase = true)) {
            return parseCardLinkPayload(trimmed)
        }

        // 3. vCard (BEGIN:VCARD)
        if (trimmed.startsWith("BEGIN:VCARD", ignoreCase = true) || trimmed.contains("\nBEGIN:VCARD", ignoreCase = true)) {
            return parseVCard(trimmed)
        }

        // 4. MECARD
        if (trimmed.startsWith("MECARD:", ignoreCase = true)) {
            return parseMeCard(trimmed)
        }

        // 5. Wi-Fi (WIFI:)
        if (trimmed.startsWith("WIFI:", ignoreCase = true)) {
            return parseWifi(trimmed)
        }

        // 6. Calendar / Event (BEGIN:VEVENT / BEGIN:VCALENDAR)
        if (trimmed.startsWith("BEGIN:VEVENT", ignoreCase = true) ||
            trimmed.startsWith("BEGIN:VCALENDAR", ignoreCase = true) ||
            trimmed.contains("BEGIN:VEVENT", ignoreCase = true)
        ) {
            return parseEvent(trimmed)
        }

        // 7a. EMVCo Merchant-Presented Payment QR (starts with 000201) or UPI / Payment URI
        if (trimmed.startsWith("000201") && trimmed.length >= 24 && trimmed.contains("6304")) {
            return parseEmvPayment(trimmed)
        }
        if (trimmed.startsWith("upi://", ignoreCase = true) || trimmed.startsWith("paytmmp://", ignoreCase = true)) {
            return parsePaymentUri(trimmed)
        }

        // 7b. GS1 Digital Link or GS1 Application Identifier string
        if (trimmed.contains("/01/") && (trimmed.startsWith("https://", true) || trimmed.startsWith("http://", true))) {
            return parseGs1DigitalLink(trimmed)
        }
        if (trimmed.startsWith("(01)") && trimmed.length >= 18) {
            return parseGs1Text(trimmed)
        }

        // 8. Email (mailto: or MATMSG:)
        if (trimmed.startsWith("mailto:", ignoreCase = true) || trimmed.startsWith("MATMSG:", ignoreCase = true)) {
            return parseEmail(trimmed)
        }

        // 9. Phone (tel:)
        if (trimmed.startsWith("tel:", ignoreCase = true)) {
            return parsePhone(trimmed)
        }

        // 10. SMS (sms:, smsto:, SMSTO:)
        if (trimmed.startsWith("sms:", ignoreCase = true) || trimmed.startsWith("smsto:", ignoreCase = true)) {
            return parseSms(trimmed)
        }

        // 11. WhatsApp
        if (trimmed.startsWith("https://wa.me/", ignoreCase = true) ||
            trimmed.startsWith("http://wa.me/", ignoreCase = true) ||
            trimmed.startsWith("https://api.whatsapp.com/", ignoreCase = true) ||
            trimmed.startsWith("https://chat.whatsapp.com/", ignoreCase = true) ||
            trimmed.startsWith("whatsapp://", ignoreCase = true)
        ) {
            return parseWhatsApp(trimmed)
        }

        // 12. Geo / Location & Google Maps URLs
        if (trimmed.startsWith("geo:", ignoreCase = true) ||
            trimmed.startsWith("https://maps.google.", ignoreCase = true) ||
            trimmed.startsWith("https://www.google.com/maps", ignoreCase = true) ||
            trimmed.startsWith("https://maps.app.goo.gl/", ignoreCase = true)
        ) {
            return parseLocation(trimmed)
        }

        // 13. Cryptocurrency URI
        val lower = trimmed.lowercase(Locale.ROOT)
        if (lower.startsWith("bitcoin:") || lower.startsWith("ethereum:") ||
            lower.startsWith("solana:") || lower.startsWith("litecoin:")
        ) {
            return parseCrypto(trimmed)
        }

        // 14. HTTP / HTTPS URL (Social, File Link, or Standard Web Link)
        if (lower.startsWith("https://") || lower.startsWith("http://")) {
            return parseHttpUrl(trimmed)
        }

        // 15. Other App / Deep Link URI (e.g., myapp://...)
        val schemeMatch = Regex("""^([a-zA-Z][a-zA-Z0-9+\-.]{1,20}):(.+)$""").matchEntire(trimmed)
        if (schemeMatch != null && !trimmed.contains(" ") && !trimmed.contains("\n")) {
            val scheme = schemeMatch.groupValues[1].lowercase(Locale.ROOT)
            val isDangerous = scheme in DANGEROUS_SCHEMES
            return ParsedUniversalQr(
                rawPayload = raw,
                type = UniversalQrType.DEEP_LINK,
                confidence = QrParseConfidence.PARTIAL,
                securityStatus = if (isDangerous) QrSecurityStatus.POTENTIAL_RISK else QrSecurityStatus.UNRECOGNIZED_SCHEME,
                displayTitle = "App / Deep Link ($scheme://)",
                parsedFields = mapOf("scheme" to scheme, "uri" to trimmed),
                previewRows = listOf("Scheme" to scheme, "Target URI" to trimmed),
                warningMessage = if (isDangerous) {
                    "Potentially dangerous URI scheme ($scheme:). CardLink will not auto-execute this link."
                } else {
                    "Unrecognized custom app link scheme ($scheme:). Verify the destination before opening."
                }
            )
        }

        // 16. Plain Text / Custom Unknown Fallback (Never rejected!)
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.TEXT,
            confidence = QrParseConfidence.CONFIRMED,
            displayTitle = trimmed.lineSequence().firstOrNull()?.take(48) ?: "Plain Text",
            subtitle = "${raw.length} characters",
            parsedFields = mapOf("text" to raw),
            previewRows = listOf("Type" to "Plain Text", "Length" to "${raw.length} characters", "Content" to raw.take(300))
        )
    }

    private fun parseCardLinkPayload(raw: String): ParsedUniversalQr {
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val versionStr = uri?.host?.removePrefix("v")?.toIntOrNull() ?: 1
        if (versionStr > 1) {
            return ParsedUniversalQr(
                rawPayload = raw,
                type = UniversalQrType.CARDLINK_PAYLOAD,
                confidence = QrParseConfidence.PARTIAL,
                displayTitle = "CardLink QR (v$versionStr)",
                warningMessage = "This CardLink QR was created by a newer version of CardLink. Update CardLink or view the raw content.",
                previewRows = listOf("Payload Version" to "v$versionStr", "Raw URI" to raw)
            )
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.CARDLINK_PAYLOAD,
            confidence = QrParseConfidence.CONFIRMED,
            displayTitle = "CardLink Payload (v$versionStr)",
            previewRows = listOf("Version" to "v$versionStr", "Path" to (uri?.path ?: "/"))
        )
    }

    private fun parseVCard(raw: String): ParsedUniversalQr {
        val contact = CardShareHelper.parseVCardToContact(raw, receivedVia = "QR")
        val hasNameOrOrg = contact != null && (contact.fullName.isNotBlank() || contact.companyName.isNotBlank())
        val rows = buildList {
            if (contact != null) {
                if (contact.fullName.isNotBlank()) add("Name" to contact.fullName)
                if (contact.designation.isNotBlank()) add("Job Title" to contact.designation)
                if (contact.companyName.isNotBlank()) add("Organization" to contact.companyName)
                if (contact.phone.isNotBlank()) add("Phone" to contact.phone)
                if (contact.email.isNotBlank()) add("Email" to contact.email)
                if (contact.website.isNotBlank()) add("Website" to contact.website)
                if (contact.officeAddress.isNotBlank()) add("Address" to contact.officeAddress)
            }
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.VCARD,
            confidence = if (hasNameOrOrg) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = contact?.fullName?.ifBlank { contact.companyName } ?: "Contact Card",
            subtitle = listOfNotNull(contact?.designation?.takeIf { it.isNotBlank() }, contact?.companyName?.takeIf { it.isNotBlank() }).joinToString(" • "),
            previewRows = rows,
            isSensitive = true,
            parsedContact = contact
        )
    }

    private fun parseMeCard(raw: String): ParsedUniversalQr {
        val body = raw.removePrefix("MECARD:").removePrefix("mecard:")
        val map = mutableMapOf<String, String>()
        body.split(";").forEach { part ->
            val idx = part.indexOf(':')
            if (idx > 0) {
                val k = part.substring(0, idx).uppercase(Locale.ROOT).trim()
                val v = part.substring(idx + 1).trim()
                if (v.isNotBlank()) map[k] = v
            }
        }
        val rawName = map["N"].orEmpty()
        val displayName = if (rawName.contains(",")) {
            val parts = rawName.split(",").map { it.trim() }
            "${parts.getOrElse(1) { "" }} ${parts.getOrElse(0) { "" }}".trim()
        } else rawName

        val contact = SavedContactEntity(
            fullName = displayName.ifBlank { map["ORG"].orEmpty().ifBlank { "MECARD Contact" } },
            companyName = map["ORG"].orEmpty(),
            phone = map["TEL"].orEmpty(),
            whatsapp = map["TEL"].orEmpty(),
            email = map["EMAIL"].orEmpty(),
            website = map["URL"].orEmpty(),
            officeAddress = map["ADR"].orEmpty(),
            notes = map["NOTE"].orEmpty(),
            receivedVia = "QR (MECARD)"
        )
        val rows = buildList {
            if (contact.fullName.isNotBlank()) add("Name" to contact.fullName)
            if (contact.companyName.isNotBlank()) add("Organization" to contact.companyName)
            if (contact.phone.isNotBlank()) add("Phone" to contact.phone)
            if (contact.email.isNotBlank()) add("Email" to contact.email)
            if (contact.website.isNotBlank()) add("Website" to contact.website)
            if (contact.officeAddress.isNotBlank()) add("Address" to contact.officeAddress)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.MECARD,
            confidence = if (map.isNotEmpty()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = contact.fullName,
            subtitle = contact.phone.ifBlank { contact.email },
            parsedFields = map,
            previewRows = rows,
            isSensitive = true,
            parsedContact = contact
        )
    }

    private fun parseWifi(raw: String): ParsedUniversalQr {
        val body = raw.substring(5)
        val fields = mutableMapOf<String, String>()
        val token = StringBuilder()
        var escaped = false
        for (ch in body) {
            if (escaped) {
                token.append(ch)
                escaped = false
            } else if (ch == '\\') {
                escaped = true
            } else if (ch == ';') {
                val s = token.toString()
                val idx = s.indexOf(':')
                if (idx > 0) {
                    fields[s.substring(0, idx).uppercase(Locale.ROOT)] = s.substring(idx + 1)
                }
                token.clear()
            } else {
                token.append(ch)
            }
        }
        val ssid = fields["S"].orEmpty()
        val pass = fields["P"].orEmpty()
        val sec = fields["T"].orEmpty().ifBlank { if (pass.isBlank()) "nopass" else "WPA" }
        val hidden = fields["H"].equals("true", ignoreCase = true)

        val secDisplay = when (sec.uppercase(Locale.ROOT)) {
            "NOPASS" -> "Open (No Password)"
            "WEP" -> "WEP"
            else -> "WPA / WPA2 / WPA3"
        }

        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.WIFI,
            confidence = if (ssid.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = ssid.ifBlank { "Wi-Fi Network" },
            subtitle = secDisplay,
            parsedFields = mapOf(
                "ssid" to ssid,
                "password" to pass,
                "security" to sec,
                "hidden" to hidden.toString()
            ),
            previewRows = listOf(
                "Network" to ssid.ifBlank { "—" },
                "Security" to secDisplay,
                "Password" to if (pass.isBlank()) "None" else "••••••••",
                "Hidden" to if (hidden) "Yes" else "No"
            ),
            isSensitive = pass.isNotBlank()
        )
    }

    private fun parseEvent(raw: String): ParsedUniversalQr {
        val map = mutableMapOf<String, String>()
        raw.lines().forEach { line ->
            val idx = line.indexOf(':')
            if (idx > 0) {
                val keyPart = line.substring(0, idx).uppercase(Locale.ROOT)
                val baseKey = keyPart.substringBefore(';')
                val value = line.substring(idx + 1).trim()
                if (baseKey !in map && value.isNotBlank()) map[baseKey] = value
                if (keyPart.contains("TZID=")) {
                    map["TZID"] = keyPart.substringAfter("TZID=").substringBefore(';')
                }
            }
        }
        val title = unescapeIcs(map["SUMMARY"].orEmpty())
        val loc = unescapeIcs(map["LOCATION"].orEmpty())
        val start = map["DTSTART"].orEmpty()
        val end = map["DTEND"].orEmpty()
        val desc = unescapeIcs(map["DESCRIPTION"].orEmpty())
        val tz = map["TZID"].orEmpty()

        val rows = buildList {
            if (title.isNotBlank()) add("Event" to title)
            if (start.isNotBlank()) add("Start" to start)
            if (end.isNotBlank()) add("End" to end)
            if (tz.isNotBlank()) add("Time Zone" to tz)
            if (loc.isNotBlank()) add("Location" to loc)
            if (desc.isNotBlank()) add("Description" to desc)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.EVENT,
            confidence = if (title.isNotBlank() && start.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = title.ifBlank { "Calendar Event" },
            subtitle = loc.ifBlank { start },
            parsedFields = mapOf(
                "title" to title,
                "location" to loc,
                "start" to start,
                "end" to end,
                "description" to desc,
                "tz" to tz
            ),
            previewRows = rows
        )
    }

    private fun parseEmvPayment(raw: String): ParsedUniversalQr {
        // Basic EMV TLV parser for Merchant Name (Tag 59), City (Tag 60), Amount (Tag 54), Currency (Tag 53)
        val tags = mutableMapOf<String, String>()
        var i = 0
        while (i + 4 <= raw.length) {
            val tag = raw.substring(i, i + 2)
            val len = raw.substring(i + 2, i + 4).toIntOrNull() ?: break
            if (i + 4 + len > raw.length) break
            tags[tag] = raw.substring(i + 4, i + 4 + len)
            i += 4 + len
        }
        val merchant = tags["59"].orEmpty()
        val city = tags["60"].orEmpty()
        val amount = tags["54"].orEmpty()
        val currency = tags["53"].orEmpty()
        val rows = buildList {
            add("Format" to "EMV Merchant-Presented QR")
            if (merchant.isNotBlank()) add("Merchant" to merchant)
            if (city.isNotBlank()) add("City" to city)
            if (amount.isNotBlank()) add("Amount" to amount)
            if (currency.isNotBlank()) add("Currency Code" to currency)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.PAYMENT,
            confidence = if (merchant.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = merchant.ifBlank { "EMV Payment QR" },
            subtitle = if (amount.isNotBlank()) "Amount: $amount" else "Merchant Payment Payload",
            parsedFields = tags,
            previewRows = rows,
            isSensitive = true,
            warningMessage = "CardLink does not verify merchants or execute payments. Open only in your trusted payment app."
        )
    }

    private fun parsePaymentUri(raw: String): ParsedUniversalQr {
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val payee = uri?.getQueryParameter("pn") ?: uri?.getQueryParameter("pa").orEmpty()
        val amount = uri?.getQueryParameter("am").orEmpty()
        val currency = uri?.getQueryParameter("cu").orEmpty()
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.PAYMENT,
            confidence = QrParseConfidence.CONFIRMED,
            displayTitle = payee.ifBlank { "Payment URI" },
            subtitle = if (amount.isNotBlank()) "$currency $amount".trim() else raw.take(40),
            parsedFields = mapOf("uri" to raw, "payee" to payee, "amount" to amount, "currency" to currency),
            previewRows = listOfNotNull(
                "Type" to "Payment URI",
                payee.takeIf { it.isNotBlank() }?.let { "Payee" to it },
                amount.takeIf { it.isNotBlank() }?.let { "Amount" to "$currency $it".trim() },
                "Destination" to raw
            ),
            isSensitive = true,
            warningMessage = "Verify the recipient and amount carefully before continuing in your payment app."
        )
    }

    private fun parseGs1DigitalLink(raw: String): ParsedUniversalQr {
        val gtin = Regex("""/01/(\d{8,14})""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val lot = Regex("""/10/([^/?#]+)""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val serial = Regex("""/21/([^/?#]+)""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val rows = buildList {
            add("Standard" to "GS1 Digital Link")
            if (gtin.isNotBlank()) add("GTIN (01)" to gtin)
            if (lot.isNotBlank()) add("Batch / Lot (10)" to lot)
            if (serial.isNotBlank()) add("Serial (21)" to serial)
            add("Link" to raw)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.GS1,
            confidence = if (gtin.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = if (gtin.isNotBlank()) "GS1 Product ($gtin)" else "GS1 Digital Link",
            parsedFields = mapOf("gtin" to gtin, "lot" to lot, "serial" to serial, "url" to raw),
            previewRows = rows
        )
    }

    private fun parseGs1Text(raw: String): ParsedUniversalQr {
        val gtin = Regex("""\(01\)(\d{8,14})""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val exp = Regex("""\(17\)(\d{6})""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val lot = Regex("""\(10\)([^(]+)""").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val rows = buildList {
            add("Standard" to "GS1 Application Identifiers")
            if (gtin.isNotBlank()) add("GTIN (01)" to gtin)
            if (exp.isNotBlank()) add("Expiry YYMMDD (17)" to exp)
            if (lot.isNotBlank()) add("Batch / Lot (10)" to lot)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.GS1,
            confidence = if (gtin.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = if (gtin.isNotBlank()) "GS1 Product ($gtin)" else "GS1 Data",
            parsedFields = mapOf("gtin" to gtin, "expiry" to exp, "lot" to lot),
            previewRows = rows
        )
    }

    private fun parseEmail(raw: String): ParsedUniversalQr {
        var to = ""
        var subject = ""
        var body = ""
        if (raw.startsWith("mailto:", ignoreCase = true)) {
            val withoutScheme = raw.substring(7)
            to = withoutScheme.substringBefore('?').trim()
            val query = withoutScheme.substringAfter('?', "")
            query.split('&').forEach { pair ->
                val k = pair.substringBefore('=').lowercase(Locale.ROOT)
                val v = urlDec(pair.substringAfter('=', ""))
                when (k) {
                    "subject" -> subject = v
                    "body" -> body = v
                }
            }
        } else {
            // MATMSG:TO:...;SUB:...;BODY:...;;
            to = Regex("""TO:([^;]+)""", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.getOrNull(1).orEmpty()
            subject = Regex("""SUB:([^;]+)""", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.getOrNull(1).orEmpty()
            body = Regex("""BODY:([^;]+)""", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val valid = EMAIL_REGEX.matches(to)
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.EMAIL,
            confidence = if (valid) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = to.ifBlank { "Email" },
            subtitle = subject,
            parsedFields = mapOf("email" to to, "subject" to subject, "body" to body),
            previewRows = listOfNotNull(
                "Recipient" to to.ifBlank { "—" },
                subject.takeIf { it.isNotBlank() }?.let { "Subject" to it },
                body.takeIf { it.isNotBlank() }?.let { "Message" to it }
            )
        )
    }

    private fun parsePhone(raw: String): ParsedUniversalQr {
        val number = raw.substring(4).trim()
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.PHONE,
            confidence = if (number.any { it.isDigit() }) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = number.ifBlank { "Phone Number" },
            parsedFields = mapOf("phone" to number),
            previewRows = listOf("Phone Number" to number, "Original Value" to raw)
        )
    }

    private fun parseSms(raw: String): ParsedUniversalQr {
        val body = raw.substringAfter(':')
        val phone = body.substringBefore(':').substringBefore('?').trim()
        val msg = when {
            body.contains(':') -> body.substringAfter(':')
            body.contains("body=", true) -> urlDec(body.substringAfter("body=").substringBefore('&'))
            else -> ""
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.SMS,
            confidence = if (phone.any { it.isDigit() }) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            displayTitle = phone.ifBlank { "SMS Message" },
            subtitle = msg.take(60),
            parsedFields = mapOf("phone" to phone, "message" to msg),
            previewRows = listOfNotNull(
                "Phone Number" to phone.ifBlank { "—" },
                msg.takeIf { it.isNotBlank() }?.let { "Message" to it }
            )
        )
    }

    private fun parseWhatsApp(raw: String): ParsedUniversalQr {
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val pathNum = uri?.pathSegments?.firstOrNull()?.filter { it.isDigit() }.orEmpty()
        val queryNum = uri?.getQueryParameter("phone")?.filter { it.isDigit() }.orEmpty()
        val number = pathNum.ifBlank { queryNum }
        val text = uri?.getQueryParameter("text").orEmpty()
        val isGroup = raw.contains("chat.whatsapp.com", ignoreCase = true)

        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.WHATSAPP,
            confidence = QrParseConfidence.CONFIRMED,
            displayTitle = if (isGroup) "WhatsApp Group Invite" else if (number.isNotBlank()) "+$number" else "WhatsApp Link",
            subtitle = text.take(60),
            parsedFields = mapOf("phone" to number, "message" to text, "url" to raw),
            previewRows = listOfNotNull(
                "Type" to if (isGroup) "WhatsApp Group" else "WhatsApp Chat",
                number.takeIf { it.isNotBlank() }?.let { "Number" to "+$it" },
                text.takeIf { it.isNotBlank() }?.let { "Prefilled Message" to it },
                "Destination" to raw
            )
        )
    }

    private fun parseLocation(raw: String): ParsedUniversalQr {
        if (raw.startsWith("geo:", ignoreCase = true)) {
            val coordsPart = raw.substring(4).substringBefore('?')
            val lat = coordsPart.substringBefore(',').trim()
            val lng = coordsPart.substringAfter(',', "").substringBefore(',').trim()
            val query = raw.substringAfter("q=", "").let { if (it == raw) "" else urlDec(it) }
            return ParsedUniversalQr(
                rawPayload = raw,
                type = UniversalQrType.LOCATION,
                confidence = if (lat.toDoubleOrNull() != null && lng.toDoubleOrNull() != null) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
                displayTitle = query.ifBlank { "Location ($lat, $lng)" },
                parsedFields = mapOf("latitude" to lat, "longitude" to lng, "label" to query, "uri" to raw),
                previewRows = listOfNotNull(
                    "Latitude" to lat,
                    "Longitude" to lng,
                    query.takeIf { it.isNotBlank() }?.let { "Label" to it }
                )
            )
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.LOCATION,
            confidence = QrParseConfidence.CONFIRMED,
            displayTitle = "Google Maps Location",
            parsedFields = mapOf("uri" to raw),
            previewRows = listOf("Type" to "Map Link", "Destination" to raw)
        )
    }

    private fun parseCrypto(raw: String): ParsedUniversalQr {
        val scheme = raw.substringBefore(':').lowercase(Locale.ROOT)
        val rest = raw.substringAfter(':')
        val address = rest.substringBefore('?').trim()
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val amount = uri?.getQueryParameter("amount").orEmpty()
        val memo = uri?.getQueryParameter("message") ?: uri?.getQueryParameter("label").orEmpty()

        val networkLabel = when (scheme) {
            "bitcoin" -> "Bitcoin (BTC)"
            "ethereum" -> "Ethereum (ETH)"
            "solana" -> "Solana (SOL)"
            "litecoin" -> "Litecoin (LTC)"
            else -> scheme.uppercase(Locale.ROOT)
        }
        return ParsedUniversalQr(
            rawPayload = raw,
            type = UniversalQrType.CRYPTO,
            confidence = if (address.length >= 16) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            securityStatus = QrSecurityStatus.POTENTIAL_RISK,
            displayTitle = networkLabel,
            subtitle = "${address.take(10)}…${address.takeLast(6)}",
            parsedFields = mapOf("network" to networkLabel, "address" to address, "amount" to amount, "memo" to memo),
            previewRows = listOfNotNull(
                "Network" to networkLabel,
                "Address" to address,
                amount.takeIf { it.isNotBlank() }?.let { "Amount" to it },
                memo.takeIf { it.isNotBlank() }?.let { "Note" to it }
            ),
            isSensitive = true,
            warningMessage = "Verify the network and destination address before continuing. Cryptocurrency transfers may be irreversible."
        )
    }

    private fun parseHttpUrl(raw: String): ParsedUniversalQr {
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val host = uri?.host.orEmpty().lowercase(Locale.ROOT)
        val scheme = uri?.scheme.orEmpty().lowercase(Locale.ROOT)

        val isPunycode = host.contains("xn--")
        val isHttpOnly = scheme == "http"
        val security = when {
            isPunycode -> QrSecurityStatus.POTENTIAL_RISK
            isHttpOnly -> QrSecurityStatus.NON_SECURE_HTTP
            else -> QrSecurityStatus.SAFE_STANDARD
        }
        val warn = when (security) {
            QrSecurityStatus.POTENTIAL_RISK -> "Suspicious internationalized (punycode) domain detected ($host). Verify carefully before opening."
            QrSecurityStatus.NON_SECURE_HTTP -> "Non-secure HTTP link. Data sent to this site is not encrypted."
            else -> ""
        }

        val socialLabel = when {
            host.contains("linkedin.com") -> "LinkedIn"
            host.contains("facebook.com") || host.contains("fb.com") -> "Facebook"
            host.contains("instagram.com") -> "Instagram"
            host.contains("x.com") || host.contains("twitter.com") -> "X / Twitter"
            host.contains("youtube.com") || host.contains("youtu.be") -> "YouTube"
            host.contains("tiktok.com") -> "TikTok"
            host.contains("github.com") -> "GitHub"
            else -> null
        }

        val fileMatch = FILE_EXT_REGEX.find(raw)
        val type = when {
            socialLabel != null -> UniversalQrType.SOCIAL
            fileMatch != null -> UniversalQrType.FILE_LINK
            else -> UniversalQrType.URL
        }

        val rows = buildList {
            if (socialLabel != null) add("Service" to socialLabel)
            if (fileMatch != null) add("File Extension" to ".${fileMatch.groupValues[1].uppercase(Locale.ROOT)}")
            add("Domain" to host.ifBlank { "Unknown" })
            add("Scheme" to scheme.uppercase(Locale.ROOT))
            add("Destination" to raw)
        }

        return ParsedUniversalQr(
            rawPayload = raw,
            type = type,
            confidence = if (host.isNotBlank()) QrParseConfidence.CONFIRMED else QrParseConfidence.PARTIAL,
            securityStatus = security,
            displayTitle = socialLabel ?: host.ifBlank { "Website Link" },
            subtitle = raw.take(64),
            parsedFields = mapOf("url" to raw, "domain" to host, "scheme" to scheme),
            previewRows = rows,
            warningMessage = warn
        )
    }

    private fun unescapeIcs(v: String): String =
        v.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

    private fun urlDec(s: String): String =
        runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault(s)
}
