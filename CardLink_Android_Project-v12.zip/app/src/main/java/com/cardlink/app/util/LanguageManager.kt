package com.cardlink.app.util

import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.content.res.Resources
import java.util.Locale

object LanguageManager {
    private const val PREFS_NAME = "cardlink_app_preferences"
    private const val KEY_LANGUAGE = "app_language_code"
    private const val KEY_THEME_MODE = "app_theme_mode"

    const val LANG_ENGLISH = "en"
    const val LANG_BANGLA = "bn"

    fun getSavedLanguage(context: Context): String {
        val code = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, LANG_ENGLISH)
        return if (code == LANG_BANGLA) LANG_BANGLA else LANG_ENGLISH
    }

    fun saveLanguage(context: Context, languageCode: String) {
        val normalized = if (languageCode == LANG_BANGLA) LANG_BANGLA else LANG_ENGLISH
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE, normalized)
            .apply()
        Locale.setDefault(Locale(normalized))
    }

    fun getSavedThemeOverride(context: Context): Boolean? {
        return when (context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_THEME_MODE, "SYSTEM")) {
            "LIGHT" -> false
            "DARK" -> true
            else -> null
        }
    }

    fun saveThemeOverride(context: Context, isDark: Boolean?) {
        val mode = when (isDark) {
            false -> "LIGHT"
            true -> "DARK"
            null -> "SYSTEM"
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_THEME_MODE, mode)
            .apply()
    }

    fun wrapBaseContext(base: Context): Context {
        val lang = getSavedLanguage(base)
        return createLocalizedResourcesContext(base, lang)
    }

    fun createLocalizedResourcesContext(base: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return base.createConfigurationContext(config)
    }

    /**
     * Wraps an Activity context so Jetpack Compose stringResource() reads the runtime-selected
     * locale resources immediately while preserving the Activity window token for Dialogs & Intents.
     */
    fun wrapActivityForCompose(activityContext: Context, languageCode: String): Context {
        val localizedRes = createLocalizedResourcesContext(activityContext, languageCode).resources
        return LocalizedActivityContextWrapper(activityContext, localizedRes)
    }
}

private class LocalizedActivityContextWrapper(
    base: Context,
    private val localizedResources: Resources
) : ContextWrapper(base) {
    override fun getResources(): Resources = localizedResources
}
