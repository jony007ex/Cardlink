package com.cardlink.app

import com.cardlink.app.data.model.LoyaltyCardEntity
import com.cardlink.app.util.CardLinkImageOptimizationService
import com.cardlink.app.util.CardOptimizationProfile
import com.cardlink.app.util.LoyaltyNumberConfidence
import com.cardlink.app.util.LoyaltyOcrClassifier
import org.junit.Assert.*
import org.junit.Test

class LoyaltyOcrAndOptimizationTest {

    @Test
    fun loyaltyOcrClassifier_detectsLabelledMembershipNumberInEnglishAndBangla() {
        val enLines = listOf(
            "UNIMART" to 64,
            "Privilege" to 36,
            "Membership No: 20000358" to 28,
            "Hotline: 16429" to 20,
            "Exp: 12/2028" to 20
        )
        val enRes = LoyaltyOcrClassifier.classifyLines(enLines)
        assertEquals("UNIMART", enRes.suggestedBrand)
        assertEquals("20000358", enRes.suggestedMembershipNumber)
        assertEquals(LoyaltyNumberConfidence.LABELLED_HIGH, enRes.membershipConfidence)
        assertEquals("Privilege", enRes.suggestedTier)

        val bnLines = listOf(
            "স্বপ্ন" to 58,
            "মেম্বারশিপ নম্বর: ২০০০০৩৫৮" to 30,
            "মোবাইল: ০১৭১১-২২৩৩৪৪" to 22
        )
        val bnRes = LoyaltyOcrClassifier.classifyLines(bnLines)
        assertEquals("20000358", bnRes.suggestedMembershipNumber)
        assertEquals(LoyaltyNumberConfidence.LABELLED_HIGH, bnRes.membershipConfidence)
    }

    @Test
    fun loyaltyOcrClassifier_handlesNextLineSpatialValueAndRejectsFalseIdentifiers() {
        val lines = listOf(
            "Agora Rewards" to 52,
            "Phone: +8801711223344" to 22,
            "Dhaka 1212" to 20,
            "Valid Thru 09/27" to 20,
            "Member ID" to 24,
            "AG-9940218" to 30
        )
        val res = LoyaltyOcrClassifier.classifyLines(lines)
        assertEquals("AG-9940218", res.suggestedMembershipNumber)
        assertEquals(LoyaltyNumberConfidence.LABELLED_HIGH, res.membershipConfidence)

        // Phone numbers, dates, and hotlines must be rejected
        assertTrue(LoyaltyOcrClassifier.isLikelyFalseIdentifier("01711223344", "01711223344"))
        assertTrue(LoyaltyOcrClassifier.isLikelyFalseIdentifier("+8801711223344", "Tel: +8801711223344"))
        assertTrue(LoyaltyOcrClassifier.isLikelyFalseIdentifier("16429", "Hotline 16429"))
        assertTrue(LoyaltyOcrClassifier.isLikelyFalseIdentifier("12/2028", "Exp: 12/2028"))
        assertFalse(LoyaltyOcrClassifier.isLikelyFalseIdentifier("20000358", "20000358"))
    }

    @Test
    fun membershipNumberAndBarcodePayload_remainStrictlySeparate() {
        val card = LoyaltyCardEntity(
            brandName = "Unimart",
            cardNickname = "Privilege",
            cardNumber = "20000358",
            barcodeValue = "020000358995",
            barcodeFormat = "CODE_128",
            barcodeVerified = true,
            barcodeSource = "SCANNED",
            membershipNumberSource = "OCR_CONFIRMED"
        )
        assertEquals("20000358", card.cardNumber)
        assertEquals("020000358995", card.barcodeValue)
        assertNotEquals(card.cardNumber, card.barcodeValue)
        assertTrue(card.barcodeVerified)
        assertEquals("SCANNED", card.barcodeSource)
    }

    @Test
    fun safeBarcodeFormatInference_validatesGs1CheckDigitsAndOffersCode128() {
        // Valid EAN-13 (4006381333931 has valid check digit 1)
        assertTrue(LoyaltyOcrClassifier.hasValidGs1CheckDigit("4006381333931"))
        assertFalse(LoyaltyOcrClassifier.hasValidGs1CheckDigit("4006381333939"))

        val eanOpts = LoyaltyOcrClassifier.getSafeBarcodeFormatsForNumber("4006381333931")
        assertTrue(eanOpts.any { it.formatName == "EAN_13" && it.isRecommended })

        // Standard 8-digit membership number without EAN-8 check digit must recommend CODE_128, NOT guess EAN_8!
        val memberOpts = LoyaltyOcrClassifier.getSafeBarcodeFormatsForNumber("20000358")
        assertTrue(memberOpts.any { it.formatName == "CODE_128" && it.isRecommended })
        assertFalse(memberOpts.any { it.formatName == "EAN_8" })
    }

    @Test
    fun imageOptimizationProfiles_keepSeparateTargetsAndFormatReadableSizes() {
        assertEquals("scanned_cards", CardOptimizationProfile.BUSINESS_CARD.subFolder)
        assertEquals("loyalty_cards", CardOptimizationProfile.LOYALTY_CARD.subFolder)
        assertTrue(CardOptimizationProfile.LOYALTY_CARD.candidateMaxEdges.first() in 1600..2400)
        assertEquals("512 B", CardLinkImageOptimizationService.formatBytesReadable(512L))
        assertTrue(CardLinkImageOptimizationService.formatBytesReadable(2L * 1024L * 1024L).contains("MB"))
    }
}
