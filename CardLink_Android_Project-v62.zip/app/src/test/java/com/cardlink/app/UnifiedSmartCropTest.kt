package com.cardlink.app

import com.cardlink.app.data.model.IdDocumentPageEntity
import com.cardlink.app.data.model.LoyaltyCardEntity
import com.cardlink.app.util.*
import org.junit.Assert.*
import org.junit.Test

class UnifiedSmartCropTest {

    @Test
    fun confidenceReviewPolicy_routesHighMediumLowCorrectly() {
        assertEquals(false to false, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.ONLY_WHEN_NEEDED, CropConfidenceLevel.HIGH))
        assertEquals(true to false, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.ONLY_WHEN_NEEDED, CropConfidenceLevel.MEDIUM))
        assertEquals(true to true, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.ONLY_WHEN_NEEDED, CropConfidenceLevel.LOW))

        assertEquals(true to false, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.ALWAYS, CropConfidenceLevel.HIGH))
        assertEquals(true to true, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.ALWAYS, CropConfidenceLevel.LOW))

        assertEquals(false to false, SmartCardCropEngine.decideReviewBehavior(true, CropReviewPolicy.NEVER, CropConfidenceLevel.LOW))
        assertEquals(false to false, SmartCardCropEngine.decideReviewBehavior(false, CropReviewPolicy.ALWAYS, CropConfidenceLevel.LOW))
    }

    @Test
    fun magneticEdgeSnap_snapsGentlyWithinThresholdAndAllowsUserOverride() {
        val detected = CardCropMetadata(0.12f, 0.16f, 0.88f, 0.15f, 0.89f, 0.83f, 0.11f, 0.82f)

        val (sx, sy, snapped) = SmartCardCropEngine.snapCornerToDetectedEdge(0.13f, 0.17f, 0, detected)
        assertTrue(snapped)
        assertEquals(0.12f, sx, 0.0001f)
        assertEquals(0.16f, sy, 0.0001f)

        val (ox, oy, snappedFar) = SmartCardCropEngine.snapCornerToDetectedEdge(0.25f, 0.30f, 0, detected)
        assertFalse(snappedFar)
        assertEquals(0.25f, ox, 0.0001f)
        assertEquals(0.30f, oy, 0.0001f)
    }

    @Test
    fun zoomAndPanInverseTransform_mapsScreenPointsAccuratelyToNormalizedCoords() {
        val (nx1, ny1) = SmartCardCropEngine.screenToNormalizedImageCoord(500f, 300f, 1000f, 600f, 1f, 0f, 0f)
        assertEquals(0.5f, nx1, 0.0001f)
        assertEquals(0.5f, ny1, 0.0001f)

        val (nx2, ny2) = SmartCardCropEngine.screenToNormalizedImageCoord(600f, 240f, 1000f, 600f, 2f, 100f, -60f)
        assertEquals(0.5f, nx2, 0.0001f)
        assertEquals(0.5f, ny2, 0.0001f)
    }

    @Test
    fun loyaltyFrontBackAndIdMultiPageCropStates_remainCompletelyIndependent() {
        val frontMeta = CardCropMetadata(0.08f, 0.10f, 0.92f, 0.10f, 0.92f, 0.90f, 0.08f, 0.90f, rotationDegrees = 0, cropRevision = 1, featureType = SmartCropFeatureType.LOYALTY_CARD.id, sideOrPage = "FRONT")
        val backMeta = CardCropMetadata(0.15f, 0.12f, 0.85f, 0.12f, 0.85f, 0.88f, 0.15f, 0.88f, rotationDegrees = 180, cropRevision = 2, featureType = SmartCropFeatureType.LOYALTY_CARD.id, sideOrPage = "BACK")

        val lc = LoyaltyCardEntity(
            brandName = "Unimart",
            cardNumber = "20000358",
            barcodeValue = "020000358995",
            frontPhotoUri = "file:///lc_front_crop.clenc",
            frontOriginalPhotoUri = "file:///lc_front_orig.clenc",
            frontCropMetaJson = CardCropMetadata.toJson(frontMeta),
            frontCropRevision = 1,
            backPhotoUri = "file:///lc_back_crop.clenc",
            backOriginalPhotoUri = "file:///lc_back_orig.clenc",
            backCropMetaJson = CardCropMetadata.toJson(backMeta),
            backCropRevision = 2
        )

        val resetBack = lc.copy(backPhotoUri = lc.backOriginalPhotoUri, backCropMetaJson = "", backCropRevision = lc.backCropRevision + 1)
        assertEquals(1, resetBack.frontCropRevision)
        assertEquals(3, resetBack.backCropRevision)
        assertEquals("020000358995", resetBack.barcodeValue)
        assertEquals("20000358", resetBack.cardNumber)
        assertNotNull(CardCropMetadata.fromJson(resetBack.frontCropMetaJson))

        val p1 = IdDocumentPageEntity(documentUuid = "doc-1", pageIndex = 0, pageLabel = "Page 1", imageUri = "file:///p1_c.clenc", originalImageUri = "file:///p1_o.clenc", cropMetaJson = CardCropMetadata.toJson(frontMeta), cropRevision = 1)
        val p2 = IdDocumentPageEntity(documentUuid = "doc-1", pageIndex = 1, pageLabel = "Page 2", imageUri = "file:///p2_c.clenc", originalImageUri = "file:///p2_o.clenc", cropMetaJson = CardCropMetadata.toJson(backMeta), cropRevision = 2)
        assertEquals(0, CardCropMetadata.fromJson(p1.cropMetaJson)?.rotationDegrees)
        assertEquals(180, CardCropMetadata.fromJson(p2.cropMetaJson)?.rotationDegrees)
        assertNotEquals(p1.originalImageUri, p2.originalImageUri)
    }

    @Test
    fun extendedCropMetadata_roundTripsSafelyAndHandlesCorruptedLegacyJson() {
        val full = CardCropMetadata(
            topLeftX = 0.12f, topLeftY = 0.16f,
            topRightX = 0.88f, topRightY = 0.15f,
            bottomRightX = 0.89f, bottomRightY = 0.83f,
            bottomLeftX = 0.11f, bottomLeftY = 0.82f,
            rotationDegrees = 90,
            cropRevision = 3,
            featureType = SmartCropFeatureType.ID_DOCUMENT.id,
            sideOrPage = "BACK",
            sourceWidth = 2400,
            sourceHeight = 1600
        )
        val encoded = CardCropMetadata.toJson(full)
        val decoded = CardCropMetadata.fromJson(encoded)
        assertNotNull(decoded)
        assertEquals("ID_DOCUMENT", decoded?.featureType)
        assertEquals("BACK", decoded?.sideOrPage)
        assertEquals(2400, decoded?.sourceWidth)
        assertEquals(3, decoded?.cropRevision)

        assertNull(CardCropMetadata.fromJson("not-valid-json-payload"))
        assertNull(CardCropMetadata.fromJson(""))

        val bad = CardCropMetadata(topLeftX = -5f, topRightX = Float.NaN, bottomRightX = 0.2f, bottomLeftX = 0.9f)
        assertFalse(SmartCardCropEngine.isValidQuad(bad))
        assertTrue(SmartCardCropEngine.isValidQuad(SmartCardCropEngine.sanitizeMetadata(bad)))
    }
}
