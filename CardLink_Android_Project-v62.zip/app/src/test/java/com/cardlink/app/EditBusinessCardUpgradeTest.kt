package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.*
import org.junit.Assert.*
import org.junit.Test

class EditBusinessCardUpgradeTest {

    @Test
    fun legacySinglePhoneCard_migratesTransparentlyWithoutDataLoss() {
        val legacy = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            phone = "+8801700799353",
            whatsapp = "+8801700799353",
            phoneNumbersJson = ""
        )
        val phones = BusinessCardProfileHelper.parsePhoneNumbers(legacy)
        assertEquals(1, phones.size)
        assertEquals("+8801700799353", phones.first().number)
        assertTrue(phones.first().isPrimary)
        assertTrue(phones.first().isWhatsAppEnabled)
    }

    @Test
    fun multiplePhones_deduplicateFormatsValidateInternationalAndPreserveOrder() {
        assertEquals(
            BusinessCardProfileHelper.normalizePhoneForComparison("01700123456"),
            BusinessCardProfileHelper.normalizePhoneForComparison("+880 1700-123456")
        )
        assertTrue(BusinessCardProfileHelper.isValidPhoneNumber("+1 (415) 555-0192"))
        assertTrue(BusinessCardProfileHelper.isValidPhoneNumber("+44 20 7946 0958 ext 204"))
        assertTrue(BusinessCardProfileHelper.isValidPhoneNumber("01700799353"))
        assertFalse(BusinessCardProfileHelper.isValidPhoneNumber("abc-12"))

        val existing = listOf(
            CardPhoneRecord(id = "p1", number = "+880 1700 799353", type = CardPhoneType.MOBILE, isPrimary = true, displayOrder = 0)
        )
        val incoming = listOf(
            CardPhoneRecord(number = "01700799353", type = CardPhoneType.MOBILE), // Same number, different format -> deduplicated!
            CardPhoneRecord(number = "+880 2 9562020 ext 12", type = CardPhoneType.OFFICE),
            CardPhoneRecord(number = "+1 212 555 0144", type = CardPhoneType.WORK)
        )
        val merged = BusinessCardProfileHelper.deduplicateAndMergePhones(existing, incoming)
        assertEquals(3, merged.size)
        assertEquals("+880 1700 799353", merged[0].number)
        assertTrue(merged[0].isPrimary)
        assertEquals(CardPhoneType.OFFICE, merged[1].type)
        assertEquals(CardPhoneType.WORK, merged[2].type)
    }

    @Test
    fun professionalCredentials_orderVisibilitySharingProfileAndVCardSuffix() {
        val base = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            phone = "+8801700799353",
            email = "mazharul@ificbank.com"
        )
        val creds = listOf(
            CardCredentialRecord(id = "c1", label = "MBA", displayOrder = 0),
            CardCredentialRecord(id = "c2", label = "CIPS", displayOrder = 1),
            CardCredentialRecord(id = "c3", label = "PMP", displayOrder = 2)
        )
        val phones = listOf(
            CardPhoneRecord(id = "p1", number = "+8801700799353", type = CardPhoneType.MOBILE, isPrimary = true, displayOrder = 0),
            CardPhoneRecord(id = "p2", number = "+88029562020", type = CardPhoneType.OFFICE, isPrimary = false, displayOrder = 1)
        )
        val card = BusinessCardProfileHelper.applyPhonesAndCredentials(base, phones, creds, showCredentialsOnCard = true, shareCredentials = true)

        assertEquals("Md. Mazharul Islam, MBA, CIPS, PMP", BusinessCardProfileHelper.formatFullNameWithCredentials(card, forSharing = false))

        // Networking profile hides credentials by default; Business includes them
        val bizProjected = SharingProfileManager.applyProfile(card, SharingProfileType.BUSINESS)
        val netProjected = SharingProfileManager.applyProfile(card, SharingProfileType.NETWORKING)
        assertTrue(bizProjected.shareCredentials)
        assertFalse(netProjected.shareCredentials)

        // vCard includes both phones and standard N: suffix when shared
        val vcf = CardShareHelper.toVCardString(bizProjected)
        assertTrue(vcf.contains("FN:Md. Mazharul Islam\\, MBA\\, CIPS\\, PMP"))
        assertTrue(vcf.contains("N:Islam;Md. Mazharul;;;MBA\\, CIPS\\, PMP"))
        assertTrue(vcf.contains("TEL;TYPE=CELL,VOICE:+8801700799353"))
        assertTrue(vcf.contains("TEL;TYPE=WORK,VOICE:+88029562020"))

        val vcfNoCreds = CardShareHelper.toVCardString(netProjected)
        assertFalse(vcfNoCreds.contains("CIPS"))
    }

    @Test
    fun businessCardImportMerge_appliesOnlyUserSelectedFieldsNeverOverwritesBlindly() {
        val current = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            designation = "Manager",
            companyName = "IFIC Bank PLC",
            phone = "+8801700799353",
            email = "old@ificbank.com"
        )
        val frontScan = SavedContactEntity(
            fullName = "Md. Mazharul Islam, MBA, CIPS",
            designation = "Senior Manager",
            companyName = "IFIC Bank PLC",
            phone = "01700799353", // Same number as current -> must NOT create duplicate!
            email = "new@ificbank.com"
        )
        val backScan = SavedContactEntity(
            fullName = "",
            phone = "+88029562020",
            officeAddress = "IFIC Tower, Purana Paltan, Dhaka"
        )

        val imported = BusinessCardProfileHelper.extractFromScannedContacts(frontScan, backScan)
        assertEquals("Md. Mazharul Islam", imported.fullName)
        assertEquals(listOf("MBA", "CIPS"), imported.credentials)

        val diffs = BusinessCardProfileHelper.computeMergeDiffs(current, imported)
        // Name & Company are identical -> must NOT appear in diffs
        assertFalse(diffs.any { it.fieldKey == "FULL_NAME" })
        assertFalse(diffs.any { it.fieldKey == "COMPANY" })
        assertTrue(diffs.any { it.fieldKey == "DESIGNATION" })
        assertTrue(diffs.any { it.fieldKey == "CREDENTIALS" })
        assertTrue(diffs.any { it.fieldKey == "PHONES" })
        assertTrue(diffs.any { it.fieldKey == "EMAIL" })

        // User chooses ONLY Designation & Keep Both phones; keeps existing Email!
        val decisions = mapOf(
            "DESIGNATION" to MergeFieldChoice.USE_SCANNED,
            "PHONES" to MergeFieldChoice.KEEP_BOTH,
            "EMAIL" to MergeFieldChoice.KEEP_CURRENT,
            "CREDENTIALS" to MergeFieldChoice.USE_SCANNED
        )
        val merged = BusinessCardProfileHelper.applyMergeDecisions(current, imported, decisions)
        assertEquals("Senior Manager", merged.designation)
        assertEquals("old@ificbank.com", merged.email) // Protected!
        assertEquals(2, BusinessCardProfileHelper.parsePhoneNumbers(merged).size)
        assertEquals(listOf("MBA", "CIPS"), BusinessCardProfileHelper.parseCredentials(merged).map { it.label })
    }

    @Test
    fun qrImport_handlesVCardMeCardPlainUrlAndBlocksDangerousSchemes() {
        val vcardQr = "BEGIN:VCARD\nVERSION:3.0\nFN:Tariq Hasan, CFA\nN:Hasan;Tariq;;;CFA\nORG:Apex Group\nTEL;TYPE=CELL:+8801711000011\nTEL;TYPE=WORK:+88029998888\nEMAIL:tariq@apex.com\nEND:VCARD"
        val vcardImp = BusinessCardProfileHelper.extractFromQrPayload(vcardQr)
        assertEquals("Tariq Hasan", vcardImp.fullName)
        assertEquals(listOf("CFA"), vcardImp.credentials)
        assertEquals(2, vcardImp.phones.size)
        assertEquals("tariq@apex.com", vcardImp.email)

        // Plain URL must ONLY offer Digital Card Link, never guess Name/Phone/Company
        val urlImp = BusinessCardProfileHelper.extractFromQrPayload("https://1drv.ms/u/s!SampleCard36568")
        assertEquals("https://1drv.ms/u/s!SampleCard36568", urlImp.publicCardUrl)
        assertTrue(urlImp.fullName.isBlank())
        assertTrue(urlImp.phones.isEmpty())

        // Malicious scheme must be blocked cleanly
        val xssImp = BusinessCardProfileHelper.extractFromQrPayload("javascript:alert(1)")
        assertTrue(xssImp.rawWarning.isNotBlank())
        assertTrue(xssImp.publicCardUrl.isBlank())

        // Validation catches missing Name & flags long Name+Credentials overflow
        val invalid = BusinessCardProfileHelper.validateDraft(BusinessCardEntity(fullName = ""))
        assertFalse(invalid.isValid)
        val overflowCard = BusinessCardProfileHelper.applyPhonesAndCredentials(
            BusinessCardEntity(fullName = "Md. Mazharul Islam Chowdhury Executive Name"),
            emptyList(),
            listOf(
                CardCredentialRecord(label = "MBA", displayOrder = 0),
                CardCredentialRecord(label = "CIPS", displayOrder = 1),
                CardCredentialRecord(label = "FCMA", displayOrder = 2),
                CardCredentialRecord(label = "PMP", displayOrder = 3),
                CardCredentialRecord(label = "CDFP", displayOrder = 4)
            )
        )
        val overflowReport = BusinessCardProfileHelper.validateDraft(overflowCard)
        assertTrue(overflowReport.isValid)
        assertTrue(overflowReport.layoutWarnings.isNotEmpty())
    }
}
