package com.cardlink.app.util

import android.content.Context
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.QrProjectEntity
import java.nio.charset.Charset
import java.util.Locale

enum class NfcHardwareState {
    READY,
    DISABLED,
    UNSUPPORTED
}

enum class NfcContentType(val label: String) {
    SHARING_PROFILE("CardLink Sharing Profile"),
    URL("Website / URL"),
    VCARD("vCard / Contact"),
    TEXT("Plain Text"),
    PHONE("Phone"),
    EMAIL("Email"),
    SMS("SMS"),
    LOCATION("Location"),
    DEEP_LINK("CardLink Deep Link"),
    CUSTOM_URI("Custom URI")
}

enum class NfcTagState(val label: String) {
    NDEF_READY("NDEF Ready"),
    NDEF_READ_ONLY("NDEF Read-Only"),
    NDEF_FORMATABLE("NDEF Formattable"),
    PROTECTED_ISO_DEP("Protected / Application-Specific"),
    NON_NDEF("Non-NDEF Tag")
}

enum class NfcClassifiedType(val label: String) {
    WEBSITE("Website"),
    SOCIAL_PROFILE("Social Profile"),
    PLAIN_TEXT("Plain Text"),
    VCARD_CONTACT("Contact / vCard"),
    PHONE("Phone"),
    EMAIL("Email"),
    SMS("SMS"),
    LOCATION("Location"),
    CARDLINK_DEEP_LINK("CardLink Link"),
    MIME_DATA("MIME Data"),
    EXTERNAL_TYPE("External Type"),
    MULTIPLE_RECORDS("Multiple Records"),
    EMPTY("Empty Tag"),
    UNKNOWN_CONTENT("Unknown Content")
}

data class NfcTagInspection(
    val techList: List<String>,
    val nfcForumType: String,
    val tagState: NfcTagState,
    val classifiedType: NfcClassifiedType,
    val isNdefSupported: Boolean,
    val isNdefFormatted: Boolean,
    val isWritable: Boolean,
    val canMakeReadOnly: Boolean,
    val maxSizeBytes: Int,
    val usedBytes: Int,
    val recordCount: Int,
    val parsedRecords: List<Pair<String, String>>,
    val primaryPayload: String,
    val rawUidHex: String = ""
)

sealed class NfcOperationResult {
    data class WriteVerified(val bytesWritten: Int, val maxBytes: Int, val inspection: NfcTagInspection) : NfcOperationResult()
    data class TestTagResult(val matches: Boolean, val inspection: NfcTagInspection) : NfcOperationResult()
    data class ReadSuccess(val inspection: NfcTagInspection) : NfcOperationResult()
    data class ClearedVerified(val inspection: NfcTagInspection) : NfcOperationResult()
    object MadeReadOnly : NfcOperationResult()
    data class CapacityExceeded(val neededBytes: Int, val maxBytes: Int) : NfcOperationResult()
    data class Failure(val message: String) : NfcOperationResult()
}

object NfcStudioEngine {

    fun checkHardwareState(context: Context): NfcHardwareState {
        val adapter = NfcAdapter.getDefaultAdapter(context) ?: return NfcHardwareState.UNSUPPORTED
        return if (adapter.isEnabled) NfcHardwareState.READY else NfcHardwareState.DISABLED
    }

    /**
     * Layer 1 & 2: Technology Detection + NDEF-First Extraction + Safe Fallback.
     * Never attempts to bypass or clone protected ISO-DEP / payment / access cards.
     */
    fun inspectTag(tag: Tag): NfcTagInspection {
        val techs = tag.techList.map { it.substringAfterLast('.') }
        val uidHex = runCatching { tag.id?.joinToString(":") { "%02X".format(it) } ?: "" }.getOrDefault("")
        val forumType = inferNfcForumType(techs)
        val hasIsoDep = techs.any { it.equals("IsoDep", true) }

        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return runCatching {
                ndef.connect()
                val msg = ndef.ndefMessage ?: ndef.cachedNdefMessage
                val used = msg?.toByteArray()?.size ?: 0
                val parsed = parseNdefRecords(msg)
                val classified = classifyNdefRecords(msg, parsed)
                val writable = ndef.isWritable
                val state = if (writable) NfcTagState.NDEF_READY else NfcTagState.NDEF_READ_ONLY
                val inspection = NfcTagInspection(
                    techList = techs,
                    nfcForumType = forumType,
                    tagState = state,
                    classifiedType = classified,
                    isNdefSupported = true,
                    isNdefFormatted = true,
                    isWritable = writable,
                    canMakeReadOnly = ndef.canMakeReadOnly(),
                    maxSizeBytes = ndef.maxSize,
                    usedBytes = used,
                    recordCount = msg?.records?.size ?: 0,
                    parsedRecords = parsed,
                    primaryPayload = parsed.firstOrNull()?.second.orEmpty(),
                    rawUidHex = uidHex
                )
                ndef.close()
                inspection
            }.getOrElse {
                runCatching { ndef.close() }
                NfcTagInspection(
                    techList = techs,
                    nfcForumType = forumType,
                    tagState = if (hasIsoDep) NfcTagState.PROTECTED_ISO_DEP else NfcTagState.NON_NDEF,
                    classifiedType = NfcClassifiedType.UNKNOWN_CONTENT,
                    isNdefSupported = true,
                    isNdefFormatted = true,
                    isWritable = false,
                    canMakeReadOnly = false,
                    maxSizeBytes = 0,
                    usedBytes = 0,
                    recordCount = 0,
                    parsedRecords = emptyList(),
                    primaryPayload = "",
                    rawUidHex = uidHex
                )
            }
        }

        val formatable = NdefFormatable.get(tag)
        val state = when {
            hasIsoDep -> NfcTagState.PROTECTED_ISO_DEP
            formatable != null -> NfcTagState.NDEF_FORMATABLE
            else -> NfcTagState.NON_NDEF
        }
        return NfcTagInspection(
            techList = techs,
            nfcForumType = forumType,
            tagState = state,
            classifiedType = NfcClassifiedType.EMPTY,
            isNdefSupported = formatable != null,
            isNdefFormatted = false,
            isWritable = formatable != null && !hasIsoDep,
            canMakeReadOnly = false,
            maxSizeBytes = 0,
            usedBytes = 0,
            recordCount = 0,
            parsedRecords = emptyList(),
            primaryPayload = "",
            rawUidHex = uidHex
        )
    }

    private fun inferNfcForumType(techs: List<String>): String = when {
        techs.any { it.equals("NfcV", true) } -> "NFC Forum Type 5 (ISO 15693)"
        techs.any { it.equals("IsoDep", true) } -> "NFC Forum Type 4 (ISO-DEP / 14443-4)"
        techs.any { it.equals("NfcF", true) } -> "NFC Forum Type 3 (FeliCa / NFC-F)"
        techs.any { it.equals("MifareUltralight", true) } -> "NFC Forum Type 2 (NFC-A / Ultralight)"
        techs.any { it.equals("MifareClassic", true) } -> "MIFARE Classic (Device-Dependent)"
        techs.any { it.equals("NfcB", true) } -> "ISO 14443-B (NFC-B)"
        techs.any { it.equals("NfcA", true) } -> "NFC Forum Type 2 / NFC-A (ISO 14443-A)"
        else -> "Standard NFC Tag"
    }

    /**
     * Layer 3: Intelligent NDEF Content Classifier.
     */
    private fun classifyNdefRecords(msg: NdefMessage?, parsed: List<Pair<String, String>>): NfcClassifiedType {
        if (msg == null || parsed.isEmpty()) return NfcClassifiedType.EMPTY
        if (parsed.size > 1) return NfcClassifiedType.MULTIPLE_RECORDS
        val (recType, value) = parsed.first()
        val v = value.trim()
        return when {
            recType.contains("vcard", true) || v.startsWith("BEGIN:VCARD", true) -> NfcClassifiedType.VCARD_CONTACT
            v.startsWith("cardlink://", true) -> NfcClassifiedType.CARDLINK_DEEP_LINK
            v.startsWith("tel:", true) -> NfcClassifiedType.PHONE
            v.startsWith("mailto:", true) -> NfcClassifiedType.EMAIL
            v.startsWith("sms:", true) || v.startsWith("smsto:", true) -> NfcClassifiedType.SMS
            v.startsWith("geo:", true) -> NfcClassifiedType.LOCATION
            v.startsWith("http://", true) || v.startsWith("https://", true) -> {
                if (v.contains("linkedin.com", true) || v.contains("facebook.com", true) || v.contains("instagram.com", true) || v.contains("x.com", true)) {
                    NfcClassifiedType.SOCIAL_PROFILE
                } else {
                    NfcClassifiedType.WEBSITE
                }
            }
            recType == "Text" -> NfcClassifiedType.PLAIN_TEXT
            recType.startsWith("MIME") -> NfcClassifiedType.MIME_DATA
            recType.startsWith("External") -> NfcClassifiedType.EXTERNAL_TYPE
            else -> NfcClassifiedType.UNKNOWN_CONTENT
        }
    }

    /**
     * Builds a standards-compliant NdefMessage before arming the physical NFC writer.
     */
    fun buildNdefMessage(
        type: NfcContentType,
        rawInput: String,
        activeCard: BusinessCardEntity? = null,
        sharingProfile: SharingProfileType = SharingProfileType.BUSINESS
    ): Result<NdefMessage> = runCatching {
        val record = when (type) {
            NfcContentType.SHARING_PROFILE -> {
                val card = activeCard ?: error("No active CardLink profile available.")
                val projected = SharingProfileManager.applyProfile(card, sharingProfile)
                val url = projected.resolveNfcShareUrl().trim()
                if (url.startsWith("https://", true) || url.startsWith("http://", true)) {
                    NdefRecord.createUri(url)
                } else {
                    val vcf = CardShareHelper.toVCardString(projected)
                    NdefRecord.createMime("text/vcard", vcf.toByteArray(Charsets.UTF_8))
                }
            }
            NfcContentType.URL -> {
                val u = rawInput.trim()
                require(u.startsWith("https://", true) || u.startsWith("http://", true)) {
                    "Enter a valid URL starting with https:// or http://."
                }
                NdefRecord.createUri(u)
            }
            NfcContentType.VCARD -> {
                val card = activeCard ?: error("No active CardLink profile available.")
                val projected = SharingProfileManager.applyProfile(card, sharingProfile)
                val vcf = CardShareHelper.toVCardString(projected)
                NdefRecord.createMime("text/vcard", vcf.toByteArray(Charsets.UTF_8))
            }
            NfcContentType.TEXT -> {
                val t = rawInput.trim()
                require(t.isNotBlank()) { "Enter text content to write." }
                NdefRecord.createTextRecord(Locale.getDefault().language.ifBlank { "en" }, t)
            }
            NfcContentType.PHONE -> {
                val p = rawInput.trim()
                require(p.any { it.isDigit() }) { "Enter a valid phone number." }
                NdefRecord.createUri(if (p.startsWith("tel:", true)) p else "tel:$p")
            }
            NfcContentType.EMAIL -> {
                val e = rawInput.trim()
                require(e.contains("@")) { "Enter a valid email address." }
                NdefRecord.createUri(if (e.startsWith("mailto:", true)) e else "mailto:$e")
            }
            NfcContentType.SMS -> {
                val s = rawInput.trim()
                require(s.any { it.isDigit() }) { "Enter a valid phone number for SMS." }
                NdefRecord.createUri(if (s.startsWith("sms:", true)) s else "sms:$s")
            }
            NfcContentType.LOCATION -> {
                val loc = rawInput.trim()
                require(loc.isNotBlank()) { "Enter coordinates (e.g. 23.7808,90.4192) or a map link." }
                val uri = if (loc.startsWith("geo:", true) || loc.startsWith("https://", true)) loc else "geo:$loc"
                NdefRecord.createUri(uri)
            }
            NfcContentType.DEEP_LINK -> {
                val path = rawInput.trim().ifBlank { "share" }
                val uri = if (path.startsWith("cardlink://", true)) path else "cardlink://$path"
                NdefRecord.createUri(uri)
            }
            NfcContentType.CUSTOM_URI -> {
                val u = rawInput.trim()
                require(u.contains(":") && !u.startsWith("javascript:", true)) { "Enter a valid supported URI." }
                NdefRecord.createUri(u)
            }
        }
        NdefMessage(arrayOf(record))
    }

    /**
     * Converts compatible NFC content directly into a QR Code Studio project for QR Fallback.
     */
    fun toQrProject(
        name: String,
        type: NfcContentType,
        rawInput: String,
        activeCard: BusinessCardEntity? = null,
        sharingProfile: SharingProfileType = SharingProfileType.BUSINESS
    ): QrProjectEntity? {
        val (qrType, payload, fields) = when (type) {
            NfcContentType.SHARING_PROFILE, NfcContentType.VCARD -> {
                val card = activeCard ?: return null
                val proj = SharingProfileManager.applyProfile(card, sharingProfile)
                val vcf = CardShareHelper.toVCardString(proj)
                Triple(QrContentType.VCARD.name, vcf, mapOf("name" to proj.fullName, "phone" to proj.phone, "email" to proj.email))
            }
            NfcContentType.URL, NfcContentType.DEEP_LINK, NfcContentType.CUSTOM_URI -> {
                val u = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.URL.name, u, mapOf("url" to u))
            }
            NfcContentType.TEXT -> {
                val t = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.TEXT.name, t, mapOf("text" to t))
            }
            NfcContentType.PHONE -> {
                val p = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.PHONE.name, if (p.startsWith("tel:", true)) p else "tel:$p", mapOf("phone" to p))
            }
            NfcContentType.EMAIL -> {
                val e = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.EMAIL.name, if (e.startsWith("mailto:", true)) e else "mailto:$e", mapOf("email" to e))
            }
            NfcContentType.SMS -> {
                val s = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.SMS.name, if (s.startsWith("sms:", true)) s else "sms:$s", mapOf("phone" to s))
            }
            NfcContentType.LOCATION -> {
                val loc = rawInput.trim().ifBlank { return null }
                Triple(QrContentType.LOCATION.name, if (loc.startsWith("geo:", true)) loc else "geo:$loc", mapOf("query" to loc))
            }
        }
        return QrProjectEntity(
            name = name.ifBlank { type.label },
            qrType = qrType,
            payload = payload,
            contentFieldsJson = QrPayloadBuilder.serializeFields(fields)
        )
    }

    /**
     * End-to-End Test Tag: re-reads the physical tag and verifies byte-for-byte match against [expectedMessage].
     */
    fun testTagAgainstExpected(tag: Tag, expectedMessage: NdefMessage): NfcOperationResult {
        val expectedBytes = expectedMessage.toByteArray()
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return runCatching {
                ndef.connect()
                val actual = ndef.ndefMessage
                val matches = actual != null && actual.toByteArray().contentEquals(expectedBytes)
                ndef.close()
                NfcOperationResult.TestTagResult(matches, inspectTag(tag))
            }.getOrElse {
                runCatching { ndef.close() }
                NfcOperationResult.Failure("Could not read tag during test. Hold steady and try again.")
            }
        }
        return NfcOperationResult.Failure("Tag does not contain readable NDEF content.")
    }

    /**
     * Write -> Read Back -> Exact Byte-for-Byte Verification.
     * Never reports success unless read-back verification matches exactly.
     */
    fun writeAndVerifyTag(
        context: Context,
        tag: Tag,
        message: NdefMessage,
        onStageChanged: (String) -> Unit = {}
    ): NfcOperationResult {
        val expectedBytes = message.toByteArray()
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return try {
                ndef.connect()
                if (!ndef.isWritable) {
                    ndef.close()
                    return NfcOperationResult.Failure("This Tag Is Read-Only: CardLink can read this NFC tag, but it cannot be rewritten.")
                }
                if (expectedBytes.size > ndef.maxSize) {
                    val max = ndef.maxSize
                    ndef.close()
                    return NfcOperationResult.CapacityExceeded(expectedBytes.size, max)
                }
                onStageChanged("WRITING")
                ndef.writeNdefMessage(message)
                onStageChanged("VERIFYING")
                val readBack = ndef.ndefMessage
                val max = ndef.maxSize
                val verified = readBack != null && readBack.toByteArray().contentEquals(expectedBytes)
                ndef.close()
                val inspection = inspectTag(tag)

                if (verified) {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_WRITTEN", "NFC", true, "NFC tag written and verified (${expectedBytes.size} bytes)")
                    NfcOperationResult.WriteVerified(expectedBytes.size, max, inspection)
                } else {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_VERIFY_FAILED", "NFC", false, "Read-back verification mismatch")
                    NfcOperationResult.Failure("NFC Tag Moved Too Soon: Hold the tag against your phone until CardLink finishes verification.")
                }
            } catch (_: Exception) {
                runCatching { ndef.close() }
                NfcOperationResult.Failure("NFC Write Interrupted: Keep the tag near your phone and try again.")
            }
        }

        val formatable = NdefFormatable.get(tag)
        if (formatable != null) {
            return try {
                onStageChanged("WRITING")
                formatable.connect()
                formatable.format(message)
                formatable.close()

                onStageChanged("VERIFYING")
                val exactVerified = runCatching {
                    val formattedNdef = Ndef.get(tag)
                    if (formattedNdef != null) {
                        formattedNdef.connect()
                        val readBack = formattedNdef.ndefMessage
                        formattedNdef.close()
                        readBack != null && readBack.toByteArray().contentEquals(expectedBytes)
                    } else {
                        false
                    }
                }.getOrDefault(false)
                val inspection = inspectTag(tag)
                if (exactVerified) {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_WRITTEN", "NFC", true, "Formatted and verified (${expectedBytes.size} bytes)")
                    NfcOperationResult.WriteVerified(expectedBytes.size, inspection.maxSizeBytes, inspection)
                } else {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_VERIFY_FAILED", "NFC", false, "Formatted tag read-back verification mismatch")
                    NfcOperationResult.Failure("Tag formatted, but read-back verification could not confirm exact bytes. Hold steady and try again.")
                }
            } catch (_: Exception) {
                runCatching { formatable.close() }
                NfcOperationResult.Failure("Could not format NFC tag. Ensure it is an NDEF-compatible tag.")
            }
        }

        return NfcOperationResult.Failure("Unsupported NFC tag technology. Use an NFC Forum-compatible NDEF tag.")
    }

    fun clearTagAndVerify(context: Context, tag: Tag): NfcOperationResult {
        val emptyMsg = NdefMessage(arrayOf(NdefRecord(NdefRecord.TNF_EMPTY, ByteArray(0), ByteArray(0), ByteArray(0))))
        val res = writeAndVerifyTag(context, tag, emptyMsg)
        return when (res) {
            is NfcOperationResult.WriteVerified -> {
                SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_CLEARED", "NFC", true, "NFC tag cleared and verified")
                NfcOperationResult.ClearedVerified(res.inspection)
            }
            else -> res
        }
    }

    fun makeTagReadOnly(context: Context, tag: Tag): NfcOperationResult {
        val ndef = Ndef.get(tag) ?: return NfcOperationResult.Failure("Tag does not support NDEF read-only locking.")
        return try {
            ndef.connect()
            if (!ndef.canMakeReadOnly()) {
                ndef.close()
                return NfcOperationResult.Failure("This NFC tag does not support permanent read-only locking.")
            }
            val ok = ndef.makeReadOnly()
            ndef.close()
            if (ok) {
                SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_LOCKED", "NFC", true, "NFC tag made permanently read-only")
                NfcOperationResult.MadeReadOnly
            } else {
                NfcOperationResult.Failure("Could not lock this NFC tag.")
            }
        } catch (_: Exception) {
            runCatching { ndef.close() }
            NfcOperationResult.Failure("Connection lost while locking tag.")
        }
    }

    private fun parseNdefRecords(message: NdefMessage?): List<Pair<String, String>> {
        if (message == null) return emptyList()
        return message.records.mapNotNull { rec ->
            when (rec.tnf) {
                NdefRecord.TNF_EMPTY -> null
                NdefRecord.TNF_WELL_KNOWN -> {
                    if (rec.type.contentEquals(NdefRecord.RTD_URI)) {
                        "URI" to (rec.toUri()?.toString() ?: "")
                    } else if (rec.type.contentEquals(NdefRecord.RTD_TEXT)) {
                        val payload = rec.payload
                        if (payload.isEmpty()) "Text" to ""
                        else {
                            val encoding = if ((payload[0].toInt() and 128) == 0) Charsets.UTF_8 else Charset.forName("UTF-16")
                            val langLen = payload[0].toInt() and 63
                            "Text" to String(payload, langLen + 1, (payload.size - langLen - 1).coerceAtLeast(0), encoding)
                        }
                    } else {
                        "Well-Known" to String(rec.payload, Charsets.UTF_8)
                    }
                }
                NdefRecord.TNF_MIME_MEDIA -> {
                    val mime = String(rec.type, Charsets.US_ASCII)
                    "MIME ($mime)" to String(rec.payload, Charsets.UTF_8)
                }
                NdefRecord.TNF_EXTERNAL_TYPE -> {
                    val ext = String(rec.type, Charsets.US_ASCII)
                    "External ($ext)" to String(rec.payload, Charsets.UTF_8)
                }
                NdefRecord.TNF_ABSOLUTE_URI -> "URI" to String(rec.type, Charsets.UTF_8)
                else -> "Record (TNF ${rec.tnf})" to String(rec.payload, Charsets.UTF_8)
            }
        }
    }
}
