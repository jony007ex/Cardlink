package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import com.cardlink.app.widget.CardLinkGlanceWidget

sealed class ValidatedInboundDestination {
    data class SafeRoute(val route: String, val requiresAuth: Boolean = false) : ValidatedInboundDestination()
    data class ShareIntake(val payload: IncomingSharePayload) : ValidatedInboundDestination()
    data class Blocked(val reason: String) : ValidatedInboundDestination()
    object DefaultLaunch : ValidatedInboundDestination()
}

/**
 * Centralized Security Gateway for ALL external inbound requests:
 * - cardlink:// deep links
 * - Android Share Target (ACTION_SEND / ACTION_SEND_MULTIPLE)
 * - App Shortcuts, Widgets & Notifications
 * Validates scheme, route, UUID format, MIME/content headers, file size, and Privacy/Panic Mode.
 */
object ExternalIntentGateway {
    private val SAFE_UUID_REGEX = Regex("^[a-fA-F0-9\\-]{8,64}$")
    private val SAFE_CONTACT_ROUTE_REGEX = Regex("^(meeting_brief|contact_detail)/[1-9][0-9]{0,18}$")
    val ALLOWED_PUBLIC_ROUTES = setOf(
        "home", "share", "scan_qr", "scan_ocr", "contacts", "contacts_import",
        "followups", "calendar", "calendar_new", "tools", "qr_studio", "nfc_studio",
        "qr_screen", "quick_nfc_qr_share", "nfc_share_iphone"
    )
    private val SENSITIVE_ROUTES = setOf(
        "my_ids", "loyalty_cards", "secure_notes", "menu_backup_export",
        "menu_privacy", "recycle_bin", "expiry_center"
    )
    private const val MAX_IMPORT_FILE_BYTES = 25L * 1024L * 1024L // 25 MB safety cap

    fun isRouteAllowedFromExternal(route: String): Boolean {
        val canonical = if (route == "followups") "calendar" else route
        return canonical in ALLOWED_PUBLIC_ROUTES ||
            canonical in SENSITIVE_ROUTES ||
            SAFE_CONTACT_ROUTE_REGEX.matches(canonical)
    }

    fun resolveInboundIntent(context: Context, intent: Intent?): ValidatedInboundDestination {
        if (intent == null) return ValidatedInboundDestination.DefaultLaunch
        val hideSensitive = SecurityHardeningManager.isSensitiveAreaHidden(context)

        // 1. Android Share Target (ACTION_SEND / ACTION_SEND_MULTIPLE)
        val sharePayload = ShareIntentExtractor.extract(intent)
        if (sharePayload != null) {
            // Validate every attached URI before accepting
            val validUris = sharePayload.uris.filter { validateInboundFileUri(context, it) }
            if (sharePayload.uris.isNotEmpty() && validUris.isEmpty()) {
                SecurityHardeningManager.logAuditEventAsync(context, "SHARE_INPUT_REJECTED", "Security", false, "Malformed or oversized shared file blocked")
                return ValidatedInboundDestination.Blocked("The shared file could not be read or exceeds safety limits.")
            }
            return ValidatedInboundDestination.ShareIntake(sharePayload.copy(uris = validUris))
        }

        // 2. cardlink:// Deep Links
        val dataUri = intent.data
        if (dataUri != null && dataUri.scheme.equals("cardlink", ignoreCase = true)) {
            return validateCardLinkDeepLink(context, dataUri, hideSensitive)
        }

        // 3. Notification ID Expiry Deep Link
        val notifIdUuid = intent.getStringExtra(IdExpiryReminderScheduler.EXTRA_ID_DOC_UUID)?.trim()
        if (!notifIdUuid.isNullOrBlank()) {
            if (!SAFE_UUID_REGEX.matches(notifIdUuid)) {
                SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Malformed ID UUID in notification")
                return ValidatedInboundDestination.Blocked("Invalid document reference.")
            }
            if (hideSensitive) {
                SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Protected deep link blocked in Privacy Mode")
                return ValidatedInboundDestination.Blocked("Protected area is hidden while Privacy Mode is active.")
            }
            return ValidatedInboundDestination.SafeRoute("my_id_detail/$notifIdUuid", requiresAuth = true)
        }

        // 4. NFC NDEF Discovered
        if (intent.action == NfcAdapter.ACTION_NDEF_DISCOVERED) {
            return ValidatedInboundDestination.SafeRoute("contacts", requiresAuth = false)
        }

        // 5. App Shortcuts & Widgets
        val requestedRoute = intent.getStringExtra("open_route")?.trim()
            ?: intent.getStringExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE)?.trim()

        if (!requestedRoute.isNullOrBlank()) {
            val canonicalRoute = if (requestedRoute == "followups") "calendar" else requestedRoute
            return when {
                canonicalRoute in ALLOWED_PUBLIC_ROUTES -> ValidatedInboundDestination.SafeRoute(canonicalRoute, requiresAuth = false)
                SAFE_CONTACT_ROUTE_REGEX.matches(canonicalRoute) -> ValidatedInboundDestination.SafeRoute(canonicalRoute, requiresAuth = false)
                canonicalRoute in SENSITIVE_ROUTES -> {
                    if (hideSensitive) {
                        SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Protected shortcut blocked in Privacy Mode")
                        ValidatedInboundDestination.Blocked("Protected area is hidden while Privacy Mode is active.")
                    } else {
                        ValidatedInboundDestination.SafeRoute(canonicalRoute, requiresAuth = true)
                    }
                }
                else -> {
                    SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Unrecognized external route rejected")
                    ValidatedInboundDestination.DefaultLaunch
                }
            }
        }

        return ValidatedInboundDestination.DefaultLaunch
    }

    private fun validateCardLinkDeepLink(context: Context, uri: Uri, hideSensitive: Boolean): ValidatedInboundDestination {
        val host = uri.host.orEmpty().lowercase()
        val segs = uri.pathSegments.orEmpty()
        return when (host) {
            "myids", "my_ids" -> {
                if (hideSensitive) {
                    SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Protected deep link blocked")
                    return ValidatedInboundDestination.Blocked("My IDs is hidden while Privacy Mode is active.")
                }
                val uuid = segs.firstOrNull().orEmpty()
                if (uuid.isNotBlank() && SAFE_UUID_REGEX.matches(uuid)) {
                    ValidatedInboundDestination.SafeRoute("my_id_detail/$uuid", requiresAuth = true)
                } else {
                    ValidatedInboundDestination.SafeRoute("my_ids", requiresAuth = true)
                }
            }
            "home" -> ValidatedInboundDestination.SafeRoute("home", requiresAuth = false)
            "contacts" -> ValidatedInboundDestination.SafeRoute("contacts", requiresAuth = false)
            "calendar", "followups" -> ValidatedInboundDestination.SafeRoute("calendar", requiresAuth = false)
            "share" -> ValidatedInboundDestination.SafeRoute("share", requiresAuth = false)
            "scan", "scan_qr" -> ValidatedInboundDestination.SafeRoute("scan_qr", requiresAuth = false)
            "qr", "qr_studio" -> ValidatedInboundDestination.SafeRoute("qr_studio", requiresAuth = false)
            "nfc", "nfc_studio" -> ValidatedInboundDestination.SafeRoute("nfc_studio", requiresAuth = false)
            else -> {
                SecurityHardeningManager.logAuditEventAsync(context, "DEEP_LINK_BLOCKED", "Security", false, "Unsupported cardlink:// route")
                ValidatedInboundDestination.DefaultLaunch
            }
        }
    }

    /**
     * Validates an inbound content URI by checking actual readable content, non-zero length,
     * maximum size cap, and basic magic-byte signatures (never trusts extension alone).
     */
    fun validateInboundFileUri(context: Context, uri: Uri): Boolean {
        val scheme = uri.scheme.orEmpty().lowercase()
        if (scheme != "content" && scheme != "file") return false
        return runCatching {
            val afd = context.contentResolver.openAssetFileDescriptor(uri, "r")
            val declaredLen = afd?.length ?: -1L
            afd?.close()
            if (declaredLen == 0L || declaredLen > MAX_IMPORT_FILE_BYTES) return false

            context.contentResolver.openInputStream(uri)?.use { stream ->
                val header = ByteArray(16)
                val read = stream.read(header)
                if (read <= 0) return false
                // Check safe headers: JPEG (FF D8), PNG (89 50 4E 47), WEBP (RIFF), PDF (%PDF), or text/vCard
                val isJpeg = read >= 2 && header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte()
                val isPng = read >= 4 && header[0] == 0x89.toByte() && header[1] == 'P'.code.toByte() && header[2] == 'N'.code.toByte() && header[3] == 'G'.code.toByte()
                val isPdf = read >= 4 && header[0] == '%'.code.toByte() && header[1] == 'P'.code.toByte() && header[2] == 'D'.code.toByte() && header[3] == 'F'.code.toByte()
                val isWebp = read >= 4 && header[0] == 'R'.code.toByte() && header[1] == 'I'.code.toByte() && header[2] == 'F'.code.toByte() && header[3] == 'F'.code.toByte()
                val isVcard = String(header, 0, read, Charsets.UTF_8).trimStart().startsWith("BEGIN:VCARD", ignoreCase = true)
                isJpeg || isPng || isPdf || isWebp || isVcard
            } ?: false
        }.getOrDefault(false)
    }
}
