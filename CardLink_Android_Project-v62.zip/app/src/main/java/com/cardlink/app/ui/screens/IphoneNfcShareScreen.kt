package com.cardlink.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.util.*

private enum class IphoneNfcWriteStage {
    IDLE,
    READY,
    TAG_DETECTED,
    WRITING,
    VERIFYING,
    VERIFIED_SUCCESS,
    FAILED
}

private tailrec fun Context.findIphoneNfcActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findIphoneNfcActivity()
    else -> null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IphoneNfcShareScreen(
    activeCard: BusinessCardEntity,
    nfcReaderManager: NfcReaderManager,
    onSaveCard: (BusinessCardEntity) -> Unit,
    onManageSharingProfiles: () -> Unit = {},
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val activity = remember(context) { context.findIphoneNfcActivity() }

    // Canonical Sharing Profile state
    var selectedProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    val effectiveCard = remember(activeCard, selectedProfile) {
        SharingProfileManager.applyProfile(activeCard, selectedProfile)
    }

    // Simplified Top-Level Choice: Digital Card (Recommended default) | Call | Email
    var selectedAction by remember { mutableStateOf(IphoneNfcActionType.PROFILE_LINK) }
    var storedCardUrl by remember(activeCard.publicCardUrl) { mutableStateOf(activeCard.resolveNfcShareUrl()) }
    var showFullUrl by remember { mutableStateOf(false) }
    var showEditUrlDialog by remember { mutableStateOf(false) }

    // Progressive Disclosure UI states
    var showProfileSheet by remember { mutableStateOf(false) }
    var showPrivacyReview by remember { mutableStateOf(false) }
    var showCompatDetailsSheet by remember { mutableStateOf(false) }
    var showTechnicalDetails by remember { mutableStateOf(false) }
    var showNfcHelpDialog by remember { mutableStateOf(false) }
    var showOfflineQrExpanded by remember { mutableStateOf(false) }

    // Compatibility preference (Android Contact Compatibility)
    var androidCompatEnabled by remember { mutableStateOf(true) }

    // State-Aware Physical NFC Tag Write & Verify flow
    var writeStage by remember { mutableStateOf(IphoneNfcWriteStage.IDLE) }
    var writeStatusMessage by remember { mutableStateOf("") }
    var verifiedBytesCount by remember { mutableIntStateOf(0) }

    val urlValidation = remember(storedCardUrl) {
        IphoneNfcShareHelper.validateDigitalCardUrlLocally(storedCardUrl)
    }

    val activePayloadSpec = remember(effectiveCard, selectedAction, storedCardUrl, urlValidation) {
        if (selectedAction == IphoneNfcActionType.PROFILE_LINK) {
            IphoneNfcPayloadSpec(
                actionType = IphoneNfcActionType.PROFILE_LINK,
                uriString = storedCardUrl.trim(),
                isAvailable = urlValidation.isValid,
                requiresInternetOnIphone = true
            )
        } else {
            IphoneNfcShareHelper.buildUriForAction(effectiveCard, selectedAction)
        }
    }

    val vcardPayload = remember(effectiveCard) { CardShareHelper.toVCardString(effectiveCard) }
    val privacyItems = remember(effectiveCard, selectedAction, androidCompatEnabled) { IphoneNfcShareHelper.buildPrivacyPreviewItems(effectiveCard, selectedAction, androidCompatEnabled) }
    val sharedFieldsCount = remember(privacyItems) { privacyItems.count { it.isShared } }
    val profileSummaryLine = remember(effectiveCard) { IphoneNfcShareHelper.buildProfileSummaryLine(effectiveCard) }

    val preparedNdefResult = remember(activePayloadSpec, vcardPayload, androidCompatEnabled) {
        if (activePayloadSpec.isAvailable) {
            IphoneNfcShareHelper.buildStandardsFirstNdefMessage(
                primaryUri = activePayloadSpec.uriString,
                vcardPayload = vcardPayload,
                includeAndroidCompatVcard = androidCompatEnabled
            )
        } else {
            Result.failure(IllegalArgumentException("Payload unavailable"))
        }
    }
    val estimatedNdefBytes = remember(preparedNdefResult) {
        preparedNdefResult.getOrNull()?.toByteArray()?.size ?: 0
    }

    val isWritingArmed = writeStage == IphoneNfcWriteStage.READY ||
        writeStage == IphoneNfcWriteStage.TAG_DETECTED ||
        writeStage == IphoneNfcWriteStage.WRITING ||
        writeStage == IphoneNfcWriteStage.VERIFYING

    // Unconditionally restore standard HCE mode when leaving Share to iPhone (even if armed!)
    DisposableEffect(Unit) {
        onDispose {
            CardLinkHceService.shareMode = NfcShareMode.VCARD
            CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(effectiveCard)
        }
    }

    // Keep background HCE synced in IPHONE_SHARE mode when NOT writing a physical tag
    LaunchedEffect(activePayloadSpec, vcardPayload, androidCompatEnabled, isWritingArmed) {
        if (!isWritingArmed) {
            if (activePayloadSpec.isAvailable) {
                CardLinkHceService.shareMode = NfcShareMode.IPHONE_SHARE
                CardLinkHceService.activeIphoneUri = activePayloadSpec.uriString
                CardLinkHceService.includeSecondaryVcardOnIphone = androidCompatEnabled
                CardLinkHceService.activeVCardPayload = vcardPayload
            }
            nfcReaderManager.disableReaderMode()
        }
    }

    // Real State-Aware Physical NFC Tag Write & Read-Back Verification using NfcAdapter.enableReaderMode
    DisposableEffect(isWritingArmed, activity, preparedNdefResult) {
        val adapter = NfcAdapter.getDefaultAdapter(context)
        val msg = preparedNdefResult.getOrNull()
        if (isWritingArmed && activity != null && adapter != null && adapter.isEnabled && msg != null) {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS

            var handled = false
            adapter.enableReaderMode(activity, { tag ->
                if (handled) return@enableReaderMode
                handled = true
                activity.runOnUiThread { writeStage = IphoneNfcWriteStage.TAG_DETECTED }
                val res = NfcStudioEngine.writeAndVerifyTag(context, tag, msg) { stage ->
                    activity.runOnUiThread {
                        when (stage) {
                            "WRITING" -> writeStage = IphoneNfcWriteStage.WRITING
                            "VERIFYING" -> writeStage = IphoneNfcWriteStage.VERIFYING
                        }
                    }
                }
                activity.runOnUiThread {
                    when (res) {
                        is NfcOperationResult.WriteVerified -> {
                            verifiedBytesCount = res.bytesWritten
                            writeStatusMessage = context.getString(R.string.iphone_nfc_verified_detail, res.bytesWritten, res.maxBytes)
                            writeStage = IphoneNfcWriteStage.VERIFIED_SUCCESS
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        is NfcOperationResult.CapacityExceeded -> {
                            writeStatusMessage = context.getString(R.string.iphone_nfc_capacity_err, res.neededBytes, res.maxBytes)
                            writeStage = IphoneNfcWriteStage.FAILED
                        }
                        is NfcOperationResult.Failure -> {
                            writeStatusMessage = res.message
                            writeStage = IphoneNfcWriteStage.FAILED
                        }
                        else -> {
                            writeStatusMessage = context.getString(R.string.iphone_nfc_write_generic_err)
                            writeStage = IphoneNfcWriteStage.FAILED
                        }
                    }
                }
            }, flags, null)
        }
        onDispose {
            if (activity != null && adapter != null) {
                runCatching { adapter.disableReaderMode(activity) }
            }
        }
    }

    // Shared CardLink QR Engine (rendered lazily only when Offline Contact QR is expanded!)
    val offlineContactQr = remember(vcardPayload, showOfflineQrExpanded) {
        if (showOfflineQrExpanded) CardShareHelper.generateQrCodeBitmap(vcardPayload, 680) else null
    }

    val isFullStandardCompat = activePayloadSpec.isAvailable &&
        (selectedAction != IphoneNfcActionType.PROFILE_LINK || urlValidation.isHttps)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.nfc_share_iphone_title), fontWeight = FontWeight.Bold)
                        Text(
                            text = stringResource(R.string.iphone_share_clean_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. READY FOR IPHONE (Simple visual + concise placement guidance + NFC Help)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val accent = MaterialTheme.colorScheme.primary
                    val muted = MaterialTheme.colorScheme.onSurfaceVariant
                    Canvas(modifier = Modifier.size(56.dp)) {
                        // NFC tag circle
                        drawCircle(
                            color = accent.copy(alpha = 0.18f),
                            radius = size.minDimension * 0.28f,
                            center = Offset(size.width * 0.28f, size.height * 0.64f)
                        )
                        drawCircle(
                            color = accent,
                            radius = size.minDimension * 0.20f,
                            center = Offset(size.width * 0.28f, size.height * 0.64f),
                            style = Stroke(width = 3f)
                        )
                        // iPhone silhouette with top area highlighted near tag
                        drawRoundRect(
                            color = muted.copy(alpha = 0.7f),
                            topLeft = Offset(size.width * 0.44f, size.height * 0.14f),
                            size = Size(size.width * 0.44f, size.height * 0.74f),
                            cornerRadius = CornerRadius(10f, 10f),
                            style = Stroke(width = 3.5f)
                        )
                        drawRoundRect(
                            color = accent.copy(alpha = 0.35f),
                            topLeft = Offset(size.width * 0.46f, size.height * 0.16f),
                            size = Size(size.width * 0.40f, size.height * 0.18f),
                            cornerRadius = CornerRadius(8f, 8f)
                        )
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = stringResource(R.string.iphone_ready_header),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.iphone_ready_guidance),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = { showNfcHelpDialog = true },
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 44.dp)
                    ) {
                        Text(stringResource(R.string.iphone_nfc_help_btn), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // 2. COMPACT SHARING PROFILE SELECTOR (Opens Bottom Sheet)
            val profileA11y = "${stringResource(R.string.iphone_sharing_profile_title)}: ${selectedProfile.label}"
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = profileA11y }
                    .clickable(role = Role.Button) { showProfileSheet = true },
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.iphone_sharing_profile_title),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = profileSummaryLine,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = selectedProfile.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // 3. WHAT SHOULD OPEN? (3 Clean Choices: Digital Card [Recommended] | Call | Email)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.iphone_what_should_open_title),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    val callSpec = remember(effectiveCard) { IphoneNfcShareHelper.buildUriForAction(effectiveCard, IphoneNfcActionType.PHONE_CALL) }
                    val emailSpec = remember(effectiveCard) { IphoneNfcShareHelper.buildUriForAction(effectiveCard, IphoneNfcActionType.EMAIL) }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IphoneChoiceTile(
                            icon = Icons.Default.Language,
                            label = stringResource(R.string.iphone_choice_digital_card),
                            badge = stringResource(R.string.iphone_choice_recommended),
                            isSelected = selectedAction == IphoneNfcActionType.PROFILE_LINK,
                            enabled = true,
                            onClick = { selectedAction = IphoneNfcActionType.PROFILE_LINK },
                            modifier = Modifier.weight(1.3f)
                        )
                        IphoneChoiceTile(
                            icon = Icons.Default.Call,
                            label = stringResource(R.string.detail_call),
                            badge = null,
                            isSelected = selectedAction == IphoneNfcActionType.PHONE_CALL,
                            enabled = callSpec.isAvailable,
                            onClick = { selectedAction = IphoneNfcActionType.PHONE_CALL },
                            modifier = Modifier.weight(0.85f)
                        )
                        IphoneChoiceTile(
                            icon = Icons.Default.Email,
                            label = stringResource(R.string.detail_email),
                            badge = null,
                            isSelected = selectedAction == IphoneNfcActionType.EMAIL,
                            enabled = emailSpec.isAvailable,
                            onClick = { selectedAction = IphoneNfcActionType.EMAIL },
                            modifier = Modifier.weight(0.85f)
                        )
                    }

                    // Contextual description after selection (clean, non-technical)
                    Text(
                        text = when (selectedAction) {
                            IphoneNfcActionType.PROFILE_LINK -> stringResource(R.string.iphone_digital_card_desc)
                            IphoneNfcActionType.PHONE_CALL -> stringResource(R.string.iphone_call_contextual_desc, activePayloadSpec.uriString.removePrefix("tel:"))
                            IphoneNfcActionType.EMAIL -> stringResource(R.string.iphone_email_contextual_desc, activePayloadSpec.uriString.removePrefix("mailto:"))
                            else -> ""
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 4. SIMPLIFIED DIGITAL CARD LINK (Shortened display + Test Link | Edit)
            if (selectedAction == IphoneNfcActionType.PROFILE_LINK) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f).clickable { showFullUrl = !showFullUrl }) {
                                Text(
                                    text = stringResource(R.string.iphone_digital_card_link_lbl),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (showFullUrl) storedCardUrl else IphoneNfcShareHelper.shortenUrlForDisplay(storedCardUrl),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (urlValidation.isValid) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                                    maxLines = if (showFullUrl) 4 else 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = {
                                        if (urlValidation.isValid) {
                                            runCatching {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storedCardUrl.trim())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                            }.onFailure {
                                                Toast.makeText(context, context.getString(R.string.nfc_iphone_url_invalid), Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            Toast.makeText(context, urlValidation.errorMessage, Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.heightIn(min = 44.dp)
                                ) { Text(stringResource(R.string.iphone_test_link_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                TextButton(
                                    onClick = { showEditUrlDialog = true },
                                    modifier = Modifier.heightIn(min = 44.dp)
                                ) { Text(stringResource(R.string.action_edit), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                        if (!urlValidation.isValid) {
                            Text(urlValidation.errorMessage, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            // 5. PRIVACY PREVIEW ("What Will Be Shared" + Review)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.iphone_privacy_title),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = stringResource(R.string.iphone_privacy_fields_count, sharedFieldsCount),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        TextButton(
                            onClick = { showPrivacyReview = !showPrivacyReview },
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) {
                            Text(
                                text = if (showPrivacyReview) stringResource(R.string.action_close) else stringResource(R.string.qa_review_btn),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    AnimatedVisibility(visible = showPrivacyReview) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            HorizontalDivider()
                            Spacer(Modifier.height(2.dp))
                            privacyItems.forEach { item ->
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = if (item.isShared) "✓" else "○",
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.isShared) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = item.label,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (item.isShared) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 6. COMPATIBILITY SUMMARY + DETAILS (Houses Android Contact Compatibility & Technical Details)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = stringResource(R.string.nfc_compat_label),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (isFullStandardCompat) {
                                stringResource(R.string.iphone_compat_full_row)
                            } else {
                                stringResource(R.string.nfc_compat_limited)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isFullStandardCompat) Color(0xFF10B981) else Color(0xFFF59E0B)
                        )
                    }
                    TextButton(
                        onClick = { showCompatDetailsSheet = true },
                        modifier = Modifier.heightIn(min = 44.dp)
                    ) {
                        Text(stringResource(R.string.iphone_compat_details_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 7. PRIMARY ACTION: WRITE & VERIFY NFC TAG (or Turn On NFC if disabled)
            if (!nfcReaderManager.isNfcSupported()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = stringResource(R.string.nfc_unsupported_title),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else if (!nfcReaderManager.isNfcEnabled()) {
                Button(
                    onClick = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Icon(Icons.Default.Nfc, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.nfc_open_settings_btn), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            } else {
                Button(
                    onClick = {
                        if (!activePayloadSpec.isAvailable) {
                            Toast.makeText(context, urlValidation.errorMessage.ifBlank { "Complete your card details first." }, Toast.LENGTH_LONG).show()
                        } else {
                            writeStatusMessage = ""
                            writeStage = IphoneNfcWriteStage.READY
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Icon(Icons.Default.Contactless, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.iphone_write_verify_btn), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }

            // 8. COLLAPSED OFFLINE BACKUP SECTION (Show Contact QR | Share VCF)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.iphone_offline_backup_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.iphone_offline_backup_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showOfflineQrExpanded = !showOfflineQrExpanded },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.QrCode2, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.iphone_show_contact_qr_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(
                            onClick = { CardShareHelper.shareVCardFile(context, effectiveCard) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.iphone_share_vcf_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }

                    // Expanded Offline Contact QR (uses CardLink's shared QR engine)
                    AnimatedVisibility(visible = showOfflineQrExpanded) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HorizontalDivider()
                            Text(
                                text = stringResource(R.string.iphone_offline_qr_expanded_title),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = stringResource(R.string.iphone_offline_qr_expanded_sub),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            offlineContactQr?.let { bmp ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    shadowElevation = 2.dp
                                ) {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = stringResource(R.string.iphone_offline_qr_expanded_title),
                                        modifier = Modifier.size(210.dp).padding(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // =========================================================================
    // BOTTOM SHEETS & DIALOGS
    // =========================================================================

    // Sharing Profile Selector Bottom Sheet
    if (showProfileSheet) {
        ModalBottomSheet(
            onDismissRequest = { showProfileSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(R.string.iphone_sharing_profile_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                SharingProfileType.values().forEach { prof ->
                    val isSel = selectedProfile == prof
                    Surface(
                        onClick = {
                            selectedProfile = prof
                            SharingProfileManager.setActiveProfile(context, prof)
                            showProfileSheet = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prof.label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(prof.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (isSel) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                TextButton(
                    onClick = {
                        showProfileSheet = false
                        onManageSharingProfiles()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Tune, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.iphone_manage_profiles_btn), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Edit Digital Card Link Dialog (Save Changes only when editing!)
    if (showEditUrlDialog) {
        var draftUrl by remember(storedCardUrl) { mutableStateOf(storedCardUrl) }
        val draftCheck = remember(draftUrl) { IphoneNfcShareHelper.validateDigitalCardUrlLocally(draftUrl) }
        AlertDialog(
            onDismissRequest = { showEditUrlDialog = false },
            title = { Text(stringResource(R.string.iphone_edit_link_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = draftUrl,
                        onValueChange = { draftUrl = it },
                        label = { Text(stringResource(R.string.nfc_iphone_url_lbl)) },
                        singleLine = true,
                        isError = !draftCheck.isValid,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!draftCheck.isValid) {
                        Text(draftCheck.errorMessage, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = draftCheck.isValid,
                    onClick = {
                        val clean = draftUrl.trim()
                        storedCardUrl = clean
                        onSaveCard(activeCard.copy(publicCardUrl = clean))
                        showEditUrlDialog = false
                        Toast.makeText(context, context.getString(R.string.nfc_iphone_url_saved), Toast.LENGTH_SHORT).show()
                    }
                ) { Text(stringResource(R.string.iphone_save_changes_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showEditUrlDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Compatibility & Technical Details Bottom Sheet
    if (showCompatDetailsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCompatDetailsSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.nfc_compat_label), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.iphone_android_compat_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(stringResource(R.string.iphone_android_compat_sub), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = androidCompatEnabled, onCheckedChange = { androidCompatEnabled = it })
                }

                HorizontalDivider()

                TextButton(
                    onClick = { showTechnicalDetails = !showTechnicalDetails },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(stringResource(R.string.iphone_tech_details_btn), fontWeight = FontWeight.SemiBold)
                    Icon(if (showTechnicalDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                }

                AnimatedVisibility(visible = showTechnicalDetails) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("• Record 1 (Primary): Standard NDEF Well-Known URI (${activePayloadSpec.uriString.take(48)})", style = MaterialTheme.typography.labelSmall)
                        if (androidCompatEnabled) {
                            Text("• Record 2 (Compatibility): Secondary vCard NDEF MIME record (text/x-vcard)", style = MaterialTheme.typography.labelSmall)
                        }
                        Text("• Estimated Encoded NDEF Size: $estimatedNdefBytes bytes (UTF-8 + headers)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("• Recommended Tag: NTAG215 (504 B) or NTAG216 (888 B). MIFARE Classic is not supported on iPhone.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    // NFC Help Dialog
    if (showNfcHelpDialog) {
        AlertDialog(
            onDismissRequest = { showNfcHelpDialog = false },
            title = { Text(stringResource(R.string.iphone_nfc_help_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.iphone_nfc_help_body_1), style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.iphone_nfc_help_body_2), style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.iphone_nfc_help_body_3), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { showNfcHelpDialog = false }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // State-Aware Physical NFC Tag Write & Verification Dialog
    if (writeStage != IphoneNfcWriteStage.IDLE) {
        val stageTitle = when (writeStage) {
            IphoneNfcWriteStage.READY -> stringResource(R.string.iphone_nfc_state_ready)
            IphoneNfcWriteStage.TAG_DETECTED -> stringResource(R.string.iphone_nfc_state_detected)
            IphoneNfcWriteStage.WRITING -> stringResource(R.string.iphone_nfc_state_writing)
            IphoneNfcWriteStage.VERIFYING -> stringResource(R.string.iphone_nfc_state_verifying)
            IphoneNfcWriteStage.VERIFIED_SUCCESS -> stringResource(R.string.iphone_nfc_state_success)
            IphoneNfcWriteStage.FAILED -> stringResource(R.string.iphone_nfc_state_failed)
            IphoneNfcWriteStage.IDLE -> ""
        }
        AlertDialog(
            onDismissRequest = { writeStage = IphoneNfcWriteStage.IDLE },
            title = {
                Text(
                    text = stageTitle,
                    fontWeight = FontWeight.Bold,
                    color = when (writeStage) {
                        IphoneNfcWriteStage.VERIFIED_SUCCESS -> Color(0xFF10B981)
                        IphoneNfcWriteStage.FAILED -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.primary
                    }
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (isWritingArmed) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text(
                            text = stringResource(R.string.iphone_nfc_hold_tag_prompt, estimatedNdefBytes),
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else if (writeStage == IphoneNfcWriteStage.VERIFIED_SUCCESS) {
                        Text(writeStatusMessage, style = MaterialTheme.typography.bodySmall)
                    } else if (writeStage == IphoneNfcWriteStage.FAILED) {
                        Text(writeStatusMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                when (writeStage) {
                    IphoneNfcWriteStage.FAILED -> {
                        Button(onClick = { writeStage = IphoneNfcWriteStage.READY }) {
                            Text(stringResource(R.string.qa_try_again_btn))
                        }
                    }
                    IphoneNfcWriteStage.VERIFIED_SUCCESS -> {
                        Button(onClick = { writeStage = IphoneNfcWriteStage.IDLE }) {
                            Text(stringResource(R.string.ocr_done_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> Unit
                }
            },
            dismissButton = {
                if (writeStage == IphoneNfcWriteStage.FAILED) {
                    TextButton(onClick = {
                        writeStage = IphoneNfcWriteStage.IDLE
                        showOfflineQrExpanded = true
                    }) { Text(stringResource(R.string.iphone_show_contact_qr_btn)) }
                } else if (writeStage != IphoneNfcWriteStage.VERIFIED_SUCCESS) {
                    TextButton(onClick = { writeStage = IphoneNfcWriteStage.IDLE }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                }
            }
        )
    }
}

@Composable
private fun IphoneChoiceTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    badge: String?,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val a11yDesc = if (badge != null) "$label ($badge)" else label
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        color = when {
            !enabled -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            isSelected -> MaterialTheme.colorScheme.primary
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        },
        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.28f)),
        modifier = modifier
            .heightIn(min = 74.dp)
            .semantics {
                selected = isSelected
                contentDescription = a11yDesc
            }
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = when {
                    !enabled -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                    isSelected -> MaterialTheme.colorScheme.onPrimary
                    else -> MaterialTheme.colorScheme.primary
                },
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = when {
                    !enabled -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                    isSelected -> MaterialTheme.colorScheme.onPrimary
                    else -> MaterialTheme.colorScheme.onSurface
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (badge != null) {
                Text(
                    text = badge,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f) else MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
