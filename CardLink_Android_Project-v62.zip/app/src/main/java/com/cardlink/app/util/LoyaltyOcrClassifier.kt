package com.cardlink.app.util

enum class LoyaltyNumberConfidence {
    NONE,
    STANDALONE_PROBABLE,
    LABELLED_HIGH
}

data class LoyaltyOcrClassificationResult(
    val suggestedBrand: String = "",
    val suggestedMembershipNumber: String = "",
    val membershipConfidence: LoyaltyNumberConfidence = LoyaltyNumberConfidence.NONE,
    val suggestedCardholder: String = "",
    val suggestedTier: String = "",
    val suggestedExpiryIso: String? = null
)

data class SafeBarcodeFormatOption(
    val formatName: String,
    val displayLabel: String,
    val isRecommended: Boolean
)

/**
 * Pure-JVM Loyalty Card OCR Classifier & Safe Barcode Format Validator.
 * - Prioritizes explicitly labelled English & বাংলা membership/loyalty identifiers.
 * - Rejects false numeric identifiers (phone numbers, expiry/dates, postal codes, hotlines, prices, store IDs).
 * - Preserves strict separation between visible Membership Number and decoded Barcode Payload.
 */
object LoyaltyOcrClassifier {

    private val POSITIVE_LABELS = listOf(
        "membership no", "membership number", "membership id",
        "member no", "member number", "member id", "member #",
        "loyalty no", "loyalty number", "loyalty id",
        "rewards id", "reward id", "rewards no",
        "customer id", "customer no", "client id",
        "card no", "card number", "card id",
        "privilege no", "privilege id", "club id", "club no",
        "account no", "a/c no",
        // Validated Bangla labels
        "মেম্বারশিপ নম্বর", "মেম্বারশিপ নং", "মেম্বার নম্বর", "মেম্বার নং",
        "লয়্যালটি নম্বর", "লয়্যালটি নং", "সদস্য নম্বর", "সদস্য নং",
        "কার্ড নম্বর", "কার্ড নং", "মেম্বার আইডি", "কাস্টমার আইডি"
    )

    private val NEGATIVE_CONTEXT_KEYWORDS = listOf(
        "phone", "mobile", "mob", "tel", "call", "hotline", "helpline", "whatsapp", "fax",
        "exp", "expiry", "expires", "valid", "since", "issued", "dob", "birth", "date",
        "road", "house", "plot", "floor", "sector", "dhaka", "chittagong", "sylhet", "khulna",
        "zip", "postal", "p.o.", "po box", "store", "branch", "outlet", "vat", "bin", "tin",
        "bdt", "tk", "usd", "price", "points", "pts", "discount",
        "ফোন", "মোবাইল", "হটলাইন", "মেয়াদ", "তারিখ", "শাখা", "ঠিকানা", "রোড", "বাড়ি"
    )

    private val TIER_KEYWORDS = listOf(
        "privilege", "platinum", "gold", "silver", "diamond", "titanium",
        "signature", "vip", "elite", "black", "premier", "priority", "classic", "executive"
    )

    private val NON_BRAND_WORDS = setOf(
        "member", "membership", "loyalty", "rewards", "reward", "privilege",
        "customer", "card", "valid", "expiry", "expires", "hotline", "signature",
        "terms", "conditions", "welcome", "points", "club", "authorized"
    )

    private val DATE_PATTERN = Regex("""\b(?:\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}|\d{4}[/\-.]\d{1,2}[/\-.]\d{1,2}|\d{2}/\d{2})\b""")
    private val BD_PHONE_PATTERN = Regex("""^(?:\+?880|0)1[3-9]\d{8}$""")
    private val INTL_PHONE_PATTERN = Regex("""^\+\d{9,15}$""")
    private val TOKEN_CANDIDATE_PATTERN = Regex("""[A-Za-z]{0,4}[\s-]?(?:\d[\s-]?){5,19}""")
    private val PURE_DIGITS_PATTERN = Regex("""\d[\d\s-]{4,22}\d""")

    /**
     * Classifies OCR text lines (each paired with relative bounding-box height for brand inference).
     */
    fun classifyLines(
        linesWithHeight: List<Pair<String, Int>>,
        decodedBarcodeValue: String = ""
    ): LoyaltyOcrClassificationResult {
        if (linesWithHeight.isEmpty()) return LoyaltyOcrClassificationResult()

        val normalizedLines = linesWithHeight.map { (raw, h) ->
            CardOcrPipeline.normalizeUnicodeText(raw) to h
        }.filter { it.first.isNotBlank() }

        // 1. Brand heuristic: prominent text line that is not a label/number/address
        val brandCandidate = normalizedLines
            .filter { (txt, _) ->
                val lower = txt.lowercase()
                txt.length in 2..32 &&
                    txt.count { it.isLetter() } >= 2 &&
                    txt.count { it.isDigit() } <= 2 &&
                    !lower.contains("http") &&
                    !lower.contains("@") &&
                    NON_BRAND_WORDS.none { w -> lower == w || lower.startsWith("$w ") || lower.contains("$w no") || lower.contains("$w id") } &&
                    NEGATIVE_CONTEXT_KEYWORDS.none { nk -> lower.contains(nk) }
            }
            .maxByOrNull { it.second }
            ?.first
            .orEmpty()

        // 2. Tier heuristic
        val tierCandidate = normalizedLines
            .map { it.first }
            .firstOrNull { line ->
                val lower = line.lowercase()
                line.length <= 28 && TIER_KEYWORDS.any { tk -> lower.contains(tk) }
            }
            ?.let { line ->
                TIER_KEYWORDS.firstOrNull { tk -> line.lowercase().contains(tk) }
                    ?.replaceFirstChar { it.uppercase() }
                    .orEmpty()
            }
            .orEmpty()

        // 3. Optional Cardholder heuristic (explicitly labelled)
        var cardholderCandidate = ""
        for (i in normalizedLines.indices) {
            val line = normalizedLines[i].first
            val lower = line.lowercase()
            if (lower.startsWith("name:") || lower.startsWith("member name") || lower.startsWith("cardholder") || lower.startsWith("holder:")) {
                val afterColon = line.substringAfter(":", "").trim()
                if (afterColon.length in 3..40 && afterColon.count { it.isDigit() } == 0) {
                    cardholderCandidate = afterColon
                    break
                } else if (i + 1 < normalizedLines.size) {
                    val nextLine = normalizedLines[i + 1].first.trim()
                    if (nextLine.length in 3..40 && nextLine.count { it.isDigit() } == 0) {
                        cardholderCandidate = nextLine
                        break
                    }
                }
            }
        }

        // 4. Priority 3: Explicitly labelled Membership / Loyalty Number (same-line or next-line)
        var labelledNumber = ""
        for (i in normalizedLines.indices) {
            val line = normalizedLines[i].first
            val asciiLine = CardOcrPipeline.convertBanglaDigitsToAscii(line)
            val lower = asciiLine.lowercase()

            val matchedLabel = POSITIVE_LABELS.firstOrNull { lbl -> lower.contains(lbl) } ?: continue

            // Extract segment right after the matched label
            val idx = lower.indexOf(matchedLabel) + matchedLabel.length
            val tail = asciiLine.substring(idx.coerceAtMost(asciiLine.length))
                .trimStart(' ', ':', '-', '#', '.', '–', '—')

            val fromSameLine = extractCleanIdentifierToken(tail)
            if (fromSameLine != null && !isLikelyFalseIdentifier(fromSameLine, tail)) {
                labelledNumber = fromSameLine
                break
            }

            // Spatial fallback: value printed directly below the label on the next line
            if (i + 1 < normalizedLines.size) {
                val nextAscii = CardOcrPipeline.convertBanglaDigitsToAscii(normalizedLines[i + 1].first)
                if (!hasNegativeContext(nextAscii)) {
                    val fromNextLine = extractCleanIdentifierToken(nextAscii)
                    if (fromNextLine != null && !isLikelyFalseIdentifier(fromNextLine, nextAscii)) {
                        labelledNumber = fromNextLine
                        break
                    }
                }
            }
        }

        if (labelledNumber.isNotBlank()) {
            return LoyaltyOcrClassificationResult(
                suggestedBrand = brandCandidate,
                suggestedMembershipNumber = labelledNumber,
                membershipConfidence = LoyaltyNumberConfidence.LABELLED_HIGH,
                suggestedCardholder = cardholderCandidate,
                suggestedTier = tierCandidate
            )
        }

        // 5. Priority 4: Standalone probable identifier (strictly rejecting phone/date/postal/hotline)
        var standaloneNumber = ""
        var bestScore = Int.MIN_VALUE
        val cleanDecodedBarcode = decodedBarcodeValue.filter { it.isLetterOrDigit() }

        for ((rawLine, _) in normalizedLines) {
            val asciiLine = CardOcrPipeline.convertBanglaDigitsToAscii(rawLine)
            if (hasNegativeContext(asciiLine)) continue
            if (DATE_PATTERN.containsMatchIn(asciiLine)) continue

            for (m in PURE_DIGITS_PATTERN.findAll(asciiLine)) {
                val rawTok = m.value.trim()
                val digitsOnly = rawTok.filter { it.isDigit() }
                if (digitsOnly.length !in 6..19) continue
                if (isLikelyFalseIdentifier(digitsOnly, asciiLine)) continue

                var score = 10
                if (digitsOnly.length in 7..16) score += 10
                if (asciiLine.trim() == rawTok) score += 15 // Clean standalone printed line
                if (cleanDecodedBarcode.isNotBlank() && digitsOnly == cleanDecodedBarcode) score += 20
                if (cleanDecodedBarcode.isNotBlank() && cleanDecodedBarcode.contains(digitsOnly)) score += 12
                if (score > bestScore) {
                    bestScore = score
                    standaloneNumber = digitsOnly
                }
            }
        }

        return LoyaltyOcrClassificationResult(
            suggestedBrand = brandCandidate,
            suggestedMembershipNumber = standaloneNumber,
            membershipConfidence = if (standaloneNumber.isNotBlank()) LoyaltyNumberConfidence.STANDALONE_PROBABLE else LoyaltyNumberConfidence.NONE,
            suggestedCardholder = cardholderCandidate,
            suggestedTier = tierCandidate
        )
    }

    private fun extractCleanIdentifierToken(text: String): String? {
        if (text.isBlank()) return null
        val match = TOKEN_CANDIDATE_PATTERN.find(text) ?: return null
        val cleaned = match.value.replace(" ", "").trim('-')
        val digitCount = cleaned.count { it.isDigit() }
        if (digitCount < 5 || cleaned.length > 22) return null
        return cleaned
    }

    private fun hasNegativeContext(asciiLine: String): Boolean {
        val lower = asciiLine.lowercase()
        return NEGATIVE_CONTEXT_KEYWORDS.any { kw ->
            val idx = lower.indexOf(kw)
            if (idx < 0) false
            else {
                val beforeOk = idx == 0 || !lower[idx - 1].isLetter()
                val afterIdx = idx + kw.length
                val afterOk = afterIdx >= lower.length || !lower[afterIdx].isLetter()
                beforeOk && afterOk
            }
        }
    }

    fun isLikelyFalseIdentifier(candidate: String, surroundingLine: String): Boolean {
        val compact = candidate.filter { it.isDigit() || it == '+' }
        val digits = candidate.filter { it.isDigit() }
        if (digits.length < 5) return true
        if (hasNegativeContext(surroundingLine)) return true
        if (DATE_PATTERN.containsMatchIn(surroundingLine) && digits.length <= 8) return true
        if (BD_PHONE_PATTERN.matches(compact)) return true
        if (INTL_PHONE_PATTERN.matches(compact)) return true
        // Reject 5-digit hotline numbers (16xxx) or 4-digit postal codes
        if (digits.length == 5 && digits.startsWith("16")) return true
        // Reject pure years (1900-2099)
        if (digits.length == 4 && digits.toIntOrNull() in 1900..2099) return true
        return false
    }

    /**
     * Validates GS1 Modulo-10 check digit for EAN-13, EAN-8, and UPC-A.
     */
    fun hasValidGs1CheckDigit(digits: String): Boolean {
        if (digits.any { !it.isDigit() }) return false
        if (digits.length !in setOf(8, 12, 13)) return false
        val body = digits.dropLast(1)
        val expectedCheck = digits.last().digitToInt()
        var sum = 0
        // Weighting from right to left (excluding check digit): 3, 1, 3, 1, ...
        for (i in body.indices) {
            val fromRight = body.length - 1 - i
            val weight = if (fromRight % 2 == 0) 3 else 1
            sum += body[i].digitToInt() * weight
        }
        val computedCheck = (10 - (sum % 10)) % 10
        return computedCheck == expectedCheck
    }

    /**
     * Returns only SAFE, validated barcode symbologies that can encode the given Membership Number
     * without silent guessing or invalid checksum failures.
     */
    fun getSafeBarcodeFormatsForNumber(membershipNumber: String): List<SafeBarcodeFormatOption> {
        val clean = membershipNumber.trim()
        if (clean.isBlank()) return emptyList()
        val allDigits = clean.all { it.isDigit() }
        val options = mutableListOf<SafeBarcodeFormatOption>()

        if (allDigits && clean.length == 13 && hasValidGs1CheckDigit(clean)) {
            options.add(SafeBarcodeFormatOption("EAN_13", "EAN-13 (Verified Checksum)", isRecommended = true))
        }
        if (allDigits && clean.length == 12 && hasValidGs1CheckDigit(clean)) {
            options.add(SafeBarcodeFormatOption("UPC_A", "UPC-A (Verified Checksum)", isRecommended = true))
        }
        if (allDigits && clean.length == 8 && hasValidGs1CheckDigit(clean)) {
            options.add(SafeBarcodeFormatOption("EAN_8", "EAN-8 (Verified Checksum)", isRecommended = true))
        }

        // Code 128 supports all standard ASCII alphanumeric membership numbers reliably
        val isAsciiPrintable = clean.all { it.code in 32..126 }
        if (isAsciiPrintable) {
            options.add(
                SafeBarcodeFormatOption(
                    "CODE_128",
                    "Code 128 (Universal Standard)",
                    isRecommended = options.none { it.isRecommended }
                )
            )
        }

        // Code 39 supports uppercase A-Z, 0-9, and - . $ / + % space
        val isCode39Safe = clean.uppercase().all { it in 'A'..'Z' || it in '0'..'9' || it in "-.$/+% " }
        if (isCode39Safe && clean.length <= 24) {
            options.add(SafeBarcodeFormatOption("CODE_39", "Code 39", isRecommended = false))
        }

        // ITF requires an even number of digits
        if (allDigits && clean.length >= 6 && clean.length % 2 == 0) {
            options.add(SafeBarcodeFormatOption("ITF", "ITF (Interleaved 2 of 5)", isRecommended = false))
        }

        return options
    }
}
