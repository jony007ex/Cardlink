package com.cardlink.app.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.cardlink.app.R

data class CanonicalToolMeta(
    val id: String,
    val category: String,
    val icon: ImageVector,
    val titleRes: Int,
    val subtitleRes: Int,
    val quickActionLabelRes: Int,
    val route: String,
    val isSensitive: Boolean = false,
    val quickActionEligible: Boolean = true
)

object ToolsRegistry {
    val all: List<CanonicalToolMeta> = listOf(
        // Scan & Create
        CanonicalToolMeta(
            id = "qr_scanner",
            category = "Scan & Create",
            icon = Icons.Default.QrCodeScanner,
            titleRes = R.string.tools_qr_scanner,
            subtitleRes = R.string.tools_qr_scanner_sub,
            quickActionLabelRes = R.string.quick_tool_scan_qr,
            route = "scan_qr"
        ),
        CanonicalToolMeta(
            id = "qr_studio",
            category = "Scan & Create",
            icon = Icons.Default.QrCode2,
            titleRes = R.string.qr_studio_title,
            subtitleRes = R.string.qr_studio_tools_subtitle,
            quickActionLabelRes = R.string.qr_studio_title,
            route = "qr_studio"
        ),
        CanonicalToolMeta(
            id = "nfc_studio",
            category = "Scan & Create",
            icon = Icons.Default.Nfc,
            titleRes = R.string.nfc_studio_title,
            subtitleRes = R.string.nfc_studio_tools_sub,
            quickActionLabelRes = R.string.nfc_studio_title,
            route = "nfc_studio"
        ),
        CanonicalToolMeta(
            id = "scan_card",
            category = "Scan & Create",
            icon = Icons.Default.DocumentScanner,
            titleRes = R.string.tools_dual_ocr,
            subtitleRes = R.string.tools_dual_ocr_sub,
            quickActionLabelRes = R.string.shortcut_scan_card,
            route = "scan_ocr"
        ),

        // Secure Wallet (Hidden during Panic Lock / Privacy Decoy Mode)
        CanonicalToolMeta(
            id = "my_ids",
            category = "Secure Wallet",
            icon = Icons.Default.Badge,
            titleRes = R.string.my_ids_title,
            subtitleRes = R.string.my_ids_tools_subtitle,
            quickActionLabelRes = R.string.quick_tool_add_id,
            route = "my_ids",
            isSensitive = true
        ),
        CanonicalToolMeta(
            id = "loyalty_cards",
            category = "Secure Wallet",
            icon = Icons.Default.CardMembership,
            titleRes = R.string.loyalty_title,
            subtitleRes = R.string.loyalty_tools_subtitle,
            quickActionLabelRes = R.string.quick_tool_add_loyalty,
            route = "loyalty_cards",
            isSensitive = true
        ),
        CanonicalToolMeta(
            id = "secure_notes",
            category = "Secure Wallet",
            icon = Icons.Default.Lock,
            titleRes = R.string.secure_notes_title,
            subtitleRes = R.string.secure_notes_subtitle,
            quickActionLabelRes = R.string.quick_tool_new_secure_note,
            route = "secure_notes",
            isSensitive = true
        ),

        // Share & Personalize
        CanonicalToolMeta(
            id = "event_mode",
            category = "Share & Personalize",
            icon = Icons.Default.EventNote,
            titleRes = R.string.tools_event_mode,
            subtitleRes = R.string.tools_event_mode_sub,
            quickActionLabelRes = R.string.tools_event_mode,
            route = "event_mode"
        ),
        CanonicalToolMeta(
            id = "quick_share",
            category = "Share & Personalize",
            icon = Icons.Default.Contactless,
            titleRes = R.string.tools_quick_nfc_qr,
            subtitleRes = R.string.tools_quick_nfc_qr_sub,
            quickActionLabelRes = R.string.tools_quick_nfc_qr,
            route = "quick_nfc_qr_share"
        ),
        CanonicalToolMeta(
            id = "nfc_share_iphone",
            category = "Share & Personalize",
            icon = Icons.Default.PhoneIphone,
            titleRes = R.string.nfc_share_iphone_title,
            subtitleRes = R.string.nfc_share_iphone_sub,
            quickActionLabelRes = R.string.nfc_share_iphone_title,
            route = "nfc_share_iphone"
        ),
        CanonicalToolMeta(
            id = "meeting_bg",
            category = "Share & Personalize",
            icon = Icons.Default.VideoCameraFront,
            titleRes = R.string.tools_meeting_bg,
            subtitleRes = R.string.tools_meeting_bg_sub,
            quickActionLabelRes = R.string.tools_meeting_bg,
            route = "meeting_bg"
        )
    )

    fun findById(id: String): CanonicalToolMeta? = all.firstOrNull { it.id == id }
}
