package com.cardlink.app.util

import android.content.Context
import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.hypot

enum class SmartCropFeatureType(
    val id: String,
    val maxOutputEdgePx: Int,
    val preferDocumentPreservation: Boolean,
    val defaultEnhanceReadability: Boolean
) {
    BUSINESS_CARD("BUSINESS_CARD", maxOutputEdgePx = 1800, preferDocumentPreservation = false, defaultEnhanceReadability = true),
    MY_CARD_IMPORT("MY_CARD_IMPORT", maxOutputEdgePx = 1800, preferDocumentPreservation = false, defaultEnhanceReadability = true),
    LOYALTY_CARD("LOYALTY_CARD", maxOutputEdgePx = 1800, preferDocumentPreservation = false, defaultEnhanceReadability = false),
    ID_DOCUMENT("ID_DOCUMENT", maxOutputEdgePx = 2200, preferDocumentPreservation = true, defaultEnhanceReadability = false),
    BUSINESS_DOCUMENT("BUSINESS_DOCUMENT", maxOutputEdgePx = 2400, preferDocumentPreservation = true, defaultEnhanceReadability = false),
    CONFERENCE_QUEUE("CONFERENCE_QUEUE", maxOutputEdgePx = 1800, preferDocumentPreservation = false, defaultEnhanceReadability = true)
}

enum class CropConfidenceLevel {
    HIGH,
    MEDIUM,
    LOW
}

enum class CropReviewPolicy(val id: String) {
    ONLY_WHEN_NEEDED("ONLY_WHEN_NEEDED"),
    ALWAYS("ALWAYS"),
    NEVER("NEVER");

    companion object {
        fun fromId(raw: String?): CropReviewPolicy =
            values().firstOrNull { it.id == raw } ?: ONLY_WHEN_NEEDED
    }
}

object SmartCropPrefs {
    private const val PREFS = "cardlink_smart_crop_prefs"
    private const val KEY_SMART_CROP = "smart_crop_enabled"
    private const val KEY_REVIEW_POLICY = "crop_review_policy"
    private const val KEY_AUTO_CAPTURE = "auto_capture_enabled"

    fun isSmartCropEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SMART_CROP, true)

    fun setSmartCropEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_SMART_CROP, enabled)
            .apply()
    }

    fun getCropReviewPolicy(context: Context): CropReviewPolicy {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_REVIEW_POLICY, CropReviewPolicy.ONLY_WHEN_NEEDED.id)
        return CropReviewPolicy.fromId(raw)
    }

    fun setCropReviewPolicy(context: Context, policy: CropReviewPolicy) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_REVIEW_POLICY, policy.id)
            .apply()
    }

    fun isAutoCaptureEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_CAPTURE, false)

    fun setAutoCaptureEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_CAPTURE, enabled)
            .apply()
    }
}

@Serializable
data class CardCropMetadata(
    val topLeftX: Float = 0.04f,
    val topLeftY: Float = 0.04f,
    val topRightX: Float = 0.96f,
    val topRightY: Float = 0.04f,
    val bottomRightX: Float = 0.96f,
    val bottomRightY: Float = 0.96f,
    val bottomLeftX: Float = 0.04f,
    val bottomLeftY: Float = 0.96f,
    val rotationDegrees: Int = 0,
    val enhanceReadability: Boolean = true,
    val isOriginalFullFrame: Boolean = false,
    val cropRevision: Int = 1,
    val updatedAtTimestamp: Long = 0L,
    val sourceImageUuid: String = "",
    val ownerEntityUuid: String = "",
    val featureType: String = "BUSINESS_CARD",
    val sideOrPage: String = "FRONT",
    val transformVersion: Int = 1,
    val confidenceLevel: String = "MEDIUM",
    val sourceWidth: Int = 0,
    val sourceHeight: Int = 0,
    val canonicalOrientation: Int = 0,
    val createdAtTimestamp: Long = 0L
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

        fun fullOriginal(
            rotationDegrees: Int = 0,
            revision: Int = 1,
            featureType: SmartCropFeatureType = SmartCropFeatureType.BUSINESS_CARD,
            sideOrPage: String = "FRONT"
        ): CardCropMetadata {
            val now = System.currentTimeMillis()
            return CardCropMetadata(
                topLeftX = 0f, topLeftY = 0f,
                topRightX = 1f, topRightY = 0f,
                bottomRightX = 1f, bottomRightY = 1f,
                bottomLeftX = 0f, bottomLeftY = 1f,
                rotationDegrees = ((rotationDegrees % 360) + 360) % 360,
                enhanceReadability = false,
                isOriginalFullFrame = true,
                cropRevision = revision,
                updatedAtTimestamp = now,
                createdAtTimestamp = now,
                featureType = featureType.id,
                sideOrPage = sideOrPage,
                confidenceLevel = CropConfidenceLevel.HIGH.name
            )
        }

        fun toJson(meta: CardCropMetadata): String =
            runCatching { json.encodeToString(serializer(), meta) }.getOrDefault("")

        fun fromJson(raw: String?): CardCropMetadata? {
            if (raw.isNullOrBlank()) return null
            return runCatching { json.decodeFromString(serializer(), raw) }.getOrNull()
        }
    }
}

data class SmartCropDetectionResult(
    val metadata: CardCropMetadata,
    val confidence: CropConfidenceLevel
)

data class CropContentSafetyReport(
    val hasTextOutsideCrop: Boolean = false,
    val barcodeOrQrBroken: Boolean = false,
    val criticalOcrDegraded: Boolean = false,
    val warningType: String = ""
) {
    val hasAnyWarning: Boolean get() = hasTextOutsideCrop || barcodeOrQrBroken || criticalOcrDegraded
}

object SmartCardCropEngine {

    private const val MIN_QUAD_NORMALIZED_AREA = 0.02f

    fun decideReviewBehavior(
        smartCropEnabled: Boolean,
        policy: CropReviewPolicy,
        confidence: CropConfidenceLevel
    ): Pair<Boolean, Boolean> {
        if (!smartCropEnabled) return false to false
        return when (policy) {
            CropReviewPolicy.NEVER -> false to false
            CropReviewPolicy.ALWAYS -> true to (confidence == CropConfidenceLevel.LOW)
            CropReviewPolicy.ONLY_WHEN_NEEDED -> when (confidence) {
                CropConfidenceLevel.HIGH -> false to false
                CropConfidenceLevel.MEDIUM -> true to false
                CropConfidenceLevel.LOW -> true to true
            }
        }
    }

    fun snapCornerToDetectedEdge(
        x: Float,
        y: Float,
        cornerIndex: Int,
        detectedEdgeMeta: CardCropMetadata?,
        threshold: Float = 0.022f
    ): Triple<Float, Float, Boolean> {
        if (detectedEdgeMeta == null || detectedEdgeMeta.isOriginalFullFrame) {
            return Triple(x, y, false)
        }
        val (tx, ty) = when (cornerIndex) {
            0 -> detectedEdgeMeta.topLeftX to detectedEdgeMeta.topLeftY
            1 -> detectedEdgeMeta.topRightX to detectedEdgeMeta.topRightY
            2 -> detectedEdgeMeta.bottomRightX to detectedEdgeMeta.bottomRightY
            3 -> detectedEdgeMeta.bottomLeftX to detectedEdgeMeta.bottomLeftY
            else -> return Triple(x, y, false)
        }
        var outX = x
        var outY = y
        var snapped = false
        if (abs(x - tx) <= threshold) {
            outX = tx
            snapped = true
        }
        if (abs(y - ty) <= threshold) {
            outY = ty
            snapped = true
        }
        return Triple(outX, outY, snapped)
    }

    fun screenToNormalizedImageCoord(
        screenX: Float,
        screenY: Float,
        boxWidth: Float,
        boxHeight: Float,
        zoomScale: Float,
        panOffsetX: Float,
        panOffsetY: Float
    ): Pair<Float, Float> {
        if (boxWidth <= 0f || boxHeight <= 0f) return 0f to 0f
        val safeScale = zoomScale.coerceAtLeast(1f)
        val cx = boxWidth * 0.5f
        val cy = boxHeight * 0.5f
        val imgX = (screenX - cx - panOffsetX) / safeScale + cx
        val imgY = (screenY - cy - panOffsetY) / safeScale + cy
        return (imgX / boxWidth).coerceIn(0f, 1f) to (imgY / boxHeight).coerceIn(0f, 1f)
    }

    fun isValidQuad(meta: CardCropMetadata): Boolean {
        val coords = floatArrayOf(
            meta.topLeftX, meta.topLeftY,
            meta.topRightX, meta.topRightY,
            meta.bottomRightX, meta.bottomRightY,
            meta.bottomLeftX, meta.bottomLeftY
        )
        if (coords.any { it.isNaN() || it.isInfinite() || it < -0.001f || it > 1.001f }) return false

        val xs = floatArrayOf(meta.topLeftX, meta.topRightX, meta.bottomRightX, meta.bottomLeftX)
        val ys = floatArrayOf(meta.topLeftY, meta.topRightY, meta.bottomRightY, meta.bottomLeftY)

        var area2 = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            area2 += (xs[i] * ys[j] - xs[j] * ys[i])
        }
        val area = area2 * 0.5f
        if (area < MIN_QUAD_NORMALIZED_AREA) return false

        for (i in 0 until 4) {
            val a = i
            val b = (i + 1) % 4
            val c = (i + 2) % 4
            val abx = xs[b] - xs[a]
            val aby = ys[b] - ys[a]
            val bcx = xs[c] - xs[b]
            val bcy = ys[c] - ys[b]
            val cross = abx * bcy - aby * bcx
            if (cross <= 0.0005f) return false
        }
        return true
    }

    fun sanitizeMetadata(meta: CardCropMetadata): CardCropMetadata {
        val normRot = ((meta.rotationDegrees % 360) + 360) % 360
        if (meta.isOriginalFullFrame) {
            return meta.copy(
                topLeftX = 0f, topLeftY = 0f,
                topRightX = 1f, topRightY = 0f,
                bottomRightX = 1f, bottomRightY = 1f,
                bottomLeftX = 0f, bottomLeftY = 1f,
                rotationDegrees = normRot,
                isOriginalFullFrame = true
            )
        }
        val clamped = meta.copy(
            topLeftX = if (meta.topLeftX.isFinite()) meta.topLeftX.coerceIn(0f, 1f) else 0.04f,
            topLeftY = if (meta.topLeftY.isFinite()) meta.topLeftY.coerceIn(0f, 1f) else 0.04f,
            topRightX = if (meta.topRightX.isFinite()) meta.topRightX.coerceIn(0f, 1f) else 0.96f,
            topRightY = if (meta.topRightY.isFinite()) meta.topRightY.coerceIn(0f, 1f) else 0.04f,
            bottomRightX = if (meta.bottomRightX.isFinite()) meta.bottomRightX.coerceIn(0f, 1f) else 0.96f,
            bottomRightY = if (meta.bottomRightY.isFinite()) meta.bottomRightY.coerceIn(0f, 1f) else 0.96f,
            bottomLeftX = if (meta.bottomLeftX.isFinite()) meta.bottomLeftX.coerceIn(0f, 1f) else 0.04f,
            bottomLeftY = if (meta.bottomLeftY.isFinite()) meta.bottomLeftY.coerceIn(0f, 1f) else 0.96f,
            rotationDegrees = normRot
        )
        return if (isValidQuad(clamped)) clamped else CardCropMetadata(rotationDegrees = normRot, cropRevision = meta.cropRevision)
    }

    fun detectAutoCrop(
        source: Bitmap,
        featureType: SmartCropFeatureType = SmartCropFeatureType.BUSINESS_CARD
    ): CardCropMetadata = detectAutoCropWithConfidence(source, featureType).metadata

    fun detectAutoCropWithConfidence(
        source: Bitmap,
        featureType: SmartCropFeatureType = SmartCropFeatureType.BUSINESS_CARD,
        sideOrPage: String = "FRONT"
    ): SmartCropDetectionResult {
        val w = source.width
        val h = source.height
        val now = System.currentTimeMillis()
        if (w < 80 || h < 80) {
            return SmartCropDetectionResult(
                metadata = CardCropMetadata.fullOriginal(0, 1, featureType, sideOrPage).copy(sourceWidth = w, sourceHeight = h),
                confidence = CropConfidenceLevel.LOW
            )
        }

        return runCatching {
            val sampleW = 160
            val sampleH = ((h.toFloat() / w.toFloat()) * sampleW).toInt().coerceIn(80, 260)
            val thumb = Bitmap.createScaledBitmap(source, sampleW, sampleH, true)

            var bgR = 0f; var bgG = 0f; var bgB = 0f; var bgCnt = 0
            fun sampleBg(x: Int, y: Int) {
                val c = thumb.getPixel(x.coerceIn(0, sampleW - 1), y.coerceIn(0, sampleH - 1))
                bgR += Color.red(c); bgG += Color.green(c); bgB += Color.blue(c); bgCnt++
            }
            for (dy in 0 until 6) {
                for (dx in 0 until 6) {
                    sampleBg(dx, dy)
                    sampleBg(sampleW - 1 - dx, dy)
                    sampleBg(dx, sampleH - 1 - dy)
                    sampleBg(sampleW - 1 - dx, sampleH - 1 - dy)
                }
            }
            bgR /= bgCnt.coerceAtLeast(1)
            bgG /= bgCnt.coerceAtLeast(1)
            bgB /= bgCnt.coerceAtLeast(1)

            fun colorDelta(x: Int, y: Int): Float {
                val c = thumb.getPixel(x.coerceIn(0, sampleW - 1), y.coerceIn(0, sampleH - 1))
                return (abs(Color.red(c) - bgR) + abs(Color.green(c) - bgG) + abs(Color.blue(c) - bgB)) / 3f
            }

            val threshold = if (featureType.preferDocumentPreservation) 18f else 20f
            var detectedEdgesCount = 0

            fun scanLeft(yStartFrac: Float, yEndFrac: Float): Int? {
                val y0 = (sampleH * yStartFrac).toInt()
                val y1 = (sampleH * yEndFrac).toInt()
                val req = ((y1 - y0) / 9).coerceAtLeast(3)
                for (x in 2 until (sampleW * 0.42f).toInt()) {
                    var cnt = 0
                    for (y in y0 until y1 step 2) if (colorDelta(x, y) > threshold) cnt++
                    if (cnt >= req) return x
                }
                return null
            }

            fun scanRight(yStartFrac: Float, yEndFrac: Float): Int? {
                val y0 = (sampleH * yStartFrac).toInt()
                val y1 = (sampleH * yEndFrac).toInt()
                val req = ((y1 - y0) / 9).coerceAtLeast(3)
                for (x in (sampleW - 3) downTo (sampleW * 0.58f).toInt()) {
                    var cnt = 0
                    for (y in y0 until y1 step 2) if (colorDelta(x, y) > threshold) cnt++
                    if (cnt >= req) return x
                }
                return null
            }

            fun scanTop(xStartFrac: Float, xEndFrac: Float): Int? {
                val x0 = (sampleW * xStartFrac).toInt()
                val x1 = (sampleW * xEndFrac).toInt()
                val req = ((x1 - x0) / 9).coerceAtLeast(3)
                for (y in 2 until (sampleH * 0.42f).toInt()) {
                    var cnt = 0
                    for (x in x0 until x1 step 2) if (colorDelta(x, y) > threshold) cnt++
                    if (cnt >= req) return y
                }
                return null
            }

            fun scanBottom(xStartFrac: Float, xEndFrac: Float): Int? {
                val x0 = (sampleW * xStartFrac).toInt()
                val x1 = (sampleW * xEndFrac).toInt()
                val req = ((x1 - x0) / 9).coerceAtLeast(3)
                for (y in (sampleH - 3) downTo (sampleH * 0.58f).toInt()) {
                    var cnt = 0
                    for (x in x0 until x1 step 2) if (colorDelta(x, y) > threshold) cnt++
                    if (cnt >= req) return y
                }
                return null
            }

            val tlXRaw = scanLeft(0.16f, 0.48f)
            val blXRaw = scanLeft(0.52f, 0.84f)
            val trXRaw = scanRight(0.16f, 0.48f)
            val brXRaw = scanRight(0.52f, 0.84f)

            val tlYRaw = scanTop(0.16f, 0.48f)
            val trYRaw = scanTop(0.52f, 0.84f)
            val blYRaw = scanBottom(0.16f, 0.48f)
            val brYRaw = scanBottom(0.52f, 0.84f)

            thumb.recycle()

            if (tlXRaw != null || blXRaw != null) detectedEdgesCount++
            if (trXRaw != null || brXRaw != null) detectedEdgesCount++
            if (tlYRaw != null || trYRaw != null) detectedEdgesCount++
            if (blYRaw != null || brYRaw != null) detectedEdgesCount++

            val pad = if (featureType.preferDocumentPreservation) 0.016f else 0.010f
            fun lx(v: Int?) = (((v ?: 3).toFloat() / sampleW) - pad).coerceIn(0.01f, 0.40f)
            fun rx(v: Int?) = (((v ?: (sampleW - 4)).toFloat() / sampleW) + pad).coerceIn(0.60f, 0.99f)
            fun ty(v: Int?) = (((v ?: 3).toFloat() / sampleH) - pad).coerceIn(0.01f, 0.40f)
            fun by(v: Int?) = (((v ?: (sampleH - 4)).toFloat() / sampleH) + pad).coerceIn(0.60f, 0.99f)

            val tlX = lx(tlXRaw ?: blXRaw)
            val blX = lx(blXRaw ?: tlXRaw)
            val trX = rx(trXRaw ?: brXRaw)
            val brX = rx(brXRaw ?: trXRaw)
            val tlY = ty(tlYRaw ?: trYRaw)
            val trY = ty(trYRaw ?: tlYRaw)
            val blY = by(blYRaw ?: brYRaw)
            val brY = by(brYRaw ?: blYRaw)

            val avgW = ((trX - tlX) + (brX - blX)) * 0.5f
            val avgH = ((blY - tlY) + (brY - trY)) * 0.5f
            val areaFrac = avgW * avgH

            val candidate = CardCropMetadata(
                topLeftX = tlX, topLeftY = tlY,
                topRightX = trX, topRightY = trY,
                bottomRightX = brX, bottomRightY = brY,
                bottomLeftX = blX, bottomLeftY = blY,
                rotationDegrees = 0,
                enhanceReadability = featureType.defaultEnhanceReadability,
                isOriginalFullFrame = false,
                featureType = featureType.id,
                sideOrPage = sideOrPage,
                sourceWidth = w,
                sourceHeight = h,
                createdAtTimestamp = now,
                updatedAtTimestamp = now
            )

            val validQuad = isValidQuad(candidate) && avgW >= 0.28f && avgH >= 0.24f
            if (!validQuad) {
                val fallback = CardCropMetadata(
                    enhanceReadability = featureType.defaultEnhanceReadability,
                    featureType = featureType.id,
                    sideOrPage = sideOrPage,
                    confidenceLevel = CropConfidenceLevel.LOW.name,
                    sourceWidth = w,
                    sourceHeight = h,
                    createdAtTimestamp = now,
                    updatedAtTimestamp = now
                )
                return@runCatching SmartCropDetectionResult(fallback, CropConfidenceLevel.LOW)
            }

            val pixW = avgW * w
            val pixH = avgH * h
            val longOverShort = maxOf(pixW, pixH) / minOf(pixW, pixH).coerceAtLeast(1f)
            val aspectHealthy = if (featureType.preferDocumentPreservation) {
                longOverShort in 1.05f..2.10f
            } else {
                longOverShort in 1.25f..2.05f
            }

            val confidence = when {
                detectedEdgesCount == 4 && areaFrac in 0.20f..0.94f && aspectHealthy -> CropConfidenceLevel.HIGH
                detectedEdgesCount >= 3 && areaFrac >= 0.14f -> CropConfidenceLevel.MEDIUM
                else -> CropConfidenceLevel.LOW
            }

            SmartCropDetectionResult(
                metadata = candidate.copy(confidenceLevel = confidence.name),
                confidence = confidence
            )
        }.getOrElse {
            SmartCropDetectionResult(
                metadata = CardCropMetadata(
                    featureType = featureType.id,
                    sideOrPage = sideOrPage,
                    confidenceLevel = CropConfidenceLevel.LOW.name,
                    sourceWidth = w,
                    sourceHeight = h,
                    createdAtTimestamp = now,
                    updatedAtTimestamp = now
                ),
                confidence = CropConfidenceLevel.LOW
            )
        }
    }

    suspend fun validateCroppedContentSafety(
        context: Context,
        sourceBitmap: Bitmap,
        croppedBitmap: Bitmap,
        meta: CardCropMetadata,
        featureType: SmartCropFeatureType,
        expectedBarcodePayload: String = "",
        expectedQrPayload: String = ""
    ): CropContentSafetyReport = withContext(Dispatchers.IO) {
        if (meta.isOriginalFullFrame) return@withContext CropContentSafetyReport()

        if (expectedBarcodePayload.isNotBlank() || expectedQrPayload.isNotBlank()) {
            val codeStillOk = runCatching {
                LoyaltyCodeHelper.quickVerifyCodePresent(croppedBitmap, expectedBarcodePayload, expectedQrPayload)
            }.getOrDefault(false)
            if (!codeStillOk) {
                return@withContext CropContentSafetyReport(
                    barcodeOrQrBroken = true,
                    warningType = "CODE"
                )
            }
        }

        val cropArea = ((meta.topRightX - meta.topLeftX) + (meta.bottomRightX - meta.bottomLeftX)) * 0.5f *
            ((meta.bottomLeftY - meta.topLeftY) + (meta.bottomRightY - meta.topRightY)) * 0.5f
        if (cropArea < 0.86f && featureType != SmartCropFeatureType.CONFERENCE_QUEUE) {
            val textOutside = runCatching {
                val srcText = OcrEngineRegistry.recognizeBitmap(context, sourceBitmap)
                val sw = sourceBitmap.width.toFloat().coerceAtLeast(1f)
                val sh = sourceBitmap.height.toFloat().coerceAtLeast(1f)
                val minX = minOf(meta.topLeftX, meta.bottomLeftX)
                val maxX = maxOf(meta.topRightX, meta.bottomRightX)
                val minY = minOf(meta.topLeftY, meta.topRightY)
                val maxY = maxOf(meta.bottomLeftY, meta.bottomRightY)
                var clippedSignificantBlocks = 0
                for (block in srcText.textBlocks) {
                    val box = block.boundingBox ?: continue
                    val txt = block.text.trim()
                    if (txt.length < 4) continue
                    val cx = box.centerX() / sw
                    val cy = box.centerY() / sh
                    if (cx < minX - 0.015f || cx > maxX + 0.015f || cy < minY - 0.015f || cy > maxY + 0.015f) {
                        clippedSignificantBlocks++
                    }
                }
                clippedSignificantBlocks >= 2
            }.getOrDefault(false)

            if (textOutside) {
                return@withContext CropContentSafetyReport(
                    hasTextOutsideCrop = true,
                    warningType = "TEXT"
                )
            }
        }

        CropContentSafetyReport()
    }

    fun applyCropAndPerspective(
        source: Bitmap,
        rawMeta: CardCropMetadata,
        maxOutputEdgePx: Int = 1800
    ): Bitmap {
        val meta = sanitizeMetadata(rawMeta)
        val rotated = if (meta.rotationDegrees != 0) {
            val m = Matrix().apply { postRotate(meta.rotationDegrees.toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, m, true)
        } else {
            source
        }

        if (meta.isOriginalFullFrame || !isValidQuad(meta)) {
            return rotated
        }

        val w = rotated.width.toFloat()
        val h = rotated.height.toFloat()

        val srcPts = floatArrayOf(
            meta.topLeftX * w, meta.topLeftY * h,
            meta.topRightX * w, meta.topRightY * h,
            meta.bottomRightX * w, meta.bottomRightY * h,
            meta.bottomLeftX * w, meta.bottomLeftY * h
        )

        val topWidth = hypot((srcPts[2] - srcPts[0]).toDouble(), (srcPts[3] - srcPts[1]).toDouble()).toFloat()
        val bottomWidth = hypot((srcPts[4] - srcPts[6]).toDouble(), (srcPts[5] - srcPts[7]).toDouble()).toFloat()
        val leftHeight = hypot((srcPts[6] - srcPts[0]).toDouble(), (srcPts[7] - srcPts[1]).toDouble()).toFloat()
        val rightHeight = hypot((srcPts[4] - srcPts[2]).toDouble(), (srcPts[5] - srcPts[3]).toDouble()).toFloat()

        val rawW = maxOf(topWidth, bottomWidth).coerceAtLeast(160f)
        val rawH = maxOf(leftHeight, rightHeight).coerceAtLeast(100f)

        val longest = maxOf(rawW, rawH)
        val scale = if (longest > maxOutputEdgePx.toFloat()) maxOutputEdgePx.toFloat() / longest else 1f
        val outW = (rawW * scale).toInt().coerceAtLeast(160)
        val outH = (rawH * scale).toInt().coerceAtLeast(100)

        val dstPts = floatArrayOf(
            0f, 0f,
            outW.toFloat(), 0f,
            outW.toFloat(), outH.toFloat(),
            0f, outH.toFloat()
        )

        val polyMatrix = Matrix()
        val mapped = polyMatrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)
        if (!mapped) {
            return rotated
        }

        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (meta.enhanceReadability) {
            val contrast = 1.06f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            paint.colorFilter = ColorMatrixColorFilter(
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        canvas.drawBitmap(rotated, polyMatrix, paint)
        if (rotated !== source) rotated.recycle()
        return output
    }
}
