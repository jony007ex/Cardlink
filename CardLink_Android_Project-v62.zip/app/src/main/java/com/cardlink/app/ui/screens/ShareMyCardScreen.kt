package com.cardlink.app.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.ui.components.FlippableBusinessCardView
import com.cardlink.app.ui.components.SmartPrivacyPreviewCard
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareMyCardScreen(
    activeCard: BusinessCardEntity,
    nfcReaderManager: NfcReaderManager,
    onSaveCard: (BusinessCardEntity) -> Unit,
    onRefreshWidgetsAndHce: () -> Unit,
    onLogShare: (method: String) -> Unit,
    onOpenNearbySwap: () -> Unit,
    onOpenNfcTap: () -> Unit,
    onOpenShareToIphone: () -> Unit,
    onOpenNfcStudio: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Canonical Sharing Profile state (Single Source of Privacy Truth)
    var selectedSharingProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    val effectiveShareCard = remember(activeCard, selectedSharingProfile) {
        SharingProfileManager.applyProfile(activeCard, selectedSharingProfile)
    }
    var isCardFlipped by remember { mutableStateOf(false) }

    // Modal & Sheet states
    var showProfileSheet by remember { mutableStateOf(false) }
    var showQrSheet by remember { mutableStateOf(false) }
    var showQrFullScreen by remember { mutableStateOf(false) }
    var showQuickShareSheet by remember { mutableStateOf(false) }
    var showNfcOptionsSheet by remember { mutableStateOf(false) }
    var showNotSureDialog by remember { mutableStateOf(false) }
    var showPngExportSheet by remember { mutableStateOf(false) }
    var showPdfExportSheet by remember { mutableStateOf(false) }
    var showHtmlExportSheet by remember { mutableStateOf(false) }
    var showHtmlPreviewDialog by remember { mutableStateOf(false) }
    var showMoreFormatsSheet by remember { mutableStateOf(false) }
    var showSendMessageDialog by remember { mutableStateOf(false) }

    // Export Options State
    var pngSides by remember { mutableStateOf(ExportCardSides.FRONT_ONLY) }
    var pngCombinedLayout by remember { mutableStateOf(CombinedPngLayout.COMBINED_SHEET) }
    var pngQuality by remember { mutableStateOf(ExportQualityTier.STANDARD) }
    var pdfSides by remember { mutableStateOf(ExportCardSides.FRONT_AND_BACK) }
    var pdfLayout by remember { mutableStateOf(PdfCardLayout.BUSINESS_CARD_SIZE) }
    var pdfQuality by remember { mutableStateOf(ExportQualityTier.HIGH_QUALITY) }

    // Stage-based non-blocking export progress (Part O Sec 40)
    var exportStageLabel by remember { mutableStateOf<String?>(null) }

    // Safe slug helper
    val cardSlug = remember(effectiveShareCard.fullName) {
        effectiveShareCard.fullName.trim()
            .replace(Regex("\\s+"), "_")
            .replace(Regex("[^a-zA-Z0-9_-]"), "")
            .trim('_')
            .ifBlank { "Contact" }
    }

    // Privacy summary for compact Sharing Profile row
    val privacyItems = remember(effectiveShareCard) {
        IphoneNfcShareHelper.buildPrivacyPreviewItems(effectiveShareCard)
    }
    val sharedLabels = remember(privacyItems) { privacyItems.filter { it.isShared }.map { it.label } }
    val compactProfileSummary = remember(sharedLabels) {
        if (sharedLabels.size <= 4) sharedLabels.joinToString(" • ").ifBlank { "Name" }
        else sharedLabels.take(4).joinToString(" • ") + " +${sharedLabels.size - 4} more"
    }

    val hasValidDigitalLink = remember(effectiveShareCard.publicCardUrl) {
        effectiveShareCard.publicCardUrl.isNotBlank() &&
            IphoneNfcShareHelper.validateDigitalCardUrlLocally(effectiveShareCard.publicCardUrl).isValid
    }

    // Lazily rendered Branded QR for Share QR Sheet (always uses active Sharing Profile!)
    val shareQrBitmap by produceState<Bitmap?>(initialValue = null, effectiveShareCard, showQrSheet, showQrFullScreen) {
        if (showQrSheet || showQrFullScreen) {
            value = withContext(Dispatchers.Default) {
                PremiumExtrasHelper.generateBrandedQrBitmap(context, effectiveShareCard, 780)
            }
        }
    }

    // Explicit Save-to-Device SAF Launchers (Section 37: Share = temp vault, Save = user destination!)
    val saveVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { destUri: Uri? ->
        if (destUri != null) {
            CardShareHelper.saveVCardToUri(context, destUri, effectiveShareCard)
                .onSuccess { Toast.makeText(context, context.getString(R.string.share_vcf_saved_toast), Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show() }
        }
    }
    val saveQrLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { destUri: Uri? ->
        val bmp = shareQrBitmap
        if (destUri != null && bmp != null) {
            scope.launch {
                CardLinkCanonicalRenderer.saveQrBitmapToUri(context, destUri, bmp)
                    .onSuccess { Toast.makeText(context, context.getString(R.string.share_export_saved_toast), Toast.LENGTH_SHORT).show() }
                    .onFailure { Toast.makeText(context, context.getString(R.string.share_export_failed_toast), Toast.LENGTH_LONG).show() }
            }
        }
    }
    val savePngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { destUri: Uri? ->
        if (destUri != null) {
            scope.launch {
                exportStageLabel = context.getString(R.string.share_stage_rendering)
                val res = CardLinkCanonicalRenderer.savePngToUri(context, destUri, effectiveShareCard, pngSides, pngQuality)
                exportStageLabel = null
                res.onSuccess { Toast.makeText(context, context.getString(R.string.share_export_saved_toast), Toast.LENGTH_SHORT).show() }
                    .onFailure { Toast.makeText(context, context.getString(R.string.share_export_failed_toast), Toast.LENGTH_LONG).show() }
            }
        }
    }
    val savePdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { destUri: Uri? ->
        if (destUri != null) {
            scope.launch {
                exportStageLabel = context.getString(R.string.share_stage_preparing_file)
                val res = CardLinkCanonicalRenderer.savePdfToUri(context, destUri, effectiveShareCard, pdfSides, pdfLayout, pdfQuality)
                exportStageLabel = null
                res.onSuccess { Toast.makeText(context, context.getString(R.string.share_export_saved_toast), Toast.LENGTH_SHORT).show() }
                    .onFailure { Toast.makeText(context, context.getString(R.string.share_export_failed_toast), Toast.LENGTH_LONG).show() }
            }
        }
    }
    val saveHtmlLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { destUri: Uri? ->
        if (destUri != null) {
            scope.launch {
                exportStageLabel = context.getString(R.string.share_stage_preparing_file)
                val res = CardLinkCanonicalRenderer.saveInteractiveHtmlToUri(context, destUri, effectiveShareCard)
                exportStageLabel = null
                res.onSuccess { Toast.makeText(context, context.getString(R.string.share_export_saved_toast), Toast.LENGTH_SHORT).show() }
                    .onFailure { Toast.makeText(context, context.getString(R.string.share_export_failed_toast), Toast.LENGTH_LONG).show() }
            }
        }
    }

    // Consistent Toolbar & System Back Navigation (Part A Sec 2)
    BackHandler(enabled = true) {
        onNavigateBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.share_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // =================================================================
            // 1. VISUAL HERO: ACTIVE FLIPPABLE FRONT/BACK BUSINESS CARD
            // =================================================================
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                FlippableBusinessCardView(
                    card = effectiveShareCard,
                    isFlippedExternal = isCardFlipped,
                    onFlipToggle = { isCardFlipped = !isCardFlipped }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                        Text(
                            text = stringResource(R.string.tpl_tap_to_flip_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (isCardFlipped) stringResource(R.string.card_side_back) else stringResource(R.string.card_side_front),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Stage-based non-blocking export progress indicator
            exportStageLabel?.let { stage ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text(stage, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // =================================================================
            // 2. COMPACT SHARING PROFILE SELECTOR (Part C Sec 5)
            // =================================================================
            val profileA11y = "${stringResource(R.string.iphone_sharing_profile_title)}: ${selectedSharingProfile.label}"
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = profileA11y }
                    .clickable(role = Role.Button) { showProfileSheet = true },
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.iphone_sharing_profile_title),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = compactProfileSummary,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = selectedSharingProfile.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // =================================================================
            // 3. READABLE PRIVACY PREVIEW (Part D Sec 6-7)
            // =================================================================
            SmartPrivacyPreviewCard(
                card = effectiveShareCard,
                onUpdateSharingPreferences = { updated ->
                    selectedSharingProfile = SharingProfileType.CUSTOM
                    SharingProfileManager.setActiveProfile(context, SharingProfileType.CUSTOM)
                    onSaveCard(updated)
                    onRefreshWidgetsAndHce()
                }
            )

            // =================================================================
            // 4. SHARE INSTANTLY (EXACT PRIORITY ORDER: QR -> Quick Share -> Nearby Swap -> NFC -> Contact/VCF)
            // =================================================================
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.share_instantly_header),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    TextButton(
                        onClick = { showNotSureDialog = true },
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 38.dp)
                    ) {
                        Text(stringResource(R.string.share_not_sure_btn), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Row 1: 1. QR Code (Recommended) | 2. Quick Share
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ShareInstantTile(
                        icon = Icons.Default.QrCode2,
                        title = stringResource(R.string.share_method_qr),
                        subtitle = stringResource(R.string.share_method_qr_sub),
                        badge = stringResource(R.string.iphone_choice_recommended),
                        emphasized = true,
                        onClick = {
                            onLogShare("QR Code")
                            showQrSheet = true
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ShareInstantTile(
                        icon = Icons.Default.Share,
                        title = stringResource(R.string.share_method_quick),
                        subtitle = stringResource(R.string.share_method_quick_sub),
                        badge = null,
                        emphasized = false,
                        onClick = { showQuickShareSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: 3. Nearby Swap | 4. NFC
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ShareInstantTile(
                        icon = Icons.Default.WifiTethering,
                        title = stringResource(R.string.share_method_nearby),
                        subtitle = stringResource(R.string.share_method_nearby_sub),
                        badge = null,
                        emphasized = false,
                        onClick = { onOpenNearbySwap() },
                        modifier = Modifier.weight(1f)
                    )
                    ShareInstantTile(
                        icon = Icons.Default.Nfc,
                        title = stringResource(R.string.share_method_nfc),
                        subtitle = stringResource(R.string.share_method_nfc_sub),
                        badge = null,
                        emphasized = false,
                        onClick = { showNfcOptionsSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 3: 5. Contact / VCF
                ShareInstantTile(
                    icon = Icons.Default.ContactPage,
                    title = stringResource(R.string.share_method_vcf),
                    subtitle = stringResource(R.string.share_method_vcf_sub),
                    badge = null,
                    emphasized = false,
                    onClick = {
                        onLogShare("Contact / VCF")
                        CardShareHelper.shareVCardFile(context, effectiveShareCard)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            // =================================================================
            // 5. EXPORT & DOWNLOAD (Cleanly Separated from Instant Sharing — Part F-K)
            // =================================================================
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.share_export_download_header),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                ExportOptionRowCard(
                    icon = Icons.Default.Image,
                    title = stringResource(R.string.share_export_card_image),
                    subtitle = stringResource(R.string.share_export_card_image_sub),
                    onClick = { showPngExportSheet = true }
                )
                ExportOptionRowCard(
                    icon = Icons.Default.PictureAsPdf,
                    title = stringResource(R.string.share_export_pdf),
                    subtitle = stringResource(R.string.share_export_pdf_sub),
                    onClick = { showPdfExportSheet = true }
                )
                ExportOptionRowCard(
                    icon = Icons.Default.Language,
                    title = stringResource(R.string.share_export_html),
                    subtitle = stringResource(R.string.share_export_html_sub),
                    onClick = { showHtmlExportSheet = true }
                )
                ExportOptionRowCard(
                    icon = Icons.Default.MoreHoriz,
                    title = stringResource(R.string.share_export_more_formats),
                    subtitle = stringResource(R.string.share_export_more_formats_sub),
                    onClick = { showMoreFormatsSheet = true }
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    // =========================================================================
    // MODALS & SHEETS
    // =========================================================================

    // 1. Sharing Profile Bottom Sheet
    if (showProfileSheet) {
        ModalBottomSheet(
            onDismissRequest = { showProfileSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(stringResource(R.string.iphone_sharing_profile_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                SharingProfileType.values().forEach { prof ->
                    val isSel = selectedSharingProfile == prof
                    Surface(
                        onClick = {
                            selectedSharingProfile = prof
                            SharingProfileManager.setActiveProfile(context, prof)
                            onRefreshWidgetsAndHce()
                            showProfileSheet = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prof.label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(prof.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (isSel) Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }

    // 2. Primary Share QR Bottom Sheet (Part E Sec 10-11)
    if (showQrSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQrSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.share_qr_sheet_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    text = "${selectedSharingProfile.label} • $compactProfileSummary",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Surface(shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 3.dp) {
                    Box(modifier = Modifier.size(230.dp).padding(12.dp), contentAlignment = Alignment.Center) {
                        val bmp = shareQrBitmap
                        if (bmp != null) {
                            Image(bitmap = bmp.asImageBitmap(), contentDescription = stringResource(R.string.share_qr_sheet_title), modifier = Modifier.fillMaxSize())
                        } else {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showQrSheet = false; showQrFullScreen = true },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp)
                    ) { Text(stringResource(R.string.card_view_fullscreen), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = {
                            val bmp = shareQrBitmap ?: return@Button
                            scope.launch {
                                CardLinkCanonicalRenderer.shareQrBitmap(context, effectiveShareCard, bmp)
                            }
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp)
                    ) { Text(stringResource(R.string.share_qr_action_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
                TextButton(
                    onClick = { saveQrLauncher.launch("CardLink_${cardSlug}_QR.png") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.SaveAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.share_save_qr_btn), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // Full-Screen QR Dialog
    if (showQrFullScreen) {
        Dialog(onDismissRequest = { showQrFullScreen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(modifier = Modifier.fillMaxSize().background(Color.White).statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
                IconButton(onClick = { showQrFullScreen = false }, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.Black)
                }
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = BusinessCardProfileHelper.formatFullNameWithCredentials(effectiveShareCard, forSharing = true).ifBlank { effectiveShareCard.fullName },
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                    shareQrBitmap?.let { bmp ->
                        Image(bitmap = bmp.asImageBitmap(), contentDescription = "Full Screen QR", modifier = Modifier.size(290.dp))
                    }
                    Text(selectedSharingProfile.label, color = Color.DarkGray, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }

    // 3. Quick Share Chooser Sheet (Part E Sec 12)
    if (showQuickShareSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQuickShareSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(stringResource(R.string.share_quick_sheet_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (hasValidDigitalLink) {
                    QuickShareChoiceRow(
                        icon = Icons.Default.Language,
                        title = "${stringResource(R.string.iphone_choice_digital_card)} (${stringResource(R.string.iphone_choice_recommended)})",
                        subtitle = IphoneNfcShareHelper.shortenUrlForDisplay(effectiveShareCard.publicCardUrl)
                    ) {
                        showQuickShareSheet = false
                        onLogShare("Quick Share (Digital Card)")
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${BusinessCardProfileHelper.formatFullNameWithCredentials(effectiveShareCard, forSharing = true)}\n${effectiveShareCard.publicCardUrl.trim()}")
                        }
                        context.startActivity(Intent.createChooser(intent, context.getString(R.string.share_method_quick)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
                QuickShareChoiceRow(Icons.Default.Image, stringResource(R.string.share_export_card_image), stringResource(R.string.share_export_card_image_sub)) {
                    showQuickShareSheet = false
                    onLogShare("Quick Share (PNG)")
                    scope.launch {
                        exportStageLabel = context.getString(R.string.share_stage_rendering)
                        CardLinkCanonicalRenderer.exportAndSharePng(context, effectiveShareCard, ExportCardSides.FRONT_ONLY, CombinedPngLayout.SEPARATE_IMAGES, ExportQualityTier.STANDARD)
                        exportStageLabel = null
                    }
                }
                QuickShareChoiceRow(Icons.Default.ContactPage, stringResource(R.string.share_method_vcf), stringResource(R.string.share_method_vcf_sub)) {
                    showQuickShareSheet = false
                    onLogShare("Quick Share (VCF)")
                    CardShareHelper.shareVCardFile(context, effectiveShareCard)
                }
                QuickShareChoiceRow(Icons.Default.QrCode2, stringResource(R.string.share_method_qr), stringResource(R.string.share_method_qr_sub)) {
                    showQuickShareSheet = false
                    showQrSheet = true
                }
                QuickShareChoiceRow(Icons.Default.PictureAsPdf, stringResource(R.string.share_export_pdf), stringResource(R.string.share_export_pdf_sub)) {
                    showQuickShareSheet = false
                    onLogShare("Quick Share (PDF)")
                    scope.launch {
                        exportStageLabel = context.getString(R.string.share_stage_preparing_file)
                        CardLinkCanonicalRenderer.exportAndSharePdf(context, effectiveShareCard, ExportCardSides.FRONT_AND_BACK, PdfCardLayout.BUSINESS_CARD_SIZE, ExportQualityTier.STANDARD)
                        exportStageLabel = null
                    }
                }
            }
        }
    }

    // 4. NFC Options Sheet with Automatic "Use QR Instead" Fallback (Part E Sec 14-15)
    if (showNfcOptionsSheet) {
        val nfcSupported = nfcReaderManager.isNfcSupported()
        val nfcEnabled = nfcReaderManager.isNfcEnabled()
        ModalBottomSheet(
            onDismissRequest = { showNfcOptionsSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(stringResource(R.string.share_method_nfc), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (!nfcSupported || !nfcEnabled) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = if (!nfcSupported) stringResource(R.string.nfc_unsupported_title) else stringResource(R.string.nfc_disabled_title),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                            Button(
                                onClick = { showNfcOptionsSheet = false; showQrSheet = true },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(stringResource(R.string.share_use_qr_instead_btn), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                QuickShareChoiceRow(Icons.Default.PhoneIphone, stringResource(R.string.nfc_share_iphone_title), stringResource(R.string.iphone_share_clean_sub)) {
                    showNfcOptionsSheet = false
                    onLogShare("NFC (iPhone)")
                    onOpenShareToIphone()
                }
                QuickShareChoiceRow(Icons.Default.Contactless, stringResource(R.string.nfc_tap_screen_title), stringResource(R.string.share_method_nfc_sub)) {
                    showNfcOptionsSheet = false
                    onLogShare("NFC Tap")
                    onOpenNfcTap()
                }
                QuickShareChoiceRow(Icons.Default.Nfc, stringResource(R.string.nfc_studio_title), stringResource(R.string.nfc_studio_tools_sub)) {
                    showNfcOptionsSheet = false
                    onOpenNfcStudio()
                }
            }
        }
    }

    // 5. Optional "Not Sure How to Share?" Assistant (Part L Sec 32)
    if (showNotSureDialog) {
        AlertDialog(
            onDismissRequest = { showNotSureDialog = false },
            title = { Text(stringResource(R.string.share_not_sure_dialog_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickShareChoiceRow(Icons.Default.PhotoCamera, stringResource(R.string.share_guide_camera), stringResource(R.string.share_method_qr)) {
                        showNotSureDialog = false; showQrSheet = true
                    }
                    QuickShareChoiceRow(Icons.Default.WifiTethering, stringResource(R.string.share_guide_nearby), stringResource(R.string.share_method_nearby)) {
                        showNotSureDialog = false; onOpenNearbySwap()
                    }
                    QuickShareChoiceRow(Icons.Default.Nfc, stringResource(R.string.share_method_nfc), stringResource(R.string.share_method_nfc_sub)) {
                        showNotSureDialog = false; showNfcOptionsSheet = true
                    }
                    QuickShareChoiceRow(Icons.Default.Chat, stringResource(R.string.share_guide_msg), stringResource(R.string.share_method_quick)) {
                        showNotSureDialog = false; showQuickShareSheet = true
                    }
                    QuickShareChoiceRow(Icons.Default.ContactPage, stringResource(R.string.share_guide_contacts), stringResource(R.string.share_method_vcf)) {
                        showNotSureDialog = false; CardShareHelper.shareVCardFile(context, effectiveShareCard)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotSureDialog = false }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // 6. Export Business Card Image (PNG) Sheet with Live Canonical Preview (Part H Sec 20-23)
    if (showPngExportSheet) {
        var previewBack by remember { mutableStateOf(pngSides == ExportCardSides.BACK_ONLY) }
        val previewBmp by produceState<Bitmap?>(initialValue = null, effectiveShareCard, previewBack, pngQuality) {
            value = withContext(Dispatchers.Default) {
                if (previewBack) CardLinkCanonicalRenderer.renderBackBitmap(context, effectiveShareCard, ExportQualityTier.STANDARD)
                else CardLinkCanonicalRenderer.renderFrontBitmap(context, effectiveShareCard, ExportQualityTier.STANDARD)
            }
        }
        ModalBottomSheet(
            onDismissRequest = { showPngExportSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.share_export_png_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                // Export Preview (Exact same canonical renderer!)
                Text(stringResource(R.string.share_export_preview_lbl), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth().aspectRatio(1.66f)) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(6.dp)) {
                        previewBmp?.let { bmp ->
                            Image(bitmap = bmp.asImageBitmap(), contentDescription = stringResource(R.string.share_export_preview_lbl), contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                        } ?: CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !previewBack, onClick = { previewBack = false }, label = { Text(stringResource(R.string.card_side_front), fontSize = 11.5.sp) })
                    FilterChip(selected = previewBack, onClick = { previewBack = true }, label = { Text(stringResource(R.string.card_side_back), fontSize = 11.5.sp) })
                }

                // Sides
                Text(stringResource(R.string.share_export_sides_lbl), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = pngSides == ExportCardSides.FRONT_ONLY, onClick = { pngSides = ExportCardSides.FRONT_ONLY; previewBack = false }, label = { Text(stringResource(R.string.share_side_front_only), fontSize = 11.sp) })
                    FilterChip(selected = pngSides == ExportCardSides.BACK_ONLY, onClick = { pngSides = ExportCardSides.BACK_ONLY; previewBack = true }, label = { Text(stringResource(R.string.share_side_back_only), fontSize = 11.sp) })
                    FilterChip(selected = pngSides == ExportCardSides.FRONT_AND_BACK, onClick = { pngSides = ExportCardSides.FRONT_AND_BACK }, label = { Text(stringResource(R.string.share_side_front_back), fontSize = 11.sp) })
                }

                if (pngSides == ExportCardSides.FRONT_AND_BACK) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = pngCombinedLayout == CombinedPngLayout.SEPARATE_IMAGES, onClick = { pngCombinedLayout = CombinedPngLayout.SEPARATE_IMAGES }, label = { Text(stringResource(R.string.share_png_separate), fontSize = 11.5.sp) })
                        FilterChip(selected = pngCombinedLayout == CombinedPngLayout.COMBINED_SHEET, onClick = { pngCombinedLayout = CombinedPngLayout.COMBINED_SHEET }, label = { Text(stringResource(R.string.share_png_combined), fontSize = 11.5.sp) })
                    }
                }

                // Quality
                Text(stringResource(R.string.share_export_quality_lbl), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = pngQuality == ExportQualityTier.STANDARD, onClick = { pngQuality = ExportQualityTier.STANDARD }, label = { Text(stringResource(R.string.share_quality_standard), fontSize = 11.5.sp) })
                    FilterChip(selected = pngQuality == ExportQualityTier.HIGH_QUALITY, onClick = { pngQuality = ExportQualityTier.HIGH_QUALITY }, label = { Text(stringResource(R.string.share_quality_high), fontSize = 11.5.sp) })
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            showPngExportSheet = false
                            savePngLauncher.launch("CardLink_${cardSlug}.png")
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.qr_save_to_device_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = {
                            showPngExportSheet = false
                            onLogShare("Business Card Image (PNG)")
                            scope.launch {
                                exportStageLabel = context.getString(R.string.share_stage_rendering)
                                CardLinkCanonicalRenderer.exportAndSharePng(context, effectiveShareCard, pngSides, pngCombinedLayout, pngQuality)
                                exportStageLabel = null
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.bk_export_btn), fontWeight = FontWeight.Bold) }
                }
            }
        }
    }

    // 7. Export PDF Sheet (Part I Sec 24-26)
    if (showPdfExportSheet) {
        var pdfPreviewBack by remember { mutableStateOf(pdfSides == ExportCardSides.BACK_ONLY) }
        val pdfPreviewBmp by produceState<Bitmap?>(initialValue = null, effectiveShareCard, pdfPreviewBack) {
            value = withContext(Dispatchers.Default) {
                if (pdfPreviewBack) CardLinkCanonicalRenderer.renderBackBitmap(context, effectiveShareCard, ExportQualityTier.STANDARD)
                else CardLinkCanonicalRenderer.renderFrontBitmap(context, effectiveShareCard, ExportQualityTier.STANDARD)
            }
        }
        ModalBottomSheet(
            onDismissRequest = { showPdfExportSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.share_export_pdf_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth().aspectRatio(1.66f)) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        pdfPreviewBmp?.let { bmp ->
                            Image(bitmap = bmp.asImageBitmap(), contentDescription = stringResource(R.string.share_export_preview_lbl), contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                        } ?: CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !pdfPreviewBack, onClick = { pdfPreviewBack = false }, label = { Text(stringResource(R.string.card_side_front), fontSize = 11.5.sp) })
                    FilterChip(selected = pdfPreviewBack, onClick = { pdfPreviewBack = true }, label = { Text(stringResource(R.string.card_side_back), fontSize = 11.5.sp) })
                }

                Text(stringResource(R.string.share_export_sides_lbl), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = pdfSides == ExportCardSides.FRONT_ONLY, onClick = { pdfSides = ExportCardSides.FRONT_ONLY; pdfPreviewBack = false }, label = { Text(stringResource(R.string.share_side_front_only), fontSize = 11.sp) })
                    FilterChip(selected = pdfSides == ExportCardSides.BACK_ONLY, onClick = { pdfSides = ExportCardSides.BACK_ONLY; pdfPreviewBack = true }, label = { Text(stringResource(R.string.share_side_back_only), fontSize = 11.sp) })
                    FilterChip(selected = pdfSides == ExportCardSides.FRONT_AND_BACK, onClick = { pdfSides = ExportCardSides.FRONT_AND_BACK }, label = { Text(stringResource(R.string.share_side_front_back), fontSize = 11.sp) })
                }

                Text(stringResource(R.string.share_pdf_layout_lbl), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = pdfLayout == PdfCardLayout.BUSINESS_CARD_SIZE, onClick = { pdfLayout = PdfCardLayout.BUSINESS_CARD_SIZE }, label = { Text(stringResource(R.string.share_pdf_card_size), fontSize = 11.5.sp) })
                    FilterChip(selected = pdfLayout == PdfCardLayout.A4_PRINT_SHEET, onClick = { pdfLayout = PdfCardLayout.A4_PRINT_SHEET }, label = { Text(stringResource(R.string.share_pdf_a4_sheet), fontSize = 11.5.sp) })
                }

                Text(stringResource(R.string.share_export_quality_lbl), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = pdfQuality == ExportQualityTier.STANDARD, onClick = { pdfQuality = ExportQualityTier.STANDARD }, label = { Text(stringResource(R.string.share_quality_standard), fontSize = 11.5.sp) })
                    FilterChip(selected = pdfQuality == ExportQualityTier.HIGH_QUALITY, onClick = { pdfQuality = ExportQualityTier.HIGH_QUALITY }, label = { Text(stringResource(R.string.share_quality_print), fontSize = 11.5.sp) })
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            showPdfExportSheet = false
                            savePdfLauncher.launch("CardLink_${cardSlug}.pdf")
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.qr_save_to_device_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = {
                            showPdfExportSheet = false
                            onLogShare("PDF Document")
                            scope.launch {
                                exportStageLabel = context.getString(R.string.share_stage_preparing_file)
                                CardLinkCanonicalRenderer.exportAndSharePdf(context, effectiveShareCard, pdfSides, pdfLayout, pdfQuality)
                                exportStageLabel = null
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.bk_export_btn), fontWeight = FontWeight.Bold) }
                }
            }
        }
    }

    // 8. Consolidated Interactive HTML Card Sheet (Part J Sec 27-29)
    if (showHtmlExportSheet) {
        ModalBottomSheet(
            onDismissRequest = { showHtmlExportSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(stringResource(R.string.share_export_html), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.share_html_sheet_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(
                    onClick = { showHtmlExportSheet = false; showHtmlPreviewDialog = true },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.qa_label_preview), fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = {
                        showHtmlExportSheet = false
                        onLogShare("Interactive HTML Card")
                        scope.launch {
                            exportStageLabel = context.getString(R.string.share_stage_preparing_file)
                            CardLinkCanonicalRenderer.exportAndShareInteractiveHtml(context, effectiveShareCard)
                            exportStageLabel = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.share_html_share_btn), fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = {
                        showHtmlExportSheet = false
                        saveHtmlLauncher.launch("CardLink_${cardSlug}_Card.html")
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.share_html_save_btn), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // HTML Card Visual Preview Dialog
    if (showHtmlPreviewDialog) {
        val pkg = remember(effectiveShareCard, selectedSharingProfile) {
            CardLinkCanonicalRenderer.buildSharePackage(activeCard, selectedSharingProfile, SharePackageContentType.INTERACTIVE_HTML)
        }
        AlertDialog(
            onDismissRequest = { showHtmlPreviewDialog = false },
            title = { Text(stringResource(R.string.share_export_html), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FlippableBusinessCardView(card = effectiveShareCard)
                    Text(
                        text = "${stringResource(R.string.privacy_preview_sharing)}: ${pkg.includedFieldLabels.joinToString(" • ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showHtmlPreviewDialog = false
                    scope.launch { CardLinkCanonicalRenderer.exportAndShareInteractiveHtml(context, effectiveShareCard) }
                }) { Text(stringResource(R.string.share_html_share_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showHtmlPreviewDialog = false }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // 9. More Formats Sheet (Save .vcf to Device + Send as Message — Part K Sec 30-31)
    if (showMoreFormatsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMoreFormatsSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(stringResource(R.string.share_export_more_formats), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                QuickShareChoiceRow(Icons.Default.SaveAlt, stringResource(R.string.share_save_vcf_device), stringResource(R.string.share_method_vcf_sub)) {
                    showMoreFormatsSheet = false
                    saveVcfLauncher.launch("CardLink_$cardSlug.vcf")
                }
                QuickShareChoiceRow(Icons.Default.Chat, stringResource(R.string.share_send_as_msg_title), stringResource(R.string.share_send_as_msg_sub)) {
                    showMoreFormatsSheet = false
                    showSendMessageDialog = true
                }
            }
        }
    }

    // 10. Send as Message Editable Draft Dialog (User performs final Send — Part K Sec 31)
    if (showSendMessageDialog) {
        var msgDraft by remember(effectiveShareCard) { mutableStateOf(CardShareHelper.buildTextSummary(effectiveShareCard)) }
        AlertDialog(
            onDismissRequest = { showSendMessageDialog = false },
            title = { Text(stringResource(R.string.share_send_as_msg_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = msgDraft,
                        onValueChange = { msgDraft = it },
                        label = { Text(stringResource(R.string.net_msg_preview_lbl)) },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showSendMessageDialog = false
                    onLogShare("Send as Message")
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, msgDraft.trim())
                    }
                    context.startActivity(Intent.createChooser(intent, context.getString(R.string.share_send_as_msg_title)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text(stringResource(R.string.net_open_send_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showSendMessageDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ShareInstantTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String?,
    emphasized: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val a11y = if (badge != null) "$title ($badge) — $subtitle" else "$title — $subtitle"
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (emphasized) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(
            width = if (emphasized) 1.5.dp else 1.dp,
            color = if (emphasized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.22f)
        ),
        modifier = modifier
            .heightIn(min = 92.dp)
            .semantics { contentDescription = a11y }
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                if (badge != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = badge,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (emphasized) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ExportOptionRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QuickShareChoiceRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        }
    }
}
