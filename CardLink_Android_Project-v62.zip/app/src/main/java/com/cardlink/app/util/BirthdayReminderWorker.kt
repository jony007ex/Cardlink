package com.cardlink.app.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.data.local.CardLinkDatabase
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/**
 * Privacy-safe background WorkManager worker that checks Contacts' Dates of Birth
 * against the user's explicit Birthday Reminder preference (OFF, ON_DAY, 1_DAY, 7_DAYS).
 * Never exposes birth year or age on the lock screen (VISIBILITY_PRIVATE + publicVersion).
 */
class BirthdayReminderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val mode = DeviceContactSyncManager.getBirthdayReminderMode(ctx)
        if (mode == "OFF") return Result.success()
        if (!FollowUpScheduler.isNotificationsEffectivelyEnabled(ctx)) return Result.success()

        val targetDaysAhead = when (mode) {
            "ON_DAY" -> 0
            "1_DAY" -> 1
            "7_DAYS" -> 7
            else -> return Result.success()
        }

        BirthdayReminderScheduler.ensureChannel(ctx)
        val today = LocalDate.now()
        val todayKey = today.toString()
        val prefs = ctx.getSharedPreferences(PREFS_SENT, Context.MODE_PRIVATE)
        // Prune stale dedup keys from prior dates so SharedPreferences never grows unboundedly
        val staleKeys = prefs.all.keys.filter { it.startsWith("bday_") && !it.endsWith("_$todayKey") }
        if (staleKeys.isNotEmpty()) {
            prefs.edit().apply { staleKeys.forEach { remove(it) } }.apply()
        }

        runCatching {
            val contacts = CardLinkDatabase.getDatabase(ctx).dao().getAllContactsSnapshot()
            for (contact in contacts) {
                val info = ContactBirthdayHelper.computeBirthdayInfo(contact.dateOfBirthIso, today) ?: continue
                if (info.daysUntilNextBirthday != targetDaysAhead) continue

                val dedupKey = "bday_${contact.id}_${mode}_$todayKey"
                if (prefs.getBoolean(dedupKey, false)) continue

                showBirthdayNotification(ctx, contact.id, contact.fullName, targetDaysAhead)
                prefs.edit().putBoolean(dedupKey, true).apply()
            }
        }
        return Result.success()
    }

    private fun showBirthdayNotification(
        context: Context,
        contactId: Long,
        contactName: String,
        daysAhead: Int
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_route", "contact_detail/$contactId")
        }
        val pi = PendingIntent.getActivity(
            context,
            (900_000 + (contactId % 50_000L)).toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = when (daysAhead) {
            0 -> context.getString(R.string.bday_notif_today_title, contactName)
            1 -> context.getString(R.string.bday_notif_tomorrow_title, contactName)
            else -> context.getString(R.string.bday_notif_upcoming_title, contactName, daysAhead)
        }
        val body = context.getString(R.string.bday_notif_body)

        val publicVersion = NotificationCompat.Builder(context, BirthdayReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.bday_notif_lockscreen_private))
            .build()

        val notif = NotificationCompat.Builder(context, BirthdayReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify((800_000 + (contactId % 50_000L)).toInt(), notif)
    }

    companion object {
        private const val PREFS_SENT = "cardlink_bday_notif_sent_prefs"
    }
}

object BirthdayReminderScheduler {
    const val CHANNEL_ID = "cardlink_birthday_reminders_v1"
    private const val WORK_NAME = "cardlink_birthday_reminder_periodic"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Contact Birthday Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Optional privacy-safe reminders for upcoming contact birthdays"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            }
            nm.createNotificationChannel(ch)
        }
    }

    fun syncSchedule(context: Context) {
        val mode = DeviceContactSyncManager.getBirthdayReminderMode(context)
        val wm = WorkManager.getInstance(context.applicationContext)
        if (mode == "OFF") {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        ensureChannel(context)
        val periodic = PeriodicWorkRequestBuilder<BirthdayReminderWorker>(12, TimeUnit.HOURS).build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, periodic)

        // Also run a lightweight one-time check so an enabled reminder for today triggers promptly
        val immediate = OneTimeWorkRequestBuilder<BirthdayReminderWorker>().build()
        wm.enqueue(immediate)
    }
}
