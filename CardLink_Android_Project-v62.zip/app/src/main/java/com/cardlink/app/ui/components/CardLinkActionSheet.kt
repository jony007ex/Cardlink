package com.cardlink.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity

data class CardLinkSheetAction(
    val icon: ImageVector,
    val label: String,
    val isDestructive: Boolean = false,
    val onClick: () -> Unit
)

/**
 * Standardized Universal Action Sheet (⋮ More) consuming CardLink's active semantic theme.
 * Destructive actions are visually separated and rendered with MaterialTheme.colorScheme.error.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkActionSheet(
    title: String,
    actions: List<CardLinkSheetAction>,
    onDismiss: () -> Unit
) {
    val regularActions = actions.filterNot { it.isDestructive }
    val destructiveActions = actions.filter { it.isDestructive }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            regularActions.forEach { act ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable {
                            onDismiss()
                            act.onClick()
                        }
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(act.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    Text(act.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                }
            }
            if (destructiveActions.isNotEmpty()) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                destructiveActions.forEach { act ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clickable {
                                onDismiss()
                                act.onClick()
                            }
                            .padding(horizontal = 6.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(act.icon, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(22.dp))
                        Text(act.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

/**
 * Smart Privacy Preview displayed before sharing a CardLink Business Card.
 * Reflects the exact live BusinessCardEntity sharing flags (single source of truth).
 */
@Composable
fun SmartPrivacyPreviewCard(
    card: BusinessCardEntity,
    onUpdateSharingPreferences: (BusinessCardEntity) -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    val hasCredentials = remember(card.credentialsJson) {
        com.cardlink.app.util.BusinessCardProfileHelper.parseCredentials(card).isNotEmpty()
    }
    val phones = remember(card.phoneNumbersJson, card.phone, card.whatsapp) {
        com.cardlink.app.util.BusinessCardProfileHelper.parsePhoneNumbers(card)
    }
    val hasPhone = phones.isNotEmpty() || card.phone.isNotBlank()
    val hasWa = card.whatsapp.isNotBlank() || phones.any { it.isWhatsAppEnabled }

    val sharedFields = buildList {
        if (card.fullName.isNotBlank()) add("Name")
        if (hasCredentials && card.shareCredentials) add("Professional Credentials")
        if (card.designation.isNotBlank()) add("Job Title")
        if (card.companyName.isNotBlank()) add("Company")
        if (card.sharePhone && hasPhone) add("Work Phone")
        if (card.shareWhatsapp && hasWa) add("WhatsApp")
        if (card.shareEmail && card.email.isNotBlank()) add("Email")
        if (card.website.isNotBlank()) add("Website")
        if (card.shareSocials && (card.linkedInUrl.isNotBlank() || card.facebookUrl.isNotBlank())) add("Social Links")
        if (card.shareAddress && card.officeAddress.isNotBlank()) add("Office Address")
    }

    val excludedFields = buildList {
        if (hasCredentials && !card.shareCredentials) add("Professional Credentials")
        if (!card.sharePhone && hasPhone) add("Work Phone")
        if (!card.shareWhatsapp && hasWa) add("WhatsApp")
        if (!card.shareEmail && card.email.isNotBlank()) add("Email")
        if (!card.shareSocials && (card.linkedInUrl.isNotBlank() || card.facebookUrl.isNotBlank())) add("Social Links")
        if (!card.shareAddress && card.officeAddress.isNotBlank()) add("Office Address")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Column {
                        Text(stringResource(R.string.privacy_preview_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Text(
                            text = stringResource(R.string.share_fields_selected_count, sharedFields.size),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = { showEditDialog = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(stringResource(R.string.privacy_preview_edit_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Clean 2-column scannable checklist (shows top 4 compactly, expands to all fields)
            val displayShared = if (expanded) sharedFields else sharedFields.take(4)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                displayShared.chunked(2).forEach { rowPair ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowPair.forEach { fld ->
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text("✓", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(fld, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                            }
                        }
                        if (rowPair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                if (!expanded && sharedFields.size > 4) {
                    Text(
                        text = "+${sharedFields.size - 4} more",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { expanded = true }
                    )
                }
            }

            if (expanded && excludedFields.isNotEmpty()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    excludedFields.forEach { fld ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("○", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            Text(fld, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (showEditDialog) {
        var sharePhone by remember(card) { mutableStateOf(card.sharePhone) }
        var shareWhatsapp by remember(card) { mutableStateOf(card.shareWhatsapp) }
        var shareEmail by remember(card) { mutableStateOf(card.shareEmail) }
        var shareAddress by remember(card) { mutableStateOf(card.shareAddress) }
        var shareSocials by remember(card) { mutableStateOf(card.shareSocials) }
        var shareCredentials by remember(card) { mutableStateOf(card.shareCredentials) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text(stringResource(R.string.privacy_preview_edit_btn), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (hasCredentials) {
                        SharingPrefRow(stringResource(R.string.edit_credentials_title), shareCredentials) { shareCredentials = it }
                    }
                    SharingPrefRow(stringResource(R.string.detail_phone), sharePhone) { sharePhone = it }
                    SharingPrefRow("WhatsApp", shareWhatsapp) { shareWhatsapp = it }
                    SharingPrefRow(stringResource(R.string.detail_email), shareEmail) { shareEmail = it }
                    SharingPrefRow(stringResource(R.string.edit_office_address), shareAddress) { shareAddress = it }
                    SharingPrefRow(stringResource(R.string.cd_other_social_lbl), shareSocials) { shareSocials = it }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateSharingPreferences(
                        card.copy(
                            sharePhone = sharePhone,
                            shareWhatsapp = shareWhatsapp,
                            shareEmail = shareEmail,
                            shareAddress = shareAddress,
                            shareSocials = shareSocials,
                            shareCredentials = shareCredentials
                        )
                    )
                    showEditDialog = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun SharingPrefRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
