package com.cardlink.app.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.IdDocumentPageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class IdExportFormat(val label: String, val extension: String, val mimeType: String) {
    PDF("PDF", "pdf", "application/pdf"),
    JPG("JPG", "jpg", "image/jpeg"),
    PNG("PNG", "png", "image/png")
}

object IdShareHelper {

    /**
     * Saves ID page images into the AES-256-GCM Encrypted Image Vault (.clenc) in filesDir/my_ids/.
     */
    fun saveIdPageBitmap(context: Context, bitmap: Bitmap, labelPrefix: String = "page"): String {
        val scaled = scaleDown(bitmap, 1800)
        val uriStr = VaultCryptoManager.saveEncryptedBitmap(
            context = context,
            bitmap = scaled,
            subFolder = "my_ids",
            prefix = "id_$labelPrefix",
            quality = 90
        )
        if (scaled !== bitmap) scaled.recycle()
        return uriStr
    }

    suspend fun importUriAsIdPageImages(context: Context, uri: Uri): List<String> = withContext(Dispatchers.IO) {
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        if (mime.contains("pdf") || uri.toString().lowercase().endsWith(".pdf")) {
            renderPdfPagesToLocalImages(context, uri)
        } else {
            val bmp = ScannedCardStorageHelper.decodeGalleryUri(context, uri) ?: return@withContext emptyList()
            listOf(saveIdPageBitmap(context, bmp, "img"))
        }
    }

    private fun renderPdfPagesToLocalImages(context: Context, pdfUri: Uri): List<String> {
        val saved = mutableListOf<String>()
        runCatching {
            context.contentResolver.openFileDescriptor(pdfUri, "r")?.use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    val maxPages = renderer.pageCount.coerceAtMost(12)
                    for (i in 0 until maxPages) {
                        renderer.openPage(i).use { page ->
                            val scale = (1400f / page.width.coerceAtLeast(1)).coerceIn(1f, 2.5f)
                            val w = (page.width * scale).toInt().coerceAtLeast(1)
                            val h = (page.height * scale).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            Canvas(bmp).drawColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            saved.add(saveIdPageBitmap(context, bmp, "pdf_p${i + 1}"))
                            bmp.recycle()
                        }
                    }
                }
            }
        }
        return saved
    }

    suspend fun sharePages(
        context: Context,
        documentName: String,
        pages: List<IdDocumentPageEntity>,
        format: IdExportFormat,
        watermarkText: String? = null
    ): Result<Unit> = when (format) {
        IdExportFormat.PDF -> sharePagesAsPdf(context, documentName, pages, watermarkText).map { Unit }
        IdExportFormat.JPG -> sharePagesAsImages(context, documentName, pages, IdExportFormat.JPG, watermarkText)
        IdExportFormat.PNG -> sharePagesAsImages(context, documentName, pages, IdExportFormat.PNG, watermarkText)
    }

    suspend fun sharePagesAsPdf(
        context: Context,
        documentName: String,
        pages: List<IdDocumentPageEntity>,
        watermarkText: String? = null
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(pages.isNotEmpty()) { "No pages selected to share." }
            val pdf = PdfDocument()
            val pageW = 1080
            val pageH = 1528
            pages.forEachIndexed { index, pageEntity ->
                val rawBmp = decodeLocalImage(context, pageEntity.imageUri) ?: return@forEachIndexed
                val bmp = if (!watermarkText.isNullOrBlank()) applyDiagonalWatermark(rawBmp, watermarkText) else rawBmp
                val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val pad = 60
                val availW = pageW - pad * 2
                val availH = pageH - pad * 2
                val ratio = minOf(availW.toFloat() / bmp.width, availH.toFloat() / bmp.height)
                val drawW = (bmp.width * ratio).toInt()
                val drawH = (bmp.height * ratio).toInt()
                val left = (pageW - drawW) / 2
                val top = (pageH - drawH) / 2
                canvas.drawBitmap(bmp, null, Rect(left, top, left + drawW, top + drawH), null)
                pdf.finishPage(page)
                if (bmp !== rawBmp) bmp.recycle()
                rawBmp.recycle()
            }

            val outFile = TempSecureExportVault.createTempExportFile(context, "pdf")
            FileOutputStream(outFile).use { pdf.writeTo(it) }
            pdf.close()

            val uri = TempSecureExportVault.toShareUri(context, outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri(outFile.name, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share ID Document (PDF)").apply {
                clipData = ClipData.newRawUri(outFile.name, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            outFile
        }
    }

    private suspend fun sharePagesAsImages(
        context: Context,
        documentName: String,
        pages: List<IdDocumentPageEntity>,
        format: IdExportFormat,
        watermarkText: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(pages.isNotEmpty()) { "No pages selected to share." }
            val uris = ArrayList<Uri>()

            pages.forEachIndexed { _, pageEntity ->
                val rawBmp = decodeLocalImage(context, pageEntity.imageUri) ?: return@forEachIndexed
                val bmp = if (!watermarkText.isNullOrBlank()) applyDiagonalWatermark(rawBmp, watermarkText) else rawBmp
                val outFile = TempSecureExportVault.createTempExportFile(context, format.extension)
                FileOutputStream(outFile).use { out ->
                    if (format == IdExportFormat.JPG) {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    } else {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
                if (bmp !== rawBmp) bmp.recycle()
                rawBmp.recycle()
                uris.add(TempSecureExportVault.toShareUri(context, outFile))
            }

            require(uris.isNotEmpty()) { "Could not prepare ID image(s) for sharing." }

            val clip = ClipData.newRawUri("CardLink_ID", uris.first()).apply {
                for (i in 1 until uris.size) addItem(ClipData.Item(uris[i]))
            }
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = format.mimeType
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                    clipData = clip
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = format.mimeType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                    clipData = clip
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(Intent.createChooser(intent, "Share ID Document (${format.label})").apply {
                clipData = clip
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    /**
     * Renders a crisp, semi-transparent diagonal anti-misuse watermark across a copy of the ID bitmap.
     * Never alters the original stored ID image.
     */
    private fun applyDiagonalWatermark(source: Bitmap, text: String): Bitmap {
        val copy = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(copy)
        val w = copy.width.toFloat()
        val h = copy.height.toFloat()

        val textSize = (minOf(w, h) * 0.052f).coerceIn(22f, 56f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(92, 180, 30, 30)
            this.textSize = textSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(72, 255, 255, 255)
            this.textSize = textSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }

        canvas.save()
        canvas.rotate(-28f, w / 2f, h / 2f)
        val stepY = (h / 3.2f).coerceAtLeast(textSize * 3.2f)
        var y = -h * 0.25f
        while (y < h * 1.35f) {
            canvas.drawText(text, w / 2f, y, strokePaint)
            canvas.drawText(text, w / 2f, y, paint)
            y += stepY
        }
        canvas.restore()
        return copy
    }

    private fun decodeLocalImage(context: Context, uriStr: String): Bitmap? {
        return VaultCryptoManager.decodeVaultBitmapUncached(context, uriStr, 1800) ?: runCatching {
            val uri = Uri.parse(uriStr)
            if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
            else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }

    private fun scaleDown(src: Bitmap, maxEdge: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxEdge) return src
        val ratio = maxEdge.toFloat() / longest.toFloat()
        return Bitmap.createScaledBitmap(
            src,
            (src.width * ratio).toInt().coerceAtLeast(1),
            (src.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }
}
