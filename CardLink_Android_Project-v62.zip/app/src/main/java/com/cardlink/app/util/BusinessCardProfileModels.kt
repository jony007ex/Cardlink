package com.cardlink.app.util

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
enum class CardPhoneType(val id: String, val displayLabel: String) {
    MOBILE("MOBILE", "Mobile"),
    WORK("WORK", "Work"),
    OFFICE("OFFICE", "Office"),
    WHATSAPP("WHATSAPP", "WhatsApp"),
    PERSONAL("PERSONAL", "Personal"),
    OTHER("OTHER", "Other")
}

@Serializable
data class CardPhoneRecord(
    val id: String = UUID.randomUUID().toString(),
    val number: String,
    val type: CardPhoneType = CardPhoneType.MOBILE,
    val isPrimary: Boolean = false,
    val isWhatsAppEnabled: Boolean = false,
    val displayOrder: Int = 0
)

@Serializable
data class CardCredentialRecord(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val displayOrder: Int = 0,
    val visibleOnCard: Boolean = true
)

enum class MergeFieldChoice {
    KEEP_CURRENT,
    USE_SCANNED,
    KEEP_BOTH
}

data class ProfileMergeDiffItem(
    val fieldKey: String,
    val label: String,
    val currentValue: String,
    val scannedValue: String,
    val supportsKeepBoth: Boolean = false,
    val defaultChoice: MergeFieldChoice = MergeFieldChoice.USE_SCANNED
)

data class ExtractedProfileImport(
    val sourceLabel: String = "",
    val fullName: String = "",
    val credentials: List<String> = emptyList(),
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val phones: List<CardPhoneRecord> = emptyList(),
    val email: String = "",
    val website: String = "",
    val officeAddress: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val publicCardUrl: String = "",
    val rawWarning: String = ""
)

data class CardValidationReport(
    val isValid: Boolean,
    val fieldErrors: List<String> = emptyList(),
    val layoutWarnings: List<String> = emptyList()
)

object BusinessCardProfileHelper {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val COMMON_CREDENTIALS: List<String> = listOf(
        "MBA", "CFA", "ACCA", "FCMA", "CIPS", "MCIPS", "PhD", "PMP", "CPA", "FRM"
    )

    private val KNOWN_CREDENTIAL_SET = setOf(
        "MBA", "EMBA", "BBA", "CFA", "ACCA", "ACA", "FCA", "FCMA", "CMA", "CPA",
        "CIPS", "MCIPS", "FCIPS", "PHD", "PH.D.", "PH.D", "PMP", "FRM", "CAMS",
        "CDFP", "CISSP", "CISA", "CISM", "MD", "MBBS", "LLB", "LLM", "MSc", "BSc",
        "MSC", "BSC", "MSS", "BSS", "MCOM", "BCOM", "PE", "P.ENG", "ENG", "CA"
    )

    private val EMAIL_REGEX = Regex("""^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$""")

    // =========================================================================
    // PHONE & CREDENTIAL SERIALIZATION (Backward-Compatible with legacy phone/whatsapp)
    // =========================================================================

    fun parsePhoneNumbers(card: BusinessCardEntity): List<CardPhoneRecord> {
        if (card.phoneNumbersJson.isNotBlank()) {
            val parsed = runCatching {
                json.decodeFromString(ListSerializer(CardPhoneRecord.serializer()), card.phoneNumbersJson)
            }.getOrNull()
            if (!parsed.isNullOrEmpty()) {
                return normalizePhoneListOrderAndPrimary(parsed)
            }
        }
        // Safe transparent fallback for existing legacy profiles with single phone / whatsapp fields
        val migrated = mutableListOf<CardPhoneRecord>()
        val mainPhone = card.phone.trim()
        val waPhone = card.whatsapp.trim()
        val sameAsMain = mainPhone.isNotBlank() && waPhone.isNotBlank() &&
            normalizePhoneForComparison(mainPhone) == normalizePhoneForComparison(waPhone)

        if (mainPhone.isNotBlank()) {
            migrated.add(
                CardPhoneRecord(
                    id = "legacy_primary",
                    number = mainPhone,
                    type = CardPhoneType.MOBILE,
                    isPrimary = true,
                    isWhatsAppEnabled = sameAsMain,
                    displayOrder = 0
                )
            )
        }
        if (waPhone.isNotBlank() && !sameAsMain) {
            migrated.add(
                CardPhoneRecord(
                    id = "legacy_whatsapp",
                    number = waPhone,
                    type = CardPhoneType.WHATSAPP,
                    isPrimary = migrated.isEmpty(),
                    isWhatsAppEnabled = true,
                    displayOrder = migrated.size
                )
            )
        }
        return normalizePhoneListOrderAndPrimary(migrated)
    }

    fun serializePhoneNumbers(phones: List<CardPhoneRecord>): String {
        val clean = normalizePhoneListOrderAndPrimary(phones.filter { it.number.isNotBlank() })
        return if (clean.isEmpty()) "" else runCatching {
            json.encodeToString(ListSerializer(CardPhoneRecord.serializer()), clean)
        }.getOrDefault("")
    }

    fun normalizePhoneListOrderAndPrimary(phones: List<CardPhoneRecord>): List<CardPhoneRecord> {
        val nonBlank = phones.filter { it.number.isNotBlank() }
        if (nonBlank.isEmpty()) return emptyList()
        val ordered = nonBlank.sortedBy { it.displayOrder }
        val primaryIdx = ordered.indexOfFirst { it.isPrimary }.let { if (it >= 0) it else 0 }
        return ordered.mapIndexed { idx, rec ->
            rec.copy(
                number = rec.number.trim(),
                isPrimary = idx == primaryIdx,
                isWhatsAppEnabled = rec.isWhatsAppEnabled || rec.type == CardPhoneType.WHATSAPP,
                displayOrder = idx
            )
        }
    }

    fun parseCredentials(card: BusinessCardEntity): List<CardCredentialRecord> {
        if (card.credentialsJson.isBlank()) return emptyList()
        val parsed = runCatching {
            json.decodeFromString(ListSerializer(CardCredentialRecord.serializer()), card.credentialsJson)
        }.getOrNull().orEmpty()
        return normalizeCredentialOrder(parsed)
    }

    fun serializeCredentials(creds: List<CardCredentialRecord>): String {
        val clean = normalizeCredentialOrder(creds)
        return if (clean.isEmpty()) "" else runCatching {
            json.encodeToString(ListSerializer(CardCredentialRecord.serializer()), clean)
        }.getOrDefault("")
    }

    fun normalizeCredentialOrder(creds: List<CardCredentialRecord>): List<CardCredentialRecord> {
        return creds
            .map { it.copy(label = it.label.trim()) }
            .filter { it.label.isNotBlank() }
            .distinctBy { it.label.uppercase() }
            .sortedBy { it.displayOrder }
            .mapIndexed { idx, rec -> rec.copy(displayOrder = idx) }
    }

    /**
     * Updates BusinessCardEntity atomically with ordered phones & credentials while keeping
     * legacy `phone` and `whatsapp` columns synchronized for 100% zero-regression compatibility.
     */
    fun applyPhonesAndCredentials(
        card: BusinessCardEntity,
        phones: List<CardPhoneRecord>,
        credentials: List<CardCredentialRecord>,
        showCredentialsOnCard: Boolean = card.showCredentialsOnCard,
        shareCredentials: Boolean = card.shareCredentials
    ): BusinessCardEntity {
        val normPhones = normalizePhoneListOrderAndPrimary(phones)
        val normCreds = normalizeCredentialOrder(credentials)
        val primaryNum = normPhones.firstOrNull { it.isPrimary }?.number ?: normPhones.firstOrNull()?.number.orEmpty()
        val waNum = normPhones.firstOrNull { it.isWhatsAppEnabled }?.number
            ?: normPhones.firstOrNull { it.type == CardPhoneType.WHATSAPP }?.number
            ?: ""

        return card.copy(
            phone = primaryNum,
            whatsapp = waNum,
            phoneNumbersJson = serializePhoneNumbers(normPhones),
            credentialsJson = serializeCredentials(normCreds),
            showCredentialsOnCard = showCredentialsOnCard,
            shareCredentials = shareCredentials
        )
    }

    fun getVisibleCredentialsList(card: BusinessCardEntity, forSharing: Boolean = false): List<CardCredentialRecord> {
        if (forSharing && !card.shareCredentials) return emptyList()
        if (!forSharing && !card.showCredentialsOnCard) return emptyList()
        return parseCredentials(card).filter { it.visibleOnCard }
    }

    fun formatCredentialsSuffix(card: BusinessCardEntity, forSharing: Boolean = false): String {
        return getVisibleCredentialsList(card, forSharing).joinToString(", ") { it.label }
    }

    fun formatFullNameWithCredentials(card: BusinessCardEntity, forSharing: Boolean = false): String {
        val name = card.fullName.trim()
        val suffix = formatCredentialsSuffix(card, forSharing)
        return when {
            name.isBlank() -> ""
            suffix.isBlank() -> name
            else -> "$name, $suffix"
        }
    }

    fun getShareablePhoneNumbers(card: BusinessCardEntity): List<CardPhoneRecord> {
        val all = parsePhoneNumbers(card)
        return all.filter { rec ->
            when {
                rec.type == CardPhoneType.WHATSAPP -> card.shareWhatsapp
                rec.isPrimary -> card.sharePhone
                else -> card.sharePhone || (rec.isWhatsAppEnabled && card.shareWhatsapp)
            }
        }
    }

    // =========================================================================
    // PHONE NORMALIZATION & VALIDATION (Bangladesh + International + Extensions)
    // =========================================================================

    fun normalizePhoneForComparison(raw: String): String {
        val ascii = CardOcrPipeline.convertBanglaDigitsToAscii(raw).trim()
        if (ascii.isBlank()) return ""
        // Separate optional extension (ext / x)
        val extSplit = ascii.split(Regex("""(?i)\s*(?:ext\.?|x)\s*"""), limit = 2)
        val basePart = extSplit[0]
        val extPart = extSplit.getOrNull(1)?.filter { it.isDigit() }.orEmpty()

        val hasPlus = basePart.trim().startsWith("+")
        val digits = basePart.filter { it.isDigit() }
        if (digits.isBlank()) return ""

        val canonicalBase = when {
            digits.startsWith("01") && digits.length == 11 -> "+880${digits.drop(1)}"
            digits.startsWith("8801") && digits.length == 13 -> "+$digits"
            hasPlus -> "+$digits"
            else -> digits
        }
        return if (extPart.isNotBlank()) "${canonicalBase}x$extPart" else canonicalBase
    }

    fun isValidPhoneNumber(raw: String): Boolean {
        val trimmed = CardOcrPipeline.convertBanglaDigitsToAscii(raw).trim()
        if (trimmed.isBlank()) return false
        // Allow digits, +, -, spaces, parentheses, dots, and ext/x
        if (!Regex("""^[0-9+\-\s().extEXTxX/]+$""").matches(trimmed)) return false
        val basePart = trimmed.split(Regex("""(?i)\s*(?:ext\.?|x)\s*"""), limit = 2)[0]
        val digits = basePart.filter { it.isDigit() }
        // Accept local/office/international numbers (6 to 15 digits)
        return digits.length in 6..15
    }

    fun deduplicateAndMergePhones(
        existing: List<CardPhoneRecord>,
        incoming: List<CardPhoneRecord>
    ): List<CardPhoneRecord> {
        val result = normalizePhoneListOrderAndPrimary(existing).toMutableList()
        val seenKeys = result.map { normalizePhoneForComparison(it.number) }.filter { it.isNotBlank() }.toMutableSet()

        for (inc in incoming) {
            val cleanNum = inc.number.trim()
            val normKey = normalizePhoneForComparison(cleanNum)
            if (cleanNum.isBlank() || normKey.isBlank()) continue
            if (normKey !in seenKeys) {
                seenKeys.add(normKey)
                result.add(
                    inc.copy(
                        id = UUID.randomUUID().toString(),
                        number = cleanNum,
                        isPrimary = result.isEmpty(),
                        displayOrder = result.size
                    )
                )
            }
        }
        return normalizePhoneListOrderAndPrimary(result)
    }

    /**
     * Splits trailing professional credentials from a scanned name string, e.g.
     * "Md. Mazharul Islam, MBA, CIPS" -> ("Md. Mazharul Islam", ["MBA", "CIPS"])
     */
    fun extractNameAndCredentials(rawName: String): Pair<String, List<String>> {
        val trimmed = rawName.trim()
        if (!trimmed.contains(",")) return trimmed to emptyList()
        val parts = trimmed.split(",").map { it.trim() }.filter { it.isNotBlank() }
        if (parts.size < 2) return trimmed to emptyList()

        val foundCreds = mutableListOf<String>()
        val nameParts = mutableListOf(parts.first())
        for (p in parts.drop(1)) {
            val tokens = p.split(Regex("""[\s/]+""")).filter { it.isNotBlank() }
            val looksLikeCred = tokens.isNotEmpty() && tokens.all { tok ->
                val clean = tok.trim('.').uppercase()
                clean in KNOWN_CREDENTIAL_SET || (clean.length in 2..6 && clean.all { it.isUpperCase() || it == '.' })
            }
            if (looksLikeCred) {
                foundCreds.addAll(tokens.map { it.trim() })
            } else {
                nameParts.add(p)
            }
        }
        return nameParts.joinToString(", ") to foundCreds.distinctBy { it.uppercase() }
    }

    // =========================================================================
    // BUSINESS CARD & QR PROFILE IMPORT EXTRACTION (Untrusted External Input)
    // =========================================================================

    fun extractFromScannedContacts(
        front: SavedContactEntity?,
        back: SavedContactEntity?,
        sourceLabel: String = "Business Card Scan"
    ): ExtractedProfileImport {
        val merged = when {
            front != null && back != null -> BusinessCardOcrParser.mergeDualSide(front, back)
            front != null -> front
            back != null -> back
            else -> return ExtractedProfileImport(sourceLabel = sourceLabel, rawWarning = "No contact fields detected.")
        }

        val (cleanName, creds) = extractNameAndCredentials(merged.fullName)
        val rawPhones = mutableListOf<CardPhoneRecord>()
        listOfNotNull(front, back).forEach { side ->
            if (side.phone.isNotBlank() && isValidPhoneNumber(side.phone)) {
                rawPhones.add(CardPhoneRecord(number = side.phone.trim(), type = CardPhoneType.MOBILE, isPrimary = rawPhones.isEmpty()))
            }
            if (side.whatsapp.isNotBlank() && isValidPhoneNumber(side.whatsapp)) {
                rawPhones.add(CardPhoneRecord(number = side.whatsapp.trim(), type = CardPhoneType.WHATSAPP, isWhatsAppEnabled = true))
            }
        }
        val uniquePhones = deduplicateAndMergePhones(emptyList(), rawPhones)

        val cleanWebsite = sanitizeSafeUrl(merged.website)
        val cleanLinkedIn = sanitizeSafeUrl(merged.linkedInUrl)
        val cleanFacebook = sanitizeSafeUrl(merged.facebookUrl)

        return ExtractedProfileImport(
            sourceLabel = sourceLabel,
            fullName = cleanName,
            credentials = creds,
            designation = merged.designation.trim(),
            companyName = merged.companyName.trim(),
            department = merged.department.trim(),
            phones = uniquePhones,
            email = merged.email.trim().takeIf { EMAIL_REGEX.matches(it) }.orEmpty(),
            website = cleanWebsite,
            officeAddress = merged.officeAddress.trim(),
            linkedInUrl = cleanLinkedIn,
            facebookUrl = cleanFacebook
        )
    }

    fun extractFromQrPayload(rawPayload: String): ExtractedProfileImport {
        val trimmed = rawPayload.trim()
        if (trimmed.isBlank()) {
            return ExtractedProfileImport(sourceLabel = "QR Import", rawWarning = "Empty QR payload.")
        }
        val parsed = UniversalQrParser.parse(trimmed)
        if (parsed.securityStatus == QrSecurityStatus.POTENTIAL_RISK) {
            return ExtractedProfileImport(
                sourceLabel = "QR Import",
                rawWarning = parsed.warningMessage.ifBlank { "Potentially unsafe QR payload blocked." }
            )
        }

        return when (parsed.type) {
            UniversalQrType.VCARD -> extractFromVCardString(trimmed)
            UniversalQrType.MECARD -> extractFromMeCardString(trimmed, parsed.parsedContact)
            UniversalQrType.CARDLINK_PAYLOAD -> {
                val c = parsed.parsedContact
                if (c != null) extractFromScannedContacts(c, null, sourceLabel = "CardLink QR")
                else ExtractedProfileImport(sourceLabel = "CardLink QR", rawWarning = "Could not extract profile fields from CardLink QR.")
            }
            UniversalQrType.URL, UniversalQrType.SOCIAL, UniversalQrType.FILE_LINK -> {
                // Plain URL: NEVER guess Name, Phone or Company — offer ONLY for Digital Card Link!
                val safe = sanitizeSafeUrl(trimmed)
                if (safe.isNotBlank()) {
                    ExtractedProfileImport(
                        sourceLabel = "URL QR",
                        publicCardUrl = safe
                    )
                } else {
                    ExtractedProfileImport(sourceLabel = "QR Import", rawWarning = "Unsupported or invalid URL format.")
                }
            }
            else -> ExtractedProfileImport(
                sourceLabel = "QR Import",
                rawWarning = "This QR code (${parsed.type.label}) does not contain Business Card profile information."
            )
        }
    }

    private fun extractFromVCardString(rawVcard: String): ExtractedProfileImport {
        val baseContact = CardShareHelper.parseVCardToContact(rawVcard, source = "QR vCard")
        val (cleanName, fnCreds) = extractNameAndCredentials(baseContact.fullName)
        val allCreds = fnCreds.toMutableList()

        // Extract multiple TEL records + optional N: honorific suffix (5th semicolon component)
        val phones = mutableListOf<CardPhoneRecord>()
        val unfolded = rawVcard.replace(Regex("\r?\n[ \t]"), "")
        for (line in unfolded.lines()) {
            val t = line.trim()
            val upper = t.uppercase()
            if (upper.startsWith("TEL")) {
                val value = t.substringAfter(":", "").trim()
                if (value.isNotBlank() && isValidPhoneNumber(value)) {
                    val meta = upper.substringBefore(":")
                    val pType = when {
                        meta.contains("WHATSAPP") -> CardPhoneType.WHATSAPP
                        meta.contains("WORK") -> CardPhoneType.WORK
                        meta.contains("HOME") -> CardPhoneType.PERSONAL
                        meta.contains("CELL") -> CardPhoneType.MOBILE
                        else -> CardPhoneType.OTHER
                    }
                    phones.add(
                        CardPhoneRecord(
                            number = value,
                            type = pType,
                            isPrimary = phones.isEmpty(),
                            isWhatsAppEnabled = pType == CardPhoneType.WHATSAPP
                        )
                    )
                }
            } else if (upper.startsWith("N:") || upper.startsWith("N;")) {
                val nVal = t.substringAfter(":", "")
                val parts = nVal.split(";")
                if (parts.size >= 5 && parts[4].isNotBlank()) {
                    parts[4].split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { s ->
                        if (allCreds.none { it.equals(s, true) }) allCreds.add(s)
                    }
                }
            }
        }

        val uniquePhones = deduplicateAndMergePhones(emptyList(), phones)
        return ExtractedProfileImport(
            sourceLabel = "vCard QR",
            fullName = cleanName,
            credentials = allCreds,
            designation = baseContact.designation.trim(),
            companyName = baseContact.companyName.trim(),
            department = baseContact.department.trim(),
            phones = uniquePhones,
            email = baseContact.email.trim().takeIf { EMAIL_REGEX.matches(it) }.orEmpty(),
            website = sanitizeSafeUrl(baseContact.website),
            officeAddress = baseContact.officeAddress.trim(),
            linkedInUrl = sanitizeSafeUrl(baseContact.linkedInUrl),
            facebookUrl = sanitizeSafeUrl(baseContact.facebookUrl)
        )
    }

    private fun extractFromMeCardString(raw: String, fallbackContact: SavedContactEntity?): ExtractedProfileImport {
        val body = raw.removePrefix("MECARD:").removePrefix("mecard:")
        val phones = mutableListOf<CardPhoneRecord>()
        var urlVal = ""
        for (token in body.split(";")) {
            val k = token.substringBefore(":").uppercase().trim()
            val v = token.substringAfter(":", "").trim()
            if (k == "TEL" && v.isNotBlank() && isValidPhoneNumber(v)) {
                phones.add(CardPhoneRecord(number = v, type = if (phones.isEmpty()) CardPhoneType.MOBILE else CardPhoneType.WORK, isPrimary = phones.isEmpty()))
            } else if (k == "URL" && v.isNotBlank()) {
                urlVal = sanitizeSafeUrl(v)
            }
        }
        val (cleanName, creds) = extractNameAndCredentials(fallbackContact?.fullName.orEmpty())
        return ExtractedProfileImport(
            sourceLabel = "MECARD QR",
            fullName = cleanName,
            credentials = creds,
            designation = fallbackContact?.designation.orEmpty().trim(),
            companyName = fallbackContact?.companyName.orEmpty().trim(),
            phones = deduplicateAndMergePhones(emptyList(), phones),
            email = fallbackContact?.email.orEmpty().trim().takeIf { EMAIL_REGEX.matches(it) }.orEmpty(),
            website = urlVal.ifBlank { sanitizeSafeUrl(fallbackContact?.website.orEmpty()) },
            officeAddress = fallbackContact?.officeAddress.orEmpty().trim()
        )
    }

    private fun sanitizeSafeUrl(raw: String): String {
        val t = raw.trim()
        if (t.isBlank()) return ""
        val lower = t.lowercase()
        if (lower.startsWith("javascript:") || lower.startsWith("data:") || lower.startsWith("file:") || lower.startsWith("intent:")) {
            return ""
        }
        val normalized = if (lower.startsWith("http://") || lower.startsWith("https://")) t else "https://$t"
        return if (IphoneNfcShareHelper.validateDigitalCardUrlLocally(normalized).isValid) normalized else ""
    }

    // =========================================================================
    // SAFE FIELD-BY-FIELD DIFF & MERGE ENGINE (Never silently overwrites!)
    // =========================================================================

    fun computeMergeDiffs(
        current: BusinessCardEntity,
        imported: ExtractedProfileImport
    ): List<ProfileMergeDiffItem> {
        val diffs = mutableListOf<ProfileMergeDiffItem>()

        fun addSimpleDiff(key: String, label: String, cur: String, scan: String, caseInsensitive: Boolean = false) {
            val cTrim = cur.trim()
            val sTrim = scan.trim()
            if (sTrim.isBlank()) return
            val same = if (caseInsensitive) cTrim.equals(sTrim, ignoreCase = true) else cTrim == sTrim
            if (!same) {
                diffs.add(
                    ProfileMergeDiffItem(
                        fieldKey = key,
                        label = label,
                        currentValue = cTrim,
                        scannedValue = sTrim,
                        supportsKeepBoth = false,
                        defaultChoice = if (cTrim.isBlank()) MergeFieldChoice.USE_SCANNED else MergeFieldChoice.KEEP_CURRENT
                    )
                )
            }
        }

        addSimpleDiff("FULL_NAME", "Full Name", current.fullName, imported.fullName)

        // Credentials diff (supports Keep Both!)
        val curCreds = parseCredentials(current).map { it.label }
        val newCreds = imported.credentials.filter { inc -> curCreds.none { it.equals(inc, true) } }
        if (newCreds.isNotEmpty()) {
            diffs.add(
                ProfileMergeDiffItem(
                    fieldKey = "CREDENTIALS",
                    label = "Professional Credentials",
                    currentValue = curCreds.joinToString(", "),
                    scannedValue = imported.credentials.joinToString(", "),
                    supportsKeepBoth = curCreds.isNotEmpty(),
                    defaultChoice = if (curCreds.isEmpty()) MergeFieldChoice.USE_SCANNED else MergeFieldChoice.KEEP_BOTH
                )
            )
        }

        addSimpleDiff("DESIGNATION", "Designation", current.designation, imported.designation)
        addSimpleDiff("COMPANY", "Company", current.companyName, imported.companyName)
        addSimpleDiff("DEPARTMENT", "Department", current.department, imported.department)

        // Normalized Phone diff (deduplicates 01700... vs +8801700...; supports Keep Both!)
        val curPhones = parsePhoneNumbers(current)
        val curPhoneKeys = curPhones.map { normalizePhoneForComparison(it.number) }.toSet()
        val genuinelyNewPhones = imported.phones.filter { normalizePhoneForComparison(it.number) !in curPhoneKeys }
        if (genuinelyNewPhones.isNotEmpty()) {
            diffs.add(
                ProfileMergeDiffItem(
                    fieldKey = "PHONES",
                    label = "Phone Numbers",
                    currentValue = curPhones.joinToString(" • ") { it.number },
                    scannedValue = genuinelyNewPhones.joinToString(" • ") { it.number },
                    supportsKeepBoth = curPhones.isNotEmpty(),
                    defaultChoice = if (curPhones.isEmpty()) MergeFieldChoice.USE_SCANNED else MergeFieldChoice.KEEP_BOTH
                )
            )
        }

        addSimpleDiff("EMAIL", "Email", current.email, imported.email, caseInsensitive = true)
        addSimpleDiff("WEBSITE", "Website", current.website, imported.website, caseInsensitive = true)
        addSimpleDiff("ADDRESS", "Office Address", current.officeAddress, imported.officeAddress)
        addSimpleDiff("LINKEDIN", "LinkedIn", current.linkedInUrl, imported.linkedInUrl, caseInsensitive = true)
        addSimpleDiff("FACEBOOK", "Facebook", current.facebookUrl, imported.facebookUrl, caseInsensitive = true)
        addSimpleDiff("PUBLIC_URL", "Digital Card Link", current.publicCardUrl, imported.publicCardUrl, caseInsensitive = true)

        return diffs
    }

    fun applyMergeDecisions(
        current: BusinessCardEntity,
        imported: ExtractedProfileImport,
        decisions: Map<String, MergeFieldChoice>
    ): BusinessCardEntity {
        var out = current

        if (decisions["FULL_NAME"] == MergeFieldChoice.USE_SCANNED && imported.fullName.isNotBlank()) {
            out = out.copy(fullName = imported.fullName.trim())
        }
        if (decisions["DESIGNATION"] == MergeFieldChoice.USE_SCANNED && imported.designation.isNotBlank()) {
            out = out.copy(designation = imported.designation.trim())
        }
        if (decisions["COMPANY"] == MergeFieldChoice.USE_SCANNED && imported.companyName.isNotBlank()) {
            out = out.copy(companyName = imported.companyName.trim())
        }
        if (decisions["DEPARTMENT"] == MergeFieldChoice.USE_SCANNED && imported.department.isNotBlank()) {
            out = out.copy(department = imported.department.trim())
        }
        if (decisions["EMAIL"] == MergeFieldChoice.USE_SCANNED && imported.email.isNotBlank()) {
            out = out.copy(email = imported.email.trim())
        }
        if (decisions["WEBSITE"] == MergeFieldChoice.USE_SCANNED && imported.website.isNotBlank()) {
            out = out.copy(website = imported.website.trim())
        }
        if (decisions["ADDRESS"] == MergeFieldChoice.USE_SCANNED && imported.officeAddress.isNotBlank()) {
            out = out.copy(officeAddress = imported.officeAddress.trim(), latitude = null, longitude = null)
        }
        if (decisions["LINKEDIN"] == MergeFieldChoice.USE_SCANNED && imported.linkedInUrl.isNotBlank()) {
            out = out.copy(linkedInUrl = imported.linkedInUrl.trim())
        }
        if (decisions["FACEBOOK"] == MergeFieldChoice.USE_SCANNED && imported.facebookUrl.isNotBlank()) {
            out = out.copy(facebookUrl = imported.facebookUrl.trim())
        }
        if (decisions["PUBLIC_URL"] == MergeFieldChoice.USE_SCANNED && imported.publicCardUrl.isNotBlank()) {
            out = out.copy(publicCardUrl = imported.publicCardUrl.trim())
        }

        // Phones merge
        val curPhones = parsePhoneNumbers(out)
        val mergedPhones = when (decisions["PHONES"]) {
            MergeFieldChoice.USE_SCANNED -> normalizePhoneListOrderAndPrimary(imported.phones)
            MergeFieldChoice.KEEP_BOTH -> deduplicateAndMergePhones(curPhones, imported.phones)
            else -> curPhones
        }

        // Credentials merge
        val curCreds = parseCredentials(out)
        val incomingCredRecs = imported.credentials.mapIndexed { idx, lbl ->
            CardCredentialRecord(label = lbl.trim(), displayOrder = idx, visibleOnCard = true)
        }
        val mergedCreds = when (decisions["CREDENTIALS"]) {
            MergeFieldChoice.USE_SCANNED -> normalizeCredentialOrder(incomingCredRecs)
            MergeFieldChoice.KEEP_BOTH -> normalizeCredentialOrder(curCreds + incomingCredRecs.map { it.copy(displayOrder = curCreds.size + it.displayOrder) })
            else -> curCreds
        }

        return applyPhonesAndCredentials(out, mergedPhones, mergedCreds, out.showCredentialsOnCard, out.shareCredentials)
    }

    // =========================================================================
    // PRE-SAVE VALIDATION & VISUAL LAYOUT OVERFLOW CHECK (Sections 33-34)
    // =========================================================================

    fun validateDraft(draft: BusinessCardEntity): CardValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (draft.fullName.trim().isBlank()) {
            errors.add("Full Name is required.")
        }

        val phones = parsePhoneNumbers(draft)
        phones.forEach { p ->
            if (!isValidPhoneNumber(p.number)) {
                errors.add("Phone number '${p.number}' is not a valid phone format.")
            }
        }

        if (draft.email.isNotBlank() && !EMAIL_REGEX.matches(draft.email.trim())) {
            errors.add("Email address format looks invalid.")
        }

        if (draft.website.isNotBlank()) {
            val wNorm = if (draft.website.trim().startsWith("http", true)) draft.website.trim() else "https://${draft.website.trim()}"
            if (!IphoneNfcShareHelper.validateDigitalCardUrlLocally(wNorm).isValid) {
                errors.add("Website URL format is invalid.")
            }
        }

        if (draft.publicCardUrl.isNotBlank()) {
            val urlRes = IphoneNfcShareHelper.validateDigitalCardUrlLocally(draft.publicCardUrl)
            if (!urlRes.isValid) {
                errors.add("Digital Card Link: ${urlRes.errorMessage}")
            }
        }

        val creds = parseCredentials(draft)
        if (creds.any { it.label.length > 24 }) {
            errors.add("Each credential label should be 24 characters or fewer.")
        }

        // Visual Layout Overflow Heuristics (Section 34)
        val visibleCreds = getVisibleCredentialsList(draft, forSharing = false)
        val combinedNameLen = draft.fullName.trim().length + visibleCreds.sumOf { it.label.length + 2 }
        if (combinedNameLen > 48) {
            warnings.add("Name and credentials are quite long and will wrap onto a second line on compact templates.")
        }
        if (visibleCreds.size > 4) {
            warnings.add("Showing more than 4 credentials on the card front may crowd the header.")
        }
        if (draft.designation.trim().length > 52) {
            warnings.add("Designation text is long and may be truncated on some templates.")
        }
        if (draft.officeAddress.trim().length > 110) {
            warnings.add("Office address is long and may clip beyond 2 lines on the card front.")
        }
        if (draft.backMessage.trim().length > 180) {
            warnings.add("Back-side message exceeds the recommended 180 characters.")
        }

        return CardValidationReport(
            isValid = errors.isEmpty(),
            fieldErrors = errors,
            layoutWarnings = warnings
        )
    }
}
