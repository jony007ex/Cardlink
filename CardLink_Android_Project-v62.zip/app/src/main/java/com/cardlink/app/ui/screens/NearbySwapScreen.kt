package com.cardlink.app.ui.screens

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.nearby.BluetoothDiscoveryManager
import com.cardlink.app.nearby.NearbyCardExchangeManager
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.SharingProfileManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbySwapScreen(
    activeCard: BusinessCardEntity,
    bluetoothDiscoveryManager: BluetoothDiscoveryManager,
    onLogShare: (method: String, target: String) -> Unit,
    onSaveReceivedContact: (SavedContactEntity) -> Unit,
    onUseQrInstead: () -> Unit = {},
    onNavigateBack: () -> Unit = {}
) {
    val context = LocalContext.current
    var nearbyTab by remember { mutableIntStateOf(0) } // 0 = Instant Nearby Swap (BLE + Wi-Fi Direct), 1 = Classic Bluetooth
    val sharingProf = remember { SharingProfileManager.getActiveProfile(context) }
    val effectiveCard = remember(activeCard, sharingProf) { SharingProfileManager.applyProfile(activeCard, sharingProf) }

    val nearbyManager = remember { NearbyCardExchangeManager(context) }
    val isNearbyActive by nearbyManager.isActive.collectAsState()
    val statusText by nearbyManager.statusText.collectAsState()
    val peers by nearbyManager.discoveredPeers.collectAsState()
    val pendingAuth by nearbyManager.pendingAuth.collectAsState()
    val connectedPeer by nearbyManager.connectedPeerName.collectAsState()
    val cardSent by nearbyManager.cardSent.collectAsState()
    val receivedContact by nearbyManager.receivedContact.collectAsState()

    val pairedDevices by bluetoothDiscoveryManager.pairedDevices.collectAsState()
    val discoveredDevices by bluetoothDiscoveryManager.discoveredDevices.collectAsState()
    val isScanning by bluetoothDiscoveryManager.isScanning.collectAsState()
    var scanTimedOutNoPeer by remember { mutableStateOf(false) }

    LaunchedEffect(isNearbyActive, peers.size) {
        if (isNearbyActive && peers.isEmpty()) {
            scanTimedOutNoPeer = false
            kotlinx.coroutines.delay(15_000L)
            if (isNearbyActive && peers.isEmpty()) {
                scanTimedOutNoPeer = true
            }
        } else {
            scanTimedOutNoPeer = false
        }
    }

    fun requiredNearbyPermissions(): Array<String> {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.addAll(
                listOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                )
            )
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        return perms.toTypedArray()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (nearbyTab == 0) nearbyManager.startNearbySession(effectiveCard)
        else bluetoothDiscoveryManager.startDiscovery()
    }

    DisposableEffect(nearbyTab, effectiveCard) {
        permLauncher.launch(requiredNearbyPermissions())
        onDispose {
            nearbyManager.stopSession()
            bluetoothDiscoveryManager.stopDiscovery()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.share_method_nearby), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { pad ->
    Column(modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.nearby_swap_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.nearby_swap_subtitle), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = {
                onLogShare("Quick Share", "")
                CardShareHelper.shareViaQuickShare(context, effectiveCard)
            }) {
                Text(stringResource(R.string.share_quick_share_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        TabRow(selectedTabIndex = nearbyTab) {
            Tab(selected = nearbyTab == 0, onClick = { nearbyTab = 0 }, text = { Text("BLE + Wi-Fi Direct", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = nearbyTab == 1, onClick = { nearbyTab = 1 }, text = { Text(stringResource(R.string.nearby_tab_classic_bt), fontSize = 12.sp, fontWeight = FontWeight.Bold) })
        }

        if (nearbyTab == 0) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.WifiTethering, null, tint = MaterialTheme.colorScheme.primary)
                        Text(statusText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    }
                    if (isNearbyActive && !scanTimedOutNoPeer) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    if (connectedPeer != null && cardSent) {
                        Text("✓ Sent your card to $connectedPeer", style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                    }
                    if (scanTimedOutNoPeer && peers.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(stringResource(R.string.nearby_no_device_found_title), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            scanTimedOutNoPeer = false
                                            permLauncher.launch(requiredNearbyPermissions())
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(stringResource(R.string.qa_try_again_btn), fontSize = 12.sp) }
                                    OutlinedButton(
                                        onClick = onUseQrInstead,
                                        modifier = Modifier.weight(1f)
                                    ) { Text(stringResource(R.string.share_use_qr_instead_btn), fontSize = 12.sp) }
                                }
                            }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    scanTimedOutNoPeer = false
                                    permLauncher.launch(requiredNearbyPermissions())
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isNearbyActive) "Refresh Nearby Scan" else "Start Nearby Swap", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = onUseQrInstead,
                                modifier = Modifier.heightIn(min = 40.dp)
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(stringResource(R.string.share_use_qr_instead_btn), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 4-Digit Security Verification Prompt before accepting connection
            pendingAuth?.let { auth ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.nearby_confirm_code), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("Peer: ${auth.endpointName} • Code: ${auth.authDigits}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { nearbyManager.rejectPendingConnection() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.nearby_decline)) }
                            Button(onClick = {
                                onLogShare("Nearby (BLE + Wi-Fi Direct)", auth.endpointName)
                                nearbyManager.acceptPendingConnection()
                            }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.nearby_accept_swap), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }

            // Preview & Save Received Contact Card
            receivedContact?.let { incoming ->
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.2.dp, Color(0xFF10B981))) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.nearby_card_received), fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                        Text(incoming.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (incoming.companyName.isNotBlank()) Text(incoming.companyName, style = MaterialTheme.typography.bodySmall)
                        if (incoming.phone.isNotBlank()) Text(incoming.phone, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { nearbyManager.clearReceivedContact() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.nearby_dismiss)) }
                            Button(onClick = {
                                onSaveReceivedContact(incoming)
                                nearbyManager.clearReceivedContact()
                                Toast.makeText(context, "Saved ${incoming.fullName} to Contacts!", Toast.LENGTH_LONG).show()
                            }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.nfc_save_contact_btn), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(peers, key = { it.endpointId }) { peer ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        ListItem(
                            headlineContent = { Text(peer.endpointName, fontWeight = FontWeight.Bold) },
                            supportingContent = { Text(stringResource(R.string.nearby_peer_sub)) },
                            trailingContent = {
                                Button(onClick = { nearbyManager.requestConnectionToPeer(peer) }) { Text(stringResource(R.string.nearby_swap_btn)) }
                            }
                        )
                    }
                }
            }
        } else {
            // Classic Bluetooth Fallback
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.nearby_classic_devices), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Button(onClick = {
                    if (!bluetoothDiscoveryManager.isBluetoothEnabled()) context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                    else permLauncher.launch(requiredNearbyPermissions())
                }) { Text(if (isScanning) "Scanning..." else "Search") }
            }
            if (isScanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(discoveredDevices, key = { "d_${it.address}" }) { dev ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text(dev.address) }, trailingContent = {
                            Button(onClick = { onLogShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, effectiveCard) }) { Text(stringResource(R.string.nearby_send_btn)) }
                        })
                    }
                }
                items(pairedDevices, key = { "p_${it.address}" }) { dev ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text("${dev.address} • Paired") }, trailingContent = {
                            Button(onClick = { onLogShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, effectiveCard) }) { Text(stringResource(R.string.nearby_send_btn)) }
                        })
                    }
                }
            }
        }
    }
    }
}
