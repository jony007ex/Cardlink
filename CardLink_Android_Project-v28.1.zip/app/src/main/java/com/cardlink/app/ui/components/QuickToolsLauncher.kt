package com.cardlink.app.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.CanonicalToolMeta
import com.cardlink.app.util.SecurityHardeningManager
import com.cardlink.app.util.ToolsRegistry

/**
 * Dynamic My Card "+" Quick Tools launcher.
 * Reads directly from the single-source-of-truth favoriteToolIds StateFlow (Tools -> Favorites).
 * Automatically hides sensitive shortcuts when Panic Lock or Privacy/Decoy Mode is active.
 */
@Composable
fun MyCardQuickToolsButton(
    favoriteToolIds: List<String>,
    onLaunchTool: (CanonicalToolMeta) -> Unit,
    onManageFavorites: () -> Unit
) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }

    // Ensure launcher closes when leaving My Card
    DisposableEffect(Unit) {
        onDispose { expanded = false }
    }

    // Close on Android Back press
    BackHandler(enabled = expanded) {
        expanded = false
    }

    val hideSensitive = SecurityHardeningManager.isSensitiveAreaHidden(context)
    val activeFavorites = remember(favoriteToolIds, hideSensitive) {
        favoriteToolIds
            .mapNotNull { ToolsRegistry.findById(it) }
            .filter { it.quickActionEligible && (!hideSensitive || !it.isSensitive) }
            .take(4)
    }

    val iconRotation by animateFloatAsState(
        targetValue = if (expanded) 45f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "quick_tools_rot"
    )
    val a11yLabel = stringResource(R.string.quick_tools_label)

    Box(contentAlignment = Alignment.Center) {
        Surface(
            onClick = { expanded = !expanded },
            shape = CircleShape,
            color = GoldAccent,
            contentColor = NavyPrimary,
            shadowElevation = 3.dp,
            modifier = Modifier
                .size(44.dp)
                .semantics { contentDescription = a11yLabel }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = a11yLabel,
                    modifier = Modifier.size(22.dp).rotate(iconRotation)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.widthIn(min = 210.dp, max = 270.dp)
        ) {
            Text(
                text = stringResource(R.string.quick_tools_label),
                style = MaterialTheme.typography.labelSmall,
                color = GoldAccent,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

            if (activeFavorites.isEmpty()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.StarBorder, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.quick_tools_empty_title), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text(
                        text = stringResource(R.string.quick_tools_empty_msg),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                    )
                    OutlinedButton(
                        onClick = {
                            expanded = false
                            onManageFavorites()
                        },
                        border = BorderStroke(1.dp, GoldAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.quick_tools_manage_btn), color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                activeFavorites.forEach { tool ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = stringResource(tool.quickActionLabelRes),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = tool.icon,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            expanded = false
                            onLaunchTool(tool)
                        }
                    )
                }
            }
        }
    }
}
