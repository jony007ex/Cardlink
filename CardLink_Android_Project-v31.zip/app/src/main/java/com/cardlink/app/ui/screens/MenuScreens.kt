package com.cardlink.app.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.tile.CardLinkTileService
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.components.BackupRestoreSection
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import androidx.compose.foundation.border
import com.cardlink.app.util.BiometricLockHelper
import com.cardlink.app.util.VaultCryptoManager
import com.cardlink.app.util.ContactActionLauncher
import com.cardlink.app.util.FollowUpScheduler
import com.cardlink.app.util.LanguageManager

@Composable
fun MenuScreen(
    onOpenSettings: () -> Unit,
    onOpenInsights: () -> Unit,
    onOpenWidgets: () -> Unit,
    onOpenFeedback: () -> Unit,
    onOpenHelpTips: () -> Unit,
    onOpenAbout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = stringResource(R.string.menu_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.menu_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        Spacer(Modifier.height(2.dp))

        MenuRowCard(
            icon = Icons.Default.Settings,
            title = stringResource(R.string.menu_settings),
            subtitle = stringResource(R.string.menu_settings_sub),
            onClick = onOpenSettings
        )

        MenuRowCard(
            icon = Icons.Default.Analytics,
            title = stringResource(R.string.menu_insights),
            subtitle = stringResource(R.string.menu_insights_sub),
            onClick = onOpenInsights
        )

        MenuRowCard(
            icon = Icons.Default.Widgets,
            title = stringResource(R.string.menu_widgets),
            subtitle = stringResource(R.string.menu_widgets_sub),
            onClick = onOpenWidgets
        )

        MenuRowCard(
            icon = Icons.Default.Forum,
            title = stringResource(R.string.menu_feedback_community),
            subtitle = stringResource(R.string.menu_feedback_community_sub),
            onClick = onOpenFeedback
        )

        MenuRowCard(
            icon = Icons.Default.HelpOutline,
            title = stringResource(R.string.menu_help_tips),
            subtitle = stringResource(R.string.menu_help_tips_sub),
            onClick = onOpenHelpTips
        )

        MenuRowCard(
            icon = Icons.Default.Info,
            title = stringResource(R.string.menu_about),
            subtitle = stringResource(R.string.menu_about_sub),
            onClick = onOpenAbout
        )
    }
}

@Composable
private fun MenuRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneralSettingsScreen(
    notificationsEnabled: Boolean,
    onToggleNotifications: (Boolean) -> Unit,
    currentLanguageCode: String,
    darkThemeOverride: Boolean?,
    onOpenPrivacy: () -> Unit,
    onOpenBackupExport: () -> Unit,
    onOpenLanguage: () -> Unit,
    onOpenAppearance: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var hasOsNotifPermission by remember {
        mutableStateOf(FollowUpScheduler.hasNotificationPermission(context))
    }

    val notifPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasOsNotifPermission = granted
        if (granted) {
            onToggleNotifications(true)
            Toast.makeText(context, "Notifications enabled", Toast.LENGTH_SHORT).show()
        } else {
            onToggleNotifications(false)
            Toast.makeText(context, "Notification permission denied", Toast.LENGTH_LONG).show()
        }
    }

    val effectiveNotifOn = notificationsEnabled && hasOsNotifPermission
    val currentLangLabel = if (currentLanguageCode == LanguageManager.LANG_BANGLA) {
        stringResource(R.string.language_bangla)
    } else {
        stringResource(R.string.language_english)
    }
    val currentAppearanceLabel = when (darkThemeOverride) {
        false -> stringResource(R.string.theme_light)
        true -> stringResource(R.string.theme_dark)
        null -> stringResource(R.string.theme_system)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_settings), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Notifications ON/OFF Switch
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.settings_notifications),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = stringResource(R.string.settings_notifications_sub),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                    Switch(
                        checked = effectiveNotifOn,
                        onCheckedChange = { enable ->
                            if (enable) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    !FollowUpScheduler.hasNotificationPermission(context)
                                ) {
                                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    hasOsNotifPermission = true
                                    onToggleNotifications(true)
                                }
                            } else {
                                onToggleNotifications(false)
                            }
                        }
                    )
                }
            }

            // 2. Privacy
            MenuRowCard(
                icon = Icons.Default.Shield,
                title = stringResource(R.string.menu_privacy),
                subtitle = stringResource(R.string.settings_privacy_sub),
                onClick = onOpenPrivacy
            )

            // 3. Backup & Export
            MenuRowCard(
                icon = Icons.Default.CloudUpload,
                title = stringResource(R.string.menu_backup_export),
                subtitle = stringResource(R.string.menu_backup_export_sub),
                onClick = onOpenBackupExport
            )

            // 4. Language
            MenuRowCard(
                icon = Icons.Default.Translate,
                title = stringResource(R.string.menu_language),
                subtitle = "${stringResource(R.string.menu_language_sub)} • $currentLangLabel",
                onClick = onOpenLanguage
            )

            // 5. Appearance
            MenuRowCard(
                icon = Icons.Default.DarkMode,
                title = stringResource(R.string.settings_appearance),
                subtitle = "${stringResource(R.string.settings_appearance_sub)} • $currentAppearanceLabel",
                onClick = onOpenAppearance
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen(
    currentLanguageCode: String,
    onSelectLanguage: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val options = listOf(
        Triple(LanguageManager.LANG_ENGLISH, "🇬🇧  ${stringResource(R.string.language_english)}", stringResource(R.string.language_english_sub)),
        Triple(LanguageManager.LANG_BANGLA, "🇧🇩  ${stringResource(R.string.language_bangla)}", stringResource(R.string.language_bangla_sub))
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.language_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = stringResource(R.string.language_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
            )

            options.forEach { (code, title, subtitle) ->
                val isSelected = currentLanguageCode == code
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSelectLanguage(code) },
                    shape = RoundedCornerShape(16.dp),
                    border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettingsScreen(
    activeCard: BusinessCardEntity,
    quickPrivacyMode: Boolean,
    auditLogs: List<com.cardlink.app.data.model.SecurityAuditLogEntity> = emptyList(),
    onClearAuditLogs: () -> Unit = {},
    onToggleQuickPrivacy: () -> Unit,
    onSaveCard: (BusinessCardEntity) -> Unit,
    onLockNow: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var draft by remember(activeCard) { mutableStateOf(activeCard) }
    var bioEnabled by remember { mutableStateOf(BiometricLockHelper.isLockEnabled(context)) }
    val enabledMsg = stringResource(R.string.privacy_lock_enabled_toast)
    val disabledMsg = stringResource(R.string.privacy_lock_disabled_toast)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_privacy), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.privacy_card_sharing), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.privacy_share_phone))
                        Switch(checked = draft.sharePhone, onCheckedChange = { draft = draft.copy(sharePhone = it); onSaveCard(draft) })
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.privacy_share_email))
                        Switch(checked = draft.shareEmail, onCheckedChange = { draft = draft.copy(shareEmail = it); onSaveCard(draft) })
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.privacy_share_address))
                        Switch(checked = draft.shareAddress, onCheckedChange = { draft = draft.copy(shareAddress = it); onSaveCard(draft) })
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.general_quick_privacy), fontWeight = FontWeight.Medium)
                            Text(
                                stringResource(R.string.general_quick_privacy_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        Switch(checked = quickPrivacyMode, onCheckedChange = { onToggleQuickPrivacy() })
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.privacy_biometric_lock), fontWeight = FontWeight.Bold)
                            Text(
                                stringResource(R.string.privacy_biometric_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        Switch(
                            checked = bioEnabled,
                            onCheckedChange = { enable ->
                                bioEnabled = enable
                                BiometricLockHelper.setLockEnabled(context, enable)
                                Toast.makeText(context, if (enable) enabledMsg else disabledMsg, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    if (bioEnabled) {
                        OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Lock, null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.privacy_lock_test_now))
                        }
                    }
                }
            }

            // Zero-Knowledge Data-at-Rest & Smart Privacy Status Card
            val vaultEncrypted = remember { VaultCryptoManager.isVaultActive(context) }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.VerifiedUser, null, tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.security_vault_card_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        text = if (vaultEncrypted) stringResource(R.string.security_db_encrypted_active)
                        else stringResource(R.string.security_db_encrypted_ready),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(stringResource(R.string.security_image_vault_active), style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.security_clipboard_active), style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.security_watermark_capture_active), style = MaterialTheme.typography.bodySmall)
                }
            }

            // Smart Inactivity Auto-Lock, Panic Lock, Decoy Mode, Integrity & Security Activity
            var autoLock by remember { mutableStateOf(com.cardlink.app.util.SecurityHardeningManager.getAutoLockDuration(context)) }
            var panicActive by remember { mutableStateOf(com.cardlink.app.util.SecurityHardeningManager.isPanicLockActive(context)) }
            var decoyActive by remember { mutableStateOf(com.cardlink.app.util.SecurityHardeningManager.isDecoyModeActive(context)) }
            val integrity = remember { com.cardlink.app.util.SecurityHardeningManager.evaluateRuntimeIntegrity(context) }
            var showAuditDialog by remember { mutableStateOf(false) }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.security_autolock_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.cardlink.app.util.AutoLockDuration.values().forEach { dur ->
                            FilterChip(
                                selected = autoLock == dur,
                                onClick = {
                                    autoLock = dur
                                    com.cardlink.app.util.SecurityHardeningManager.setAutoLockDuration(context, dur)
                                },
                                label = { Text(dur.labelKey, fontSize = 11.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.security_panic_lock_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(stringResource(R.string.security_panic_lock_sub), style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = panicActive,
                            onCheckedChange = {
                                panicActive = it
                                com.cardlink.app.util.SecurityHardeningManager.setPanicLockActive(context, it)
                            }
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.security_decoy_mode_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(stringResource(R.string.security_decoy_mode_sub), style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = decoyActive,
                            onCheckedChange = {
                                decoyActive = it
                                com.cardlink.app.util.SecurityHardeningManager.setDecoyModeActive(context, it)
                            }
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Text(
                        text = "Runtime Integrity: ${integrity.riskLevel.label}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (integrity.riskLevel == com.cardlink.app.util.RuntimeRiskLevel.NORMAL) Color(0xFF10B981) else Color(0xFFF59E0B)
                    )
                    if (integrity.signals.isNotEmpty()) {
                        Text(integrity.signals.joinToString(" • "), style = MaterialTheme.typography.labelSmall)
                    }

                    OutlinedButton(onClick = { showAuditDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.History, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${stringResource(R.string.security_audit_title)} (${auditLogs.size})")
                    }
                }
            }

            if (showAuditDialog) {
                val fmtAudit = remember { java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()) }
                AlertDialog(
                    onDismissRequest = { showAuditDialog = false },
                    title = { Text(stringResource(R.string.security_audit_title), fontWeight = FontWeight.Bold) },
                    text = {
                        Column(modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (auditLogs.isEmpty()) {
                                Text("No security events recorded yet.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                auditLogs.take(40).forEach { log ->
                                    Text(
                                        text = "${fmtAudit.format(java.util.Date(log.timestamp))} • [${log.featureTag}] ${log.safeDetail.ifBlank { log.eventType }}",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    },
                    confirmButton = {
                        if (auditLogs.isNotEmpty()) {
                            TextButton(onClick = { onClearAuditLogs(); showAuditDialog = false }) {
                                Text("Clear History", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    },
                    dismissButton = { TextButton(onClick = { showAuditDialog = false }) { Text(stringResource(R.string.action_close)) } }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupExportScreen(
    viewModel: CardLinkViewModel,
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_backup_export), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            BackupRestoreSection(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WidgetsMenuScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_widgets), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.DashboardCustomize, null, tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.widgets_qs_tile_title), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Text(
                        stringResource(R.string.widgets_qs_tile_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                    )
                    Button(
                        onClick = {
                            CardLinkTileService.requestAddTile(context) { msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddCircleOutline, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.widgets_add_qs_tile), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.QrCode2, null, tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.widgets_home_qr_title), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Text(
                        stringResource(R.string.widgets_home_qr_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DarkModeScreen(
    darkThemeOverride: Boolean?,
    currentAppTheme: com.cardlink.app.util.AppCustomThemeConfig,
    onSelectTheme: (Boolean?) -> Unit,
    onOpenThemeStudio: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val options = listOf(
        Triple(false, stringResource(R.string.theme_light), stringResource(R.string.theme_light_desc)),
        Triple(true, stringResource(R.string.theme_dark), stringResource(R.string.theme_dark_desc)),
        Triple(null, stringResource(R.string.theme_system), stringResource(R.string.theme_system_desc))
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_appearance), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                stringResource(R.string.theme_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
            )

            options.forEach { (value, title, desc) ->
                val isSelected = darkThemeOverride == value
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSelectTheme(value) },
                    shape = RoundedCornerShape(16.dp),
                    border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        RadioButton(selected = isSelected, onClick = { onSelectTheme(value) })
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.theme_colors_title),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onOpenThemeStudio),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(stringResource(R.string.theme_colors_title), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            stringResource(R.string.theme_colors_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(Color(currentAppTheme.backgroundHex.toInt())))
                            Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(Color(currentAppTheme.buttonHex.toInt())))
                            Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(Color(currentAppTheme.secondaryHex.toInt())))
                            Text(
                                text = currentAppTheme.themeName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutCreditsScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val versionInfo = remember {
        runCatching {
            val pi = context.packageManager.getPackageInfo(context.packageName, 0)
            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
            "Version ${pi.versionName} (Build $code)"
        }.getOrNull()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_about), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.size(120.dp),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.cardlink_welcome_brand),
                    contentDescription = "CardLink Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("CardLink", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                if (!versionInfo.isNullOrBlank()) {
                    Text(
                        text = versionInfo,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.about_concept_by),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                        Text(
                            text = "Md. Mazharul Islam",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    ContactActionLauncher.launchWhatsAppChat(
                                        context = context,
                                        rawNumber = "+8801700799353",
                                        recipientName = "Md. Mazharul Islam"
                                    )
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = stringResource(R.string.about_whatsapp_label),
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    runCatching {
                                        context.startActivity(
                                            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:jony007ex@gmail.com")).apply {
                                                putExtra(Intent.EXTRA_EMAIL, arrayOf("jony007ex@gmail.com"))
                                            }
                                        )
                                    }
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Email, contentDescription = "Email", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Email: jony007ex@gmail.com",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .size(78.dp)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        shape = CircleShape,
                        shadowElevation = 4.dp
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.developer_profile_mazharul),
                            contentDescription = "Md. Mazharul Islam",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    }
                }
            }
        }
    }
}
