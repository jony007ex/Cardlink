package com.cardlink.app.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.onPrimary
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.surface
import com.cardlink.app.util.CanonicalToolMeta
import com.cardlink.app.util.SecurityHardeningManager
import com.cardlink.app.util.ToolsRegistry

/**
 * Floating bottom-right "+" Quick Tools Speed-Dial for My Card.
 * Matches My Contacts' FAB design tokens (size, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary, CircleShape,
 * 18dp bottom/end insets, 200ms upward speed-dial animation, translucent backdrop scrim).
 * Reads directly from the single-source-of-truth favoriteToolIds StateFlow (Tools -> Favorites).
 */
@Composable
fun BoxScope.MyCardFloatingQuickToolsOverlay(
    favoriteToolIds: List<String>,
    onLaunchTool: (CanonicalToolMeta) -> Unit,
    onManageFavorites: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    // Always collapse when leaving My Card or switching tabs
    DisposableEffect(Unit) {
        onDispose { isExpanded = false }
    }

    // Intercept Android Back when expanded
    BackHandler(enabled = isExpanded) {
        isExpanded = false
    }

    val hideSensitive = SecurityHardeningManager.isSensitiveAreaHidden(context)
    val activeFavorites = remember(favoriteToolIds, hideSensitive) {
        favoriteToolIds
            .mapNotNull { ToolsRegistry.findById(it) }
            .filter { it.quickActionEligible && (!hideSensitive || !it.isSensitive) }
            .take(4)
    }

    val fabRotation by animateFloatAsState(
        targetValue = if (isExpanded) 45f else 0f,
        animationSpec = tween(durationMillis = 200),
        label = "mycard_fab_rotation"
    )

    val openLabel = stringResource(R.string.quick_tools_open)
    val closeLabel = stringResource(R.string.quick_tools_close)
    val baseLabel = stringResource(R.string.quick_tools_label)

    // Translucent backdrop scrim: tap outside to dismiss
    if (isExpanded) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.42f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { isExpanded = false }
        )
    }

    // Anchored Bottom-Right Speed-Dial Column matching Contacts FAB
    Column(
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 18.dp, bottom = 18.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        AnimatedVisibility(
            visible = isExpanded,
            enter = fadeIn(tween(200)) + expandVertically(tween(200), expandFrom = Alignment.Bottom),
            exit = fadeOut(tween(180)) + shrinkVertically(tween(180), shrinkTowards = Alignment.Bottom)
        ) {
            if (activeFavorites.isEmpty()) {
                Card(
                    modifier = Modifier.widthIn(min = 220.dp, max = 270.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.StarBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = stringResource(R.string.quick_tools_empty_title),
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        }
                        Text(
                            text = stringResource(R.string.quick_tools_empty_msg),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = {
                                isExpanded = false
                                onManageFavorites()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = stringResource(R.string.quick_tools_manage_btn),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    activeFavorites.forEach { tool ->
                        val actionTitle = stringResource(tool.quickActionLabelRes)
                        Surface(
                            onClick = {
                                isExpanded = false
                                onLaunchTool(tool)
                            },
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                            shadowElevation = 6.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = tool.icon,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = actionTitle,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { isExpanded = !isExpanded },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = CircleShape,
            modifier = Modifier.semantics {
                contentDescription = if (isExpanded) closeLabel else openLabel
                stateDescription = if (isExpanded) "$baseLabel Expanded" else baseLabel
            }
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = if (isExpanded) closeLabel else openLabel,
                modifier = Modifier.rotate(fabRotation)
            )
        }
    }
}
