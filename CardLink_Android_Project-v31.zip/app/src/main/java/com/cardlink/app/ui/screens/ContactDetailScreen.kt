package com.cardlink.app.ui.screens

import android.Manifest
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cardlink.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contact: SavedContactEntity,
    mySenderName: String,
    mySenderCompany: String = "",
    contactFollowUps: List<FollowUpEntity> = emptyList(),
    onSaveContact: (SavedContactEntity, String?) -> Unit,
    onAddFollowUp: (FollowUpEntity) -> Unit = {},
    onToggleFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteContact: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isEditingNumbers by remember(contact.id) { mutableStateOf(false) }
    var phoneDraft by remember(contact) { mutableStateOf(contact.phone) }
    var whatsappDraft by remember(contact) { mutableStateOf(contact.whatsapp) }
    var showWaScheduleConfirmDialog by remember { mutableStateOf<SavedContactEntity?>(null) }

    var notes by remember(contact) { mutableStateOf(contact.notes) }
    var selectedTag by remember(contact) { mutableStateOf(contact.categoryTag) }
    var currentLat by remember(contact) { mutableStateOf(contact.latitude) }
    var currentLng by remember(contact) { mutableStateOf(contact.longitude) }
    var userGps by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var showTemplateSheetFor by remember { mutableStateOf<String?>(null) }
    var newActionTitle by remember { mutableStateOf("") }

    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val whatsAppTarget = contact.whatsapp.ifBlank { contact.phone }
    val tagOptions = listOf("General", "Client", "Vendor", "VIP", "Colleague", "Event")
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val hasPendingWaSchedules = remember(contactFollowUps) { contactFollowUps.any { !it.isCompleted && it.channel == "WHATSAPP" && it.status != "CANCELLED" } }

    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                val ts = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                notes = if (notes.isBlank()) "[$ts (Voice Note)] $spokenText" else "$notes\n[$ts (Voice Note)] $spokenText"
            }
        }
    }

    LaunchedEffect(contact.officeAddress) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
        if ((currentLat == null || currentLng == null) && contact.officeAddress.isNotBlank()) {
            GeoLocationHelper.geocodeAddress(context, contact.officeAddress)?.let { (la, lo) ->
                currentLat = la; currentLng = lo
                onSaveContact(contact.copy(latitude = la, longitude = lo), null)
            }
        }
    }

    val distanceKm = remember(userGps, currentLat, currentLng) {
        val u = userGps; val la = currentLat; val lo = currentLng
        if (u != null && la != null && lo != null) GeoLocationHelper.distanceInKm(u.first, u.second, la, lo) else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { CardShareHelper.exportToAndroidContacts(context, contact) }) { Icon(Icons.Default.PersonAdd, null) }
                    IconButton(onClick = onDeleteContact) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!contact.profilePhotoUri.isNullOrBlank() || !contact.backPhotoUri.isNullOrBlank()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!contact.profilePhotoUri.isNullOrBlank()) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (!contact.backPhotoUri.isNullOrBlank()) Text(stringResource(R.string.detail_front_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Card(modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)), shape = RoundedCornerShape(14.dp)) {
                                AsyncImage(model = Uri.parse(contact.profilePhotoUri), contentDescription = "Front Card", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                        }
                    }
                    if (!contact.backPhotoUri.isNullOrBlank()) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(stringResource(R.string.detail_back_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Card(modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)), shape = RoundedCornerShape(14.dp)) {
                                AsyncImage(model = Uri.parse(contact.backPhotoUri), contentDescription = "Back Card", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                        }
                    }
                }
            }
            Text("${contact.designation} • ${contact.companyName}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_phone_wa_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (!isEditingNumbers) {
                            TextButton(onClick = { phoneDraft = contact.phone; whatsappDraft = contact.whatsapp; isEditingNumbers = true }) { Text(stringResource(R.string.action_edit)) }
                        }
                    }
                    if (!isEditingNumbers) {
                        Text("${stringResource(R.string.detail_phone)}: ${contact.phone.ifBlank { stringResource(R.string.detail_not_set) }}", fontSize = 13.sp)
                        Text("${stringResource(R.string.detail_whatsapp)}: ${contact.whatsapp.ifBlank { stringResource(R.string.detail_not_set) }}", fontSize = 13.sp)
                    } else {
                        OutlinedTextField(value = phoneDraft, onValueChange = { phoneDraft = it }, label = { Text("Phone (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = whatsappDraft, onValueChange = { whatsappDraft = it }, label = { Text("WhatsApp (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { phoneDraft = contact.phone; whatsappDraft = contact.whatsapp; isEditingNumbers = false }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_cancel)) }
                            Button(onClick = {
                                val cleanPhone = if (phoneDraft.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(phoneDraft)
                                val cleanWa = if (whatsappDraft.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(whatsappDraft)
                                if (cleanPhone.isNotBlank() && !PhoneContactsHelper.isValidInternationalOrLocalPhone(cleanPhone)) { Toast.makeText(context, "Invalid phone number", Toast.LENGTH_SHORT).show(); return@Button }
                                if (cleanWa.isNotBlank() && !PhoneContactsHelper.isValidInternationalOrLocalPhone(cleanWa)) { Toast.makeText(context, "Invalid WhatsApp number", Toast.LENGTH_SHORT).show(); return@Button }
                                val updated = contact.copy(phone = cleanPhone, whatsapp = cleanWa)
                                val waChanged = cleanWa != contact.whatsapp && cleanWa.isNotBlank()
                                if (waChanged && hasPendingWaSchedules) showWaScheduleConfirmDialog = updated
                                else { onSaveContact(updated, if (waChanged) cleanWa else null); isEditingNumbers = false; Toast.makeText(context, "Numbers updated", Toast.LENGTH_SHORT).show() }
                            }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_save)) }
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tagOptions.forEach { tag ->
                    FilterChip(selected = selectedTag == tag, onClick = { selectedTag = tag; onSaveContact(contact.copy(categoryTag = tag, notes = notes, latitude = currentLat, longitude = currentLng), null) }, label = { Text(tag) })
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ContactActionLauncher.launchDialer(context, primaryPhone) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_call)) }
                Button(onClick = { ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_wa)) }
                Button(onClick = { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_email)) }
                Button(onClick = { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName, currentLat, currentLng) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_map)) }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showTemplateSheetFor = "WA" }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_wa_templates), fontSize = 12.sp) }
                OutlinedButton(onClick = { showTemplateSheetFor = "EMAIL" }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_email_templates), fontSize = 12.sp) }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_geo_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (distanceKm != null) Text("$distanceKm km away", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    if (contact.officeAddress.isNotBlank()) Text(contact.officeAddress, style = MaterialTheme.typography.bodySmall)
                    if (currentLat != null && currentLng != null) Text("GPS Pin: ${GeoLocationHelper.formatCoordinates(currentLat, currentLng)}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { ContactActionLauncher.launchTurnByTurnNavigation(context, currentLat, currentLng, contact.officeAddress) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_directions), fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                            scope.launch {
                                val coords = (if (contact.officeAddress.isNotBlank()) GeoLocationHelper.geocodeAddress(context, contact.officeAddress) else null) ?: GeoLocationHelper.getCurrentGpsCoordinates(context)
                                if (coords != null) { currentLat = coords.first; currentLng = coords.second; onSaveContact(contact.copy(latitude = coords.first, longitude = coords.second), null); Toast.makeText(context, "GPS Pinned!", Toast.LENGTH_SHORT).show() }
                            }
                        }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_detect_gps), fontSize = 12.sp) }
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.detail_tasks_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newActionTitle, onValueChange = { newActionTitle = it }, label = { Text(stringResource(R.string.detail_add_task)) }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            if (newActionTitle.isNotBlank()) {
                                val item = FollowUpEntity(contactId = contact.id, contactName = contact.fullName, companyName = contact.companyName, title = newActionTitle.trim(), dueAtTimestamp = System.currentTimeMillis() + 24L * 3600_000L)
                                onAddFollowUp(item); FollowUpScheduler.scheduleForItem(context, item); newActionTitle = ""
                            }
                        }) { Text(stringResource(R.string.action_add)) }
                    }
                    contactFollowUps.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(checked = item.isCompleted, onCheckedChange = { onToggleFollowUp(item) })
                                Column {
                                    Text(item.title, fontSize = 13.sp, textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None)
                                    Text(dateFmt.format(Date(item.dueAtTimestamp)), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            IconButton(onClick = { onDeleteFollowUp(item) }) { Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.detail_notes_label)) },
                modifier = Modifier.fillMaxWidth(), minLines = 3,
                trailingIcon = {
                    IconButton(onClick = {
                        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak meeting notes...")
                        }
                        runCatching { speechRecognizerLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Speech recognition not available", Toast.LENGTH_SHORT).show() }
                    }) { Icon(Icons.Default.Mic, "Voice Dictation", tint = MaterialTheme.colorScheme.primary) }
                }
            )
            Button(onClick = { onSaveContact(contact.copy(notes = notes, categoryTag = selectedTag, latitude = currentLat, longitude = currentLng), null); Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.detail_save_notes)) }
        }
    }

    if (showWaScheduleConfirmDialog != null) {
        val u = showWaScheduleConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showWaScheduleConfirmDialog = null },
            title = { Text(stringResource(R.string.detail_update_wa_title)) },
            text = { Text("Update scheduled WhatsApp recipients for this contact to ${u.whatsapp}?") },
            confirmButton = { Button(onClick = { onSaveContact(u, u.whatsapp); showWaScheduleConfirmDialog = null; isEditingNumbers = false }) { Text(stringResource(R.string.detail_update_btn)) } },
            dismissButton = { TextButton(onClick = { onSaveContact(u, null); showWaScheduleConfirmDialog = null; isEditingNumbers = false }) { Text(stringResource(R.string.detail_keep_existing)) } }
        )
    }

    if (showTemplateSheetFor != null) {
        val mode = showTemplateSheetFor!!
        AlertDialog(
            onDismissRequest = { showTemplateSheetFor = null },
            title = { Text(if (mode == "WA") "WhatsApp Templates" else "Email Templates", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MessageTemplateHelper.defaultTemplates.forEach { tmpl ->
                        val body = tmpl.buildBody(contact, mySenderName, mySenderCompany)
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            if (mode == "WA") ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName, body)
                            else ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName, tmpl.buildSubject(contact, mySenderName, mySenderCompany), body)
                            showTemplateSheetFor = null
                        }) { Column(modifier = Modifier.padding(10.dp)) { Text(tmpl.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp); Text(body, style = MaterialTheme.typography.bodySmall, maxLines = 2) } }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTemplateSheetFor = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
