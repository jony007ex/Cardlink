package com.cardlink.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.onPrimary
import com.cardlink.app.util.*

@Composable
fun FirstRunOnboardingScreen(
    onCreateMyCard: () -> Unit,
    onExploreCardLink: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) } // 0..3

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top progress dots & Skip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 0..3) {
                        Surface(
                            modifier = Modifier.height(6.dp).width(if (i == step) 26.dp else 8.dp),
                            shape = CircleShape,
                            color = if (i <= step) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                        ) {}
                    }
                }
                if (step < 3) {
                    TextButton(onClick = onExploreCardLink) {
                        Text(stringResource(R.string.ux_skip), color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Step Content (No permissions requested during onboarding!)
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                when (step) {
                    0 -> {
                        OnboardingHeroIcon(Icons.Default.Badge)
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.ux_onb_1_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        Text(stringResource(R.string.ux_onb_1_sub), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(22.dp))
                        OnboardingBullet(Icons.Default.Share, stringResource(R.string.ux_onb_1_b1))
                        OnboardingBullet(Icons.Default.Contacts, stringResource(R.string.ux_onb_1_b2))
                        OnboardingBullet(Icons.Default.EventAvailable, stringResource(R.string.ux_onb_1_b3))
                    }
                    1 -> {
                        OnboardingHeroIcon(Icons.Default.DocumentScanner)
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.ux_onb_2_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(22.dp))
                        OnboardingBullet(Icons.Default.CameraAlt, stringResource(R.string.ux_onb_2_b1))
                        OnboardingBullet(Icons.Default.PersonAdd, stringResource(R.string.ux_onb_2_b2))
                        OnboardingBullet(Icons.Default.NotificationsActive, stringResource(R.string.ux_onb_2_b3))
                    }
                    2 -> {
                        OnboardingHeroIcon(Icons.Default.VerifiedUser)
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.ux_onb_3_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(22.dp))
                        OnboardingBullet(Icons.Default.CreditCard, stringResource(R.string.ux_onb_3_b1))
                        OnboardingBullet(Icons.Default.Storage, stringResource(R.string.ux_onb_3_b2))
                        OnboardingBullet(Icons.Default.Fingerprint, stringResource(R.string.ux_onb_3_b3))
                    }
                    else -> {
                        OnboardingHeroIcon(Icons.Default.AutoAwesome)
                        Spacer(Modifier.height(20.dp))
                        Text(stringResource(R.string.ux_onb_4_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        Text(stringResource(R.string.ux_onb_4_sub), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f))
                    }
                }
            }

            // Bottom Actions
            if (step < 3) {
                Button(
                    onClick = { step++ },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Text(stringResource(R.string.action_continue), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                }
            } else {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onCreateMyCard,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Text(stringResource(R.string.ux_create_my_card), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                    }
                    OutlinedButton(
                        onClick = onExploreCardLink,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Text(stringResource(R.string.ux_explore_cardlink), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun OnboardingHeroIcon(icon: ImageVector) {
    Surface(
        modifier = Modifier.size(84.dp),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
private fun OnboardingBullet(icon: ImageVector, text: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun WhatsNewDialog(
    onTryScanner: () -> Unit,
    onSetupBackup: () -> Unit,
    onViewIds: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text(stringResource(R.string.ux_whats_new_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WhatsNewRow(Icons.Default.QrCodeScanner, "Universal QR Scanner", "Scan links, contacts, Wi-Fi, events and more.", "Try Now", onTryScanner)
                WhatsNewRow(Icons.Default.Storage, "Master Backup", "Protect CardLink data using one updatable backup file.", "Set Up", onSetupBackup)
                WhatsNewRow(Icons.Default.Badge, "Smart ID Reminders", "Get notified before important IDs expire.", "View My IDs", onViewIds)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) { Text(stringResource(R.string.action_close), fontWeight = FontWeight.Bold) }
        }
    )
}

@Composable
private fun WhatsNewRow(icon: ImageVector, title: String, desc: String, action: String, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(desc, style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 6.dp)) {
                Text(action, color = MaterialTheme.colorScheme.primary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Compact Smart Summary Card ("Today in CardLink") + Get Started Checklist for My Card.
 * Never shows empty filler cards.
 */
@Composable
fun TodayInCardLinkAndChecklist(
    activeCard: BusinessCardEntity,
    contacts: List<SavedContactEntity>,
    followUps: List<FollowUpEntity>,
    idDocuments: List<IdDocumentEntity>,
    onOpenEditCard: () -> Unit,
    onOpenShare: () -> Unit,
    onOpenFollowUps: () -> Unit,
    onOpenMyIds: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenContacts: () -> Unit
) {
    val context = LocalContext.current
    var checklistDismissed by remember { mutableStateOf(UxExperiencePrefs.isChecklistDismissed(context)) }

    // 1. Get Started Checklist (6 real items)
    val cardCreated = activeCard.fullName.isNotBlank() && activeCard.phone != "+880 1700-000000"
    val photoAdded = !activeCard.profilePhotoUri.isNullOrBlank() || !activeCard.companyLogoUri.isNullOrBlank()
    val shareTested = UxExperiencePrefs.hasTestedShare(context)
    val bioEnabled = BiometricLockHelper.isLockEnabled(context)
    val masterSet = MasterBackupManager.getMasterInfo(context).uriString != null
    val checklistItems = listOf(
        Triple("Create your Business Card", cardCreated, onOpenEditCard),
        Triple("Add profile photo or company logo", photoAdded, onOpenEditCard),
        Triple("Preview your card", true, onOpenEditCard),
        Triple("Test Share My Card", shareTested, onOpenShare),
        Triple("Enable Biometric Lock", bioEnabled, onOpenPrivacy),
        Triple("Set up Master Backup", masterSet, onOpenBackup)
    )
    val completedCount = checklistItems.count { it.second }

    if (!checklistDismissed && completedCount < checklistItems.size) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(stringResource(R.string.ux_get_started_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Text("$completedCount of ${checklistItems.size} completed", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = {
                        UxExperiencePrefs.setChecklistDismissed(context, true)
                        checklistDismissed = true
                    }) { Text(stringResource(R.string.ux_skip_for_now), fontSize = 11.5.sp) }
                }
                LinearProgressIndicator(
                    progress = { completedCount.toFloat() / checklistItems.size.toFloat() },
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape)
                )
                checklistItems.filterNot { it.second }.take(3).forEach { (label, _, action) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable(onClick = action).padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.RadioButtonUnchecked, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    // 2. Today in CardLink (Priority-ordered smart summary, only shown if relevant items exist)
    val now = System.currentTimeMillis()
    val pendingFollowUps = followUps.filter { !it.isCompleted }
    val dueFollowUps = pendingFollowUps.count { it.dueAtTimestamp <= now + 24L * 3600_000L }
    val expiringIds = idDocuments.count { doc ->
        val st = IdExpiryHelper.resolveStatus(doc.expiryDateIso)
        st == IdExpiryStatus.EXPIRED || st == IdExpiryStatus.EXPIRES_TODAY || st == IdExpiryStatus.EXPIRING_SOON
    }
    val backupHealth = remember(contacts.size, idDocuments.size) {
        BackupCenterPrefs.computeBackupHealth(context, contacts.size + idDocuments.size)
    }
    val newContactsWeek = contacts.count { now - it.savedAtTimestamp <= 7L * 24L * 3600_000L }

    val todayItems = buildList {
        if (expiringIds > 0) add(Triple(Icons.Default.WarningAmber, "$expiringIds ID(s) expiring soon or expired", "Review IDs" to onOpenMyIds))
        if (dueFollowUps > 0) add(Triple(Icons.Default.Event, "$dueFollowUps Follow-Up(s) due or overdue", "Review" to onOpenFollowUps))
        if (backupHealth.status == BackupHealthStatus.BACKUP_OVERDUE || backupHealth.status == BackupHealthStatus.BACKUP_RECOMMENDED) {
            add(Triple(Icons.Default.Storage, "Backup recommended to protect your data", "Update" to onOpenBackup))
        }
        if (newContactsWeek > 0) add(Triple(Icons.Default.People, "$newContactsWeek new contact(s) added this week", "View" to onOpenContacts))
    }

    if (todayItems.isNotEmpty()) {
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.ux_today_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                todayItems.forEach { (icon, text, ctaPair) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = ctaPair.second).padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Text(ctaPair.first, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpAndTipsScreen(
    onReopenChecklist: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var expandedTopic by remember { mutableStateOf<String?>(null) }

    val topics = remember {
        listOf(
            "Create My Card" to "Tap the Edit icon on My Card to add your name, designation, company, phone, email, and profile photo. Your digital card updates instantly.",
            "Share My Card" to "Tap Share My Card to share via QR code, NFC tap, vCard (.vcf), PDF, or interactive HTML card.",
            "Scan a Business Card" to "Use Scan Card from My Card, Contacts +, or Tools. CardLink extracts contact fields via offline OCR so you can review and save.",
            "Add an ID" to "Go to Tools -> My IDs -> + to store passports, NIDs, or licences inside CardLink's encrypted vault with 60/30-day expiry reminders.",
            "Add a Loyalty Card" to "Go to Tools -> Loyalty Cards -> + to scan barcodes/QR codes and save front/back photos for instant checkout.",
            "Create a QR Code" to "Open Tools -> QR Code Studio to create styled QR codes for URLs, Wi-Fi, vCards, WhatsApp, Events, and more, verified by our internal decoder.",
            "Set Up Master Backup" to "Open Menu -> Settings -> Backup & Export -> Set Up Master Backup to maintain one persistent, deduplicated CardLink_Master.cardlink file with rolling snapshots.",
            "Restore Backup" to "Choose Restore Backup or Restore Snapshot in Backup & Export. Merge is recommended by default so existing data is preserved.",
            "Manage Privacy & Security" to "Open Menu -> Settings -> Privacy to enable Biometric Lock, Smart Auto-Lock, Panic Lock, Privacy/Decoy Mode, and view your local Security Activity.",
            "Customize Theme" to "Open Menu -> Settings -> Appearance -> Theme Colors to choose from 8 accessible presets or build a custom theme with Live Preview."
        )
    }

    val filtered = remember(search) {
        val q = search.trim()
        if (q.isBlank()) topics else topics.filter { it.first.contains(q, true) || it.second.contains(q, true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.menu_help_tips), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text(stringResource(R.string.ux_help_search_hint)) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedButton(
                onClick = onReopenChecklist,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Checklist, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.ux_reopen_checklist))
            }

            filtered.forEach { (title, body) ->
                val isExp = expandedTopic == title
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable {
                        expandedTopic = if (isExp) null else title
                    },
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Icon(if (isExp) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        AnimatedVisibility(visible = isExp) {
                            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
    }
}
