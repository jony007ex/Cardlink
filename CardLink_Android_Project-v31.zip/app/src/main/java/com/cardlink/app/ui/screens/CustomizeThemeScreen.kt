package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.ui.components.BusinessCardTemplateThumbnail
import com.cardlink.app.ui.components.FlippableBusinessCardView
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.onPrimary
import com.cardlink.app.util.*

private val CARD_STUDIO_SWATCHES = listOf(
    0xFF0A192FL, 0xFF112240L, 0xFF1E293BL, 0xFF064E3BL,
    0xFF3B0764L, 0xFF4C0519L, 0xFF121215L, 0xFF1E3A8AL,
    0xFFD4AF37L, 0xFFFBBF24L, 0xFF38BDF8L, 0xFF2DD4BFL,
    0xFFF4B6A8L, 0xFFF8FAFCL, 0xFFFFFFFFL, 0xFF0F172AL
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizeThemeScreen(
    activeCard: BusinessCardEntity,
    onSaveCardTheme: (BusinessCardEntity) -> Unit,
    onResetCardDefaults: () -> BusinessCardEntity,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    val activeTemplateSpec = remember(activeCard.selectedTemplateId, activeCard.template) {
        CardTemplateRegistry.resolveForCard(activeCard)
    }

    // Gallery filter & independent Card Template Favorites / Recently Used
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, FAVORITES, or CardTemplateCategory.name
    var favoriteTemplateIds by remember { mutableStateOf(CardTemplatePrefs.getFavoriteIds(context)) }
    var recentTemplateIds by remember { mutableStateOf(CardTemplatePrefs.getRecentlyUsedIds(context)) }

    // Interactive Full Preview State (tapping a tile opens Preview WITHOUT changing Main Card until "Use This Template")
    var previewSpec by remember { mutableStateOf<BusinessCardTemplateSpec?>(null) }
    var previewCardDraft by remember { mutableStateOf(activeCard) }
    var previewFlipped by remember { mutableStateOf(false) }
    var showColorCustomizer by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }

    fun openTemplatePreview(spec: BusinessCardTemplateSpec) {
        previewSpec = spec
        previewCardDraft = if (spec.id == activeTemplateSpec.id) {
            activeCard.copy(selectedTemplateId = spec.id)
        } else {
            CardTemplateRegistry.applyTemplateToCard(activeCard, spec)
        }
        previewFlipped = false // Always start on Front when opening a template preview
        showColorCustomizer = false
    }

    // Back press from Full Preview returns to Gallery
    BackHandler(enabled = previewSpec != null) {
        previewSpec = null
    }

    val currentPreview = previewSpec
    if (currentPreview != null) {
        // =====================================================================
        // FULL INTERACTIVE TEMPLATE PREVIEW (Front <-> QR Back Flip + Colors)
        // =====================================================================
        val isFav = currentPreview.id in favoriteTemplateIds
        val contrastRatio = remember(previewCardDraft.textColorHex, previewCardDraft.primaryColorHex) {
            ThemeContrastHelper.contrastRatio(previewCardDraft.textColorHex, previewCardDraft.primaryColorHex)
        }
        val lowContrast = contrastRatio < 4.5

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(currentPreview.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = currentPreview.category.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { previewSpec = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                        }
                    },
                    actions = {
                        IconButton(onClick = { showDetailsDialog = true }) {
                            Icon(Icons.Default.Info, contentDescription = stringResource(R.string.tpl_details_title))
                        }
                        IconButton(onClick = {
                            favoriteTemplateIds = CardTemplatePrefs.toggleFavorite(context, currentPreview.id)
                        }) {
                            Icon(
                                imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = if (isFav) "Remove Favorite Design" else "Favorite Design",
                                tint = if (isFav) MaterialTheme.colorScheme.primary else LocalContentColor.current
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Interactive 3D Flippable Preview Card using user's REAL Business Card data
                FlippableBusinessCardView(
                    card = previewCardDraft,
                    isFlippedExternal = previewFlipped,
                    onFlipToggle = { previewFlipped = !previewFlipped }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.tpl_tap_to_flip_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    TextButton(
                        onClick = { previewFlipped = !previewFlipped },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = if (previewFlipped) stringResource(R.string.tpl_show_front) else stringResource(R.string.tpl_show_back),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Low Contrast Warning + Auto-Fix
                if (lowContrast) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF59E0B).copy(alpha = 0.14f)),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.WarningAmber, null, tint = Color(0xFFF59E0B))
                            Text(
                                text = "Low Contrast (${String.format("%.1f", contrastRatio)}:1) — readability may be reduced.",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFF59E0B),
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                val fixedText = ThemeContrastHelper.bestOnColor(previewCardDraft.primaryColorHex)
                                previewCardDraft = previewCardDraft.copy(textColorHex = fixedText)
                            }) { Text("Fix", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        }
                    }
                }

                // Primary CTA: Use This Template
                Button(
                    onClick = {
                        CardTemplatePrefs.recordAppliedTemplate(context, currentPreview.id)
                        recentTemplateIds = CardTemplatePrefs.getRecentlyUsedIds(context)
                        onSaveCardTheme(previewCardDraft)
                        Toast.makeText(context, context.getString(R.string.tpl_applied_toast), Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Icon(Icons.Default.Check, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.tpl_use_this_template), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                }

                // Secondary Action: Customize Colors & Typography
                OutlinedButton(
                    onClick = { showColorCustomizer = !showColorCustomizer },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.tpl_customize_colors), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(4.dp))
                    Icon(if (showColorCustomizer) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = MaterialTheme.colorScheme.primary)
                }

                // Expandable Live Color & Typography Customization Panel
                AnimatedVisibility(visible = showColorCustomizer) {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (currentPreview.colorVariants.isNotEmpty()) {
                                Text(stringResource(R.string.tpl_color_variants), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    currentPreview.colorVariants.forEach { variant ->
                                        AssistChip(
                                            onClick = {
                                                previewCardDraft = previewCardDraft.copy(
                                                    primaryColorHex = variant.primaryHex,
                                                    secondaryColorHex = variant.primaryHex,
                                                    cardGradientEndHex = variant.gradientEndHex,
                                                    accentColorHex = variant.accentHex,
                                                    buttonColorHex = variant.accentHex,
                                                    iconColorHex = variant.accentHex,
                                                    textColorHex = variant.textHex
                                                )
                                            },
                                            label = { Text(variant.name, fontSize = 11.5.sp) }
                                        )
                                    }
                                }
                            }

                            Text(stringResource(R.string.tpl_typography_label), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Serif" to "Executive", "SansSerif" to "Modern", "Monospace" to "Compact").forEach { (key, lbl) ->
                                    FilterChip(
                                        selected = previewCardDraft.fontFamilyName == key,
                                        onClick = { previewCardDraft = previewCardDraft.copy(fontFamilyName = key) },
                                        label = { Text(lbl, fontSize = 11.5.sp) }
                                    )
                                }
                            }

                            CardColorEditorRow("Background", previewCardDraft.primaryColorHex) { c ->
                                previewCardDraft = previewCardDraft.copy(primaryColorHex = c, secondaryColorHex = c)
                            }
                            CardColorEditorRow("Gradient End", previewCardDraft.cardGradientEndHex) { c ->
                                previewCardDraft = previewCardDraft.copy(cardGradientEndHex = c)
                            }
                            CardColorEditorRow("Accent & Border", previewCardDraft.accentColorHex) { c ->
                                previewCardDraft = previewCardDraft.copy(accentColorHex = c, buttonColorHex = c, iconColorHex = c)
                            }
                            CardColorEditorRow("Text Color", previewCardDraft.textColorHex) { c ->
                                previewCardDraft = previewCardDraft.copy(textColorHex = c)
                            }

                            TextButton(
                                onClick = {
                                    previewCardDraft = CardTemplateRegistry.applyTemplateToCard(activeCard, currentPreview)
                                },
                                modifier = Modifier.align(Alignment.End)
                            ) { Text(stringResource(R.string.tpl_reset_colors), color = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
        }

        if (showDetailsDialog) {
            AlertDialog(
                onDismissRequest = { showDetailsDialog = false },
                title = { Text(currentPreview.name, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Category: ${currentPreview.category.label}", style = MaterialTheme.typography.bodySmall)
                        Text("Photo Style: ${currentPreview.photoStyle.label}", style = MaterialTheme.typography.bodySmall)
                        Text("Typography: ${currentPreview.typography.label}", style = MaterialTheme.typography.bodySmall)
                        Text("QR Back: Supported (Scanner-Safe)", style = MaterialTheme.typography.bodySmall)
                        Text("Custom Colors: Supported", style = MaterialTheme.typography.bodySmall)
                        Text("English & বাংলা Ready: Yes", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { showDetailsDialog = false }) { Text(stringResource(R.string.action_close)) } }
            )
        }
        return
    }

    // =========================================================================
    // PREMIUM BUSINESS CARD TEMPLATE GALLERY (2-Column Responsive Grid)
    // =========================================================================
    val displayedTemplates = remember(selectedFilter, favoriteTemplateIds) {
        when (selectedFilter) {
            "ALL" -> CardTemplateRegistry.all
            "FAVORITES" -> CardTemplateRegistry.all.filter { it.id in favoriteTemplateIds }
            else -> CardTemplateRegistry.all.filter { it.category.name == selectedFilter }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.customize_card_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.tpl_gallery_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    // Surprise Me — previews a random template without applying it
                    IconButton(onClick = {
                        val candidates = CardTemplateRegistry.all.filterNot { it.id == activeTemplateSpec.id }
                        if (candidates.isNotEmpty()) openTemplatePreview(candidates.random())
                    }) {
                        Icon(Icons.Default.Shuffle, contentDescription = stringResource(R.string.tpl_surprise_me), tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showResetConfirm = true }) {
                        Icon(Icons.Default.RestartAlt, contentDescription = stringResource(R.string.tpl_reset_default))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Compact Category Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    label = { Text(stringResource(R.string.tpl_filter_all), fontSize = 12.sp) }
                )
                CardTemplateCategory.values().forEach { cat ->
                    FilterChip(
                        selected = selectedFilter == cat.name,
                        onClick = { selectedFilter = cat.name },
                        label = { Text(cat.label, fontSize = 12.sp) }
                    )
                }
                FilterChip(
                    selected = selectedFilter == "FAVORITES",
                    onClick = { selectedFilter = "FAVORITES" },
                    leadingIcon = { Icon(Icons.Default.Favorite, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary) },
                    label = { Text(stringResource(R.string.tpl_filter_favorites), fontSize = 12.sp) }
                )
            }

            // Recently Used Templates Strip (only records actually applied templates)
            val recentSpecs = remember(recentTemplateIds) {
                recentTemplateIds.mapNotNull { CardTemplateRegistry.findById(it) }
            }
            if (selectedFilter == "ALL" && recentSpecs.isNotEmpty()) {
                Text(stringResource(R.string.tpl_recently_used), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recentSpecs.forEach { spec ->
                        AssistChip(
                            onClick = { openTemplatePreview(spec) },
                            label = { Text(spec.name, fontSize = 11.5.sp) }
                        )
                    }
                }
            }

            if (displayedTemplates.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.FavoriteBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        Text("No Favorite Card Designs Yet", fontWeight = FontWeight.Bold)
                        Text("Tap the heart icon on any design to save it here.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                // 2-Column Responsive Visual Template Gallery Grid
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    displayedTemplates.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            pair.forEach { spec ->
                                val isActive = spec.id == activeTemplateSpec.id
                                val isFav = spec.id in favoriteTemplateIds
                                TemplateGalleryTile(
                                    spec = spec,
                                    userName = activeCard.fullName,
                                    userCompany = activeCard.companyName,
                                    isActive = isActive,
                                    isFavorite = isFav,
                                    onTap = { openTemplatePreview(spec) },
                                    onToggleFavorite = {
                                        favoriteTemplateIds = CardTemplatePrefs.toggleFavorite(context, spec.id)
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text(stringResource(R.string.tpl_reset_dialog_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.tpl_reset_dialog_msg)) },
            confirmButton = {
                Button(onClick = {
                    val resetCard = onResetCardDefaults()
                    onSaveCardTheme(resetCard)
                    showResetConfirm = false
                    Toast.makeText(context, "Card design reset to default.", Toast.LENGTH_SHORT).show()
                }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun TemplateGalleryTile(
    spec: BusinessCardTemplateSpec,
    userName: String,
    userCompany: String,
    isActive: Boolean,
    isFavorite: Boolean,
    onTap: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stateLabel = if (isActive) "${spec.name} – Business Card Template – Selected" else "${spec.name} – Business Card Template – Not Selected"

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .semantics {
                selected = isActive
                contentDescription = stateLabel
            }
            .clickable(role = Role.Button, onClick = onTap),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (isActive) 2.dp else 1.dp,
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isActive) 4.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            BusinessCardTemplateThumbnail(
                spec = spec,
                userName = userName,
                userCompany = userCompany
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = spec.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = spec.category.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite template",
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            if (isActive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                    Text(
                        text = stringResource(R.string.tpl_active_badge),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun CardColorEditorRow(
    label: String,
    currentHex: Long,
    onColorSelected: (Long) -> Unit
) {
    var hexInput by remember(currentHex) { mutableStateOf(ThemeContrastHelper.formatHex(currentHex)) }
    val validHex = ThemeContrastHelper.parseHexColorOrNull(hexInput) != null

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(22.dp).clip(CircleShape).background(Color(currentHex.toInt())).border(1.dp, Color.Gray, CircleShape))
                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            OutlinedTextField(
                value = hexInput,
                onValueChange = { txt ->
                    hexInput = txt.take(7)
                    ThemeContrastHelper.parseHexColorOrNull(txt)?.let { onColorSelected(it) }
                },
                isError = !validHex,
                singleLine = true,
                modifier = Modifier.width(115.dp)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            CARD_STUDIO_SWATCHES.forEach { sw ->
                val isSel = sw == currentHex
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(sw.toInt()))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                        .clickable { onColorSelected(sw) }
                )
            }
        }
    }
}
