package com.cardlink.app.ui.screens

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.QrDesignPresetEntity
import com.cardlink.app.data.model.QrProjectEntity
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.primary
import com.cardlink.app.ui.theme.MaterialTheme.colorScheme.onPrimary
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale

private fun qrTypeIcon(type: QrContentType): ImageVector = when (type) {
    QrContentType.URL -> Icons.Default.Link
    QrContentType.TEXT -> Icons.Default.TextFields
    QrContentType.VCARD -> Icons.Default.ContactPage
    QrContentType.WIFI -> Icons.Default.Wifi
    QrContentType.WHATSAPP -> Icons.Default.Chat
    QrContentType.LOCATION -> Icons.Default.LocationOn
    QrContentType.EMAIL -> Icons.Default.Email
    QrContentType.PHONE -> Icons.Default.Phone
    QrContentType.SMS -> Icons.Default.Sms
    QrContentType.EVENT -> Icons.Default.Event
    QrContentType.PAYMENT -> Icons.Default.Payments
    QrContentType.GOOGLE_MAPS -> Icons.Default.Map
    QrContentType.YOUTUBE -> Icons.Default.PlayCircle
    QrContentType.SOCIAL -> Icons.Default.Public
    QrContentType.CRYPTO -> Icons.Default.CurrencyBitcoin
    QrContentType.FILE_LINK -> Icons.Default.AttachFile
    QrContentType.CUSTOM -> Icons.Default.Code
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrCodeStudioScreen(
    activeCard: BusinessCardEntity,
    savedProjects: List<QrProjectEntity>,
    savedPresets: List<QrDesignPresetEntity>,
    onSaveProject: (QrProjectEntity) -> Unit,
    onDuplicateProject: (QrProjectEntity) -> Unit,
    onToggleFavorite: (QrProjectEntity) -> Unit,
    onDeleteProject: (QrProjectEntity) -> Unit,
    onSaveDesignPreset: (String, String) -> Unit,
    onDeleteDesignPreset: (QrDesignPresetEntity) -> Unit,
    onOpenQrScanner: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Create / Editor, 1 = My QR Codes

    // Editor state
    var editingProject by remember { mutableStateOf<QrProjectEntity?>(null) }
    var selectedType by remember { mutableStateOf(QrContentType.URL) }
    var fields by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var designConfig by remember { mutableStateOf(QrDesignConfig()) }
    var customLogoUri by remember { mutableStateOf<String?>(null) }
    var projectName by remember { mutableStateOf("") }

    // Type picker & switch confirmation
    var showTypePicker by remember { mutableStateOf(false) }
    var pendingTypeSwitch by remember { mutableStateOf<QrContentType?>(null) }

    // Expandable sections
    var contentExpanded by remember { mutableStateOf(true) }
    var designExpanded by remember { mutableStateOf(false) }
    var exportExpanded by remember { mutableStateOf(false) }

    // Export settings
    var exportFormat by remember { mutableStateOf(QrExportFormat.PNG) }
    var exportResolutionPx by remember { mutableIntStateOf(1024) }
    var exportPrintSizeMm by remember { mutableIntStateOf(50) }

    // Dialogs
    var showSaveProjectDialog by remember { mutableStateOf(false) }
    var showSavePresetDialog by remember { mutableStateOf(false) }
    var showCopySensitiveConfirm by remember { mutableStateOf(false) }
    var showRawPayloadContent by remember { mutableStateOf(false) }
    var pendingUnsafeExportAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    // Build payload reactively
    val buildResult = remember(selectedType, fields) {
        QrPayloadBuilder.build(selectedType, fields)
    }

    // Debounced lightweight 512px live preview & internal decode validation
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var readinessReport by remember { mutableStateOf<ScanReadinessReport?>(null) }

    LaunchedEffect(buildResult.payload, buildResult.isValid, designConfig, customLogoUri) {
        if (!buildResult.isValid || buildResult.payload.isBlank()) {
            previewBitmap = null
            readinessReport = QrStudioEngine.evaluateScanReadiness("", false, designConfig, null)
            return@LaunchedEffect
        }
        delay(220L)
        val (bmp, report) = withContext(Dispatchers.Default) {
            val logoBmp = QrStudioEngine.resolveLogoBitmap(context, designConfig, activeCard, customLogoUri)
            val rendered = QrStudioEngine.renderQrBitmap(
                payload = buildResult.payload,
                config = designConfig,
                sizePx = 512,
                logoBitmap = logoBmp,
                forceOpaqueBackground = false
            )
            val eval = QrStudioEngine.evaluateScanReadiness(buildResult.payload, true, designConfig, rendered)
            Pair(rendered, eval)
        }
        previewBitmap = bmp
        readinessReport = report
    }

    // Launchers
    val pickLogoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) { QrStudioEngine.saveQrLogoLocally(context, uri) }
                if (saved != null) {
                    customLogoUri = saved
                    designConfig = designConfig.copy(
                        logoSource = QrLogoSource.CUSTOM_IMAGE.name,
                        errorCorrection = QrEcLevel.HIGH.name
                    )
                } else {
                    Toast.makeText(context, "Could not load selected logo image.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val saveToDeviceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        if (uri != null && buildResult.isValid) {
            scope.launch {
                val logoBmp = withContext(Dispatchers.IO) {
                    QrStudioEngine.resolveLogoBitmap(context, designConfig, activeCard, customLogoUri)
                }
                QrStudioEngine.exportToUri(
                    context = context,
                    destinationUri = uri,
                    payload = buildResult.payload,
                    config = designConfig,
                    format = exportFormat,
                    resolutionPx = exportResolutionPx,
                    printSizeMm = exportPrintSizeMm,
                    logoBitmap = logoBmp
                ).onSuccess {
                    Toast.makeText(context, context.getString(R.string.qr_studio_saved_device), Toast.LENGTH_LONG).show()
                }.onFailure {
                    Toast.makeText(context, it.localizedMessage ?: "Export failed", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val locationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        val gps = GeoLocationHelper.getCurrentGpsCoordinates(context)
        if (gps != null) {
            fields = fields + mapOf(
                "latitude" to String.format(Locale.US, "%.6f", gps.first),
                "longitude" to String.format(Locale.US, "%.6f", gps.second)
            )
        } else {
            Toast.makeText(context, "Location unavailable — enter Latitude & Longitude manually.", Toast.LENGTH_LONG).show()
        }
    }

    fun loadProjectIntoEditor(project: QrProjectEntity) {
        editingProject = project
        selectedType = runCatching { QrContentType.valueOf(project.qrType) }.getOrDefault(QrContentType.CUSTOM)
        fields = QrPayloadBuilder.deserializeFields(project.contentFieldsJson).ifEmpty {
            mapOf("rawData" to project.payload, "url" to project.payload, "text" to project.payload)
        }
        designConfig = QrPayloadBuilder.deserializeDesign(project.designConfigJson)
        customLogoUri = project.logoUri
        projectName = project.name
        showRawPayloadContent = false
        activeTab = 0
    }

    fun startFreshProject() {
        editingProject = null
        fields = emptyMap()
        projectName = ""
        showRawPayloadContent = false
    }

    fun runWithSafetyCheck(action: () -> Unit) {
        val rep = readinessReport
        if (rep != null && rep.level == ScanReadinessLevel.HIGH_RISK) {
            pendingUnsafeExportAction = action
        } else {
            action()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.qr_studio_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.qr_studio_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (activeTab == 0 && editingProject != null) {
                        TextButton(onClick = { startFreshProject() }) {
                            Text("New", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Top Mode Tabs: Create QR | My QR Codes
            TabRow(selectedTabIndex = activeTab) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text(stringResource(R.string.qr_studio_tab_create), fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.QrCode2, null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("${stringResource(R.string.qr_studio_tab_library)} (${savedProjects.size})", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.FolderSpecial, null, modifier = Modifier.size(18.dp)) }
                )
            }

            if (activeTab == 0) {
                // =============================================================
                // TAB 0: GUIDED QR CODE STUDIO EDITOR
                // =============================================================
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. QR TYPE SELECTOR CARD
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { showTypePicker = true },
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(42.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(qrTypeIcon(selectedType), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.qr_studio_qr_type), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(selectedType.displayName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            Text(stringResource(R.string.qr_studio_change_type), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Icon(Icons.Default.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    // 2. CONTENT SECTION (Expandable, type-specific form)
                    ExpandableStudioCard(
                        title = stringResource(R.string.qr_studio_enter_content),
                        icon = Icons.Default.EditNote,
                        expanded = contentExpanded,
                        onToggle = { contentExpanded = !contentExpanded }
                    ) {
                        // Quick Actions Row: Paste from Clipboard + Type-specific helper
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    val clipText = cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString().orEmpty()
                                    if (clipText.isBlank()) {
                                        Toast.makeText(context, "Clipboard is empty.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val targetKey = when (selectedType) {
                                            QrContentType.URL -> "url"
                                            QrContentType.TEXT -> "text"
                                            QrContentType.EMAIL -> "email"
                                            QrContentType.PHONE, QrContentType.SMS, QrContentType.WHATSAPP -> "phone"
                                            QrContentType.GOOGLE_MAPS -> "mapsUrl"
                                            QrContentType.YOUTUBE -> "youtubeUrl"
                                            QrContentType.SOCIAL -> "handleOrUrl"
                                            QrContentType.PAYMENT -> "paymentUri"
                                            QrContentType.CRYPTO -> "address"
                                            QrContentType.FILE_LINK -> "fileUrl"
                                            else -> "rawData"
                                        }
                                        fields = fields + (targetKey to clipText.trim())
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(5.dp))
                                Text(stringResource(R.string.qr_studio_paste_clipboard), fontSize = 12.sp)
                            }

                            if (selectedType == QrContentType.VCARD) {
                                Button(
                                    onClick = { fields = QrPayloadBuilder.fieldsFromMyCard(activeCard) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Badge, null, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(stringResource(R.string.qr_studio_use_my_card), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (selectedType == QrContentType.LOCATION) {
                                OutlinedButton(
                                    onClick = {
                                        locationPermLauncher.launch(
                                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                        )
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(stringResource(R.string.qr_studio_use_location), fontSize = 12.sp)
                                }
                            }
                        }

                        QrTypeContentForm(
                            type = selectedType,
                            fields = fields,
                            onFieldChange = { k, v -> fields = fields + (k to v) }
                        )

                        // Suggested https:// fix button (never silently alters URL without confirmation)
                        if (buildResult.suggestedHttpsFix != null) {
                            OutlinedButton(
                                onClick = { fields = fields + ("url" to buildResult.suggestedHttpsFix) },
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Add https:// -> ${buildResult.suggestedHttpsFix}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }

                        if (buildResult.warningMessage.isNotBlank()) {
                            Text(
                                text = buildResult.warningMessage,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFF59E0B)
                            )
                        }
                    }

                    // 3. LIVE PREVIEW + SCAN READINESS CARD
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(stringResource(R.string.qr_studio_live_preview), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    "Static QR • ${designConfig.resolvedEcLevel().name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }

                            if (previewBitmap != null && buildResult.isValid) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (designConfig.transparentBackground) Color(0xFFE5E7EB) else Color.White,
                                    shadowElevation = 4.dp,
                                    modifier = Modifier.sizeIn(maxWidth = 240.dp, maxHeight = 280.dp)
                                ) {
                                    Image(
                                        bitmap = previewBitmap!!.asImageBitmap(),
                                        contentDescription = "Live QR Preview for ${selectedType.displayName}",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.padding(8.dp).fillMaxWidth()
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(170.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.QrCode2, null, tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f), modifier = Modifier.size(44.dp))
                                        Text(
                                            text = buildResult.validationMessage.ifBlank { stringResource(R.string.qr_studio_preview_placeholder) },
                                            style = MaterialTheme.typography.bodySmall,
                                            textAlign = TextAlign.Center,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                                        )
                                    }
                                }
                            }

                            // Scan Readiness Checklist Panel
                            readinessReport?.let { rep ->
                                val (statusText, statusColor) = when (rep.level) {
                                    ScanReadinessLevel.READY_TO_EXPORT -> stringResource(R.string.qr_studio_ready_export) to Color(0xFF10B981)
                                    ScanReadinessLevel.NEEDS_ATTENTION -> stringResource(R.string.qr_studio_needs_attention) to Color(0xFFF59E0B)
                                    ScanReadinessLevel.HIGH_RISK -> stringResource(R.string.qr_studio_high_risk) to Color(0xFFEF4444)
                                }
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    color = statusColor.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.55f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(stringResource(R.string.qr_studio_scan_readiness), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(statusText, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = statusColor)
                                        }
                                        Text(rep.summaryMessage, style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = "${if (rep.contrastGood) "✅" else "⚠️"} Contrast ${String.format(Locale.US, "%.1f", rep.contrastRatio)}:1  •  " +
                                                "${if (rep.quietZoneSufficient) "✅" else "⚠️"} Quiet Zone  •  " +
                                                "${if (rep.internalDecodeMatched) "✅" else "❌"} Internal Decode",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }

                            // Human-Readable Content Preview (Masks Wi-Fi password by default)
                            if (buildResult.isValid && buildResult.previewSummaryLines.isNotEmpty()) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("QR Content Preview", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            TextButton(
                                                onClick = { showRawPayloadContent = !showRawPayloadContent },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                            ) {
                                                Text(if (showRawPayloadContent) "Hide Content" else "Show Content", fontSize = 11.sp)
                                            }
                                        }
                                        buildResult.previewSummaryLines.forEach { (k, v) ->
                                            Text("$k: $v", style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                        if (showRawPayloadContent) {
                                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                            Text(buildResult.payload, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }

                            // Quick Test & Copy Content Row
                            if (buildResult.isValid) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = onOpenQrScanner,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text(stringResource(R.string.qr_studio_test_scanner), fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            if (selectedType.isSensitive) {
                                                showCopySensitiveConfirm = true
                                            } else {
                                                SecureClipboardHelper.copySensitive(context, selectedType.displayName, buildResult.payload)
                                            }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text("Copy Content", fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }

                    // 4. DESIGN STUDIO SECTION (Colors, Shapes, Logo, Frame, Error Correction, Presets)
                    ExpandableStudioCard(
                        title = stringResource(R.string.qr_studio_customize_design),
                        icon = Icons.Default.Palette,
                        expanded = designExpanded,
                        onToggle = { designExpanded = !designExpanded }
                    ) {
                        QrDesignStudioPanel(
                            config = designConfig,
                            savedPresets = savedPresets,
                            onConfigChange = { designConfig = it },
                            onPickCustomLogo = {
                                pickLogoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onRemoveLogo = {
                                customLogoUri = null
                                designConfig = designConfig.copy(logoSource = QrLogoSource.NONE.name)
                            },
                            onSaveAsPreset = { showSavePresetDialog = true },
                            onDeletePreset = onDeleteDesignPreset,
                            onResetDesign = {
                                customLogoUri = null
                                designConfig = QrDesignConfig()
                            }
                        )
                    }

                    // 5. SAVE / SHARE / EXPORT SECTION
                    ExpandableStudioCard(
                        title = stringResource(R.string.qr_studio_export_share_section),
                        icon = Icons.Default.IosShare,
                        expanded = exportExpanded,
                        onToggle = { exportExpanded = !exportExpanded }
                    ) {
                        Text("Format", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QrExportFormat.values().forEach { fmt ->
                                FilterChip(
                                    selected = exportFormat == fmt,
                                    onClick = { exportFormat = fmt },
                                    label = { Text(fmt.label, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (exportFormat != QrExportFormat.SVG) {
                            Text("Resolution", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(512, 1024, 2048, 4096).forEach { res ->
                                    FilterChip(
                                        selected = exportResolutionPx == res,
                                        onClick = { exportResolutionPx = res },
                                        label = { Text("${res}×$res px", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        if (exportFormat == QrExportFormat.PDF) {
                            Text("Print Size (300 DPI)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(30, 50, 75, 100).forEach { mm ->
                                    FilterChip(
                                        selected = exportPrintSizeMm == mm,
                                        onClick = { exportPrintSizeMm = mm },
                                        label = { Text("$mm mm", fontSize = 11.sp) }
                                    )
                                }
                            }
                            if (exportPrintSizeMm <= 30 && buildResult.payload.length > 220) {
                                Text(
                                    "Warning: 30 mm may be too small for a dense QR code. Consider 50 mm or larger.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFF59E0B)
                                )
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                enabled = buildResult.isValid,
                                onClick = {
                                    runWithSafetyCheck {
                                        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                                        val safeName = projectName.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "CardLink_QR" }
                                        saveToDeviceLauncher.launch("${safeName}_$stamp.${exportFormat.ext}")
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.qr_studio_save_device), fontSize = 12.sp)
                            }
                            Button(
                                enabled = buildResult.isValid,
                                onClick = {
                                    runWithSafetyCheck {
                                        scope.launch {
                                            val logoBmp = withContext(Dispatchers.IO) {
                                                QrStudioEngine.resolveLogoBitmap(context, designConfig, activeCard, customLogoUri)
                                            }
                                            QrStudioEngine.shareQrCode(
                                                context = context,
                                                projectName = projectName.ifBlank { selectedType.displayName },
                                                payload = buildResult.payload,
                                                config = designConfig,
                                                format = exportFormat,
                                                resolutionPx = exportResolutionPx,
                                                printSizeMm = exportPrintSizeMm,
                                                logoBitmap = logoBmp
                                            ).onFailure {
                                                Toast.makeText(context, it.localizedMessage ?: "Share failed", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.qr_studio_share_qr), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Primary Save QR Project Button
                    Button(
                        enabled = buildResult.isValid,
                        onClick = { showSaveProjectDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Icon(Icons.Default.Save, null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (editingProject != null) "Update QR Project" else stringResource(R.string.qr_studio_save_project),
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                }
            } else {
                // =============================================================
                // TAB 1: MY QR CODES LIBRARY
                // =============================================================
                MyQrLibraryTab(
                    projects = savedProjects,
                    onEdit = { loadProjectIntoEditor(it) },
                    onDuplicate = {
                        onDuplicateProject(it)
                        Toast.makeText(context, "QR project duplicated", Toast.LENGTH_SHORT).show()
                    },
                    onToggleFavorite = onToggleFavorite,
                    onShare = { proj ->
                        scope.launch {
                            val cfg = QrPayloadBuilder.deserializeDesign(proj.designConfigJson)
                            val logoBmp = withContext(Dispatchers.IO) {
                                QrStudioEngine.resolveLogoBitmap(context, cfg, activeCard, proj.logoUri)
                            }
                            QrStudioEngine.shareQrCode(
                                context = context,
                                projectName = proj.name,
                                payload = proj.payload,
                                config = cfg,
                                format = QrExportFormat.PNG,
                                resolutionPx = 1024,
                                printSizeMm = 50,
                                logoBitmap = logoBmp
                            )
                        }
                    },
                    onDelete = onDeleteProject,
                    onCreateNew = { startFreshProject(); activeTab = 0 }
                )
            }
        }
    }

    // Categorized QR Type Picker Dialog with Search
    if (showTypePicker) {
        QrTypePickerDialog(
            currentType = selectedType,
            onDismiss = { showTypePicker = false },
            onSelectType = { newType ->
                showTypePicker = false
                if (newType != selectedType) {
                    val hasEnteredData = fields.values.any { it.isNotBlank() }
                    if (hasEnteredData) {
                        pendingTypeSwitch = newType
                    } else {
                        selectedType = newType
                        fields = emptyMap()
                    }
                }
            }
        )
    }

    // Warn before discarding incompatible entered data when switching QR type
    if (pendingTypeSwitch != null) {
        val target = pendingTypeSwitch!!
        AlertDialog(
            onDismissRequest = { pendingTypeSwitch = null },
            title = { Text("Switch QR Type?", fontWeight = FontWeight.Bold) },
            text = { Text("Switching to ${target.displayName} will clear the current form fields. Your visual design settings will be kept.") },
            confirmButton = {
                Button(onClick = {
                    selectedType = target
                    fields = emptyMap()
                    showRawPayloadContent = false
                    pendingTypeSwitch = null
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingTypeSwitch = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Save QR Project Dialog
    if (showSaveProjectDialog) {
        var nameInput by remember(projectName) { mutableStateOf(projectName) }
        AlertDialog(
            onDismissRequest = { showSaveProjectDialog = false },
            title = { Text(stringResource(R.string.qr_studio_save_project), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("QR Name (e.g. Office Wi-Fi, My Contact)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Note: This saves an editable static QR project in CardLink. Printed copies continue encoding the data printed on them.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val finalName = nameInput.trim()
                    if (finalName.isBlank()) {
                        Toast.makeText(context, "Please enter a name for this QR project.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    projectName = finalName
                    val entity = (editingProject ?: QrProjectEntity(name = finalName, payload = buildResult.payload)).copy(
                        name = finalName,
                        qrType = selectedType.name,
                        payload = buildResult.payload,
                        contentFieldsJson = QrPayloadBuilder.serializeFields(fields),
                        designConfigJson = QrPayloadBuilder.serializeDesign(designConfig),
                        logoUri = customLogoUri
                    )
                    onSaveProject(entity)
                    editingProject = entity
                    showSaveProjectDialog = false
                    Toast.makeText(context, "QR Project saved!", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveProjectDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Save Design Preset Dialog (Visual config ONLY — never saves payloads or passwords!)
    if (showSavePresetDialog) {
        var presetName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSavePresetDialog = false },
            title = { Text("Save as Design Preset", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = presetName,
                        onValueChange = { presetName = it },
                        label = { Text("Preset Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Saves colors, shapes, and frame styling only (no QR content or passwords).", style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (presetName.isNotBlank()) {
                        onSaveDesignPreset(presetName.trim(), QrPayloadBuilder.serializeDesign(designConfig))
                        showSavePresetDialog = false
                        Toast.makeText(context, "Design preset saved!", Toast.LENGTH_SHORT).show()
                    }
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showSavePresetDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Copy Sensitive QR Content Confirmation
    if (showCopySensitiveConfirm) {
        AlertDialog(
            onDismissRequest = { showCopySensitiveConfirm = false },
            title = { Text("Copy Sensitive QR Content?", fontWeight = FontWeight.Bold) },
            text = { Text("This ${selectedType.displayName} payload may contain sensitive data (such as a Wi-Fi password or address). Clipboard will auto-clear in 45 seconds.") },
            confirmButton = {
                Button(onClick = {
                    showCopySensitiveConfirm = false
                    SecureClipboardHelper.copySensitive(context, selectedType.displayName, buildResult.payload)
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showCopySensitiveConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // High-Risk Scan Warning before exporting an unverified QR
    if (pendingUnsafeExportAction != null) {
        AlertDialog(
            onDismissRequest = { pendingUnsafeExportAction = null },
            title = { Text("Scan Risk Warning", fontWeight = FontWeight.Bold, color = Color(0xFFEF4444)) },
            text = { Text("This QR design could not be verified by the internal decoder. Increase contrast, reduce logo size, or reset the QR style before exporting.") },
            confirmButton = {
                Button(
                    onClick = {
                        val act = pendingUnsafeExportAction
                        pendingUnsafeExportAction = null
                        act?.invoke()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Export Anyway") }
            },
            dismissButton = {
                TextButton(onClick = { pendingUnsafeExportAction = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ExpandableStudioCard(
    title: String,
    icon: ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = MaterialTheme.colorScheme.primary)
            }
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun QrTypePickerDialog(
    currentType: QrContentType,
    onDismiss: () -> Unit,
    onSelectType: (QrContentType) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val allTypes = remember { QrContentType.values().toList() }
    val filtered = remember(search) {
        val q = search.trim()
        if (q.isBlank()) allTypes
        else allTypes.filter { it.displayName.contains(q, true) || it.category.name.contains(q, true) }
    }
    val grouped = remember(filtered) { filtered.groupBy { it.category } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.qr_studio_qr_type), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text(stringResource(R.string.qr_studio_search_types)) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QrTypeCategory.values().forEach { cat ->
                        val items = grouped[cat].orEmpty()
                        if (items.isNotEmpty()) {
                            Text(
                                text = cat.name.replace("_", " & "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            items.chunked(2).forEach { pair ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    pair.forEach { t ->
                                        val isSel = t == currentType
                                        Surface(
                                            onClick = { onSelectType(t) },
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                            modifier = Modifier.weight(1f).semantics { selected = isSel }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(qrTypeIcon(t), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                Text(t.displayName, fontSize = 11.5.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) } }
    )
}

@Composable
private fun QrTypeContentForm(
    type: QrContentType,
    fields: Map<String, String>,
    onFieldChange: (String, String) -> Unit
) {
    fun f(k: String) = fields[k].orEmpty()

    when (type) {
        QrContentType.URL -> {
            OutlinedTextField(value = f("url"), onValueChange = { onFieldChange("url", it) }, label = { Text("Website URL * (https://...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.TEXT -> {
            val t = f("text")
            OutlinedTextField(
                value = t,
                onValueChange = { onFieldChange("text", it) },
                label = { Text("Text Content * (${t.length} chars)") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
        }
        QrContentType.VCARD -> {
            val ver = f("vcardVersion").ifBlank { "3.0" }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = ver == "3.0", onClick = { onFieldChange("vcardVersion", "3.0") }, label = { Text("vCard 3.0") })
                FilterChip(selected = ver == "4.0", onClick = { onFieldChange("vcardVersion", "4.0") }, label = { Text("vCard 4.0") })
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("firstName"), onValueChange = { onFieldChange("firstName", it) }, label = { Text("First Name") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("lastName"), onValueChange = { onFieldChange("lastName", it) }, label = { Text("Last Name") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = f("displayName"), onValueChange = { onFieldChange("displayName", it) }, label = { Text("Display Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("org"), onValueChange = { onFieldChange("org", it) }, label = { Text("Organization") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("title"), onValueChange = { onFieldChange("title", it) }, label = { Text("Job Title") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = f("mobilePhone"), onValueChange = { onFieldChange("mobilePhone", it) }, label = { Text("Mobile Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("workPhone"), onValueChange = { onFieldChange("workPhone", it) }, label = { Text("Work Phone") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("personalPhone"), onValueChange = { onFieldChange("personalPhone", it) }, label = { Text("Personal Phone") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = f("email"), onValueChange = { onFieldChange("email", it) }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("website"), onValueChange = { onFieldChange("website", it) }, label = { Text("Website") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("street"), onValueChange = { onFieldChange("street", it) }, label = { Text("Street Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("city"), onValueChange = { onFieldChange("city", it) }, label = { Text("City") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("country"), onValueChange = { onFieldChange("country", it) }, label = { Text("Country") }, singleLine = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(value = f("notes"), onValueChange = { onFieldChange("notes", it) }, label = { Text("Notes") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.EMAIL -> {
            OutlinedTextField(value = f("email"), onValueChange = { onFieldChange("email", it) }, label = { Text("Recipient Email *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("subject"), onValueChange = { onFieldChange("subject", it) }, label = { Text("Subject") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("body"), onValueChange = { onFieldChange("body", it) }, label = { Text("Message") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.PHONE -> {
            OutlinedTextField(value = f("phone"), onValueChange = { onFieldChange("phone", it) }, label = { Text("Phone Number * (e.g. +88017...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.SMS -> {
            OutlinedTextField(value = f("phone"), onValueChange = { onFieldChange("phone", it) }, label = { Text("Phone Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("message"), onValueChange = { onFieldChange("message", it) }, label = { Text("SMS Message") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.WHATSAPP -> {
            OutlinedTextField(value = f("phone"), onValueChange = { onFieldChange("phone", it) }, label = { Text("Phone with Country Code * (e.g. +88017...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("message"), onValueChange = { onFieldChange("message", it) }, label = { Text("Prefilled Message (Optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.WIFI -> {
            var showPass by remember { mutableStateOf(false) }
            val sec = f("security").ifBlank { "WPA" }
            val hidden = f("hidden").equals("true", true)
            OutlinedTextField(value = f("ssid"), onValueChange = { onFieldChange("ssid", it) }, label = { Text("Network Name / SSID *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = sec == "WPA", onClick = { onFieldChange("security", "WPA") }, label = { Text("WPA/WPA2/WPA3", fontSize = 11.sp) })
                FilterChip(selected = sec == "WEP", onClick = { onFieldChange("security", "WEP") }, label = { Text("WEP", fontSize = 11.sp) })
                FilterChip(selected = sec == "nopass", onClick = { onFieldChange("security", "nopass") }, label = { Text("No Password", fontSize = 11.sp) })
            }
            if (sec != "nopass") {
                OutlinedTextField(
                    value = fields["password"].orEmpty(),
                    onValueChange = { onFieldChange("password", it) },
                    label = { Text("Wi-Fi Password *") },
                    singleLine = true,
                    visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showPass = !showPass }) {
                            Icon(if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle password")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Hidden Network", style = MaterialTheme.typography.bodySmall)
                Switch(checked = hidden, onCheckedChange = { onFieldChange("hidden", it.toString()) })
            }
        }
        QrContentType.LOCATION -> {
            OutlinedTextField(value = f("placeTitle"), onValueChange = { onFieldChange("placeTitle", it) }, label = { Text("Place Title / Address (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("latitude"), onValueChange = { onFieldChange("latitude", it) }, label = { Text("Latitude *") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("longitude"), onValueChange = { onFieldChange("longitude", it) }, label = { Text("Longitude *") }, singleLine = true, modifier = Modifier.weight(1f))
            }
        }
        QrContentType.EVENT -> {
            val todayIso = remember { LocalDate.now().toString() }
            val allDay = f("allDay").equals("true", true)
            OutlinedTextField(value = f("eventTitle"), onValueChange = { onFieldChange("eventTitle", it) }, label = { Text("Event Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("eventLocation"), onValueChange = { onFieldChange("eventLocation", it) }, label = { Text("Location") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("All-Day Event", style = MaterialTheme.typography.bodySmall)
                Switch(checked = allDay, onCheckedChange = { onFieldChange("allDay", it.toString()) })
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("startDate").ifBlank { todayIso }, onValueChange = { onFieldChange("startDate", it) }, label = { Text("Start Date (YYYY-MM-DD)") }, singleLine = true, modifier = Modifier.weight(1f))
                if (!allDay) {
                    OutlinedTextField(value = f("startTime").ifBlank { "09:00" }, onValueChange = { onFieldChange("startTime", it) }, label = { Text("Start (HH:MM)") }, singleLine = true, modifier = Modifier.weight(0.75f))
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("endDate").ifBlank { f("startDate").ifBlank { todayIso } }, onValueChange = { onFieldChange("endDate", it) }, label = { Text("End Date (YYYY-MM-DD)") }, singleLine = true, modifier = Modifier.weight(1f))
                if (!allDay) {
                    OutlinedTextField(value = f("endTime").ifBlank { "10:00" }, onValueChange = { onFieldChange("endTime", it) }, label = { Text("End (HH:MM)") }, singleLine = true, modifier = Modifier.weight(0.75f))
                }
            }
            OutlinedTextField(value = f("timeZone").ifBlank { ZoneId.systemDefault().id }, onValueChange = { onFieldChange("timeZone", it) }, label = { Text("Time Zone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("description"), onValueChange = { onFieldChange("description", it) }, label = { Text("Description") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.GOOGLE_MAPS -> {
            OutlinedTextField(value = f("mapsUrl"), onValueChange = { onFieldChange("mapsUrl", it) }, label = { Text("Google Maps URL *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = f("locationTitle"), onValueChange = { onFieldChange("locationTitle", it) }, label = { Text("Location Title (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.YOUTUBE -> {
            OutlinedTextField(value = f("youtubeUrl"), onValueChange = { onFieldChange("youtubeUrl", it) }, label = { Text("YouTube Video / Channel / Playlist / Shorts URL *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.SOCIAL -> {
            val plat = f("platform").ifBlank { "LinkedIn" }
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                QrStudioPresets.socialPlatforms.forEach { (pName, _) ->
                    FilterChip(selected = plat == pName, onClick = { onFieldChange("platform", pName) }, label = { Text(pName, fontSize = 11.sp) })
                }
            }
            OutlinedTextField(value = f("handleOrUrl"), onValueChange = { onFieldChange("handleOrUrl", it) }, label = { Text("$plat Profile URL or Username *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.PAYMENT -> {
            OutlinedTextField(value = f("paymentUri"), onValueChange = { onFieldChange("paymentUri", it) }, label = { Text("Payment URL or Supported URI *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        QrContentType.CRYPTO -> {
            val net = f("network").ifBlank { "Bitcoin (BTC)" }
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                QrStudioPresets.cryptoNetworks.forEach { (nName, _) ->
                    FilterChip(selected = net == nName, onClick = { onFieldChange("network", nName) }, label = { Text(nName, fontSize = 11.sp) })
                }
            }
            OutlinedTextField(value = f("address"), onValueChange = { onFieldChange("address", it) }, label = { Text("Wallet Address * (Never enter private keys)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = f("amount"), onValueChange = { onFieldChange("amount", it) }, label = { Text("Amount (Optional)") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(value = f("note"), onValueChange = { onFieldChange("note", it) }, label = { Text("Note (Optional)") }, singleLine = true, modifier = Modifier.weight(1f))
            }
        }
        QrContentType.FILE_LINK -> {
            OutlinedTextField(value = f("fileUrl"), onValueChange = { onFieldChange("fileUrl", it) }, label = { Text("Shared File URL * (https://...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text(
                "Static QR codes link to an online file URL. CardLink does not upload local files automatically.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
            )
        }
        QrContentType.CUSTOM -> {
            OutlinedTextField(value = f("rawData"), onValueChange = { onFieldChange("rawData", it) }, label = { Text("Raw Exact QR Payload *") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun QrDesignStudioPanel(
    config: QrDesignConfig,
    savedPresets: List<QrDesignPresetEntity>,
    onConfigChange: (QrDesignConfig) -> Unit,
    onPickCustomLogo: () -> Unit,
    onRemoveLogo: () -> Unit,
    onSaveAsPreset: () -> Unit,
    onDeletePreset: (QrDesignPresetEntity) -> Unit,
    onResetDesign: () -> Unit
) {
    val contrastRatio = remember(config.foregroundHex, config.backgroundHex, config.transparentBackground) {
        QrStudioEngine.computeContrastRatio(config.foregroundHex, config.backgroundHex, config.transparentBackground)
    }
    val goodContrast = contrastRatio >= 4.5

    // 1. Design Presets
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Design Presets", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onSaveAsPreset) { Text("Save Preset", fontSize = 11.sp) }
            TextButton(onClick = onResetDesign) { Text("Reset Design", fontSize = 11.sp, color = MaterialTheme.colorScheme.error) }
        }
    }
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QrStudioPresets.builtInDesigns.forEach { preset ->
            AssistChip(onClick = { onConfigChange(preset.config) }, label = { Text(preset.name, fontSize = 11.sp) })
        }
        savedPresets.forEach { custom ->
            InputChip(
                selected = false,
                onClick = { onConfigChange(QrPayloadBuilder.deserializeDesign(custom.designConfigJson)) },
                label = { Text(custom.name, fontSize = 11.sp) },
                trailingIcon = {
                    Icon(Icons.Default.Close, contentDescription = "Delete preset", modifier = Modifier.size(14.dp).clickable { onDeletePreset(custom) })
                }
            )
        }
    }

    // 2. Color Palettes + HEX Inputs + Contrast Badge
    HorizontalDivider()
    Text(stringResource(R.string.qr_studio_set_colors), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        QrStudioPresets.colorPalettes.forEach { pal ->
            FilterChip(
                selected = config.foregroundHex.equals(pal.fgHex, true) && config.backgroundHex.equals(pal.bgHex, true),
                onClick = {
                    onConfigChange(
                        config.copy(
                            foregroundHex = pal.fgHex,
                            backgroundHex = pal.bgHex,
                            useGradient = pal.useGradient,
                            gradientEndHex = pal.gradEndHex
                        )
                    )
                },
                label = { Text(pal.name, fontSize = 11.sp) }
            )
        }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = config.foregroundHex,
            onValueChange = { onConfigChange(config.copy(foregroundHex = it.take(7))) },
            label = { Text(stringResource(R.string.qr_studio_fg_color)) },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = config.backgroundHex,
            onValueChange = { onConfigChange(config.copy(backgroundHex = it.take(7))) },
            label = { Text(stringResource(R.string.qr_studio_bg_color)) },
            singleLine = true,
            enabled = !config.transparentBackground,
            modifier = Modifier.weight(1f)
        )
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Foreground Gradient", style = MaterialTheme.typography.bodySmall)
        Switch(checked = config.useGradient, onCheckedChange = { onConfigChange(config.copy(useGradient = it)) })
    }
    if (config.useGradient) {
        OutlinedTextField(
            value = config.gradientEndHex,
            onValueChange = { onConfigChange(config.copy(gradientEndHex = it.take(7))) },
            label = { Text("Gradient End HEX") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Transparent PNG Background", style = MaterialTheme.typography.bodySmall)
        Switch(checked = config.transparentBackground, onCheckedChange = { onConfigChange(config.copy(transparentBackground = it)) })
    }
    Text(
        text = if (goodContrast) "✅ ${stringResource(R.string.qr_studio_good_contrast)} (${String.format(Locale.US, "%.1f", contrastRatio)}:1)"
        else "⚠️ ${stringResource(R.string.qr_studio_low_contrast)} (${String.format(Locale.US, "%.1f", contrastRatio)}:1)",
        color = if (goodContrast) Color(0xFF10B981) else Color(0xFFF59E0B),
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
    )

    // 3. Body & Finder Eye Shapes
    HorizontalDivider()
    Text(stringResource(R.string.qr_studio_body_style), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QrBodyStyle.values().forEach { style ->
            FilterChip(
                selected = config.bodyStyle == style.name,
                onClick = { onConfigChange(config.copy(bodyStyle = style.name)) },
                label = { Text(style.label, fontSize = 11.sp) }
            )
        }
    }

    Text(stringResource(R.string.qr_studio_eye_frame), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QrEyeFrameStyle.values().forEach { style ->
            FilterChip(
                selected = config.eyeFrameStyle == style.name,
                onClick = { onConfigChange(config.copy(eyeFrameStyle = style.name)) },
                label = { Text(style.label, fontSize = 11.sp) }
            )
        }
    }

    Text(stringResource(R.string.qr_studio_eye_center), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QrEyeCenterStyle.values().forEach { style ->
            FilterChip(
                selected = config.eyeCenterStyle == style.name,
                onClick = { onConfigChange(config.copy(eyeCenterStyle = style.name)) },
                label = { Text(style.label, fontSize = 11.sp) }
            )
        }
    }

    // 4. Logo / Image Inside QR
    HorizontalDivider()
    Text(stringResource(R.string.qr_studio_add_logo), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = config.resolvedLogoSource() == QrLogoSource.NONE, onClick = onRemoveLogo, label = { Text("None", fontSize = 11.sp) })
        FilterChip(
            selected = config.resolvedLogoSource() == QrLogoSource.CARDLINK_ICON,
            onClick = { onConfigChange(config.copy(logoSource = QrLogoSource.CARDLINK_ICON.name, errorCorrection = QrEcLevel.HIGH.name)) },
            label = { Text("CardLink Icon", fontSize = 11.sp) }
        )
        FilterChip(
            selected = config.resolvedLogoSource() == QrLogoSource.MY_CARD_LOGO,
            onClick = { onConfigChange(config.copy(logoSource = QrLogoSource.MY_CARD_LOGO.name, errorCorrection = QrEcLevel.HIGH.name)) },
            label = { Text("My Card Logo", fontSize = 11.sp) }
        )
        FilterChip(
            selected = config.resolvedLogoSource() == QrLogoSource.CUSTOM_IMAGE,
            onClick = onPickCustomLogo,
            label = { Text("Choose Image", fontSize = 11.sp) }
        )
    }
    if (config.resolvedLogoSource() != QrLogoSource.NONE) {
        Text("Logo Size: ${config.logoSizePercent}% (Safe max: 24%)", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = config.logoSizePercent.toFloat(),
            onValueChange = { onConfigChange(config.copy(logoSizePercent = it.toInt().coerceIn(10, 24))) },
            valueRange = 10f..24f
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Solid Background Behind Logo", style = MaterialTheme.typography.bodySmall)
            Switch(checked = config.logoSolidBackground, onCheckedChange = { onConfigChange(config.copy(logoSolidBackground = it)) })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Rounded Logo Corners", style = MaterialTheme.typography.bodySmall)
            Switch(checked = config.logoRoundedCorners, onCheckedChange = { onConfigChange(config.copy(logoRoundedCorners = it)) })
        }
    }

    // 5. Frame & Call-To-Action Label
    HorizontalDivider()
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Frame & Call-to-Action Label", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        Switch(checked = config.frameEnabled, onCheckedChange = { onConfigChange(config.copy(frameEnabled = it)) })
    }
    if (config.frameEnabled) {
        val framePresets = listOf("Scan Me", "Scan to Connect", "Scan for Contact", "Scan for Wi-Fi", "Scan for Location", "Scan for Event", "স্ক্যান করুন")
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            framePresets.forEach { lbl ->
                FilterChip(selected = config.frameLabel == lbl, onClick = { onConfigChange(config.copy(frameLabel = lbl)) }, label = { Text(lbl, fontSize = 11.sp) })
            }
        }
        OutlinedTextField(
            value = config.frameLabel,
            onValueChange = { onConfigChange(config.copy(frameLabel = it.take(28))) },
            label = { Text("Custom Frame Label") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }

    // 6. Error Correction & Quiet Zone
    HorizontalDivider()
    Text("Error Correction", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
    Text(
        "Higher error correction improves tolerance to damage and logos but creates a denser QR code.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
    )
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QrEcLevel.values().forEach { ec ->
            FilterChip(
                selected = config.errorCorrection == ec.name,
                onClick = { onConfigChange(config.copy(errorCorrection = ec.name)) },
                label = { Text(ec.label, fontSize = 11.sp) }
            )
        }
    }

    Text("Quiet Zone Margin: ${config.quietZoneModules} modules", style = MaterialTheme.typography.labelSmall)
    Slider(
        value = config.quietZoneModules.toFloat(),
        onValueChange = { onConfigChange(config.copy(quietZoneModules = it.toInt().coerceIn(2, 6))) },
        valueRange = 2f..6f,
        steps = 3
    )
}

@Composable
private fun MyQrLibraryTab(
    projects: List<QrProjectEntity>,
    onEdit: (QrProjectEntity) -> Unit,
    onDuplicate: (QrProjectEntity) -> Unit,
    onToggleFavorite: (QrProjectEntity) -> Unit,
    onShare: (QrProjectEntity) -> Unit,
    onDelete: (QrProjectEntity) -> Unit,
    onCreateNew: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var sortBy by remember { mutableStateOf("UPDATED") } // UPDATED, ADDED, NAME, FAVORITES
    var pendingDelete by remember { mutableStateOf<QrProjectEntity?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val filtered = remember(projects, search, sortBy) {
        val q = search.trim()
        val base = projects.filter { p ->
            (q.isBlank() || p.name.contains(q, true) || p.qrType.contains(q, true)) &&
                (sortBy != "FAVORITES" || p.isFavorite)
        }
        when (sortBy) {
            "ADDED" -> base.sortedByDescending { it.createdAtTimestamp }
            "NAME" -> base.sortedBy { it.name.lowercase() }
            else -> base.sortedByDescending { it.updatedAtTimestamp }
        }
    }

    if (projects.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.QrCode2, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                    Text("No Saved QR Projects Yet", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Create custom QR codes for links, Wi-Fi, contacts, or events and save them here for future editing and high-resolution export.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onCreateNew,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.qr_studio_create_btn), fontWeight = FontWeight.Bold) }
                }
            }
        }
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Search saved QR projects...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = sortBy == "UPDATED", onClick = { sortBy = "UPDATED" }, label = { Text("Recently Updated", fontSize = 11.sp) })
            FilterChip(selected = sortBy == "ADDED", onClick = { sortBy = "ADDED" }, label = { Text("Recently Added", fontSize = 11.sp) })
            FilterChip(selected = sortBy == "NAME", onClick = { sortBy = "NAME" }, label = { Text("Name A–Z", fontSize = 11.sp) })
            FilterChip(selected = sortBy == "FAVORITES", onClick = { sortBy = "FAVORITES" }, label = { Text("Favorites", fontSize = 11.sp) })
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
            items(filtered, key = { it.stableUuid }) { proj ->
                val typeEnum = runCatching { QrContentType.valueOf(proj.qrType) }.getOrDefault(QrContentType.CUSTOM)
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onEdit(proj) },
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(qrTypeIcon(typeEnum), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(proj.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${typeEnum.displayName} • Updated ${fmt.format(Date(proj.updatedAtTimestamp))}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                            IconButton(onClick = { onToggleFavorite(proj) }) {
                                Icon(
                                    imageVector = if (proj.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (proj.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onEdit(proj) }) { Text(stringResource(R.string.action_edit), fontSize = 12.sp) }
                            TextButton(onClick = { onDuplicate(proj) }) { Text("Duplicate", fontSize = 12.sp) }
                            TextButton(onClick = { onShare(proj) }) { Text(stringResource(R.string.my_ids_share_short), fontSize = 12.sp) }
                            TextButton(onClick = { pendingDelete = proj }) {
                                Text(stringResource(R.string.action_delete), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (pendingDelete != null) {
        val target = pendingDelete!!
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete QR Project?", fontWeight = FontWeight.Bold) },
            text = { Text("Remove \"${target.name}\" from My QR Codes? Already printed copies are not affected.") },
            confirmButton = {
                Button(
                    onClick = { onDelete(target); pendingDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
