package com.cardlink.app.ui.screens

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.cardlink.app.R
import com.cardlink.app.data.model.IdDocumentEntity
import com.cardlink.app.data.model.IdDocumentPageEntity
import com.cardlink.app.data.model.IdDocumentType
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import kotlin.math.abs

private tailrec fun Context.findActivityForIds(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForIds()
    else -> null
}

private fun createTempIdCaptureUri(context: Context): Uri {
    val dir = File(context.cacheDir, "my_id_capture").apply { if (!exists()) mkdirs() }
    val file = File(dir, "id_cap_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

@Composable
private fun idTypeLabel(typeName: String, customName: String = ""): String {
    if (typeName == IdDocumentType.CUSTOM.name && customName.isNotBlank()) return customName
    return when (runCatching { IdDocumentType.valueOf(typeName) }.getOrDefault(IdDocumentType.CUSTOM)) {
        IdDocumentType.NATIONAL_ID -> stringResource(R.string.id_type_national)
        IdDocumentType.PASSPORT -> stringResource(R.string.id_type_passport)
        IdDocumentType.DRIVING_LICENCE -> stringResource(R.string.id_type_driving)
        IdDocumentType.EMPLOYEE_ID -> stringResource(R.string.id_type_employee)
        IdDocumentType.OFFICE_ID -> stringResource(R.string.id_type_office)
        IdDocumentType.STUDENT_ID -> stringResource(R.string.id_type_student)
        IdDocumentType.PROFESSIONAL_ID -> stringResource(R.string.id_type_professional)
        IdDocumentType.MEMBERSHIP_ID -> stringResource(R.string.id_type_membership)
        IdDocumentType.ACCESS_CARD -> stringResource(R.string.id_type_access)
        IdDocumentType.CUSTOM -> stringResource(R.string.id_type_custom)
    }
}

@Composable
private fun expiryStatusColor(status: IdExpiryStatus): Color = when (status) {
    IdExpiryStatus.VALID -> Color(0xFF10B981)
    IdExpiryStatus.RENEWAL_RECOMMENDED -> Color(0xFFF59E0B)
    IdExpiryStatus.EXPIRING_SOON -> Color(0xFFF97316)
    IdExpiryStatus.EXPIRES_TODAY -> Color(0xFFEF4444)
    IdExpiryStatus.EXPIRED -> Color(0xFFEF4444)
    IdExpiryStatus.NO_EXPIRY -> GoldAccent
}

@Composable
private fun expiryCountdownText(expiryDateIso: String?): String {
    val days = IdExpiryHelper.daysUntilExpiry(expiryDateIso) ?: return ""
    return when {
        days > 0L -> stringResource(R.string.id_expires_in_days, days)
        days == 0L -> stringResource(R.string.id_expires_today)
        else -> stringResource(R.string.id_expired_days_ago, abs(days))
    }
}

@Composable
private fun expiryStatusBadgeLabel(status: IdExpiryStatus): String = when (status) {
    IdExpiryStatus.VALID -> stringResource(R.string.id_status_valid)
    IdExpiryStatus.RENEWAL_RECOMMENDED -> stringResource(R.string.id_status_renewal_recommended)
    IdExpiryStatus.EXPIRING_SOON -> stringResource(R.string.id_status_expiring_soon)
    IdExpiryStatus.EXPIRES_TODAY -> stringResource(R.string.id_expires_today)
    IdExpiryStatus.EXPIRED -> stringResource(R.string.id_status_expired)
    IdExpiryStatus.NO_EXPIRY -> ""
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdsWalletScreen(
    documents: List<IdDocumentEntity>,
    allPages: List<IdDocumentPageEntity>,
    onAddNewId: () -> Unit,
    onOpenIdDetail: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val pagesByDoc = remember(allPages) { allPages.groupBy { it.documentUuid } }

    val filteredDocs = remember(documents, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) documents
        else documents.filter {
            it.documentName.contains(q, true) ||
                it.documentType.contains(q, true) ||
                it.customTypeName.contains(q, true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.my_ids_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.my_ids_wallet_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddNewId,
                containerColor = GoldAccent,
                contentColor = NavyPrimary,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text(stringResource(R.string.my_ids_add_btn), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (documents.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = GoldAccent.copy(alpha = 0.16f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Badge, null, tint = GoldAccent, modifier = Modifier.size(34.dp))
                                }
                            }
                            Text(
                                text = stringResource(R.string.my_ids_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.my_ids_empty_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onAddNewId,
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.my_ids_add_btn), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.my_ids_search_hint)) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredDocs, key = { it.stableUuid }) { doc ->
                        val docPages = pagesByDoc[doc.stableUuid].orEmpty()
                        val status = IdExpiryHelper.resolveStatus(doc.expiryDateIso)
                        val statusColor = expiryStatusColor(status)
                        val countdown = expiryCountdownText(doc.expiryDateIso)
                        val badgeLabel = expiryStatusBadgeLabel(status)

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onOpenIdDetail(doc.stableUuid) },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(
                                1.dp,
                                if (status == IdExpiryStatus.EXPIRED || status == IdExpiryStatus.EXPIRING_SOON || status == IdExpiryStatus.EXPIRES_TODAY)
                                    statusColor.copy(alpha = 0.65f)
                                else GoldAccent.copy(alpha = 0.3f)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(46.dp),
                                    shape = CircleShape,
                                    color = GoldAccent.copy(alpha = 0.16f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Badge, null, tint = GoldAccent, modifier = Modifier.size(24.dp))
                                    }
                                }
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        text = doc.documentName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${idTypeLabel(doc.documentType, doc.customTypeName)} • ${docPages.size} ${stringResource(R.string.my_ids_pages_suffix)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                    if (status != IdExpiryStatus.NO_EXPIRY) {
                                        val summaryLine = when (status) {
                                            IdExpiryStatus.EXPIRED, IdExpiryStatus.EXPIRES_TODAY -> countdown
                                            else -> "$badgeLabel • $countdown"
                                        }
                                        Text(
                                            text = summaryLine,
                                            color = statusColor,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdEditorScreen(
    existingDoc: IdDocumentEntity?,
    existingPages: List<IdDocumentPageEntity>,
    onSave: (IdDocumentEntity, List<IdDocumentPageEntity>) -> Unit,
    onOpenSettings: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEditing = existingDoc != null
    val docUuid = remember(existingDoc) { existingDoc?.stableUuid ?: java.util.UUID.randomUUID().toString() }

    var documentName by remember(existingDoc) { mutableStateOf(existingDoc?.documentName.orEmpty()) }
    var documentType by remember(existingDoc) { mutableStateOf(existingDoc?.documentType ?: IdDocumentType.NATIONAL_ID.name) }
    var customTypeName by remember(existingDoc) { mutableStateOf(existingDoc?.customTypeName.orEmpty()) }
    var pages by remember(existingDoc, existingPages) { mutableStateOf(existingPages) }
    var extractedText by remember(existingDoc) { mutableStateOf(existingDoc?.extractedText.orEmpty()) }
    var notes by remember(existingDoc) { mutableStateOf(existingDoc?.notes.orEmpty()) }
    var expiryDateIso by remember(existingDoc) { mutableStateOf(existingDoc?.expiryDateIso) }
    var remindersEnabled by remember(existingDoc) { mutableStateOf(existingDoc?.expiryRemindersEnabled ?: true) }

    var isRunningOcr by remember { mutableStateOf(false) }
    var detectedExpiryCandidates by remember { mutableStateOf<List<String>>(emptyList()) }
    var showAddPageSourceSheet by remember { mutableStateOf(false) }
    var replacePageIndex by remember { mutableStateOf<Int?>(null) }
    var pendingCaptureUri by remember { mutableStateOf<Uri?>(null) }

    fun addOrReplacePagesFromUris(savedUris: List<String>) {
        if (savedUris.isEmpty()) return
        val replaceIdx = replacePageIndex
        if (replaceIdx != null && replaceIdx in pages.indices) {
            val updated = pages.toMutableList()
            updated[replaceIdx] = updated[replaceIdx].copy(imageUri = savedUris.first())
            pages = updated
            replacePageIndex = null
        } else {
            val startIdx = pages.size
            val appended = savedUris.mapIndexed { offset, u ->
                val idx = startIdx + offset
                val lbl = when (idx) {
                    0 -> "Front"
                    1 -> "Back"
                    else -> "Page ${idx + 1}"
                }
                IdDocumentPageEntity(documentUuid = docUuid, pageIndex = idx, pageLabel = lbl, imageUri = u)
            }
            pages = pages + appended
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingCaptureUri
        if (ok && uri != null) {
            scope.launch {
                val saved = IdShareHelper.importUriAsIdPageImages(context, uri)
                addOrReplacePagesFromUris(saved)
            }
        }
    }

    val camPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val uri = createTempIdCaptureUri(context)
            pendingCaptureUri = uri
            takePictureLauncher.launch(uri)
        } else {
            Toast.makeText(context, "Camera permission denied — choose an image or file instead.", Toast.LENGTH_LONG).show()
        }
    }

    val galleryPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val saved = IdShareHelper.importUriAsIdPageImages(context, uri)
                addOrReplacePagesFromUris(saved)
            }
        }
    }

    val fileImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val saved = IdShareHelper.importUriAsIdPageImages(context, uri)
                if (saved.isEmpty()) {
                    Toast.makeText(context, "Could not import selected file.", Toast.LENGTH_SHORT).show()
                } else {
                    addOrReplacePagesFromUris(saved)
                }
            }
        }
    }

    fun openDatePicker(initialIso: String? = expiryDateIso) {
        val base = IdExpiryHelper.parseIsoDate(initialIso) ?: LocalDate.now().plusYears(1)
        DatePickerDialog(
            context,
            { _, y, mZeroBased, d ->
                expiryDateIso = IdExpiryHelper.toIsoDate(y, mZeroBased + 1, d)
                detectedExpiryCandidates = emptyList()
            },
            base.year,
            base.monthValue - 1,
            base.dayOfMonth
        ).show()
    }

    fun runOcrAcrossPages() {
        if (pages.isEmpty()) {
            Toast.makeText(context, "Please add at least one ID photo or file first.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            isRunningOcr = true
            runCatching {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val sb = StringBuilder()
                for (p in pages) {
                    val bmp = withContext(Dispatchers.IO) {
                        ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(p.imageUri))
                    } ?: continue
                    val res = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                    if (res.text.isNotBlank()) {
                        if (sb.isNotEmpty()) sb.append("\n---\n")
                        sb.append(res.text.trim())
                    }
                }
                val text = sb.toString().trim()
                if (text.isNotBlank()) {
                    extractedText = text
                    val candidates = IdExpiryHelper.detectExpiryDateCandidates(text)
                    if (candidates.isNotEmpty()) {
                        detectedExpiryCandidates = candidates
                    }
                } else {
                    Toast.makeText(context, "No readable text detected.", Toast.LENGTH_SHORT).show()
                }
            }.onFailure {
                Toast.makeText(context, "OCR could not complete.", Toast.LENGTH_SHORT).show()
            }
            isRunningOcr = false
        }
    }

    val notificationsActive = FollowUpScheduler.isNotificationsEffectivelyEnabled(context)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isEditing) stringResource(R.string.my_ids_edit_title) else stringResource(R.string.my_ids_add_btn),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Document Name & Type
            OutlinedTextField(
                value = documentName,
                onValueChange = { documentName = it },
                label = { Text(stringResource(R.string.my_ids_doc_name_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.my_ids_doc_type_label), fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IdDocumentType.values().forEach { type ->
                    FilterChip(
                        selected = documentType == type.name,
                        onClick = { documentType = type.name },
                        label = { Text(idTypeLabel(type.name), fontSize = 12.sp) }
                    )
                }
            }

            if (documentType == IdDocumentType.CUSTOM.name) {
                OutlinedTextField(
                    value = customTypeName,
                    onValueChange = { customTypeName = it },
                    label = { Text(stringResource(R.string.my_ids_custom_type_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 2. Document Pages (Single-Sided, Front + Back, Multi-Page Passport)
            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.my_ids_pages_section), fontWeight = FontWeight.Bold, color = GoldAccent)
                Button(
                    onClick = { replacePageIndex = null; showAddPageSourceSheet = true },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.AddAPhoto, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.my_ids_add_page), fontSize = 12.sp)
                }
            }

            if (pages.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text(
                        text = stringResource(R.string.my_ids_no_pages_hint),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pages.forEachIndexed { idx, page ->
                        Card(modifier = Modifier.width(156.dp), shape = RoundedCornerShape(14.dp)) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(page.pageLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = GoldAccent)
                                AsyncImage(
                                    model = Uri.parse(page.imageUri),
                                    contentDescription = page.pageLabel,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1.586f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, GoldAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                )
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    TextButton(
                                        onClick = { replacePageIndex = idx; showAddPageSourceSheet = true },
                                        contentPadding = PaddingValues(horizontal = 4.dp)
                                    ) { Text(stringResource(R.string.my_ids_replace), fontSize = 11.sp) }
                                    IconButton(
                                        onClick = { pages = pages.filterIndexed { i, _ -> i != idx } },
                                        modifier = Modifier.size(30.dp)
                                    ) { Icon(Icons.Default.DeleteOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) }
                                }
                            }
                        }
                    }
                }
            }

            // 3. OCR Extraction & Review
            HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.my_ids_extracted_text), fontWeight = FontWeight.Bold, color = GoldAccent)
                OutlinedButton(
                    onClick = { runOcrAcrossPages() },
                    enabled = !isRunningOcr && pages.isNotEmpty()
                ) {
                    if (isRunningOcr) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.DocumentScanner, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.my_ids_run_ocr), fontSize = 12.sp)
                }
            }

            // OCR Expiry Date Confirmation Banner (NEVER auto-saved without confirmation!)
            if (detectedExpiryCandidates.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF172A46)),
                    border = BorderStroke(1.dp, GoldAccent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.id_ocr_expiry_detected), fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
                        detectedExpiryCandidates.forEach { isoCandidate ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(IdExpiryHelper.formatDisplayDate(isoCandidate), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { openDatePicker(isoCandidate) }) {
                                        Text(stringResource(R.string.action_edit), fontSize = 12.sp)
                                    }
                                    Button(
                                        onClick = {
                                            expiryDateIso = isoCandidate
                                            detectedExpiryCandidates = emptyList()
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) { Text(stringResource(R.string.action_confirm), fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = extractedText,
                onValueChange = { extractedText = it },
                label = { Text(stringResource(R.string.my_ids_extracted_text)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Text(
                text = stringResource(R.string.my_ids_ocr_disclaimer),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            // 4. Expiry Date & Renewal Reminders
            HorizontalDivider()
            Text(stringResource(R.string.id_expiry_date_label), fontWeight = FontWeight.Bold, color = GoldAccent)

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (expiryDateIso != null) IdExpiryHelper.formatDisplayDate(expiryDateIso)
                                else stringResource(R.string.id_no_expiry_set),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            if (expiryDateIso != null) {
                                val st = IdExpiryHelper.resolveStatus(expiryDateIso)
                                Text(
                                    text = expiryCountdownText(expiryDateIso),
                                    color = expiryStatusColor(st),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { openDatePicker() }) {
                                Text(stringResource(R.string.calendar_pick_date), fontSize = 12.sp)
                            }
                            if (expiryDateIso != null) {
                                IconButton(onClick = { expiryDateIso = null }) {
                                    Icon(Icons.Default.Close, null)
                                }
                            }
                        }
                    }

                    if (expiryDateIso != null) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.id_expiry_reminders_label), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (remindersEnabled) {
                                    Text(
                                        text = stringResource(R.string.id_reminder_milestones_summary),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldAccent
                                    )
                                }
                            }
                            Switch(checked = remindersEnabled, onCheckedChange = { remindersEnabled = it })
                        }

                        if (remindersEnabled && !notificationsActive) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.id_notif_off_notice),
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = onOpenSettings) {
                                        Text(stringResource(R.string.calendar_open_settings), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(stringResource(R.string.loyalty_notes_label)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Button(
                onClick = {
                    val trimmedName = documentName.trim()
                    if (trimmedName.isBlank()) {
                        Toast.makeText(context, context.getString(R.string.my_ids_name_required), Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val entity = (existingDoc ?: IdDocumentEntity(stableUuid = docUuid, documentName = trimmedName)).copy(
                        documentName = trimmedName,
                        documentType = documentType,
                        customTypeName = customTypeName.trim(),
                        extractedText = extractedText.trim(),
                        notes = notes.trim(),
                        expiryDateIso = expiryDateIso,
                        expiryRemindersEnabled = remindersEnabled
                    )
                    onSave(entity, pages)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_save), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Add Page Source Dialog (Take Photo / Choose Image / Import from Files / Drive)
    if (showAddPageSourceSheet) {
        AlertDialog(
            onDismissRequest = { showAddPageSourceSheet = false },
            title = { Text(stringResource(R.string.my_ids_add_page), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            showAddPageSourceSheet = false
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                                android.content.pm.PackageManager.PERMISSION_GRANTED
                            ) {
                                val uri = createTempIdCaptureUri(context)
                                pendingCaptureUri = uri
                                takePictureLauncher.launch(uri)
                            } else {
                                camPermLauncher.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoCamera, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_take_photo))
                    }
                    OutlinedButton(
                        onClick = {
                            showAddPageSourceSheet = false
                            galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_choose_image))
                    }
                    OutlinedButton(
                        onClick = {
                            showAddPageSourceSheet = false
                            fileImportLauncher.launch(arrayOf("image/*", "application/pdf"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_import_files))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddPageSourceSheet = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdDetailScreen(
    doc: IdDocumentEntity,
    pages: List<IdDocumentPageEntity>,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenSettings: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Protect sensitive ID screen from app-switcher preview / screenshots while visible
    DisposableEffect(Unit) {
        val window = context.findActivityForIds()?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    val status = IdExpiryHelper.resolveStatus(doc.expiryDateIso)
    val statusColor = expiryStatusColor(status)
    val countdown = expiryCountdownText(doc.expiryDateIso)
    val notificationsActive = FollowUpScheduler.isNotificationsEffectivelyEnabled(context)

    var isFlipped by remember { mutableStateOf(false) }
    val flipRotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(420),
        label = "id_flip"
    )
    var enlargedPhotoUri by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showShareOptionsDialog by remember { mutableStateOf(false) }
    var pendingShareAction by remember { mutableStateOf<Pair<String, List<IdDocumentPageEntity>>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(doc.documentName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            idTypeLabel(doc.documentType, doc.customTypeName),
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldAccent
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = { if (pages.isNotEmpty()) showShareOptionsDialog = true }) {
                        Icon(Icons.Default.Share, contentDescription = stringResource(R.string.my_ids_share))
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.action_edit))
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.action_delete), tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. EXPIRY STATUS & COUNTDOWN CARD
            if (doc.expiryDateIso != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.7f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = expiryStatusBadgeLabel(status),
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = countdown,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            text = "${stringResource(R.string.id_expiry_date_label)}: ${IdExpiryHelper.formatDisplayDate(doc.expiryDateIso)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (doc.expiryRemindersEnabled) {
                            if (notificationsActive) {
                                Text(
                                    text = "${stringResource(R.string.id_expiry_reminders_label)}: ${stringResource(R.string.id_reminder_milestones_summary)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldAccent
                                )
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.id_notif_off_notice),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = onOpenSettings) {
                                        Text(stringResource(R.string.calendar_open_settings), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. DOCUMENT VIEWER (Smooth Front <-> Back Flip for 2-page IDs, or Multi-Page viewer)
            if (pages.size == 2) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !isFlipped,
                            onClick = { isFlipped = false },
                            label = { Text(stringResource(R.string.detail_front_side)) }
                        )
                        FilterChip(
                            selected = isFlipped,
                            onClick = { isFlipped = true },
                            label = { Text(stringResource(R.string.detail_back_side)) }
                        )
                    }
                    OutlinedButton(onClick = { isFlipped = !isFlipped }) {
                        Icon(Icons.Default.Flip, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.my_ids_flip), fontSize = 12.sp)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.586f)
                        .graphicsLayer {
                            rotationY = flipRotation
                            cameraDistance = 14f * density
                        }
                ) {
                    val activePage = if (flipRotation <= 90f) pages[0] else pages[1]
                    Card(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { if (flipRotation > 90f) rotationY = 180f }
                            .border(1.5.dp, GoldAccent, RoundedCornerShape(16.dp))
                            .clickable { enlargedPhotoUri = activePage.imageUri },
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        AsyncImage(
                            model = Uri.parse(activePage.imageUri),
                            contentDescription = activePage.pageLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            } else if (pages.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    pages.forEach { page ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(page.pageLabel, style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1.586f)
                                    .border(1.5.dp, GoldAccent, RoundedCornerShape(14.dp))
                                    .clickable { enlargedPhotoUri = page.imageUri },
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                AsyncImage(
                                    model = Uri.parse(page.imageUri),
                                    contentDescription = page.pageLabel,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }

            // 3. EXTRACTED TEXT
            if (doc.extractedText.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(stringResource(R.string.my_ids_extracted_text), fontWeight = FontWeight.Bold, color = GoldAccent)
                            TextButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Extracted ID Text", doc.extractedText))
                                Toast.makeText(context, "Copied!", Toast.LENGTH_SHORT).show()
                            }) { Text("Copy", fontSize = 12.sp) }
                        }
                        Text(doc.extractedText, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // 4. NOTES
            if (doc.notes.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.loyalty_notes_label), fontWeight = FontWeight.Bold, color = GoldAccent)
                        Text(doc.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    // Full-screen photo viewer
    if (enlargedPhotoUri != null) {
        Dialog(
            onDismissRequest = { enlargedPhotoUri = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.94f))
                    .clickable { enlargedPhotoUri = null }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = Uri.parse(enlargedPhotoUri),
                    contentDescription = "ID Page",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    // Share Format & Page Selector Dialog
    if (showShareOptionsDialog) {
        var selectedFormat by remember { mutableStateOf("PDF") }
        var selectedPageScope by remember { mutableStateOf("ALL") }
        AlertDialog(
            onDismissRequest = { showShareOptionsDialog = false },
            title = { Text(stringResource(R.string.my_ids_share), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = selectedFormat == "PDF", onClick = { selectedFormat = "PDF" }, label = { Text("PDF") })
                        FilterChip(selected = selectedFormat == "IMAGE", onClick = { selectedFormat = "IMAGE" }, label = { Text("Image") })
                    }
                    if (pages.size >= 2) {
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = selectedPageScope == "ALL", onClick = { selectedPageScope = "ALL" }, label = { Text(if (pages.size == 2) "Front & Back" else "All Pages") })
                            FilterChip(selected = selectedPageScope == "FRONT", onClick = { selectedPageScope = "FRONT" }, label = { Text("Front Only") })
                            FilterChip(selected = selectedPageScope == "BACK", onClick = { selectedPageScope = "BACK" }, label = { Text("Back Only") })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val chosenPages = when (selectedPageScope) {
                        "FRONT" -> pages.take(1)
                        "BACK" -> pages.drop(1).take(1).ifEmpty { pages.take(1) }
                        else -> pages
                    }
                    showShareOptionsDialog = false
                    pendingShareAction = Pair(selectedFormat, chosenPages)
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showShareOptionsDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Mandatory Sensitive-Document Share Confirmation Dialog
    if (pendingShareAction != null) {
        val (fmt, chosenPages) = pendingShareAction!!
        AlertDialog(
            onDismissRequest = { pendingShareAction = null },
            title = { Text(stringResource(R.string.my_ids_share_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.my_ids_share_confirm_msg)) },
            confirmButton = {
                Button(onClick = {
                    pendingShareAction = null
                    scope.launch {
                        if (fmt == "PDF") IdShareHelper.sharePagesAsPdf(context, doc.documentName, chosenPages)
                        else IdShareHelper.sharePagesAsImage(context, doc.documentName, chosenPages)
                    }
                }) { Text(stringResource(R.string.my_ids_continue_share)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingShareAction = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.my_ids_delete_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.my_ids_delete_msg)) },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirm = false; onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
