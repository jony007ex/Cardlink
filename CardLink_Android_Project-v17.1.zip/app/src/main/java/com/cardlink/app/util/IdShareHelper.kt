package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.IdDocumentPageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object IdShareHelper {

    fun saveIdPageBitmap(context: Context, bitmap: Bitmap, labelPrefix: String = "page"): String {
        val dir = File(context.filesDir, "my_ids").apply { if (!exists()) mkdirs() }
        val file = File(dir, "id_${labelPrefix}_${System.currentTimeMillis()}_${(100..999).random()}.jpg")
        val scaled = scaleDown(bitmap, 1800)
        FileOutputStream(file).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        if (scaled !== bitmap) scaled.recycle()
        return Uri.fromFile(file).toString()
    }

    suspend fun importUriAsIdPageImages(context: Context, uri: Uri): List<String> = withContext(Dispatchers.IO) {
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        if (mime.contains("pdf") || uri.toString().lowercase().endsWith(".pdf")) {
            renderPdfPagesToLocalImages(context, uri)
        } else {
            val bmp = ScannedCardStorageHelper.decodeGalleryUri(context, uri) ?: return@withContext emptyList()
            listOf(saveIdPageBitmap(context, bmp, "img"))
        }
    }

    private fun renderPdfPagesToLocalImages(context: Context, pdfUri: Uri): List<String> {
        val saved = mutableListOf<String>()
        runCatching {
            context.contentResolver.openFileDescriptor(pdfUri, "r")?.use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    val maxPages = renderer.pageCount.coerceAtMost(12)
                    for (i in 0 until maxPages) {
                        renderer.openPage(i).use { page ->
                            val scale = (1400f / page.width.coerceAtLeast(1)).coerceIn(1f, 2.5f)
                            val w = (page.width * scale).toInt().coerceAtLeast(1)
                            val h = (page.height * scale).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            Canvas(bmp).drawColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            saved.add(saveIdPageBitmap(context, bmp, "pdf_p${i + 1}"))
                            bmp.recycle()
                        }
                    }
                }
            }
        }
        return saved
    }

    suspend fun sharePagesAsPdf(
        context: Context,
        documentName: String,
        pages: List<IdDocumentPageEntity>
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(pages.isNotEmpty()) { "No pages selected to share." }
            val pdf = PdfDocument()
            val pageW = 1080
            val pageH = 1528
            pages.forEachIndexed { index, pageEntity ->
                val bmp = decodeLocalImage(context, pageEntity.imageUri) ?: return@forEachIndexed
                val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val pad = 60
                val availW = pageW - pad * 2
                val availH = pageH - pad * 2
                val ratio = minOf(availW.toFloat() / bmp.width, availH.toFloat() / bmp.height)
                val drawW = (bmp.width * ratio).toInt()
                val drawH = (bmp.height * ratio).toInt()
                val left = (pageW - drawW) / 2
                val top = (pageH - drawH) / 2
                canvas.drawBitmap(bmp, null, Rect(left, top, left + drawW, top + drawH), null)
                pdf.finishPage(page)
                bmp.recycle()
            }

            val dir = File(context.cacheDir, "cards").apply { if (!exists()) mkdirs() }
            val safeName = documentName.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "CardLink_ID" }
            val outFile = File(dir, "${safeName}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(outFile).use { pdf.writeTo(it) }
            pdf.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share ID Document (PDF)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            outFile
        }
    }

    suspend fun sharePagesAsImage(
        context: Context,
        documentName: String,
        pages: List<IdDocumentPageEntity>
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(pages.isNotEmpty()) { "No pages selected to share." }
            val bitmaps = pages.mapNotNull { decodeLocalImage(context, it.imageUri) }
            require(bitmaps.isNotEmpty()) { "Could not read ID image." }

            val combined = if (bitmaps.size == 1) {
                bitmaps.first()
            } else {
                val targetW = bitmaps.maxOf { it.width }.coerceAtMost(1400)
                val scaledList = bitmaps.map { b ->
                    val r = targetW.toFloat() / b.width.coerceAtLeast(1)
                    Bitmap.createScaledBitmap(b, targetW, (b.height * r).toInt().coerceAtLeast(1), true)
                }
                val gap = 32
                val totalH = scaledList.sumOf { it.height } + gap * (scaledList.size + 1)
                val outBmp = Bitmap.createBitmap(targetW + gap * 2, totalH, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(outBmp)
                canvas.drawColor(Color.WHITE)
                var y = gap.toFloat()
                scaledList.forEach { sb ->
                    canvas.drawBitmap(sb, gap.toFloat(), y, null)
                    y += sb.height + gap
                }
                outBmp
            }

            val dir = File(context.cacheDir, "cards").apply { if (!exists()) mkdirs() }
            val safeName = documentName.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "CardLink_ID" }
            val outFile = File(dir, "${safeName}_${System.currentTimeMillis()}.png")
            FileOutputStream(outFile).use { combined.compress(Bitmap.CompressFormat.PNG, 95, it) }

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share ID Document (Image)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            outFile
        }
    }

    private fun decodeLocalImage(context: Context, uriStr: String): Bitmap? = runCatching {
        val uri = Uri.parse(uriStr)
        if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
        else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    }.getOrNull()

    private fun scaleDown(src: Bitmap, maxEdge: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxEdge) return src
        val ratio = maxEdge.toFloat() / longest.toFloat()
        return Bitmap.createScaledBitmap(
            src,
            (src.width * ratio).toInt().coerceAtLeast(1),
            (src.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }
}
