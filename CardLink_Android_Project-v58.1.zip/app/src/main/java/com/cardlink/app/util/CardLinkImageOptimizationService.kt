package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.math.abs

enum class CardOptimizationProfile(
    val subFolder: String,
    val candidateMaxEdges: List<Int>,
    val candidateQualities: List<Int>
) {
    /**
     * Prioritizes small text, logos, and QR readability on Business Cards.
     */
    BUSINESS_CARD(
        subFolder = "scanned_cards",
        candidateMaxEdges = listOf(1800, 2100, 2400),
        candidateQualities = listOf(82, 88, 93)
    ),

    /**
     * Prioritizes crisp 1D barcode bars, QR quiet zones, and membership numbers on Loyalty Cards.
     */
    LOYALTY_CARD(
        subFolder = "loyalty_cards",
        candidateMaxEdges = listOf(1600, 2000, 2400),
        candidateQualities = listOf(84, 90, 94)
    )
}

data class OptimizedCardAssetResult(
    val encryptedMasterUri: String,
    val masterSizeBytes: Long,
    val estimatedSavedBytes: Long,
    val qualityUsed: Int,
    val maxEdgeUsed: Int,
    val formatLabel: String,
    val passedCodeValidation: Boolean
)

data class CardLinkStorageOverview(
    val contactsBytes: Long,
    val loyaltyBytes: Long,
    val idsAndDocsBytes: Long,
    val tempFilesBytes: Long,
    val totalSavedBytes: Long,
    val optimizedCount: Int
)

/**
 * Shared CardLink Image Optimization Service for Loyalty Cards and Contact Business Cards.
 * - Never blindly applied to My IDs / Passports / Business Documents.
 * - Uses an adaptive compression ladder (WebP / JPEG) gated by actual Barcode/QR + contrast readability validation.
 * - Encrypts final optimized masters into CardLink's AES-256-GCM .clenc vault.
 * - Deduplicates byte-identical optimized masters safely via SHA-256 hash filenames.
 * - Generates fast 384px regenerable thumbnails in cacheDir/card_thumbs/ (never backed up in Master Backup).
 * - Never logs sensitive user content, OCR text, card numbers, or barcode payloads.
 */
object CardLinkImageOptimizationService {

    private const val PREFS_OPT = "cardlink_image_opt_metrics_prefs"
    private const val KEY_TOTAL_SAVED_BYTES = "total_saved_bytes"
    private const val KEY_OPTIMIZED_COUNT = "optimized_count"
    private const val THUMB_CACHE_DIR = "card_thumbs"
    private const val THUMB_MAX_EDGE = 384
    private const val LEGACY_OPT_THRESHOLD_BYTES = 460L * 1024L // Only lazily optimize legacy masters > 460 KB

    @Suppress("DEPRECATION")
    private fun preferredLossyFormat(): Pair<Bitmap.CompressFormat, String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Bitmap.CompressFormat.WEBP_LOSSY to "WEBP"
        } else {
            Bitmap.CompressFormat.WEBP to "WEBP"
        }
    }

    private fun encodeCandidateBytes(
        bitmap: Bitmap,
        maxEdgePx: Int,
        quality: Int,
        useJpegFallback: Boolean
    ): ByteArray {
        val scaled = scaleDownProportional(bitmap, maxEdgePx)
        val baos = ByteArrayOutputStream()
        if (useJpegFallback) {
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        } else {
            val (fmt, _) = preferredLossyFormat()
            scaled.compress(fmt, quality, baos)
        }
        if (scaled !== bitmap) scaled.recycle()
        return baos.toByteArray()
    }

    private fun scaleDownProportional(src: Bitmap, maxEdgePx: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxEdgePx) return src
        val ratio = maxEdgePx.toFloat() / longest.toFloat()
        val targetW = (src.width * ratio).toInt().coerceAtLeast(1)
        val targetH = (src.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, targetW, targetH, true)
    }

    /**
     * Checks perceptual luminance preservation between source and decoded candidate on a small grid
     * so aggressive compression artifacts or washed-out contrast are rejected cleanly.
     */
    private fun passesPerceptualSanityCheck(source: Bitmap, candidate: Bitmap): Boolean {
        val gridW = 32
        val gridH = 20
        val sThumb = Bitmap.createScaledBitmap(source, gridW, gridH, true)
        val cThumb = Bitmap.createScaledBitmap(candidate, gridW, gridH, true)
        var totalDiff = 0.0
        var count = 0
        for (y in 0 until gridH) {
            for (x in 0 until gridW) {
                val sp = sThumb.getPixel(x, y)
                val cp = cThumb.getPixel(x, y)
                val sl = 0.299 * ((sp shr 16) and 0xFF) + 0.587 * ((sp shr 8) and 0xFF) + 0.114 * (sp and 0xFF)
                val cl = 0.299 * ((cp shr 16) and 0xFF) + 0.587 * ((cp shr 8) and 0xFF) + 0.114 * (cp and 0xFF)
                totalDiff += abs(sl - cl)
                count++
            }
        }
        sThumb.recycle()
        cThumb.recycle()
        val meanAbsDiff = totalDiff / count.coerceAtLeast(1)
        return meanAbsDiff <= 14.0
    }

    /**
     * Adaptive optimization pipeline:
     * Tests smallest acceptable candidate first, validates Barcode/QR decode preservation & perceptual quality,
     * escalates resolution/quality if needed, encrypts into .clenc vault with safe SHA-256 deduplication,
     * verifies decrypt/decode, and pre-warms the regenerable 384px thumbnail cache.
     */
    suspend fun optimizeAndEncryptCard(
        context: Context,
        croppedBitmap: Bitmap,
        profile: CardOptimizationProfile,
        prefix: String,
        expectedBarcodePayload: String = "",
        expectedQrPayload: String = "",
        baselineOriginalBytes: Long = 0L
    ): OptimizedCardAssetResult = withContext(Dispatchers.IO) {
        val (lossyFmt, lossyLabel) = preferredLossyFormat()
        val needsCodeCheck = expectedBarcodePayload.isNotBlank() || expectedQrPayload.isNotBlank()

        var chosenBytes: ByteArray? = null
        var chosenQuality = profile.candidateQualities.last()
        var chosenMaxEdge = profile.candidateMaxEdges.last()
        var chosenFormatLabel = lossyLabel
        var codePassed = !needsCodeCheck

        // Measure unoptimized JPEG92 reference size if caller didn't supply a baseline
        val referenceBytesSize = if (baselineOriginalBytes > 0L) {
            baselineOriginalBytes
        } else {
            val refBaos = ByteArrayOutputStream()
            croppedBitmap.compress(Bitmap.CompressFormat.JPEG, 92, refBaos)
            refBaos.size().toLong()
        }

        val steps = profile.candidateMaxEdges.size
        for (i in 0 until steps) {
            val edge = profile.candidateMaxEdges[i]
            val quality = profile.candidateQualities[i]
            val isFinalStep = (i == steps - 1)
            val useJpeg = isFinalStep && lossyFmt != Bitmap.CompressFormat.JPEG
            val bytes = encodeCandidateBytes(croppedBitmap, edge, quality, useJpeg)

            val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (decoded == null) continue

            val visualOk = passesPerceptualSanityCheck(croppedBitmap, decoded)
            val codesOk = if (needsCodeCheck) {
                val codes = runCatching { LoyaltyCodeHelper.detectCodesFromBitmap(decoded, "AUTO") }.getOrDefault(emptyList())
                val bcOk = expectedBarcodePayload.isBlank() || codes.any { !it.isQr && it.rawValue == expectedBarcodePayload }
                val qrOk = expectedQrPayload.isBlank() || codes.any { it.isQr && it.rawValue == expectedQrPayload }
                bcOk && qrOk
            } else true

            decoded.recycle()

            if ((visualOk && codesOk) || isFinalStep) {
                chosenBytes = bytes
                chosenQuality = quality
                chosenMaxEdge = edge
                chosenFormatLabel = if (useJpeg) "JPEG" else lossyLabel
                codePassed = codesOk
                break
            }
        }

        val finalBytes = chosenBytes ?: encodeCandidateBytes(croppedBitmap, 2000, 92, useJpegFallback = true)
        val uriStr = saveDeduplicatedEncryptedAsset(context, finalBytes, profile.subFolder, prefix)
        val savedLen = finalBytes.size.toLong()
        val deltaSaved = (referenceBytesSize - savedLen).coerceAtLeast(0L)
        if (deltaSaved > 0L) {
            recordOptimizationSavings(context, deltaSaved)
        }

        // Pre-warm lightweight 384px regenerable thumbnail in cacheDir/card_thumbs/
        runCatching { generateOrGetThumbnailBitmap(context, uriStr, "", croppedBitmap) }
        finalBytes.fill(0)

        OptimizedCardAssetResult(
            encryptedMasterUri = uriStr,
            masterSizeBytes = savedLen,
            estimatedSavedBytes = deltaSaved,
            qualityUsed = chosenQuality,
            maxEdgeUsed = chosenMaxEdge,
            formatLabel = chosenFormatLabel,
            passedCodeValidation = codePassed
        )
    }

    /**
     * Content-addressed encrypted storage: computes SHA-256 of optimized plaintext bytes so identical
     * re-imported cards reuse the existing encrypted vault file instead of duplicating storage.
     */
    private fun saveDeduplicatedEncryptedAsset(
        context: Context,
        plainBytes: ByteArray,
        subFolder: String,
        prefix: String
    ): String {
        val hashPrefix = sha256Hex(plainBytes).take(24)
        val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
        val dedupFile = File(dir, "${prefix}_opt_${hashPrefix}.clenc")
        if (dedupFile.exists() && dedupFile.length() > 16L) {
            // Verify existing deduplicated asset decrypts cleanly before reusing
            val verified = VaultCryptoManager.readDecryptedBytesFromFile(dedupFile)
            if (verified != null && verified.isNotEmpty()) {
                verified.fill(0)
                return Uri.fromFile(dedupFile).toString()
            }
        }
        val uriStr = VaultCryptoManager.saveEncryptedBytes(context, plainBytes, subFolder, "${prefix}_opt")
        // Verify newly written encrypted asset decrypts cleanly
        val verifyRead = VaultCryptoManager.readDecryptedBytes(context, uriStr)
        verifyRead?.fill(0)
        return uriStr
    }

    /**
     * Lazy legacy migration for oversized existing Loyalty/Business card .clenc assets (> 460 KB).
     * Never blocks app startup. Preserves old file until new optimized master is verified decryptable.
     * Returns new URI if optimized, or null if already efficient / skipped.
     */
    suspend fun optimizeLegacyVaultAssetIfNeeded(
        context: Context,
        existingUri: String?,
        profile: CardOptimizationProfile,
        prefix: String,
        expectedBarcodePayload: String = "",
        expectedQrPayload: String = ""
    ): String? = withContext(Dispatchers.IO) {
        if (existingUri.isNullOrBlank() || !existingUri.endsWith(".clenc", ignoreCase = true)) return@withContext null
        if (existingUri.contains("_opt_")) return@withContext null // Already optimized

        val oldFile = runCatching { File(Uri.parse(existingUri).path ?: return@withContext null) }.getOrNull() ?: return@withContext null
        if (!oldFile.exists() || oldFile.length() < LEGACY_OPT_THRESHOLD_BYTES) return@withContext null

        val oldLen = oldFile.length()
        val decodedOrig = VaultCryptoManager.decodeVaultBitmapUncached(context, existingUri, 2400) ?: return@withContext null
        try {
            val result = optimizeAndEncryptCard(
                context = context,
                croppedBitmap = decodedOrig,
                profile = profile,
                prefix = prefix,
                expectedBarcodePayload = expectedBarcodePayload,
                expectedQrPayload = expectedQrPayload,
                baselineOriginalBytes = oldLen
            )
            // Require meaningful reduction (>= 15%) AND code validation pass before swapping
            if (!result.passedCodeValidation || result.masterSizeBytes >= (oldLen * 85L) / 100L) {
                if (result.encryptedMasterUri != existingUri) {
                    ScannedCardStorageHelper.deleteSavedCardImage(result.encryptedMasterUri)
                }
                return@withContext null
            }
            // Verify new asset opens cleanly before caller updates DB reference
            val reopened = VaultCryptoManager.decodeVaultBitmapUncached(context, result.encryptedMasterUri, 600)
            if (reopened == null) {
                ScannedCardStorageHelper.deleteSavedCardImage(result.encryptedMasterUri)
                return@withContext null
            }
            reopened.recycle()
            result.encryptedMasterUri
        } finally {
            runCatching { decodedOrig.recycle() }
        }
    }

    /**
     * Fast Regenerable Thumbnail Layer (384px WebP inside cacheDir/card_thumbs/).
     * - Encrypted at rest via VaultCryptoManager so no plaintext card image ever persists on disk.
     * - Excluded automatically from Master Backup (lives inside cacheDir).
     * - Prevents list screens from decoding full 2000px masters on every scroll.
     */
    fun generateOrGetThumbnailBitmap(
        context: Context,
        masterUri: String,
        cacheBustKey: String = "",
        preDecodedBitmap: Bitmap? = null
    ): Bitmap? {
        if (masterUri.isBlank()) return null
        val thumbDir = File(context.cacheDir, THUMB_CACHE_DIR).apply { if (!exists()) mkdirs() }
        val thumbName = "th_${sha256Hex("${masterUri}_$cacheBustKey".toByteArray()).take(24)}.clenc"
        val thumbFile = File(thumbDir, thumbName)
        val thumbUri = Uri.fromFile(thumbFile).toString()

        // 1. Fast path: load existing lightweight thumbnail
        if (thumbFile.exists() && thumbFile.length() > 16L) {
            VaultCryptoManager.decodeVaultBitmap(context, thumbUri, THUMB_MAX_EDGE, cacheBustKey)?.let { return it }
        }

        // 2. Slow path (once per image): derive 384px WebP thumbnail and cache it
        val sourceBmp = preDecodedBitmap ?: VaultCryptoManager.decodeVaultBitmapUncached(context, masterUri, THUMB_MAX_EDGE)
            ?: return null
        return try {
            val thumbBmp = scaleDownProportional(sourceBmp, THUMB_MAX_EDGE)
            val thumbBytes = encodeCandidateBytes(thumbBmp, THUMB_MAX_EDGE, 78, useJpegFallback = false)
            runCatching {
                val enc = VaultCryptoManager.encryptRawVaultBytes(thumbBytes)
                FileOutputStream(thumbFile).use { out ->
                    out.write(enc)
                    out.flush()
                }
            }
            thumbBytes.fill(0)
            if (thumbBmp !== sourceBmp && preDecodedBitmap == null) {
                sourceBmp.recycle()
            }
            thumbBmp
        } catch (_: Exception) {
            if (preDecodedBitmap == null) runCatching { sourceBmp.recycle() }
            null
        }
    }

    fun evictThumbnailCacheForUri(context: Context, masterUri: String?) {
        if (masterUri.isNullOrBlank()) return
        VaultCryptoManager.evictFromCache(masterUri)
    }

    fun clearAllThumbnails(context: Context): Int {
        val dir = File(context.cacheDir, THUMB_CACHE_DIR)
        if (!dir.exists() || !dir.isDirectory) return 0
        var removed = 0
        dir.listFiles()?.forEach { f ->
            if (f.isFile && runCatching { f.delete() }.getOrDefault(false)) removed++
        }
        return removed
    }

    fun computeStorageOverview(context: Context): CardLinkStorageOverview {
        fun dirBytes(dir: File): Long {
            if (!dir.exists()) return 0L
            return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        }
        val contactsBytes = dirBytes(File(context.filesDir, "scanned_cards"))
        val loyaltyBytes = dirBytes(File(context.filesDir, "loyalty_cards"))
        val idsBytes = dirBytes(File(context.filesDir, "my_ids")) + dirBytes(File(context.filesDir, "vault_ids"))
        val tempBytes = dirBytes(File(context.cacheDir, "secure_temp_exports")) +
            dirBytes(File(context.cacheDir, THUMB_CACHE_DIR)) +
            dirBytes(File(context.cacheDir, "cards")) +
            dirBytes(File(context.cacheDir, "exports")) +
            dirBytes(File(context.cacheDir, "qr_exports"))

        val prefs = context.getSharedPreferences(PREFS_OPT, Context.MODE_PRIVATE)
        val totalSaved = prefs.getLong(KEY_TOTAL_SAVED_BYTES, 0L)
        val optCount = prefs.getInt(KEY_OPTIMIZED_COUNT, 0)

        return CardLinkStorageOverview(
            contactsBytes = contactsBytes,
            loyaltyBytes = loyaltyBytes,
            idsAndDocsBytes = idsBytes,
            tempFilesBytes = tempBytes,
            totalSavedBytes = totalSaved,
            optimizedCount = optCount
        )
    }

    fun clearTemporaryFiles(context: Context): Int {
        val expRemoved = TempSecureExportVault.cleanupExpiredExportsSync(context, forceAll = true)
        val thumbRemoved = clearAllThumbnails(context)
        return expRemoved + thumbRemoved
    }

    fun formatBytesReadable(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.1f MB", mb)
    }

    private fun recordOptimizationSavings(context: Context, savedDeltaBytes: Long) {
        val prefs = context.getSharedPreferences(PREFS_OPT, Context.MODE_PRIVATE)
        val prev = prefs.getLong(KEY_TOTAL_SAVED_BYTES, 0L)
        val cnt = prefs.getInt(KEY_OPTIMIZED_COUNT, 0)
        prefs.edit()
            .putLong(KEY_TOTAL_SAVED_BYTES, prev + savedDeltaBytes)
            .putInt(KEY_OPTIMIZED_COUNT, cnt + 1)
            .apply()
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }
}
