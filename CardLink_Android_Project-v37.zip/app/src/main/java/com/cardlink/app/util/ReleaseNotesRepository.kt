package com.cardlink.app.util

import android.content.Context
import android.os.Build
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.cardlink.app.R

enum class ReleaseChangeCategory(
    val labelRes: Int,
    val icon: ImageVector
) {
    NEW(R.string.wn_cat_new, Icons.Default.AutoAwesome),
    IMPROVED(R.string.wn_cat_improved, Icons.Default.Bolt),
    SECURITY(R.string.wn_cat_security, Icons.Default.Shield),
    FIXED(R.string.wn_cat_fixed, Icons.Default.Build)
}

data class ReleaseChange(
    val id: String,
    val category: ReleaseChangeCategory,
    val titleRes: Int,
    val descRes: Int,
    val icon: ImageVector,
    val destinationRoute: String? = null,
    val actionLabelRes: Int? = null
)

data class ReleaseNoteEntry(
    val versionCode: Int,
    val versionName: String,
    val releaseDate: String,
    val summaryRes: Int,
    val changes: List<ReleaseChange>
)

object ReleaseNotesRepository {
    private const val PREFS = "cardlink_release_notes_prefs"
    private const val KEY_LAST_VIEWED_VERSION_NAME = "last_viewed_whats_new_version_name"
    private const val KEY_LAST_VIEWED_VERSION_CODE = "last_viewed_whats_new_version_code"

    /**
     * Curated, offline-first release history (latest 6 major releases).
     * Benefit-first language — no internal developer jargon.
     */
    val releases: List<ReleaseNoteEntry> = listOf(
        ReleaseNoteEntry(
            versionCode = 42,
            versionName = "15.2.0",
            releaseDate = "23 Nov 2026",
            summaryRes = R.string.wn_15_2_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_15_2_protection_status",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_15_2_c1_title,
                    descRes = R.string.wn_15_2_c1_desc,
                    icon = Icons.Default.VerifiedUser,
                    destinationRoute = "menu_privacy",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_2_checkup",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_15_2_c2_title,
                    descRes = R.string.wn_15_2_c2_desc,
                    icon = Icons.Default.FactCheck,
                    destinationRoute = "security_checkup",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_2_clipboard",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_15_2_c3_title,
                    descRes = R.string.wn_15_2_c3_desc,
                    icon = Icons.Default.ContentPaste
                ),
                ReleaseChange(
                    id = "wn_15_2_activity",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_15_2_c4_title,
                    descRes = R.string.wn_15_2_c4_desc,
                    icon = Icons.Default.History,
                    destinationRoute = "security_activity",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 41,
            versionName = "15.1.0",
            releaseDate = "23 Nov 2026",
            summaryRes = R.string.wn_15_1_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_15_1_reauth",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_15_1_c1_title,
                    descRes = R.string.wn_15_1_c1_desc,
                    icon = Icons.Default.Fingerprint,
                    destinationRoute = "menu_privacy",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_1_temp_vault",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_15_1_c2_title,
                    descRes = R.string.wn_15_1_c2_desc,
                    icon = Icons.Default.Shield
                ),
                ReleaseChange(
                    id = "wn_15_1_screen_privacy",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_15_1_c3_title,
                    descRes = R.string.wn_15_1_c3_desc,
                    icon = Icons.Default.VisibilityOff
                ),
                ReleaseChange(
                    id = "wn_15_1_gateway",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_15_1_c4_title,
                    descRes = R.string.wn_15_1_c4_desc,
                    icon = Icons.Default.VerifiedUser
                ),
                ReleaseChange(
                    id = "wn_15_1_perms",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_15_1_c5_title,
                    descRes = R.string.wn_15_1_c5_desc,
                    icon = Icons.Default.AdminPanelSettings,
                    destinationRoute = "menu_permissions",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 40,
            versionName = "15.0.0",
            releaseDate = "22 Nov 2026",
            summaryRes = R.string.wn_15_0_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_15_0_nfc_studio",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_15_0_c1_title,
                    descRes = R.string.wn_15_0_c1_desc,
                    icon = Icons.Default.Nfc,
                    destinationRoute = "nfc_studio",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_0_meeting_voice",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_15_0_c2_title,
                    descRes = R.string.wn_15_0_c2_desc,
                    icon = Icons.Default.Mic
                ),
                ReleaseChange(
                    id = "wn_15_0_quality",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_15_0_c3_title,
                    descRes = R.string.wn_15_0_c3_desc,
                    icon = Icons.Default.FactCheck,
                    destinationRoute = "data_quality",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_0_recycle_bin",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_15_0_c4_title,
                    descRes = R.string.wn_15_0_c4_desc,
                    icon = Icons.Default.DeleteSweep,
                    destinationRoute = "recycle_bin",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_15_0_migration",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_15_0_c5_title,
                    descRes = R.string.wn_15_0_c5_desc,
                    icon = Icons.Default.PhoneAndroid,
                    destinationRoute = "device_migration",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 38,
            versionName = "13.1.0",
            releaseDate = "22 Nov 2026",
            summaryRes = R.string.wn_13_1_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_13_1_whats_new",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_13_1_c1_title,
                    descRes = R.string.wn_13_1_c1_desc,
                    icon = Icons.Default.AutoAwesome
                ),
                ReleaseChange(
                    id = "wn_13_1_privacy_preview",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_13_1_c2_title,
                    descRes = R.string.wn_13_1_c2_desc,
                    icon = Icons.Default.PrivacyTip,
                    destinationRoute = "share",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_13_1_expiry_center",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_13_1_c3_title,
                    descRes = R.string.wn_13_1_c3_desc,
                    icon = Icons.Default.EventNote,
                    destinationRoute = "expiry_center",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_13_1_undo_restore",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_13_1_c4_title,
                    descRes = R.string.wn_13_1_c4_desc,
                    icon = Icons.Default.Undo,
                    destinationRoute = "menu_backup_export",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_13_1_save_target",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_13_1_c5_title,
                    descRes = R.string.wn_13_1_c5_desc,
                    icon = Icons.Default.Share
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 36,
            versionName = "12.1.0",
            releaseDate = "21 Nov 2026",
            summaryRes = R.string.wn_12_1_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_12_1_theme_sync",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_12_1_c1_title,
                    descRes = R.string.wn_12_1_c1_desc,
                    icon = Icons.Default.Palette,
                    destinationRoute = "menu_theme_studio",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_12_1_nav_colors",
                    category = ReleaseChangeCategory.FIXED,
                    titleRes = R.string.wn_12_1_c2_title,
                    descRes = R.string.wn_12_1_c2_desc,
                    icon = Icons.Default.CheckCircle
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 35,
            versionName = "12.0.0",
            releaseDate = "21 Nov 2026",
            summaryRes = R.string.wn_12_0_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_12_0_gallery",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_12_0_c1_title,
                    descRes = R.string.wn_12_0_c1_desc,
                    icon = Icons.Default.Style,
                    destinationRoute = "customize",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_12_0_flip",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_12_0_c2_title,
                    descRes = R.string.wn_12_0_c2_desc,
                    icon = Icons.Default.Flip
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 34,
            versionName = "11.2.0",
            releaseDate = "21 Nov 2026",
            summaryRes = R.string.wn_11_2_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_11_2_fab",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_11_2_c1_title,
                    descRes = R.string.wn_11_2_c1_desc,
                    icon = Icons.Default.AddCircle
                ),
                ReleaseChange(
                    id = "wn_11_2_insights",
                    category = ReleaseChangeCategory.IMPROVED,
                    titleRes = R.string.wn_11_2_c2_title,
                    descRes = R.string.wn_11_2_c2_desc,
                    icon = Icons.Default.Analytics,
                    destinationRoute = "analytics",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 31,
            versionName = "10.0.0",
            releaseDate = "21 Nov 2026",
            summaryRes = R.string.wn_10_0_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_10_0_master_backup",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_10_0_c1_title,
                    descRes = R.string.wn_10_0_c1_desc,
                    icon = Icons.Default.Storage,
                    destinationRoute = "menu_backup_export",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_10_0_security",
                    category = ReleaseChangeCategory.SECURITY,
                    titleRes = R.string.wn_10_0_c2_title,
                    descRes = R.string.wn_10_0_c2_desc,
                    icon = Icons.Default.Lock,
                    destinationRoute = "menu_privacy",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        ),
        ReleaseNoteEntry(
            versionCode = 29,
            versionName = "9.1.0",
            releaseDate = "21 Nov 2026",
            summaryRes = R.string.wn_9_1_summary,
            changes = listOf(
                ReleaseChange(
                    id = "wn_9_1_scanner",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_9_1_c1_title,
                    descRes = R.string.wn_9_1_c1_desc,
                    icon = Icons.Default.QrCodeScanner,
                    destinationRoute = "scan_qr",
                    actionLabelRes = R.string.wn_try_now
                ),
                ReleaseChange(
                    id = "wn_9_1_studio",
                    category = ReleaseChangeCategory.NEW,
                    titleRes = R.string.wn_9_1_c2_title,
                    descRes = R.string.wn_9_1_c2_desc,
                    icon = Icons.Default.QrCode2,
                    destinationRoute = "qr_studio",
                    actionLabelRes = R.string.wn_try_now
                )
            )
        )
    )

    fun getInstalledVersion(context: Context): Pair<String, Int> = runCatching {
        val pi = context.packageManager.getPackageInfo(context.packageName, 0)
        val verName = pi.versionName ?: releases.first().versionName
        val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pi.longVersionCode.toInt()
        } else {
            @Suppress("DEPRECATION")
            pi.versionCode
        }
        Pair(verName, verCode)
    }.getOrDefault(Pair(releases.first().versionName, releases.first().versionCode))

    fun hasUnseenReleaseNotes(context: Context): Boolean {
        val (curName, curCode) = getInstalledVersion(context)
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastCode = p.getInt(KEY_LAST_VIEWED_VERSION_CODE, 0)
        val lastName = p.getString(KEY_LAST_VIEWED_VERSION_NAME, "") ?: ""
        return curCode > lastCode || (lastName.isNotBlank() && lastName != curName)
    }

    fun markCurrentVersionViewed(context: Context) {
        val (curName, curCode) = getInstalledVersion(context)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LAST_VIEWED_VERSION_NAME, curName)
            .putInt(KEY_LAST_VIEWED_VERSION_CODE, curCode)
            .apply()
    }
}
