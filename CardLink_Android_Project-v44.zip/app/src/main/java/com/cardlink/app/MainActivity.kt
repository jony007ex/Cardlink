package com.cardlink.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.rotate
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.nearby.BluetoothDiscoveryManager
import com.cardlink.app.nearby.NearbyCardExchangeManager
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.tile.CardLinkTileService
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.components.BackupRestoreSection
import com.cardlink.app.ui.components.BusinessCardBackView
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.components.MyCardFloatingQuickToolsOverlay
import com.cardlink.app.ui.components.ContactsFilterAndSortSheet
import com.cardlink.app.ui.components.ContactsSummaryCardsRow
import com.cardlink.app.ui.components.SmartPrivacyPreviewCard
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.ui.components.FlippableBusinessCardView
import com.cardlink.app.ui.screens.*
import com.cardlink.app.ui.theme.*
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkGlanceWidget
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : FragmentActivity() {

    private val viewModel: CardLinkViewModel by viewModels()
    private lateinit var nfcReaderManager: NfcReaderManager
    private lateinit var bluetoothDiscoveryManager: BluetoothDiscoveryManager
    private var isAppUnlocked by mutableStateOf(true)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LanguageManager.wrapBaseContext(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FollowUpScheduler.ensureChannels(this)
        TempSecureExportVault.cleanupExpiredExportsAsync(this)
        isAppUnlocked = !BiometricLockHelper.isLockEnabled(this)

        bluetoothDiscoveryManager = BluetoothDiscoveryManager(this)
        nfcReaderManager = NfcReaderManager(this) { vcfPayload ->
            val contact = CardShareHelper.parseVCardToContact(vcfPayload, "NFC Tap")
            viewModel.saveReceivedContact(contact, null)
            Toast.makeText(this, "Saved ${contact.fullName} via NFC!", Toast.LENGTH_LONG).show()
        }

        handleIncomingNfcIntent(intent)
        val validatedInbound = ExternalIntentGateway.resolveInboundIntent(this, intent)
        val incomingSharePayload = (validatedInbound as? ValidatedInboundDestination.ShareIntake)?.payload
        if (validatedInbound is ValidatedInboundDestination.Blocked) {
            Toast.makeText(this, validatedInbound.reason, Toast.LENGTH_LONG).show()
        }
        if (validatedInbound is ValidatedInboundDestination.SafeRoute && validatedInbound.requiresAuth && BiometricLockHelper.isLockEnabled(this)) {
            isAppUnlocked = false
            SensitiveActionAuthenticator.invalidateTrustWindow()
            SecureClipboardHelper.clearCardLinkClipboardNow(this)
        }
        val initialRoute = when (validatedInbound) {
            is ValidatedInboundDestination.ShareIntake -> "share_intake"
            is ValidatedInboundDestination.SafeRoute -> validatedInbound.route
            else -> "splash"
        }

        setContent {
            val darkOverride by viewModel.darkThemeOverride.collectAsState()
            val customAppTheme by viewModel.appCustomTheme.collectAsState()
            val appLanguage by viewModel.appLanguage.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
            val localizedContext = remember(appLanguage) {
                LanguageManager.wrapActivityForCompose(this@MainActivity, appLanguage)
            }
            val localizedConfig = remember(localizedContext) {
                localizedContext.resources.configuration
            }

            val keyguardLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
                if (res.resultCode == RESULT_OK) isAppUnlocked = true
            }

            fun triggerAuth() {
                BiometricLockHelper.showPrompt(
                    activity = this@MainActivity,
                    onSuccess = { isAppUnlocked = true },
                    onFallbackToDeviceCredential = {
                        BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity)?.let { keyguardLauncher.launch(it) }
                    },
                    onError = { msg -> Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
                )
            }

            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalConfiguration provides localizedConfig
            ) {
            CardLinkTheme(darkTheme = darkOverride ?: isSystemInDarkTheme(), customConfig = customAppTheme) {
                if (!isAppUnlocked) {
                    LaunchedEffect(Unit) { triggerAuth() }
                    Box(modifier = Modifier.fillMaxSize().background(Color(customAppTheme.backgroundHex.toInt())).padding(24.dp), contentAlignment = Alignment.Center) {
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(customAppTheme.surfaceHex.toInt()))) {
                            Column(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Icon(Icons.Default.Fingerprint, null, tint = Color(customAppTheme.iconHex.toInt()), modifier = Modifier.size(68.dp))
                                Text(stringResource(R.string.lock_title), color = Color(customAppTheme.textHex.toInt()), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text(stringResource(R.string.lock_subtitle), color = Color(customAppTheme.textHex.toInt()).copy(alpha = 0.78f), fontSize = 13.sp)
                                Button(
                                    onClick = { triggerAuth() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(customAppTheme.buttonHex.toInt()), contentColor = MaterialTheme.colorScheme.onPrimary),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) { Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.lock_unlock_biometric), fontWeight = FontWeight.Bold) }
                                val credIntent = remember { BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity) }
                                if (credIntent != null) {
                                    OutlinedButton(onClick = { keyguardLauncher.launch(credIntent) }, modifier = Modifier.fillMaxWidth()) {
                                        Text(stringResource(R.string.lock_unlock_device), color = Color(customAppTheme.accentHex.toInt()))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    CardLinkAppScaffold(
                        viewModel = viewModel, nfcReaderManager = nfcReaderManager,
                        bluetoothDiscoveryManager = bluetoothDiscoveryManager, startRoute = initialRoute,
                        incomingSharePayload = incomingSharePayload,
                        onLockNow = { isAppUnlocked = false; SensitiveActionAuthenticator.invalidateTrustWindow()
            SecureClipboardHelper.clearCardLinkClipboardNow(this) }
                    )
                }
            }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIncomingNfcIntent(intent) }

    private fun handleIncomingNfcIntent(intent: Intent?) {
        if (intent?.action == NfcAdapter.ACTION_NDEF_DISCOVERED) {
            @Suppress("DEPRECATION")
            val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
            rawMsgs?.forEach { parcelable ->
                val ndefMsg = parcelable as? NdefMessage ?: return@forEach
                ndefMsg.records.forEach { record ->
                    val payloadText = String(record.payload, Charsets.UTF_8)
                    if (payloadText.contains("BEGIN:VCARD", ignoreCase = true)) {
                        val contact = CardShareHelper.parseVCardToContact(payloadText, "NFC vCard")
                        viewModel.saveReceivedContact(contact, null)
                        Toast.makeText(this, "Saved ${contact.fullName} via NFC vCard!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onPause() { super.onPause(); nfcReaderManager.disableReaderMode() }
    override fun onStop() {
        super.onStop()
        SecurityHardeningManager.recordAppBackgrounded()
        if (BiometricLockHelper.isLockEnabled(this)) {
            isAppUnlocked = false
            SensitiveActionAuthenticator.invalidateTrustWindow()
            SecureClipboardHelper.clearCardLinkClipboardNow(this)
        }
    }

    override fun onResume() {
        super.onResume()
        if (SecurityHardeningManager.shouldLockOnResume(this)) {
            isAppUnlocked = false
            SensitiveActionAuthenticator.invalidateTrustWindow()
            SecureClipboardHelper.clearCardLinkClipboardNow(this)
        }
        TempSecureExportVault.cleanupExpiredExportsAsync(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkAppScaffold(
    incomingSharePayload: IncomingSharePayload? = null,
    viewModel: CardLinkViewModel,
    nfcReaderManager: NfcReaderManager,
    bluetoothDiscoveryManager: BluetoothDiscoveryManager,
    startRoute: String,
    onLockNow: () -> Unit = {}
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val activeCard by viewModel.activeCard.collectAsState()
    val myCards by viewModel.myCards.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val totalContactsCount by viewModel.totalContactsCount.collectAsState()
    val favoriteContactsCount by viewModel.favoriteContactsCount.collectAsState()
    val deviceSyncMessage by viewModel.deviceSyncMessage.collectAsState()

    LaunchedEffect(deviceSyncMessage) {
        val msg = deviceSyncMessage
        if (!msg.isNullOrBlank()) {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearDeviceSyncMessage()
        }
    }
    val shareHistory by viewModel.shareHistory.collectAsState()
    val followUps by viewModel.followUps.collectAsState()
    val loyaltyCards by viewModel.loyaltyCards.collectAsState()
    val idDocuments by viewModel.idDocuments.collectAsState()
    val idPages by viewModel.idPages.collectAsState()
    val qrProjects by viewModel.qrProjects.collectAsState()
    val qrDesignPresets by viewModel.qrDesignPresets.collectAsState()
    val qrScanHistory by viewModel.qrScanHistory.collectAsState()
    val saveScanHistoryEnabled by viewModel.saveScanHistoryEnabled.collectAsState()
    val securityAuditLogs by viewModel.securityAuditLogs.collectAsState()
    val secureNotes by viewModel.secureNotes.collectAsState()
    val favoriteToolIds by viewModel.favoriteToolIds.collectAsState()
    val recentToolIds by viewModel.recentToolIds.collectAsState()
    val hasUnseenWhatsNew by viewModel.hasUnseenWhatsNew.collectAsState()
    val nfcProjects by viewModel.nfcProjects.collectAsState()
    val recycleBinItems by viewModel.recycleBinItems.collectAsState()
    val conferenceQueue by viewModel.conferenceQueue.collectAsState()
    val pendingDrafts by viewModel.pendingDrafts.collectAsState()
    val customAppTheme by viewModel.appCustomTheme.collectAsState()
    val eventMode by viewModel.eventMode.collectAsState()
    val darkThemeOverride by viewModel.darkThemeOverride.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    var showEventModeDialog by remember { mutableStateOf(false) }
    var autoOpenContactsImport by remember { mutableStateOf(startRoute == "contacts_import") }
    var autoOpenCalendarCreate by remember { mutableStateOf(startRoute == "calendar_new") }
    val normalizedStartRoute = when (startRoute) {
        "contacts_import" -> "contacts"
        "calendar_new" -> "calendar"
        else -> startRoute
    }
    val scope = rememberCoroutineScope()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current

    val bottomNavRoutes = listOf("home", "contacts", "calendar", "tools", "settings")

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomNavRoutes) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    val navItemColors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    NavigationBarItem(selected = currentRoute == "home", onClick = { navController.navigate("home") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Badge, null) }, label = { Text(stringResource(R.string.nav_my_card)) }, colors = navItemColors)
                    NavigationBarItem(selected = currentRoute == "contacts", onClick = { navController.navigate("contacts") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Contacts, null) }, label = { Text(stringResource(R.string.nav_contacts)) }, colors = navItemColors)
                    NavigationBarItem(selected = currentRoute == "calendar", onClick = { navController.navigate("calendar") { launchSingleTop = true } }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text(stringResource(R.string.nav_calendar)) }, colors = navItemColors)
                    NavigationBarItem(selected = currentRoute == "tools", onClick = { navController.navigate("tools") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Build, null) }, label = { Text(stringResource(R.string.nav_tools)) }, colors = navItemColors)
                    NavigationBarItem(selected = currentRoute == "settings", onClick = { navController.navigate("settings") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Menu, null) }, label = { Text(stringResource(R.string.nav_menu)) }, colors = navItemColors)
                }
            }
        }
    ) { padding ->
        NavHost(navController = navController, startDestination = normalizedStartRoute, modifier = Modifier.padding(padding)) {
            composable("splash") {
                val alphaAnim = remember { Animatable(0f) }
                val scaleAnim = remember { Animatable(0.94f) }

                LaunchedEffect(Unit) {
                    launch {
                        alphaAnim.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
                        )
                    }
                    launch {
                        scaleAnim.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing)
                        )
                    }
                    delay(1450)
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0C1943))
                        .padding(horizontal = 36.dp, vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.cardlink_welcome_brand),
                        contentDescription = "CardLink — Connect Beyond Paper",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 360.dp)
                            .aspectRatio(1f)
                            .alpha(alphaAnim.value)
                            .scale(scaleAnim.value)
                    )
                }
            }

            composable("home") {
                val quickPrivacy by viewModel.quickPrivacyMode.collectAsState()
                val displayCard = remember(activeCard, quickPrivacy) {
                    if (quickPrivacy) activeCard.copy(sharePhone = false, shareAddress = false, shareEmail = false) else activeCard
                }
                Box(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Clean, Balanced My Card Header (+ Quick Tools moved to Floating Action Button)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Card Link", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("${stringResource(R.string.home_active_prefix)} ${activeCard.profileTitle}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { navController.navigate("global_search") }) {
                                    Icon(Icons.Default.Search, contentDescription = stringResource(R.string.ux_global_search_title), tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { viewModel.toggleQuickPrivacyMode() }) {
                                    Icon(
                                        if (quickPrivacy) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        "Quick Privacy",
                                        tint = if (quickPrivacy) MaterialTheme.colorScheme.primary else LocalContentColor.current
                                    )
                                }
                                IconButton(onClick = { navController.navigate("customize") }) {
                                    Icon(Icons.Default.Palette, "Customize")
                                }
                                IconButton(onClick = { navController.navigate("edit_card") }) {
                                    Icon(Icons.Default.Edit, "Edit")
                                }
                            }
                        }

                        if (myCards.size > 1) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                myCards.forEach { profile ->
                                    FilterChip(
                                        selected = profile.id == activeCard.id,
                                        onClick = { viewModel.switchActiveProfile(profile.id) },
                                        label = {
                                            Text(
                                                text = profile.profileTitle,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        // Business Card Preview (Hero)
                        FlippableBusinessCardView(card = displayCard)
                        Text(
                            text = if (quickPrivacy) stringResource(R.string.home_quick_privacy_on) else stringResource(R.string.home_tap_to_flip),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Primary Action: Share My Card
                        Button(
                            onClick = {
                                UxExperiencePrefs.markShareTested(context)
                                navController.navigate("share")
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Share, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.home_share_my_card), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        // Capture Actions: Scan QR & Scan Card
                        Button(
                            onClick = { navController.navigate("scan_qr") },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.home_scan_qr), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { navController.navigate("scan_ocr") },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.DocumentScanner, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.home_scan_card), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        // Event / Conference Mode
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { showEventModeDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (eventMode.isActive) Color(0xFF0E2A47) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                            ),
                            border = if (eventMode.isActive) BorderStroke(1.dp, Color(0xFF00E5FF)) else null
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EventNote,
                                        contentDescription = null,
                                        tint = if (eventMode.isActive) Color(0xFF00E5FF) else MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text(
                                            text = if (eventMode.isActive) "${stringResource(R.string.home_event_mode_on)} ${eventMode.eventName}" else stringResource(R.string.tools_event_mode),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (eventMode.isActive) Color(0xFF00E5FF) else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (eventMode.isActive) {
                                                listOf(eventMode.location.takeIf { it.isNotBlank() }, stringResource(R.string.home_event_auto_tagging)).filterNotNull().joinToString(" • ")
                                            } else stringResource(R.string.home_event_tap_desc),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                                if (eventMode.isActive) {
                                    TextButton(onClick = {
                                        viewModel.deactivateEventMode()
                                        Toast.makeText(context, "Event Mode stopped", Toast.LENGTH_SHORT).show()
                                    }) { Text(stringResource(R.string.action_stop), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                                } else {
                                    Text(stringResource(R.string.action_start), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        // Sufficient bottom clearance so Floating "+" Quick Tools FAB never covers Event Mode or final controls
                        Spacer(Modifier.height(84.dp))
                    }

                    // Anchored Bottom-Right Floating "+" Quick Tools FAB (Synchronized live with Tools -> Favorites)
                    MyCardFloatingQuickToolsOverlay(
                        favoriteToolIds = favoriteToolIds,
                        onLaunchTool = { tool ->
                            viewModel.recordToolUsed(tool.id)
                            if (tool.id == "event_mode") showEventModeDialog = true
                            else navController.navigate(tool.route) { launchSingleTop = true }
                        },
                        onManageFavorites = {
                            navController.navigate("tools") { launchSingleTop = true }
                        }
                    )
                }
            }

            composable("edit_card") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                val profilePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "profile")?.let { draft = draft.copy(profilePhotoUri = it) }
                }
                val companyLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "logo")?.let { draft = draft.copy(companyLogoUri = it) }
                }
                val editLocPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    GeoLocationHelper.getCurrentGpsCoordinates(context)?.let { gps ->
                        draft = draft.copy(latitude = gps.first, longitude = gps.second)
                        scope.launch { if (draft.officeAddress.isBlank()) GeoLocationHelper.reverseGeocode(context, gps.first, gps.second)?.let { draft = draft.copy(officeAddress = it) } }
                        Toast.makeText(context, "Current GPS Pinned!", Toast.LENGTH_SHORT).show()
                    }
                }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.edit_card_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = draft)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { profilePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AccountCircle, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.edit_upload_photo)) }
                        OutlinedButton(onClick = { companyLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.QrCode2, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.edit_qr_logo)) }
                    }
                    OutlinedTextField(value = draft.profileTitle, onValueChange = { draft = draft.copy(profileTitle = it) }, label = { Text(stringResource(R.string.edit_profile_label)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.fullName, onValueChange = { draft = draft.copy(fullName = it) }, label = { Text(stringResource(R.string.edit_full_name)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text(stringResource(R.string.edit_designation)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text(stringResource(R.string.edit_company)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.department, onValueChange = { draft = draft.copy(department = it) }, label = { Text(stringResource(R.string.edit_department)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.publicCardUrl, onValueChange = { draft = draft.copy(publicCardUrl = it) }, label = { Text("NFC Public / Google Drive Card Link") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.phone, onValueChange = { draft = draft.copy(phone = it) }, label = { Text(stringResource(R.string.edit_business_phone)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text(stringResource(R.string.edit_whatsapp)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text(stringResource(R.string.edit_email)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.officeAddress, onValueChange = { draft = draft.copy(officeAddress = it) }, label = { Text(stringResource(R.string.edit_office_address)) }, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { scope.launch { GeoLocationHelper.geocodeAddress(context, draft.officeAddress)?.let { draft = draft.copy(latitude = it.first, longitude = it.second); Toast.makeText(context, "Address Pinned!", Toast.LENGTH_SHORT).show() } } }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.edit_auto_pin), fontSize = 12.sp) }
                        OutlinedButton(onClick = { editLocPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.edit_current_gps), fontSize = 12.sp) }
                    }
                    OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text(stringResource(R.string.edit_website)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.linkedInUrl, onValueChange = { draft = draft.copy(linkedInUrl = it) }, label = { Text(stringResource(R.string.edit_linkedin)) }, modifier = Modifier.fillMaxWidth())

                    // QR Back Section: Editable Back-Side Heading, Message (180-char limit) & Live Preview
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                    Text(
                        text = stringResource(R.string.edit_qr_back_section),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    BusinessCardBackView(card = draft, showFlipHint = false)
                    OutlinedTextField(
                        value = draft.backHeading,
                        onValueChange = { draft = draft.copy(backHeading = it.take(60)) },
                        label = { Text(stringResource(R.string.edit_back_heading)) },
                        placeholder = { Text(draft.companyName.ifBlank { "Card Link" }) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = draft.backMessage,
                        onValueChange = { draft = draft.copy(backMessage = it.take(180)) },
                        label = { Text("${stringResource(R.string.edit_back_message)} (${draft.backMessage.length} / 180)") },
                        placeholder = { Text(draft.bio.ifBlank { "Write a short professional message for the QR back..." }) },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { viewModel.saveCard(draft.copy(id = 0, profileTitle = "New Profile", isDefault = true)); navController.popBackStack() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_save_as_new)) }
                        Button(onClick = { viewModel.saveCard(draft); navController.popBackStack() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_save_changes)) }
                    }
                }
            }

            composable("customize") {
                CustomizeThemeScreen(
                    activeCard = activeCard,
                    onSaveCardTheme = { card -> viewModel.saveCard(card) },
                    onResetCardDefaults = {
                        activeCard.copy(
                            selectedTemplateId = com.cardlink.app.util.CardTemplateRegistry.DEFAULT_TEMPLATE_ID,
                            template = com.cardlink.app.data.model.CardTemplate.EXECUTIVE_NAVY,
                            primaryColorHex = 0xFF0A192FL,
                            secondaryColorHex = 0xFF112240L,
                            cardGradientEndHex = 0xFF172A46L,
                            accentColorHex = 0xFFD4AF37L,
                            buttonColorHex = 0xFFD4AF37L,
                            iconColorHex = 0xFFD4AF37L
                        )
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("share") {
                var selectedSharingProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
                val effectiveShareCard = remember(activeCard, selectedSharingProfile) {
                    SharingProfileManager.applyProfile(activeCard, selectedSharingProfile)
                }
                val vcfSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { destUri: Uri? ->
                    if (destUri != null) {
                        CardShareHelper.saveVCardToUri(context, destUri, effectiveShareCard)
                            .onSuccess { Toast.makeText(context, context.getString(R.string.share_vcf_saved_toast), Toast.LENGTH_LONG).show() }
                            .onFailure { Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show() }
                    }
                }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(stringResource(R.string.share_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = effectiveShareCard)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SharingProfileType.values().forEach { prof ->
                            FilterChip(
                                selected = selectedSharingProfile == prof,
                                onClick = {
                                    selectedSharingProfile = prof
                                    SharingProfileManager.setActiveProfile(context, prof)
                                },
                                label = { Text(prof.label, fontSize = 11.5.sp) }
                            )
                        }
                    }
                    SmartPrivacyPreviewCard(
                        card = effectiveShareCard,
                        onUpdateSharingPreferences = { updated ->
                            selectedSharingProfile = SharingProfileType.CUSTOM
                            SharingProfileManager.setActiveProfile(context, SharingProfileType.CUSTOM)
                            viewModel.saveCard(updated)
                        }
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("NFC Tap"); navController.navigate("nfc_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text(stringResource(R.string.share_nfc_tap)) }
                        Button(onClick = { navController.navigate("nearby_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text(stringResource(R.string.share_nearby_fast_btn)) }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("Quick Share"); CardShareHelper.shareViaQuickShare(context, effectiveShareCard) }, modifier = Modifier.weight(1f).height(56.dp)) { Text(stringResource(R.string.share_quick_share_btn)) }
                        Button(onClick = { viewModel.logShare("Contact / VCF"); CardShareHelper.shareVCardFile(context, effectiveShareCard) }, modifier = Modifier.weight(1f).height(56.dp)) { Text(stringResource(R.string.share_contact_vcf_btn)) }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("QR Code"); navController.navigate("qr_screen") }, modifier = Modifier.weight(1f).height(52.dp)) { Text(stringResource(R.string.share_qr_code)) }
                    }
                    OutlinedButton(
                        onClick = {
                            val slug = effectiveShareCard.fullName.trim().replace(Regex("\\s+"), "_").replace(Regex("[^a-zA-Z0-9_-]"), "").ifBlank { "Contact" }
                            vcfSaveLauncher.launch("CardLink_$slug.vcf")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SaveAlt, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.share_save_vcf_device))
                    }
                    OutlinedButton(onClick = { viewModel.logShare("PNG Image"); CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.share_as_png)) }
                    OutlinedButton(onClick = { viewModel.logShare("PDF Export"); CardShareHelper.shareCardAsPdf(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.share_as_pdf)) }
                    OutlinedButton(onClick = { viewModel.logShare("WhatsApp / Text"); CardShareHelper.shareAsText(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.share_as_text)) }
                    OutlinedButton(
                        onClick = { viewModel.logShare("HTML Card"); PremiumExtrasHelper.shareClickableHtmlCard(context, activeCard) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.share_html_card))
                    }
                }
            }

            composable("nfc_share") {
                var nfcShareMode by remember { mutableStateOf(CardLinkHceService.shareMode) }
                var isReceiveMode by remember { mutableStateOf(false) }
                var nfcLinkDraft by remember(activeCard) { mutableStateOf(activeCard.resolveNfcShareUrl()) }
                DisposableEffect(activeCard, nfcShareMode, nfcLinkDraft, isReceiveMode) {
                    CardLinkHceService.shareMode = nfcShareMode; CardLinkHceService.activeShareUrl = nfcLinkDraft; CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(activeCard)
                    if (isReceiveMode) nfcReaderManager.enableReaderMode() else nfcReaderManager.disableReaderMode()
                    onDispose { nfcReaderManager.disableReaderMode() }
                }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Default.Contactless, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(80.dp))
                    if (!nfcReaderManager.isNfcSupported()) Text("NFC is not supported on this phone.", fontWeight = FontWeight.Bold)
                    else if (!nfcReaderManager.isNfcEnabled()) { Text("NFC is disabled.", fontWeight = FontWeight.Bold); Button(onClick = { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Open NFC Settings") } }
                    else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = !isReceiveMode, onClick = { isReceiveMode = false }, label = { Text("Send My Card") })
                            FilterChip(selected = isReceiveMode, onClick = { isReceiveMode = true }, label = { Text("Receive Card") })
                        }
                        if (!isReceiveMode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = nfcShareMode == NfcShareMode.VCARD, onClick = { nfcShareMode = NfcShareMode.VCARD }, label = { Text("vCard") })
                                FilterChip(selected = nfcShareMode == NfcShareMode.LINK, onClick = { nfcShareMode = NfcShareMode.LINK }, label = { Text("Link") })
                            }
                            if (nfcShareMode == NfcShareMode.LINK) {
                                OutlinedTextField(value = nfcLinkDraft, onValueChange = { nfcLinkDraft = it }, label = { Text("NFC URL") }, modifier = Modifier.fillMaxWidth())
                                Button(onClick = { viewModel.saveCard(activeCard.copy(publicCardUrl = nfcLinkDraft)); Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show() }) { Text("Save NFC Link") }
                            }
                        }
                        BusinessCardView(card = activeCard)
                    }
                }
            }

            composable("nearby_share") {
                var nearbyTab by remember { mutableIntStateOf(0) } // 0 = Instant Nearby Swap (BLE + Wi-Fi Direct), 1 = Classic Bluetooth
                val sharingProf = remember { SharingProfileManager.getActiveProfile(context) }
                val effectiveCard = remember(activeCard, sharingProf) { SharingProfileManager.applyProfile(activeCard, sharingProf) }

                val nearbyManager = remember { NearbyCardExchangeManager(context) }
                val isNearbyActive by nearbyManager.isActive.collectAsState()
                val statusText by nearbyManager.statusText.collectAsState()
                val peers by nearbyManager.discoveredPeers.collectAsState()
                val pendingAuth by nearbyManager.pendingAuth.collectAsState()
                val connectedPeer by nearbyManager.connectedPeerName.collectAsState()
                val cardSent by nearbyManager.cardSent.collectAsState()
                val receivedContact by nearbyManager.receivedContact.collectAsState()

                val pairedDevices by bluetoothDiscoveryManager.pairedDevices.collectAsState()
                val discoveredDevices by bluetoothDiscoveryManager.discoveredDevices.collectAsState()
                val isScanning by bluetoothDiscoveryManager.isScanning.collectAsState()

                fun requiredNearbyPermissions(): Array<String> {
                    val perms = mutableListOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        perms.addAll(
                            listOf(
                                Manifest.permission.BLUETOOTH_SCAN,
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.BLUETOOTH_ADVERTISE
                            )
                        )
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                    }
                    return perms.toTypedArray()
                }

                val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    if (nearbyTab == 0) nearbyManager.startNearbySession(effectiveCard)
                    else bluetoothDiscoveryManager.startDiscovery()
                }

                DisposableEffect(nearbyTab, effectiveCard) {
                    permLauncher.launch(requiredNearbyPermissions())
                    onDispose {
                        nearbyManager.stopSession()
                        bluetoothDiscoveryManager.stopDiscovery()
                    }
                }

                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.nearby_swap_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.nearby_swap_subtitle), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(onClick = {
                            viewModel.logShare("Quick Share")
                            CardShareHelper.shareViaQuickShare(context, effectiveCard)
                        }) {
                            Text(stringResource(R.string.share_quick_share_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    TabRow(selectedTabIndex = nearbyTab) {
                        Tab(selected = nearbyTab == 0, onClick = { nearbyTab = 0 }, text = { Text("BLE + Wi-Fi Direct", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                        Tab(selected = nearbyTab == 1, onClick = { nearbyTab = 1 }, text = { Text("Classic Bluetooth", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                    }

                    if (nearbyTab == 0) {
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.WifiTethering, null, tint = MaterialTheme.colorScheme.primary)
                                    Text(statusText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                }
                                if (isNearbyActive) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                if (connectedPeer != null && cardSent) {
                                    Text("✓ Sent your card to $connectedPeer", style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { permLauncher.launch(requiredNearbyPermissions()) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(if (isNearbyActive) "Refresh Nearby Scan" else "Start Nearby Swap", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // 4-Digit Security Verification Prompt before accepting connection
                        pendingAuth?.let { auth ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Confirm 4-Digit Security Code", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Text("Peer: ${auth.endpointName} • Code: ${auth.authDigits}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { nearbyManager.rejectPendingConnection() }, modifier = Modifier.weight(1f)) { Text("Decline") }
                                        Button(onClick = {
                                            viewModel.logShare("Nearby (BLE + Wi-Fi Direct)", auth.endpointName)
                                            nearbyManager.acceptPendingConnection()
                                        }, modifier = Modifier.weight(1f)) { Text("Accept & Swap", fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        }

                        // Preview & Save Received Contact Card
                        receivedContact?.let { incoming ->
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.2.dp, Color(0xFF10B981))) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Card Received!", fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                    Text(incoming.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    if (incoming.companyName.isNotBlank()) Text(incoming.companyName, style = MaterialTheme.typography.bodySmall)
                                    if (incoming.phone.isNotBlank()) Text(incoming.phone, style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { nearbyManager.clearReceivedContact() }, modifier = Modifier.weight(1f)) { Text("Dismiss") }
                                        Button(onClick = {
                                            viewModel.saveReceivedContact(incoming, null)
                                            nearbyManager.clearReceivedContact()
                                            Toast.makeText(context, "Saved ${incoming.fullName} to Contacts!", Toast.LENGTH_LONG).show()
                                        }, modifier = Modifier.weight(1f)) { Text("Save Contact", fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        }

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(peers, key = { it.endpointId }) { peer ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    ListItem(
                                        headlineContent = { Text(peer.endpointName, fontWeight = FontWeight.Bold) },
                                        supportingContent = { Text("CardLink Nearby (BLE + Wi-Fi Direct)") },
                                        trailingContent = {
                                            Button(onClick = { nearbyManager.requestConnectionToPeer(peer) }) { Text("Swap") }
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        // Classic Bluetooth Fallback
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Classic Bluetooth Devices", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Button(onClick = {
                                if (!bluetoothDiscoveryManager.isBluetoothEnabled()) context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                                else permLauncher.launch(requiredNearbyPermissions())
                            }) { Text(if (isScanning) "Scanning..." else "Search") }
                        }
                        if (isScanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(discoveredDevices, key = { "d_${it.address}" }) { dev ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text(dev.address) }, trailingContent = {
                                        Button(onClick = { viewModel.logShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, effectiveCard) }) { Text("Send") }
                                    })
                                }
                            }
                            items(pairedDevices, key = { "p_${it.address}" }) { dev ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text("${dev.address} • Paired") }, trailingContent = {
                                        Button(onClick = { viewModel.logShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, effectiveCard) }) { Text("Send") }
                                    })
                                }
                            }
                        }
                    }
                }
            }

            composable("qr_screen") {
                val qr = remember(activeCard) { PremiumExtrasHelper.generateBrandedQrBitmap(context, activeCard, 750) }
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(activeCard.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp))
                    Image(bitmap = qr.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(260.dp)); Spacer(Modifier.height(20.dp))
                    Button(onClick = { CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share QR & Card Image") }
                }
            }

            composable("scan_qr") {
                QrScannerScreen(
                    scanHistory = qrScanHistory,
                    saveHistoryEnabled = saveScanHistoryEnabled,
                    onToggleSaveHistory = { viewModel.setSaveScanHistoryEnabled(it) },
                    onRecordScan = { viewModel.recordQrScan(it) },
                    onToggleHistoryFavorite = { viewModel.toggleQrScanHistoryFavorite(it) },
                    onDeleteHistoryEntry = { viewModel.deleteQrScanHistory(it) },
                    onClearHistory = { viewModel.clearAllQrScanHistory() },
                    onSaveToQrStudio = { viewModel.saveQrProject(it) },
                    onSaveContact = { parsed ->
                        viewModel.saveReceivedContact(parsed, null)
                        navController.navigate("contacts") { popUpTo("scan_qr") { inclusive = true } }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("scan_ocr") {
                OcrCardScannerScreen(
                    existingContacts = allContacts,
                    eventMode = eventMode,
                    activeCard = activeCard,
                    queuedCount = conferenceQueue.size,
                    onEnqueueConferenceCard = { bmp -> viewModel.enqueueConferenceCardBitmap(bmp) },
                    onOpenConferenceQueue = { navController.navigate("conference_queue") },
                    onUpdateSharingPreferences = { updated -> viewModel.saveCard(updated) },
                    onSavePendingDraft = { draft -> viewModel.savePendingDraft(draft) },
                    onScheduleFollowUpForContact = { navController.navigate("followups") { launchSingleTop = true } },
                    onContactSaved = {
                        viewModel.saveReceivedContact(it, null)
                        navController.navigate("contacts") { popUpTo("scan_ocr") { inclusive = true } }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("conference_queue") {
                ConferenceReviewQueueScreen(
                    queueItems = conferenceQueue,
                    activeCard = activeCard,
                    onBatchSaveReady = { viewModel.batchSaveReadyConferenceQueue(it) },
                    onSaveSingleQueueItem = { item, contact -> viewModel.saveSingleConferenceQueueItem(item, contact) },
                    onDeleteQueueItem = { viewModel.deleteConferenceQueueItem(it) },
                    onClearQueue = { viewModel.clearConferenceQueue() },
                    onNavigateToScanner = { navController.navigate("scan_ocr") { launchSingleTop = true } },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("networking_inbox") {
                NetworkingInboxScreen(
                    contacts = allContacts,
                    followUps = followUps,
                    queueItems = conferenceQueue,
                    pendingDrafts = pendingDrafts,
                    onOpenFollowUps = { navController.navigate("followups") { launchSingleTop = true } },
                    onOpenConferenceQueue = { navController.navigate("conference_queue") { launchSingleTop = true } },
                    onOpenDataQuality = { navController.navigate("data_quality") { launchSingleTop = true } },
                    onDeleteDraft = { viewModel.deletePendingDraft(it) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(CardLinkTileService.ROUTE_QUICK_SHARE) {
                QuickNfcQrShareScreen(activeCard = activeCard, nfcReaderManager = nfcReaderManager, onNavigateHome = { navController.navigate("home") })
            }

            composable("contacts") {
                var showDuplicateMergeDialog by remember { mutableStateOf(false) }
                var showPhoneImportSheet by remember { mutableStateOf(autoOpenContactsImport) }
                var isFabExpanded by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    if (autoOpenContactsImport) autoOpenContactsImport = false
                }

                // Close expandable + menu if navigating away
                DisposableEffect(Unit) {
                    onDispose { isFabExpanded = false }
                }

                // System back closes expanded menu first before leaving Contacts
                BackHandler(enabled = isFabExpanded) {
                    isFabExpanded = false
                }

                val fabRotation by animateFloatAsState(
                    targetValue = if (isFabExpanded) 45f else 0f,
                    animationSpec = tween(durationMillis = 200),
                    label = "contacts_fab_rotation"
                )

                val duplicatesMap = remember(contacts) {
                    val map = mutableMapOf<String, MutableList<SavedContactEntity>>()
                    contacts.forEach { c ->
                        val key = c.phone.filter { it.isDigit() }.takeLast(8).ifBlank { c.fullName.trim().lowercase() }
                        if (key.length >= 4) map.getOrPut(key) { mutableListOf() }.add(c)
                    }
                    map.values.filter { it.size > 1 }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        var selectedFilterTag by remember { mutableStateOf("All") }
                        var selectedSourceFilter by remember { mutableStateOf("ALL") }
                        var onlyFavorites by remember { mutableStateOf(false) }
                        var onlyBirthdaySoon by remember { mutableStateOf(false) }
                        var selectedSort by remember { mutableStateOf("FAVORITES_FIRST") }
                        var showFilterSortSheet by remember { mutableStateOf(false) }

                        var myCurrentGps by remember { mutableStateOf(GeoLocationHelper.getCurrentGpsCoordinates(context)) }
                        val radarLocLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                            myCurrentGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
                        }

                        // Clean Contacts Top Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(stringResource(R.string.contacts_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                if (duplicatesMap.isNotEmpty()) {
                                    Text("${duplicatesMap.size} duplicate group(s) found", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (duplicatesMap.isNotEmpty()) {
                                    OutlinedButton(onClick = { showDuplicateMergeDialog = true }) {
                                        Text(stringResource(R.string.action_merge), fontSize = 12.sp)
                                    }
                                }
                                IconButton(onClick = { showFilterSortSheet = true }) {
                                    Icon(
                                        Icons.Default.Tune,
                                        contentDescription = stringResource(R.string.contacts_filter_sort_title),
                                        tint = if (onlyFavorites || onlyBirthdaySoon || selectedSourceFilter != "ALL" || selectedFilterTag != "All") MaterialTheme.colorScheme.primary else LocalContentColor.current
                                    )
                                }
                            }
                        }

                        // 2 Compact Reactive Summary Cards immediately above Search: [ Total Contacts ] | [ Favorites ]
                        ContactsSummaryCardsRow(
                            totalCount = totalContactsCount,
                            favoriteCount = favoriteContactsCount,
                            isFavoritesFilterActive = onlyFavorites,
                            onSelectAll = {
                                onlyFavorites = false
                                onlyBirthdaySoon = false
                                selectedFilterTag = "All"
                                selectedSourceFilter = "ALL"
                            },
                            onSelectFavorites = {
                                onlyFavorites = !onlyFavorites
                            }
                        )

                        val primaryFilterChips = listOf("All", "Favorites", "Client", "Vendor", "VIP")
                        val filteredContacts = remember(contacts, selectedFilterTag, selectedSourceFilter, onlyFavorites, onlyBirthdaySoon, selectedSort, myCurrentGps) {
                            val base = contacts.filter { c ->
                                val tagMatch = when (selectedFilterTag) {
                                    "All" -> true
                                    "Nearby (<5 km)" -> {
                                        val u = myCurrentGps ?: (activeCard.latitude?.let { lat -> activeCard.longitude?.let { lng -> Pair(lat, lng) } })
                                        if (u == null) (c.latitude != null && c.longitude != null)
                                        else (c.latitude != null && c.longitude != null && GeoLocationHelper.distanceInKm(u.first, u.second, c.latitude, c.longitude) <= 5.0)
                                    }
                                    else -> c.categoryTag.equals(selectedFilterTag, true)
                                }
                                val favMatch = !onlyFavorites || c.isFavorite
                                val bdayMatch = !onlyBirthdaySoon || (ContactBirthdayHelper.computeBirthdayInfo(c.dateOfBirthIso)?.isBirthdaySoon == true)
                                val srcMatch = when (selectedSourceFilter) {
                                    "ALL" -> true
                                    "SCANNED" -> c.receivedVia.contains("OCR", true) || c.receivedVia.contains("Scan", true)
                                    "DUAL" -> c.receivedVia.contains("Dual", true) || (!c.profilePhotoUri.isNullOrBlank() && !c.backPhotoUri.isNullOrBlank())
                                    "PHONE" -> c.receivedVia.contains("Phone", true)
                                    "QR" -> c.receivedVia.contains("QR", true) || c.receivedVia.contains("NFC", true) || c.receivedVia.contains("Nearby", true)
                                    else -> true
                                }
                                tagMatch && favMatch && bdayMatch && srcMatch
                            }
                            when (selectedSort) {
                                "NAME_AZ" -> base.sortedBy { it.fullName.lowercase() }
                                "NAME_ZA" -> base.sortedByDescending { it.fullName.lowercase() }
                                "RECENT_ADDED" -> base.sortedByDescending { it.savedAtTimestamp }
                                else -> base.sortedWith(compareByDescending<SavedContactEntity> { it.isFavorite }.thenByDescending { it.savedAtTimestamp })
                            }
                        }

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            placeholder = { Text(stringResource(R.string.contacts_search_placeholder)) },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            primaryFilterChips.forEach { chip ->
                                val isSel = if (chip == "Favorites") onlyFavorites else (!onlyFavorites && selectedFilterTag == chip)
                                FilterChip(
                                    selected = isSel,
                                    onClick = {
                                        if (chip == "Favorites") {
                                            onlyFavorites = !onlyFavorites
                                        } else {
                                            onlyFavorites = false
                                            selectedFilterTag = chip
                                            if (chip == "Nearby (<5 km)") {
                                                radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                            }
                                        }
                                    },
                                    label = { Text(chip) }
                                )
                            }
                            FilterChip(
                                selected = false,
                                onClick = { showFilterSortSheet = true },
                                label = { Text(stringResource(R.string.contacts_more_filters)) }
                            )
                        }

                        if (showFilterSortSheet) {
                            ContactsFilterAndSortSheet(
                                selectedTag = selectedFilterTag,
                                selectedSource = selectedSourceFilter,
                                onlyFavorites = onlyFavorites,
                                onlyBirthdaySoon = onlyBirthdaySoon,
                                selectedSort = selectedSort,
                                onApply = { tag, src, fav, bday, sort ->
                                    selectedFilterTag = tag
                                    selectedSourceFilter = src
                                    onlyFavorites = fav
                                    onlyBirthdaySoon = bday
                                    selectedSort = sort
                                    if (tag == "Nearby (<5 km)") {
                                        radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                    }
                                },
                                onDismiss = { showFilterSortSheet = false }
                            )
                        }

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 88.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredContacts, key = { it.id }) { contact ->
                                val compactSource = when {
                                    !contact.profilePhotoUri.isNullOrBlank() && !contact.backPhotoUri.isNullOrBlank() -> "Dual-Sided"
                                    contact.receivedVia.contains("OCR", true) || contact.receivedVia.contains("Scan", true) -> "Scanned"
                                    contact.receivedVia.contains("Phone", true) -> "Phone"
                                    contact.receivedVia.contains("Nearby", true) -> "Nearby"
                                    contact.receivedVia.contains("NFC", true) -> "NFC"
                                    else -> "QR"
                                }
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { navController.navigate("contact_detail/${contact.id}") },
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        if (!contact.profilePhotoUri.isNullOrBlank()) {
                                            VaultImage(
                                                uriString = contact.profilePhotoUri,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                maxEdgePx = 220,
                                                modifier = Modifier
                                                    .size(54.dp, 36.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            )
                                        } else {
                                            Surface(
                                                modifier = Modifier.size(40.dp),
                                                shape = CircleShape,
                                                color = MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = contact.fullName.take(2).uppercase(),
                                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp
                                                    )
                                                }
                                            }
                                        }

                                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = contact.fullName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false)
                                                )
                                                if (contact.isFavorite) {
                                                    Icon(Icons.Default.Star, contentDescription = "Favorite", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                                }
                                            }
                                            val subLine = listOf(contact.designation, contact.companyName).filter { it.isNotBlank() }.joinToString(" • ")
                                            if (subLine.isNotBlank()) {
                                                Text(
                                                    text = subLine,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                                        ) {
                                            Text(
                                                text = compactSource,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.5.sp,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Outside-tap scrim to close expandable + menu
                    if (isFabExpanded) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.42f))
                                .clickable { isFabExpanded = false }
                        )
                    }

                    // Expandable Floating + Speed-Dial Menu (Import Contacts, Scan QR, Scan Card)
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 18.dp, bottom = 18.dp),
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AnimatedVisibility(
                            visible = isFabExpanded,
                            enter = fadeIn(tween(200)) + expandVertically(tween(200), expandFrom = Alignment.Bottom),
                            exit = fadeOut(tween(180)) + shrinkVertically(tween(180), shrinkTowards = Alignment.Bottom)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    onClick = {
                                        isFabExpanded = false
                                        showPhoneImportSheet = true
                                    },
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                                    shadowElevation = 6.dp
                                ) {
                                    Row(
                                        modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.PersonSearch, contentDescription = stringResource(R.string.contacts_import_short), tint = MaterialTheme.colorScheme.primary)
                                        Text(stringResource(R.string.contacts_import_short), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    }
                                }

                                Surface(
                                    onClick = {
                                        isFabExpanded = false
                                        navController.navigate("scan_qr")
                                    },
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                                    shadowElevation = 6.dp
                                ) {
                                    Row(
                                        modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.QrCodeScanner, contentDescription = stringResource(R.string.home_scan_qr), tint = MaterialTheme.colorScheme.primary)
                                        Text(stringResource(R.string.home_scan_qr), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    }
                                }

                                Surface(
                                    onClick = {
                                        isFabExpanded = false
                                        navController.navigate("scan_ocr")
                                    },
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                                    shadowElevation = 6.dp
                                ) {
                                    Row(
                                        modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.DocumentScanner, contentDescription = stringResource(R.string.home_scan_card), tint = MaterialTheme.colorScheme.primary)
                                        Text(stringResource(R.string.home_scan_card), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    }
                                }
                            }
                        }

                        FloatingActionButton(
                            onClick = { isFabExpanded = !isFabExpanded },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            shape = CircleShape
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = if (isFabExpanded) stringResource(R.string.contacts_fab_close) else stringResource(R.string.contacts_fab_open),
                                modifier = Modifier.rotate(fabRotation)
                            )
                        }
                    }

                    if (showPhoneImportSheet) {
                        PhoneContactsImportDialog(existingContacts = allContacts, onDismiss = { showPhoneImportSheet = false }) { contactToSave, existingDup, mode ->
                            when (mode) {
                                "SKIP" -> Unit
                                "MERGE" -> if (existingDup != null) {
                                    viewModel.saveReceivedContact(existingDup.copy(phone = existingDup.phone.ifBlank { contactToSave.phone }, whatsapp = existingDup.whatsapp.ifBlank { contactToSave.whatsapp }, email = existingDup.email.ifBlank { contactToSave.email }), null)
                                } else viewModel.saveReceivedContact(contactToSave, null)
                                else -> viewModel.saveReceivedContact(contactToSave, null)
                            }
                        }
                    }

                    if (showDuplicateMergeDialog && duplicatesMap.isNotEmpty()) {
                        AlertDialog(
                            onDismissRequest = { showDuplicateMergeDialog = false },
                            title = { Text(stringResource(R.string.contacts_merge_title), fontWeight = FontWeight.Bold) },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    duplicatesMap.forEach { group ->
                                        val primary = group.first(); val dups = group.drop(1)
                                        Card(modifier = Modifier.fillMaxWidth()) {
                                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("Primary: ${primary.fullName}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Button(onClick = {
                                                    val combinedNotes = (listOf(primary.notes) + dups.map { it.notes }).filter { it.isNotBlank() }.joinToString("\n---\n")
                                                    viewModel.saveReceivedContact(primary.copy(notes = combinedNotes), null)
                                                    dups.forEach { viewModel.deleteContact(it) }
                                                    showDuplicateMergeDialog = false
                                                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contacts_merge_group)) }
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = { TextButton(onClick = { showDuplicateMergeDialog = false }) { Text(stringResource(R.string.action_close)) } }
                        )
                    }
                }
            }

            composable("contact_detail/{contactId}", arguments = listOf(navArgument("contactId") { type = NavType.LongType })) { entry ->
                val id = entry.arguments?.getLong("contactId") ?: 0L
                val contact = contacts.firstOrNull { it.id == id } ?: allContacts.firstOrNull { it.id == id }
                if (contact != null) {
                    var showReturnCardDialog by remember { mutableStateOf(false) }
                    if (showReturnCardDialog) {
                        SendMyCardBackDialog(
                            recipient = contact,
                            activeCard = activeCard,
                            onUpdateSharingPreferences = { viewModel.saveCard(it) },
                            onSavePendingDraft = { viewModel.savePendingDraft(it) },
                            onDismiss = { showReturnCardDialog = false }
                        )
                    }
                    ContactDetailScreen(
                        onSendMyCardBack = { showReturnCardDialog = true },
                        contact = contact, mySenderName = activeCard.fullName, mySenderCompany = activeCard.companyName,
                        contactFollowUps = remember(followUps, contact.id) { followUps.filter { it.contactId == contact.id } },
                        onSaveContact = { updated, newWa -> viewModel.saveReceivedContact(updated, newWa) },
                        onToggleFavorite = { c -> viewModel.toggleContactFavorite(c) },
                        onSyncToPhone = { c, forceNew, targetId -> viewModel.syncSingleContactToPhone(c, forceNew, targetId) },
                        onAddFollowUp = { viewModel.saveFollowUp(it) }, onToggleFollowUp = { viewModel.toggleFollowUpCompleted(it) },
                        onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                        onDeleteContact = { viewModel.deleteContact(contact); navController.popBackStack() },
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            composable("calendar") {
                FollowUpCalendarScreen(
                    followUps = followUps, contacts = allContacts,
                    onSaveFollowUp = { viewModel.saveFollowUp(it) }, onToggleCompleted = { viewModel.toggleFollowUpCompleted(it) },
                    onCancelFollowUp = { viewModel.cancelFollowUp(it) }, onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                    onOpenContact = { cId -> navController.navigate("contact_detail/$cId") },
                    onOpenSettings = { navController.navigate("menu_general_settings") },
                    openCreateOnLaunch = autoOpenCalendarCreate.also { if (it) autoOpenCalendarCreate = false }
                )
            }

            composable("tools") {
                ToolsScreen(
                    activeCard = activeCard,
                    eventMode = eventMode,
                    favoriteToolIds = favoriteToolIds,
                    recentToolIds = recentToolIds,
                    onToggleFavoriteTool = { id -> viewModel.toggleFavoriteTool(id) },
                    onMoveFavoriteTool = { id, delta -> viewModel.moveFavoriteTool(id, delta) },
                    onLaunchCanonicalTool = { tool ->
                        viewModel.recordToolUsed(tool.id)
                        if (tool.id == "event_mode") showEventModeDialog = true
                        else navController.navigate(tool.route) { launchSingleTop = true }
                    },
                    onLogShare = { viewModel.logShare(it) }
                )
            }

            composable("qr_studio") {
                QrCodeStudioScreen(
                    activeCard = activeCard,
                    savedProjects = qrProjects,
                    savedPresets = qrDesignPresets,
                    onSaveProject = { viewModel.saveQrProject(it) },
                    onDuplicateProject = { viewModel.duplicateQrProject(it) },
                    onToggleFavorite = { viewModel.toggleQrProjectFavorite(it) },
                    onDeleteProject = { viewModel.deleteQrProject(it) },
                    onSaveDesignPreset = { name, json -> viewModel.saveQrDesignPreset(name, json) },
                    onDeleteDesignPreset = { viewModel.deleteQrDesignPreset(it) },
                    onOpenQrScanner = { navController.navigate("scan_qr") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("secure_notes") {
                SecureNotesScreen(
                    notes = secureNotes,
                    onSaveNote = { viewModel.saveSecureNote(it) },
                    onDeleteNote = { viewModel.deleteSecureNote(it) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("my_ids") {
                MyIdsWalletScreen(
                    documents = idDocuments,
                    allPages = idPages,
                    onAddNewId = { navController.navigate("my_id_editor/new") },
                    onOpenIdDetail = { uuid -> navController.navigate("my_id_detail/$uuid") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "my_id_editor/{docUuid}",
                arguments = listOf(navArgument("docUuid") { type = NavType.StringType })
            ) { entry ->
                val uuidArg = entry.arguments?.getString("docUuid") ?: "new"
                val existingDoc = if (uuidArg == "new") null else idDocuments.firstOrNull { it.stableUuid == uuidArg }
                val existingPages = if (existingDoc == null) emptyList() else idPages.filter { it.documentUuid == existingDoc.stableUuid }
                MyIdEditorScreen(
                    existingDoc = existingDoc,
                    existingPages = existingPages,
                    onSave = { doc, pages ->
                        viewModel.saveIdDocument(doc, pages)
                        navController.popBackStack()
                    },
                    onOpenSettings = { navController.navigate("menu_general_settings") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "my_id_detail/{docUuid}",
                arguments = listOf(navArgument("docUuid") { type = NavType.StringType })
            ) { entry ->
                val uuidArg = entry.arguments?.getString("docUuid") ?: ""
                val doc = idDocuments.firstOrNull { it.stableUuid == uuidArg }
                val docPages = idPages.filter { it.documentUuid == uuidArg }
                if (doc != null) {
                    MyIdDetailScreen(
                        doc = doc,
                        pages = docPages,
                        onEdit = { navController.navigate("my_id_editor/${doc.stableUuid}") },
                        onDelete = {
                            viewModel.deleteIdDocument(doc)
                            navController.popBackStack()
                        },
                        onOpenSettings = { navController.navigate("menu_general_settings") },
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            composable("loyalty_cards") {
                LoyaltyCardWalletScreen(
                    loyaltyCards = loyaltyCards,
                    onAddCardWithMode = { mode -> navController.navigate("loyalty_card_editor/0?mode=$mode") },
                    onOpenCard = { cid -> navController.navigate("loyalty_card_detail/$cid") { launchSingleTop = true } },
                    onToggleFavorite = { card -> viewModel.toggleLoyaltyCardFavorite(card) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "loyalty_card_editor/{cardId}?mode={mode}",
                arguments = listOf(
                    navArgument("cardId") { type = NavType.LongType },
                    navArgument("mode") { type = NavType.StringType; defaultValue = "MANUAL" }
                )
            ) { entry ->
                val cid = entry.arguments?.getLong("cardId") ?: 0L
                val mode = entry.arguments?.getString("mode") ?: "MANUAL"
                val existing = loyaltyCards.firstOrNull { it.id == cid }
                LoyaltyCardEditorScreen(
                    existingCard = existing,
                    defaultCardholderName = activeCard.fullName,
                    initialLaunchMode = mode,
                    onSave = { saved ->
                        viewModel.saveLoyaltyCard(saved)
                        navController.popBackStack()
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "loyalty_card_detail/{cardId}",
                arguments = listOf(navArgument("cardId") { type = NavType.LongType })
            ) { entry ->
                val cid = entry.arguments?.getLong("cardId") ?: 0L
                val card = loyaltyCards.firstOrNull { it.id == cid }
                if (card != null) {
                    LoyaltyCardDetailScreen(
                        card = card,
                        onEdit = { navController.navigate("loyalty_card_editor/${card.id}?mode=MANUAL") },
                        onToggleFavorite = { viewModel.toggleLoyaltyCardFavorite(card) },
                        onRecordUsed = { viewModel.recordLoyaltyCardUsed(card) },
                        onDelete = {
                            viewModel.deleteLoyaltyCard(card)
                            navController.popBackStack()
                        },
                        onNavigateBack = { navController.popBackStack() }
                    )
                } else {
                    LaunchedEffect(cid) {
                        if (loyaltyCards.isNotEmpty()) navController.popBackStack()
                    }
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }

            composable("analytics") {
                val backupChanges = remember(allContacts, idDocuments, loyaltyCards, qrProjects, secureNotes) {
                    BackupChangeTracker.computeSinceLastBackup(
                        context = context,
                        contacts = allContacts,
                        idDocuments = idDocuments,
                        loyaltyCards = loyaltyCards,
                        qrProjects = qrProjects,
                        secureNotes = secureNotes
                    ).nonZeroLines()
                }
                AnalyticsScreen(
                    contacts = allContacts,
                    shareHistory = shareHistory,
                    followUps = followUps,
                    idDocuments = idDocuments,
                    onOpenFollowUps = { navController.navigate("followups") { launchSingleTop = true } },
                    onOpenMyIds = { navController.navigate("my_ids") { launchSingleTop = true } },
                    onOpenExpiryCenter = { navController.navigate("expiry_center") },
                    onOpenDataQuality = { navController.navigate("data_quality") },
                    onOpenNetworkingInbox = { navController.navigate("networking_inbox") },
                    networkingInboxCount = conferenceQueue.size + pendingDrafts.size,
                    backupChangeLines = backupChanges,
                    onOpenBackup = { navController.navigate("menu_backup_export") { launchSingleTop = true } },
                    onOpenContacts = { navController.navigate("contacts") { launchSingleTop = true } },
                    onOpenPrivacy = { navController.navigate("menu_privacy") { launchSingleTop = true } },
                    onExportLogged = { viewModel.logShare(it) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("nfc_studio") {
                NfcStudioScreen(
                    activeCard = activeCard,
                    savedProjects = nfcProjects,
                    onSaveProject = { viewModel.saveNfcProject(it) },
                    onDeleteProject = { viewModel.deleteNfcProject(it) },
                    onUpdateCardSharing = { viewModel.saveCard(it) },
                    onSaveContactFromNfc = { c -> viewModel.saveReceivedContact(c, null) },
                    onCreateQrFallback = { qr ->
                        viewModel.saveQrProject(qr)
                        Toast.makeText(context, "Moved to QR Code Studio!", Toast.LENGTH_SHORT).show()
                        navController.navigate("qr_studio") { launchSingleTop = true }
                    },
                    onOpenQrStudio = { navController.navigate("qr_studio") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("data_quality") {
                ContactDataQualityScreen(
                    contacts = allContacts,
                    followUps = followUps,
                    onOpenContacts = { navController.navigate("contacts") { launchSingleTop = true } },
                    onOpenFollowUps = { navController.navigate("followups") { launchSingleTop = true } },
                    onMergePair = { merged, del ->
                        viewModel.saveReceivedContact(merged, null)
                        viewModel.deleteContact(del)
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("security_checkup") {
                SecurityCheckupScreen(
                    onNavigateRoute = { route -> navController.navigate(route) { launchSingleTop = true } },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("security_activity") {
                SecurityActivityScreen(
                    auditLogs = securityAuditLogs,
                    onClearAuditLogs = { viewModel.clearSecurityAuditLogs() },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("security_tech_info") {
                TechnicalSecurityInfoScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_permissions") {
                PermissionHealthScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("recycle_bin") {
                RecycleBinScreen(
                    items = recycleBinItems,
                    onRestoreItem = { viewModel.restoreRecycleBinItem(it) },
                    onDeletePermanently = { viewModel.deleteRecycleBinItemPermanently(it) },
                    onEmptyBin = { viewModel.emptyRecycleBin() },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("device_migration") {
                DeviceMigrationAssistantScreen(
                    onOpenBackupCenter = { navController.navigate("menu_backup_export") { launchSingleTop = true } },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("expiry_center") {
                ExpiryCenterScreen(
                    idDocuments = idDocuments,
                    onReviewId = { uuid -> navController.navigate("my_id_detail/$uuid") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("share_intake") {
                ShareIntakeScreen(
                    payload = incomingSharePayload,
                    onSaveQrProject = { viewModel.saveQrProject(it) },
                    onSaveSecureNote = { viewModel.saveSecureNote(it) },
                    onSaveContact = { viewModel.saveReceivedContact(it, null) },
                    onSaveIdDocument = { doc, pages -> viewModel.saveIdDocument(doc, pages) },
                    onOpenQrStudio = { navController.navigate("qr_studio") { popUpTo("share_intake") { inclusive = true } } },
                    onOpenScanCard = { navController.navigate("scan_ocr") { popUpTo("share_intake") { inclusive = true } } },
                    onOpenLoyaltyCards = { navController.navigate("loyalty_cards") { popUpTo("share_intake") { inclusive = true } } },
                    onFinished = { navController.navigate("home") { popUpTo("share_intake") { inclusive = true } } }
                )
            }

            composable("meeting_bg") {
                MeetingBackgroundScreen(activeCard = activeCard, onExported = { viewModel.logShare("Meeting Background") }, onNavigateBack = { navController.popBackStack() })
            }

            composable("settings") {
                MenuScreen(
                    hasUnseenWhatsNew = hasUnseenWhatsNew,
                    onOpenSettings = { navController.navigate("menu_general_settings") },
                    onOpenInsights = { navController.navigate("analytics") { launchSingleTop = true } },
                    onOpenWidgets = { navController.navigate("menu_widgets") },
                    onOpenFeedback = { navController.navigate("menu_feedback_community") },
                    onOpenWhatsNew = { navController.navigate("menu_whats_new") },
                    onOpenHelpTips = { navController.navigate("menu_help_tips") },
                    onOpenAbout = { navController.navigate("menu_about") }
                )
            }

            composable("menu_whats_new") {
                WhatsNewScreen(
                    onMarkedViewed = { viewModel.markWhatsNewViewed() },
                    onTryFeatureRoute = { route ->
                        navController.navigate(route) { launchSingleTop = true }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("global_search") {
                GlobalSearchScreen(
                    contacts = allContacts,
                    followUps = followUps,
                    loyaltyCards = loyaltyCards,
                    idDocuments = idDocuments,
                    qrProjects = qrProjects,
                    secureNotes = secureNotes,
                    onNavigateToRoute = { route ->
                        navController.popBackStack()
                        navController.navigate(route) { launchSingleTop = true }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_help_tips") {
                HelpAndTipsScreen(
                    onReopenChecklist = {
                        UxExperiencePrefs.setChecklistDismissed(context, false)
                        navController.navigate("home") { popUpTo("home") { inclusive = false } }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_feedback_community") {
                FeedbackCommunityScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_language") {
                LanguageScreen(
                    currentLanguageCode = appLanguage,
                    onSelectLanguage = { code -> viewModel.setAppLanguage(code) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_general_settings") {
                GeneralSettingsScreen(
                    notificationsEnabled = notificationsEnabled,
                    onToggleNotifications = { enabled -> viewModel.setNotificationsEnabled(enabled) },
                    currentLanguageCode = appLanguage,
                    darkThemeOverride = darkThemeOverride,
                    onOpenPrivacy = { navController.navigate("menu_privacy") },
                    onOpenBackupExport = { navController.navigate("menu_backup_export") },
                    onOpenLanguage = { navController.navigate("menu_language") },
                    onOpenAppearance = { navController.navigate("menu_dark_mode") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_privacy") {
                val quickPrivacy by viewModel.quickPrivacyMode.collectAsState()
                PrivacySettingsScreen(
                    activeCard = activeCard,
                    quickPrivacyMode = quickPrivacy,
                    auditLogs = securityAuditLogs,
                    onClearAuditLogs = { viewModel.clearSecurityAuditLogs() },
                    onOpenRecycleBin = { navController.navigate("recycle_bin") },
                    onOpenPermissions = { navController.navigate("menu_permissions") },
                    onRunSecurityCheckup = { navController.navigate("security_checkup") },
                    onOpenSecurityActivity = { navController.navigate("security_activity") },
                    onOpenTechInfo = { navController.navigate("security_tech_info") },
                    onToggleQuickPrivacy = { viewModel.toggleQuickPrivacyMode() },
                    onSaveCard = { viewModel.saveCard(it) },
                    onLockNow = onLockNow,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_backup_export") {
                BackupExportScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_widgets") {
                WidgetsMenuScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_dark_mode") {
                DarkModeScreen(
                    darkThemeOverride = darkThemeOverride,
                    currentAppTheme = customAppTheme,
                    onSelectTheme = { viewModel.toggleTheme(it) },
                    onOpenThemeStudio = { navController.navigate("menu_theme_studio") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_theme_studio") {
                AppThemeStudioScreen(
                    currentAppTheme = customAppTheme,
                    darkThemeOverride = darkThemeOverride,
                    onApplyAppTheme = { cfg -> viewModel.saveAppCustomTheme(cfg) },
                    onSelectDisplayMode = { mode -> viewModel.toggleTheme(mode) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("menu_about") {
                AboutCreditsScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }

        if (showEventModeDialog) {
            var evName by remember { mutableStateOf(eventMode.eventName) }
            var evLoc by remember { mutableStateOf(eventMode.location) }
            val evLocPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                GeoLocationHelper.getCurrentGpsCoordinates(context)?.let { gps ->
                    scope.launch {
                        val addr = GeoLocationHelper.reverseGeocode(context, gps.first, gps.second)
                        evLoc = addr ?: GeoLocationHelper.formatCoordinates(gps.first, gps.second)
                    }
                }
            }
            AlertDialog(
                onDismissRequest = { showEventModeDialog = false },
                title = { Text(stringResource(R.string.tools_event_mode), fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "While Event Mode is active, every card you scan (QR / Dual-Side OCR) or receive via NFC will automatically be tagged with this event's name, date, and location.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = evName,
                            onValueChange = { evName = it },
                            label = { Text(stringResource(R.string.home_event_name_label)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = evLoc,
                            onValueChange = { evLoc = it },
                            label = { Text(stringResource(R.string.home_event_venue_label)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(
                            onClick = {
                                evLocPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.home_event_gps_btn))
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (evName.isBlank()) {
                            Toast.makeText(context, "Please enter an event name", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.activateEventMode(evName, evLoc)
                        showEventModeDialog = false
                        Toast.makeText(context, "Event Mode Active: $evName", Toast.LENGTH_LONG).show()
                    }) { Text(stringResource(R.string.home_event_activate)) }
                },
                dismissButton = {
                    if (eventMode.isActive) {
                        TextButton(onClick = {
                            viewModel.deactivateEventMode()
                            showEventModeDialog = false
                        }) { Text(stringResource(R.string.home_event_turn_off)) }
                    } else {
                        TextButton(onClick = { showEventModeDialog = false }) { Text(stringResource(R.string.action_cancel)) }
                    }
                }
            )
        }
    }
}

@Composable
private fun PhoneContactsImportDialog(
    existingContacts: List<SavedContactEntity>,
    onDismiss: () -> Unit,
    onImportContact: (SavedContactEntity, SavedContactEntity?, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var deviceContacts by remember { mutableStateOf<List<DevicePhoneContact>>(emptyList()) }
    var permissionDenied by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var primaryPhoneOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var whatsappOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var showPreviewStep by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { permissionDenied = false; scope.launch { deviceContacts = PhoneContactsHelper.loadDeviceContacts(context) } }
        else permissionDenied = true
    }

    LaunchedEffect(Unit) {
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            deviceContacts = PhoneContactsHelper.loadDeviceContacts(context)
        } else permLauncher.launch(Manifest.permission.READ_CONTACTS)
    }

    val filtered = remember(deviceContacts, search) {
        deviceContacts.filter { search.isBlank() || it.displayName.contains(search, true) || it.phones.any { p -> p.contains(search, true) } }
    }
    val chosenList = remember(deviceContacts, selectedIds) { deviceContacts.filter { it.contactId in selectedIds } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (showPreviewStep) "${stringResource(R.string.contacts_import_preview)} (${chosenList.size})" else stringResource(R.string.contacts_import_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (permissionDenied) Text(stringResource(R.string.contacts_perm_denied), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (!showPreviewStep) {
                    OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text(stringResource(R.string.contacts_import_search)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    filtered.take(30).forEach { dc ->
                        val isSel = dc.contactId in selectedIds
                        Card(modifier = Modifier.fillMaxWidth().clickable { selectedIds = if (isSel) selectedIds - dc.contactId else selectedIds + dc.contactId }) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = isSel, onCheckedChange = { selectedIds = if (it) selectedIds + dc.contactId else selectedIds - dc.contactId })
                                Column { Text(dc.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(dc.phones.firstOrNull().orEmpty(), style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                } else {
                    chosenList.forEach { dc ->
                        val chosenPhone = primaryPhoneOverride[dc.contactId] ?: dc.phones.firstOrNull().orEmpty()
                        val chosenEmail = dc.emails.firstOrNull().orEmpty()
                        val waVal = whatsappOverride[dc.contactId].orEmpty()
                        val dup = remember(dc, chosenPhone, chosenEmail, existingContacts) { PhoneContactsHelper.findDuplicateContact(existingContacts, dc.displayName, chosenPhone, chosenEmail) }
                        var dupAction by remember(dc.contactId) { mutableStateOf(if (dup != null) "MERGE" else "IMPORT") }
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(dc.displayName, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                if (dc.phones.size > 1) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        dc.phones.forEach { p -> FilterChip(selected = chosenPhone == p, onClick = { primaryPhoneOverride = primaryPhoneOverride + (dc.contactId to p) }, label = { Text(p, fontSize = 11.sp) }) }
                                    }
                                }
                                OutlinedTextField(value = waVal, onValueChange = { whatsappOverride = whatsappOverride + (dc.contactId to it) }, label = { Text(stringResource(R.string.contacts_wa_optional)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                if (dup != null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("SKIP" to "Skip", "MERGE" to "Merge", "IMPORT" to "Separate").forEach { (k, l) -> FilterChip(selected = dupAction == k, onClick = { dupAction = k }, label = { Text(l, fontSize = 11.sp) }) }
                                    }
                                }
                                Button(onClick = {
                                    val entity = SavedContactEntity(
                                        fullName = dc.displayName, designation = dc.jobTitle, companyName = dc.organization,
                                        phone = if (chosenPhone.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(chosenPhone) else "",
                                        whatsapp = if (waVal.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(waVal) else "",
                                        email = chosenEmail, receivedVia = "Phone Contacts"
                                    )
                                    onImportContact(entity, dup, dupAction)
                                    selectedIds = selectedIds - dc.contactId
                                }, modifier = Modifier.fillMaxWidth()) { Text("Apply (${dupAction.lowercase()})") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!permissionDenied && selectedIds.isNotEmpty() && !showPreviewStep) Button(onClick = { showPreviewStep = true }) { Text("Preview (${selectedIds.size})") }
            else TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        },
        dismissButton = { if (showPreviewStep) TextButton(onClick = { showPreviewStep = false }) { Text(stringResource(R.string.action_back)) } }
    )
}
