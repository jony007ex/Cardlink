package com.cardlink.app.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cardlink.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.*
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class CalendarFilter(val labelRes: Int) {
    ALL(R.string.calendar_filter_upcoming),
    TODAY(R.string.calendar_filter_today),
    TOMORROW(R.string.calendar_filter_tomorrow),
    THIS_WEEK(R.string.calendar_filter_week),
    WHATSAPP(R.string.calendar_filter_whatsapp),
    OVERDUE(R.string.calendar_filter_overdue),
    COMPLETED(R.string.calendar_filter_completed)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FollowUpCalendarScreen(
    followUps: List<FollowUpEntity>,
    contacts: List<SavedContactEntity>,
    onSaveFollowUp: (FollowUpEntity) -> Unit,
    onToggleCompleted: (FollowUpEntity) -> Unit,
    onCancelFollowUp: (FollowUpEntity) -> Unit,
    onDeleteFollowUp: (FollowUpEntity) -> Unit,
    onOpenContact: (Long) -> Unit,
    onOpenSettings: () -> Unit = {}
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf(CalendarFilter.ALL) }
    var editingItem by remember { mutableStateOf<FollowUpEntity?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }
    var showNotifDisabledDialog by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val todayStart = remember {
        Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    }
    val tomorrowStart = todayStart + 24L * 3600_000L
    val dayAfterTomorrowStart = tomorrowStart + 24L * 3600_000L
    val weekEnd = todayStart + 7L * 24L * 3600_000L

    val activeItems = remember(followUps) { followUps.filter { !it.isCompleted && it.status != FollowUpStatus.CANCELLED.name } }
    val filteredList = remember(followUps, selectedFilter) {
        when (selectedFilter) {
            CalendarFilter.ALL -> activeItems
            CalendarFilter.TODAY -> activeItems.filter { it.dueAtTimestamp in todayStart until tomorrowStart }
            CalendarFilter.TOMORROW -> activeItems.filter { it.dueAtTimestamp in tomorrowStart until dayAfterTomorrowStart }
            CalendarFilter.THIS_WEEK -> activeItems.filter { it.dueAtTimestamp in todayStart..weekEnd }
            CalendarFilter.WHATSAPP -> activeItems.filter { it.channel == FollowUpChannel.WHATSAPP.name }
            CalendarFilter.OVERDUE -> activeItems.filter { it.dueAtTimestamp < now }
            CalendarFilter.COMPLETED -> followUps.filter { it.isCompleted || it.status == FollowUpStatus.CANCELLED.name }
        }
    }

    val todayCount = remember(activeItems) { activeItems.count { it.dueAtTimestamp in todayStart until tomorrowStart } }
    val dateFormatter = remember { SimpleDateFormat("EEE, dd MMM • hh:mm a", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editingItem = null; showEditorDialog = true },
                containerColor = GoldAccent, contentColor = NavyPrimary,
                icon = { Icon(Icons.Default.AddAlert, null) },
                text = { Text(stringResource(R.string.calendar_new_followup), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(stringResource(R.string.calendar_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.calendar_subtitle), style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.CalendarMonth, null, tint = GoldAccent, modifier = Modifier.size(30.dp))
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalendarStatBox(stringResource(R.string.calendar_due_today), todayCount.toString(), NavyPrimary, GoldAccent, Modifier.weight(1f))
                CalendarStatBox(stringResource(R.string.calendar_active), activeItems.size.toString(), NavyPrimary, Color.White, Modifier.weight(1f))
                CalendarStatBox(stringResource(R.string.calendar_completed), followUps.count { it.isCompleted }.toString(), NavyPrimary, Color(0xFF4ADE80), Modifier.weight(1f))
            }

            val primaryFilters = listOf(
                CalendarFilter.ALL to 1.02f,
                CalendarFilter.TODAY to 0.78f,
                CalendarFilter.TOMORROW to 1.10f,
                CalendarFilter.THIS_WEEK to 1.10f
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                primaryFilters.forEach { (filter, segWeight) ->
                    val isSelected = selectedFilter == filter
                    Surface(
                        onClick = { selectedFilter = filter },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) GoldAccent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .weight(segWeight)
                            .heightIn(min = 38.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = stringResource(filter.labelRes),
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 11.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (filteredList.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.EventAvailable, null, tint = GoldAccent, modifier = Modifier.size(42.dp))
                        Text(stringResource(selectedFilter.labelRes), fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.calendar_empty_hint), style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredList, key = { it.id }) { item ->
                        val isOverdue = !item.isCompleted && item.dueAtTimestamp < now && item.status != FollowUpStatus.CANCELLED.name
                        val isWa = item.channel == FollowUpChannel.WHATSAPP.name
                        Card(modifier = Modifier.fillMaxWidth().clickable { if (item.contactId > 0L) onOpenContact(item.contactId) }, shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Checkbox(checked = item.isCompleted, onCheckedChange = { onToggleCompleted(item) })
                                        Column {
                                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None)
                                            Text(listOf(item.contactName, item.companyName).filter { it.isNotBlank() }.joinToString(" • "), color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = { editingItem = item; showEditorDialog = true }) { Icon(Icons.Default.Edit, "Edit") }
                                        if (!item.isCompleted && item.status != FollowUpStatus.CANCELLED.name) {
                                            IconButton(onClick = { onCancelFollowUp(item) }) { Icon(Icons.Default.Block, "Cancel", tint = GoldAccent) }
                                        }
                                        IconButton(onClick = { onDeleteFollowUp(item) }) { Icon(Icons.Default.DeleteOutline, "Delete", tint = MaterialTheme.colorScheme.error) }
                                    }
                                }
                                if (isWa) {
                                    Text("WhatsApp (${item.whatsappNumber}) • ${if (item.whatsappMode == WhatsAppScheduleMode.AUTOMATIC_SEND.name) "Automatic Send (API)" else "Reminder to Send"} • ${item.status}", fontSize = 11.sp, color = GoldAccent)
                                    if (item.whatsappMessage.isNotBlank()) Text("Message: \"${item.whatsappMessage}\"", style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = { ContactActionLauncher.launchWhatsAppChat(context, item.whatsappNumber, item.contactName, item.whatsappMessage.ifBlank { item.title }) }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.Chat, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.calendar_open_wa_send))
                                    }
                                }
                                if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(dateFormatter.format(Date(item.dueAtTimestamp)) + if (item.reminderOffsetMinutes > 0) " (${item.reminderOffsetMinutes}m early)" else "", fontSize = 12.sp, color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (item.alarmEnabled) AssistChip(onClick = {}, label = { Text("Alarm", fontSize = 10.sp) })
                                        if (item.notificationEnabled) AssistChip(onClick = {}, label = { Text("Notif", fontSize = 10.sp) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        FollowUpEditorDialog(
            initial = editingItem, myContacts = contacts,
            onDismiss = { showEditorDialog = false; editingItem = null },
            onSave = { savedItem ->
                onSaveFollowUp(savedItem)
                val statusMsg = FollowUpScheduler.scheduleForItem(context, savedItem)
                showEditorDialog = false; editingItem = null
                if ((savedItem.notificationEnabled || savedItem.alarmEnabled) && !FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) {
                    showNotifDisabledDialog = true
                } else {
                    Toast.makeText(context, statusMsg, Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    if (showNotifDisabledDialog) {
        AlertDialog(
            onDismissRequest = { showNotifDisabledDialog = false },
            title = { Text(stringResource(R.string.calendar_notif_disabled_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.calendar_notif_disabled_msg)) },
            confirmButton = {
                Button(onClick = {
                    showNotifDisabledDialog = false
                    onOpenSettings()
                }) { Text(stringResource(R.string.calendar_open_settings)) }
            },
            dismissButton = {
                TextButton(onClick = { showNotifDisabledDialog = false }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }
}

@Composable
private fun FollowUpEditorDialog(initial: FollowUpEntity?, myContacts: List<SavedContactEntity>, onDismiss: () -> Unit, onSave: (FollowUpEntity) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cal = remember(initial) { Calendar.getInstance().apply { timeInMillis = initial?.dueAtTimestamp ?: (System.currentTimeMillis() + 3600_000L) } }
    var year by remember(initial) { mutableIntStateOf(cal.get(Calendar.YEAR)) }
    var month by remember(initial) { mutableIntStateOf(cal.get(Calendar.MONTH)) }
    var day by remember(initial) { mutableIntStateOf(cal.get(Calendar.DAY_OF_MONTH)) }
    var hour by remember(initial) { mutableIntStateOf(cal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember(initial) { mutableIntStateOf(cal.get(Calendar.MINUTE)) }

    var contactSource by remember(initial) { mutableStateOf("MY_CONTACTS") }
    var selectedMyContact by remember(initial) { mutableStateOf(myContacts.firstOrNull { it.id == initial?.contactId } ?: myContacts.firstOrNull()) }
    var contactName by remember(initial) { mutableStateOf(initial?.contactName ?: selectedMyContact?.fullName ?: "") }
    var companyName by remember(initial) { mutableStateOf(initial?.companyName ?: selectedMyContact?.companyName ?: "") }
    var title by remember(initial) { mutableStateOf(initial?.title ?: "Follow-up Meeting") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
    var alarmEnabled by remember(initial) { mutableStateOf(initial?.alarmEnabled ?: false) }
    var notificationEnabled by remember(initial) { mutableStateOf(initial?.notificationEnabled ?: true) }
    var reminderOffsetMinutes by remember(initial) { mutableIntStateOf(initial?.reminderOffsetMinutes ?: 0) }
    var channel by remember(initial) { mutableStateOf(initial?.channel ?: FollowUpChannel.GENERAL.name) }
    var whatsappNumber by remember(initial) { mutableStateOf(initial?.whatsappNumber ?: selectedMyContact?.whatsapp?.ifBlank { selectedMyContact?.phone.orEmpty() }.orEmpty()) }
    var whatsappMessage by remember(initial) { mutableStateOf(initial?.whatsappMessage ?: "") }
    var whatsappMode by remember(initial) { mutableStateOf(initial?.whatsappMode ?: WhatsAppScheduleMode.REMINDER_TO_SEND.name) }

    var phoneContactsList by remember { mutableStateOf<List<DevicePhoneContact>>(emptyList()) }
    var phoneSearch by remember { mutableStateOf("") }
    var showPhonePickerList by remember { mutableStateOf(false) }
    var pendingMultiNumberContact by remember { mutableStateOf<DevicePhoneContact?>(null) }

    val readContactsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { phoneContactsList = PhoneContactsHelper.loadDeviceContacts(context); showPhonePickerList = true }
        else { contactSource = "MANUAL"; Toast.makeText(context, "Phone Contacts permission denied — use manual entry.", Toast.LENGTH_LONG).show() }
    }

    val dateTimeText = remember(year, month, day, hour, minute) {
        val c = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0) }
        SimpleDateFormat("EEE, dd MMM yyyy • hh:mm a", Locale.getDefault()).format(c.time)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) stringResource(R.string.calendar_schedule_title) else stringResource(R.string.calendar_edit_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.calendar_title_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = contactSource == "MY_CONTACTS", onClick = { contactSource = "MY_CONTACTS"; showPhonePickerList = false }, label = { Text("My Contacts") })
                    FilterChip(selected = contactSource == "PHONE_CONTACTS", onClick = {
                        contactSource = "PHONE_CONTACTS"
                        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            scope.launch { phoneContactsList = PhoneContactsHelper.loadDeviceContacts(context); showPhonePickerList = true }
                        } else readContactsLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }, label = { Text("Phone") })
                    FilterChip(selected = contactSource == "MANUAL", onClick = { contactSource = "MANUAL"; showPhonePickerList = false }, label = { Text("Manual") })
                }

                if (contactSource == "MY_CONTACTS" && myContacts.isNotEmpty()) {
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        myContacts.forEach { c ->
                            FilterChip(selected = selectedMyContact?.id == c.id, onClick = {
                                selectedMyContact = c; contactName = c.fullName; companyName = c.companyName
                                if (whatsappNumber.isBlank()) whatsappNumber = c.whatsapp.ifBlank { c.phone }
                            }, label = { Text(c.fullName) })
                        }
                    }
                }

                if (contactSource == "PHONE_CONTACTS" && showPhonePickerList) {
                    OutlinedTextField(value = phoneSearch, onValueChange = { phoneSearch = it }, label = { Text("Search phone contacts...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    phoneContactsList.filter { phoneSearch.isBlank() || it.displayName.contains(phoneSearch, true) || it.phones.any { p -> p.contains(phoneSearch, true) } }.take(8).forEach { pc ->
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            contactName = pc.displayName; companyName = pc.organization
                            if (pc.phones.size > 1) pendingMultiNumberContact = pc else whatsappNumber = pc.phones.firstOrNull().orEmpty()
                            showPhonePickerList = false
                        }) { Column(modifier = Modifier.padding(8.dp)) { Text(pc.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(pc.phones.joinToString(", "), style = MaterialTheme.typography.bodySmall) } }
                    }
                }

                OutlinedTextField(value = contactName, onValueChange = { contactName = it }, label = { Text(stringResource(R.string.calendar_contact_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text(dateTimeText, color = GoldAccent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { DatePickerDialog(context, { _, y, m, d -> year = y; month = m; day = d }, year, month, day).show() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.calendar_pick_date)) }
                    OutlinedButton(onClick = { TimePickerDialog(context, { _, h, min -> hour = h; minute = min }, hour, minute, false).show() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.calendar_pick_time)) }
                }

                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("At Time" to 0, "10m Early" to 10, "30m Early" to 30, "1h Early" to 60, "1d Early" to 1440).forEach { (lbl, mins) ->
                        FilterChip(selected = reminderOffsetMinutes == mins, onClick = { reminderOffsetMinutes = mins }, label = { Text(lbl) })
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.calendar_alarm_alert), fontSize = 13.sp); Switch(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it }) }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.calendar_notif_reminder), fontSize = 13.sp); Switch(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it }) }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = channel == FollowUpChannel.GENERAL.name, onClick = { channel = FollowUpChannel.GENERAL.name }, label = { Text("General") })
                    FilterChip(selected = channel == FollowUpChannel.WHATSAPP.name, onClick = { channel = FollowUpChannel.WHATSAPP.name }, label = { Text("WhatsApp") })
                }

                if (channel == FollowUpChannel.WHATSAPP.name) {
                    OutlinedTextField(value = whatsappNumber, onValueChange = { whatsappNumber = it }, label = { Text("WhatsApp (+88017...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = whatsappMessage, onValueChange = { whatsappMessage = it }, label = { Text(stringResource(R.string.calendar_wa_msg_label)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = whatsappMode == WhatsAppScheduleMode.REMINDER_TO_SEND.name, onClick = { whatsappMode = WhatsAppScheduleMode.REMINDER_TO_SEND.name }, label = { Text("Reminder to Send") })
                        FilterChip(selected = whatsappMode == WhatsAppScheduleMode.AUTOMATIC_SEND.name, onClick = { whatsappMode = WhatsAppScheduleMode.AUTOMATIC_SEND.name }, label = { Text("Auto Send (API)") })
                    }
                    Text(
                        if (whatsappMode == WhatsAppScheduleMode.AUTOMATIC_SEND.name) "Requires official Meta WhatsApp Cloud API credentials; otherwise triggers Reminder to Send."
                        else "Notification opens WhatsApp chat with prepared message so you can tap Send.",
                        style = MaterialTheme.typography.labelSmall, color = GoldAccent
                    )
                }

                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.calendar_notes_label)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                val chosenCal = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }
                val normalizedWa = if (channel == FollowUpChannel.WHATSAPP.name && whatsappNumber.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(whatsappNumber) else whatsappNumber.trim()
                if (channel == FollowUpChannel.WHATSAPP.name && !PhoneContactsHelper.isValidInternationalOrLocalPhone(normalizedWa)) {
                    Toast.makeText(context, "Enter a valid WhatsApp number with country code.", Toast.LENGTH_SHORT).show(); return@Button
                }
                val finalName = contactName.trim().ifBlank { selectedMyContact?.fullName ?: "General Follow-Up" }
                val finalTitle = title.trim().ifBlank { "Follow-Up" }
                onSave(
                    FollowUpEntity(
                        id = initial?.id ?: 0L,
                        contactId = if (contactSource == "MY_CONTACTS") (selectedMyContact?.id ?: 0L) else (initial?.contactId ?: 0L),
                        contactName = finalName, companyName = companyName.trim().ifBlank { selectedMyContact?.companyName.orEmpty() },
                        title = finalTitle, notes = notes.trim(), dueAtTimestamp = chosenCal.timeInMillis,
                        isCompleted = initial?.isCompleted ?: false, createdAtTimestamp = initial?.createdAtTimestamp ?: System.currentTimeMillis(),
                        alarmEnabled = alarmEnabled, notificationEnabled = notificationEnabled, reminderOffsetMinutes = reminderOffsetMinutes,
                        channel = channel, whatsappNumber = normalizedWa,
                        whatsappMessage = if (channel == FollowUpChannel.WHATSAPP.name) whatsappMessage.trim().ifBlank { "Hello $finalName, following up on: $finalTitle" } else "",
                        whatsappMode = whatsappMode, status = FollowUpStatus.PENDING.name
                    )
                )
            }) { Text(stringResource(R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )

    if (pendingMultiNumberContact != null) {
        val pc = pendingMultiNumberContact!!
        AlertDialog(
            onDismissRequest = { pendingMultiNumberContact = null },
            title = { Text("Select Number for ${pc.displayName}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { pc.phones.forEach { num -> OutlinedButton(onClick = { whatsappNumber = num; pendingMultiNumberContact = null }, modifier = Modifier.fillMaxWidth()) { Text(num) } } } },
            confirmButton = { TextButton(onClick = { pendingMultiNumberContact = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}

@Composable
private fun CalendarStatBox(label: String, count: String, bgColor: Color, valueColor: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = bgColor)) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(count, color = valueColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
        }
    }
}
