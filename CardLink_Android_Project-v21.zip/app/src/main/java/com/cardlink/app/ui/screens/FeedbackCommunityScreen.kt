package com.cardlink.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary

private const val CARDLINK_WHATSAPP_GROUP_URL =
    "https://chat.whatsapp.com/BZMGBSV5y5z86IsnbRxdbd?s=cl&p=a&iam=2"

private enum class FeedbackCategory(
    val icon: ImageVector,
    val titleRes: Int,
    val descRes: Int,
    val templateLabel: String
) {
    FEATURE_REQUEST(
        Icons.Default.Lightbulb,
        R.string.feedback_cat_feature,
        R.string.feedback_cat_feature_desc,
        "Feature Request"
    ),
    REPORT_PROBLEM(
        Icons.Default.Build,
        R.string.feedback_cat_bug,
        R.string.feedback_cat_bug_desc,
        "Bug Report"
    ),
    IMPROVEMENT(
        Icons.Default.AutoAwesome,
        R.string.feedback_cat_improvement,
        R.string.feedback_cat_improvement_desc,
        "Improvement"
    ),
    UI_UX(
        Icons.Default.Palette,
        R.string.feedback_cat_uiux,
        R.string.feedback_cat_uiux_desc,
        "UI/UX"
    ),
    GENERAL(
        Icons.Default.Forum,
        R.string.feedback_cat_general,
        R.string.feedback_cat_general_desc,
        "General"
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackCommunityScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf<FeedbackCategory?>(null) }
    var feedbackNote by remember { mutableStateOf("") }
    var includeAppInfo by remember { mutableStateOf(false) }

    var showOpenConfirmDialog by remember { mutableStateOf(false) }
    var showOpenErrorDialog by remember { mutableStateOf(false) }

    fun buildFormattedFeedback(): String {
        val catLabel = selectedCategory?.templateLabel ?: "General"
        val body = feedbackNote.trim()
        return buildString {
            appendLine("CardLink Feedback")
            appendLine()
            appendLine("Type: $catLabel")
            if (body.isNotBlank()) {
                appendLine()
                appendLine("Feedback:")
                appendLine(body)
            }
            if (selectedCategory == FeedbackCategory.REPORT_PROBLEM && includeAppInfo) {
                val (verName, verCode) = readSafeAppVersion(context)
                val deviceModel = listOf(Build.MANUFACTURER, Build.MODEL)
                    .map { it.orEmpty().trim() }
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(" ")
                appendLine()
                appendLine("App Info:")
                appendLine("CardLink: v$verName (Build $verCode)")
                appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                if (deviceModel.isNotBlank()) {
                    appendLine("Device: $deviceModel")
                }
            }
        }.trim()
    }

    fun copyPreparedFeedback() {
        val prepared = buildFormattedFeedback()
        val ok = runCatching {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                ?: error("Clipboard unavailable")
            cm.setPrimaryClip(ClipData.newPlainText("CardLink Feedback", prepared))
            true
        }.getOrDefault(false)

        Toast.makeText(
            context,
            if (ok) context.getString(R.string.feedback_copied_toast)
            else context.getString(R.string.feedback_copy_failed_toast),
            Toast.LENGTH_SHORT
        ).show()
    }

    fun launchWhatsAppGroup() {
        val uri = Uri.parse(CARDLINK_WHATSAPP_GROUP_URL)
        val launched = runCatching {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrElse { ex ->
            if (ex is ActivityNotFoundException) false else false
        }
        if (!launched) {
            showOpenErrorDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.feedback_title),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.feedback_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Intro text
            Text(
                text = stringResource(R.string.feedback_intro),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
            )

            // Section: What would you like to share?
            Text(
                text = stringResource(R.string.feedback_choose_type_header),
                style = MaterialTheme.typography.labelLarge,
                color = GoldAccent,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FeedbackCategory.values().forEach { category ->
                    val isSelected = selectedCategory == category
                    val title = stringResource(category.titleRes)
                    val desc = stringResource(category.descRes)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .semantics {
                                selected = isSelected
                                contentDescription = "$title. $desc"
                            }
                            .clickable(role = Role.RadioButton) {
                                selectedCategory = if (isSelected) null else category
                            },
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(
                            width = if (isSelected) 1.6.dp else 1.dp,
                            color = if (isSelected) GoldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 62.dp)
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(40.dp),
                                shape = CircleShape,
                                color = if (isSelected) GoldAccent else GoldAccent.copy(alpha = 0.16f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = category.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) NavyPrimary else GoldAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.5.sp,
                                    color = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                                )
                            }
                            Icon(
                                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            // Optional App Info toggle ONLY when "Report a Problem" is selected
            AnimatedVisibility(
                visible = selectedCategory == FeedbackCategory.REPORT_PROBLEM,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = stringResource(R.string.feedback_include_app_info),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = stringResource(R.string.feedback_include_app_info_sub),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = includeAppInfo,
                            onCheckedChange = { includeAppInfo = it }
                        )
                    }
                }
            }

            // Optional Feedback Note + Copy Feedback action
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = stringResource(R.string.feedback_note_label),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = GoldAccent
                    )
                    OutlinedTextField(
                        value = feedbackNote,
                        onValueChange = { feedbackNote = it },
                        placeholder = { Text(stringResource(R.string.feedback_note_placeholder)) },
                        minLines = 3,
                        maxLines = 6,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = { copyPreparedFeedback() },
                        enabled = feedbackNote.isNotBlank() || selectedCategory != null,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.feedback_copy_btn),
                            color = GoldAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = stringResource(R.string.feedback_copy_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f)
                    )
                }
            }

            // Prominent CardLink Community Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.2.dp, GoldAccent.copy(alpha = 0.65f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            modifier = Modifier.size(46.dp),
                            shape = CircleShape,
                            color = GoldAccent.copy(alpha = 0.18f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Groups,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = stringResource(R.string.feedback_community_card_title),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = stringResource(R.string.feedback_community_card_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f)
                            )
                        }
                    }

                    Button(
                        onClick = { showOpenConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAccent,
                            contentColor = NavyPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.feedback_open_whatsapp_btn),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Privacy Notice
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PrivacyTip,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp).padding(top = 2.dp)
                    )
                    Text(
                        text = stringResource(R.string.feedback_privacy_notice),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
        }
    }

    // Confirmation Dialog before leaving CardLink
    if (showOpenConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showOpenConfirmDialog = false },
            icon = { Icon(Icons.Default.Chat, null, tint = GoldAccent) },
            title = {
                Text(
                    text = stringResource(R.string.feedback_confirm_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(text = stringResource(R.string.feedback_confirm_msg))
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOpenConfirmDialog = false
                        launchWhatsAppGroup()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAccent,
                        contentColor = NavyPrimary
                    )
                ) {
                    Text(
                        text = stringResource(R.string.action_continue),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showOpenConfirmDialog = false }) {
                    Text(text = stringResource(R.string.action_cancel))
                }
            }
        )
    }

    // Graceful Fallback Error Dialog if neither WhatsApp nor a browser can open the URL
    if (showOpenErrorDialog) {
        AlertDialog(
            onDismissRequest = { showOpenErrorDialog = false },
            title = {
                Text(
                    text = stringResource(R.string.feedback_unable_open_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(text = stringResource(R.string.feedback_unable_open_msg))
            },
            confirmButton = {
                Button(onClick = { showOpenErrorDialog = false }) {
                    Text(text = stringResource(R.string.action_close))
                }
            }
        )
    }
}

private fun readSafeAppVersion(context: Context): Pair<String, Long> = runCatching {
    val pi = context.packageManager.getPackageInfo(context.packageName, 0)
    val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        pi.longVersionCode
    } else {
        @Suppress("DEPRECATION")
        pi.versionCode.toLong()
    }
    Pair(pi.versionName ?: "8.1.0", code)
}.getOrDefault(Pair("8.1.0", 26L))
