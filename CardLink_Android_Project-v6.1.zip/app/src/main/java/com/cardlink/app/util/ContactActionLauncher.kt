package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object ContactActionLauncher {

    fun launchDialer(context: Context, rawPhone: String) {
        val cleaned = rawPhone.filter { it.isDigit() || it == '+' || it == '#' || it == '*' }
        if (cleaned.isBlank()) return
        safeStart(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleaned")), "No dialer found.")
    }

    fun launchWhatsAppChat(context: Context, rawNumber: String, recipientName: String = "", defaultCountryCode: String = "880") {
        val digits = rawNumber.filter { it.isDigit() }
        val e164 = when {
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") && digits.length == 11 -> defaultCountryCode + digits.drop(1)
            else -> digits
        }
        if (e164.length < 7) {
            Toast.makeText(context, "Invalid WhatsApp number", Toast.LENGTH_SHORT).show()
            return
        }
        val text = if (recipientName.isNotBlank()) "Hello $recipientName, great connecting with you via CardLink!" else "Hello!"
        val uri = Uri.parse("https://wa.me/$e164").buildUpon().appendQueryParameter("text", text).build()
        safeStart(context, Intent(Intent.ACTION_VIEW, uri), "WhatsApp not installed.")
    }

    fun launchEmailComposer(context: Context, emailAddress: String, recipientName: String = "", senderName: String = "") {
        val clean = emailAddress.trim()
        if (clean.isBlank()) return
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", clean, null)).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(clean))
            putExtra(Intent.EXTRA_SUBJECT, "Following up — $senderName")
        }
        safeStart(context, intent, "No email app found.")
    }

    fun launchGoogleMaps(context: Context, officeAddress: String, companyName: String = "") {
        val query = listOf(companyName.trim(), officeAddress.trim()).filter { it.isNotBlank() }.joinToString(", ")
        if (query.isBlank()) return
        val encoded = Uri.encode(query)
        val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$encoded")
        safeStart(context, Intent(Intent.ACTION_VIEW, webUri), "Could not open Maps.")
    }

    fun launchExternalUrl(context: Context, rawUrl: String) {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) return
        val url = if (trimmed.startsWith("http", true)) trimmed else "https://$trimmed"
        safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Could not open link.")
    }

    private fun safeStart(context: Context, intent: Intent, err: String) {
        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
        }
    }
}
