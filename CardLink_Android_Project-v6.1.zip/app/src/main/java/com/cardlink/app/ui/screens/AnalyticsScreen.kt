package com.cardlink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.data.model.ShareHistoryEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class TimeRange(val label: String, val days: Int?) {
    WEEK("This Week", 7),
    MONTH("This Month", 30),
    ALL("All Time", null)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    contacts: List<SavedContactEntity>,
    shareHistory: List<ShareHistoryEntity>
) {
    var selectedRange by remember { mutableStateOf(TimeRange.WEEK) }
    val now = remember { System.currentTimeMillis() }
    val cutoff = selectedRange.days?.let { now - it * 24L * 60L * 60L * 1000L } ?: 0L

    val periodContacts = remember(contacts, cutoff) {
        contacts.filter { it.savedAtTimestamp >= cutoff }
    }
    val periodShares = remember(shareHistory, cutoff) {
        shareHistory.filter { it.timestamp >= cutoff }
    }

    val categoryOrder = listOf("Client", "Vendor", "VIP", "Colleague", "Event", "General")
    val categoryCounts = remember(contacts) {
        categoryOrder.map { cat ->
            cat to contacts.count { it.categoryTag.equals(cat, ignoreCase = true) }
        }
    }
    val maxCategoryCount = (categoryCounts.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

    val methodCounts = remember(periodShares) {
        periodShares.groupingBy { it.method }.eachCount().entries.sortedByDescending { it.value }
    }
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Networking Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Your sharing & contact growth insights", style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.Analytics, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(32.dp))
        }

        // Period Filter Chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeRange.entries.forEach { range ->
                FilterChip(
                    selected = selectedRange == range,
                    onClick = { selectedRange = range },
                    label = { Text(range.label) }
                )
            }
        }

        // Top KPI Summary Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiStatCard(
                title = "Cards Shared",
                value = periodShares.size.toString(),
                subtitle = selectedRange.label,
                icon = Icons.Default.Share,
                modifier = Modifier.weight(1f)
            )
            KpiStatCard(
                title = "New Contacts",
                value = periodContacts.size.toString(),
                subtitle = selectedRange.label,
                icon = Icons.Default.PersonAdd,
                modifier = Modifier.weight(1f)
            )
            KpiStatCard(
                title = "Total Vault",
                value = contacts.size.toString(),
                subtitle = "All Contacts",
                icon = Icons.Default.Groups,
                modifier = Modifier.weight(1f)
            )
        }

        // Category Breakdown Visual Bars
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Contacts by Category", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (contacts.isEmpty()) {
                    Text(
                        "No contacts saved yet. Scan a QR or paper card to see category breakdown.",
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    categoryCounts.forEach { (category, count) ->
                        val fraction = (count.toFloat() / maxCategoryCount.toFloat()).coerceIn(0f, 1f)
                        val pct = if (contacts.isNotEmpty()) (count * 100 / contacts.size) else 0
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(category, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                Text("$count ($pct%)", fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (count > 0) GoldAccent else Color.Transparent)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sharing Channels Summary
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sharing Channels (${selectedRange.label})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (methodCounts.isEmpty()) {
                    Text(
                        "No shares recorded in this period yet. Share via NFC, QR, Bluetooth, or HTML Card to track.",
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    methodCounts.forEach { (method, count) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.CheckCircle, null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                                Text(method, fontSize = 14.sp)
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = GoldAccent.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "$count×",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Share History Log
        if (shareHistory.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Recent Activity", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    shareHistory.take(8).forEach { event ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(event.method, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(event.cardProfileTitle, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(
                                dateFormat.format(Date(event.timestamp)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp)
        }
    }
}
