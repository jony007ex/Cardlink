package com.cardlink.app.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate

@Composable
fun BusinessCardView(card: BusinessCardEntity, modifier: Modifier = Modifier) {
    val isIvory = card.template == CardTemplate.MINIMAL_IVORY
    val isSplit = card.template == CardTemplate.MODERN_SPLIT

    val bgPrimary = if (isIvory) Color(0xFFFAF9F6) else Color(card.primaryColorHex)
    val bgSecondary = if (isIvory) Color(0xFFF1EFEA) else Color(card.primaryColorHex).copy(alpha = 0.82f)
    val accentColor = Color(card.accentColorHex)
    val textColor = if (isIvory) Color(0xFF0F172A) else Color(card.textColorHex)

    val fontFamily = when (card.fontFamilyName) {
        "Serif" -> FontFamily.Serif
        "Monospace" -> FontFamily.Monospace
        else -> FontFamily.SansSerif
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 230.dp)
            .border(1.5.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(card.cornerRadiusDp.dp)),
        shape = RoundedCornerShape(card.cornerRadiusDp.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        if (isSplit) {
            // MODERN SPLIT PREMIUM LAYOUT
            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                Column(
                    modifier = Modifier
                        .width(120.dp)
                        .fillMaxHeight()
                        .background(accentColor)
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    ProfileAvatar(card, Color(0xFF0A192F), Color.White, fontFamily, 66)
                    Spacer(Modifier.height(10.dp))
                    if (!card.companyLogoUri.isNullOrBlank()) {
                        AsyncImage(
                            model = Uri.parse(card.companyLogoUri),
                            contentDescription = "Company Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(bgPrimary)
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(card.fullName.ifBlank { "Your Full Name" }, color = textColor, fontSize = 19.sp, fontWeight = FontWeight.Bold, fontFamily = fontFamily)
                    Text(card.designation.ifBlank { "Designation" }, color = accentColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFamily = fontFamily)
                    Text(
                        listOf(card.department, card.companyName).filter { it.isNotBlank() }.joinToString(" • "),
                        color = textColor.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        fontFamily = fontFamily
                    )
                    HorizontalDivider(color = accentColor.copy(alpha = 0.35f))
                    ContactLines(card, accentColor, textColor, fontFamily)
                }
            }
        } else {
            // EXECUTIVE NAVY / MINIMAL IVORY / CHARCOAL GOLD PREMIUM LAYOUT
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.linearGradient(listOf(bgPrimary, bgSecondary)))
            ) {
                // Subtle Gold Top Accent Bar
                Box(modifier = Modifier.fillMaxWidth().height(5.dp).background(accentColor))

                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header: Profile Photo + Name/Title + Top-Right Company Logo
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        ProfileAvatar(card, accentColor, accentColor, fontFamily, 62)

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = card.fullName.ifBlank { "Your Full Name" },
                                color = textColor,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = card.designation.ifBlank { "Professional Designation" },
                                color = accentColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = fontFamily
                            )
                            Text(
                                text = listOf(card.department, card.companyName)
                                    .filter { it.isNotBlank() }
                                    .joinToString(" • ")
                                    .ifBlank { "Organization Name" },
                                color = textColor.copy(alpha = 0.8f),
                                fontSize = 12.sp,
                                fontFamily = fontFamily
                            )
                        }

                        // Company Logo Badge (Top-Right)
                        if (!card.companyLogoUri.isNullOrBlank()) {
                            Surface(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                                color = Color.White.copy(alpha = 0.92f)
                            ) {
                                AsyncImage(
                                    model = Uri.parse(card.companyLogoUri),
                                    contentDescription = "Company Logo",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(4.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = accentColor.copy(alpha = 0.35f))

                    ContactLines(card, accentColor, textColor, fontFamily)
                }
            }
        }
    }
}

@Composable
private fun ProfileAvatar(
    card: BusinessCardEntity,
    borderColor: Color,
    initialsColor: Color,
    fontFamily: FontFamily,
    sizeDp: Int
) {
    if (!card.profilePhotoUri.isNullOrBlank()) {
        AsyncImage(
            model = Uri.parse(card.profilePhotoUri),
            contentDescription = "Profile Photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .border(2.dp, borderColor, CircleShape)
        )
    } else {
        Surface(
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .border(2.dp, borderColor, CircleShape),
            color = borderColor.copy(alpha = 0.18f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = card.fullName.take(2).uppercase().ifBlank { "CL" },
                    color = initialsColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    fontFamily = fontFamily
                )
            }
        }
    }
}

@Composable
private fun ContactLines(
    card: BusinessCardEntity,
    accentColor: Color,
    textColor: Color,
    fontFamily: FontFamily
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (card.phone.isNotBlank() && card.sharePhone) InfoRow(Icons.Default.Phone, card.phone, accentColor, textColor, fontFamily)
        if (card.email.isNotBlank() && card.shareEmail) InfoRow(Icons.Default.Email, card.email, accentColor, textColor, fontFamily)
        if (card.website.isNotBlank()) InfoRow(Icons.Default.Language, card.website, accentColor, textColor, fontFamily)
        if (card.officeAddress.isNotBlank() && card.shareAddress) InfoRow(Icons.Default.LocationOn, card.officeAddress, accentColor, textColor, fontFamily)
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, tint: Color, color: Color, fontFamily: FontFamily) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Text(text = text, color = color, fontSize = 13.sp, fontFamily = fontFamily)
    }
}


@Composable
fun FlippableBusinessCardView(
    card: BusinessCardEntity,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isFlipped by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val rotation by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 500),
        label = "card_flip"
    )
    val brandedQr = androidx.compose.runtime.remember(card) {
        com.cardlink.app.util.PremiumExtrasHelper.generateBrandedQrBitmap(context, card, 420)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clickable { isFlipped = !isFlipped }
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 14f * density
            }
    ) {
        if (rotation <= 90f) {
            BusinessCardView(card = card)
        } else {
            // Back side of the 3D Card (Branded Logo QR + Bio + Flip Hint)
            val accentColor = Color(card.accentColorHex)
            val bgPrimary = Color(card.primaryColorHex)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 230.dp)
                    .graphicsLayer { rotationY = 180f }
                    .border(1.5.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(card.cornerRadiusDp.dp)),
                shape = RoundedCornerShape(card.cornerRadiusDp.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(bgPrimary, bgPrimary.copy(alpha = 0.85f))))
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        modifier = Modifier.size(135.dp)
                    ) {
                        androidx.compose.foundation.Image(
                            bitmap = brandedQr.asImageBitmap(),
                            contentDescription = "Branded QR",
                            modifier = Modifier.fillMaxSize().padding(6.dp)
                        )
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(card.companyName.ifBlank { "CardLink" }, color = accentColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (card.bio.isNotBlank()) {
                            Text(card.bio, color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp, maxLines = 4)
                        }
                        Text("Tap card to flip front", color = accentColor.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
