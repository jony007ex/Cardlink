package com.cardlink.app.ui.screens

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.cardlink.app.ui.components.CardLinkCameraZoomState
import com.cardlink.app.ui.components.ScannerZoomPresetBar
import com.cardlink.app.ui.components.SmartCardCropDialog
import com.cardlink.app.ui.components.attachTapToFocus
import com.cardlink.app.ui.components.cardLinkPinchToZoom
import coil.compose.AsyncImage
import com.cardlink.app.R
import com.cardlink.app.data.model.IdDocumentEntity
import com.cardlink.app.data.model.IdDocumentPageEntity
import com.cardlink.app.data.model.IdDocumentType
import com.cardlink.app.ui.components.ScreenPrivacyGuard
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.util.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import kotlin.math.abs

private tailrec fun Context.findActivityForIds(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForIds()
    else -> null
}

private fun ImageProxy.toUprightIdBitmap(): Bitmap? {
    val buffer = planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rot = imageInfo.rotationDegrees
    if (rot == 0) return raw
    val m = Matrix().apply { postRotate(rot.toFloat()) }
    val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    if (rotated !== raw) raw.recycle()
    return rotated
}

private val DROPDOWN_DOCUMENT_TYPES = listOf(
    IdDocumentType.NATIONAL_ID,
    IdDocumentType.PASSPORT,
    IdDocumentType.DRIVING_LICENCE,
    IdDocumentType.EMPLOYEE_ID,
    IdDocumentType.STUDENT_ID,
    IdDocumentType.PROFESSIONAL_ID,
    IdDocumentType.MEMBERSHIP_ID,
    IdDocumentType.ACCESS_CARD,
    IdDocumentType.CUSTOM
)

@Composable
private fun idTypeLabel(typeName: String, customName: String = ""): String {
    if (typeName == IdDocumentType.CUSTOM.name && customName.isNotBlank()) return customName
    return when (runCatching { IdDocumentType.valueOf(typeName) }.getOrDefault(IdDocumentType.CUSTOM)) {
        IdDocumentType.NATIONAL_ID -> stringResource(R.string.id_type_national)
        IdDocumentType.PASSPORT -> stringResource(R.string.id_type_passport)
        IdDocumentType.DRIVING_LICENCE -> stringResource(R.string.id_type_driving)
        IdDocumentType.EMPLOYEE_ID, IdDocumentType.OFFICE_ID -> stringResource(R.string.id_type_employee_office)
        IdDocumentType.STUDENT_ID -> stringResource(R.string.id_type_student)
        IdDocumentType.PROFESSIONAL_ID -> stringResource(R.string.id_type_professional)
        IdDocumentType.MEMBERSHIP_ID -> stringResource(R.string.id_type_membership)
        IdDocumentType.ACCESS_CARD -> stringResource(R.string.id_type_access)
        IdDocumentType.TRADE_LICENCE -> "Trade Licence"
        IdDocumentType.TIN_CERTIFICATE -> "TIN Certificate"
        IdDocumentType.BIN_VAT_CERTIFICATE -> "BIN / VAT Certificate"
        IdDocumentType.PROFESSIONAL_LICENCE -> "Professional Licence"
        IdDocumentType.VENDOR_ENLISTMENT -> "Vendor Enlistment"
        IdDocumentType.INSURANCE_CERTIFICATE -> "Insurance Certificate"
        IdDocumentType.BUSINESS_DOCUMENT -> "Business Document"
        IdDocumentType.CUSTOM -> stringResource(R.string.id_type_custom)
    }
}

@Composable
private fun expiryStatusColor(status: IdExpiryStatus): Color = when (status) {
    IdExpiryStatus.VALID -> Color(0xFF10B981)
    IdExpiryStatus.RENEWAL_RECOMMENDED -> Color(0xFFF59E0B)
    IdExpiryStatus.EXPIRING_SOON -> Color(0xFFF97316)
    IdExpiryStatus.EXPIRES_TODAY -> Color(0xFFEF4444)
    IdExpiryStatus.EXPIRED -> Color(0xFFEF4444)
    IdExpiryStatus.NO_EXPIRY -> MaterialTheme.colorScheme.primary
}

@Composable
private fun expiryCountdownText(expiryDateIso: String?): String {
    val days = IdExpiryHelper.daysUntilExpiry(expiryDateIso) ?: return ""
    return when {
        days > 0L -> stringResource(R.string.id_expires_in_days, days)
        days == 0L -> stringResource(R.string.id_expires_today)
        else -> stringResource(R.string.id_expired_days_ago, abs(days))
    }
}

@Composable
private fun expiryStatusBadgeLabel(status: IdExpiryStatus): String = when (status) {
    IdExpiryStatus.VALID -> stringResource(R.string.id_status_valid)
    IdExpiryStatus.RENEWAL_RECOMMENDED -> stringResource(R.string.id_status_renewal_recommended)
    IdExpiryStatus.EXPIRING_SOON -> stringResource(R.string.id_status_expiring_soon)
    IdExpiryStatus.EXPIRES_TODAY -> stringResource(R.string.id_expires_today)
    IdExpiryStatus.EXPIRED -> stringResource(R.string.id_status_expired)
    IdExpiryStatus.NO_EXPIRY -> ""
}

// =========================================================================
// 1. MY IDs WALLET HOME SCREEN (Minimal Circular "+" FAB matching Loyalty Cards)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdsWalletScreen(
    documents: List<IdDocumentEntity>,
    allPages: List<IdDocumentPageEntity>,
    onAddNewId: () -> Unit,
    onOpenIdDetail: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val pagesByDoc = remember(allPages) { allPages.groupBy { it.documentUuid } }

    val filteredDocs = remember(documents, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) documents
        else documents.filter {
            it.documentName.contains(q, true) ||
                it.documentType.contains(q, true) ||
                it.customTypeName.contains(q, true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.my_ids_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.my_ids_wallet_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewId,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.my_ids_add_btn)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (documents.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Badge, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                                }
                            }
                            Text(
                                text = stringResource(R.string.my_ids_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.my_ids_empty_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onAddNewId,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.my_ids_add_btn), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.my_ids_search_hint)) },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredDocs, key = { it.stableUuid }) { doc ->
                        val docPages = pagesByDoc[doc.stableUuid].orEmpty()
                        val status = IdExpiryHelper.resolveStatus(doc.expiryDateIso)
                        val statusColor = expiryStatusColor(status)
                        val countdown = expiryCountdownText(doc.expiryDateIso)
                        val badgeLabel = expiryStatusBadgeLabel(status)

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onOpenIdDetail(doc.stableUuid) },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(
                                1.dp,
                                if (status == IdExpiryStatus.EXPIRED || status == IdExpiryStatus.EXPIRING_SOON || status == IdExpiryStatus.EXPIRES_TODAY)
                                    statusColor.copy(alpha = 0.65f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(46.dp),
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Badge, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                    }
                                }
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        text = doc.documentName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${idTypeLabel(doc.documentType, doc.customTypeName)} • ${docPages.size} ${stringResource(R.string.my_ids_pages_suffix)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                    if (status != IdExpiryStatus.NO_EXPIRY) {
                                        val summaryLine = when (status) {
                                            IdExpiryStatus.EXPIRED, IdExpiryStatus.EXPIRES_TODAY -> countdown
                                            else -> "$badgeLabel • $countdown"
                                        }
                                        Text(
                                            text = summaryLine,
                                            color = statusColor,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// 2. ADD / EDIT ID SCREEN (Dropdown Type, Clean Add Document Panel, Structured OCR)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdEditorScreen(
    existingDoc: IdDocumentEntity?,
    existingPages: List<IdDocumentPageEntity>,
    onSave: (IdDocumentEntity, List<IdDocumentPageEntity>) -> Unit,
    onOpenSettings: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEditing = existingDoc != null
    val docUuid = remember(existingDoc) { existingDoc?.stableUuid ?: java.util.UUID.randomUUID().toString() }

    var documentName by remember(existingDoc) { mutableStateOf(existingDoc?.documentName.orEmpty()) }
    var documentType by remember(existingDoc) { mutableStateOf(existingDoc?.documentType ?: IdDocumentType.NATIONAL_ID.name) }
    var customTypeName by remember(existingDoc) { mutableStateOf(existingDoc?.customTypeName.orEmpty()) }
    var typeDropdownExpanded by remember { mutableStateOf(false) }

    var pages by remember(existingDoc, existingPages) { mutableStateOf(existingPages) }
    var extractedFields by remember(existingDoc) {
        mutableStateOf(IdOcrParser.parseStoredText(existingDoc?.extractedText.orEmpty()))
    }
    var notes by remember(existingDoc) { mutableStateOf(existingDoc?.notes.orEmpty()) }
    var expiryDateIso by remember(existingDoc) { mutableStateOf(existingDoc?.expiryDateIso) }
    var remindersEnabled by remember(existingDoc) { mutableStateOf(existingDoc?.expiryRemindersEnabled ?: true) }

    var isRunningOcr by remember { mutableStateOf(false) }
    var detectedExpiryCandidates by remember { mutableStateOf<List<String>>(emptyList()) }
    var showAddSourceDialog by remember { mutableStateOf(false) }
    var showAddFieldDialog by remember { mutableStateOf(false) }
    var replacePageIndex by remember { mutableStateOf<Int?>(null) }
    var showInAppIdCamera by remember { mutableStateOf(false) }
    var pendingIdCropBitmap by remember { mutableStateOf<Bitmap?>(null) }

    fun normalizePageLabels(list: List<IdDocumentPageEntity>): List<IdDocumentPageEntity> {
        val isPassport = documentType == IdDocumentType.PASSPORT.name
        val useCardLabels = !isPassport && list.size <= 2
        return list.mapIndexed { idx, p ->
            val lbl = if (useCardLabels) {
                if (idx == 0) "Front" else "Back"
            } else {
                "Page ${idx + 1}"
            }
            p.copy(pageIndex = idx, pageLabel = lbl)
        }
    }

    fun addOrReplacePagesFromUris(savedUris: List<String>) {
        if (savedUris.isEmpty()) return
        val replaceIdx = replacePageIndex
        if (replaceIdx != null && replaceIdx in pages.indices) {
            val updated = pages.toMutableList()
            updated[replaceIdx] = updated[replaceIdx].copy(imageUri = savedUris.first())
            pages = normalizePageLabels(updated)
            replacePageIndex = null
        } else {
            val appended = savedUris.map { u ->
                IdDocumentPageEntity(documentUuid = docUuid, pageIndex = 0, pageLabel = "", imageUri = u)
            }
            pages = normalizePageLabels(pages + appended)
        }
    }

    fun launchCameraCapture() {
        showInAppIdCamera = true
    }

    fun openGalleryImageForIdCrop(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2000) }
            if (bmp != null) {
                pendingIdCropBitmap = bmp
            } else {
                val saved = IdShareHelper.importUriAsIdPageImages(context, uri)
                addOrReplacePagesFromUris(saved)
            }
        }
    }

    val galleryPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            openGalleryImageForIdCrop(uri)
        }
    }

    val fileImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val saved = IdShareHelper.importUriAsIdPageImages(context, uri)
                if (saved.isEmpty()) {
                    Toast.makeText(context, "Could not import selected file.", Toast.LENGTH_SHORT).show()
                } else {
                    addOrReplacePagesFromUris(saved)
                }
            }
        }
    }

    fun openDatePicker(initialIso: String? = expiryDateIso) {
        val base = IdExpiryHelper.parseIsoDate(initialIso) ?: LocalDate.now().plusYears(1)
        DatePickerDialog(
            context,
            { _, y, mZeroBased, d ->
                expiryDateIso = IdExpiryHelper.toIsoDate(y, mZeroBased + 1, d)
                detectedExpiryCandidates = emptyList()
            },
            base.year,
            base.monthValue - 1,
            base.dayOfMonth
        ).show()
    }

    fun runStructuredOcrAcrossPages() {
        if (pages.isEmpty()) {
            Toast.makeText(context, "Please add a document photo or file first.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            isRunningOcr = true
            runCatching {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val sb = StringBuilder()
                for (p in pages) {
                    val bmp = withContext(Dispatchers.IO) {
                        ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(p.imageUri))
                    } ?: continue
                    val res = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                    if (res.text.isNotBlank()) {
                        if (sb.isNotEmpty()) sb.append("\n")
                        sb.append(res.text.trim())
                    }
                }
                val rawText = sb.toString().trim()
                if (rawText.isNotBlank()) {
                    val parsedFields = IdOcrParser.extractPersonalFields(rawText)
                    if (parsedFields.isNotEmpty()) {
                        extractedFields = parsedFields
                    } else {
                        Toast.makeText(context, context.getString(R.string.my_ids_ocr_no_personal_fields), Toast.LENGTH_LONG).show()
                    }
                    val candidates = IdExpiryHelper.detectExpiryDateCandidates(rawText)
                    if (candidates.isNotEmpty()) {
                        detectedExpiryCandidates = candidates
                    }
                } else {
                    Toast.makeText(context, "No readable text detected.", Toast.LENGTH_SHORT).show()
                }
            }.onFailure {
                Toast.makeText(context, "OCR could not complete.", Toast.LENGTH_SHORT).show()
            }
            isRunningOcr = false
        }
    }

    val notificationsActive = FollowUpScheduler.isNotificationsEffectivelyEnabled(context)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isEditing) stringResource(R.string.my_ids_edit_title) else stringResource(R.string.my_ids_add_btn),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Document Name
            OutlinedTextField(
                value = documentName,
                onValueChange = { documentName = it },
                label = { Text(stringResource(R.string.my_ids_doc_name_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 2. Document Type Dropdown (ExposedDropdownMenuBox)
            ExposedDropdownMenuBox(
                expanded = typeDropdownExpanded,
                onExpandedChange = { typeDropdownExpanded = !typeDropdownExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = idTypeLabel(documentType),
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.my_ids_doc_type_label)) },
                    placeholder = { Text(stringResource(R.string.my_ids_select_doc_type)) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = typeDropdownExpanded,
                    onDismissRequest = { typeDropdownExpanded = false }
                ) {
                    DROPDOWN_DOCUMENT_TYPES.forEach { type ->
                        val isSelected = documentType == type.name ||
                            (type == IdDocumentType.EMPLOYEE_ID && documentType == IdDocumentType.OFFICE_ID.name)
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = idTypeLabel(type.name),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            trailingIcon = {
                                if (isSelected) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                documentType = type.name
                                pages = normalizePageLabels(pages)
                                typeDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            if (documentType == IdDocumentType.CUSTOM.name) {
                OutlinedTextField(
                    value = customTypeName,
                    onValueChange = { customTypeName = it },
                    label = { Text(stringResource(R.string.my_ids_custom_type_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 3. Clean "Add Document" Upload / Capture Panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            modifier = Modifier.size(40.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.UploadFile, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.my_ids_add_document_title),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = stringResource(R.string.my_ids_add_document_sub),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                    }

                    if (pages.isEmpty()) {
                        // Primary 3-button upload row inside the panel
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { replacePageIndex = null; launchCameraCapture() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PhotoCamera, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.height(2.dp))
                                    Text(stringResource(R.string.my_ids_take_photo), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    replacePageIndex = null
                                    galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PhotoLibrary, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.height(2.dp))
                                    Text(stringResource(R.string.my_ids_choose_image), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    replacePageIndex = null
                                    fileImportLauncher.launch(arrayOf("image/*", "application/pdf"))
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.height(2.dp))
                                    Text(stringResource(R.string.my_ids_import_file_short), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    } else {
                        // Document previews + "+ Add Another Side / Page"
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            pages.forEachIndexed { idx, page ->
                                Card(
                                    modifier = Modifier.width(156.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(page.pageLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        VaultImage(
                                    uriString = page.imageUri,
                                            contentDescription = page.pageLabel,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(1.586f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        )
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            TextButton(
                                                onClick = { replacePageIndex = idx; showAddSourceDialog = true },
                                                contentPadding = PaddingValues(horizontal = 4.dp)
                                            ) { Text(stringResource(R.string.my_ids_replace), fontSize = 11.sp) }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = {
                                                        replacePageIndex = idx
                                                        scope.launch {
                                                            val bmp = withContext(Dispatchers.IO) {
                                                                VaultCryptoManager.decodeVaultBitmap(context, page.imageUri, 2000)
                                                                    ?: ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(page.imageUri), 2000)
                                                            }
                                                            if (bmp != null) pendingIdCropBitmap = bmp
                                                        }
                                                    },
                                                    modifier = Modifier.size(30.dp)
                                                ) { Icon(Icons.Default.Crop, contentDescription = stringResource(R.string.crop_adjust_title), tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp)) }
                                                IconButton(
                                                    onClick = {
                                                        pages = normalizePageLabels(pages.filterIndexed { i, _ -> i != idx })
                                                    },
                                                    modifier = Modifier.size(30.dp)
                                                ) { Icon(Icons.Default.DeleteOutline, contentDescription = stringResource(R.string.action_delete), tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = { replacePageIndex = null; showAddSourceDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                        ) {
                            Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.my_ids_add_another_side_page), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // 4. Structured Personal Information Extraction (Filtered OCR)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.my_ids_extracted_info), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { showAddFieldDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.action_add), fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = { runStructuredOcrAcrossPages() },
                        enabled = !isRunningOcr && pages.isNotEmpty(),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        if (isRunningOcr) CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.DocumentScanner, null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.my_ids_run_ocr), fontSize = 12.sp)
                    }
                }
            }

            // OCR Expiry Date Confirmation Banner (NEVER auto-saved without confirmation!)
            if (detectedExpiryCandidates.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF172A46)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.id_ocr_expiry_detected), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        detectedExpiryCandidates.forEach { isoCandidate ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(IdExpiryHelper.formatDisplayDate(isoCandidate), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { openDatePicker(isoCandidate) }) {
                                        Text(stringResource(R.string.action_edit), fontSize = 12.sp)
                                    }
                                    Button(
                                        onClick = {
                                            expiryDateIso = isoCandidate
                                            detectedExpiryCandidates = emptyList()
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) { Text(stringResource(R.string.action_confirm), fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }

            if (extractedFields.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text(
                        text = stringResource(R.string.my_ids_extracted_info_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.padding(14.dp)
                    )
                }
            } else {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        extractedFields.forEachIndexed { idx, field ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = field.value,
                                    onValueChange = { updatedVal ->
                                        val mutable = extractedFields.toMutableList()
                                        mutable[idx] = field.copy(value = updatedVal)
                                        extractedFields = mutable
                                    },
                                    label = { Text(field.key) },
                                    singleLine = field.key != "Address",
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        extractedFields = extractedFields.filterIndexed { i, _ -> i != idx }
                                    }
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_delete), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            Text(
                text = stringResource(R.string.my_ids_ocr_disclaimer),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )

            // 5. Expiry Date & Renewal Reminders (Unchanged trusted logic)
            HorizontalDivider()
            Text(stringResource(R.string.id_expiry_date_label), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (expiryDateIso != null) IdExpiryHelper.formatDisplayDate(expiryDateIso)
                                else stringResource(R.string.id_no_expiry_set),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            if (expiryDateIso != null) {
                                val st = IdExpiryHelper.resolveStatus(expiryDateIso)
                                Text(
                                    text = expiryCountdownText(expiryDateIso),
                                    color = expiryStatusColor(st),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { openDatePicker() }) {
                                Text(stringResource(R.string.calendar_pick_date), fontSize = 12.sp)
                            }
                            if (expiryDateIso != null) {
                                IconButton(onClick = { expiryDateIso = null }) {
                                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                                }
                            }
                        }
                    }

                    if (expiryDateIso != null) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.id_expiry_reminders_label), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (remindersEnabled) {
                                    Text(
                                        text = stringResource(R.string.id_reminder_milestones_summary),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Switch(checked = remindersEnabled, onCheckedChange = { remindersEnabled = it })
                        }

                        if (remindersEnabled && !notificationsActive) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.id_notif_off_notice),
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = onOpenSettings) {
                                        Text(stringResource(R.string.calendar_open_settings), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(stringResource(R.string.loyalty_notes_label)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Button(
                onClick = {
                    val trimmedName = documentName.trim()
                    if (trimmedName.isBlank()) {
                        Toast.makeText(context, context.getString(R.string.my_ids_name_required), Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val serializedFields = IdOcrParser.serializeFields(extractedFields)
                    val entity = (existingDoc ?: IdDocumentEntity(stableUuid = docUuid, documentName = trimmedName)).copy(
                        documentName = trimmedName,
                        documentType = documentType,
                        customTypeName = customTypeName.trim(),
                        extractedText = serializedFields,
                        notes = notes.trim(),
                        expiryDateIso = expiryDateIso,
                        expiryRemindersEnabled = remindersEnabled
                    )
                    onSave(entity, normalizePageLabels(pages))
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_save), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showInAppIdCamera) {
        IdDocumentCameraCaptureDialog(
            pageLabel = if (pages.isEmpty()) stringResource(R.string.card_side_front) else "Page ${pages.size + 1}",
            onCaptured = { bmp ->
                showInAppIdCamera = false
                pendingIdCropBitmap = bmp
            },
            onPickedGalleryUri = { uri ->
                showInAppIdCamera = false
                openGalleryImageForIdCrop(uri)
            },
            onDismiss = { showInAppIdCamera = false }
        )
    }

    pendingIdCropBitmap?.let { srcBmp ->
        SmartCardCropDialog(
            sourceBitmap = srcBmp,
            onConfirm = { croppedBmp, _ ->
                pendingIdCropBitmap = null
                scope.launch {
                    val savedUri = withContext(Dispatchers.IO) {
                        IdShareHelper.saveIdPageBitmap(context, croppedBmp, "cam")
                    }
                    addOrReplacePagesFromUris(listOf(savedUri))
                }
            },
            onDismiss = { pendingIdCropBitmap = null }
        )
    }

    // Add / Replace Document Source Dialog
    if (showAddSourceDialog) {
        AlertDialog(
            onDismissRequest = { showAddSourceDialog = false },
            title = { Text(stringResource(R.string.my_ids_add_document_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { showAddSourceDialog = false; launchCameraCapture() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoCamera, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_take_photo))
                    }
                    OutlinedButton(
                        onClick = {
                            showAddSourceDialog = false
                            galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_choose_image))
                    }
                    OutlinedButton(
                        onClick = {
                            showAddSourceDialog = false
                            fileImportLauncher.launch(arrayOf("image/*", "application/pdf"))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.my_ids_import_file_short))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddSourceDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    // Add Manual Personal Field Dialog
    if (showAddFieldDialog) {
        var selectedKey by remember { mutableStateOf(IdOcrParser.STANDARD_FIELD_KEYS.first()) }
        var fieldVal by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddFieldDialog = false },
            title = { Text(stringResource(R.string.my_ids_add_field_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IdOcrParser.STANDARD_FIELD_KEYS.forEach { k ->
                            FilterChip(selected = selectedKey == k, onClick = { selectedKey = k }, label = { Text(k, fontSize = 11.sp) })
                        }
                    }
                    OutlinedTextField(
                        value = fieldVal,
                        onValueChange = { fieldVal = it },
                        label = { Text(selectedKey) },
                        singleLine = selectedKey != "Address",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (fieldVal.isNotBlank()) {
                        extractedFields = extractedFields + ExtractedIdField(selectedKey, fieldVal.trim())
                    }
                    showAddFieldDialog = false
                }) { Text(stringResource(R.string.action_add)) }
            },
            dismissButton = {
                TextButton(onClick = { showAddFieldDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

// =========================================================================
// 3. MY ID DETAIL SCREEN (Tap-to-Flip, Single Expandable Share Panel, Structured Info)
// =========================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyIdDetailScreen(
    doc: IdDocumentEntity,
    pages: List<IdDocumentPageEntity>,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenSettings: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()



    val status = IdExpiryHelper.resolveStatus(doc.expiryDateIso)
    val statusColor = expiryStatusColor(status)
    val countdown = expiryCountdownText(doc.expiryDateIso)
    val notificationsActive = FollowUpScheduler.isNotificationsEffectivelyEnabled(context)
    val structuredFields = remember(doc.extractedText) { IdOcrParser.parseStoredText(doc.extractedText) }

    var isFlipped by remember { mutableStateOf(false) }
    val flipRotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(420),
        label = "id_flip"
    )
    var activeMultiPageIdx by remember(pages.size) { mutableIntStateOf(0) }
    var enlargedPhotoUri by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    // Progressive Expandable Share Panel State (No Share icon in TopAppBar!)
    var isSharePanelExpanded by remember { mutableStateOf(false) }
    var selectedSide by remember(pages.size) {
        mutableStateOf(if (pages.size == 2) "BOTH" else "ALL")
    }
    var selectedMultiPageIndices by remember(pages.size) {
        mutableStateOf(pages.indices.toSet())
    }
    var selectedFormat by remember { mutableStateOf(IdExportFormat.PDF) }
    var pendingSharePages by remember { mutableStateOf<List<IdDocumentPageEntity>?>(null) }

    val flipActionLabel = if (isFlipped) stringResource(R.string.my_ids_show_front_a11y) else stringResource(R.string.my_ids_show_back_a11y)

    var watermarkEnabled by remember { mutableStateOf(true) }
    val todayWatermarkDate = remember {
        java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.US).format(java.util.Date())
    }
    var watermarkText by remember { mutableStateOf("For Verification Only • $todayWatermarkDate") }

    ScreenPrivacyGuard {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(doc.documentName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            idTypeLabel(doc.documentType, doc.customTypeName),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.action_edit))
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.action_delete), tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. EXPIRY STATUS & COUNTDOWN CARD
            if (doc.expiryDateIso != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.7f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = expiryStatusBadgeLabel(status),
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = countdown,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            text = "${stringResource(R.string.id_expiry_date_label)}: ${IdExpiryHelper.formatDisplayDate(doc.expiryDateIso)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (doc.expiryRemindersEnabled) {
                            if (notificationsActive) {
                                Text(
                                    text = "${stringResource(R.string.id_expiry_reminders_label)}: ${stringResource(R.string.id_reminder_milestones_summary)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.id_notif_off_notice),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = onOpenSettings) {
                                        Text(stringResource(R.string.calendar_open_settings), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. DOCUMENT PREVIEW (Tap-to-Flip for 2-sided IDs, Single preview for 1-sided, Page nav for 3+ pages)
            if (pages.size == 2) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.586f)
                            .semantics { contentDescription = flipActionLabel }
                            .clickable(role = Role.Button, onClickLabel = flipActionLabel) {
                                isFlipped = !isFlipped
                            }
                            .graphicsLayer {
                                rotationY = flipRotation
                                cameraDistance = 14f * density
                            }
                    ) {
                        val activePage = if (flipRotation <= 90f) pages[0] else pages[1]
                        Card(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer { if (flipRotation > 90f) rotationY = 180f }
                                .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                VaultImage(
                                    uriString = activePage.imageUri,
                                    contentDescription = activePage.pageLabel,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                // Side badge (Front / Back)
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f),
                                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp)
                                ) {
                                    Text(
                                        text = if (flipRotation <= 90f) stringResource(R.string.detail_front_side) else stringResource(R.string.detail_back_side),
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                // Full-screen zoom icon button
                                IconButton(
                                    onClick = { enlargedPhotoUri = activePage.imageUri },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.72f))
                                ) {
                                    Icon(Icons.Default.ZoomOutMap, contentDescription = stringResource(R.string.loyalty_tap_to_enlarge), tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    // Subtle discoverable instruction below the card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f), modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.my_ids_tap_to_flip_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                    }
                }
            } else if (pages.size == 1) {
                val page = pages.first()
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.586f)
                        .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                        .clickable { enlargedPhotoUri = page.imageUri },
                    shape = RoundedCornerShape(16.dp)
                ) {
                    VaultImage(
                                    uriString = page.imageUri,
                        contentDescription = page.pageLabel,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else if (pages.size > 2) {
                val safeIdx = activeMultiPageIdx.coerceIn(0, pages.lastIndex)
                val currentPage = pages[safeIdx]
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pages.forEachIndexed { idx, p ->
                            FilterChip(
                                selected = safeIdx == idx,
                                onClick = { activeMultiPageIdx = idx },
                                label = { Text(p.pageLabel, fontSize = 12.sp) }
                            )
                        }
                    }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.586f)
                            .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                            .clickable { enlargedPhotoUri = currentPage.imageUri },
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        VaultImage(
                                    uriString = currentPage.imageUri,
                            contentDescription = currentPage.pageLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // 3. SINGLE CLEAR SHARE ACTION + PROGRESSIVE EXPANDABLE SHARE PANEL
            if (pages.isNotEmpty()) {
                OutlinedButton(
                    onClick = { isSharePanelExpanded = !isSharePanelExpanded },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.my_ids_share_short),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        imageVector = if (isSharePanelExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                AnimatedVisibility(
                    visible = isSharePanelExpanded,
                    enter = fadeIn(tween(180)) + expandVertically(tween(200)),
                    exit = fadeOut(tween(160)) + shrinkVertically(tween(180))
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Side / Pages selector (only shown when >1 page)
                            if (pages.size == 2) {
                                Text(stringResource(R.string.my_ids_share_side_label), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    val sideOpts = listOf(
                                        "FRONT" to stringResource(R.string.my_ids_side_front),
                                        "BACK" to stringResource(R.string.my_ids_side_back),
                                        "BOTH" to stringResource(R.string.my_ids_side_both)
                                    )
                                    sideOpts.forEach { (key, lbl) ->
                                        val isSel = selectedSide == key
                                        SelectableSegmentButton(
                                            label = lbl,
                                            isSelected = isSel,
                                            onClick = { selectedSide = key },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            } else if (pages.size > 2) {
                                Text(stringResource(R.string.my_ids_share_pages_label), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SelectableSegmentButton(
                                        label = stringResource(R.string.my_ids_all_pages),
                                        isSelected = selectedSide == "ALL",
                                        onClick = { selectedSide = "ALL" },
                                        modifier = Modifier.weight(1f)
                                    )
                                    SelectableSegmentButton(
                                        label = stringResource(R.string.my_ids_selected_pages),
                                        isSelected = selectedSide == "SELECTED",
                                        onClick = { selectedSide = "SELECTED" },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (selectedSide == "SELECTED") {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        pages.forEachIndexed { idx, p ->
                                            val checked = idx in selectedMultiPageIndices
                                            FilterChip(
                                                selected = checked,
                                                onClick = {
                                                    selectedMultiPageIndices = if (checked && selectedMultiPageIndices.size > 1) {
                                                        selectedMultiPageIndices - idx
                                                    } else {
                                                        selectedMultiPageIndices + idx
                                                    }
                                                },
                                                label = { Text(p.pageLabel, fontSize = 12.sp) }
                                            )
                                        }
                                    }
                                }
                            }

                            // File Format selector (PDF | JPG | PNG)
                            Text(stringResource(R.string.my_ids_file_format_label), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IdExportFormat.values().forEach { fmt ->
                                    SelectableSegmentButton(
                                        label = fmt.label,
                                        isSelected = selectedFormat == fmt,
                                        onClick = { selectedFormat = fmt },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            // Dynamic Anti-Misuse Watermark Option
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.security_watermark_toggle),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = stringResource(R.string.security_watermark_sub),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                }
                                Switch(checked = watermarkEnabled, onCheckedChange = { watermarkEnabled = it })
                            }
                            if (watermarkEnabled) {
                                OutlinedTextField(
                                    value = watermarkText,
                                    onValueChange = { watermarkText = it },
                                    label = { Text(stringResource(R.string.security_watermark_text_label)) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Button(
                                onClick = {
                                    val targetPages = when {
                                        pages.size == 1 -> pages
                                        pages.size == 2 && selectedSide == "FRONT" -> listOf(pages[0])
                                        pages.size == 2 && selectedSide == "BACK" -> listOf(pages[1])
                                        pages.size > 2 && selectedSide == "SELECTED" -> pages.filterIndexed { i, _ -> i in selectedMultiPageIndices }.ifEmpty { pages }
                                        else -> pages
                                    }
                                    pendingSharePages = targetPages
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Share, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.my_ids_share_short), fontWeight = FontWeight.Bold)
                            }

                            Text(
                                text = stringResource(R.string.my_ids_share_instruction),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f)
                            )
                        }
                    }
                }
            }

            // 4. EXTRACTED PERSONAL INFORMATION
            if (structuredFields.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(stringResource(R.string.my_ids_extracted_info), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = {
                                SecureClipboardHelper.copySensitive(
                                    context = context,
                                    label = "Extracted ID Info",
                                    text = IdOcrParser.serializeFields(structuredFields)
                                )
                            }) { Text("Copy", fontSize = 12.sp) }
                        }
                        structuredFields.forEachIndexed { idx, field ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = field.key,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                                Text(
                                    text = field.value,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (idx < structuredFields.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            }
                        }
                    }
                }
            }

            // 5. NOTES
            if (doc.notes.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.loyalty_notes_label), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(doc.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }

    // Full-screen photo viewer
    if (enlargedPhotoUri != null) {
        Dialog(
            onDismissRequest = { enlargedPhotoUri = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.94f))
                    .clickable { enlargedPhotoUri = null }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                VaultImage(
                                    uriString = enlargedPhotoUri,
                    contentDescription = "ID Page",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    // Mandatory Sensitive-Document Share Confirmation Dialog
    if (pendingSharePages != null) {
        val targetPages = pendingSharePages!!
        AlertDialog(
            onDismissRequest = { pendingSharePages = null },
            title = { Text(stringResource(R.string.my_ids_share_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.my_ids_share_confirm_msg)) },
            confirmButton = {
                Button(onClick = {
                    pendingSharePages = null
                    scope.launch {
                        IdShareHelper.sharePages(context, doc.documentName, targetPages, selectedFormat, watermarkText = if (watermarkEnabled) watermarkText.trim().takeIf { it.isNotBlank() } else null)
                            .onFailure {
                                Toast.makeText(context, it.localizedMessage ?: "Share failed", Toast.LENGTH_SHORT).show()
                            }
                    }
                }) { Text(stringResource(R.string.my_ids_continue_share)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingSharePages = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.my_ids_delete_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.my_ids_delete_msg)) },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirm = false; onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
    }
}

@Composable
private fun SelectableSegmentButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
        modifier = modifier
            .heightIn(min = 42.dp)
            .semantics { selected = isSelected }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelected) {
                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text = label,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
@Composable
private fun IdDocumentCameraCaptureDialog(
    pageLabel: String,
    onCaptured: (Bitmap) -> Unit,
    onPickedGalleryUri: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPerm = granted
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) onPickedGalleryUri(uri)
    }
    LaunchedEffect(Unit) {
        if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA)
    }

    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val zoomState = remember { CardLinkCameraZoomState() }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { runCatching { cameraRef?.cameraControl?.enableTorch(false) } }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply { this.attachTapToFocus(zoomState) }
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                                cameraRef = cam
                                hasFlash = cam.cameraInfo.hasFlashUnit()
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                val accent = MaterialTheme.colorScheme.primary
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                ) {
                    val docW = size.width * 0.88f
                    val docH = docW / 1.54f
                    val left = (size.width - docW) / 2f
                    val top = (size.height - docH) / 2.2f
                    drawRect(color = Color.Black.copy(alpha = 0.55f))
                    drawRoundRect(color = Color.Transparent, topLeft = Offset(left, top), size = Size(docW, docH), cornerRadius = CornerRadius(22f, 22f), blendMode = BlendMode.Clear)
                    drawRoundRect(color = accent, topLeft = Offset(left, top), size = Size(docW, docH), cornerRadius = CornerRadius(22f, 22f), style = Stroke(width = 5f))
                }

                if (zoomState.currentZoomRatio >= 2.5f) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.Black.copy(alpha = 0.72f),
                        modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.my_ids_zoom_corners_hint),
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 104.dp)
                )

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.qr_gallery), fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (isCapturing) return@Button
                            isCapturing = true
                            imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                                override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                    val bmp = imageProxy.toUprightIdBitmap()
                                    imageProxy.close()
                                    isCapturing = false
                                    if (bmp != null) onCaptured(bmp)
                                    else Toast.makeText(context, "Could not capture document photo.", Toast.LENGTH_SHORT).show()
                                }
                                override fun onError(exc: ImageCaptureException) {
                                    isCapturing = false
                                    Toast.makeText(context, "Camera capture failed — try Gallery instead.", Toast.LENGTH_SHORT).show()
                                }
                            })
                        },
                        enabled = !isCapturing,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp)
                    ) {
                        if (isCapturing) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(26.dp), strokeWidth = 2.5.dp)
                        else Icon(Icons.Default.PhotoCamera, contentDescription = stringResource(R.string.my_ids_take_photo), modifier = Modifier.size(28.dp))
                    }

                    if (hasFlash) {
                        IconButton(
                            onClick = {
                                torchOn = !torchOn
                                runCatching { cameraRef?.cameraControl?.enableTorch(torchOn) }
                            },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.16f), CircleShape)
                        ) {
                            Icon(if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff, contentDescription = stringResource(R.string.scanner_flashlight), tint = Color.White)
                        }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                }
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                    OutlinedButton(
                        onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) { Text(stringResource(R.string.loyalty_pick_from_gallery_btn)) }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.65f)) {
                    Text(
                        text = pageLabel,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White)
                }
            }
        }
    }
}
