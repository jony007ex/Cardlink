package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.room.withTransaction
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.widget.CardLinkWidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class BackupSelectionOptions(
    val isComplete: Boolean = true,
    val includeMyCards: Boolean = true,
    val includeContacts: Boolean = true,
    val includeFollowUps: Boolean = true,
    val includeLoyaltyCards: Boolean = true,
    val includeMyIds: Boolean = true,
    val includeAssets: Boolean = true,
    val includePreferences: Boolean = true
)

data class BackupPreCreationSummary(
    val myCardsCount: Int,
    val contactsCount: Int,
    val followUpsCount: Int,
    val loyaltyCardsCount: Int,
    val myIdsCount: Int,
    val assetsCount: Int,
    val estimatedSizeBytes: Long,
    val hasEnoughStorage: Boolean
)

@Serializable
data class CardLinkPackageManifest(
    val backupFormatVersion: Int = 3,
    val dbSchemaVersion: Int = 9,
    val appVersionName: String = "7.0.0",
    val appVersionCode: Long = 23L,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val isCompleteBackup: Boolean = true,
    val isEncrypted: Boolean = false,
    val myCardsCount: Int = 0,
    val contactsCount: Int = 0,
    val followUpsCount: Int = 0,
    val loyaltyCardsCount: Int = 0,
    val myIdsCount: Int = 0,
    val qrProjectsCount: Int = 0,
    val assetsCount: Int = 0,
    val payloadSha256: String = "",
    val assetChecksums: Map<String, String> = emptyMap()
)

@Serializable
data class CardLinkPackagePreferences(
    val languageCode: String = LanguageManager.LANG_ENGLISH,
    val darkThemeMode: String = "SYSTEM",
    val notificationsEnabled: Boolean = true,
    val biometricLockEnabled: Boolean = false,
    val appThemeConfig: AppCustomThemeConfig = AppCustomThemeConfig(),
    val eventMode: EventModeConfig = EventModeConfig(),
    val reminderIntervalDays: Int = 30,
    val favoriteToolIds: List<String> = emptyList(),
    val favoriteCardTemplateIds: List<String> = emptyList()
)

@Serializable
data class CardLinkPackagePayload(
    val myCards: List<BusinessCardEntity> = emptyList(),
    val savedContacts: List<SavedContactEntity> = emptyList(),
    val followUps: List<FollowUpEntity> = emptyList(),
    val loyaltyCards: List<LoyaltyCardEntity> = emptyList(),
    val idDocuments: List<IdDocumentEntity> = emptyList(),
    val idPages: List<IdDocumentPageEntity> = emptyList(),
    val qrProjects: List<QrProjectEntity> = emptyList(),
    val qrDesignPresets: List<QrDesignPresetEntity> = emptyList(),
    val secureNotes: List<SecureNoteEntity> = emptyList(),
    val nfcProjects: List<NfcProjectEntity> = emptyList(),
    val conferenceQueue: List<ConferenceQueueEntity> = emptyList(),
    val pendingDrafts: List<PendingDraftEntity> = emptyList(),
    val preferences: CardLinkPackagePreferences? = null,
    val assetBindings: Map<String, String> = emptyMap()
)

enum class BackupVerificationState {
    VERIFIED,
    INCOMPLETE,
    CORRUPTED,
    WRONG_PASSWORD,
    UNSUPPORTED_VERSION
}

enum class RestoreConflictPolicy {
    KEEP_EXISTING,
    USE_BACKUP,
    KEEP_BOTH
}

data class BackupInspectionResult(
    val isLegacyJson: Boolean,
    val createdAtTimestamp: Long,
    val appVersionName: String,
    val backupFormatVersion: Int,
    val isEncrypted: Boolean,
    val myCardsCount: Int,
    val contactsCount: Int,
    val followUpsCount: Int,
    val loyaltyCardsCount: Int,
    val myIdsCount: Int,
    val assetsCount: Int,
    val verificationState: BackupVerificationState,
    val detailMessage: String
)

data class DetailedRestoreResult(
    val myCardsRestored: Int = 0,
    val contactsRestored: Int = 0,
    val followUpsRestored: Int = 0,
    val loyaltyCardsRestored: Int = 0,
    val myIdsRestored: Int = 0,
    val qrProjectsRestored: Int = 0,
    val assetsRestored: Int = 0,
    val conflictsResolved: Int = 0,
    val skipped: Int = 0
)

object CardLinkBackupPackageManager {

    const val CURRENT_FORMAT_VERSION = 3
    private val CRYPTO_MAGIC = byteArrayOf('C'.code.toByte(), 'L'.code.toByte(), 'K'.code.toByte(), '3'.code.toByte())
    private const val PBKDF2_ITERATIONS = 210_000
    private val secureRandom = SecureRandom()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }

    suspend fun computeBackupSummary(
        context: Context,
        options: BackupSelectionOptions
    ): BackupPreCreationSummary = withContext(Dispatchers.IO) {
        val dao = CardLinkDatabase.getDatabase(context).dao()
        val cards = if (options.isComplete || options.includeMyCards) dao.getAllMyCardsSnapshot() else emptyList()
        val contacts = if (options.isComplete || options.includeContacts) dao.getAllContactsSnapshot() else emptyList()
        val followUps = if (options.isComplete || options.includeFollowUps) dao.getAllFollowUpsSnapshot() else emptyList()
        val loyalty = if (options.isComplete || options.includeLoyaltyCards) dao.getAllLoyaltyCardsSnapshot() else emptyList()
        val idDocs = if (options.isComplete || options.includeMyIds) dao.getAllIdDocumentsSnapshot() else emptyList()
        val idPages = if (options.isComplete || options.includeMyIds) dao.getAllIdPagesSnapshot() else emptyList()
        val qrProjects = if (options.isComplete) dao.getAllQrProjectsSnapshot() else emptyList()

        val assetFiles = if (options.isComplete || options.includeAssets) {
            collectAssetFiles(cards, contacts, loyalty, idPages, qrProjects, conferenceQueue).values.distinct()
        } else emptyList()

        val assetsBytes = assetFiles.sumOf { it.length() }
        val jsonEstimate = (cards.size * 800L + contacts.size * 600L + followUps.size * 400L + loyalty.size * 500L + idDocs.size * 700L + 4096L)
        val estimatedTotal = assetsBytes + jsonEstimate
        val availBytes = runCatching { StatFs(context.cacheDir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        // Require at least 2x estimated size + 8 MB safety margin
        val enough = availBytes > (estimatedTotal * 2L + 8L * 1024L * 1024L)

        BackupPreCreationSummary(
            myCardsCount = cards.size,
            contactsCount = contacts.size,
            followUpsCount = followUps.size,
            loyaltyCardsCount = loyalty.size,
            myIdsCount = idDocs.size,
            assetsCount = assetFiles.size,
            estimatedSizeBytes = estimatedTotal,
            hasEnoughStorage = enough
        )
    }

    suspend fun createBackupPackageToUri(
        context: Context,
        destinationUri: Uri,
        fileName: String,
        options: BackupSelectionOptions,
        passwordChars: CharArray?,
        onStage: (String) -> Unit = {}
    ): Result<RecentBackupEntry> = withContext(Dispatchers.IO) {
        runCatching {
            val summary = computeBackupSummary(context, options)
            if (!summary.hasEnoughStorage) {
                error("Not Enough Storage: CardLink needs additional free space to prepare this backup.")
            }

            onStage("Collecting data…")
            val tempFile = File(context.cacheDir, "pkg_build_${System.currentTimeMillis()}.cardlink")
            try {
                val manifest = writePackageToFile(context, tempFile, options, passwordChars, onStage)

                onStage("Verifying backup…")
                val verifyResult = inspectPackageFile(tempFile, passwordChars)
                if (verifyResult.verificationState != BackupVerificationState.VERIFIED) {
                    error("Backup integrity check failed: ${verifyResult.detailMessage}")
                }

                context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                    FileInputStream(tempFile).use { it.copyTo(out) }
                    out.flush()
                } ?: error("Could not write backup file to the chosen destination.")

                val entry = RecentBackupEntry(
                    fileName = fileName,
                    uriString = destinationUri.toString(),
                    createdAtTimestamp = manifest.createdAtTimestamp,
                    sizeBytes = tempFile.length(),
                    isCompleteBackup = options.isComplete,
                    isEncrypted = manifest.isEncrypted,
                    verified = true
                )
                val totalRecs = manifest.myCardsCount + manifest.contactsCount + manifest.followUpsCount + manifest.loyaltyCardsCount + manifest.myIdsCount
                BackupCenterPrefs.recordSuccessfulBackup(context, entry, totalRecs)
                entry
            } finally {
                if (tempFile.exists()) tempFile.delete()
                passwordChars?.fill('\u0000')
            }
        }
    }

    private suspend fun writePackageToFile(
        context: Context,
        targetFile: File,
        options: BackupSelectionOptions,
        passwordChars: CharArray?,
        onStage: (String) -> Unit
    ): CardLinkPackageManifest {
        val db = CardLinkDatabase.getDatabase(context)
        val dao = db.dao()

        val cards = if (options.isComplete || options.includeMyCards) dao.getAllMyCardsSnapshot() else emptyList()
        val contacts = if (options.isComplete || options.includeContacts) dao.getAllContactsSnapshot() else emptyList()
        val followUps = if (options.isComplete || options.includeFollowUps) dao.getAllFollowUpsSnapshot() else emptyList()
        val loyalty = if (options.isComplete || options.includeLoyaltyCards) dao.getAllLoyaltyCardsSnapshot() else emptyList()
        val idDocs = if (options.isComplete || options.includeMyIds) dao.getAllIdDocumentsSnapshot() else emptyList()
        val idPages = if (options.isComplete || options.includeMyIds) dao.getAllIdPagesSnapshot() else emptyList()
        val qrProjects = if (options.isComplete) dao.getAllQrProjectsSnapshot() else emptyList()
        val qrPresets = if (options.isComplete) dao.getAllQrDesignPresetsSnapshot() else emptyList()
        val secureNotes = if (options.isComplete) dao.getAllSecureNotesSnapshot() else emptyList()
        val nfcProjects = if (options.isComplete) dao.getAllNfcProjectsSnapshot() else emptyList()
        val conferenceQueue = if (options.isComplete) dao.getAllConferenceQueueSnapshot() else emptyList()
        val pendingDrafts = if (options.isComplete) dao.getAllPendingDraftsSnapshot() else emptyList()

        val prefs = if (options.isComplete || options.includePreferences) {
            CardLinkPackagePreferences(
                languageCode = LanguageManager.getSavedLanguage(context),
                darkThemeMode = when (LanguageManager.getSavedThemeOverride(context)) {
                    false -> "LIGHT"
                    true -> "DARK"
                    null -> "SYSTEM"
                },
                notificationsEnabled = LanguageManager.isNotificationsEnabled(context),
                biometricLockEnabled = BiometricLockHelper.isLockEnabled(context),
                appThemeConfig = ThemeContrastHelper.loadAppTheme(context),
                eventMode = EventModeHelper.load(context),
                reminderIntervalDays = BackupCenterPrefs.getReminderIntervalDays(context),
                favoriteToolIds = UxExperiencePrefs.getFavoriteToolIds(context),
                favoriteCardTemplateIds = CardTemplatePrefs.getFavoriteIds(context)
            )
        } else null

        onStage("Processing images…")
        val assetMap = if (options.isComplete || options.includeAssets) {
            collectAssetFiles(cards, contacts, loyalty, idPages, qrProjects, conferenceQueue)
        } else emptyMap()

        // Build relative asset keys (e.g. assets/img_0.jpg) -> original URI mapping
        val uriToRelPath = linkedMapOf<String, String>()
        val relPathToFile = linkedMapOf<String, File>()
        val assetChecksums = linkedMapOf<String, String>()
        var assetIdx = 0
        for ((uriStr, file) in assetMap) {
            val relPath = "assets/asset_${assetIdx++}_${file.name}"
            uriToRelPath[uriStr] = relPath
            relPathToFile[relPath] = file
            assetChecksums[relPath] = sha256(VaultCryptoManager.readDecryptedBytesFromFile(file) ?: file.readBytes())
        }

        val payload = CardLinkPackagePayload(
            myCards = cards,
            savedContacts = contacts,
            followUps = followUps,
            loyaltyCards = loyalty,
            idDocuments = idDocs,
            idPages = idPages,
            qrProjects = qrProjects,
            qrDesignPresets = qrPresets,
            secureNotes = secureNotes,
            nfcProjects = nfcProjects,
            conferenceQueue = conferenceQueue,
            pendingDrafts = pendingDrafts,
            preferences = prefs,
            assetBindings = uriToRelPath
        )

        onStage("Creating package…")
        val payloadBytes = json.encodeToString(payload).toByteArray(Charsets.UTF_8)
        val payloadHash = sha256(payloadBytes)
        val isEncrypted = passwordChars != null && passwordChars.isNotEmpty()

        val (verName, verCode) = readAppVersion(context)
        val manifest = CardLinkPackageManifest(
            backupFormatVersion = CURRENT_FORMAT_VERSION,
            dbSchemaVersion = 19,
            appVersionName = verName,
            appVersionCode = verCode,
            createdAtTimestamp = System.currentTimeMillis(),
            isCompleteBackup = options.isComplete,
            isEncrypted = isEncrypted,
            myCardsCount = cards.size,
            contactsCount = contacts.size,
            followUpsCount = followUps.size,
            loyaltyCardsCount = loyalty.size,
            myIdsCount = idDocs.size,
            qrProjectsCount = qrProjects.size,
            assetsCount = relPathToFile.size,
            payloadSha256 = payloadHash,
            assetChecksums = assetChecksums
        )

        ZipOutputStream(BufferedOutputStream(FileOutputStream(targetFile))).use { zos ->
            // 1. manifest.json (unencrypted metadata & hashes for safe inspection before restore)
            zos.putNextEntry(ZipEntry("manifest.json"))
            zos.write(json.encodeToString(manifest).toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            if (isEncrypted) {
                // Encrypt both payload & assets bundle so sensitive My IDs & photos are protected
                val encPayload = encryptAesGcm(payloadBytes, passwordChars!!)
                zos.putNextEntry(ZipEntry("payload.enc"))
                zos.write(encPayload)
                zos.closeEntry()

                val innerAssetsBytes = buildAssetsZipBytes(relPathToFile)
                val encAssets = encryptAesGcm(innerAssetsBytes, passwordChars)
                zos.putNextEntry(ZipEntry("assets.enc"))
                zos.write(encAssets)
                zos.closeEntry()
            } else {
                zos.putNextEntry(ZipEntry("payload.json"))
                zos.write(payloadBytes)
                zos.closeEntry()

                for ((relPath, file) in relPathToFile) {
                    zos.putNextEntry(ZipEntry(relPath))
                    val plainBytes = VaultCryptoManager.readDecryptedBytesFromFile(file) ?: file.readBytes()
                    zos.write(plainBytes)
                    zos.closeEntry()
                }
            }
        }
        payloadBytes.fill(0)
        return manifest
    }

    suspend fun inspectBackupUri(
        context: Context,
        sourceUri: Uri,
        passwordChars: CharArray? = null
    ): BackupInspectionResult = withContext(Dispatchers.IO) {
        val tempFile = File(context.cacheDir, "inspect_${System.currentTimeMillis()}.tmp")
        try {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(tempFile).use { input.copyTo(it) }
            } ?: return@withContext corruptedResult("Unable to read selected backup file.")
            inspectPackageFile(tempFile, passwordChars)
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    private fun inspectPackageFile(file: File, passwordChars: CharArray?): BackupInspectionResult {
        if (!file.exists() || file.length() < 4) return corruptedResult("Backup file is empty or unreadable.")

        // Check ZIP magic bytes vs Legacy JSON
        val header = ByteArray(4)
        FileInputStream(file).use { it.read(header) }
        val isZip = header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()

        if (!isZip) {
            return inspectLegacyJsonFile(file)
        }

        val zipEntries = linkedMapOf<String, ByteArray>()
        val zipReadOk = runCatching {
            ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        zipEntries[entry.name] = zis.readBytes()
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }.isSuccess
        if (!zipReadOk) return corruptedResult("Archive structure is corrupted.")

        val manifestBytes = zipEntries["manifest.json"] ?: return corruptedResult("Missing manifest.json in backup package.")
        val manifest = runCatching {
            json.decodeFromString<CardLinkPackageManifest>(manifestBytes.toString(Charsets.UTF_8))
        }.getOrNull() ?: return corruptedResult("Backup manifest could not be parsed.")

        if (manifest.backupFormatVersion > CURRENT_FORMAT_VERSION || manifest.backupFormatVersion < 1) {
            return BackupInspectionResult(
                isLegacyJson = false,
                createdAtTimestamp = manifest.createdAtTimestamp,
                appVersionName = manifest.appVersionName,
                backupFormatVersion = manifest.backupFormatVersion,
                isEncrypted = manifest.isEncrypted,
                myCardsCount = manifest.myCardsCount,
                contactsCount = manifest.contactsCount,
                followUpsCount = manifest.followUpsCount,
                loyaltyCardsCount = manifest.loyaltyCardsCount,
                myIdsCount = manifest.myIdsCount,
                assetsCount = manifest.assetsCount,
                verificationState = BackupVerificationState.UNSUPPORTED_VERSION,
                detailMessage = "Unsupported Backup Version (v${manifest.backupFormatVersion}). Please update CardLink."
            )
        }

        var state = BackupVerificationState.VERIFIED
        var msg = "Verified"

        if (manifest.isEncrypted) {
            val encPayload = zipEntries["payload.enc"]
            if (encPayload == null) {
                state = BackupVerificationState.CORRUPTED
                msg = "Missing encrypted payload."
            } else if (passwordChars != null && passwordChars.isNotEmpty()) {
                val dec = runCatching { decryptAesGcm(encPayload, passwordChars) }.getOrNull()
                if (dec == null) {
                    state = BackupVerificationState.WRONG_PASSWORD
                    msg = "Incorrect password or corrupted encrypted backup."
                } else {
                    val hash = sha256(dec)
                    if (manifest.payloadSha256.isNotBlank() && !hash.equals(manifest.payloadSha256, true)) {
                        state = BackupVerificationState.CORRUPTED
                        msg = "SHA-256 checksum mismatch."
                    }
                    val encAssets = zipEntries["assets.enc"]
                    if (state == BackupVerificationState.VERIFIED && manifest.assetsCount > 0 && encAssets == null) {
                        state = BackupVerificationState.INCOMPLETE
                        msg = "Some assets are missing."
                    }
                }
            }
        } else {
            val plainPayload = zipEntries["payload.json"]
            if (plainPayload == null) {
                state = BackupVerificationState.CORRUPTED
                msg = "Missing payload.json."
            } else {
                val hash = sha256(plainPayload)
                if (manifest.payloadSha256.isNotBlank() && !hash.equals(manifest.payloadSha256, true)) {
                    state = BackupVerificationState.CORRUPTED
                    msg = "SHA-256 integrity mismatch."
                } else {
                    var missingAssets = 0
                    for ((relPath, expectedSha) in manifest.assetChecksums) {
                        val b = zipEntries[relPath]
                        if (b == null) missingAssets++
                        else if (!sha256(b).equals(expectedSha, true)) {
                            state = BackupVerificationState.CORRUPTED
                            msg = "Corrupted asset detected ($relPath)."
                            break
                        }
                    }
                    if (state == BackupVerificationState.VERIFIED && missingAssets > 0) {
                        state = BackupVerificationState.INCOMPLETE
                        msg = "$missingAssets asset file(s) missing from backup."
                    }
                }
            }
        }

        return BackupInspectionResult(
            isLegacyJson = false,
            createdAtTimestamp = manifest.createdAtTimestamp,
            appVersionName = manifest.appVersionName,
            backupFormatVersion = manifest.backupFormatVersion,
            isEncrypted = manifest.isEncrypted,
            myCardsCount = manifest.myCardsCount,
            contactsCount = manifest.contactsCount,
            followUpsCount = manifest.followUpsCount,
            loyaltyCardsCount = manifest.loyaltyCardsCount,
            myIdsCount = manifest.myIdsCount,
            assetsCount = manifest.assetsCount,
            verificationState = state,
            detailMessage = msg
        )
    }

    private fun inspectLegacyJsonFile(file: File): BackupInspectionResult {
        val raw = runCatching { file.readText(Charsets.UTF_8) }.getOrNull()
            ?: return corruptedResult("Could not read legacy JSON backup.")
        val legacy = runCatching { json.decodeFromString<CardLinkBackupPayload>(raw) }.getOrNull()
            ?: return corruptedResult("Not a valid CardLink backup or legacy JSON file.")

        return BackupInspectionResult(
            isLegacyJson = true,
            createdAtTimestamp = legacy.exportedAtTimestamp,
            appVersionName = "Legacy JSON",
            backupFormatVersion = legacy.schemaVersion,
            isEncrypted = false,
            myCardsCount = legacy.myCards.size,
            contactsCount = legacy.savedContacts.size,
            followUpsCount = 0,
            loyaltyCardsCount = legacy.loyaltyCards.size,
            myIdsCount = legacy.idDocuments.size,
            assetsCount = legacy.myCards.size + legacy.savedContacts.size + legacy.loyaltyCards.size + legacy.idDocuments.sumOf { it.pages.size },
            verificationState = BackupVerificationState.VERIFIED,
            detailMessage = "Legacy CardLink JSON backup (v${legacy.schemaVersion}) verified."
        )
    }

    suspend fun restoreBackupUri(
        context: Context,
        sourceUri: Uri,
        replaceExisting: Boolean,
        conflictPolicy: RestoreConflictPolicy,
        passwordChars: CharArray?,
        onStage: (String) -> Unit = {}
    ): Result<DetailedRestoreResult> = withContext(Dispatchers.IO) {
        runCatching {
            onStage("Validating backup…")
            val tempFile = File(context.cacheDir, "restore_in_${System.currentTimeMillis()}.tmp")
            try {
                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    FileOutputStream(tempFile).use { input.copyTo(it) }
                } ?: error("Unable to open selected backup file.")

                val inspection = inspectPackageFile(tempFile, passwordChars)
                when (inspection.verificationState) {
                    BackupVerificationState.WRONG_PASSWORD -> error("Incorrect backup password.")
                    BackupVerificationState.CORRUPTED -> error("Backup is corrupted: ${inspection.detailMessage}")
                    BackupVerificationState.UNSUPPORTED_VERSION -> error(inspection.detailMessage)
                    else -> Unit
                }

                // Create Pre-Restore Safety Snapshot so user can Undo Restore if needed
                onStage("Creating safety snapshot…")
                val recDir = File(context.filesDir, "recovery_snapshots").apply { if (!exists()) mkdirs() }
                val snapshotFile = File(recDir, "Pre_Restore_Snapshot.cardlink")
                runCatching {
                    writePackageToFile(context, snapshotFile, BackupSelectionOptions(isComplete = true), null) {}
                    BackupCenterPrefs.savePreRestoreSnapshotPath(context, snapshotFile.absolutePath)
                }

                if (inspection.isLegacyJson) {
                    restoreLegacyJsonInternal(context, tempFile, replaceExisting, conflictPolicy, onStage)
                } else {
                    restoreCardLinkPackageInternal(context, tempFile, replaceExisting, conflictPolicy, passwordChars, onStage)
                }
            } finally {
                if (tempFile.exists()) tempFile.delete()
                passwordChars?.fill('\u0000')
            }
        }
    }

    suspend fun undoLastRestore(
        context: Context,
        onStage: (String) -> Unit = {}
    ): Result<DetailedRestoreResult> = withContext(Dispatchers.IO) {
        runCatching {
            val path = BackupCenterPrefs.getPreRestoreSnapshotPath(context)
                ?: error("No pre-restore safety snapshot is available.")
            val file = File(path)
            if (!file.exists()) error("Pre-restore safety snapshot is no longer available.")
            val res = restoreCardLinkPackageInternal(
                context = context,
                pkgFile = file,
                replaceExisting = true,
                conflictPolicy = RestoreConflictPolicy.USE_BACKUP,
                passwordChars = null,
                onStage = onStage
            )
            BackupCenterPrefs.savePreRestoreSnapshotPath(context, null)
            file.delete()
            res
        }
    }

    private suspend fun restoreCardLinkPackageInternal(
        context: Context,
        pkgFile: File,
        replaceExisting: Boolean,
        conflictPolicy: RestoreConflictPolicy,
        passwordChars: CharArray?,
        onStage: (String) -> Unit
    ): DetailedRestoreResult {
        val zipEntries = linkedMapOf<String, ByteArray>()
        ZipInputStream(BufferedInputStream(FileInputStream(pkgFile))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) zipEntries[entry.name] = zis.readBytes()
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        val manifest = json.decodeFromString<CardLinkPackageManifest>(
            (zipEntries["manifest.json"] ?: error("Missing manifest.json")).toString(Charsets.UTF_8)
        )
        val payloadBytes = if (manifest.isEncrypted) {
            val pwd = passwordChars ?: error("Password is required for this encrypted backup.")
            decryptAesGcm(zipEntries["payload.enc"] ?: error("Missing payload.enc"), pwd)
        } else {
            zipEntries["payload.json"] ?: error("Missing payload.json")
        }

        val payload = json.decodeFromString<CardLinkPackagePayload>(payloadBytes.toString(Charsets.UTF_8))
        payloadBytes.fill(0)

        // Extract assets into durable local folders and remap old URI -> new durable file URI
        onStage("Restoring images…")
        val assetBytesByRelPath = linkedMapOf<String, ByteArray>()
        if (manifest.isEncrypted) {
            val encAssets = zipEntries["assets.enc"]
            if (encAssets != null && passwordChars != null) {
                val decZip = decryptAesGcm(encAssets, passwordChars)
                ZipInputStream(ByteArrayInputStream(decZip)).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) assetBytesByRelPath[e.name] = zis.readBytes()
                        zis.closeEntry()
                        e = zis.nextEntry
                    }
                }
            }
        } else {
            for ((name, bytes) in zipEntries) {
                if (name.startsWith("assets/")) assetBytesByRelPath[name] = bytes
            }
        }

        val oldUriToNewUri = mutableMapOf<String, String>()
        var restoredAssetsCount = 0
        for ((oldUri, relPath) in payload.assetBindings) {
            val bytes = assetBytesByRelPath[relPath] ?: continue
            val subFolder = when {
                oldUri.contains("loyalty_cards") -> "loyalty_cards"
                oldUri.contains("my_ids") -> "my_ids"
                oldUri.contains("scanned_cards") -> "scanned_cards"
                oldUri.contains("qr_logos") -> "qr_logos"
                else -> "profile_assets"
            }
            oldUriToNewUri[oldUri] = if (subFolder == "loyalty_cards" || subFolder == "my_ids") {
                VaultCryptoManager.saveEncryptedBytes(context, bytes, subFolder, "rest_${restoredAssetsCount}")
            } else {
                val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
                val outFile = File(dir, "rest_${System.currentTimeMillis()}_${restoredAssetsCount}_${File(relPath).name}")
                outFile.writeBytes(bytes)
                Uri.fromFile(outFile).toString()
            }
            restoredAssetsCount++
        }

        fun remap(uri: String?): String? = uri?.let { oldUriToNewUri[it] ?: it }

        val remappedCards = payload.myCards.map { it.copy(profilePhotoUri = remap(it.profilePhotoUri), companyLogoUri = remap(it.companyLogoUri)) }
        val remappedContacts = payload.savedContacts.map {
            it.copy(
                profilePhotoUri = remap(it.profilePhotoUri),
                backPhotoUri = remap(it.backPhotoUri),
                frontOriginalPhotoUri = remap(it.frontOriginalPhotoUri),
                backOriginalPhotoUri = remap(it.backOriginalPhotoUri)
            )
        }
        val remappedConferenceQueue = payload.conferenceQueue.map {
            it.copy(
                encryptedFrontUri = remap(it.encryptedFrontUri) ?: it.encryptedFrontUri,
                encryptedBackUri = remap(it.encryptedBackUri)
            )
        }
        val remappedLoyalty = payload.loyaltyCards.map { it.copy(frontPhotoUri = remap(it.frontPhotoUri), backPhotoUri = remap(it.backPhotoUri)) }
        val remappedIdPages = payload.idPages.map { it.copy(imageUri = remap(it.imageUri) ?: it.imageUri) }
        val remappedQrProjects = payload.qrProjects.map { it.copy(logoUri = remap(it.logoUri)) }

        val db = CardLinkDatabase.getDatabase(context)
        val dao = db.dao()

        var cardsAdded = 0
        var contactsAdded = 0
        var followUpsAdded = 0
        var loyaltyAdded = 0
        var idsAdded = 0
        var qrProjectsAdded = 0
        var conflicts = 0
        var skipped = 0

        val existingFollowUpsBefore = dao.getAllFollowUpsSnapshot()
        val existingIdsBefore = dao.getAllIdDocumentsSnapshot()
        if (replaceExisting) {
            existingFollowUpsBefore.forEach { FollowUpScheduler.cancelForItem(context, it.id) }
            existingIdsBefore.forEach { IdExpiryReminderScheduler.cancelForDocument(context, it.stableUuid) }
        }

        db.withTransaction {
            if (replaceExisting) {
                if (remappedCards.isNotEmpty() || manifest.isCompleteBackup) dao.clearAllMyCards()
                if (remappedContacts.isNotEmpty() || manifest.isCompleteBackup) dao.clearAllContacts()
                if (payload.followUps.isNotEmpty() || manifest.isCompleteBackup) dao.clearAllFollowUps()
                if (remappedLoyalty.isNotEmpty() || manifest.isCompleteBackup) dao.clearAllLoyaltyCards()
                if (payload.idDocuments.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllIdPages()
                    dao.clearAllIdDocuments()
                }
                if (remappedQrProjects.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllQrProjects()
                }
                if (payload.qrDesignPresets.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllQrDesignPresets()
                }
                if (payload.secureNotes.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllSecureNotes()
                }
                if (payload.nfcProjects.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllNfcProjects()
                }
                if (remappedConferenceQueue.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllConferenceQueue()
                }
                if (payload.pendingDrafts.isNotEmpty() || manifest.isCompleteBackup) {
                    dao.clearAllPendingDrafts()
                }
            }

            onStage("Restoring contacts…")
            val curCards = dao.getAllMyCardsSnapshot()
            for (c in remappedCards) {
                val dup = curCards.firstOrNull {
                    it.profileTitle.equals(c.profileTitle, true) && it.fullName.equals(c.fullName, true)
                }
                if (dup == null) {
                    dao.upsertMyCard(c.copy(id = 0L)); cardsAdded++
                } else {
                    conflicts++
                    when (conflictPolicy) {
                        RestoreConflictPolicy.KEEP_EXISTING -> skipped++
                        RestoreConflictPolicy.USE_BACKUP -> { dao.upsertMyCard(c.copy(id = dup.id)); cardsAdded++ }
                        RestoreConflictPolicy.KEEP_BOTH -> { dao.upsertMyCard(c.copy(id = 0L)); cardsAdded++ }
                    }
                }
            }

            val curContacts = dao.getAllContactsSnapshot()
            for (ct in remappedContacts) {
                val dup = curContacts.firstOrNull { ex ->
                    val p1 = ex.phone.filter { it.isDigit() }.takeLast(8)
                    val p2 = ct.phone.filter { it.isDigit() }.takeLast(8)
                    (p1.length >= 6 && p1 == p2) ||
                        (ex.email.isNotBlank() && ex.email.equals(ct.email, true) && ex.fullName.equals(ct.fullName, true))
                }
                if (dup == null) {
                    dao.upsertContact(ct.copy(id = 0L)); contactsAdded++
                } else {
                    conflicts++
                    when (conflictPolicy) {
                        RestoreConflictPolicy.KEEP_EXISTING -> skipped++
                        RestoreConflictPolicy.USE_BACKUP -> { dao.upsertContact(ct.copy(id = dup.id)); contactsAdded++ }
                        RestoreConflictPolicy.KEEP_BOTH -> { dao.upsertContact(ct.copy(id = 0L)); contactsAdded++ }
                    }
                }
            }

            val curFollowUps = dao.getAllFollowUpsSnapshot()
            for (fu in payload.followUps) {
                val dup = curFollowUps.firstOrNull { it.title == fu.title && it.dueAtTimestamp == fu.dueAtTimestamp && it.contactName == fu.contactName }
                if (dup == null) {
                    dao.upsertFollowUp(fu.copy(id = 0L)); followUpsAdded++
                } else skipped++
            }

            onStage("Restoring Loyalty Cards…")
            val curLoyalty = dao.getAllLoyaltyCardsSnapshot()
            for (lc in remappedLoyalty) {
                val dup = curLoyalty.firstOrNull { it.stableUuid == lc.stableUuid }
                if (dup == null) {
                    dao.upsertLoyaltyCard(lc.copy(id = 0L)); loyaltyAdded++
                } else {
                    conflicts++
                    when (conflictPolicy) {
                        RestoreConflictPolicy.KEEP_EXISTING -> skipped++
                        RestoreConflictPolicy.USE_BACKUP -> { dao.upsertLoyaltyCard(lc.copy(id = dup.id)); loyaltyAdded++ }
                        RestoreConflictPolicy.KEEP_BOTH -> { dao.upsertLoyaltyCard(lc.copy(id = 0L, stableUuid = java.util.UUID.randomUUID().toString())); loyaltyAdded++ }
                    }
                }
            }

            onStage("Restoring My IDs…")
            val curIds = dao.getAllIdDocumentsSnapshot()
            val pagesByUuid = remappedIdPages.groupBy { it.documentUuid }
            for (doc in payload.idDocuments) {
                val dup = curIds.firstOrNull { it.stableUuid == doc.stableUuid }
                val docPages = pagesByUuid[doc.stableUuid].orEmpty()
                if (dup == null) {
                    dao.upsertIdDocument(doc.copy(id = 0L))
                    if (docPages.isNotEmpty()) dao.insertIdPagesBatch(docPages.map { it.copy(id = 0L) })
                    idsAdded++
                } else {
                    conflicts++
                    when (conflictPolicy) {
                        RestoreConflictPolicy.KEEP_EXISTING -> skipped++
                        RestoreConflictPolicy.USE_BACKUP -> {
                            dao.upsertIdDocument(doc.copy(id = dup.id))
                            dao.deletePagesForDocument(doc.stableUuid)
                            if (docPages.isNotEmpty()) dao.insertIdPagesBatch(docPages.map { it.copy(id = 0L) })
                            idsAdded++
                        }
                        RestoreConflictPolicy.KEEP_BOTH -> {
                            val newUuid = java.util.UUID.randomUUID().toString()
                            dao.upsertIdDocument(doc.copy(id = 0L, stableUuid = newUuid))
                            if (docPages.isNotEmpty()) dao.insertIdPagesBatch(docPages.map { it.copy(id = 0L, documentUuid = newUuid) })
                            idsAdded++
                        }
                    }
                }
            }

            val curQrProjects = dao.getAllQrProjectsSnapshot()
            for (qp in remappedQrProjects) {
                val dup = curQrProjects.firstOrNull { it.stableUuid == qp.stableUuid }
                if (dup == null) {
                    dao.upsertQrProject(qp.copy(id = 0L)); qrProjectsAdded++
                } else {
                    conflicts++
                    when (conflictPolicy) {
                        RestoreConflictPolicy.KEEP_EXISTING -> skipped++
                        RestoreConflictPolicy.USE_BACKUP -> { dao.upsertQrProject(qp.copy(id = dup.id)); qrProjectsAdded++ }
                        RestoreConflictPolicy.KEEP_BOTH -> { dao.upsertQrProject(qp.copy(id = 0L, stableUuid = java.util.UUID.randomUUID().toString())); qrProjectsAdded++ }
                    }
                }
            }

            val curPresets = dao.getAllQrDesignPresetsSnapshot()
            val existingPresetUuids = curPresets.map { it.stableUuid }.toSet()
            val newPresets = payload.qrDesignPresets.filterNot { it.stableUuid in existingPresetUuids }.map { it.copy(id = 0L) }
            if (newPresets.isNotEmpty()) dao.insertQrDesignPresetsBatch(newPresets)

            val existingNotes = dao.getAllSecureNotesSnapshot().map { it.stableUuid }.toSet()
            payload.secureNotes.filterNot { it.stableUuid in existingNotes }.forEach { dao.upsertSecureNote(it.copy(id = 0L)) }

            val existingNfc = dao.getAllNfcProjectsSnapshot().map { it.stableUuid }.toSet()
            payload.nfcProjects.filterNot { it.stableUuid in existingNfc }.forEach { dao.upsertNfcProject(it.copy(id = 0L)) }

            val existingQueue = dao.getAllConferenceQueueSnapshot().map { it.stableUuid }.toSet()
            remappedConferenceQueue.filterNot { it.stableUuid in existingQueue }.forEach { dao.upsertConferenceQueueItem(it.copy(id = 0L)) }

            val existingDrafts = dao.getAllPendingDraftsSnapshot().map { it.stableUuid }.toSet()
            payload.pendingDrafts.filterNot { it.stableUuid in existingDrafts }.forEach { dao.upsertPendingDraft(it.copy(id = 0L)) }
        }

        // Restore preferences if present
        payload.preferences?.let { p ->
            LanguageManager.saveLanguage(context, p.languageCode)
            LanguageManager.saveThemeOverride(context, when (p.darkThemeMode) { "LIGHT" -> false; "DARK" -> true; else -> null })
            LanguageManager.setNotificationsEnabled(context, p.notificationsEnabled)
            BiometricLockHelper.setLockEnabled(context, p.biometricLockEnabled)
            ThemeContrastHelper.saveAppTheme(context, p.appThemeConfig)
            EventModeHelper.save(context, p.eventMode)
            BackupCenterPrefs.setReminderIntervalDays(context, p.reminderIntervalDays)
            if (p.favoriteToolIds.isNotEmpty()) UxExperiencePrefs.setFavoriteToolIds(context, p.favoriteToolIds)
            if (p.favoriteCardTemplateIds.isNotEmpty()) CardTemplatePrefs.setFavoriteIds(context, p.favoriteCardTemplateIds)
        }

        onStage("Rebuilding reminders…")
        FollowUpScheduler.rescheduleAllPending(context)
        IdExpiryReminderScheduler.rescheduleAll(context)
        BackupReminderScheduler.scheduleNextReminder(context)
        BirthdayReminderScheduler.syncSchedule(context)

        onStage("Finalizing…")
        CardLinkWidgetUpdater.updateAllWidgets(context)

        return DetailedRestoreResult(
            myCardsRestored = cardsAdded,
            contactsRestored = contactsAdded,
            followUpsRestored = followUpsAdded,
            loyaltyCardsRestored = loyaltyAdded,
            myIdsRestored = idsAdded,
            qrProjectsRestored = qrProjectsAdded,
            assetsRestored = restoredAssetsCount,
            conflictsResolved = conflicts,
            skipped = skipped
        )
    }

    private suspend fun restoreLegacyJsonInternal(
        context: Context,
        jsonFile: File,
        replaceExisting: Boolean,
        conflictPolicy: RestoreConflictPolicy,
        onStage: (String) -> Unit
    ): DetailedRestoreResult {
        onStage("Restoring legacy JSON backup…")
        val bundle = CardLinkBackupManager.importFullBackupFromUri(context, Uri.fromFile(jsonFile)).getOrThrow()
        val db = CardLinkDatabase.getDatabase(context)
        val dao = db.dao()
        var skipped = 0
        var conflicts = 0
        var loyaltyAdded = 0
        var idsAdded = 0

        db.withTransaction {
            if (replaceExisting) {
                dao.clearAllMyCards()
                dao.clearAllContacts()
                dao.clearAllLoyaltyCards()
                dao.clearAllIdPages()
                dao.clearAllIdDocuments()
            }
            if (bundle.myCards.isNotEmpty()) dao.insertMyCardsBatch(bundle.myCards)
            if (bundle.contacts.isNotEmpty()) dao.insertContactsBatch(bundle.contacts)

            val curLoyalty = dao.getAllLoyaltyCardsSnapshot()
            for (lc in bundle.loyaltyCards) {
                val dup = curLoyalty.firstOrNull { it.stableUuid == lc.stableUuid }
                if (dup == null) { dao.upsertLoyaltyCard(lc.copy(id = 0L)); loyaltyAdded++ }
                else if (conflictPolicy == RestoreConflictPolicy.USE_BACKUP) { dao.upsertLoyaltyCard(lc.copy(id = dup.id)); loyaltyAdded++; conflicts++ }
                else { skipped++; conflicts++ }
            }

            val curIds = dao.getAllIdDocumentsSnapshot()
            for ((doc, pages) in bundle.idDocuments) {
                val dup = curIds.firstOrNull { it.stableUuid == doc.stableUuid }
                if (dup == null) {
                    dao.upsertIdDocument(doc.copy(id = 0L))
                    if (pages.isNotEmpty()) dao.insertIdPagesBatch(pages.map { it.copy(id = 0L) })
                    idsAdded++
                } else { skipped++; conflicts++ }
            }
        }

        onStage("Rebuilding reminders…")
        IdExpiryReminderScheduler.rescheduleAll(context)
        CardLinkWidgetUpdater.updateAllWidgets(context)

        return DetailedRestoreResult(
            myCardsRestored = bundle.myCards.size,
            contactsRestored = bundle.contacts.size,
            loyaltyCardsRestored = loyaltyAdded,
            myIdsRestored = idsAdded,
            conflictsResolved = conflicts,
            skipped = skipped
        )
    }

    private fun collectAssetFiles(
        cards: List<BusinessCardEntity>,
        contacts: List<SavedContactEntity>,
        loyalty: List<LoyaltyCardEntity>,
        idPages: List<IdDocumentPageEntity>,
        qrProjects: List<QrProjectEntity> = emptyList(),
        conferenceQueue: List<ConferenceQueueEntity> = emptyList()
    ): Map<String, File> {
        val result = linkedMapOf<String, File>()
        fun addUri(uriStr: String?) {
            if (uriStr.isNullOrBlank()) return
            val uri = Uri.parse(uriStr)
            if (uri.scheme == "file") {
                val f = File(uri.path ?: return)
                if (f.exists() && f.isFile) result[uriStr] = f
            }
        }
        cards.forEach { addUri(it.profilePhotoUri); addUri(it.companyLogoUri) }
        contacts.forEach {
            addUri(it.profilePhotoUri)
            addUri(it.backPhotoUri)
            addUri(it.frontOriginalPhotoUri)
            addUri(it.backOriginalPhotoUri)
        }
        conferenceQueue.forEach { addUri(it.encryptedFrontUri); addUri(it.encryptedBackUri) }
        loyalty.forEach { addUri(it.frontPhotoUri); addUri(it.backPhotoUri) }
        idPages.forEach { addUri(it.imageUri) }
        qrProjects.forEach { addUri(it.logoUri) }
        return result
    }

    private fun buildAssetsZipBytes(relPathToFile: Map<String, File>): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            for ((rel, file) in relPathToFile) {
                zos.putNextEntry(ZipEntry(rel))
                val plainBytes = VaultCryptoManager.readDecryptedBytesFromFile(file) ?: file.readBytes()
                zos.write(plainBytes)
                zos.closeEntry()
            }
        }
        return baos.toByteArray()
    }

    private fun encryptAesGcm(plain: ByteArray, password: CharArray): ByteArray {
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val iv = ByteArray(12).also { secureRandom.nextBytes(it) }
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ciphertext = cipher.doFinal(plain)
        val out = ByteArrayOutputStream(CRYPTO_MAGIC.size + 4 + 16 + 12 + ciphertext.size)
        DataOutputStream(out).use { dos ->
            dos.write(CRYPTO_MAGIC)
            dos.writeInt(1)
            dos.write(salt)
            dos.write(iv)
            dos.write(ciphertext)
        }
        return out.toByteArray()
    }

    private fun decryptAesGcm(encrypted: ByteArray, password: CharArray): ByteArray {
        val dis = DataInputStream(ByteArrayInputStream(encrypted))
        val magic = ByteArray(4).also { dis.readFully(it) }
        if (!magic.contentEquals(CRYPTO_MAGIC)) error("Invalid encrypted header.")
        val ver = dis.readInt()
        if (ver != 1) error("Unsupported crypto version.")
        val salt = ByteArray(16).also { dis.readFully(it) }
        val iv = ByteArray(12).also { dis.readFully(it) }
        val ciphertext = dis.readBytes()
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return try {
            cipher.doFinal(ciphertext)
        } catch (e: AEADBadTagException) {
            error("Incorrect backup password or corrupted file.")
        }
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, PBKDF2_ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(bytes, "AES")
    }

    private fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun readAppVersion(context: Context): Pair<String, Long> = runCatching {
        val pi = context.packageManager.getPackageInfo(context.packageName, 0)
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
        Pair(pi.versionName ?: "7.0.0", code)
    }.getOrDefault(Pair("7.0.0", 23L))

    private fun corruptedResult(msg: String) = BackupInspectionResult(
        isLegacyJson = false,
        createdAtTimestamp = 0L,
        appVersionName = "",
        backupFormatVersion = 0,
        isEncrypted = false,
        myCardsCount = 0,
        contactsCount = 0,
        followUpsCount = 0,
        loyaltyCardsCount = 0,
        myIdsCount = 0,
        assetsCount = 0,
        verificationState = BackupVerificationState.CORRUPTED,
        detailMessage = msg
    )
}
