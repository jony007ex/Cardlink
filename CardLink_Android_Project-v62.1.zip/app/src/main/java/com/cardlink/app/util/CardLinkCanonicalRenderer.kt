package com.cardlink.app.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import com.cardlink.app.data.model.BusinessCardEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Canonical Sharing Priority Order (Part E Sec 8 & Part M Sec 33):
 * QR Code -> Quick Share -> Nearby Swap -> NFC -> Contact / VCF
 */
enum class ShareMethodPriority(val orderIndex: Int, val id: String) {
    QR_CODE(0, "QR_CODE"),
    QUICK_SHARE(1, "QUICK_SHARE"),
    NEARBY_SWAP(2, "NEARBY_SWAP"),
    NFC(3, "NFC"),
    CONTACT_VCF(4, "CONTACT_VCF")
}

enum class SharePackageContentType {
    QR,
    VCF,
    DIGITAL_CARD_LINK,
    PNG,
    PDF,
    INTERACTIVE_HTML,
    NFC_NDEF,
    MESSAGE_TEXT
}

/**
 * Platform-neutral Share Package descriptor shared across Android Sharesheet & future iOS adapters.
 */
data class CanonicalSharePackage(
    val contentType: SharePackageContentType,
    val sharingProfile: SharingProfileType,
    val displayTitle: String,
    val primaryPayload: String,
    val includedFieldLabels: List<String>,
    val excludedFieldLabels: List<String>
)

enum class ExportCardSides {
    FRONT_ONLY,
    BACK_ONLY,
    FRONT_AND_BACK
}

enum class CombinedPngLayout {
    SEPARATE_IMAGES,
    COMBINED_SHEET
}

enum class ExportQualityTier(val widthPx: Int, val heightPx: Int) {
    STANDARD(1200, 720),
    HIGH_QUALITY(2100, 1260)
}

enum class PdfCardLayout {
    BUSINESS_CARD_SIZE,
    A4_PRINT_SHEET
}

/**
 * Canonical Business Card Rendering & Export Engine (Parts G, H, I, J, N, O).
 * Guarantees that My Card Preview, Share Preview, PNG, PDF, and Interactive HTML exports
 * reflect the exact active Business Card template, colors, geometry, photo, logo, credentials,
 * multiple phone numbers, and QR Back — never an outdated generic layout.
 */
object CardLinkCanonicalRenderer {

    private val renderCache: LruCache<String, Bitmap> by lazy {
        val maxKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        val cacheKb = (maxKb / 16).coerceIn(4096, 16384)
        object : LruCache<String, Bitmap>(cacheKb) {
            override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    /**
     * Deterministic cache identity invalidated automatically whenever profile data, template,
     * colors, photo, logo, credentials, phones, back-side text, side, or resolution changes.
     */
    fun computeRenderCacheKey(
        card: BusinessCardEntity,
        side: String,
        quality: ExportQualityTier
    ): String {
        val sig = listOf(
            card.id,
            card.selectedTemplateId,
            card.template.name,
            card.primaryColorHex,
            card.cardGradientEndHex,
            card.accentColorHex,
            card.textColorHex,
            card.fontFamilyName,
            card.cornerRadiusDp,
            card.fullName,
            card.credentialsJson,
            card.showCredentialsOnCard,
            card.shareCredentials,
            card.designation,
            card.companyName,
            card.department,
            card.phone,
            card.whatsapp,
            card.phoneNumbersJson,
            card.email,
            card.website,
            card.officeAddress,
            card.publicCardUrl,
            card.profilePhotoUri.orEmpty(),
            card.companyLogoUri.orEmpty(),
            card.backHeading,
            card.backMessage,
            card.bio,
            card.sharePhone,
            card.shareWhatsapp,
            card.shareEmail,
            card.shareAddress,
            card.shareSocials,
            side,
            quality.name
        ).joinToString("|")
        return "card_${sig.hashCode()}_${side}_${quality.widthPx}"
    }

    fun clearRenderCache() {
        renderCache.evictAll()
    }

    /**
     * Pure-JVM helper returning the canonical Share Package for privacy auditing & cross-platform adapters.
     */
    fun buildSharePackage(
        card: BusinessCardEntity,
        profile: SharingProfileType,
        contentType: SharePackageContentType
    ): CanonicalSharePackage {
        val projected = SharingProfileManager.applyProfile(card, profile)
        val privacyItems = IphoneNfcShareHelper.buildPrivacyPreviewItems(projected)
        val included = privacyItems.filter { it.isShared }.map { it.label }
        val excluded = privacyItems.filter { !it.isShared && it.hasValue }.map { it.label }
        val payload = when (contentType) {
            SharePackageContentType.VCF, SharePackageContentType.QR -> CardShareHelper.toVCardString(projected)
            SharePackageContentType.DIGITAL_CARD_LINK, SharePackageContentType.NFC_NDEF -> projected.resolveNfcShareUrl()
            SharePackageContentType.MESSAGE_TEXT -> CardShareHelper.buildTextSummary(projected)
            SharePackageContentType.INTERACTIVE_HTML -> buildInteractiveHtmlString(null, projected)
            else -> projected.fullName
        }
        return CanonicalSharePackage(
            contentType = contentType,
            sharingProfile = profile,
            displayTitle = BusinessCardProfileHelper.formatFullNameWithCredentials(projected, forSharing = true)
                .ifBlank { projected.fullName.ifBlank { "CardLink" } },
            primaryPayload = payload,
            includedFieldLabels = included,
            excludedFieldLabels = excluded
        )
    }

    // =========================================================================
    // CANONICAL FRONT & BACK BITMAP RENDERER (Matches BusinessCardView 1:1)
    // =========================================================================

    fun renderFrontBitmap(
        context: Context?,
        card: BusinessCardEntity,
        quality: ExportQualityTier = ExportQualityTier.STANDARD
    ): Bitmap {
        val key = computeRenderCacheKey(card, "FRONT", quality)
        renderCache.get(key)?.takeIf { !it.isRecycled }?.let { return it }

        val w = quality.widthPx
        val h = quality.heightPx
        val s = w / 1200f // Uniform layout scale relative to 1200x720 reference canvas
        val spec = CardTemplateRegistry.resolveForCard(card)

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val cornerR = (card.cornerRadiusDp * 2.4f) * s
        val cardRect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clipPath = Path().apply { addRoundRect(cardRect, cornerR, cornerR, Path.Direction.CW) }
        canvas.save()
        canvas.clipPath(clipPath)

        // 1. Background linear gradient (exact active card colors)
        val bgStart = card.primaryColorHex.toInt()
        val bgEnd = card.cardGradientEndHex.toInt()
        val accent = card.accentColorHex.toInt()
        val textCol = card.textColorHex.toInt()
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), bgStart, bgEnd, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(cardRect, bgPaint)

        // 2. Template Decoration Geometry (exact mirror of BusinessCardView.TemplateDecorationLayer)
        drawTemplateDecoration(canvas, w.toFloat(), h.toFloat(), s, spec.layoutStyle, accent)

        // 3. Typography matching card.fontFamilyName
        val tfBold = resolveTypeface(card.fontFamilyName, bold = true)
        val tfMed = resolveTypeface(card.fontFamilyName, bold = false)

        val padStart = (if (spec.layoutStyle == CardLayoutStyle.LEFT_ACCENT_BAR) 78f else 60f) * s
        val padEnd = 60f * s
        val padTop = (if (spec.layoutStyle == CardLayoutStyle.TOP_BAND) 76f else 58f) * s

        // 4. Optional Company Logo (top-right inside white rounded container)
        var headerRightLimit = w - padEnd
        val logoBmp = decodeOptionalLocalBitmap(context, card.companyLogoUri, (160 * s).toInt())
        if (logoBmp != null) {
            val logoBoxSize = 114f * s
            val logoLeft = w - padEnd - logoBoxSize
            val logoTop = padTop
            val logoRect = RectF(logoLeft, logoTop, logoLeft + logoBoxSize, logoTop + logoBoxSize)
            canvas.drawRoundRect(logoRect, 24f * s, 24f * s, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(236, 255, 255, 255) })
            val inset = 12f * s
            val dst = fitInsideRect(logoBmp.width, logoBmp.height, RectF(logoRect.left + inset, logoRect.top + inset, logoRect.right - inset, logoRect.bottom - inset))
            canvas.drawBitmap(logoBmp, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            logoBmp.recycle()
            headerRightLimit = logoLeft - 24f * s
        }

        // 5. Optional Profile Photo (clipped to template photoStyle)
        var textStartX = padStart
        var headerBottomY = padTop + 170f * s
        if (spec.photoStyle != CardPhotoStyle.NO_PHOTO) {
            val photoW = (if (spec.photoStyle == CardPhotoStyle.SOFT_RECT) 150f else 174f) * s
            val photoH = (if (spec.photoStyle == CardPhotoStyle.SOFT_RECT) 186f else 174f) * s
            val photoRect = RectF(padStart, padTop, padStart + photoW, padTop + photoH)
            val photoPath = Path().apply {
                when (spec.photoStyle) {
                    CardPhotoStyle.CIRCLE -> addOval(photoRect, Path.Direction.CW)
                    CardPhotoStyle.ROUNDED_SQUARE -> addRoundRect(photoRect, 38f * s, 38f * s, Path.Direction.CW)
                    CardPhotoStyle.SOFT_RECT -> addRoundRect(photoRect, 26f * s, 26f * s, Path.Direction.CW)
                    CardPhotoStyle.NO_PHOTO -> Unit
                }
            }
            val photoBmp = decodeOptionalLocalBitmap(context, card.profilePhotoUri, (260 * s).toInt())
            canvas.save()
            canvas.clipPath(photoPath)
            if (photoBmp != null) {
                val srcRect = centerCropSrcRect(photoBmp.width, photoBmp.height, photoW / photoH)
                canvas.drawBitmap(photoBmp, srcRect, photoRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                photoBmp.recycle()
            } else {
                canvas.drawRect(photoRect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(accent, 42) })
                val initials = card.fullName.trim().take(2).uppercase().ifBlank { "CL" }
                val initPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = accent
                    textSize = 54f * s
                    typeface = tfBold
                    textAlign = Paint.Align.CENTER
                }
                val fm = initPaint.fontMetrics
                val cy = photoRect.centerY() - (fm.ascent + fm.descent) / 2f
                canvas.drawText(initials, photoRect.centerX(), cy, initPaint)
            }
            canvas.restore()
            canvas.drawPath(photoPath, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accent
                style = Paint.Style.STROKE
                strokeWidth = 4.5f * s
            })
            textStartX = photoRect.right + 34f * s
            headerBottomY = maxOf(headerBottomY, photoRect.bottom)
        }

        // 6. Name + Subordinate Professional Credentials (~74% size) + Designation + Org
        val headerAvailW = (headerRightLimit - textStartX).coerceAtLeast(240f * s)
        val displayName = card.fullName.trim().ifBlank { "Your Name" }
        val credSuffix = BusinessCardProfileHelper.formatCredentialsSuffix(card, forSharing = false)
        val nameSize = (if (displayName.length > 26) 50f else 56f) * s
        val credSize = nameSize * 0.74f

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textCol; textSize = nameSize; typeface = tfBold }
        val credPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(textCol, 215); textSize = credSize; typeface = tfMed }
        val rolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 36f * s; typeface = tfBold }
        val orgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(textCol, 205); textSize = 32f * s; typeface = tfMed }

        var curY = padTop + nameSize
        val inlineCreds = credSuffix.isNotBlank() &&
            (namePaint.measureText(displayName) + credPaint.measureText(", $credSuffix")) <= headerAvailW

        if (inlineCreds) {
            canvas.drawText(displayName, textStartX, curY, namePaint)
            val nameW = namePaint.measureText(displayName)
            canvas.drawText(", $credSuffix", textStartX + nameW, curY, credPaint)
            curY += 16f * s
        } else {
            val nameLines = wrapTextToWidth(displayName, namePaint, headerAvailW, maxLines = 2)
            nameLines.forEachIndexed { i, ln ->
                if (i > 0) curY += nameSize * 1.12f
                canvas.drawText(ln, textStartX, curY, namePaint)
            }
            if (credSuffix.isNotBlank()) {
                curY += credSize * 1.25f
                val credLines = wrapTextToWidth(credSuffix, credPaint, headerAvailW, maxLines = 2)
                credLines.forEachIndexed { i, ln ->
                    if (i > 0) curY += credSize * 1.15f
                    canvas.drawText(ln, textStartX, curY, credPaint)
                }
            }
            curY += 14f * s
        }

        if (card.designation.isNotBlank()) {
            curY += 38f * s
            val roleLines = wrapTextToWidth(card.designation.trim(), rolePaint, headerAvailW, maxLines = 2)
            roleLines.forEachIndexed { i, ln ->
                if (i > 0) curY += 40f * s
                canvas.drawText(ln, textStartX, curY, rolePaint)
            }
        }

        val orgLine = listOf(card.companyName, card.department).map { it.trim() }.filter { it.isNotBlank() }.joinToString(" • ")
        if (orgLine.isNotBlank()) {
            curY += 40f * s
            val orgLines = wrapTextToWidth(orgLine, orgPaint, headerAvailW, maxLines = 2)
            orgLines.forEachIndexed { i, ln ->
                if (i > 0) curY += 36f * s
                canvas.drawText(ln, textStartX, curY, orgPaint)
            }
        }

        // 7. Accent Divider
        val dividerY = maxOf(headerBottomY + 26f * s, curY + 28f * s).coerceAtMost(h * 0.56f)
        canvas.drawLine(
            padStart, dividerY, w - padEnd, dividerY,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(accent, 95); strokeWidth = 3f * s }
        )

        // 8. Contact Details (Multiple Phones, Email, Website, Address)
        val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(textCol, 232); textSize = 33f * s; typeface = tfMed }
        val bulletPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 30f * s; typeface = tfBold }
        val detailAvailW = (w - padStart - padEnd - 44f * s).coerceAtLeast(300f * s)

        val detailRows = mutableListOf<Pair<String, String>>()
        val shareablePhones = BusinessCardProfileHelper.getShareablePhoneNumbers(card)
        if (shareablePhones.isNotEmpty()) {
            val firstP = shareablePhones.first()
            val secondP = shareablePhones.getOrNull(1)
            val combined = if (secondP != null && (firstP.number.length + secondP.number.length) <= 34) {
                "${firstP.number}  •  ${secondP.number}"
            } else firstP.number
            detailRows.add("☎" to combined)
            if (secondP != null && (firstP.number.length + secondP.number.length) > 34) {
                detailRows.add("☎" to "${secondP.type.displayLabel}: ${secondP.number}")
            }
        } else if (card.sharePhone && card.phone.isNotBlank()) {
            detailRows.add("☎" to card.phone.trim())
        }
        if (card.shareEmail && card.email.isNotBlank()) detailRows.add("✉" to card.email.trim())
        if (card.website.isNotBlank()) detailRows.add("🌐" to card.website.trim())
        if (card.shareAddress && card.officeAddress.isNotBlank()) detailRows.add("⌖" to card.officeAddress.trim())

        var dy = dividerY + 52f * s
        val maxY = h - 38f * s
        for ((glyph, textVal) in detailRows) {
            if (dy > maxY) break
            canvas.drawText(glyph, padStart, dy, bulletPaint)
            val wrapped = wrapTextToWidth(textVal, detailPaint, detailAvailW, maxLines = if (glyph == "⌖") 2 else 1)
            wrapped.forEachIndexed { i, ln ->
                if (i > 0) dy += 38f * s
                if (dy <= maxY) canvas.drawText(ln, padStart + 42f * s, dy, detailPaint)
            }
            dy += 50f * s
        }

        canvas.restore()

        // Outer Card Border
        val borderW = (if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 5f else 3f) * s
        canvas.drawRoundRect(
            RectF(borderW / 2f, borderW / 2f, w - borderW / 2f, h - borderW / 2f),
            cornerR, cornerR,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = withAlpha(accent, if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 215 else 140)
                style = Paint.Style.STROKE
                strokeWidth = borderW
            }
        )

        renderCache.put(key, bmp)
        return bmp
    }

    fun renderBackBitmap(
        context: Context?,
        card: BusinessCardEntity,
        quality: ExportQualityTier = ExportQualityTier.STANDARD
    ): Bitmap {
        val key = computeRenderCacheKey(card, "BACK", quality)
        renderCache.get(key)?.takeIf { !it.isRecycled }?.let { return it }

        val w = quality.widthPx
        val h = quality.heightPx
        val s = w / 1200f
        val spec = CardTemplateRegistry.resolveForCard(card)

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val cornerR = (card.cornerRadiusDp * 2.4f) * s
        val cardRect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clipPath = Path().apply { addRoundRect(cardRect, cornerR, cornerR, Path.Direction.CW) }
        canvas.save()
        canvas.clipPath(clipPath)

        val bgStart = card.primaryColorHex.toInt()
        val bgEnd = card.cardGradientEndHex.toInt()
        val accent = card.accentColorHex.toInt()
        val textCol = card.textColorHex.toInt()
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), bgStart, bgEnd, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(cardRect, bgPaint)
        drawTemplateDecoration(canvas, w.toFloat(), h.toFloat(), s, spec.layoutStyle, accent)

        // Scanner-safe high-contrast white QR container (left side, exact mirror of BusinessCardBackView)
        val qrOuterSize = 400f * s
        val qrLeft = 64f * s
        val qrTop = (h - qrOuterSize) / 2f
        val qrRect = RectF(qrLeft, qrTop, qrLeft + qrOuterSize, qrTop + qrOuterSize)
        canvas.drawRoundRect(qrRect, 36f * s, 36f * s, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })

        val qrPad = 20f * s
        val qrPx = (qrOuterSize - qrPad * 2).toInt().coerceAtLeast(240)
        val qrBmp = if (context != null) {
            PremiumExtrasHelper.generateBrandedQrBitmap(context, card, qrPx)
        } else {
            CardShareHelper.generateQrCodeBitmap(CardShareHelper.toVCardString(card), qrPx)
        }
        canvas.drawBitmap(qrBmp, null, RectF(qrRect.left + qrPad, qrRect.top + qrPad, qrRect.right - qrPad, qrRect.bottom - qrPad), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))

        // Right-side Back Heading + Back Message
        val tfBold = resolveTypeface(card.fontFamilyName, bold = true)
        val tfMed = resolveTypeface(card.fontFamilyName, bold = false)
        val textLeft = qrRect.right + 48f * s
        val textAvailW = (w - textLeft - 56f * s).coerceAtLeast(240f * s)

        val headingText = card.backHeading.trim().ifBlank { card.companyName.trim().ifBlank { "CardLink" } }
        val messageText = card.backMessage.trim().ifBlank { card.bio.trim() }

        val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 48f * s; typeface = tfBold }
        val msgSize = when {
            messageText.length > 130 -> 30f * s
            messageText.length > 90 -> 33f * s
            else -> 36f * s
        }
        val msgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(textCol, 230); textSize = msgSize; typeface = tfMed }

        val headLines = wrapTextToWidth(headingText, headPaint, textAvailW, maxLines = 2)
        val msgLines = if (messageText.isNotBlank()) wrapTextToWidth(messageText, msgPaint, textAvailW, maxLines = 5) else emptyList()

        val totalBlockH = headLines.size * (54f * s) + (if (msgLines.isNotEmpty()) 22f * s + msgLines.size * (msgSize * 1.28f) else 0f)
        var ty = ((h - totalBlockH) / 2f) + 44f * s

        headLines.forEachIndexed { idx, ln ->
            if (idx > 0) ty += 54f * s
            canvas.drawText(ln, textLeft, ty, headPaint)
        }
        if (msgLines.isNotEmpty()) {
            ty += 26f * s
            msgLines.forEach { ln ->
                ty += msgSize * 1.25f
                canvas.drawText(ln, textLeft, ty, msgPaint)
            }
        }

        canvas.restore()

        val borderW = (if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 5f else 3f) * s
        canvas.drawRoundRect(
            RectF(borderW / 2f, borderW / 2f, w - borderW / 2f, h - borderW / 2f),
            cornerR, cornerR,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = withAlpha(accent, 175)
                style = Paint.Style.STROKE
                strokeWidth = borderW
            }
        )

        renderCache.put(key, bmp)
        return bmp
    }

    fun renderCombinedFrontBackSheet(
        context: Context?,
        card: BusinessCardEntity,
        quality: ExportQualityTier = ExportQualityTier.STANDARD
    ): Bitmap {
        val front = renderFrontBitmap(context, card, quality)
        val back = renderBackBitmap(context, card, quality)
        val pad = (front.width * 0.06f).toInt().coerceAtLeast(36)
        val gap = (front.height * 0.08f).toInt().coerceAtLeast(32)
        val sheetW = front.width + pad * 2
        val sheetH = front.height + back.height + pad * 2 + gap
        val sheet = Bitmap.createBitmap(sheetW, sheetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        canvas.drawColor(Color.parseColor("#F8FAFC"))
        canvas.drawBitmap(front, pad.toFloat(), pad.toFloat(), null)
        canvas.drawBitmap(back, pad.toFloat(), (pad + front.height + gap).toFloat(), null)
        return sheet
    }

    // =========================================================================
    // PNG EXPORT (Share via TempSecureExportVault OR Explicit Save to Device)
    // =========================================================================

    suspend fun exportAndSharePng(
        context: Context,
        card: BusinessCardEntity,
        sides: ExportCardSides,
        combinedLayout: CombinedPngLayout,
        quality: ExportQualityTier
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = safeSlug(card.fullName)
            val uris = ArrayList<Uri>()

            when {
                sides == ExportCardSides.FRONT_ONLY -> {
                    val bmp = renderFrontBitmap(context, card, quality)
                    val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Front", "png")
                    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    uris.add(TempSecureExportVault.toShareUri(context, file))
                }
                sides == ExportCardSides.BACK_ONLY -> {
                    val bmp = renderBackBitmap(context, card, quality)
                    val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Back", "png")
                    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    uris.add(TempSecureExportVault.toShareUri(context, file))
                }
                combinedLayout == CombinedPngLayout.COMBINED_SHEET -> {
                    val sheet = renderCombinedFrontBackSheet(context, card, quality)
                    val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_FrontBack", "png")
                    FileOutputStream(file).use { sheet.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    sheet.recycle()
                    uris.add(TempSecureExportVault.toShareUri(context, file))
                }
                else -> {
                    val front = renderFrontBitmap(context, card, quality)
                    val back = renderBackBitmap(context, card, quality)
                    val f1 = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Front", "png")
                    val f2 = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Back", "png")
                    FileOutputStream(f1).use { front.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    FileOutputStream(f2).use { back.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    uris.add(TempSecureExportVault.toShareUri(context, f1))
                    uris.add(TempSecureExportVault.toShareUri(context, f2))
                }
            }

            shareUrisViaOsSheet(context, uris, "image/png", "Share Business Card Image", CardShareHelper.buildTextSummary(card))
        }
    }

    suspend fun savePngToUri(
        context: Context,
        destUri: Uri,
        card: BusinessCardEntity,
        sides: ExportCardSides,
        quality: ExportQualityTier
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val bmpToSave = when (sides) {
                ExportCardSides.FRONT_ONLY -> renderFrontBitmap(context, card, quality)
                ExportCardSides.BACK_ONLY -> renderBackBitmap(context, card, quality)
                ExportCardSides.FRONT_AND_BACK -> renderCombinedFrontBackSheet(context, card, quality)
            }
            context.contentResolver.openOutputStream(destUri, "wt")?.use { out ->
                bmpToSave.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            } ?: error("Could not open selected destination URI.")
            if (sides == ExportCardSides.FRONT_AND_BACK) bmpToSave.recycle()
        }
    }

    // =========================================================================
    // PDF EXPORT (Exact Active Card Design + Print-Safe Margins — Business Card & A4)
    // =========================================================================

    private fun buildCanonicalPdfDocument(
        context: Context,
        card: BusinessCardEntity,
        sides: ExportCardSides,
        layout: PdfCardLayout,
        quality: ExportQualityTier
    ): PdfDocument {
        val pdf = PdfDocument()
        val frontBmp = if (sides != ExportCardSides.BACK_ONLY) renderFrontBitmap(context, card, quality) else null
        val backBmp = if (sides != ExportCardSides.FRONT_ONLY) renderBackBitmap(context, card, quality) else null

        if (layout == PdfCardLayout.BUSINESS_CARD_SIZE) {
            // Standard 3.5" x 2.0" Business Card with clean print-safe margin
            val pageW = if (quality == ExportQualityTier.HIGH_QUALITY) 1125 else 750
            val pageH = if (quality == ExportQualityTier.HIGH_QUALITY) 675 else 450
            val margin = (pageW * 0.032f)
            val drawRect = RectF(margin, margin, pageW - margin, pageH - margin)
            var pageNum = 1

            fun addCardPage(bmp: Bitmap) {
                val p = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum++).create())
                p.canvas.drawColor(Color.WHITE)
                p.canvas.drawBitmap(bmp, null, drawRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                pdf.finishPage(p)
            }
            if (frontBmp != null) addCardPage(frontBmp)
            if (backBmp != null) addCardPage(backBmp)
        } else {
            // A4 Print Sheet (595 x 842 pt) with generous print-safe margins & subtle corner trim guides
            val pageW = 595
            val pageH = 842
            val cardW = 350f
            val cardH = 210f
            val left = (pageW - cardW) / 2f
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
            val c = p.canvas
            c.drawColor(Color.WHITE)

            val trimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1"); strokeWidth = 1f }
            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#64748B")
                textSize = 11f
                typeface = Typeface.SANS_SERIF
            }

            fun drawFramedCard(bmp: Bitmap, topY: Float, caption: String) {
                val rect = RectF(left, topY, left + cardW, topY + cardH)
                c.drawText(caption, left, topY - 10f, labelPaint)
                c.drawBitmap(bmp, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                // Subtle outside corner crop marks
                val mk = 12f
                val gp = 4f
                c.drawLine(rect.left, rect.top - gp - mk, rect.left, rect.top - gp, trimPaint)
                c.drawLine(rect.left - gp - mk, rect.top, rect.left - gp, rect.top, trimPaint)
                c.drawLine(rect.right, rect.top - gp - mk, rect.right, rect.top - gp, trimPaint)
                c.drawLine(rect.right + gp, rect.top, rect.right + gp + mk, rect.top, trimPaint)
                c.drawLine(rect.left, rect.bottom + gp, rect.left, rect.bottom + gp + mk, trimPaint)
                c.drawLine(rect.left - gp - mk, rect.bottom, rect.left - gp, rect.bottom, trimPaint)
                c.drawLine(rect.right, rect.bottom + gp, rect.right, rect.bottom + gp + mk, trimPaint)
                c.drawLine(rect.right + gp, rect.bottom, rect.right + gp + mk, rect.bottom, trimPaint)
            }

            if (frontBmp != null && backBmp != null) {
                drawFramedCard(frontBmp, 140f, "FRONT")
                drawFramedCard(backBmp, 460f, "BACK")
            } else if (frontBmp != null) {
                drawFramedCard(frontBmp, 280f, "FRONT")
            } else if (backBmp != null) {
                drawFramedCard(backBmp, 280f, "BACK")
            }
            pdf.finishPage(p)
        }
        return pdf
    }

    suspend fun exportAndSharePdf(
        context: Context,
        card: BusinessCardEntity,
        sides: ExportCardSides,
        layout: PdfCardLayout,
        quality: ExportQualityTier
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val pdf = buildCanonicalPdfDocument(context, card, sides, layout, quality)
            val safeName = safeSlug(card.fullName)
            val suffix = if (layout == PdfCardLayout.A4_PRINT_SHEET) "A4" else "Card"
            val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_$suffix", "pdf")
            FileOutputStream(file).use { pdf.writeTo(it) }
            pdf.close()

            val uri = TempSecureExportVault.toShareUri(context, file)
            shareUrisViaOsSheet(context, arrayListOf(uri), "application/pdf", "Export Business Card PDF", null)
        }
    }

    suspend fun savePdfToUri(
        context: Context,
        destUri: Uri,
        card: BusinessCardEntity,
        sides: ExportCardSides,
        layout: PdfCardLayout,
        quality: ExportQualityTier
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val pdf = buildCanonicalPdfDocument(context, card, sides, layout, quality)
            context.contentResolver.openOutputStream(destUri, "wt")?.use { out ->
                pdf.writeTo(out)
                out.flush()
            } ?: error("Could not open selected destination URI.")
            pdf.close()
        }
    }

    // =========================================================================
    // INTERACTIVE HTML CARD (Matches Active Card Design + Privacy-Filtered Actions)
    // =========================================================================

    fun buildInteractiveHtmlString(context: Context?, card: BusinessCardEntity): String {
        val c = card.sanitizedForSharing()
        val bgStartHex = toCssHex(card.primaryColorHex)
        val bgEndHex = toCssHex(card.cardGradientEndHex)
        val accentHex = toCssHex(card.accentColorHex)
        val textHex = toCssHex(card.textColorHex)
        val radius = card.cornerRadiusDp.coerceIn(10, 28)

        val vcfEscaped = CardShareHelper.toVCardString(c)
            .replace("\\", "\\\\")
            .replace("`", "\\`")
            .replace("$", "\\$")

        val safeName = htmlEscape(c.fullName.ifBlank { "CardLink Profile" })
        val credSuffix = htmlEscape(BusinessCardProfileHelper.formatCredentialsSuffix(c, forSharing = true))
        val safeDesig = htmlEscape(c.designation)
        val safeOrg = htmlEscape(listOf(c.companyName, c.department).map { it.trim() }.filter { it.isNotBlank() }.joinToString(" • "))
        val safeBio = htmlEscape(c.bio)

        // Optional inline base64 photo & logo (gracefully skipped if missing or in JVM unit tests)
        val photoDataUri = encodeOptionalAssetDataUri(context, card.profilePhotoUri, 240)
        val logoDataUri = encodeOptionalAssetDataUri(context, card.companyLogoUri, 160)

        val phones = BusinessCardProfileHelper.getShareablePhoneNumbers(c)
        val phonesHtml = buildString {
            for (rec in phones) {
                val cleanDial = rec.number.filter { it.isDigit() || it == '+' }
                if (cleanDial.isNotBlank()) {
                    append("<a class='btn btn-outline' href='tel:${htmlEscape(cleanDial)}'>${htmlEscape(rec.type.displayLabel)}: ${htmlEscape(rec.number)}</a>")
                }
                if (rec.isWhatsAppEnabled && c.shareWhatsapp) {
                    val digits = rec.number.filter { it.isDigit() }
                    val e164 = if (digits.startsWith("0") && digits.length == 11) "880${digits.drop(1)}" else digits
                    if (e164.length >= 7) {
                        append("<a class='btn btn-outline' href='https://wa.me/$e164' target='_blank' rel='noopener'>WhatsApp: ${htmlEscape(rec.number)}</a>")
                    }
                }
            }
            if (phones.isEmpty() && c.phone.isNotBlank()) {
                val cleanDial = c.phone.filter { it.isDigit() || it == '+' }
                append("<a class='btn btn-outline' href='tel:${htmlEscape(cleanDial)}'>Call: ${htmlEscape(c.phone)}</a>")
            }
        }

        val emailHtml = if (c.email.isNotBlank()) "<a class='btn btn-outline' href='mailto:${htmlEscape(c.email)}'>Email: ${htmlEscape(c.email)}</a>" else ""
        val webHtml = if (c.website.isNotBlank()) {
            val href = if (c.website.startsWith("http", true)) c.website else "https://${c.website}"
            "<a class='btn btn-outline' href='${htmlEscape(href)}' target='_blank' rel='noopener'>Website: ${htmlEscape(c.website)}</a>"
        } else ""
        val linkedInHtml = if (c.linkedInUrl.isNotBlank()) "<a class='btn btn-outline' href='${htmlEscape(c.linkedInUrl)}' target='_blank' rel='noopener'>LinkedIn</a>" else ""
        val fbHtml = if (c.facebookUrl.isNotBlank()) "<a class='btn btn-outline' href='${htmlEscape(c.facebookUrl)}' target='_blank' rel='noopener'>Facebook</a>" else ""
        val mapHtml = when {
            c.latitude != null && c.longitude != null ->
                "<a class='btn btn-outline' href='https://www.google.com/maps/dir/?api=1&destination=${c.latitude},${c.longitude}' target='_blank' rel='noopener'>Office Location (Maps)</a>"
            c.officeAddress.isNotBlank() ->
                "<a class='btn btn-outline' href='https://www.google.com/maps/search/?api=1&query=${java.net.URLEncoder.encode(c.officeAddress, "UTF-8")}' target='_blank' rel='noopener'>${htmlEscape(c.officeAddress)}</a>"
            else -> ""
        }

        val avatarTag = if (photoDataUri.isNotBlank()) {
            "<img class='avatar' src='$photoDataUri' alt='$safeName' />"
        } else {
            "<div class='avatar initials'>${htmlEscape(c.fullName.trim().take(2).uppercase().ifBlank { "CL" })}</div>"
        }
        val logoTag = if (logoDataUri.isNotBlank()) {
            "<div class='logo-box'><img src='$logoDataUri' alt='Logo' /></div>"
        } else ""

        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>$safeName — Digital Business Card</title>
<style>
  body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#0F172A;color:$textHex;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px;box-sizing:border-box;}
  .card{width:100%;max-width:440px;background:linear-gradient(135deg,$bgStartHex,$bgEndHex);border:1.5px solid $accentHex;border-radius:${radius}px;padding:26px;box-shadow:0 20px 45px rgba(0,0,0,0.42);}
  .header{display:flex;align-items:center;gap:14px;margin-bottom:16px;}
  .avatar{width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid $accentHex;flex-shrink:0;}
  .initials{display:flex;align-items:center;justify-content:center;font-weight:700;font-size:20px;color:$accentHex;background:rgba(255,255,255,0.08);}
  .title-col{flex:1;min-width:0;}
  .logo-box{width:44px;height:44px;border-radius:10px;background:#fff;padding:4px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
  .logo-box img{max-width:100%;max-height:100%;object-fit:contain;}
  h1{margin:0;font-size:22px;line-height:1.25;color:$textHex;}
  .creds{font-size:15px;font-weight:500;opacity:0.86;}
  .role{color:$accentHex;font-size:14px;font-weight:600;margin-top:4px;}
  .org{color:$textHex;opacity:0.82;font-size:13px;margin-top:2px;}
  .divider{height:1px;background:$accentHex;opacity:0.35;margin:14px 0;}
  .bio{font-size:13px;opacity:0.88;line-height:1.45;margin-bottom:14px;}
  .btn{display:block;width:100%;text-align:center;padding:12px 14px;margin:8px 0;border-radius:12px;text-decoration:none;font-weight:700;font-size:14px;box-sizing:border-box;}
  .btn-primary{background:$accentHex;color:$bgStartHex;border:none;cursor:pointer;}
  .btn-outline{border:1px solid $accentHex;color:$textHex;background:rgba(255,255,255,0.05);}
  .footer{text-align:center;margin-top:16px;font-size:11px;opacity:0.65;}
</style>
</head>
<body>
  <div class="card">
    <div class="header">
      $avatarTag
      <div class="title-col">
        <h1>$safeName${if (credSuffix.isNotBlank()) " <span class='creds'>, $credSuffix</span>" else ""}</h1>
        ${if (safeDesig.isNotBlank()) "<div class='role'>$safeDesig</div>" else ""}
        ${if (safeOrg.isNotBlank()) "<div class='org'>$safeOrg</div>" else ""}
      </div>
      $logoTag
    </div>
    <div class="divider"></div>
    ${if (safeBio.isNotBlank()) "<div class='bio'>$safeBio</div>" else ""}
    <button class="btn btn-primary" onclick="downloadVcf()">Save Contact (.vcf)</button>
    $phonesHtml
    $emailHtml
    $webHtml
    $linkedInHtml
    $fbHtml
    $mapHtml
    <div class="footer">Created with CardLink</div>
  </div>
<script>
function downloadVcf(){
  const vcf=`$vcfEscaped`;
  const blob=new Blob([vcf],{type:'text/vcard;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.href=url;a.download='${safeSlug(c.fullName)}.vcf';a.click();
  URL.revokeObjectURL(url);
}
</script>
</body>
</html>"""
    }

    suspend fun exportAndShareInteractiveHtml(context: Context, card: BusinessCardEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val html = buildInteractiveHtmlString(context, card)
            val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeSlug(card.fullName)}_InteractiveCard", "html")
            file.writeText(html, Charsets.UTF_8)
            val uri = TempSecureExportVault.toShareUri(context, file)
            shareUrisViaOsSheet(context, arrayListOf(uri), "text/html", "Share Interactive HTML Card", null)
        }
    }

    suspend fun saveInteractiveHtmlToUri(context: Context, destUri: Uri, card: BusinessCardEntity): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val html = buildInteractiveHtmlString(context, card)
            context.contentResolver.openOutputStream(destUri, "wt")?.use { out ->
                out.write(html.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: error("Could not open selected destination URI.")
        }
    }

    suspend fun shareQrBitmap(context: Context, card: BusinessCardEntity, qrBitmap: Bitmap): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeSlug(card.fullName)}_QR", "png")
            FileOutputStream(file).use { qrBitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = TempSecureExportVault.toShareUri(context, file)
            shareUrisViaOsSheet(context, arrayListOf(uri), "image/png", "Share Business Card QR", null)
        }
    }

    suspend fun saveQrBitmapToUri(context: Context, destUri: Uri, qrBitmap: Bitmap): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(destUri, "wt")?.use { out ->
                qrBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            } ?: error("Could not open selected destination URI.")
        }
    }

    // =========================================================================
    // INTERNAL GRAPHICS & SHARE HELPERS
    // =========================================================================

    private fun shareUrisViaOsSheet(
        context: Context,
        uris: ArrayList<Uri>,
        mimeType: String,
        chooserTitle: String,
        extraText: String?
    ) {
        require(uris.isNotEmpty()) { "No files generated for sharing." }
        val clip = ClipData.newRawUri("CardLink_Export", uris.first()).apply {
            for (i in 1 until uris.size) addItem(ClipData.Item(uris[i]))
        }
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uris.first())
                if (!extraText.isNullOrBlank()) putExtra(Intent.EXTRA_TEXT, extraText)
                clipData = clip
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = mimeType
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                if (!extraText.isNullOrBlank()) putExtra(Intent.EXTRA_TEXT, extraText)
                clipData = clip
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle).apply {
            clipData = clip
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun drawTemplateDecoration(
        canvas: Canvas,
        w: Float,
        h: Float,
        s: Float,
        layoutStyle: CardLayoutStyle,
        accent: Int
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (layoutStyle) {
            CardLayoutStyle.LEFT_ACCENT_BAR -> {
                paint.color = accent
                canvas.drawRect(0f, 0f, 24f * s, h, paint)
            }
            CardLayoutStyle.TOP_BAND -> {
                paint.color = accent
                canvas.drawRect(0f, 0f, w, 20f * s, paint)
            }
            CardLayoutStyle.SPLIT_PANEL -> {
                paint.color = withAlpha(accent, 36)
                canvas.drawRect(w * 0.68f, 0f, w, h, paint)
            }
            CardLayoutStyle.DIAGONAL_ACCENT -> {
                paint.color = withAlpha(accent, 36)
                val p = Path().apply {
                    moveTo(w * 0.72f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, h)
                    lineTo(w * 0.56f, h)
                    close()
                }
                canvas.drawPath(p, paint)
            }
            CardLayoutStyle.WAVE_CURVE -> {
                paint.color = withAlpha(accent, 42)
                val p = Path().apply {
                    moveTo(0f, h * 0.78f)
                    cubicTo(w * 0.30f, h * 0.62f, w * 0.70f, h * 0.96f, w, h * 0.72f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                canvas.drawPath(p, paint)
            }
            CardLayoutStyle.MODERN_FRAME -> {
                paint.color = withAlpha(accent, 105)
                paint.strokeWidth = 3f * s
                val inset = 18f * s
                canvas.drawLine(inset, inset, w - inset, inset, paint)
                canvas.drawLine(inset, h - inset, w - inset, h - inset, paint)
            }
            else -> Unit
        }
    }

    private fun resolveTypeface(fontFamilyName: String, bold: Boolean): Typeface {
        val style = if (bold) Typeface.BOLD else Typeface.NORMAL
        return when (fontFamilyName) {
            "Serif" -> Typeface.create(Typeface.SERIF, style)
            "Monospace" -> Typeface.create(Typeface.MONOSPACE, style)
            else -> Typeface.create(Typeface.SANS_SERIF, style)
        }
    }

    private fun withAlpha(argb: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(argb), Color.green(argb), Color.blue(argb))

    private fun decodeOptionalLocalBitmap(context: Context?, uriStr: String?, maxEdge: Int): Bitmap? {
        if (context == null || uriStr.isNullOrBlank()) return null
        return runCatching {
            if (uriStr.endsWith(".clenc", ignoreCase = true)) {
                VaultCryptoManager.decodeVaultBitmapUncached(context, uriStr, maxEdge)
            } else {
                ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(uriStr), maxEdge)
            }
        }.getOrNull()
    }

    private fun encodeOptionalAssetDataUri(context: Context?, uriStr: String?, maxEdge: Int): String {
        val bmp = decodeOptionalLocalBitmap(context, uriStr, maxEdge) ?: return ""
        return try {
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, baos)
            val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            "data:image/jpeg;base64,$b64"
        } catch (_: Exception) {
            ""
        } finally {
            runCatching { bmp.recycle() }
        }
    }

    private fun centerCropSrcRect(srcW: Int, srcH: Int, targetRatio: Float): Rect {
        val srcRatio = srcW.toFloat() / srcH.coerceAtLeast(1).toFloat()
        return if (srcRatio > targetRatio) {
            val newW = (srcH * targetRatio).toInt().coerceIn(1, srcW)
            val left = (srcW - newW) / 2
            Rect(left, 0, left + newW, srcH)
        } else {
            val newH = (srcW / targetRatio).toInt().coerceIn(1, srcH)
            val top = (srcH - newH) / 2
            Rect(0, top, srcW, top + newH)
        }
    }

    private fun fitInsideRect(srcW: Int, srcH: Int, bounds: RectF): RectF {
        val ratio = minOf(bounds.width() / srcW.coerceAtLeast(1), bounds.height() / srcH.coerceAtLeast(1))
        val dw = srcW * ratio
        val dh = srcH * ratio
        val l = bounds.centerX() - dw / 2f
        val t = bounds.centerY() - dh / 2f
        return RectF(l, t, l + dw, t + dh)
    }

    private fun wrapTextToWidth(text: String, paint: Paint, maxWidth: Float, maxLines: Int): List<String> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val lines = mutableListOf<String>()
        var current = ""
        for (w in words) {
            val test = if (current.isEmpty()) w else "$current $w"
            if (paint.measureText(test) <= maxWidth || current.isEmpty()) {
                current = test
            } else {
                lines.add(current)
                current = w
                if (lines.size == maxLines - 1) break
            }
        }
        if (current.isNotEmpty() && lines.size < maxLines) {
            lines.add(current)
        }
        return lines.mapIndexed { idx, line ->
            if (idx == maxLines - 1 && paint.measureText(line) > maxWidth) {
                var trimmed = line
                while (trimmed.length > 3 && paint.measureText("$trimmed…") > maxWidth) {
                    trimmed = trimmed.dropLast(1)
                }
                "$trimmed…"
            } else line
        }
    }

    private fun toCssHex(argb: Long): String = String.format("#%06X", (argb.toInt() and 0xFFFFFF))

    private fun htmlEscape(raw: String): String = raw
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;")

    private fun safeSlug(name: String): String = name.trim()
        .replace(Regex("\\s+"), "_")
        .replace(Regex("[^a-zA-Z0-9_-]"), "")
        .trim('_')
        .ifBlank { "CardLink" }
}
