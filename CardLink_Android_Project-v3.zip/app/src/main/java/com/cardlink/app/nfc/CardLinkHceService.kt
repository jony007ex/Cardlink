package com.cardlink.app.nfc

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import java.nio.charset.StandardCharsets

/**
 * Full NFC Forum Type 4 Tag NDEF Emulation over Host Card Emulation (HCE).
 * When another Android or iPhone taps the back of this phone, the OS reads the
 * Capability Container (E103) and NDEF File (E104) containing an NDEF URI Record
 * (Google Drive link / Website / LinkedIn), automatically opening the link in the browser!
 */
class CardLinkHceService : HostApduService() {

    companion object {
        @Volatile
        var activeShareUrl: String = "https://cardlink.app"

        @Volatile
        var activeVCardPayload: String = "BEGIN:VCARD\nVERSION:3.0\nFN:CardLink User\nEND:VCARD"

        private val APDU_SELECT_NDEF_APP = byteArrayOf(
            0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
            0xD2.toByte(), 0x76, 0x00, 0x00, 0x85.toByte(), 0x01, 0x01, 0x00
        )

        val SELECT_CARDLINK_AID = byteArrayOf(
            0x00, 0xA4.toByte(), 0x04, 0x00, 0x08,
            0xF0.toByte(), 0x43, 0x41, 0x52, 0x44, 0x4C, 0x49, 0x4E, 0x4B
        )

        private val APDU_SELECT_CC = byteArrayOf(0x00, 0xA4.toByte(), 0x00, 0x0C, 0x02, 0xE1.toByte(), 0x03)
        private val APDU_SELECT_NDEF = byteArrayOf(0x00, 0xA4.toByte(), 0x00, 0x0C, 0x02, 0xE1.toByte(), 0x04)

        // Standard 15-byte Capability Container (CC) for NFC Forum Type 4 Tag (Read-Only)
        private val CC_FILE = byteArrayOf(
            0x00, 0x0F, // CCLEN = 15 bytes
            0x20,       // Mapping Version 2.0
            0x00, 0x3B, // MLe = 59 bytes
            0x00, 0x34, // MLc = 52 bytes
            0x04, 0x06, // NDEF File Control TLV (T=04, L=06)
            0xE1.toByte(), 0x04, // NDEF File ID = E104
            0x04, 0x00, // Max NDEF size = 1024 bytes
            0x00,       // Read access: granted without security
            0xFF.toByte() // Write access: read-only
        )

        private val SW_OK = byteArrayOf(0x90.toByte(), 0x00.toByte())
        private val SW_NOT_FOUND = byteArrayOf(0x6A.toByte(), 0x82.toByte())
    }

    private var selectedFile: Int = 0 // 1 = CC, 2 = NDEF

    private fun buildNdefFileBytes(): ByteArray {
        val uriRecord = NdefRecord.createUri(activeShareUrl)
        val ndefMessage = NdefMessage(arrayOf(uriRecord))
        val msgBytes = ndefMessage.toByteArray()
        val len = msgBytes.size
        // Type 4 NDEF file starts with 2-byte big-endian NLEN
        return byteArrayOf(((len shr 8) and 0xFF).toByte(), (len and 0xFF).toByte()) + msgBytes
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null || commandApdu.size < 4) return SW_NOT_FOUND

        // 1. Direct CardLink-to-CardLink vCard Exchange
        if (commandApdu.contentEquals(SELECT_CARDLINK_AID)) {
            return activeVCardPayload.toByteArray(StandardCharsets.UTF_8) + SW_OK
        }

        // 2. SELECT NDEF Tag Application (D2760000850101)
        if (commandApdu.size >= 12 &&
            commandApdu[0] == 0x00.toByte() &&
            commandApdu[1] == 0xA4.toByte() &&
            commandApdu[2] == 0x04.toByte()
        ) {
            selectedFile = 0
            return SW_OK
        }

        // 3. SELECT Capability Container (E103)
        if (commandApdu.contentEquals(APDU_SELECT_CC)) {
            selectedFile = 1
            return SW_OK
        }

        // 4. SELECT NDEF File (E104)
        if (commandApdu.contentEquals(APDU_SELECT_NDEF)) {
            selectedFile = 2
            return SW_OK
        }

        // 5. READ BINARY (00 B0 P1 P2 Le)
        if (commandApdu[0] == 0x00.toByte() && commandApdu[1] == 0xB0.toByte() && commandApdu.size >= 5) {
            val offset = ((commandApdu[2].toInt() and 0xFF) shl 8) or (commandApdu[3].toInt() and 0xFF)
            val length = commandApdu[4].toInt() and 0xFF
            val source = when (selectedFile) {
                1 -> CC_FILE
                2 -> buildNdefFileBytes()
                else -> return SW_NOT_FOUND
            }
            if (offset >= source.size) return SW_OK
            val end = (offset + length).coerceAtMost(source.size)
            return source.copyOfRange(offset, end) + SW_OK
        }

        return SW_NOT_FOUND
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = 0
    }
}
