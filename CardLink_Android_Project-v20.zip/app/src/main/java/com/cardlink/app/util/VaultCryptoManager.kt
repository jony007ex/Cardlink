package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultCryptoManager {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val MASTER_KEY_ALIAS = "cardlink_vault_master_aes256_v1"
    private const val VAULT_PREFS = "cardlink_vault_crypto_prefs"
    private const val KEY_WRAPPED_DB_PASS = "wrapped_sqlcipher_passphrase_v1"

    // Magic header for AES-256-GCM encrypted local vault files (.clenc)
    private val VAULT_FILE_MAGIC = byteArrayOf('C'.code.toByte(), 'L'.code.toByte(), 'V'.code.toByte(), '1'.code.toByte())
    private val SQLITE_PLAIN_HEADER = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
    private val secureRandom = SecureRandom()

    @Volatile
    private var sqlCipherLoaded = false

    fun ensureSqlCipherLoaded() {
        if (!sqlCipherLoaded) {
            synchronized(this) {
                if (!sqlCipherLoaded) {
                    System.loadLibrary("sqlcipher")
                    sqlCipherLoaded = true
                }
            }
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val specBuilder = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)

        // Prefer StrongBox hardware security module on Android 9+ if device supports it
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                kg.init(specBuilder.setIsStrongBoxBacked(true).build())
                return kg.generateKey()
            } catch (_: Exception) {
                // Fallback gracefully to standard TEE-backed AndroidKeyStore
            }
        }
        val fallbackSpec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        kg.init(fallbackSpec)
        return kg.generateKey()
    }

    fun encryptWithKeystore(plainBytes: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val enc = cipher.doFinal(plainBytes)
        val out = ByteArray(1 + iv.size + enc.size)
        out[0] = iv.size.toByte()
        System.arraycopy(iv, 0, out, 1, iv.size)
        System.arraycopy(enc, 0, out, 1 + iv.size, enc.size)
        return out
    }

    fun decryptWithKeystore(blob: ByteArray): ByteArray {
        require(blob.size > 13) { "Malformed encrypted vault payload." }
        val ivLen = blob[0].toInt() and 0xFF
        val iv = blob.copyOfRange(1, 1 + ivLen)
        val enc = blob.copyOfRange(1 + ivLen, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(enc)
    }

    /**
     * Returns a 32-byte random SQLCipher passphrase wrapped by AndroidKeyStore.
     * Passphrase is never hardcoded or logged.
     */
    fun getOrCreateDatabasePassphrase(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(VAULT_PREFS, Context.MODE_PRIVATE)
        val wrappedB64 = prefs.getString(KEY_WRAPPED_DB_PASS, null)
        if (!wrappedB64.isNullOrBlank()) {
            val decoded = runCatching { decryptWithKeystore(Base64.decode(wrappedB64, Base64.NO_WRAP)) }.getOrNull()
            if (decoded != null && decoded.size >= 32) return decoded
        }
        val rawPass = ByteArray(32).also { secureRandom.nextBytes(it) }
        val wrapped = encryptWithKeystore(rawPass)
        prefs.edit().putString(KEY_WRAPPED_DB_PASS, Base64.encodeToString(wrapped, Base64.NO_WRAP)).apply()
        return rawPass
    }

    private fun isPlaintextSqliteFile(file: File): Boolean {
        if (!file.exists() || file.length() < SQLITE_PLAIN_HEADER.size) return false
        val header = ByteArray(SQLITE_PLAIN_HEADER.size)
        FileInputStream(file).use { it.read(header) }
        return header.contentEquals(SQLITE_PLAIN_HEADER)
    }

    /**
     * Seamlessly upgrades an existing unencrypted cardlink.db to SQLCipher AES-256 encryption
     * in place using sqlcipher_export(), preserving 100% of existing user data.
     */
    fun migratePlaintextDbIfNeeded(context: Context, dbName: String, passphrase: ByteArray) {
        ensureSqlCipherLoaded()
        val dbFile = context.getDatabasePath(dbName)
        if (!isPlaintextSqliteFile(dbFile)) return

        val tempEncrypted = File(dbFile.parentFile, "${dbName}_enc_tmp")
        if (tempEncrypted.exists()) tempEncrypted.delete()

        val hexKey = passphrase.joinToString("") { "%02x".format(it) }
        var plainDb: SQLiteDatabase? = null
        try {
            plainDb = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                ByteArray(0),
                null,
                SQLiteDatabase.OPEN_READWRITE,
                null
            )
            // Preserve user_version (Room schema version)
            var currentUserVersion = 8
            plainDb.rawQuery("PRAGMA user_version;", null).use { c ->
                if (c.moveToFirst()) currentUserVersion = c.getInt(0)
            }
            plainDb.execSQL("ATTACH DATABASE '${tempEncrypted.absolutePath}' AS encrypted KEY \"x'$hexKey'\";")
            plainDb.execSQL("SELECT sqlcipher_export('encrypted');")
            plainDb.execSQL("PRAGMA encrypted.user_version = $currentUserVersion;")
            plainDb.execSQL("DETACH DATABASE encrypted;")
            plainDb.close()
            plainDb = null

            // Atomically replace plaintext DB and remove old WAL/SHM journal files
            if (tempEncrypted.exists() && tempEncrypted.length() > 0L) {
                File(dbFile.parentFile, "$dbName-wal").delete()
                File(dbFile.parentFile, "$dbName-shm").delete()
                File(dbFile.parentFile, "$dbName-journal").delete()
                if (dbFile.delete()) {
                    tempEncrypted.renameTo(dbFile)
                }
            }
        } catch (_: Exception) {
            runCatching { plainDb?.close() }
            if (tempEncrypted.exists()) tempEncrypted.delete()
            // Keep original DB intact if migration failed so no data is ever lost
        }
    }

    // =========================================================================
    // ENCRYPTED IMAGE VAULT (.clenc files — AES-256-GCM at rest, decrypted in RAM)
    // =========================================================================

    fun isEncryptedVaultFile(file: File): Boolean {
        if (!file.exists() || file.length() < VAULT_FILE_MAGIC.size + 14) return false
        val magic = ByteArray(VAULT_FILE_MAGIC.size)
        FileInputStream(file).use { it.read(magic) }
        return magic.contentEquals(VAULT_FILE_MAGIC)
    }

    fun saveEncryptedBitmap(
        context: Context,
        bitmap: Bitmap,
        subFolder: String,
        prefix: String,
        quality: Int = 90
    ): String {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        val plainBytes = baos.toByteArray()
        val uriStr = saveEncryptedBytes(context, plainBytes, subFolder, prefix)
        plainBytes.fill(0)
        return uriStr
    }

    fun saveEncryptedBytes(
        context: Context,
        plainBytes: ByteArray,
        subFolder: String,
        prefix: String
    ): String {
        val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
        val outFile = File(dir, "${prefix}_${System.currentTimeMillis()}_${(100..999).random()}.clenc")
        val encrypted = encryptWithKeystore(plainBytes)
        FileOutputStream(outFile).use { out ->
            out.write(VAULT_FILE_MAGIC)
            out.write(encrypted)
            out.flush()
        }
        return Uri.fromFile(outFile).toString()
    }

    /**
     * Reads bytes from either an encrypted .clenc vault file (decrypted in RAM) or a legacy plain .jpg file.
     */
    fun readDecryptedBytes(context: Context, uriString: String?): ByteArray? {
        if (uriString.isNullOrBlank()) return null
        return runCatching {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") {
                val f = File(uri.path ?: return null)
                if (!f.exists()) return null
                readDecryptedBytesFromFile(f)
            } else {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }
        }.getOrNull()
    }

    fun readDecryptedBytesFromFile(file: File): ByteArray? {
        if (!file.exists()) return null
        return runCatching {
            val raw = file.readBytes()
            if (raw.size > VAULT_FILE_MAGIC.size + 13 &&
                raw[0] == VAULT_FILE_MAGIC[0] &&
                raw[1] == VAULT_FILE_MAGIC[1] &&
                raw[2] == VAULT_FILE_MAGIC[2] &&
                raw[3] == VAULT_FILE_MAGIC[3]
            ) {
                decryptWithKeystore(raw.copyOfRange(VAULT_FILE_MAGIC.size, raw.size))
            } else {
                raw
            }
        }.getOrNull()
    }

    fun decodeVaultBitmap(context: Context, uriString: String?): Bitmap? {
        val bytes = readDecryptedBytes(context, uriString) ?: return null
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
    }

    fun isVaultActive(context: Context): Boolean {
        val dbFile = context.getDatabasePath("cardlink.db")
        return dbFile.exists() && !isPlaintextSqliteFile(dbFile)
    }
}
