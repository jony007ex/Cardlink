package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayInputStream
import android.net.Uri
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.LruCache
import net.zetetic.database.sqlcipher.SQLiteDatabase
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultCryptoManager {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    const val CURRENT_KEY_VERSION = 1
    private const val MASTER_KEY_ALIAS = "cardlink_vault_master_aes256_v1"
    private const val VAULT_PREFS = "cardlink_vault_crypto_prefs"
    private const val KEY_WRAPPED_DB_PASS = "wrapped_sqlcipher_passphrase_v1"

    private val VAULT_FILE_MAGIC = byteArrayOf('C'.code.toByte(), 'L'.code.toByte(), 'V'.code.toByte(), '1'.code.toByte())
    private val SQLITE_PLAIN_HEADER = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
    private val secureRandom = SecureRandom()

    @Volatile
    private var sqlCipherLoaded = false

    fun ensureSqlCipherLoaded(): Boolean {
        if (sqlCipherLoaded) return true
        return synchronized(this) {
            if (!sqlCipherLoaded) {
                sqlCipherLoaded = runCatching {
                    System.loadLibrary("sqlcipher")
                    true
                }.getOrDefault(false)
            }
            sqlCipherLoaded
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getEntry(MASTER_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val strongBoxSpec = KeyGenParameterSpec.Builder(
                    MASTER_KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setIsStrongBoxBacked(true)
                    .build()
                kg.init(strongBoxSpec)
                return kg.generateKey()
            } catch (_: Exception) {
                // Fallback gracefully to standard TEE-backed AndroidKeyStore
            }
        }
        val fallbackSpec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        kg.init(fallbackSpec)
        return kg.generateKey()
    }

    fun encryptWithKeystore(plainBytes: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val enc = cipher.doFinal(plainBytes)
        val out = ByteArray(1 + iv.size + enc.size)
        out[0] = iv.size.toByte()
        System.arraycopy(iv, 0, out, 1, iv.size)
        System.arraycopy(enc, 0, out, 1 + iv.size, enc.size)
        return out
    }

    fun decryptWithKeystore(blob: ByteArray): ByteArray {
        require(blob.size > 13) { "Malformed encrypted vault payload." }
        val ivLen = blob[0].toInt() and 0xFF
        val iv = blob.copyOfRange(1, 1 + ivLen)
        val enc = blob.copyOfRange(1 + ivLen, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(enc)
    }

    /**
     * Returns a 32-byte random SQLCipher key wrapped by AndroidKeyStore.
     */
    fun getOrCreateDatabasePassphrase(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(VAULT_PREFS, Context.MODE_PRIVATE)
        val wrappedB64 = prefs.getString(KEY_WRAPPED_DB_PASS, null)
        if (!wrappedB64.isNullOrBlank()) {
            val decoded = runCatching { decryptWithKeystore(Base64.decode(wrappedB64, Base64.NO_WRAP)) }.getOrNull()
            if (decoded != null && decoded.size >= 32) return decoded
        }
        val rawPass = ByteArray(32).also { secureRandom.nextBytes(it) }
        val wrapped = encryptWithKeystore(rawPass)
        prefs.edit().putString(KEY_WRAPPED_DB_PASS, Base64.encodeToString(wrapped, Base64.NO_WRAP)).apply()
        return rawPass
    }

    private fun isPlaintextSqliteFile(file: File): Boolean {
        if (!file.exists() || file.length() < SQLITE_PLAIN_HEADER.size) return false
        val header = ByteArray(SQLITE_PLAIN_HEADER.size)
        FileInputStream(file).use { it.read(header) }
        return header.contentEquals(SQLITE_PLAIN_HEADER)
    }

    /**
     * Prepares a verified SupportOpenHelperFactory for SQLCipher.
     * - Uses raw 256-bit key spec ("x'<64-hex>'") consistently for both migration and opening.
     * - If an existing plaintext DB is found, migrates it in place and verifies it opens before replacing.
     * - If anything fails, returns null so Room opens the existing DB safely without crashing.
     */
    fun prepareEncryptedFactory(context: Context, dbName: String): SupportOpenHelperFactory? {
        return runCatching {
            if (!ensureSqlCipherLoaded()) return null
            val rawPass = getOrCreateDatabasePassphrase(context)
            val hexKey = rawPass.joinToString("") { "%02x".format(it) }
            val rawKeySpecBytes = "x'$hexKey'".toByteArray(Charsets.UTF_8)

            val dbFile = context.getDatabasePath(dbName)
            if (dbFile.exists() && isPlaintextSqliteFile(dbFile)) {
                val migrated = migratePlaintextDb(dbFile, dbName, hexKey, rawKeySpecBytes)
                if (!migrated) {
                    // Migration failed — keep plaintext DB and let standard Room open it without crashing
                    return null
                }
            } else if (dbFile.exists()) {
                // Verify existing encrypted DB opens cleanly with rawKeySpecBytes
                if (!canOpenEncryptedDb(dbFile, rawKeySpecBytes)) {
                    // Fallback check: maybe it was created with rawPass directly
                    if (canOpenEncryptedDb(dbFile, rawPass)) {
                        return SupportOpenHelperFactory(rawPass)
                    }
                    return null
                }
            }
            SupportOpenHelperFactory(rawKeySpecBytes)
        }.getOrNull()
    }

    private fun canOpenEncryptedDb(dbFile: File, keyBytes: ByteArray): Boolean {
        var testDb: SQLiteDatabase? = null
        return try {
            testDb = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                keyBytes,
                null,
                SQLiteDatabase.OPEN_READONLY,
                null
            )
            testDb.rawQuery("SELECT count(*) FROM sqlite_master;", null).use { it.moveToFirst() }
            true
        } catch (_: Exception) {
            false
        } finally {
            runCatching { testDb?.close() }
        }
    }

    private fun migratePlaintextDb(
        dbFile: File,
        dbName: String,
        hexKey: String,
        rawKeySpecBytes: ByteArray
    ): Boolean {
        val tempEncrypted = File(dbFile.parentFile, "${dbName}_enc_tmp")
        if (tempEncrypted.exists()) tempEncrypted.delete()

        var plainDb: SQLiteDatabase? = null
        return try {
            plainDb = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                ByteArray(0),
                null,
                SQLiteDatabase.OPEN_READWRITE,
                null
            )
            var currentUserVersion = 8
            plainDb.rawQuery("PRAGMA user_version;", null).use { c ->
                if (c.moveToFirst()) currentUserVersion = c.getInt(0)
            }
            plainDb.execSQL("ATTACH DATABASE '${tempEncrypted.absolutePath}' AS encrypted KEY \"x'$hexKey'\";")
            plainDb.rawQuery("SELECT sqlcipher_export('encrypted');", null).use { it.moveToFirst() }
            plainDb.execSQL("PRAGMA encrypted.user_version = $currentUserVersion;")
            plainDb.execSQL("DETACH DATABASE encrypted;")
            plainDb.close()
            plainDb = null

            // Verify the new encrypted file actually opens with rawKeySpecBytes before touching the original DB!
            if (tempEncrypted.exists() && tempEncrypted.length() > 0L && canOpenEncryptedDb(tempEncrypted, rawKeySpecBytes)) {
                File(dbFile.parentFile, "$dbName-wal").delete()
                File(dbFile.parentFile, "$dbName-shm").delete()
                File(dbFile.parentFile, "$dbName-journal").delete()
                if (dbFile.delete() && tempEncrypted.renameTo(dbFile)) {
                    true
                } else {
                    false
                }
            } else {
                tempEncrypted.delete()
                false
            }
        } catch (_: Exception) {
            runCatching { plainDb?.close() }
            if (tempEncrypted.exists()) tempEncrypted.delete()
            false
        }
    }

    // =========================================================================
    // ENCRYPTED IMAGE VAULT (.clenc files — AES-256-GCM at rest, decrypted in RAM)
    // =========================================================================

    fun saveEncryptedBitmap(
        context: Context,
        bitmap: Bitmap,
        subFolder: String,
        prefix: String,
        quality: Int = 90
    ): String {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        val plainBytes = baos.toByteArray()
        val uriStr = saveEncryptedBytes(context, plainBytes, subFolder, prefix)
        plainBytes.fill(0)
        return uriStr
    }

    fun saveEncryptedBytes(
        context: Context,
        plainBytes: ByteArray,
        subFolder: String,
        prefix: String
    ): String {
        val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
        val outFile = File(dir, "${prefix}_${System.currentTimeMillis()}_${(100..999).random()}.clenc")
        val encrypted = encryptWithKeystore(plainBytes)
        FileOutputStream(outFile).use { out ->
            out.write(VAULT_FILE_MAGIC)
            out.write(encrypted)
            out.flush()
        }
        return Uri.fromFile(outFile).toString()
    }

    fun readDecryptedBytes(context: Context, uriString: String?): ByteArray? {
        if (uriString.isNullOrBlank()) return null
        return runCatching {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "file") {
                val f = File(uri.path ?: return null)
                if (!f.exists()) return null
                readDecryptedBytesFromFile(f)
            } else {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }
        }.getOrNull()
    }

    fun readDecryptedBytesFromFile(file: File): ByteArray? {
        if (!file.exists()) return null
        return runCatching {
            val raw = file.readBytes()
            if (raw.size > VAULT_FILE_MAGIC.size + 13 &&
                raw[0] == VAULT_FILE_MAGIC[0] &&
                raw[1] == VAULT_FILE_MAGIC[1] &&
                raw[2] == VAULT_FILE_MAGIC[2] &&
                raw[3] == VAULT_FILE_MAGIC[3]
            ) {
                decryptWithKeystore(raw.copyOfRange(VAULT_FILE_MAGIC.size, raw.size))
            } else {
                raw
            }
        }.getOrNull()
    }

    private val vaultBitmapCache: LruCache<String, Bitmap> by lazy {
        val maxKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        val cacheKb = (maxKb / 12).coerceIn(4096, 24576)
        object : LruCache<String, Bitmap>(cacheKb) {
            override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
        }
    }

    /**
     * Immediately invalidates all cached resolutions for a given image URI (used on crop revision bump or image replace).
     */
    fun evictFromCache(uriString: String?) {
        if (uriString.isNullOrBlank()) return
        val prefix = "${uriString}_"
        runCatching {
            vaultBitmapCache.snapshot().keys
                .filter { it == uriString || it.startsWith(prefix) }
                .forEach { vaultBitmapCache.remove(it) }
        }
    }

    /**
     * Decodes a vault (.clenc) or local file image in RAM, normalizes EXIF orientation into
     * canonical upright coordinates, and caches keyed by (uri + resolution + optional revision).
     */
    /**
     * Decodes a fresh, uncached EXIF-normalized Bitmap that the caller owns and may safely `.recycle()`
     * (used by PDF/Image export and off-screen barcode decoders without invalidating UI cache).
     */
    fun decodeVaultBitmapUncached(
        context: Context,
        uriString: String?,
        maxEdgePx: Int = 1800
    ): Bitmap? {
        if (uriString.isNullOrBlank()) return null
        val bytes = readDecryptedBytes(context, uriString) ?: return null
        return decodeNormalizedBitmapBytes(bytes, maxEdgePx)
    }

    private fun decodeNormalizedBitmapBytes(bytes: ByteArray, maxEdgePx: Int): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val srcW = bounds.outWidth
        val srcH = bounds.outHeight
        if (srcW <= 0 || srcH <= 0) return@runCatching null

        var sample = 1
        while (maxOf(srcW / sample, srcH / sample) > maxEdgePx) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        val rawBmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return@runCatching null

        val rotDeg = runCatching {
            ByteArrayInputStream(bytes).use { bis ->
                when (ExifInterface(bis).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            }
        }.getOrDefault(0f)

        if (rotDeg != 0f) {
            val m = Matrix().apply { postRotate(rotDeg) }
            val upright = Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, m, true)
            if (upright !== rawBmp) rawBmp.recycle()
            upright
        } else {
            rawBmp
        }
    }.getOrNull()

    fun decodeVaultBitmap(
        context: Context,
        uriString: String?,
        maxEdgePx: Int = 1200,
        cacheBustKey: String = ""
    ): Bitmap? {
        if (uriString.isNullOrBlank()) return null
        val cacheKey = if (cacheBustKey.isBlank()) "${uriString}_$maxEdgePx" else "${uriString}_${maxEdgePx}_$cacheBustKey"
        vaultBitmapCache.get(cacheKey)?.takeIf { !it.isRecycled }?.let { return it }

        val bytes = readDecryptedBytes(context, uriString) ?: return null
        val decoded = decodeNormalizedBitmapBytes(bytes, maxEdgePx)

        if (decoded != null) {
            vaultBitmapCache.put(cacheKey, decoded)
        }
        return decoded
    }

    fun isVaultActive(context: Context): Boolean {
        val dbFile = context.getDatabasePath("cardlink.db")
        return dbFile.exists() && !isPlaintextSqliteFile(dbFile)
    }


    fun isStrongBoxSupported(context: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_STRONGBOX_KEYSTORE)

    fun isHardwareKeystoreAvailable(): Boolean = runCatching {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        ks.containsAlias(MASTER_KEY_ALIAS)
    }.getOrDefault(false)
}
