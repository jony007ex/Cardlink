package com.cardlink.app.util

import android.graphics.Bitmap
import android.graphics.Color
import android.content.Context
import android.graphics.Rect
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.MultiFormatWriter
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object LoyaltyCodeHelper {

    val SUPPORTED_1D_FORMATS = listOf(
        "CODE_128",
        "CODE_39",
        "EAN_13",
        "EAN_8",
        "UPC_A",
        "UPC_E",
        "ITF",
        "CODABAR"
    )

    fun mlKitFormatToName(mlKitFormat: Int): String? = when (mlKitFormat) {
        Barcode.FORMAT_CODE_128 -> "CODE_128"
        Barcode.FORMAT_CODE_39 -> "CODE_39"
        Barcode.FORMAT_EAN_13 -> "EAN_13"
        Barcode.FORMAT_EAN_8 -> "EAN_8"
        Barcode.FORMAT_UPC_A -> "UPC_A"
        Barcode.FORMAT_UPC_E -> "UPC_E"
        Barcode.FORMAT_ITF -> "ITF"
        Barcode.FORMAT_CODABAR -> "CODABAR"
        Barcode.FORMAT_QR_CODE -> "QR_CODE"
        else -> null
    }

    fun formatDisplayName(formatName: String): String = when (formatName.uppercase()) {
        "CODE_128" -> "Code 128"
        "CODE_39" -> "Code 39"
        "EAN_13" -> "EAN-13"
        "EAN_8" -> "EAN-8"
        "UPC_A" -> "UPC-A"
        "UPC_E" -> "UPC-E"
        "ITF" -> "ITF"
        "CODABAR" -> "Codabar"
        "QR_CODE" -> "QR Code"
        else -> formatName
    }

    private fun nameToZxingFormat(formatName: String): BarcodeFormat? = when (formatName.uppercase()) {
        "CODE_128" -> BarcodeFormat.CODE_128
        "CODE_39" -> BarcodeFormat.CODE_39
        "EAN_13" -> BarcodeFormat.EAN_13
        "EAN_8" -> BarcodeFormat.EAN_8
        "UPC_A" -> BarcodeFormat.UPC_A
        "UPC_E" -> BarcodeFormat.UPC_E
        "ITF" -> BarcodeFormat.ITF
        "CODABAR" -> BarcodeFormat.CODABAR
        else -> null
    }

    /**
     * Re-generates a crisp, high-contrast 1D barcode directly from the stored format + exact payload.
     * Never guesses an unsupported format or fabricates data; returns null if encoding fails.
     */
    fun generateBarcodeBitmap(
        payload: String,
        formatName: String,
        widthPx: Int = 960,
        heightPx: Int = 320
    ): Bitmap? {
        if (payload.isBlank() || formatName.isBlank()) return null
        val zxingFormat = nameToZxingFormat(formatName) ?: return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.MARGIN to 12,
                EncodeHintType.CHARACTER_SET to "UTF-8"
            )
            val matrix = MultiFormatWriter().encode(payload, zxingFormat, widthPx, heightPx, hints)
            val w = matrix.width
            val h = matrix.height
            val pixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, w, 0, 0, w, h)
            }
        }.getOrNull()
    }

    /**
     * Re-generates a clean, high-contrast QR Code from the exact verbatim stored QR payload.
     */
    fun generateQrBitmap(
        payload: String,
        sizePx: Int = 640
    ): Bitmap? {
        if (payload.isBlank()) return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.MARGIN to 2
            )
            val matrix = MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val w = matrix.width
            val h = matrix.height
            val pixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, w, 0, 0, w, h)
            }
        }.getOrNull()
    }

    fun maskCardNumber(raw: String): String {
        val clean = raw.trim()
        if (clean.length <= 4) return clean
        return "•••• ${clean.takeLast(4)}"
    }

    fun verifyCodeBitmap(bitmap: Bitmap?, expectedPayload: String): Boolean {
        if (bitmap == null || expectedPayload.isBlank()) return false
        return runCatching {
            val w = bitmap.width
            val h = bitmap.height
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            val source = RGBLuminanceSource(w, h, pixels)
            val binary = BinaryBitmap(HybridBinarizer(source))
            val hints = mapOf(DecodeHintType.TRY_HARDER to true)
            MultiFormatReader().decode(binary, hints).text == expectedPayload
        }.getOrDefault(false)
    }


    data class DetectedLoyaltyCode(
        val rawValue: String,
        val formatName: String,
        val isQr: Boolean
    )

    data class ExtractedLoyaltyCardHints(
        val barcode: DetectedLoyaltyCode? = null,
        val qr: DetectedLoyaltyCode? = null,
        val suggestedBrand: String = "",
        val suggestedNumber: String = ""
    )

    /**
     * Multi-pass on-device Barcode & QR detector for Gallery photos and captured card images.
     * Pass 1: Full bitmap upright
     * Pass 2: Center + 4 overlapping quadrant crops upscaled 2x (catches small dense QRs / fine 1D barcodes)
     * Pass 3: 90, 180, 270 degree rotations
     */
    suspend fun detectCodesFromBitmap(
        bitmap: Bitmap,
        mode: String = "AUTO" // "AUTO", "BARCODE", "QR"
    ): List<DetectedLoyaltyCode> = withContext(Dispatchers.IO) {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_QR_CODE,
                Barcode.FORMAT_CODE_128,
                Barcode.FORMAT_CODE_39,
                Barcode.FORMAT_EAN_13,
                Barcode.FORMAT_EAN_8,
                Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_UPC_E,
                Barcode.FORMAT_ITF,
                Barcode.FORMAT_CODABAR
            )
            .build()
        val scanner = BarcodeScanning.getClient(options)

        fun mapMatches(barcodes: List<Barcode>): List<DetectedLoyaltyCode> = barcodes.mapNotNull { bc ->
            val raw = bc.rawValue?.trim().orEmpty()
            val fmt = mlKitFormatToName(bc.format) ?: return@mapNotNull null
            if (raw.isBlank()) return@mapNotNull null
            val isQr = fmt == "QR_CODE"
            val allowed = when (mode.uppercase()) {
                "QR" -> isQr
                "BARCODE" -> !isQr
                else -> true
            }
            if (allowed) DetectedLoyaltyCode(raw, fmt, isQr) else null
        }.distinctBy { "${it.formatName}:${it.rawValue}" }

        try {
            // Pass 1: Direct full bitmap
            val p1 = runCatching { scanner.process(InputImage.fromBitmap(bitmap, 0)).await() }.getOrDefault(emptyList())
            val m1 = mapMatches(p1)
            if (m1.isNotEmpty()) return@withContext m1

            // Pass 2: Center & 4 quadrant crops upscaled 2x (handles dense small QRs & narrow barcodes on full card shots)
            val w = bitmap.width
            val h = bitmap.height
            val rects = listOf(
                Rect(w / 6, h / 6, (w * 5) / 6, (h * 5) / 6),
                Rect(0, 0, (w * 2) / 3, (h * 2) / 3),
                Rect(w / 3, 0, w, (h * 2) / 3),
                Rect(0, h / 3, (w * 2) / 3, h),
                Rect(w / 3, h / 3, w, h)
            )
            for (r in rects) {
                val cw = r.width().coerceAtLeast(1)
                val ch = r.height().coerceAtLeast(1)
                if (r.left + cw <= w && r.top + ch <= h) {
                    val crop = Bitmap.createBitmap(bitmap, r.left, r.top, cw, ch)
                    val targetW = (cw * 2).coerceAtMost(2400)
                    val targetH = (ch * 2).coerceAtMost(2400)
                    val scaled = Bitmap.createScaledBitmap(crop, targetW, targetH, true)
                    val hits = runCatching { scanner.process(InputImage.fromBitmap(scaled, 0)).await() }.getOrDefault(emptyList())
                    if (scaled !== crop) scaled.recycle()
                    crop.recycle()
                    val mapped = mapMatches(hits)
                    if (mapped.isNotEmpty()) return@withContext mapped
                }
            }

            // Pass 3: Explicit 90 / 180 / 270 degree rotations
            for (deg in listOf(90, 180, 270)) {
                val hits = runCatching { scanner.process(InputImage.fromBitmap(bitmap, deg)).await() }.getOrDefault(emptyList())
                val mapped = mapMatches(hits)
                if (mapped.isNotEmpty()) return@withContext mapped
            }

            emptyList()
        } finally {
            runCatching { scanner.close() }
        }
    }

    suspend fun detectCodesFromUri(
        context: Context,
        uri: Uri,
        mode: String = "AUTO"
    ): List<DetectedLoyaltyCode> = withContext(Dispatchers.IO) {
        val bmp = if (uri.toString().endsWith(".clenc", ignoreCase = true)) {
            VaultCryptoManager.decodeVaultBitmapUncached(context, uri.toString(), 2200)
        } else {
            ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2200)
        } ?: return@withContext emptyList()
        try {
            detectCodesFromBitmap(bmp, mode)
        } finally {
            runCatching { bmp.recycle() }
        }
    }

    /**
     * Automatically inspects a captured Loyalty Card photo for printed Barcode/QR codes
     * and optional brand/membership number hints so the user doesn't have to scan twice.
     */
    suspend fun analyzeCardPhotoHints(
        bitmap: Bitmap,
        runTextOcr: Boolean = true
    ): ExtractedLoyaltyCardHints = withContext(Dispatchers.IO) {
        val codes = detectCodesFromBitmap(bitmap, "AUTO")
        val barcode = codes.firstOrNull { !it.isQr }
        val qr = codes.firstOrNull { it.isQr }

        var suggestedBrand = ""
        var suggestedNumber = barcode?.rawValue.orEmpty()

        if (runTextOcr) {
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            runCatching {
                val visionText = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
                val lines = visionText.textBlocks.flatMap { it.lines }
                    .map { it.text.trim() to (it.boundingBox?.height() ?: 0) }
                    .filter { it.first.length >= 2 }

                // Largest non-numeric line is typically the brand/store title
                val brandCandidate = lines
                    .filter { (t, _) ->
                        t.count { it.isLetter() } >= 2 &&
                            t.count { it.isDigit() } <= 2 &&
                            !t.contains("member", true) &&
                            !t.contains("loyalty", true) &&
                            !t.contains("rewards", true) &&
                            !t.contains("privilege", true) &&
                            t.length <= 32
                    }
                    .maxByOrNull { it.second }?.first.orEmpty()
                if (brandCandidate.isNotBlank()) suggestedBrand = brandCandidate

                // Look for an 8-19 digit membership/card number if barcode wasn't found
                if (suggestedNumber.isBlank()) {
                    val numRegex = Regex("""(?:\d[\s-]?){8,19}""")
                    for ((txt, _) in lines) {
                        val m = numRegex.find(txt)
                        if (m != null) {
                            val cleanNum = m.value.filter { it.isDigit() }
                            if (cleanNum.length in 8..19) {
                                suggestedNumber = cleanNum
                                break
                            }
                        }
                    }
                }
            }
            runCatching { recognizer.close() }
        }

        ExtractedLoyaltyCardHints(
            barcode = barcode,
            qr = qr,
            suggestedBrand = suggestedBrand,
            suggestedNumber = suggestedNumber
        )
    }
}
