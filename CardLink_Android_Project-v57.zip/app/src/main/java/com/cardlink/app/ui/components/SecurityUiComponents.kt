package com.cardlink.app.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.cardlink.app.R
import com.cardlink.app.util.VaultCryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private tailrec fun Context.findActivityForSecurity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForSecurity()
    else -> null
}

/**
 * Renders both AES-256-GCM encrypted .clenc vault images (decrypted exclusively in RAM)
 * and legacy unencrypted .jpg / content:// URIs seamlessly.
 */
@Composable
fun VaultImage(
    uriString: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    maxEdgePx: Int = 1024,
    cacheBustKey: String = ""
) {
    if (uriString.isNullOrBlank()) return
    val context = LocalContext.current
    val isEncryptedVault = uriString.endsWith(".clenc", ignoreCase = true)

    if (!isEncryptedVault) {
        val parsedUri = remember(uriString) { runCatching { Uri.parse(uriString) }.getOrNull() }
        if (parsedUri != null) {
            val imageModel = remember(parsedUri, cacheBustKey) {
                if (cacheBustKey.isBlank()) parsedUri
                else ImageRequest.Builder(context)
                    .data(parsedUri)
                    .memoryCacheKey("${parsedUri}_$cacheBustKey")
                    .diskCacheKey("${parsedUri}_$cacheBustKey")
                    .build()
            }
            AsyncImage(
                model = imageModel,
                contentDescription = contentDescription,
                contentScale = contentScale,
                modifier = modifier
            )
        } else {
            Box(
                modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.BrokenImage, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    } else {
        val loadState by produceState<Pair<Boolean, Bitmap?>>(
            initialValue = false to null,
            key1 = uriString,
            key2 = maxEdgePx,
            key3 = cacheBustKey
        ) {
            val bmp = withContext(Dispatchers.IO) {
                VaultCryptoManager.decodeVaultBitmap(context, uriString, maxEdgePx, cacheBustKey)
            }
            value = true to bmp
        }
        val (done, bmp) = loadState
        if (bmp != null && !bmp.isRecycled) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = contentDescription,
                contentScale = contentScale,
                modifier = modifier
            )
        } else if (!done) {
            Box(
                modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
            }
        } else {
            Box(
                modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.BrokenImage, contentDescription = "Unavailable image", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/**
 * Applies FLAG_SECURE + Android 14+ (API 34) Activity.ScreenCaptureCallback detection.
 * If a screen capture event is detected, displays an immediate privacy shield overlay.
 */
@Composable
fun ScreenPrivacyGuard(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    var captureDetected by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val activity = context.findActivityForSecurity()
        val window = activity?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        var captureCallback: Activity.ScreenCaptureCallback? = null
        if (activity != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val cb = Activity.ScreenCaptureCallback {
                captureDetected = true
                Toast.makeText(
                    context,
                    context.getString(R.string.security_capture_detected_toast),
                    Toast.LENGTH_LONG
                ).show()
            }
            captureCallback = cb
            runCatching {
                activity.registerScreenCaptureCallback(activity.mainExecutor, cb)
            }
        }

        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            if (activity != null && captureCallback != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                runCatching { activity.unregisterScreenCaptureCallback(captureCallback) }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        content()

        if (captureDetected) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.97f))
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.PrivacyTip, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                        Text(
                            text = stringResource(R.string.security_capture_shield_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = stringResource(R.string.security_capture_shield_msg),
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { captureDetected = false },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(stringResource(R.string.security_capture_resume), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
