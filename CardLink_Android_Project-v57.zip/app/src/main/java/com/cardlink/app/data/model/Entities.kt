package com.cardlink.app.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class CardTemplate {
    EXECUTIVE_NAVY,
    MINIMAL_IVORY,
    CHARCOAL_GOLD,
    MODERN_SPLIT,
    MODERN_MINIMAL,
    FUTURISTIC_PROFESSIONAL
}

enum class FollowUpChannel {
    GENERAL,
    WHATSAPP
}

enum class WhatsAppScheduleMode {
    REMINDER_TO_SEND,
    AUTOMATIC_SEND
}

enum class FollowUpStatus {
    PENDING,
    READY_TO_SEND,
    SENT_CONFIRMED,
    COMPLETED,
    CANCELLED
}

@Serializable
@Entity(tableName = "my_cards")
data class BusinessCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileTitle: String = "Executive Profile",
    val isDefault: Boolean = true,
    val fullName: String = "",
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val backHeading: String = "",
    val backMessage: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val publicCardUrl: String = "",
    val profilePhotoUri: String? = null,
    val companyLogoUri: String? = null,
    val template: CardTemplate = CardTemplate.EXECUTIVE_NAVY,
    val selectedTemplateId: String = "executive_navy_gold:v1",
    val primaryColorHex: Long = 0xFF0A192F,
    val secondaryColorHex: Long = 0xFF112240,
    val accentColorHex: Long = 0xFFD4AF37,
    val textColorHex: Long = 0xFFFFFFFF,
    val buttonColorHex: Long = 0xFFD4AF37,
    val iconColorHex: Long = 0xFFD4AF37,
    val cardGradientEndHex: Long = 0xFF172A46,
    val fontFamilyName: String = "Serif",
    val cornerRadiusDp: Int = 20,
    val sharePhone: Boolean = true,
    val shareWhatsapp: Boolean = true,
    val shareEmail: Boolean = true,
    val shareAddress: Boolean = true,
    val shareSocials: Boolean = true
) {
    fun resolveNfcShareUrl(): String {
        val candidate = listOf(publicCardUrl, linkedInUrl, website, facebookUrl)
            .firstOrNull { it.isNotBlank() }
            ?.trim()
            ?: "https://cardlink.app"
        return if (candidate.startsWith("http://", true) || candidate.startsWith("https://", true)) {
            candidate
        } else {
            "https://$candidate"
        }
    }

    fun sanitizedForSharing(): BusinessCardEntity = copy(
        phone = if (sharePhone) phone else "",
        whatsapp = if (shareWhatsapp) whatsapp else "",
        email = if (shareEmail) email else "",
        officeAddress = if (shareAddress) officeAddress else "",
        latitude = if (shareAddress) latitude else null,
        longitude = if (shareAddress) longitude else null,
        linkedInUrl = if (shareSocials) linkedInUrl else "",
        facebookUrl = if (shareSocials) facebookUrl else "",
        otherSocialUrl = if (shareSocials) otherSocialUrl else "",
        profilePhotoUri = null,
        companyLogoUri = null
    )
}

@Serializable
@Entity(
    tableName = "saved_contacts",
    indices = [
        Index(value = ["isFavorite"], name = "idx_saved_contacts_favorite"),
        Index(value = ["savedAtTimestamp"], name = "idx_saved_contacts_saved_at"),
        Index(value = ["categoryTag"], name = "idx_saved_contacts_category")
    ]
)
data class SavedContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val profilePhotoUri: String? = null,
    val backPhotoUri: String? = null,
    val notes: String = "",
    val receivedVia: String = "QR Code",
    val categoryTag: String = "General",
    val alternateName: String = "",
    val alternateCompany: String = "",
    val meetingContext: String = "",
    val introducedBy: String = "",
    val discussionTopic: String = "",
    val isFavorite: Boolean = false,
    val dateOfBirthIso: String? = null,
    val linkedDeviceContactId: String? = null,
    val deviceContactSyncState: String = "NOT_SYNCED",
    val lastDeviceContactSyncAt: Long = 0L,
    val lastContactedTimestamp: Long = 0L,
    val rawOcrText: String = "",
    val frontOriginalPhotoUri: String? = null,
    val backOriginalPhotoUri: String? = null,
    val frontCropMetaJson: String = "",
    val backCropMetaJson: String = "",
    val frontCropRevision: Int = 0,
    val backCropRevision: Int = 0,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "share_history")
data class ShareHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardProfileTitle: String,
    val method: String,
    val recipientInfo: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "follow_up_items",
    indices = [
        Index(value = ["contactId"], name = "idx_follow_up_contact"),
        Index(value = ["dueAtTimestamp"], name = "idx_follow_up_due_at"),
        Index(value = ["isCompleted"], name = "idx_follow_up_completed")
    ]
)
data class FollowUpEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactId: Long,
    val contactName: String,
    val companyName: String = "",
    val title: String,
    val notes: String = "",
    val dueAtTimestamp: Long,
    val isCompleted: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val alarmEnabled: Boolean = false,
    val notificationEnabled: Boolean = true,
    val reminderOffsetMinutes: Int = 0,
    val channel: String = FollowUpChannel.GENERAL.name,
    val whatsappNumber: String = "",
    val whatsappMessage: String = "",
    val whatsappMode: String = WhatsAppScheduleMode.REMINDER_TO_SEND.name,
    val status: String = FollowUpStatus.PENDING.name,
    val followUpUuid: String = java.util.UUID.randomUUID().toString(),
    val deviceCalendarId: Long? = null,
    val deviceEventId: Long? = null,
    val lastSyncedTimestamp: Long = 0L,
    val calendarSyncStatus: String = "NONE",
    val followUpType: String = "GENERAL",
    val meetingMethod: String = "IN_PERSON",
    val meetingLink: String = "",
    val meetingAgenda: String = ""
)
@Serializable
@Entity(
    tableName = "loyalty_cards",
    indices = [
        Index(value = ["isFavorite"], name = "idx_loyalty_cards_favorite"),
        Index(value = ["lastUsedTimestamp"], name = "idx_loyalty_cards_last_used")
    ]
)
data class LoyaltyCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val brandName: String,
    val cardNickname: String = "",
    val cardNumber: String = "",
    val cardholderName: String = "",
    val notes: String = "",
    val barcodeValue: String = "",
    val barcodeFormat: String = "",
    val qrPayload: String = "",
    val frontPhotoUri: String? = null,
    val backPhotoUri: String? = null,
    val isFavorite: Boolean = false,
    val lastUsedTimestamp: Long = 0L,
    val usageCount: Int = 0,
    val expiryDateIso: String? = null,
    val pointsBalance: String = "",
    val membershipTier: String = "",
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)
enum class IdDocumentType {
    NATIONAL_ID,
    PASSPORT,
    DRIVING_LICENCE,
    EMPLOYEE_ID,
    OFFICE_ID,
    STUDENT_ID,
    PROFESSIONAL_ID,
    MEMBERSHIP_ID,
    ACCESS_CARD,
    TRADE_LICENCE,
    TIN_CERTIFICATE,
    BIN_VAT_CERTIFICATE,
    PROFESSIONAL_LICENCE,
    VENDOR_ENLISTMENT,
    INSURANCE_CERTIFICATE,
    BUSINESS_DOCUMENT,
    CUSTOM
}

@Serializable
@Entity(tableName = "my_id_documents")
data class IdDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val documentName: String,
    val documentType: String = IdDocumentType.NATIONAL_ID.name,
    val customTypeName: String = "",
    val extractedText: String = "",
    val notes: String = "",
    val expiryDateIso: String? = null,
    val expiryRemindersEnabled: Boolean = true,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "my_id_pages",
    indices = [
        Index(value = ["documentUuid"], name = "idx_my_id_pages_doc_uuid")
    ]
)
data class IdDocumentPageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentUuid: String,
    val pageIndex: Int = 0,
    val pageLabel: String = "Front",
    val imageUri: String,
    val mimeType: String = "image/jpeg"
)
@Serializable
@Entity(tableName = "qr_studio_projects")
data class QrProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val qrType: String = "URL",
    val payload: String,
    val contentFieldsJson: String = "{}",
    val designConfigJson: String = "{}",
    val logoUri: String? = null,
    val isFavorite: Boolean = false,
    val expiryReminderIso: String? = null,
    val isDynamic: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "qr_design_presets")
data class QrDesignPresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val designConfigJson: String = "{}",
    val createdAtTimestamp: Long = System.currentTimeMillis()
)
@Serializable
@Entity(tableName = "qr_scan_history")
data class QrScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val detectedType: String = "TEXT",
    val displayTitle: String = "",
    val rawPayload: String = "",
    val payloadHash: String = "",
    val isSensitive: Boolean = false,
    val isFavorite: Boolean = false,
    val scannedAtTimestamp: Long = System.currentTimeMillis()
)
@Serializable
@Entity(tableName = "security_audit_logs")
data class SecurityAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val eventType: String,
    val featureTag: String,
    val success: Boolean = true,
    val safeDetail: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "secure_notes")
data class SecureNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val category: String = "General",
    val content: String = "",
    val isPinned: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)
@Serializable
@Entity(tableName = "nfc_studio_projects")
data class NfcProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val contentType: String = "URL",
    val payload: String = "",
    val sharingProfileId: String = "BUSINESS",
    val lastWrittenTimestamp: Long = 0L,
    val lastVerified: Boolean = false,
    val isFavorite: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "recycle_bin_items")
data class RecycleBinEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val entityType: String, // CONTACT, LOYALTY_CARD, MY_ID, SECURE_NOTE, QR_PROJECT, NFC_PROJECT
    val displayTitle: String,
    val payloadJson: String,
    val deletedAtTimestamp: Long = System.currentTimeMillis(),
    val expiresAtTimestamp: Long = System.currentTimeMillis() + 30L * 24L * 3600_000L
)
@Serializable
@Entity(tableName = "conference_queue_items")
data class ConferenceQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val eventName: String = "",
    val eventLocation: String = "",
    val encryptedFrontUri: String = "",
    val encryptedBackUri: String? = null,
    val queueStatus: String = "WAITING", // WAITING, PROCESSING, READY, NEEDS_REVIEW, POSSIBLE_DUPLICATE, FAILED
    val parsedContactJson: String = "",
    val suggestedName: String = "",
    val suggestedCompany: String = "",
    val duplicateContactId: Long? = null,
    val duplicateReason: String = "",
    val errorDetail: String = "",
    val capturedAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "pending_send_drafts")
data class PendingDraftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stableUuid: String = java.util.UUID.randomUUID().toString(),
    val contactId: Long = 0L,
    val contactName: String,
    val channel: String = "WHATSAPP", // WHATSAPP, EMAIL, SMS, SHARESHEET
    val recipientAddress: String = "",
    val subject: String = "",
    val messageBody: String = "",
    val attachmentFormat: String = "VCF", // VCF, LINK, QR, HTML, IMAGE
    val status: String = "READY_TO_SEND",
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

@Serializable
data class ArchivedIdDocumentBundle(
    val document: IdDocumentEntity,
    val pages: List<IdDocumentPageEntity> = emptyList()
)
