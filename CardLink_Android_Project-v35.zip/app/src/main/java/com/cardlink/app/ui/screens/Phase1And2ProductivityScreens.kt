package com.cardlink.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================================================================
// 1. CONTACT DATA QUALITY CENTER (Menu -> Insights -> Contact Data Quality)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDataQualityScreen(
    contacts: List<SavedContactEntity>,
    followUps: List<FollowUpEntity>,
    onOpenContacts: () -> Unit,
    onOpenFollowUps: () -> Unit,
    onMergePair: (SavedContactEntity, SavedContactEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    var showDuplicatesDialog by remember { mutableStateOf(false) }

    val dupPairs = remember(contacts) { SmartDuplicateDetector.findDuplicatePairs(contacts) }
    val missingPhone = remember(contacts) { contacts.count { it.phone.isBlank() } }
    val missingEmail = remember(contacts) { contacts.count { it.email.isBlank() } }
    val missingCompany = remember(contacts) { contacts.count { it.companyName.isBlank() } }
    val missingDesignation = remember(contacts) { contacts.count { it.designation.isBlank() } }
    val contactIdsWithFu = remember(followUps) { followUps.map { it.contactId }.toSet() }
    val withoutFollowUp = remember(contacts, contactIdsWithFu) { contacts.count { it.id !in contactIdsWithFu } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.data_quality_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QualityRowCard("Possible Duplicates", "${dupPairs.size} pair(s) found", "Review") { showDuplicatesDialog = true }
            QualityRowCard("Missing Phone", "$missingPhone contact(s)", "View Contacts", onOpenContacts)
            QualityRowCard("Missing Email", "$missingEmail contact(s)", "View Contacts", onOpenContacts)
            QualityRowCard("Missing Company", "$missingCompany contact(s)", "View Contacts", onOpenContacts)
            QualityRowCard("Missing Designation", "$missingDesignation contact(s)", "View Contacts", onOpenContacts)
            QualityRowCard("Contacts Without Follow-Up", "$withoutFollowUp contact(s)", "Schedule", onOpenFollowUps)
        }
    }

    if (showDuplicatesDialog) {
        SmartDuplicateCenterDialog(
            pairs = dupPairs,
            onMergePair = { merged, del -> onMergePair(merged, del) },
            onDismiss = { showDuplicatesDialog = false }
        )
    }
}

@Composable
private fun QualityRowCard(title: String, countText: String, cta: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                Text(countText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(cta, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
        }
    }
}

// =============================================================================
// 2. SECURE RECYCLE BIN (Settings -> Privacy -> Recently Deleted)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecycleBinScreen(
    items: List<RecycleBinEntity>,
    onRestoreItem: (RecycleBinEntity) -> Unit,
    onDeletePermanently: (RecycleBinEntity) -> Unit,
    onEmptyBin: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var retentionDays by remember { mutableIntStateOf(SharingProfileManager.getRecycleBinRetentionDays(context)) }
    var showEmptyConfirm by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.recycle_bin_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (items.isNotEmpty()) {
                        TextButton(onClick = { showEmptyConfirm = true }) {
                            Text("Empty", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Retention Policy", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(7 to "7 Days", 30 to "30 Days", 0 to "Delete Immediately").forEach { (d, lbl) ->
                            FilterChip(
                                selected = retentionDays == d,
                                onClick = {
                                    retentionDays = d
                                    SharingProfileManager.setRecycleBinRetentionDays(context, d)
                                },
                                label = { Text(lbl, fontSize = 11.5.sp) }
                            )
                        }
                    }
                }
            }

            if (items.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                        Text("Recycle Bin is Empty", fontWeight = FontWeight.Bold)
                        Text("Deleted Contacts, Loyalty Cards, Secure Notes, and QR/NFC projects are held safely here during your retention period.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                items.forEach { item ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(item.displayTitle, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                            Text(
                                "${item.entityType} • Deleted ${fmt.format(Date(item.deletedAtTimestamp))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { onRestoreItem(item) }) { Text("Restore", fontWeight = FontWeight.Bold) }
                                TextButton(onClick = { onDeletePermanently(item) }) {
                                    Text("Delete Permanently", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEmptyConfirm) {
        AlertDialog(
            onDismissRequest = { showEmptyConfirm = false },
            title = { Text("Empty Recycle Bin?", fontWeight = FontWeight.Bold) },
            text = { Text("All ${items.size} item(s) will be permanently removed and cannot be recovered.") },
            confirmButton = {
                Button(
                    onClick = { onEmptyBin(); showEmptyConfirm = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Empty Bin") }
            },
            dismissButton = { TextButton(onClick = { showEmptyConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}

// =============================================================================
// 3. DEVICE MIGRATION ASSISTANT (Settings -> Backup & Export -> Move to a New Device)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceMigrationAssistantScreen(
    onOpenBackupCenter: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val masterInfo = remember { MasterBackupManager.getMasterInfo(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.migration_assistant_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Before Leaving Your Old Device", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    MigrationStepRow(masterInfo.isAccessible, "Master Backup configured (${masterInfo.fileName})")
                    MigrationStepRow(masterInfo.lastUpdatedTimestamp != null, "Latest changes backed up & verified")
                    MigrationStepRow(true, "Keep your backup password ready (if encrypted)")
                    MigrationStepRow(true, "Transfer CardLink_Master.cardlink to your new phone")
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("On Your New Device", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    MigrationStepRow(false, "1. Install CardLink on the new device")
                    MigrationStepRow(false, "2. Open Settings -> Backup & Export -> Restore Backup")
                    MigrationStepRow(false, "3. Select CardLink_Master.cardlink & verify integrity")
                    MigrationStepRow(false, "4. Restore data, rebuild reminders & re-enable Biometric Lock")
                }
            }

            Button(
                onClick = onOpenBackupCenter,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Open Backup & Export", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MigrationStepRow(done: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(
            imageVector = if (done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

// =============================================================================
// 4. MEETING BRIEF + VOICE-TO-CONTACT NOTES (Embedded in ContactDetailScreen)
// =============================================================================

@Composable
fun MeetingBriefAndVoiceNoteCard(
    contact: SavedContactEntity,
    contactFollowUps: List<FollowUpEntity>,
    onAppendNote: (String) -> Unit
) {
    val context = LocalContext.current
    val fmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val nextFollowUp = remember(contactFollowUps) {
        contactFollowUps.filterNot { it.isCompleted }.minByOrNull { it.dueAtTimestamp }
    }

    var pendingTranscript by remember { mutableStateOf<String?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.firstOrNull()?.trim()
            if (!text.isNullOrBlank()) {
                pendingTranscript = text
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Workspaces, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text(stringResource(R.string.meeting_brief_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                }
                TextButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your meeting note for ${contact.fullName}")
                        }
                        runCatching { speechLauncher.launch(intent) }.onFailure {
                            Toast.makeText(context, "On-device speech recognition is unavailable.", Toast.LENGTH_LONG).show()
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Default.Mic, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.voice_note_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (contact.meetingContext.isNotBlank()) {
                Text("Met at: ${contact.meetingContext} (${fmt.format(Date(contact.savedAtTimestamp))})", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("First met: ${fmt.format(Date(contact.savedAtTimestamp))}", style = MaterialTheme.typography.bodySmall)
            }
            if (nextFollowUp != null) {
                Text("Next Follow-Up: ${nextFollowUp.title} (${fmt.format(Date(nextFollowUp.dueAtTimestamp))})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
            if (contact.notes.isNotBlank()) {
                Text("Last Note: ${contact.notes.take(120)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    // Review & Edit Voice Transcript before saving (never auto-saves unreviewed speech!)
    pendingTranscript?.let { initialText ->
        var editable by remember(initialText) { mutableStateOf(initialText) }
        AlertDialog(
            onDismissRequest = { pendingTranscript = null },
            title = { Text("Review Voice Note", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editable,
                    onValueChange = { editable = it },
                    label = { Text("Transcript") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (editable.isNotBlank()) onAppendNote(editable.trim())
                    pendingTranscript = null
                }) { Text("Save as Contact Note") }
            },
            dismissButton = { TextButton(onClick = { pendingTranscript = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}
