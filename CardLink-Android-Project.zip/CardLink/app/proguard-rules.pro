# CardLink ships with minification disabled for maximum reliability.
-keep class com.cardlink.app.data.** { *; }
