package com.cardlink.app

import com.cardlink.app.data.CardData
import com.cardlink.app.data.SocialLink
import com.cardlink.app.util.VCard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VCardTest {
    private val card = CardData(
        fullName = "Md. Mazharul Islam", designation = "AVP, Digital; Banking", company = "Acme, Ltd.", department = "IT",
        phone = "+880 1711-000000", whatsapp = "+8801811000000", email = "m@acme.com",
        address = "Level 5, Gulshan Ave\nDhaka", website = "https://acme.com", linkedin = "https://linkedin.com/in/m",
        facebook = "https://facebook.com/m", otherLinks = listOf(SocialLink("X", "https://x.com/m")),
        bio = "Banking; fintech, digital.", cardUrl = "https://card.acme.com/m", photoBase64 = "A".repeat(400),
    )

    @Test fun roundTrip() = assertEquals(card, VCard.parseAll(VCard.build(card)).single())

    @Test fun linesAreFolded() = assertTrue(VCard.build(card).split("\r\n").all { it.length <= 75 })

    @Test fun multipleCards() = assertEquals(2, VCard.parseAll(VCard.build(card) + VCard.build(card.copy(fullName = "B"))).size)

    @Test fun vcard21() {
        val c = VCard.parseAll("BEGIN:VCARD\nVERSION:2.1\nN:Doe;Jane;;;\nTEL;CELL:+1555\nEND:VCARD").single()
        assertEquals("Jane Doe", c.fullName); assertEquals("+1555", c.phone)
    }

    @Test fun meCard() {
        val c = VCard.parseMeCard("MECARD:N:Doe,John;TEL:+1234;EMAIL:j@d.com;;")!!
        assertEquals("John Doe", c.fullName); assertEquals("j@d.com", c.email)
    }

    @Test fun garbage() { assertTrue(VCard.parseAll("hello").isEmpty()); assertNull(VCard.parseMeCard("https://x.com")) }
}
