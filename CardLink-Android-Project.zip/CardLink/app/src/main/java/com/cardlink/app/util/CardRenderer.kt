package com.cardlink.app.util

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.TextPaint
import android.text.TextUtils
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.ShareField
import com.cardlink.app.data.toCardData
import java.io.OutputStream
import kotlin.math.min

/** Renders a high-resolution, shareable image of the business card. */
object CardRenderer {
    const val W = 1400
    const val H = 800

    fun fontFor(style: String, bold: Boolean): Typeface {
        val base = when (style) { "SANS" -> Typeface.SANS_SERIF; "MONO" -> Typeface.MONOSPACE; else -> Typeface.SERIF }
        return Typeface.create(base, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    fun darken(c: Int, f: Float): Int = Color.argb(
        Color.alpha(c), (Color.red(c) * (1 - f)).toInt(), (Color.green(c) * (1 - f)).toInt(), (Color.blue(c) * (1 - f)).toInt(),
    )

    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun render(p: CardProfile, fields: Set<ShareField>, includeQr: Boolean = true): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val primary = p.primaryColor.toInt(); val accent = p.accentColor.toInt(); val textCol = p.textColor.toInt()
        val data = p.toCardData(fields)
        val wf = W.toFloat(); val hf = H.toFloat()

        c.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, wf, hf), 56f, 56f, Path.Direction.CW) })
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        if (p.backgroundStyle == "SOLID") bg.color = primary
        else bg.shader = LinearGradient(0f, 0f, wf, hf, primary, darken(primary, 0.35f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, bg)
        if (p.backgroundStyle == "PATTERN") {
            val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(accent, 24); strokeWidth = 3f }
            var x = -hf
            while (x < wf) { c.drawLine(x, hf, x + hf, 0f, lp); x += 60f }
        }
        c.drawCircle(wf - 120f, 90f, 300f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(accent, 26) })
        c.drawRect(0f, hf - 14f, wf, hf, Paint().apply { color = accent })

        val photo = if (ShareField.PHOTO in fields) p.photoPath?.let { ImageStore.decodeFile(it, 420) } else null
        val logo = p.logoPath?.let { ImageStore.decodeFile(it, 320) }
        val qr = if (includeQr) runCatching {
            QrCodeGen.generate(VCard.build(data, includePhoto = false), 420, p.qrColor.toInt(), Color.WHITE)
        }.getOrNull() else null

        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = textCol; textSize = 66f; typeface = fontFor(p.fontStyle, true) }
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 38f; typeface = fontFor(p.fontStyle, false) }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(textCol, 220); textSize = 32f; typeface = fontFor(p.fontStyle, false) }
        val infoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(textCol, 235); textSize = 30f; typeface = Typeface.SANS_SERIF }
        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accent; textSize = 22f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); letterSpacing = 0.12f
        }
        val companyLine = listOf(data.company, data.department).filter { it.isNotBlank() }.joinToString("  ·  ")
        val info = buildList {
            if (data.phone.isNotBlank()) add("PHONE" to data.phone)
            if (data.whatsapp.isNotBlank() && data.whatsapp != data.phone) add("WHATSAPP" to data.whatsapp)
            if (data.email.isNotBlank()) add("EMAIL" to data.email)
            if (data.website.isNotBlank()) add("WEB" to Links.display(data.website))
            if (data.linkedin.isNotBlank()) add("LINKEDIN" to Links.display(data.linkedin))
            if (data.address.isNotBlank()) add("OFFICE" to data.address)
        }.take(5)
        val name = data.fullName.ifBlank { "Your Name" }

        when (p.layoutStyle) {
            "CENTERED" -> {
                val cx = wf / 2
                if (photo != null) circleImage(c, photo, cx, 170f, 105f, accent) else initials(c, name, cx, 170f, 105f, accent, primary, p.fontStyle)
                text(c, name, cx, 350f, namePaint, wf - 200, Paint.Align.CENTER)
                text(c, data.designation, cx, 405f, titlePaint, wf - 200, Paint.Align.CENTER)
                text(c, companyLine, cx, 452f, subPaint, wf - 200, Paint.Align.CENTER)
                c.drawRect(cx - 80, 482f, cx + 80, 486f, Paint().apply { color = accent })
                val values = info.map { it.second }
                values.chunked(2).take(3).forEachIndexed { i, row ->
                    text(c, row.joinToString("     •     "), cx, 555f + i * 56f, infoPaint, wf - 520, Paint.Align.CENTER)
                }
                logo?.let { fit(c, it, RectF(60f, 50f, 260f, 190f)) }
                qr?.let { qrBox(c, it, RectF(wf - 250f, hf - 270f, wf - 50f, hf - 70f)) }
            }
            "SPLIT" -> {
                c.drawRect(0f, 0f, 480f, hf, Paint().apply { color = darken(primary, 0.45f) })
                c.drawRect(480f, 0f, 486f, hf, Paint().apply { color = accent })
                if (photo != null) circleImage(c, photo, 240f, 260f, 135f, accent) else initials(c, name, 240f, 260f, 135f, accent, primary, p.fontStyle)
                logo?.let { fit(c, it, RectF(110f, 470f, 370f, 650f)) }
                val x0 = 540f
                val qrW = if (qr != null) 260f else 0f
                text(c, name, x0, 170f, namePaint, wf - x0 - 60, Paint.Align.LEFT)
                text(c, data.designation, x0, 228f, titlePaint, wf - x0 - 60, Paint.Align.LEFT)
                text(c, companyLine, x0, 278f, subPaint, wf - x0 - 60, Paint.Align.LEFT)
                c.drawRect(x0, 312f, x0 + 140f, 316f, Paint().apply { color = accent })
                info.forEachIndexed { i, (label, value) ->
                    val y = 390f + i * 64f
                    text(c, label, x0, y, labelPaint, 180f, Paint.Align.LEFT)
                    text(c, value, x0 + 180f, y, infoPaint, wf - x0 - 240 - qrW, Paint.Align.LEFT)
                }
                qr?.let { qrBox(c, it, RectF(wf - 270f, hf - 290f, wf - 60f, hf - 80f)) }
            }
            else -> {
                if (photo != null) circleImage(c, photo, 200f, 220f, 120f, accent) else initials(c, name, 200f, 220f, 120f, accent, primary, p.fontStyle)
                val x0 = 380f
                val logoW = if (logo != null) 240f else 0f
                text(c, name, x0, 175f, namePaint, wf - x0 - 80 - logoW, Paint.Align.LEFT)
                text(c, data.designation, x0, 233f, titlePaint, wf - x0 - 80 - logoW, Paint.Align.LEFT)
                text(c, companyLine, x0, 283f, subPaint, wf - x0 - 80 - logoW, Paint.Align.LEFT)
                c.drawRect(x0, 318f, x0 + 150f, 322f, Paint().apply { color = accent })
                val qrW = if (qr != null) 300f else 0f
                info.forEachIndexed { i, (label, value) ->
                    val y = 410f + i * 64f
                    text(c, label, 80f, y, labelPaint, 200f, Paint.Align.LEFT)
                    text(c, value, 290f, y, infoPaint, wf - 290f - 80 - qrW, Paint.Align.LEFT)
                }
                logo?.let { fit(c, it, RectF(wf - 270f, 60f, wf - 70f, 220f)) }
                qr?.let { qrBox(c, it, RectF(wf - 290f, hf - 300f, wf - 70f, hf - 80f)) }
            }
        }
        return bmp
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, paint: TextPaint, maxW: Float, align: Paint.Align) {
        if (s.isBlank()) return
        val t = TextUtils.ellipsize(s.replace('\n', ' '), paint, maxW.coerceAtLeast(40f), TextUtils.TruncateAt.END).toString()
        paint.textAlign = align
        c.drawText(t, x, y, paint)
    }

    private fun circleImage(c: Canvas, src: Bitmap, cx: Float, cy: Float, r: Float, border: Int) {
        val size = min(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - size) / 2, (src.height - size) / 2, size, size)
        val scaled = Bitmap.createScaledBitmap(sq, (r * 2).toInt(), (r * 2).toInt(), true)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        c.save(); c.translate(cx - r, cy - r); c.drawCircle(r, r, r, paint); c.restore()
        c.drawCircle(cx, cy, r + 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f; color = border })
    }

    private fun initials(c: Canvas, name: String, cx: Float, cy: Float, r: Float, bg: Int, fg: Int, font: String) {
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg })
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fg; textSize = r * 0.8f; typeface = fontFor(font, true); textAlign = Paint.Align.CENTER
        }
        c.drawText(initialsOf(name), cx, cy - (p.descent() + p.ascent()) / 2, p)
    }

    fun initialsOf(name: String) = name.split(" ").filter { it.isNotBlank() }.take(2)
        .joinToString("") { it.first().uppercase() }.ifEmpty { "?" }

    private fun fit(c: Canvas, b: Bitmap, box: RectF) {
        val s = min(box.width() / b.width, box.height() / b.height)
        val w = b.width * s; val h = b.height * s
        val dst = RectF(box.centerX() - w / 2, box.centerY() - h / 2, box.centerX() + w / 2, box.centerY() + h / 2)
        c.drawBitmap(b, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun qrBox(c: Canvas, qr: Bitmap, box: RectF) {
        c.drawRoundRect(box, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val inset = RectF(box.left + 14, box.top + 14, box.right - 14, box.bottom - 14)
        c.drawBitmap(qr, null, inset, Paint(Paint.FILTER_BITMAP_FLAG))
    }

    fun writePng(bmp: Bitmap, out: OutputStream) { bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }

    fun writePdf(bmp: Bitmap, out: OutputStream) {
        val doc = PdfDocument()
        // 3.5" x 2" business card at 72 pt/inch, scaled up 2x for quality.
        val pageW = 504; val pageH = 288
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
        page.canvas.scale(pageW.toFloat() / bmp.width, pageH.toFloat() / bmp.height)
        page.canvas.drawBitmap(bmp, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }
}
