package com.cardlink.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.CardProfile
import com.cardlink.app.util.Links
import java.io.File

fun cardFont(style: String): FontFamily = when (style) {
    "SANS" -> FontFamily.SansSerif
    "MONO" -> FontFamily.Monospace
    else -> FontFamily.Serif
}

private class CardStyle(val accent: Color, val text: Color, val primary: Color, val font: FontFamily, val s: Float)

/** The on-screen digital business card. Fully driven by the profile's design settings. */
@Composable
fun BusinessCard(profile: CardProfile, modifier: Modifier = Modifier) {
    val primary = Color(profile.primaryColor)
    val accent = Color(profile.accentColor)
    val textColor = Color(profile.textColor)
    val shape = RoundedCornerShape(22.dp)
    val brush: Brush = if (profile.backgroundStyle == "SOLID") SolidColor(primary)
    else Brush.linearGradient(listOf(primary, lerp(primary, Color.Black, 0.35f)))
    BoxWithConstraints(
        modifier.fillMaxWidth().aspectRatio(1.75f)
            .shadow(14.dp, shape, ambientColor = primary, spotColor = primary)
            .clip(shape)
            .background(brush)
            .drawBehind {
                if (profile.backgroundStyle == "PATTERN") {
                    val step = 18.dp.toPx()
                    var x = -size.height
                    while (x < size.width) {
                        drawLine(accent.copy(alpha = 0.10f), Offset(x, size.height), Offset(x + size.height, 0f), strokeWidth = 1.5f)
                        x += step
                    }
                }
                drawCircle(accent.copy(alpha = 0.10f), radius = size.height * 0.8f, center = Offset(size.width * 0.96f, size.height * 0.04f))
                drawRect(accent, topLeft = Offset(0f, size.height - 4.dp.toPx()), size = Size(size.width, 4.dp.toPx()))
            },
    ) {
        val st = CardStyle(accent, textColor, primary, cardFont(profile.fontStyle), maxWidth.value / 340f)
        when (profile.layoutStyle) {
            "CENTERED" -> CenteredLayout(profile, st)
            "SPLIT" -> SplitLayout(profile, st)
            else -> LeftLayout(profile, st)
        }
    }
}

@Composable
private fun NameBlock(p: CardProfile, st: CardStyle, align: TextAlign = TextAlign.Start, nameSize: Float = 20f) {
    val s = st.s
    Text(
        p.fullName.ifBlank { "Your Name" }, color = st.text, fontFamily = st.font, fontWeight = FontWeight.Bold,
        fontSize = (nameSize * s).sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align,
        modifier = Modifier.fillMaxWidth(),
    )
    if (p.designation.isNotBlank()) Text(
        p.designation, color = st.accent, fontFamily = st.font, fontSize = (11.5f * s).sp, maxLines = 1,
        overflow = TextOverflow.Ellipsis, textAlign = align, modifier = Modifier.fillMaxWidth(),
    )
    val org = listOf(p.company, p.department).filter { it.isNotBlank() }.joinToString(" · ")
    if (org.isNotBlank()) Text(
        org, color = st.text.copy(alpha = 0.85f), fontFamily = st.font, fontSize = (10f * s).sp, maxLines = 1,
        overflow = TextOverflow.Ellipsis, textAlign = align, modifier = Modifier.fillMaxWidth(),
    )
}

private fun contactLines(p: CardProfile): List<Pair<ImageVector, String>> = buildList {
    if (p.phone.isNotBlank()) add(Icons.Filled.Phone to p.phone)
    if (p.email.isNotBlank()) add(Icons.Filled.Email to p.email)
    if (p.website.isNotBlank()) add(Icons.Filled.Language to Links.display(p.website))
    else if (p.linkedin.isNotBlank()) add(Icons.Filled.Language to Links.display(p.linkedin))
}

@Composable
private fun ContactLine(icon: ImageVector, text: String, st: CardStyle) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = st.accent, modifier = Modifier.size((10f * st.s).dp))
        Spacer(Modifier.width((5f * st.s).dp))
        Text(text, color = st.text.copy(alpha = 0.92f), fontSize = (8.5f * st.s).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Logo(path: String?, sizeDp: Float) {
    if (path != null && File(path).exists()) {
        AsyncImage(
            model = File(path), contentDescription = "Company logo",
            modifier = Modifier.size(sizeDp.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Fit,
        )
    }
}

@Composable
private fun LeftLayout(p: CardProfile, st: CardStyle) {
    val s = st.s
    Column(Modifier.fillMaxSize().padding((16f * s).dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(p.photoPath, p.fullName, (62f * s).dp, st.accent, st.accent, st.primary, fontFamily = st.font)
            Spacer(Modifier.width((12f * s).dp))
            Column(Modifier.weight(1f)) { NameBlock(p, st) }
            Logo(p.logoPath, 38f * s)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.width((36f * s).dp).height(2.dp).background(st.accent))
        Spacer(Modifier.height((6f * s).dp))
        Column(verticalArrangement = Arrangement.spacedBy((3f * s).dp)) {
            contactLines(p).forEach { (i, t) -> ContactLine(i, t, st) }
        }
    }
}

@Composable
private fun CenteredLayout(p: CardProfile, st: CardStyle) {
    val s = st.s
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.TopStart).padding((12f * s).dp)) { Logo(p.logoPath, 30f * s) }
        Column(
            Modifier.fillMaxSize().padding(horizontal = (20f * s).dp, vertical = (12f * s).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Avatar(p.photoPath, p.fullName, (52f * s).dp, st.accent, st.accent, st.primary, fontFamily = st.font)
            Spacer(Modifier.height((6f * s).dp))
            NameBlock(p, st, TextAlign.Center, 18f)
            Spacer(Modifier.weight(1f))
            Box(Modifier.width((40f * s).dp).height(2.dp).background(st.accent))
            Spacer(Modifier.height((5f * s).dp))
            Row(horizontalArrangement = Arrangement.spacedBy((12f * s).dp)) {
                contactLines(p).take(2).forEach { (i, t) -> ContactLine(i, t, st) }
            }
        }
    }
}

@Composable
private fun SplitLayout(p: CardProfile, st: CardStyle) {
    val s = st.s
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(0.36f).fillMaxHeight().background(Color.Black.copy(alpha = 0.25f)).padding((10f * s).dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Avatar(p.photoPath, p.fullName, (66f * s).dp, st.accent, st.accent, st.primary, fontFamily = st.font)
            Spacer(Modifier.height((10f * s).dp))
            Logo(p.logoPath, 34f * s)
        }
        Box(Modifier.width(2.dp).fillMaxHeight().background(st.accent))
        Column(Modifier.weight(0.64f).fillMaxHeight().padding((14f * s).dp)) {
            NameBlock(p, st, nameSize = 18f)
            Spacer(Modifier.weight(1f))
            Column(verticalArrangement = Arrangement.spacedBy((3f * s).dp)) {
                contactLines(p).forEach { (i, t) -> ContactLine(i, t, st) }
            }
        }
    }
}
