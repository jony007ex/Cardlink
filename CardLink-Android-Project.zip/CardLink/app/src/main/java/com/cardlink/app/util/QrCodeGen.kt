package com.cardlink.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object QrCodeGen {
    fun generate(content: String, size: Int = 800, fg: Int = Color.BLACK, bg: Int = Color.WHITE, logo: Bitmap? = null): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to if (logo != null) ErrorCorrectionLevel.H else ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8",
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val w = matrix.width; val h = matrix.height
        val pixels = IntArray(w * h)
        for (y in 0 until h) {
            val off = y * w
            for (x in 0 until w) pixels[off + x] = if (matrix.get(x, y)) fg else bg
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        if (logo != null) {
            val c = Canvas(bmp)
            val box = w * 0.24f
            val l = (w - box) / 2f; val t = (h - box) / 2f
            c.drawRoundRect(RectF(l, t, l + box, t + box), box * 0.18f, box * 0.18f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg })
            val pad = box * 0.12f
            val avail = box - pad * 2
            val s = minOf(avail / logo.width, avail / logo.height)
            val lw = logo.width * s; val lh = logo.height * s
            val dst = RectF(l + (box - lw) / 2f, t + (box - lh) / 2f, l + (box + lw) / 2f, t + (box + lh) / 2f)
            c.drawBitmap(logo, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        return bmp
    }
}
