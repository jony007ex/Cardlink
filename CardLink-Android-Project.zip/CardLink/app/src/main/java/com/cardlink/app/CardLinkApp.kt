package com.cardlink.app

import android.app.Application
import android.content.Context
import com.cardlink.app.data.AppDatabase
import com.cardlink.app.data.CardData
import com.cardlink.app.data.CardRepository
import com.cardlink.app.data.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow

class CardLinkApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** A card received from NFC, Nearby, QR or a .vcf file, awaiting the user's decision. */
data class IncomingCard(val card: CardData, val source: String)

/** Simple manual dependency container. */
class AppContainer(context: Context) {
    val context: Context = context.applicationContext
    val db = AppDatabase.get(this.context)
    val repo = CardRepository(db)
    val settings = SettingsRepository(this.context)
    val incoming = MutableStateFlow<IncomingCard?>(null)
}

val Context.appContainer: AppContainer get() = (applicationContext as CardLinkApp).container
