package com.cardlink.app.util

import android.net.Uri
import android.util.Patterns

/** Validation helpers for user-entered and externally received data. */
object Links {
    /** Returns a safe http(s) URL or null if the input is not a valid web link. */
    fun normalize(input: String?): String? {
        val t = input?.trim().orEmpty()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val lower = t.lowercase()
        if (lower.startsWith("javascript:") || lower.startsWith("file:") || lower.startsWith("intent:") ||
            lower.startsWith("content:") || lower.startsWith("data:")
        ) return null
        val withScheme = if (lower.startsWith("http://") || lower.startsWith("https://")) t else "https://$t"
        return try {
            val uri = Uri.parse(withScheme)
            val host = uri.host ?: return null
            if (!host.contains('.') || host.startsWith('.') || host.endsWith('.')) return null
            if (!Patterns.WEB_URL.matcher(withScheme).matches()) return null
            withScheme
        } catch (e: Exception) {
            null
        }
    }

    fun isWebUrl(input: String?): Boolean {
        val t = input?.trim()?.lowercase().orEmpty()
        return (t.startsWith("http://") || t.startsWith("https://")) && normalize(input) != null
    }

    fun isValidEmail(e: String) = Patterns.EMAIL_ADDRESS.matcher(e.trim()).matches()
    fun isValidPhone(p: String) = p.trim().matches(Regex("^\\+?[0-9 ()\\-.]{6,22}$"))
    fun digitsOnly(p: String) = p.filter { it.isDigit() }
    fun whatsappUrl(number: String) = "https://wa.me/${digitsOnly(number)}"
    fun display(url: String) = url.trim().removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')
    fun host(url: String): String = try { Uri.parse(url).host ?: url } catch (e: Exception) { url }
}
