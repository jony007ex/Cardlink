package com.cardlink.app.nearby

import android.Manifest
import android.os.Build
import androidx.lifecycle.ViewModel
import com.cardlink.app.AppContainer
import com.cardlink.app.IncomingCard
import com.cardlink.app.data.CardData
import com.cardlink.app.data.ShareHistory
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class NearbyMode { IDLE, SEND, RECEIVE }
enum class NearbyStatus { IDLE, SEARCHING, ADVERTISING, CONNECTING, AWAITING_ACCEPT, TRANSFERRING, DONE, FAILED }

data class NearbyEndpoint(val id: String, val name: String)
data class PendingRequest(val endpointId: String, val name: String, val code: String)

data class NearbyState(
    val mode: NearbyMode = NearbyMode.IDLE,
    val status: NearbyStatus = NearbyStatus.IDLE,
    val message: String = "",
    val endpoints: List<NearbyEndpoint> = emptyList(),
    val progress: Float = 0f,
    val pending: PendingRequest? = null,
    val targetName: String = "",
)

/**
 * Device-to-device sharing using Google Nearby Connections (Bluetooth, BLE and Wi-Fi, end-to-end encrypted).
 * Sender discovers, receiver advertises; the receiver must explicitly accept every incoming card.
 */
class NearbyViewModel(private val container: AppContainer) : ViewModel() {
    private val client = Nearby.getConnectionsClient(container.context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(NearbyState())
    val state: StateFlow<NearbyState> = _state
    private var outgoing: ByteArray? = null
    private var outgoingName: String = ""

    private val strategy = Strategy.P2P_POINT_TO_POINT

    fun startSending(localName: String, card: CardData) {
        stopAll()
        var json = card.toJson().toString()
        if (json.toByteArray().size > MAX_BYTES) json = card.copy(photoBase64 = null).toJson().toString()
        outgoing = json.toByteArray(Charsets.UTF_8)
        outgoingName = localName
        _state.value = NearbyState(NearbyMode.SEND, NearbyStatus.SEARCHING, "Looking for nearby CardLink users…")
        client.startDiscovery(SERVICE_ID, discoveryCallback, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { fail(it) }
    }

    fun startReceiving(localName: String) {
        stopAll()
        _state.value = NearbyState(NearbyMode.RECEIVE, NearbyStatus.ADVERTISING, "Visible to nearby devices as \"$localName\"")
        client.startAdvertising(localName, SERVICE_ID, lifecycleCallback, AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { fail(it) }
    }

    fun sendTo(endpoint: NearbyEndpoint) {
        _state.update { it.copy(status = NearbyStatus.CONNECTING, message = "Connecting to ${endpoint.name}…", targetName = endpoint.name, progress = 0f) }
        client.requestConnection(outgoingName, endpoint.id, lifecycleCallback).addOnFailureListener { fail(it) }
    }

    fun acceptPending() {
        val p = _state.value.pending ?: return
        _state.update { it.copy(pending = null, status = NearbyStatus.CONNECTING, message = "Connecting to ${p.name}…", targetName = p.name) }
        client.acceptConnection(p.endpointId, payloadCallback).addOnFailureListener { fail(it) }
    }

    fun rejectPending() {
        val p = _state.value.pending ?: return
        client.rejectConnection(p.endpointId)
        _state.update { it.copy(pending = null, status = NearbyStatus.ADVERTISING, message = "Request declined. Still visible to nearby devices.") }
    }

    fun stopAll() {
        runCatching {
            client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
        }
    }

    fun reset() { stopAll(); _state.value = NearbyState() }

    private fun fail(e: Exception) {
        val code = (e as? ApiException)?.statusCode
        val msg = when (code) {
            ConnectionsStatusCodes.MISSING_PERMISSION_BLUETOOTH, ConnectionsStatusCodes.MISSING_PERMISSION_BLUETOOTH_ADMIN,
            ConnectionsStatusCodes.MISSING_PERMISSION_ACCESS_COARSE_LOCATION, ConnectionsStatusCodes.MISSING_PERMISSION_ACCESS_WIFI_STATE ->
                "Required permission missing. Please grant Nearby permissions."
            ConnectionsStatusCodes.STATUS_BLUETOOTH_ERROR -> "Bluetooth error. Turn Bluetooth off and on, then try again."
            ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT -> "Already connected."
            ConnectionsStatusCodes.STATUS_ENDPOINT_IO_ERROR -> "The connection was interrupted. Move closer and retry."
            else -> "Could not complete the request. Make sure Bluetooth, Wi-Fi and Location are on. (${e.message ?: code})"
        }
        _state.update { it.copy(status = NearbyStatus.FAILED, message = msg, progress = 0f) }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            _state.update { s ->
                if (s.endpoints.any { it.id == endpointId }) s
                else s.copy(endpoints = s.endpoints + NearbyEndpoint(endpointId, info.endpointName))
            }
        }
        override fun onEndpointLost(endpointId: String) {
            _state.update { s -> s.copy(endpoints = s.endpoints.filterNot { it.id == endpointId }) }
        }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            if (_state.value.mode == NearbyMode.SEND) {
                _state.update { it.copy(status = NearbyStatus.AWAITING_ACCEPT, message = "Waiting for ${info.endpointName} to accept (code ${info.authenticationDigits})…") }
                client.acceptConnection(endpointId, payloadCallback).addOnFailureListener { fail(it) }
            } else {
                _state.update { it.copy(pending = PendingRequest(endpointId, info.endpointName, info.authenticationDigits)) }
            }
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            if (resolution.status.isSuccess) {
                if (_state.value.mode == NearbyMode.SEND) {
                    val bytes = outgoing ?: return
                    _state.update { it.copy(status = NearbyStatus.TRANSFERRING, message = "Sending your card…", progress = 0.05f) }
                    client.sendPayload(endpointId, Payload.fromBytes(bytes)).addOnFailureListener { fail(it) }
                } else {
                    _state.update { it.copy(status = NearbyStatus.TRANSFERRING, message = "Receiving card…", progress = 0.05f) }
                }
            } else {
                val rejected = resolution.status.statusCode == ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED
                _state.update {
                    it.copy(status = NearbyStatus.FAILED, message = if (rejected) "The other person declined the card." else "Connection failed. Please try again.")
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            val s = _state.value
            if (s.status == NearbyStatus.TRANSFERRING) {
                _state.update { it.copy(status = NearbyStatus.FAILED, message = "Disconnected before the transfer finished.") }
            }
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            val card = runCatching { CardData.fromJson(JSONObject(String(bytes, Charsets.UTF_8))) }.getOrNull()
            if (card == null || card.fullName.isBlank()) {
                _state.update { it.copy(status = NearbyStatus.FAILED, message = "Received data was not a valid business card.") }
                return
            }
            container.incoming.value = IncomingCard(card, "Nearby / Bluetooth")
            _state.update { it.copy(status = NearbyStatus.DONE, message = "Card received from ${card.fullName}", progress = 1f) }
            scope.launch { container.repo.addHistory(ShareHistory(method = "Nearby / Bluetooth", direction = "RECEIVED", detail = card.fullName)) }
            client.disconnectFromEndpoint(endpointId)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (_state.value.mode != NearbyMode.SEND) return
            when (update.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS -> {
                    val total = update.totalBytes
                    if (total > 0) _state.update { it.copy(progress = (update.bytesTransferred.toFloat() / total).coerceIn(0.05f, 1f)) }
                }
                PayloadTransferUpdate.Status.SUCCESS -> {
                    val name = _state.value.targetName
                    _state.update { it.copy(status = NearbyStatus.DONE, message = "Card delivered to $name", progress = 1f) }
                    scope.launch { container.repo.addHistory(ShareHistory(method = "Nearby / Bluetooth", direction = "SENT", detail = name)) }
                    // Give the receiver a moment to finish reading before disconnecting.
                    scope.launch { kotlinx.coroutines.delay(800); client.disconnectFromEndpoint(endpointId) }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED ->
                    _state.update { it.copy(status = NearbyStatus.FAILED, message = "Transfer failed. Please try again.") }
            }
        }
    }

    override fun onCleared() {
        stopAll()
        scope.cancel()
        super.onCleared()
    }

    companion object {
        const val SERVICE_ID = "com.cardlink.app.SHARE"
        private const val MAX_BYTES = 30_000

        fun requiredPermissions(): Array<String> = when {
            Build.VERSION.SDK_INT >= 33 -> arrayOf(
                Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.NEARBY_WIFI_DEVICES,
                Manifest.permission.ACCESS_FINE_LOCATION,
            )
            Build.VERSION.SDK_INT >= 31 -> arrayOf(
                Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION,
            )
            else -> arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
}
