@file:OptIn(ExperimentalMaterial3Api::class)

package com.cardlink.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cardlink.app.data.parseLinks
import com.cardlink.app.ui.CardViewModel
import com.cardlink.app.ui.components.BusinessCard
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.InfoRow
import com.cardlink.app.ui.components.SectionTitle
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.components.rememberQr
import com.cardlink.app.util.Actions
import com.cardlink.app.util.Links
import com.cardlink.app.util.ShareHelper

private data class Detail(val icon: ImageVector, val label: String, val value: String, val action: () -> Unit)

@Composable
fun HomeScreen(
    vm: CardViewModel,
    onEdit: () -> Unit, onDesign: () -> Unit, onShare: () -> Unit,
    onQr: () -> Unit, onScan: () -> Unit, onProfiles: () -> Unit,
) {
    val profile by vm.activeProfile.collectAsStateWithLifecycle()
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                title = {
                    Box {
                        Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { menu = true }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("My Card", style = MaterialTheme.typography.titleLarge)
                                Text(profile?.label.orEmpty(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Filled.ArrowDropDown, "Switch profile")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            profiles.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.label + if (p.fullName.isNotBlank()) " · ${p.fullName}" else "") },
                                    leadingIcon = { if (p.id == profile?.id) Icon(Icons.Filled.Check, null) else Spacer(Modifier.size(24.dp)) },
                                    onClick = { vm.setActive(p.id); menu = false },
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Manage profiles") }, leadingIcon = { Icon(Icons.Filled.Add, null) }, onClick = { menu = false; onProfiles() })
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onScan) { Icon(Icons.Filled.QrCodeScanner, "Scan a card") }
                    IconButton(onClick = onDesign) { Icon(Icons.Filled.Palette, "Design") }
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit") }
                },
            )
        },
    ) { pad ->
        val p = profile
        if (p == null) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val qr by rememberQr(Triple(p, settings.shareFields, "home")) { ShareHelper.qrBitmap(p, settings.shareFields, false, 400) }
        val details = buildList {
            if (p.phone.isNotBlank()) add(Detail(Icons.Filled.Phone, "Business phone", p.phone) { Actions.dial(ctx, p.phone) })
            if (p.whatsapp.isNotBlank()) add(Detail(Icons.Filled.Chat, "WhatsApp", p.whatsapp) { Actions.whatsapp(ctx, p.whatsapp) })
            if (p.email.isNotBlank()) add(Detail(Icons.Filled.Email, "Email", p.email) { Actions.email(ctx, p.email) })
            if (p.address.isNotBlank()) add(Detail(Icons.Filled.LocationOn, "Office address", p.address) { Actions.map(ctx, p.address) })
            if (p.department.isNotBlank()) add(Detail(Icons.Filled.Business, "Department", p.department) {})
            if (p.website.isNotBlank()) add(Detail(Icons.Filled.Language, "Website", Links.display(p.website)) { Actions.openUrl(ctx, p.website) })
            if (p.linkedin.isNotBlank()) add(Detail(Icons.Filled.Work, "LinkedIn", Links.display(p.linkedin)) { Actions.openUrl(ctx, p.linkedin) })
            if (p.facebook.isNotBlank()) add(Detail(Icons.Filled.Public, "Facebook", Links.display(p.facebook)) { Actions.openUrl(ctx, p.facebook) })
            parseLinks(p.otherLinks).forEach { l -> add(Detail(Icons.Filled.Link, l.label, Links.display(l.url)) { Actions.openUrl(ctx, l.url) }) }
            if (p.cardUrl.isNotBlank()) add(Detail(Icons.Filled.Link, "Digital card link", Links.display(p.cardUrl)) { Actions.openUrl(ctx, p.cardUrl) })
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { BusinessCard(p, Modifier.clickable(onClick = onDesign)) }
            if (p.fullName.isBlank()) item {
                SurfaceCard {
                    Column(Modifier.padding(18.dp)) {
                        Text("Let's create your card", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("Add your name, title, company and contact details to get started.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        FilledTonalButton(onClick = onEdit) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(8.dp)); Text("Create my card") }
                    }
                }
            }
            item { GoldButton("Share My Card", Icons.Filled.Share, onShare, enabled = p.fullName.isNotBlank()) }
            item {
                SurfaceCard(Modifier.clickable(onClick = onQr)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(6.dp), contentAlignment = Alignment.Center) {
                            qr?.let { Image(it, "My QR code", Modifier.fillMaxSize()) } ?: CircularProgressIndicator(Modifier.size(24.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("My QR code", style = MaterialTheme.typography.titleMedium)
                            Text("Anyone can scan this with their camera to save your contact.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.QrCode2, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Show full screen", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
            if (details.isNotEmpty()) item {
                Column {
                    SectionTitle("Contact details")
                    SurfaceCard {
                        Column(Modifier.padding(6.dp)) {
                            details.forEach { d -> InfoRow(d.icon, d.label, d.value, onClick = d.action) }
                        }
                    }
                }
            }
            if (p.bio.isNotBlank()) item {
                Column {
                    SectionTitle("About")
                    SurfaceCard { Text(p.bio, Modifier.padding(18.dp), style = MaterialTheme.typography.bodyLarge, maxLines = 12, overflow = TextOverflow.Ellipsis) }
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
