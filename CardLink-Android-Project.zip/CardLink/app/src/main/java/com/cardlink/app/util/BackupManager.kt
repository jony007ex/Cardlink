package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.CardRepository
import com.cardlink.app.data.SavedContact
import com.cardlink.app.data.ShareHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Local, user-controlled backup to a JSON file chosen with the system file picker. */
object BackupManager {

    suspend fun export(ctx: Context, repo: CardRepository, uri: Uri) = withContext(Dispatchers.IO) {
        val root = JSONObject().put("app", "CardLink").put("backupVersion", 1).put("createdAt", System.currentTimeMillis())
        root.put("profiles", JSONArray().apply { repo.allProfiles().forEach { put(profileToJson(it)) } })
        root.put("contacts", JSONArray().apply { repo.allContacts().forEach { put(contactToJson(it)) } })
        root.put("history", JSONArray().apply {
            repo.allHistory().forEach {
                put(JSONObject().put("method", it.method).put("direction", it.direction).put("detail", it.detail).put("timestamp", it.timestamp))
            }
        })
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(root.toString().toByteArray()) }
            ?: throw IllegalStateException("Cannot write file")
    }

    /** @return number of contacts restored */
    suspend fun import(ctx: Context, repo: CardRepository, uri: Uri): Int = withContext(Dispatchers.IO) {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Cannot read file")
        val root = JSONObject(text)
        require(root.optString("app") == "CardLink") { "This is not a CardLink backup" }
        val profiles = root.optJSONArray("profiles").objects().map { profileFromJson(ctx, it) }
        val contacts = root.optJSONArray("contacts").objects().map { contactFromJson(ctx, it) }
        val history = root.optJSONArray("history").objects().map {
            ShareHistory(method = it.optString("method"), direction = it.optString("direction"), detail = it.optString("detail"), timestamp = it.optLong("timestamp"))
        }
        repo.restoreAll(profiles, contacts, history)
        contacts.size
    }

    private fun JSONArray?.objects(): List<JSONObject> =
        if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    private fun profileToJson(p: CardProfile) = JSONObject().apply {
        put("id", p.id); put("label", p.label); put("fullName", p.fullName); put("designation", p.designation)
        put("company", p.company); put("department", p.department); put("phone", p.phone); put("whatsapp", p.whatsapp)
        put("email", p.email); put("address", p.address); put("website", p.website); put("linkedin", p.linkedin)
        put("facebook", p.facebook); put("otherLinks", p.otherLinks); put("bio", p.bio); put("cardUrl", p.cardUrl)
        put("templateId", p.templateId); put("primaryColor", p.primaryColor); put("accentColor", p.accentColor)
        put("textColor", p.textColor); put("fontStyle", p.fontStyle); put("layoutStyle", p.layoutStyle)
        put("backgroundStyle", p.backgroundStyle); put("qrColor", p.qrColor)
        ImageStore.fileToBase64(p.photoPath)?.let { put("photo", it) }
        ImageStore.fileToBase64(p.logoPath)?.let { put("logo", it) }
    }

    private fun profileFromJson(ctx: Context, o: JSONObject): CardProfile {
        val d = CardProfile()
        return CardProfile(
            id = o.optLong("id", 0), label = o.optString("label", d.label), fullName = o.optString("fullName"),
            designation = o.optString("designation"), company = o.optString("company"), department = o.optString("department"),
            phone = o.optString("phone"), whatsapp = o.optString("whatsapp"), email = o.optString("email"),
            address = o.optString("address"), website = o.optString("website"), linkedin = o.optString("linkedin"),
            facebook = o.optString("facebook"), otherLinks = o.optString("otherLinks"), bio = o.optString("bio"),
            cardUrl = o.optString("cardUrl"),
            photoPath = ImageStore.saveBase64(ctx, o.optString("photo").ifEmpty { null }),
            logoPath = ImageStore.saveBase64(ctx, o.optString("logo").ifEmpty { null }, ".png"),
            templateId = o.optString("templateId", d.templateId),
            primaryColor = o.optLong("primaryColor", d.primaryColor), accentColor = o.optLong("accentColor", d.accentColor),
            textColor = o.optLong("textColor", d.textColor), fontStyle = o.optString("fontStyle", d.fontStyle),
            layoutStyle = o.optString("layoutStyle", d.layoutStyle), backgroundStyle = o.optString("backgroundStyle", d.backgroundStyle),
            qrColor = o.optLong("qrColor", d.qrColor),
        )
    }

    private fun contactToJson(c: SavedContact) = JSONObject().apply {
        put("fullName", c.fullName); put("designation", c.designation); put("company", c.company); put("department", c.department)
        put("phone", c.phone); put("whatsapp", c.whatsapp); put("email", c.email); put("address", c.address)
        put("website", c.website); put("linkedin", c.linkedin); put("facebook", c.facebook); put("otherLinks", c.otherLinks)
        put("bio", c.bio); put("cardUrl", c.cardUrl); put("notes", c.notes); put("source", c.source); put("savedAt", c.savedAt)
        ImageStore.fileToBase64(c.photoPath)?.let { put("photo", it) }
    }

    private fun contactFromJson(ctx: Context, o: JSONObject) = SavedContact(
        fullName = o.optString("fullName"), designation = o.optString("designation"), company = o.optString("company"),
        department = o.optString("department"), phone = o.optString("phone"), whatsapp = o.optString("whatsapp"),
        email = o.optString("email"), address = o.optString("address"), website = o.optString("website"),
        linkedin = o.optString("linkedin"), facebook = o.optString("facebook"), otherLinks = o.optString("otherLinks"),
        bio = o.optString("bio"), cardUrl = o.optString("cardUrl"), notes = o.optString("notes"),
        source = o.optString("source", "Backup"), savedAt = o.optLong("savedAt", System.currentTimeMillis()),
        photoPath = ImageStore.saveBase64(ctx, o.optString("photo").ifEmpty { null }),
    )
}
