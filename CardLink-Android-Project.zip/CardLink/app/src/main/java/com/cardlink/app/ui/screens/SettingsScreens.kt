@file:OptIn(ExperimentalMaterial3Api::class)

package com.cardlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cardlink.app.BuildConfig
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.ShareField
import com.cardlink.app.ui.CardViewModel
import com.cardlink.app.ui.SettingsViewModel
import com.cardlink.app.ui.components.LogoMark
import com.cardlink.app.ui.components.ScreenScaffold
import com.cardlink.app.ui.components.SectionTitle
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.ui.theme.Success
import com.cardlink.app.util.toast
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun NavRow(icon: ImageVector, title: String, subtitle: String? = null, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = if (subtitle != null) { { Text(subtitle) } } else null,
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
fun SettingsScreen(
    vm: SettingsViewModel,
    onProfiles: () -> Unit, onHistory: () -> Unit, onAbout: () -> Unit, scrollToPrivacy: Boolean = false,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var confirmRestore by remember { mutableStateOf<android.net.Uri?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            vm.backup(uri).onSuccess { ctx.toast("Backup saved") }.onFailure { ctx.toast("Backup failed: ${it.message}") }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> confirmRestore = uri }

    ScreenScaffold(title = "Settings") { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Column {
                    SectionTitle("Appearance")
                    SurfaceCard {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.DarkMode, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp)); Text("Theme", style = MaterialTheme.typography.titleMedium)
                            }
                            Spacer(Modifier.height(10.dp))
                            val opts = listOf("SYSTEM" to "System", "LIGHT" to "Light", "DARK" to "Dark")
                            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                                opts.forEachIndexed { i, (k, l) ->
                                    SegmentedButton(settings.theme == k, { vm.setTheme(k) }, SegmentedButtonDefaults.itemShape(i, opts.size)) { Text(l) }
                                }
                            }
                        }
                    }
                }
            }
            item {
                Column {
                    SectionTitle("Card profiles")
                    SurfaceCard { NavRow(Icons.Filled.Badge, "Manage profiles", "Corporate, personal and other cards", onProfiles) }
                }
            }
            item {
                Column {
                    SectionTitle("Privacy – information shared")
                    SurfaceCard {
                        Column(Modifier.padding(vertical = 8.dp)) {
                            Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Security, null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(12.dp))
                                Text("Your name is always shared. Turn off anything you'd rather keep private — this applies to NFC, Nearby, QR, images and app sharing.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            ShareField.entries.forEach { f ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { vm.toggleField(f, f !in settings.shareFields) }.padding(horizontal = 16.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(f.label, Modifier.weight(1f))
                                    Switch(checked = f in settings.shareFields, onCheckedChange = { vm.toggleField(f, it) })
                                }
                            }
                        }
                    }
                }
            }
            item {
                Column {
                    SectionTitle("Data")
                    SurfaceCard {
                        Column {
                            NavRow(Icons.Filled.Backup, "Back up to file", "Profiles, contacts & history in one file") {
                                backupLauncher.launch("CardLink_Backup_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.json")
                            }
                            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                            NavRow(Icons.Filled.Restore, "Restore from backup", "Replaces current data") {
                                restoreLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                            }
                            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                            NavRow(Icons.Filled.History, "Sharing history", null, onHistory)
                        }
                    }
                }
            }
            item {
                Column {
                    SectionTitle("About")
                    SurfaceCard {
                        Column {
                            NavRow(Icons.Filled.Lock, "Privacy promise", "All data stays on this device. No account, no tracking.") { onAbout() }
                            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                            NavRow(Icons.Filled.Info, "About CardLink", "Version ${BuildConfig.VERSION_NAME}", onAbout)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    confirmRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmRestore = null },
            title = { Text("Restore backup?") },
            text = { Text("Your current profiles, contacts and history will be replaced with the backup's contents.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = null
                    scope.launch {
                        vm.restore(uri).onSuccess { ctx.toast("Restored $it contact(s)") }.onFailure { ctx.toast("Restore failed: ${it.message}") }
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { confirmRestore = null }) { Text("Cancel") } },
        )
    }
}

@Composable
fun ProfilesScreen(vm: CardViewModel, onBack: () -> Unit, onEdit: () -> Unit) {
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val active by vm.activeProfile.collectAsStateWithLifecycle()
    var newDialog by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<CardProfile?>(null) }

    ScreenScaffold(title = "Card Profiles", onBack = onBack, actions = {
        IconButton(onClick = { newDialog = true }) { Icon(Icons.Filled.Add, "New profile") }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Keep separate cards for different roles — e.g. a corporate card and a personal card. The selected profile is the one you share.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
            items(profiles, key = { it.id }) { p ->
                SurfaceCard(Modifier.clickable { vm.setActive(p.id) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = p.id == active?.id, onClick = { vm.setActive(p.id) })
                        Column(Modifier.weight(1f)) {
                            Text(p.label, style = MaterialTheme.typography.titleMedium)
                            Text(p.fullName.ifBlank { "Not filled in yet" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.createProfile("${p.label} copy", p) }) { Icon(Icons.Filled.ContentCopy, "Duplicate") }
                        IconButton(onClick = { toDelete = p }, enabled = profiles.size > 1) { Icon(Icons.Filled.Delete, "Delete") }
                    }
                }
            }
        }
    }

    if (newDialog) {
        var label by remember { mutableStateOf("Personal") }
        AlertDialog(
            onDismissRequest = { newDialog = false },
            title = { Text("New card profile") },
            text = { OutlinedTextField(label, { label = it }, label = { Text("Profile name") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.createProfile(label.ifBlank { "New card" }); newDialog = false; onEdit() }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { newDialog = false }) { Text("Cancel") } },
        )
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete \"${p.label}\"?") },
            text = { Text("This card profile will be removed permanently.") },
            confirmButton = { TextButton(onClick = { vm.deleteProfile(p); toDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
fun HistoryScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val history by vm.history.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    ScreenScaffold(title = "Sharing History", onBack = onBack, actions = {
        if (history.isNotEmpty()) IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.Delete, "Clear") }
    }) { pad ->
        if (history.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(pad).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Filled.History, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(12.dp))
                Text("No sharing activity yet", style = MaterialTheme.typography.titleMedium)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history, key = { it.id }) { h ->
                    val sent = h.direction == "SENT"
                    SurfaceCard {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            leadingContent = { Icon(if (sent) Icons.Filled.CallMade else Icons.Filled.CallReceived, null, tint = if (sent) Gold else Success) },
                            headlineContent = { Text(if (sent) "Shared · ${h.method}" else "Received · ${h.method}") },
                            supportingContent = { Text(listOf(h.detail, fmt.format(Date(h.timestamp))).filter { it.isNotBlank() }.joinToString(" · ")) },
                        )
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Clear history?") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
    )
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    ScreenScaffold(title = "About", onBack = onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item { LogoMark(88.dp) }
            item { Text("CardLink", style = MaterialTheme.typography.headlineMedium) }
            item { Text("Smart Digital Business Card · v${BuildConfig.VERSION_NAME}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                Text("CardLink replaces paper business cards with a beautiful, customizable digital card you can share in seconds — by NFC tap, Bluetooth / Nearby, QR code or any messaging app.",
                    textAlign = TextAlign.Center)
            }
            val points = listOf(
                "Works offline — no account or cloud server required.",
                "Your information is stored only on this device.",
                "Nothing is ever shared without you tapping a share action.",
                "You choose which fields are included when sharing.",
                "Nearby transfers are encrypted and must be accepted by the receiver.",
                "Links from other cards are validated before they are opened.",
                "Camera is used only to scan QR codes; nothing is recorded.",
            )
            item {
                SurfaceCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Privacy promise", style = MaterialTheme.typography.titleMedium)
                        points.forEach { pt ->
                            Row {
                                Icon(Icons.Filled.CheckCircle, null, tint = Success, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp)); Text(pt, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
            item { Text("© CardLink", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)) }
        }
    }
}
