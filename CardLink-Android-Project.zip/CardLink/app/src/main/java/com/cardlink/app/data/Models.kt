package com.cardlink.app.data

import org.json.JSONArray
import org.json.JSONObject

data class SocialLink(val label: String, val url: String)

fun parseLinks(raw: String): List<SocialLink> = raw.lines().mapNotNull { line ->
    val i = line.indexOf('|')
    when {
        line.isBlank() -> null
        i < 0 -> SocialLink("Link", line.trim())
        else -> SocialLink(line.substring(0, i).trim().ifEmpty { "Link" }, line.substring(i + 1).trim())
    }
}.filter { it.url.isNotBlank() }

fun formatLinks(list: List<SocialLink>): String = list.filter { it.url.isNotBlank() }
    .joinToString("\n") { "${it.label.replace("|", " ").replace("\n", " ").trim()}|${it.url.trim()}" }

/** Portable representation of a card used for vCard, QR, NFC and Nearby transfers. */
data class CardData(
    val fullName: String = "",
    val designation: String = "",
    val company: String = "",
    val department: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val address: String = "",
    val website: String = "",
    val linkedin: String = "",
    val facebook: String = "",
    val otherLinks: List<SocialLink> = emptyList(),
    val bio: String = "",
    val cardUrl: String = "",
    val photoBase64: String? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("app", "CardLink"); put("v", 1)
        put("fullName", fullName); put("designation", designation); put("company", company)
        put("department", department); put("phone", phone); put("whatsapp", whatsapp)
        put("email", email); put("address", address); put("website", website)
        put("linkedin", linkedin); put("facebook", facebook); put("bio", bio); put("cardUrl", cardUrl)
        put("otherLinks", JSONArray().apply {
            otherLinks.forEach { put(JSONObject().put("label", it.label).put("url", it.url)) }
        })
        photoBase64?.let { put("photo", it) }
    }

    companion object {
        fun fromJson(o: JSONObject): CardData {
            val links = mutableListOf<SocialLink>()
            o.optJSONArray("otherLinks")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val l = arr.optJSONObject(i) ?: continue
                    links += SocialLink(l.optString("label", "Link"), l.optString("url"))
                }
            }
            return CardData(
                fullName = o.optString("fullName"), designation = o.optString("designation"),
                company = o.optString("company"), department = o.optString("department"),
                phone = o.optString("phone"), whatsapp = o.optString("whatsapp"),
                email = o.optString("email"), address = o.optString("address"),
                website = o.optString("website"), linkedin = o.optString("linkedin"),
                facebook = o.optString("facebook"), otherLinks = links.filter { it.url.isNotBlank() },
                bio = o.optString("bio"), cardUrl = o.optString("cardUrl"),
                photoBase64 = o.optString("photo").ifEmpty { null },
            )
        }
    }
}

/** Fields the user can choose to include when sharing (privacy control). */
enum class ShareField(val label: String) {
    PHOTO("Profile photo"),
    DESIGNATION("Designation"),
    COMPANY("Company"),
    DEPARTMENT("Department"),
    PHONE("Business phone"),
    WHATSAPP("WhatsApp number"),
    EMAIL("Email address"),
    ADDRESS("Office address"),
    WEBSITE("Company website"),
    LINKEDIN("LinkedIn"),
    FACEBOOK("Facebook"),
    OTHER_LINKS("Other social links"),
    BIO("Introduction"),
    CARD_URL("Digital card link"),
}

fun CardProfile.toCardData(fields: Set<ShareField>): CardData {
    fun f(field: ShareField, v: String) = if (field in fields) v.trim() else ""
    return CardData(
        fullName = fullName.trim(),
        designation = f(ShareField.DESIGNATION, designation),
        company = f(ShareField.COMPANY, company),
        department = f(ShareField.DEPARTMENT, department),
        phone = f(ShareField.PHONE, phone),
        whatsapp = f(ShareField.WHATSAPP, whatsapp),
        email = f(ShareField.EMAIL, email),
        address = f(ShareField.ADDRESS, address),
        website = f(ShareField.WEBSITE, website),
        linkedin = f(ShareField.LINKEDIN, linkedin),
        facebook = f(ShareField.FACEBOOK, facebook),
        otherLinks = if (ShareField.OTHER_LINKS in fields) parseLinks(otherLinks) else emptyList(),
        bio = f(ShareField.BIO, bio),
        cardUrl = f(ShareField.CARD_URL, cardUrl),
    )
}

fun SavedContact.toCardData() = CardData(
    fullName, designation, company, department, phone, whatsapp, email, address,
    website, linkedin, facebook, parseLinks(otherLinks), bio, cardUrl, null,
)

fun CardData.toContact(photoPath: String?, source: String) = SavedContact(
    fullName = fullName.ifBlank { "Unnamed contact" }, designation = designation, company = company,
    department = department, phone = phone, whatsapp = whatsapp, email = email, address = address,
    website = website, linkedin = linkedin, facebook = facebook, otherLinks = formatLinks(otherLinks),
    bio = bio, cardUrl = cardUrl, photoPath = photoPath, source = source,
)

/** Pre-designed professional templates. */
data class CardTemplate(
    val id: String, val name: String, val category: String,
    val primary: Long, val accent: Long, val text: Long,
    val font: String, val layout: String, val background: String,
)

val CardTemplates = listOf(
    CardTemplate("classic_navy", "Classic Navy", "Corporate", 0xFF0B1F3A, 0xFFC9A646, 0xFFFFFFFF, "SERIF", "LEFT", "GRADIENT"),
    CardTemplate("executive_gold", "Executive Gold", "Corporate", 0xFF1A1A1A, 0xFFD4AF37, 0xFFF5F0E1, "SERIF", "CENTERED", "PATTERN"),
    CardTemplate("charcoal_pro", "Charcoal Pro", "Corporate", 0xFF2B2D33, 0xFFE0B75A, 0xFFFFFFFF, "SANS", "SPLIT", "SOLID"),
    CardTemplate("emerald", "Emerald Prestige", "Corporate", 0xFF0F3D33, 0xFFD9B86C, 0xFFFFFFFF, "SERIF", "SPLIT", "GRADIENT"),
    CardTemplate("minimal_white", "Minimal White", "Personal", 0xFFFFFFFF, 0xFF0B1F3A, 0xFF2B2D33, "SANS", "LEFT", "SOLID"),
    CardTemplate("ocean", "Ocean Gradient", "Personal", 0xFF0E4C75, 0xFF7FD1E8, 0xFFFFFFFF, "SANS", "CENTERED", "GRADIENT"),
    CardTemplate("burgundy", "Burgundy Classic", "Personal", 0xFF5A1426, 0xFFE8C887, 0xFFFFFFFF, "SERIF", "LEFT", "PATTERN"),
    CardTemplate("tech_mono", "Tech Mono", "Personal", 0xFF101418, 0xFF3DDC97, 0xFFE8F0F2, "MONO", "LEFT", "PATTERN"),
)

fun CardProfile.applyTemplate(t: CardTemplate) = copy(
    templateId = t.id, primaryColor = t.primary, accentColor = t.accent, textColor = t.text,
    fontStyle = t.font, layoutStyle = t.layout, backgroundStyle = t.background,
    qrColor = if (t.primary == 0xFFFFFFFF) t.accent else t.primary,
)
