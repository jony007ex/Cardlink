@file:OptIn(ExperimentalMaterial3Api::class)

package com.cardlink.app.ui.screens

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.nfc.tech.Ndef
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cardlink.app.IncomingCard
import com.cardlink.app.appContainer
import com.cardlink.app.data.toCardData
import com.cardlink.app.nearby.NearbyMode
import com.cardlink.app.nearby.NearbyStatus
import com.cardlink.app.nearby.NearbyViewModel
import com.cardlink.app.nfc.NfcShareState
import com.cardlink.app.nfc.NfcStatus
import com.cardlink.app.nfc.NfcUtil
import com.cardlink.app.ui.CardViewModel
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.ScreenScaffold
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.components.findActivity
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.ui.theme.Success
import com.cardlink.app.util.Actions
import com.cardlink.app.util.Links
import com.cardlink.app.util.ShareHelper
import kotlinx.coroutines.launch

@Composable
private fun ModeSwitch(sendSelected: Boolean, onChange: (Boolean) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        SegmentedButton(sendSelected, { onChange(true) }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Send my card") }
        SegmentedButton(!sendSelected, { onChange(false) }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Receive a card") }
    }
}

@Composable
private fun Pulse(icon: ImageVector, active: Boolean, color: Color) {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(1f, 1.35f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "s")
    val a by t.animateFloat(0.45f, 0f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "a")
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        if (active) {
            Box(Modifier.size(150.dp).scale(s).graphicsLayer { alpha = a }.clip(CircleShape).background(color))
            Box(Modifier.size(150.dp).scale(s * 0.8f).graphicsLayer { alpha = a }.clip(CircleShape).background(color))
        }
        Box(Modifier.size(130.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(60.dp))
        }
    }
}

@Composable
private fun StatusBanner(ok: Boolean, text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (ok) Success.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer),
        shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Error, null, tint = if (ok) Success else MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun NfcScreen(vm: CardViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val profile by vm.activeProfile.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var status by remember { mutableStateOf(NfcUtil.status(ctx)) }
    var sendMode by remember { mutableStateOf(true) }
    var sharing by remember { mutableStateOf(false) }
    var delivered by remember { mutableStateOf(false) }
    var receivedUrl by remember { mutableStateOf<String?>(null) }
    var readerMsg by remember { mutableStateOf<String?>(null) }
    val reads by NfcShareState.reads.collectAsState()
    var baseline by remember { mutableIntStateOf(NfcShareState.reads.value) }
    val scope = rememberCoroutineScope()

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        status = NfcUtil.status(ctx)
        if (sharing) activity?.let { NfcUtil.setPreferred(it, true) }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { activity?.let { NfcUtil.setPreferred(it, false) } }
    DisposableEffect(Unit) {
        onDispose { NfcShareState.stop(); activity?.let { NfcUtil.setPreferred(it, false) } }
    }
    LaunchedEffect(reads) {
        if (sharing && reads > baseline) { delivered = true; baseline = reads; vm.recordShare("NFC tap") }
    }

    val data = profile?.toCardData(settings.shareFields)
    val link = data?.let { ShareHelper.primaryLink(it) }

    fun startSharing() {
        val d = data ?: return
        val msg = NfcUtil.buildMessage(d, settings.nfcMode, link)
        NfcShareState.start(msg)
        baseline = NfcShareState.reads.value
        activity?.let { NfcUtil.setPreferred(it, true) }
        sharing = true; delivered = false
    }
    fun stopSharing() { NfcShareState.stop(); activity?.let { NfcUtil.setPreferred(it, false) }; sharing = false }

    // Reader mode for receiving a card from another phone.
    val receiving = !sendMode && (status == NfcStatus.READY || status == NfcStatus.READY_NO_HCE)
    DisposableEffect(receiving, activity) {
        val adapter = NfcAdapter.getDefaultAdapter(ctx)
        val main = Handler(Looper.getMainLooper())
        if (receiving && adapter != null && activity != null) {
            adapter.enableReaderMode(activity, { tag ->
                val result = runCatching {
                    Ndef.get(tag)?.let { ndef -> ndef.connect(); val m = ndef.ndefMessage ?: ndef.cachedNdefMessage; runCatching { ndef.close() }; m }
                }.getOrNull()
                val parsed = NfcUtil.parseMessage(result)
                main.post {
                    when (parsed) {
                        is NfcUtil.ReadResult.Cards -> {
                            ctx.appContainer.incoming.value = IncomingCard(parsed.cards.first(), "NFC tap")
                            readerMsg = "Card received from ${parsed.cards.first().fullName}"
                        }
                        is NfcUtil.ReadResult.Url -> receivedUrl = parsed.url
                        is NfcUtil.ReadResult.Text -> readerMsg = "Received: ${parsed.text}"
                        NfcUtil.ReadResult.Empty -> readerMsg = "No business card found on that device. Ask them to open CardLink → NFC Tap → Send."
                    }
                }
            }, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B, null)
        }
        onDispose { if (adapter != null && activity != null) runCatching { adapter.disableReaderMode(activity) } }
    }

    ScreenScaffold(title = "NFC Tap", onBack = onBack) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            when (status) {
                NfcStatus.UNSUPPORTED -> {
                    item { Pulse(Icons.Filled.Nfc, false, Color.Gray) }
                    item { Text("NFC isn't available on this phone", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center) }
                    item { Text("You can still share instantly with Bluetooth / Nearby, your QR code, or any messaging app.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    return@LazyColumn
                }
                NfcStatus.DISABLED -> {
                    item { Pulse(Icons.Filled.Nfc, false, Color.Gray) }
                    item { Text("NFC is turned off", style = MaterialTheme.typography.titleLarge) }
                    item {
                        Text("1. Tap the button below\n2. Turn on \"NFC\" (sometimes called \"Connected devices → NFC\")\n3. Come back to CardLink",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    item {
                        GoldButton("Open NFC settings", Icons.Filled.Settings, {
                            runCatching { ctx.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
                                .onFailure { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                        })
                    }
                    return@LazyColumn
                }
                else -> {}
            }
            item { ModeSwitch(sendMode) { if (it != sendMode) { stopSharing(); sendMode = it; readerMsg = null } } }
            if (sendMode) {
                if (status == NfcStatus.READY_NO_HCE) {
                    item { StatusBanner(false, "This phone can read NFC cards but can't emulate one. Use Receive mode here, or share with QR / Nearby.") }
                    return@LazyColumn
                }
                item { Pulse(Icons.Filled.Nfc, sharing, if (delivered) Success else Color(0xFF3F7DD8)) }
                item {
                    Text(
                        when { delivered -> "Card delivered!"; sharing -> "Ready — hold phones back to back"; else -> "Tap to start sharing" },
                        style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center,
                    )
                }
                item {
                    Text(
                        "Keep this screen open and unlocked. The other phone just needs NFC switched on; with CardLink it opens your card for saving, otherwise the system offers to open it.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                    )
                }
                item {
                    Column(Modifier.fillMaxWidth()) {
                        Text("Send as", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            SegmentedButton(settings.nfcMode != "LINK", { vm.setNfcMode("VCARD"); if (sharing) stopSharing() }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Contact card") }
                            SegmentedButton(settings.nfcMode == "LINK", {
                                if (link == null) readerMsg = "Add a digital card link or website in Edit to use link mode."
                                else { vm.setNfcMode("LINK"); if (sharing) stopSharing() }
                            }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Web link") }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (settings.nfcMode == "LINK") "Shares ${link?.let { Links.display(it) } ?: "your link"} — opens on almost any phone."
                            else "Shares a vCard contact (no photo) — best between CardLink users.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                readerMsg?.let { m -> item { StatusBanner(false, m) } }
                item {
                    if (sharing) OutlinedButton(onClick = { stopSharing() }, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) { Text("Stop sharing") }
                    else GoldButton("Start NFC sharing", Icons.Filled.Nfc, { startSharing() }, enabled = data != null && data.fullName.isNotBlank())
                }
            } else {
                item { Pulse(Icons.Filled.Download, true, Gold) }
                item { Text("Ready to receive", style = MaterialTheme.typography.titleLarge) }
                item {
                    Text("Ask the other person to open CardLink → Share → NFC Tap → Start sharing, then touch the backs of your phones together.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                readerMsg?.let { m -> item { StatusBanner(m.startsWith("Card received"), m) } }
            }
        }
    }

    receivedUrl?.let { url ->
        AlertDialog(
            onDismissRequest = { receivedUrl = null },
            title = { Text("Open shared link?") },
            text = { Text("The other phone shared:\n\n$url\n\nOnly open links from people you trust.") },
            confirmButton = { TextButton(onClick = { Actions.openUrl(ctx, url); receivedUrl = null }) { Text("Open") } },
            dismissButton = { TextButton(onClick = { receivedUrl = null }) { Text("Cancel") } },
        )
    }
}

private fun bluetoothEnabled(ctx: Context): Boolean = runCatching {
    (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter?.isEnabled == true
}.getOrDefault(false)

@Composable
fun NearbyScreen(cardVm: CardViewModel, vm: NearbyViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by vm.state.collectAsStateWithLifecycle()
    val profile by cardVm.activeProfile.collectAsStateWithLifecycle()
    val perms = remember { NearbyViewModel.requiredPermissions() }
    fun granted() = perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    var hasPerms by remember { mutableStateOf(granted()) }
    var btOn by remember { mutableStateOf(bluetoothEnabled(ctx)) }
    var sendMode by remember { mutableStateOf(true) }
    val localName = profile?.fullName?.ifBlank { null } ?: Build.MODEL

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { hasPerms = granted() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { hasPerms = granted(); btOn = bluetoothEnabled(ctx) }

    fun begin(send: Boolean) {
        if (send) scope.launch { cardVm.shareableCard(withPhoto = true)?.let { vm.startSending(localName, it) } }
        else vm.startReceiving(localName)
    }
    LaunchedEffect(hasPerms) { if (hasPerms) begin(sendMode) }

    ScreenScaffold(title = "Bluetooth / Nearby", onBack = { vm.reset(); onBack() }) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (!hasPerms) {
                item { Pulse(Icons.Filled.Bluetooth, false, Color(0xFF2E9C8F)) }
                item { Text("Allow nearby device access", style = MaterialTheme.typography.titleLarge) }
                item {
                    Text("CardLink uses Bluetooth and Wi-Fi to find nearby phones and send your card directly, encrypted, without the internet. Location access is required by Android for nearby scanning; CardLink never stores your location.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item { GoldButton("Grant permissions", Icons.Filled.Bluetooth, { launcher.launch(perms) }) }
                item {
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", ctx.packageName, null)))
                    }) { Text("Open app settings") }
                }
                return@LazyColumn
            }
            if (!btOn) item {
                SurfaceCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Bluetooth is off", style = MaterialTheme.typography.titleSmall)
                        Text("Turn on Bluetooth for the fastest, most reliable connection.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } }) { Text("Open Bluetooth settings") }
                    }
                }
            }
            item { ModeSwitch(sendMode) { if (it != sendMode) { sendMode = it; begin(it) } } }
            item {
                Pulse(
                    if (sendMode) Icons.Filled.Send else Icons.Filled.Download,
                    state.status in listOf(NearbyStatus.SEARCHING, NearbyStatus.ADVERTISING, NearbyStatus.CONNECTING, NearbyStatus.AWAITING_ACCEPT, NearbyStatus.TRANSFERRING),
                    when (state.status) { NearbyStatus.DONE -> Success; NearbyStatus.FAILED -> MaterialTheme.colorScheme.error; else -> Color(0xFF2E9C8F) },
                )
            }
            item { Text(state.message, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium) }
            if (state.status == NearbyStatus.TRANSFERRING || state.status == NearbyStatus.DONE) item {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)))
            }
            if (state.status == NearbyStatus.FAILED || state.status == NearbyStatus.DONE) item {
                OutlinedButton(onClick = { begin(sendMode) }) { Text(if (state.status == NearbyStatus.DONE) "Share again" else "Try again") }
            }
            if (sendMode && state.mode == NearbyMode.SEND && state.status == NearbyStatus.SEARCHING) {
                item {
                    Text("Ask the other person to open CardLink → Share → Bluetooth / Nearby → Receive. Nearby phones appear below.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
                if (state.endpoints.isEmpty()) item { CircularProgressIndicator() }
                items(state.endpoints, key = { it.id }) { ep ->
                    SurfaceCard {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Smartphone, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(ep.name, style = MaterialTheme.typography.titleMedium)
                                Text("Nearby CardLink user", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(onClick = { vm.sendTo(ep) }, shape = RoundedCornerShape(12.dp)) { Text("Send") }
                        }
                    }
                }
            }
            if (!sendMode && state.status == NearbyStatus.ADVERTISING) item {
                Text("Keep this screen open. You'll be asked to accept before any card is received.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    state.pending?.let { req ->
        AlertDialog(
            onDismissRequest = { vm.rejectPending() },
            icon = { Icon(Icons.Filled.Bluetooth, null) },
            title = { Text("Accept card from ${req.name}?") },
            text = {
                Column {
                    Text("Confirm the code matches on both phones:")
                    Spacer(Modifier.height(8.dp))
                    Text(req.code, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.acceptPending() }) { Text("Accept") } },
            dismissButton = { TextButton(onClick = { vm.rejectPending() }) { Text("Decline") } },
        )
    }
}
