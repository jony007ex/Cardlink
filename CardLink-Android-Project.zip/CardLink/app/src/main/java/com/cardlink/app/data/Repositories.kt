package com.cardlink.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CardRepository(private val db: AppDatabase) {
    private val profileDao = db.profileDao()
    private val contactDao = db.contactDao()
    private val historyDao = db.historyDao()

    val profiles: Flow<List<CardProfile>> = profileDao.observeAll()
    val history: Flow<List<ShareHistory>> = historyDao.observeAll()

    suspend fun ensureDefaultProfile() {
        if (profileDao.count() == 0) profileDao.insert(CardProfile(label = "Corporate"))
    }

    suspend fun saveProfile(p: CardProfile): Long = profileDao.insert(p)
    suspend fun deleteProfile(p: CardProfile) = profileDao.delete(p)
    suspend fun allProfiles() = profileDao.getAll()

    fun searchContacts(q: String) = contactDao.search(q.trim())
    fun observeContact(id: Long) = contactDao.observe(id)
    suspend fun saveContact(c: SavedContact): Long = contactDao.insert(c)
    suspend fun updateContact(c: SavedContact) = contactDao.update(c)
    suspend fun deleteContact(c: SavedContact) = contactDao.delete(c)
    suspend fun allContacts() = contactDao.getAll()

    suspend fun addHistory(h: ShareHistory) = historyDao.insert(h)
    suspend fun clearHistory() = historyDao.clear()
    suspend fun allHistory() = historyDao.getAll()

    /** Replaces all local data with the supplied backup content. */
    suspend fun restoreAll(profiles: List<CardProfile>, contacts: List<SavedContact>, history: List<ShareHistory>) {
        db.withTransaction {
            profileDao.clear(); contactDao.clear(); historyDao.clear()
            profiles.forEach { profileDao.insert(it) }
            contacts.forEach { contactDao.insert(it) }
            history.forEach { historyDao.insert(it) }
            if (profileDao.count() == 0) profileDao.insert(CardProfile())
        }
    }
}

data class AppSettings(
    val theme: String = "SYSTEM",
    val onboarded: Boolean = false,
    val activeProfileId: Long = 0L,
    val shareFields: Set<ShareField> = ShareField.entries.toSet(),
    val nfcMode: String = "VCARD",
)

private val Context.dataStore by preferencesDataStore(name = "cardlink_prefs")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val ACTIVE = longPreferencesKey("active_profile")
        val FIELDS = stringSetPreferencesKey("share_fields")
        val NFC_MODE = stringPreferencesKey("nfc_mode")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            theme = p[Keys.THEME] ?: "SYSTEM",
            onboarded = p[Keys.ONBOARDED] ?: false,
            activeProfileId = p[Keys.ACTIVE] ?: 0L,
            shareFields = p[Keys.FIELDS]?.mapNotNull { n -> ShareField.entries.firstOrNull { it.name == n } }?.toSet()
                ?: ShareField.entries.toSet(),
            nfcMode = p[Keys.NFC_MODE] ?: "VCARD",
        )
    }

    suspend fun setTheme(v: String) { context.dataStore.edit { it[Keys.THEME] = v } }
    suspend fun setOnboarded(v: Boolean) { context.dataStore.edit { it[Keys.ONBOARDED] = v } }
    suspend fun setActiveProfile(id: Long) { context.dataStore.edit { it[Keys.ACTIVE] = id } }
    suspend fun setNfcMode(v: String) { context.dataStore.edit { it[Keys.NFC_MODE] = v } }
    suspend fun setShareFields(fields: Set<ShareField>) {
        context.dataStore.edit { it[Keys.FIELDS] = fields.map { f -> f.name }.toSet() }
    }
}
