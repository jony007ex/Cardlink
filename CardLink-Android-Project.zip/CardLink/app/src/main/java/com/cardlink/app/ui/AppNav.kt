@file:OptIn(ExperimentalLayoutApi::class)

package com.cardlink.app.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cardlink.app.AppContainer
import com.cardlink.app.nearby.NearbyViewModel
import com.cardlink.app.ui.screens.AboutScreen
import com.cardlink.app.ui.screens.ContactDetailScreen
import com.cardlink.app.ui.screens.ContactsScreen
import com.cardlink.app.ui.screens.DesignScreen
import com.cardlink.app.ui.screens.EditCardScreen
import com.cardlink.app.ui.screens.HistoryScreen
import com.cardlink.app.ui.screens.HomeScreen
import com.cardlink.app.ui.screens.NearbyScreen
import com.cardlink.app.ui.screens.NfcScreen
import com.cardlink.app.ui.screens.OnboardingScreen
import com.cardlink.app.ui.screens.ProfilesScreen
import com.cardlink.app.ui.screens.QrScreen
import com.cardlink.app.ui.screens.ReceivedCardDialog
import com.cardlink.app.ui.screens.ScanScreen
import com.cardlink.app.ui.screens.SettingsScreen
import com.cardlink.app.ui.screens.ShareScreen
import com.cardlink.app.ui.screens.SplashScreen
import com.cardlink.app.ui.theme.CardLinkTheme
import com.cardlink.app.util.Actions
import com.cardlink.app.util.toast

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val EDIT = "edit"
    const val DESIGN = "design"
    const val SHARE = "share"
    const val NFC = "nfc"
    const val NEARBY = "nearby"
    const val QR = "qr"
    const val SCAN = "scan"
    const val CONTACTS = "contacts"
    const val CONTACT = "contact/{id}"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val HISTORY = "history"
    const val PROFILES = "profiles"
    fun contact(id: Long) = "contact/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private fun NavHostController.go(route: String) = navigate(route) { launchSingleTop = true }

@Composable
fun CardLinkRoot(container: AppContainer) {
    val factory = remember { VmFactory(container) }
    val cardVm: CardViewModel = viewModel(factory = factory)
    val contactsVm: ContactsViewModel = viewModel(factory = factory)
    val settingsVm: SettingsViewModel = viewModel(factory = factory)
    val settings by cardVm.settings.collectAsStateWithLifecycle()
    val dark = when (settings.theme) { "LIGHT" -> false; "DARK" -> true; else -> isSystemInDarkTheme() }

    CardLinkTheme(darkTheme = dark) {
        val ctx = LocalContext.current
        val nav = rememberNavController()
        val backStack by nav.currentBackStackEntryAsState()
        val route = backStack?.destination?.route
        val tabs = listOf(
            Tab(Routes.HOME, "My Card", Icons.Filled.Badge),
            Tab(Routes.SHARE, "Share", Icons.Filled.Share),
            Tab(Routes.CONTACTS, "Contacts", Icons.Filled.Contacts),
            Tab(Routes.SETTINGS, "Settings", Icons.Filled.Settings),
        )
        val incoming by container.incoming.collectAsStateWithLifecycle()

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (tabs.any { it.route == route }) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(Routes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.secondaryContainer),
                            )
                        }
                    }
                }
            },
        ) { pad ->
            NavHost(
                navController = nav, startDestination = Routes.SPLASH,
                modifier = Modifier.padding(pad).consumeWindowInsets(pad),
                enterTransition = { fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 10 } },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(260)) },
                popExitTransition = { fadeOut(tween(200)) + slideOutHorizontally(tween(260)) { it / 10 } },
            ) {
                composable(Routes.SPLASH) {
                    SplashScreen(container) { onboarded ->
                        nav.navigate(if (onboarded) Routes.HOME else Routes.ONBOARDING) { popUpTo(Routes.SPLASH) { inclusive = true } }
                    }
                }
                composable(Routes.ONBOARDING) {
                    OnboardingScreen {
                        settingsVm.setOnboarded()
                        val empty = cardVm.activeProfile.value?.fullName.isNullOrBlank()
                        nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                        if (empty) nav.go(Routes.EDIT)
                    }
                }
                composable(Routes.HOME) {
                    HomeScreen(
                        cardVm,
                        onEdit = { nav.go(Routes.EDIT) }, onDesign = { nav.go(Routes.DESIGN) },
                        onShare = { nav.navigate(Routes.SHARE) { popUpTo(Routes.HOME) { saveState = true }; launchSingleTop = true } },
                        onQr = { nav.go(Routes.QR) }, onScan = { nav.go(Routes.SCAN) }, onProfiles = { nav.go(Routes.PROFILES) },
                    )
                }
                composable(Routes.EDIT) {
                    val p by cardVm.activeProfile.collectAsStateWithLifecycle()
                    p?.let { prof ->
                        EditCardScreen(prof, onSave = { cardVm.save(it) { ctx.toast("Card saved") }; nav.popBackStack() }, onBack = { nav.popBackStack() })
                    } ?: Loading()
                }
                composable(Routes.DESIGN) {
                    val p by cardVm.activeProfile.collectAsStateWithLifecycle()
                    p?.let { prof ->
                        DesignScreen(prof, onSave = { cardVm.save(it) { ctx.toast("Design applied") }; nav.popBackStack() }, onBack = { nav.popBackStack() })
                    } ?: Loading()
                }
                composable(Routes.SHARE) {
                    ShareScreen(
                        cardVm, onNfc = { nav.go(Routes.NFC) }, onNearby = { nav.go(Routes.NEARBY) }, onQr = { nav.go(Routes.QR) },
                        onScan = { nav.go(Routes.SCAN) }, onHistory = { nav.go(Routes.HISTORY) },
                        onPrivacy = { nav.navigate(Routes.SETTINGS) { popUpTo(Routes.HOME) { saveState = true }; launchSingleTop = true } },
                    )
                }
                composable(Routes.NFC) { NfcScreen(cardVm) { nav.popBackStack() } }
                composable(Routes.NEARBY) {
                    val nearbyVm: NearbyViewModel = viewModel(factory = factory)
                    NearbyScreen(cardVm, nearbyVm) { nav.popBackStack() }
                }
                composable(Routes.QR) { QrScreen(cardVm, onBack = { nav.popBackStack() }, onScan = { nav.go(Routes.SCAN) }) }
                composable(Routes.SCAN) { ScanScreen { nav.popBackStack() } }
                composable(Routes.CONTACTS) { ContactsScreen(contactsVm, onOpen = { nav.go(Routes.contact(it)) }, onScan = { nav.go(Routes.SCAN) }) }
                composable(Routes.CONTACT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments?.getLong("id") ?: 0L
                    ContactDetailScreen(contactsVm, id) { nav.popBackStack() }
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(settingsVm, onProfiles = { nav.go(Routes.PROFILES) }, onHistory = { nav.go(Routes.HISTORY) }, onAbout = { nav.go(Routes.ABOUT) })
                }
                composable(Routes.PROFILES) { ProfilesScreen(cardVm, onBack = { nav.popBackStack() }, onEdit = { nav.go(Routes.EDIT) }) }
                composable(Routes.HISTORY) { HistoryScreen(settingsVm) { nav.popBackStack() } }
                composable(Routes.ABOUT) { AboutScreen { nav.popBackStack() } }
            }
        }

        incoming?.let { inc ->
            ReceivedCardDialog(
                incoming = inc,
                onSave = { alsoPhone ->
                    container.incoming.value = null
                    contactsVm.saveIncoming(inc) { id ->
                        ctx.toast("Saved to My Contacts")
                        if (route != Routes.SPLASH && route != Routes.ONBOARDING) nav.go(Routes.contact(id))
                    }
                    if (alsoPhone) Actions.addToPhoneContacts(ctx, inc.card, null)
                },
                onDismiss = { container.incoming.value = null },
            )
        }
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}
