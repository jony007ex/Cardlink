package com.cardlink.app

import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.IntentCompat
import androidx.lifecycle.lifecycleScope
import com.cardlink.app.data.toContact
import com.cardlink.app.nfc.NfcUtil
import com.cardlink.app.ui.CardLinkRoot
import com.cardlink.app.util.ImageStore
import com.cardlink.app.util.VCard
import com.cardlink.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        val container = appContainer
        setContent { CardLinkRoot(container) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Handles cards arriving from an NFC tap or from opening a .vcf file in another app. */
    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val container = appContainer
        when (intent.action) {
            NfcAdapter.ACTION_NDEF_DISCOVERED -> {
                val msgs = IntentCompat.getParcelableArrayExtra(intent, NfcAdapter.EXTRA_NDEF_MESSAGES, NdefMessage::class.java)
                val msg = msgs?.firstOrNull() as? NdefMessage
                when (val r = NfcUtil.parseMessage(msg)) {
                    is NfcUtil.ReadResult.Cards -> container.incoming.value = IncomingCard(r.cards.first(), "NFC tap")
                    else -> toast("No business card found in that NFC tag")
                }
            }
            Intent.ACTION_VIEW -> {
                val uri = intent.data ?: return
                lifecycleScope.launch {
                    val cards = withContext(Dispatchers.IO) {
                        runCatching {
                            contentResolver.openInputStream(uri)?.use { VCard.parseAll(it.readBytes().toString(Charsets.UTF_8)) }
                        }.getOrNull().orEmpty()
                    }
                    when {
                        cards.isEmpty() -> toast("This file doesn't contain a valid contact card")
                        cards.size == 1 -> container.incoming.value = IncomingCard(cards.first(), "vCard file")
                        else -> {
                            withContext(Dispatchers.IO) {
                                cards.forEach { c ->
                                    val photo = ImageStore.saveBase64(this@MainActivity, c.photoBase64)
                                    container.repo.saveContact(c.copy(photoBase64 = null).toContact(photo, "vCard file"))
                                }
                            }
                            toast("Imported ${cards.size} contacts into My Contacts")
                        }
                    }
                }
            }
        }
    }
}
