package com.cardlink.app.nfc

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.cardemulation.CardEmulation
import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import com.cardlink.app.data.CardData
import com.cardlink.app.util.Links
import com.cardlink.app.util.VCard
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Holds the NDEF message exposed over NFC. The HCE service only answers while [active] is true,
 * which only happens after the user explicitly taps "Start NFC sharing".
 */
object NfcShareState {
    @Volatile var ndefFile: ByteArray? = null
        private set
    @Volatile var active: Boolean = false
        private set
    /** Incremented each time a reader finished reading the card. */
    val reads = MutableStateFlow(0)

    fun start(message: NdefMessage) {
        val bytes = message.toByteArray()
        ndefFile = byteArrayOf((bytes.size shr 8).toByte(), (bytes.size and 0xFF).toByte()) + bytes
        active = true
    }

    fun stop() { active = false; ndefFile = null }
    fun onRead() { reads.value = reads.value + 1 }
}

/**
 * Emulates an NFC Forum Type 4 Tag (Host Card Emulation). Any NFC phone that taps this phone
 * reads the card as a standard NDEF tag — no Android Beam required.
 */
class CardHceService : HostApduService() {
    private var selected: ByteArray? = null
    private var isNdefFile = false

    override fun processCommandApdu(apdu: ByteArray, extras: Bundle?): ByteArray {
        val ndef = NfcShareState.ndefFile
        if (!NfcShareState.active || ndef == null) return SW_NOT_FOUND
        if (apdu.size < 4) return SW_WRONG_LENGTH
        val ins = apdu[1]
        val p1 = apdu[2]
        return when {
            ins == INS_SELECT && p1 == 0x04.toByte() -> {
                if (apdu.size < 5) return SW_WRONG_LENGTH
                val lc = apdu[4].toInt() and 0xFF
                if (apdu.size < 5 + lc) return SW_WRONG_LENGTH
                val aid = apdu.copyOfRange(5, 5 + lc)
                selected = null; isNdefFile = false
                if (aid.contentEquals(NDEF_AID)) SW_OK else SW_NOT_FOUND
            }
            ins == INS_SELECT && p1 == 0x00.toByte() -> {
                if (apdu.size < 7) return SW_WRONG_LENGTH
                val fid = apdu.copyOfRange(5, 7)
                when {
                    fid.contentEquals(CC_FILE_ID) -> { selected = capabilityContainer(ndef.size); isNdefFile = false; SW_OK }
                    fid.contentEquals(NDEF_FILE_ID) -> { selected = ndef; isNdefFile = true; SW_OK }
                    else -> SW_NOT_FOUND
                }
            }
            ins == INS_READ_BINARY -> {
                val file = selected ?: return SW_NOT_FOUND
                val offset = ((apdu[2].toInt() and 0xFF) shl 8) or (apdu[3].toInt() and 0xFF)
                var le = if (apdu.size > 4) apdu[4].toInt() and 0xFF else 0
                if (le == 0) le = 256
                if (offset > file.size) return SW_WRONG_P1P2
                val end = minOf(file.size, offset + le)
                if (isNdefFile && end == file.size && end > 2) NfcShareState.onRead()
                file.copyOfRange(offset, end) + SW_OK
            }
            else -> SW_INS_NOT_SUPPORTED
        }
    }

    override fun onDeactivated(reason: Int) { selected = null; isNdefFile = false }

    private fun capabilityContainer(ndefFileSize: Int): ByteArray {
        val max = ndefFileSize.coerceAtLeast(0x00FF).coerceAtMost(0x7FFF)
        return byteArrayOf(
            0x00, 0x0F,             // CCLEN
            0x20,                   // Mapping version 2.0
            0x00, 0xFF.toByte(),    // MLe – max R-APDU data size
            0x00, 0xFF.toByte(),    // MLc – max C-APDU data size
            0x04, 0x06,             // NDEF File Control TLV
            0xE1.toByte(), 0x04,    // NDEF file id
            (max shr 8).toByte(), (max and 0xFF).toByte(),
            0x00,                   // read access: granted
            0xFF.toByte(),          // write access: denied
        )
    }

    companion object {
        private val INS_SELECT = 0xA4.toByte()
        private val INS_READ_BINARY = 0xB0.toByte()
        private val NDEF_AID = byteArrayOf(0xD2.toByte(), 0x76, 0x00, 0x00, 0x85.toByte(), 0x01, 0x01)
        private val CC_FILE_ID = byteArrayOf(0xE1.toByte(), 0x03)
        private val NDEF_FILE_ID = byteArrayOf(0xE1.toByte(), 0x04)
        private val SW_OK = byteArrayOf(0x90.toByte(), 0x00)
        private val SW_NOT_FOUND = byteArrayOf(0x6A, 0x82.toByte())
        private val SW_WRONG_LENGTH = byteArrayOf(0x67, 0x00)
        private val SW_WRONG_P1P2 = byteArrayOf(0x6B, 0x00)
        private val SW_INS_NOT_SUPPORTED = byteArrayOf(0x6D, 0x00)
    }
}

enum class NfcStatus { UNSUPPORTED, DISABLED, READY_NO_HCE, READY }

object NfcUtil {
    fun status(ctx: Context): NfcStatus {
        val adapter = NfcAdapter.getDefaultAdapter(ctx) ?: return NfcStatus.UNSUPPORTED
        if (!adapter.isEnabled) return NfcStatus.DISABLED
        return if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)) NfcStatus.READY
        else NfcStatus.READY_NO_HCE
    }

    /** VCARD mode sends a contact record; LINK mode sends a URL any phone can open. */
    fun buildMessage(data: CardData, mode: String, link: String?): NdefMessage =
        if (mode == "LINK" && link != null) NdefMessage(NdefRecord.createUri(link))
        else NdefMessage(
            NdefRecord.createMime("text/vcard", VCard.build(data.copy(photoBase64 = null), includePhoto = false).toByteArray(Charsets.UTF_8)),
        )

    fun setPreferred(activity: Activity, enable: Boolean) {
        runCatching {
            val adapter = NfcAdapter.getDefaultAdapter(activity) ?: return
            val ce = CardEmulation.getInstance(adapter)
            if (enable) ce.setPreferredService(activity, ComponentName(activity, CardHceService::class.java))
            else ce.unsetPreferredService(activity)
        }
    }

    sealed interface ReadResult {
        data class Cards(val cards: List<CardData>) : ReadResult
        data class Url(val url: String) : ReadResult
        data class Text(val text: String) : ReadResult
        data object Empty : ReadResult
    }

    fun parseMessage(msg: NdefMessage?): ReadResult {
        if (msg == null) return ReadResult.Empty
        for (r in msg.records) {
            if (r.tnf == NdefRecord.TNF_MIME_MEDIA) {
                val type = String(r.type, Charsets.US_ASCII).lowercase()
                if (type == "text/vcard" || type == "text/x-vcard") {
                    val cards = VCard.parseAll(String(r.payload, Charsets.UTF_8))
                    if (cards.isNotEmpty()) return ReadResult.Cards(cards)
                }
            }
            r.toUri()?.toString()?.let { u ->
                return if (Links.isWebUrl(u)) ReadResult.Url(u) else ReadResult.Text(u)
            }
        }
        return ReadResult.Empty
    }
}
