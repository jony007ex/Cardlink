package com.cardlink.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY id")
    fun observeAll(): Flow<List<CardProfile>>

    @Query("SELECT * FROM profiles ORDER BY id")
    suspend fun getAll(): List<CardProfile>

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: CardProfile): Long

    @Delete
    suspend fun delete(p: CardProfile)

    @Query("DELETE FROM profiles")
    suspend fun clear()
}

@Dao
interface ContactDao {
    @Query(
        "SELECT * FROM contacts WHERE fullName LIKE '%' || :q || '%' OR company LIKE '%' || :q || '%' " +
            "OR designation LIKE '%' || :q || '%' OR email LIKE '%' || :q || '%' OR phone LIKE '%' || :q || '%' " +
            "OR notes LIKE '%' || :q || '%' ORDER BY fullName COLLATE NOCASE"
    )
    fun search(q: String): Flow<List<SavedContact>>

    @Query("SELECT * FROM contacts WHERE id = :id")
    fun observe(id: Long): Flow<SavedContact?>

    @Query("SELECT * FROM contacts ORDER BY fullName COLLATE NOCASE")
    suspend fun getAll(): List<SavedContact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(c: SavedContact): Long

    @Update
    suspend fun update(c: SavedContact)

    @Delete
    suspend fun delete(c: SavedContact)

    @Query("DELETE FROM contacts")
    suspend fun clear()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM share_history ORDER BY timestamp DESC LIMIT 500")
    fun observeAll(): Flow<List<ShareHistory>>

    @Query("SELECT * FROM share_history ORDER BY timestamp DESC")
    suspend fun getAll(): List<ShareHistory>

    @Insert
    suspend fun insert(h: ShareHistory): Long

    @Query("DELETE FROM share_history")
    suspend fun clear()
}

@Database(entities = [CardProfile::class, SavedContact::class, ShareHistory::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun contactDao(): ContactDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "cardlink.db")
                .fallbackToDestructiveMigration()
                .build().also { instance = it }
        }
    }
}
