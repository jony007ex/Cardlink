@file:OptIn(ExperimentalMaterial3Api::class)

package com.cardlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cardlink.app.IncomingCard
import com.cardlink.app.data.CardData
import com.cardlink.app.data.SavedContact
import com.cardlink.app.data.toCardData
import com.cardlink.app.ui.ContactsViewModel
import com.cardlink.app.ui.components.Avatar
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.InfoRow
import com.cardlink.app.ui.components.ScreenScaffold
import com.cardlink.app.ui.components.SectionTitle
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.ui.theme.Navy
import com.cardlink.app.util.Actions
import com.cardlink.app.util.ImageStore
import com.cardlink.app.util.Links
import com.cardlink.app.util.ShareHelper
import com.cardlink.app.util.toast
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun ContactsScreen(vm: ContactsViewModel, onOpen: (Long) -> Unit, onScan: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    var menu by remember { mutableStateOf(false) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val n = runCatching { vm.importVcf(uri) }.getOrDefault(-1)
            ctx.toast(if (n >= 0) "Imported $n contact(s)" else "Could not read that file")
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri ->
        if (uri != null) scope.launch {
            val n = runCatching { vm.exportVcf(uri) }.getOrDefault(-1)
            ctx.toast(if (n >= 0) "Exported $n contact(s)" else "Export failed")
        }
    }

    ScreenScaffold(
        title = "My Contacts",
        actions = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Import vCard (.vcf)") }, leadingIcon = { Icon(Icons.Filled.FileDownload, null) },
                        onClick = { menu = false; importer.launch(arrayOf("text/x-vcard", "text/vcard", "text/directory", "application/octet-stream", "*/*")) })
                    DropdownMenuItem(text = { Text("Export all as vCard") }, leadingIcon = { Icon(Icons.Filled.FileUpload, null) },
                        onClick = { menu = false; exporter.launch("CardLink_Contacts.vcf") }, enabled = contacts.isNotEmpty() || query.isNotEmpty())
                }
            }
        },
        floating = {
            ExtendedFloatingActionButton(onClick = onScan, containerColor = Gold, contentColor = Navy,
                icon = { Icon(Icons.Filled.QrCodeScanner, null) }, text = { Text("Scan card") })
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { vm.query.value = it },
                placeholder = { Text("Search name, company, email…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { vm.query.value = "" }) { Icon(Icons.Filled.Clear, "Clear") } },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            )
            if (contacts.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Filled.Contacts, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(16.dp))
                    Text(if (query.isEmpty()) "No saved cards yet" else "No matches", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (query.isEmpty()) "Cards you receive via NFC, Nearby, QR or vCard files appear here." else "Try a different search.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { Text("${contacts.size} contact(s)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(contacts, key = { it.id }) { c -> ContactRow(c) { onOpen(c.id) } }
                }
            }
        }
    }
}

@Composable
private fun ContactRow(c: SavedContact, onClick: () -> Unit) {
    SurfaceCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.photoPath, c.fullName, 52.dp, Gold, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(c.fullName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val sub = listOf(c.designation, c.company).filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("via ${c.source}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

private data class Row4(val icon: ImageVector, val label: String, val value: String, val action: (() -> Unit)?)

private fun detailRows(ctx: android.content.Context, d: CardData): List<Row4> = buildList {
    if (d.phone.isNotBlank()) add(Row4(Icons.Filled.Phone, "Phone", d.phone) { Actions.dial(ctx, d.phone) })
    if (d.whatsapp.isNotBlank()) add(Row4(Icons.Filled.Chat, "WhatsApp", d.whatsapp) { Actions.whatsapp(ctx, d.whatsapp) })
    if (d.email.isNotBlank()) add(Row4(Icons.Filled.Email, "Email", d.email) { Actions.email(ctx, d.email) })
    if (d.address.isNotBlank()) add(Row4(Icons.Filled.LocationOn, "Office address", d.address) { Actions.map(ctx, d.address) })
    if (d.department.isNotBlank()) add(Row4(Icons.Filled.Business, "Department", d.department, null))
    if (d.website.isNotBlank()) add(Row4(Icons.Filled.Language, "Website", Links.display(d.website)) { Actions.openUrl(ctx, d.website) })
    if (d.linkedin.isNotBlank()) add(Row4(Icons.Filled.Work, "LinkedIn", Links.display(d.linkedin)) { Actions.openUrl(ctx, d.linkedin) })
    if (d.facebook.isNotBlank()) add(Row4(Icons.Filled.Public, "Facebook", Links.display(d.facebook)) { Actions.openUrl(ctx, d.facebook) })
    d.otherLinks.forEach { l -> add(Row4(Icons.Filled.Link, l.label, Links.display(l.url)) { Actions.openUrl(ctx, l.url) }) }
    if (d.cardUrl.isNotBlank()) add(Row4(Icons.Filled.Link, "Digital card", Links.display(d.cardUrl)) { Actions.openUrl(ctx, d.cardUrl) })
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalButton(onClick = onClick, enabled = enabled, shape = CircleShape, modifier = Modifier.size(56.dp), contentPadding = PaddingValues(0.dp)) {
            Icon(icon, label)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun ContactDetailScreen(vm: ContactsViewModel, id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contact by remember(id) { vm.contact(id) }.collectAsState(initial = null)
    var confirmDelete by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf<String?>(null) }

    val c = contact
    LaunchedEffect(c?.id) { if (c != null && notes == null) notes = c.notes }

    ScreenScaffold(title = "Contact", onBack = onBack, actions = {
        if (c != null) {
            IconButton(onClick = { scope.launch { ShareHelper.shareContactVcf(ctx, c.toCardData(), c.photoPath) } }) { Icon(Icons.Filled.Share, "Share") }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }) { pad ->
        if (c == null) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@ScreenScaffold
        }
        val d = c.toCardData()
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(c.photoPath, c.fullName, 110.dp, Gold, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(12.dp))
                    Text(c.fullName, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                    if (c.designation.isNotBlank()) Text(c.designation, color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.titleMedium)
                    if (c.company.isNotBlank()) Text(c.company, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    AssistChip(onClick = {}, label = { Text("Saved via ${c.source} · ${DateFormat.getDateInstance().format(Date(c.savedAt))}") })
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    QuickAction(Icons.Filled.Call, "Call", c.phone.isNotBlank()) { Actions.dial(ctx, c.phone) }
                    QuickAction(Icons.Filled.Chat, "WhatsApp", c.whatsapp.isNotBlank() || c.phone.isNotBlank()) { Actions.whatsapp(ctx, c.whatsapp.ifBlank { c.phone }) }
                    QuickAction(Icons.Filled.Email, "Email", c.email.isNotBlank()) { Actions.email(ctx, c.email) }
                    QuickAction(Icons.Filled.Language, "Website", c.website.isNotBlank()) { Actions.openUrl(ctx, c.website) }
                }
            }
            val rows = detailRows(ctx, d)
            if (rows.isNotEmpty()) item {
                SurfaceCard { Column(Modifier.padding(6.dp)) { rows.forEach { r -> InfoRow(r.icon, r.label, r.value, r.action) } } }
            }
            if (c.bio.isNotBlank()) item {
                Column {
                    SectionTitle("About")
                    SurfaceCard { Text(c.bio, Modifier.padding(16.dp)) }
                }
            }
            item {
                Column {
                    SectionTitle("My private notes")
                    OutlinedTextField(
                        value = notes.orEmpty(), onValueChange = { notes = it },
                        placeholder = { Text("Where you met, follow-ups, interests…") },
                        leadingIcon = { Icon(Icons.Filled.Notes, null) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), shape = RoundedCornerShape(14.dp),
                    )
                    if ((notes ?: "") != c.notes) {
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { vm.update(c.copy(notes = notes.orEmpty())); ctx.toast("Notes saved") }, shape = RoundedCornerShape(12.dp)) { Text("Save notes") }
                    }
                }
            }
            item { GoldButton("Add to phone contacts", Icons.Filled.PersonAdd, { Actions.addToPhoneContacts(ctx, d, c.photoPath) }) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (confirmDelete && c != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${c.fullName}?") },
            text = { Text("This removes the card and your notes from CardLink. Contacts already exported to your phone are not affected.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(c); onBack() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

/** Preview shown whenever a card arrives (NFC, Nearby, QR or .vcf). Nothing is saved without consent. */
@Composable
fun ReceivedCardDialog(incoming: IncomingCard, onSave: (alsoPhone: Boolean) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val d = incoming.card
    val photo = remember(d.photoBase64) { ImageStore.decodeBase64(d.photoBase64)?.asImageBitmap() }
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.padding(20.dp),
        title = { Text("New business card", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Navy).padding(18.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(null, d.fullName, 64.dp, Gold, Gold, Navy, bitmap = photo)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(d.fullName, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleLarge)
                            if (d.designation.isNotBlank()) Text(d.designation, color = Gold)
                            val org = listOf(d.company, d.department).filter { it.isNotBlank() }.joinToString(" · ")
                            if (org.isNotBlank()) Text(org, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Received via ${incoming.source}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                detailRows(ctx, d).forEach { r -> InfoRow(r.icon, r.label, r.value, null) }
                if (d.bio.isNotBlank()) Text(d.bio, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { onSave(true) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Filled.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Save & add to phone contacts")
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(false) }, shape = RoundedCornerShape(12.dp)) { Text("Save to My Contacts") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Discard") } },
    )
}
