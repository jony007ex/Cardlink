package com.cardlink.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** The user's own business card profile (multiple profiles supported). */
@Entity(tableName = "profiles")
data class CardProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String = "Corporate",
    val fullName: String = "",
    val designation: String = "",
    val company: String = "",
    val department: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val address: String = "",
    val website: String = "",
    val linkedin: String = "",
    val facebook: String = "",
    /** Newline separated "Label|url" entries. */
    val otherLinks: String = "",
    val bio: String = "",
    /** Optional public link to a hosted card (e.g. personal page). */
    val cardUrl: String = "",
    val photoPath: String? = null,
    val logoPath: String? = null,
    val templateId: String = "classic_navy",
    val primaryColor: Long = 0xFF0B1F3A,
    val accentColor: Long = 0xFFC9A646,
    val textColor: Long = 0xFFFFFFFF,
    /** SERIF, SANS, MONO */
    val fontStyle: String = "SERIF",
    /** LEFT, CENTERED, SPLIT */
    val layoutStyle: String = "LEFT",
    /** SOLID, GRADIENT, PATTERN */
    val backgroundStyle: String = "GRADIENT",
    val qrColor: Long = 0xFF0B1F3A,
    val updatedAt: Long = System.currentTimeMillis(),
)

/** A business card received from someone else. */
@Entity(tableName = "contacts")
data class SavedContact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String = "",
    val designation: String = "",
    val company: String = "",
    val department: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val address: String = "",
    val website: String = "",
    val linkedin: String = "",
    val facebook: String = "",
    val otherLinks: String = "",
    val bio: String = "",
    val cardUrl: String = "",
    val photoPath: String? = null,
    val notes: String = "",
    val source: String = "Manual",
    val savedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "share_history")
data class ShareHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val method: String,
    /** SENT or RECEIVED */
    val direction: String,
    val detail: String,
    val timestamp: Long = System.currentTimeMillis(),
)
