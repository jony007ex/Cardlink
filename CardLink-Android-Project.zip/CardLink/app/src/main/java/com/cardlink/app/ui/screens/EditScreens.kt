@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.cardlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.CardTemplates
import com.cardlink.app.data.SocialLink
import com.cardlink.app.data.applyTemplate
import com.cardlink.app.data.formatLinks
import com.cardlink.app.data.parseLinks
import com.cardlink.app.ui.components.Avatar
import com.cardlink.app.ui.components.BusinessCard
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.ScreenScaffold
import com.cardlink.app.ui.components.SectionTitle
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.util.ImageStore
import com.cardlink.app.util.Links
import com.cardlink.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun Field(
    value: String, onChange: (String) -> Unit, label: String, icon: ImageVector,
    keyboard: KeyboardType = KeyboardType.Text, error: String? = null, singleLine: Boolean = true,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.Words, hint: String? = null,
) {
    val support = error ?: hint
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        leadingIcon = { Icon(icon, null) }, singleLine = singleLine, minLines = if (singleLine) 1 else 3,
        isError = error != null,
        supportingText = if (support != null) { { Text(support) } } else null,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, capitalization = capitalization, imeAction = if (singleLine) ImeAction.Next else ImeAction.Default),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
    )
}

private fun urlError(v: String) = if (v.isNotBlank() && Links.normalize(v) == null) "Enter a valid web address" else null
private fun normUrl(v: String) = if (v.isBlank()) "" else Links.normalize(v) ?: v.trim()

@Composable
fun EditCardScreen(profile: CardProfile, onSave: (CardProfile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var d by remember(profile.id) { mutableStateOf(profile) }
    var links by remember(profile.id) { mutableStateOf(parseLinks(profile.otherLinks)) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = withContext(Dispatchers.IO) { ImageStore.importFromUri(ctx, uri, 640) }
            if (path != null) d = d.copy(photoPath = path) else ctx.toast("Could not load that image")
        }
    }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = withContext(Dispatchers.IO) { ImageStore.importFromUri(ctx, uri, 400, png = true) }
            if (path != null) d = d.copy(logoPath = path) else ctx.toast("Could not load that image")
        }
    }

    val emailErr = if (d.email.isNotBlank() && !Links.isValidEmail(d.email)) "Enter a valid email address" else null
    val phoneErr = if (d.phone.isNotBlank() && !Links.isValidPhone(d.phone)) "Use digits, spaces and an optional +" else null
    val waErr = if (d.whatsapp.isNotBlank() && !Links.isValidPhone(d.whatsapp)) "Include country code, e.g. +8801…" else null
    val webErr = urlError(d.website)
    val liErr = urlError(d.linkedin) ?: if (d.linkedin.isNotBlank() && !d.linkedin.contains("linkedin", true)) "This doesn't look like a LinkedIn link" else null
    val fbErr = urlError(d.facebook)
    val cardErr = urlError(d.cardUrl)
    val linkErr = links.any { it.url.isNotBlank() && Links.normalize(it.url) == null }
    val canSave = d.fullName.isNotBlank() && listOf(emailErr, phoneErr, waErr, webErr, fbErr, cardErr).all { it == null } &&
        (liErr == null || liErr.startsWith("This")) && !linkErr

    fun save() {
        onSave(
            d.copy(
                fullName = d.fullName.trim(), website = normUrl(d.website), linkedin = normUrl(d.linkedin),
                facebook = normUrl(d.facebook), cardUrl = normUrl(d.cardUrl),
                otherLinks = formatLinks(links.map { it.copy(url = normUrl(it.url)) }),
            ),
        )
    }

    ScreenScaffold(
        title = "Edit My Card", onBack = onBack,
        actions = { TextButton(onClick = { save() }, enabled = canSave) { Text("Save", fontWeight = FontWeight.Bold) } },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).imePadding(),
            contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { BusinessCard(d.copy(otherLinks = formatLinks(links))) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.clickable { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                            Avatar(d.photoPath, d.fullName, 84.dp, Gold, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(28.dp).clip(CircleShape).background(Gold),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.AddAPhoto, null, Modifier.size(16.dp), tint = Color.Black) }
                        }
                        if (d.photoPath != null) TextButton(onClick = { d = d.copy(photoPath = null) }) { Text("Remove") }
                        else Text("Photo", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(84.dp).clip(RoundedCornerShape(16.dp))
                                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(16.dp))
                                .clickable { logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            contentAlignment = Alignment.Center,
                        ) {
                            val lp = d.logoPath
                            if (lp != null && File(lp).exists()) AsyncImage(File(lp), "Logo", Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
                            else Icon(Icons.Filled.Apartment, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (d.logoPath != null) TextButton(onClick = { d = d.copy(logoPath = null) }) { Text("Remove") }
                        else Text("Company logo", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            item { SectionTitle("Card profile") }
            item { Field(d.label, { d = d.copy(label = it) }, "Profile name (e.g. Corporate, Personal)", Icons.Filled.Label) }
            item { SectionTitle("Identity") }
            item { Field(d.fullName, { d = d.copy(fullName = it) }, "Full name *", Icons.Filled.Person, error = if (d.fullName.isBlank()) "Required" else null) }
            item { Field(d.designation, { d = d.copy(designation = it) }, "Professional designation", Icons.Filled.Badge) }
            item { Field(d.company, { d = d.copy(company = it) }, "Company / organization", Icons.Filled.Business) }
            item { Field(d.department, { d = d.copy(department = it) }, "Department", Icons.Filled.Apartment) }
            item { SectionTitle("Contact") }
            item { Field(d.phone, { d = d.copy(phone = it) }, "Business phone", Icons.Filled.Phone, KeyboardType.Phone, phoneErr) }
            item {
                Field(d.whatsapp, { d = d.copy(whatsapp = it) }, "WhatsApp number", Icons.Filled.Chat, KeyboardType.Phone, waErr, hint = "With country code")
            }
            if (d.phone.isNotBlank() && d.whatsapp.isBlank()) item {
                TextButton(onClick = { d = d.copy(whatsapp = d.phone) }) { Text("Use business phone for WhatsApp") }
            }
            item { Field(d.email, { d = d.copy(email = it.trim()) }, "Professional email", Icons.Filled.Email, KeyboardType.Email, emailErr, capitalization = KeyboardCapitalization.None) }
            item { Field(d.address, { d = d.copy(address = it) }, "Office address", Icons.Filled.LocationOn, singleLine = false) }
            item { SectionTitle("Online") }
            item { Field(d.website, { d = d.copy(website = it.trim()) }, "Company website", Icons.Filled.Language, KeyboardType.Uri, webErr, capitalization = KeyboardCapitalization.None) }
            item { Field(d.linkedin, { d = d.copy(linkedin = it.trim()) }, "LinkedIn profile URL", Icons.Filled.Work, KeyboardType.Uri, liErr, capitalization = KeyboardCapitalization.None) }
            item { Field(d.facebook, { d = d.copy(facebook = it.trim()) }, "Facebook profile URL", Icons.Filled.Public, KeyboardType.Uri, fbErr, capitalization = KeyboardCapitalization.None) }
            item {
                Field(
                    d.cardUrl, { d = d.copy(cardUrl = it.trim()) }, "Digital card link (optional)", Icons.Filled.Link, KeyboardType.Uri, cardErr,
                    capitalization = KeyboardCapitalization.None, hint = "Shared when someone picks \"Card link\" or NFC link mode",
                )
            }
            item {
                SurfaceCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Other social links", style = MaterialTheme.typography.titleMedium)
                        links.forEachIndexed { i, l ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedTextField(l.label, { v -> links = links.toMutableList().also { it[i] = l.copy(label = v) } },
                                        label = { Text("Name (e.g. X, Instagram)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                                    OutlinedTextField(l.url, { v -> links = links.toMutableList().also { it[i] = l.copy(url = v.trim()) } },
                                        label = { Text("URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                                        isError = l.url.isNotBlank() && Links.normalize(l.url) == null,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                                }
                                IconButton(onClick = { links = links.toMutableList().also { it.removeAt(i) } }) { Icon(Icons.Filled.Delete, "Remove") }
                            }
                        }
                        OutlinedButton(onClick = { links = links + SocialLink("", "") }) {
                            Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Add link")
                        }
                    }
                }
            }
            item { SectionTitle("Introduction") }
            item {
                Field(d.bio, { if (it.length <= 500) d = d.copy(bio = it) }, "Short professional introduction", Icons.Filled.Notes,
                    singleLine = false, capitalization = KeyboardCapitalization.Sentences, hint = "${d.bio.length}/500")
            }
            item { GoldButton("Save card", Icons.Filled.Check, { save() }, Modifier.padding(top = 4.dp), enabled = canSave) }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

private val Palette = listOf(
    0xFF0B1F3A, 0xFF1C3A63, 0xFF0E4C75, 0xFF2B2D33, 0xFF101418, 0xFF1A1A1A, 0xFF0F3D33, 0xFF5A1426,
    0xFF4A2C6F, 0xFFFFFFFF, 0xFFF7F5F0, 0xFFC9A646, 0xFFD4AF37, 0xFFE8C887, 0xFF7FD1E8, 0xFF3DDC97, 0xFFE57373, 0xFF000000,
)

@Composable
private fun ColorPickerRow(title: String, selected: Long, onSelect: (Long) -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Palette.forEach { c ->
                val sel = c == selected
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                        .border(if (sel) 3.dp else 1.dp, if (sel) Gold else MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { onSelect(c) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (sel) Icon(Icons.Filled.Check, null, Modifier.size(16.dp), tint = if (c == 0xFFFFFFFF || c == 0xFFF7F5F0) Color.Black else Color.White)
                }
            }
        }
    }
}

@Composable
private fun Segments(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            options.forEachIndexed { i, (key, label) ->
                SegmentedButton(
                    selected = key == selected, onClick = { onSelect(key) },
                    shape = SegmentedButtonDefaults.itemShape(i, options.size),
                ) { Text(label) }
            }
        }
    }
}

@Composable
fun DesignScreen(profile: CardProfile, onSave: (CardProfile) -> Unit, onBack: () -> Unit) {
    var d by remember(profile.id) { mutableStateOf(profile) }
    ScreenScaffold(
        title = "Card Design", onBack = onBack,
        actions = { TextButton(onClick = { onSave(d) }) { Text("Save", fontWeight = FontWeight.Bold) } },
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item { BusinessCard(d) }
            item {
                Column {
                    SectionTitle("Templates")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(CardTemplates, key = { it.id }) { t ->
                            val sel = d.templateId == t.id
                            Column(
                                Modifier.width(170.dp).clip(RoundedCornerShape(16.dp))
                                    .border(if (sel) 2.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(16.dp))
                                    .clickable { d = d.applyTemplate(t) }.padding(6.dp),
                            ) {
                                BusinessCard(d.applyTemplate(t))
                                Spacer(Modifier.height(6.dp))
                                Text(t.name, style = MaterialTheme.typography.labelLarge)
                                Text(t.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            item {
                SurfaceCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        Segments("Layout", listOf("LEFT" to "Classic", "CENTERED" to "Centered", "SPLIT" to "Split"), d.layoutStyle) { d = d.copy(layoutStyle = it, templateId = "custom") }
                        Segments("Typography", listOf("SERIF" to "Serif", "SANS" to "Modern", "MONO" to "Mono"), d.fontStyle) { d = d.copy(fontStyle = it, templateId = "custom") }
                        Segments("Background", listOf("SOLID" to "Solid", "GRADIENT" to "Gradient", "PATTERN" to "Pattern"), d.backgroundStyle) { d = d.copy(backgroundStyle = it, templateId = "custom") }
                    }
                }
            }
            item {
                SurfaceCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        ColorPickerRow("Card colour", d.primaryColor) { d = d.copy(primaryColor = it, templateId = "custom") }
                        ColorPickerRow("Accent colour", d.accentColor) { d = d.copy(accentColor = it, templateId = "custom") }
                        ColorPickerRow("Text colour", d.textColor) { d = d.copy(textColor = it, templateId = "custom") }
                        ColorPickerRow("QR code colour", d.qrColor) { d = d.copy(qrColor = it) }
                    }
                }
            }
            item { Button(onClick = { onSave(d) }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text("Apply design") } }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}
