package com.cardlink.app.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import android.widget.Toast
import androidx.core.content.FileProvider
import com.cardlink.app.data.CardData
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.ShareField
import com.cardlink.app.data.toCardData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class ShareFormat(val label: String, val description: String) {
    LINK("Card link", "Your digital card / website link"),
    VCARD("vCard (.vcf)", "Saves straight into Contacts"),
    IMAGE("Card image", "Professional PNG of your card"),
    QR("QR code", "Scannable QR image"),
    PDF("PDF", "Print-ready business card"),
    TEXT("Text", "Plain-text contact details"),
}

enum class ShareTarget(val label: String, val pkg: String?, val brand: Long) {
    WHATSAPP("WhatsApp", "com.whatsapp", 0xFF25D366),
    WHATSAPP_BUSINESS("WA Business", "com.whatsapp.w4b", 0xFF128C7E),
    LINKEDIN("LinkedIn", "com.linkedin.android", 0xFF0A66C2),
    FACEBOOK("Facebook", "com.facebook.katana", 0xFF1877F2),
    TELEGRAM("Telegram", "org.telegram.messenger", 0xFF229ED9),
    GMAIL("Gmail", "com.google.android.gm", 0xFFEA4335),
    SMS("SMS", null, 0xFF5E6B7A),
    MORE("More apps", null, 0xFF2B2D33),
}

data class SharePayload(val text: String?, val uri: Uri?, val mime: String, val subject: String)

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

object ShareHelper {
    private fun shareDir(ctx: Context) = File(ctx.cacheDir, "shared").apply { mkdirs() }
    fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    fun primaryLink(d: CardData): String? =
        listOf(d.cardUrl, d.website, d.linkedin).firstNotNullOfOrNull { Links.normalize(it.ifBlank { null }) }

    fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifEmpty { "card" }

    fun qrContent(p: CardProfile, fields: Set<ShareField>) = VCard.build(p.toCardData(fields), includePhoto = false)

    fun qrBitmap(p: CardProfile, fields: Set<ShareField>, withLogo: Boolean, size: Int = 900): Bitmap {
        val logo = if (withLogo) p.logoPath?.let { ImageStore.decodeFile(it, 240) } else null
        return QrCodeGen.generate(qrContent(p, fields), size, p.qrColor.toInt(), Color.WHITE, logo)
    }

    suspend fun build(ctx: Context, p: CardProfile, fields: Set<ShareField>, format: ShareFormat): SharePayload? =
        withContext(Dispatchers.IO) {
            val data = p.toCardData(fields)
            val safe = safeName(data.fullName)
            val subject = "${data.fullName.ifBlank { "My" }} – Digital Business Card"
            val caption = listOf(data.fullName, listOf(data.designation, data.company).filter { it.isNotBlank() }.joinToString(", "))
                .filter { it.isNotBlank() }.joinToString("\n")
            when (format) {
                ShareFormat.LINK -> {
                    val link = primaryLink(data) ?: return@withContext null
                    val sig = listOf(data.fullName, data.designation).filter { it.isNotBlank() }.joinToString(", ")
                    SharePayload("Hello! Here is my digital business card:\n$link\n\n— $sig", null, "text/plain", subject)
                }
                ShareFormat.TEXT -> SharePayload(CardText.format(data), null, "text/plain", subject)
                ShareFormat.VCARD -> {
                    val photo = if (ShareField.PHOTO in fields) ImageStore.toBase64(p.photoPath, 320, 80) else null
                    val f = File(shareDir(ctx), "$safe.vcf")
                    f.writeText(VCard.build(data.copy(photoBase64 = photo)))
                    SharePayload(null, uriFor(ctx, f), "text/x-vcard", subject)
                }
                ShareFormat.QR -> {
                    val f = File(shareDir(ctx), "${safe}_QR.png")
                    f.outputStream().use { qrBitmap(p, fields, true).compress(Bitmap.CompressFormat.PNG, 100, it) }
                    SharePayload("$caption\nScan this QR code to save my contact.", uriFor(ctx, f), "image/png", subject)
                }
                ShareFormat.IMAGE -> {
                    val f = File(shareDir(ctx), "${safe}_Card.png")
                    f.outputStream().use { CardRenderer.writePng(CardRenderer.render(p, fields), it) }
                    SharePayload(caption, uriFor(ctx, f), "image/png", subject)
                }
                ShareFormat.PDF -> {
                    val f = File(shareDir(ctx), "${safe}_Card.pdf")
                    f.outputStream().use { CardRenderer.writePdf(CardRenderer.render(p, fields), it) }
                    SharePayload(caption, uriFor(ctx, f), "application/pdf", subject)
                }
            }
        }

    /** Opens the chosen app (or the Android Sharesheet). Only ever triggered by an explicit user tap. */
    fun launch(ctx: Context, payload: SharePayload, target: ShareTarget) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = payload.mime
            putExtra(Intent.EXTRA_SUBJECT, payload.subject)
            payload.text?.let { putExtra(Intent.EXTRA_TEXT, it) }
            payload.uri?.let {
                putExtra(Intent.EXTRA_STREAM, it)
                clipData = ClipData.newRawUri("card", it)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        val chooser = Intent.createChooser(send, "Share my card")
        when (target) {
            ShareTarget.MORE -> start(ctx, chooser)
            ShareTarget.SMS -> {
                if (payload.uri == null) {
                    start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", payload.text.orEmpty()))
                } else {
                    val pkg = Telephony.Sms.getDefaultSmsPackage(ctx)
                    if (pkg != null) send.setPackage(pkg)
                    try { ctx.startActivity(send) } catch (e: ActivityNotFoundException) { start(ctx, chooser) }
                }
            }
            else -> {
                send.setPackage(target.pkg)
                try {
                    ctx.startActivity(send)
                } catch (e: ActivityNotFoundException) {
                    ctx.toast("${target.label} is not installed – choose another app")
                    send.setPackage(null)
                    start(ctx, Intent.createChooser(send, "Share my card"))
                }
            }
        }
    }

    private fun start(ctx: Context, i: Intent) {
        try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) { ctx.toast("No app available for this action") }
    }

    fun shareText(ctx: Context, text: String, subject: String = "") =
        launch(ctx, SharePayload(text, null, "text/plain", subject), ShareTarget.MORE)

    suspend fun shareContactVcf(ctx: Context, d: CardData, photoPath: String?) {
        val uri = withContext(Dispatchers.IO) {
            val f = File(shareDir(ctx), "${safeName(d.fullName)}.vcf")
            f.writeText(VCard.build(d.copy(photoBase64 = ImageStore.toBase64(photoPath, 320, 80))))
            uriFor(ctx, f)
        }
        launch(ctx, SharePayload(null, uri, "text/x-vcard", d.fullName), ShareTarget.MORE)
    }
}

object CardText {
    fun format(d: CardData): String = buildString {
        appendLine("👤 ${d.fullName}")
        if (d.designation.isNotBlank()) appendLine("💼 ${d.designation}")
        val org = listOf(d.company, d.department).filter { it.isNotBlank() }.joinToString(" — ")
        if (org.isNotBlank()) appendLine("🏢 $org")
        if (d.phone.isNotBlank()) appendLine("📞 ${d.phone}")
        if (d.whatsapp.isNotBlank()) appendLine("💬 WhatsApp: ${Links.whatsappUrl(d.whatsapp)}")
        if (d.email.isNotBlank()) appendLine("✉️ ${d.email}")
        if (d.address.isNotBlank()) appendLine("📍 ${d.address}")
        if (d.website.isNotBlank()) appendLine("🌐 ${d.website}")
        if (d.linkedin.isNotBlank()) appendLine("🔗 LinkedIn: ${d.linkedin}")
        if (d.facebook.isNotBlank()) appendLine("🔗 Facebook: ${d.facebook}")
        d.otherLinks.forEach { appendLine("🔗 ${it.label}: ${it.url}") }
        if (d.cardUrl.isNotBlank()) appendLine("🪪 Digital card: ${d.cardUrl}")
        if (d.bio.isNotBlank()) { appendLine(); appendLine(d.bio) }
        appendLine(); append("Shared with CardLink")
    }
}

/** Opens the system "Add contact" screen pre-filled — no contacts permission required. */
object PhoneContacts {
    fun insertIntent(d: CardData, photoPath: String?): Intent {
        val i = Intent(ContactsContract.Intents.Insert.ACTION).apply { type = ContactsContract.RawContacts.CONTENT_TYPE }
        i.putExtra(ContactsContract.Intents.Insert.NAME, d.fullName)
        if (d.phone.isNotBlank()) {
            i.putExtra(ContactsContract.Intents.Insert.PHONE, d.phone)
            i.putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
        }
        if (d.whatsapp.isNotBlank() && d.whatsapp != d.phone) {
            i.putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, d.whatsapp)
            i.putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
        }
        if (d.email.isNotBlank()) {
            i.putExtra(ContactsContract.Intents.Insert.EMAIL, d.email)
            i.putExtra(ContactsContract.Intents.Insert.EMAIL_TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
        }
        if (d.address.isNotBlank()) {
            i.putExtra(ContactsContract.Intents.Insert.POSTAL, d.address)
            i.putExtra(ContactsContract.Intents.Insert.POSTAL_TYPE, ContactsContract.CommonDataKinds.StructuredPostal.TYPE_WORK)
        }
        if (d.bio.isNotBlank()) i.putExtra(ContactsContract.Intents.Insert.NOTES, d.bio)
        val rows = ArrayList<ContentValues>()
        if (d.company.isNotBlank() || d.designation.isNotBlank() || d.department.isNotBlank()) {
            rows += ContentValues().apply {
                put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                put(ContactsContract.CommonDataKinds.Organization.COMPANY, d.company)
                put(ContactsContract.CommonDataKinds.Organization.TITLE, d.designation)
                put(ContactsContract.CommonDataKinds.Organization.DEPARTMENT, d.department)
                put(ContactsContract.CommonDataKinds.Organization.TYPE, ContactsContract.CommonDataKinds.Organization.TYPE_WORK)
            }
        }
        (listOf(d.website, d.linkedin, d.facebook, d.cardUrl) + d.otherLinks.map { it.url })
            .filter { it.isNotBlank() }.forEach { url ->
                rows += ContentValues().apply {
                    put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Website.CONTENT_ITEM_TYPE)
                    put(ContactsContract.CommonDataKinds.Website.URL, url)
                    put(ContactsContract.CommonDataKinds.Website.TYPE, ContactsContract.CommonDataKinds.Website.TYPE_WORK)
                }
            }
        photoPath?.let { ImageStore.decodeFile(it, 360) }?.let { bmp ->
            rows += ContentValues().apply {
                put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)
                put(ContactsContract.CommonDataKinds.Photo.PHOTO, ImageStore.jpegBytes(bmp, 85))
            }
        }
        if (rows.isNotEmpty()) i.putParcelableArrayListExtra(ContactsContract.Intents.Insert.DATA, rows)
        return i
    }
}

/** Safe launchers for call / WhatsApp / email / map / web actions. */
object Actions {
    private fun start(ctx: Context, i: Intent) {
        try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) { ctx.toast("No app found for this action") }
    }
    fun dial(ctx: Context, n: String) = start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n.trim()))))
    fun whatsapp(ctx: Context, n: String) = openUrl(ctx, Links.whatsappUrl(n))
    fun email(ctx: Context, e: String) = start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + e.trim())))
    fun map(ctx: Context, a: String) = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a))))
    fun openUrl(ctx: Context, url: String) {
        val u = Links.normalize(url)
        if (u == null) ctx.toast("This link looks invalid and was blocked") else start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }
    fun addToPhoneContacts(ctx: Context, d: CardData, photoPath: String?) = start(ctx, PhoneContacts.insertIntent(d, photoPath))
}
