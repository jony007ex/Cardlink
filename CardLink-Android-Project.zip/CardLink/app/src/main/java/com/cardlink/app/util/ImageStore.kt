package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import kotlin.math.max

/** Stores profile photos and logos privately inside the app's internal storage. */
object ImageStore {
    private fun dir(ctx: Context) = File(ctx.filesDir, "images").apply { mkdirs() }

    fun importFromUri(ctx: Context, uri: Uri, maxSize: Int = 640, png: Boolean = false): String? = try {
        val bmp = decodeUri(ctx, uri, maxSize) ?: throw IllegalStateException("decode failed")
        val file = File(dir(ctx), UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
        file.outputStream().use {
            bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 88, it)
        }
        file.absolutePath
    } catch (e: Exception) {
        null
    }

    private fun decodeUri(ctx: Context, uri: Uri, maxSize: Int): Bitmap? {
        val raw: Bitmap? = if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width; val h = info.size.height
                val scale = maxSize.toFloat() / max(w, h)
                if (scale < 1f) decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
            }
        } else {
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }
        return raw?.let { scaleDown(it, maxSize) }
    }

    fun decodeFile(path: String, maxSize: Int): Bitmap? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var sample = 1
        while (max(opts.outWidth, opts.outHeight) / (sample * 2) >= maxSize) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.let { scaleDown(it, maxSize) }
    } catch (e: Exception) {
        null
    }

    private fun scaleDown(b: Bitmap, maxSize: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= maxSize) return b
        val s = maxSize.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt().coerceAtLeast(1), (b.height * s).toInt().coerceAtLeast(1), true)
    }

    fun toBase64(path: String?, maxSize: Int = 240, quality: Int = 75): String? {
        if (path == null || !File(path).exists()) return null
        val bmp = decodeFile(path, maxSize) ?: return null
        return Base64.encodeToString(jpegBytes(bmp, quality), Base64.NO_WRAP)
    }

    fun jpegBytes(bmp: Bitmap, quality: Int = 80): ByteArray =
        ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()

    fun fileToBase64(path: String?): String? = try {
        if (path == null) null else Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
    } catch (e: Exception) { null }

    fun saveBase64(ctx: Context, b64: String?, ext: String = ".jpg"): String? = try {
        if (b64.isNullOrBlank()) null else {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            // Ensure it is really an image before storing it.
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IllegalArgumentException("not an image")
            val f = File(dir(ctx), UUID.randomUUID().toString() + ext)
            f.writeBytes(bytes); f.absolutePath
        }
    } catch (e: Exception) { null }

    fun decodeBase64(b64: String?): Bitmap? = try {
        if (b64.isNullOrBlank()) null else Base64.decode(b64, Base64.DEFAULT).let { BitmapFactory.decodeByteArray(it, 0, it.size) }
    } catch (e: Exception) { null }

    fun delete(path: String?) { if (path != null) runCatching { File(path).delete() } }
}
