@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.cardlink.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cardlink.app.data.ShareField
import com.cardlink.app.ui.CardViewModel
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.OptionTile
import com.cardlink.app.ui.components.ScreenScaffold
import com.cardlink.app.ui.components.SectionTitle
import com.cardlink.app.ui.components.SurfaceCard
import com.cardlink.app.ui.components.rememberQr
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.util.CardRenderer
import com.cardlink.app.util.ShareFormat
import com.cardlink.app.util.ShareHelper
import com.cardlink.app.util.ShareTarget
import com.cardlink.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun targetIcon(t: ShareTarget): ImageVector = when (t) {
    ShareTarget.WHATSAPP -> Icons.Filled.Chat
    ShareTarget.WHATSAPP_BUSINESS -> Icons.Filled.Storefront
    ShareTarget.LINKEDIN -> Icons.Filled.Work
    ShareTarget.FACEBOOK -> Icons.Filled.ThumbUp
    ShareTarget.TELEGRAM -> Icons.Filled.Send
    ShareTarget.GMAIL -> Icons.Filled.Email
    ShareTarget.SMS -> Icons.Filled.Sms
    ShareTarget.MORE -> Icons.Filled.MoreHoriz
}

@Composable
fun ShareScreen(vm: CardViewModel, onNfc: () -> Unit, onNearby: () -> Unit, onQr: () -> Unit, onScan: () -> Unit, onHistory: () -> Unit, onPrivacy: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile by vm.activeProfile.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var showSheet by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val pngSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val p = profile
        if (uri != null && p != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openOutputStream(uri)?.use { CardRenderer.writePng(CardRenderer.render(p, settings.shareFields), it) } }.isSuccess
            }
            ctx.toast(if (ok) "Card saved as PNG" else "Could not save the image")
            if (ok) vm.recordShare("Downloaded PNG")
        }
    }
    val pdfSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val p = profile
        if (uri != null && p != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openOutputStream(uri)?.use { CardRenderer.writePdf(CardRenderer.render(p, settings.shareFields), it) } }.isSuccess
            }
            ctx.toast(if (ok) "Card saved as PDF" else "Could not save the PDF")
            if (ok) vm.recordShare("Downloaded PDF")
        }
    }

    ScreenScaffold(title = "Share My Card", actions = {
        IconButton(onClick = onScan) { Icon(Icons.Filled.QrCodeScanner, "Scan") }
        IconButton(onClick = onHistory) { Icon(Icons.Filled.History, "History") }
    }) { pad ->
        val p = profile
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (p == null || p.fullName.isBlank()) {
                item {
                    SurfaceCard {
                        Text("Add your name and details in My Card → Edit before sharing.", Modifier.padding(18.dp))
                    }
                }
                return@LazyColumn
            }
            item {
                Text("Choose how you want to share", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    OptionTile(Icons.Filled.Nfc, "NFC Tap", "Touch phones back to back", Color(0xFF3F7DD8), onNfc, Modifier.weight(1f))
                    OptionTile(Icons.Filled.Bluetooth, "Bluetooth / Nearby", "Send to a nearby phone", Color(0xFF2E9C8F), onNearby, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    OptionTile(Icons.Filled.QrCode2, "QR Code", "Let them scan your code", Gold, onQr, Modifier.weight(1f))
                    OptionTile(Icons.Filled.Apps, "Share via Apps", "WhatsApp, LinkedIn & more", Color(0xFF8A5CD0), { showSheet = true }, Modifier.weight(1f))
                }
            }
            item {
                Column {
                    SectionTitle("Download")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { pngSaver.launch("${ShareHelper.safeName(p.fullName)}_Card.png") }, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Filled.Image, null); Spacer(Modifier.width(8.dp)); Text("PNG")
                        }
                        OutlinedButton(onClick = { pdfSaver.launch("${ShareHelper.safeName(p.fullName)}_Card.pdf") }, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Filled.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("PDF")
                        }
                    }
                }
            }
            item {
                SurfaceCard(Modifier.clickable(onClick = onPrivacy)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Privacy", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Sharing ${settings.shareFields.size} of ${ShareField.entries.size} optional fields. Tap to choose what's shared.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSheet) {
        val p = profile
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var format by remember { mutableStateOf(ShareFormat.IMAGE) }
        ModalBottomSheet(onDismissRequest = { showSheet = false }, sheetState = sheetState) {
            Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
                Text("Share via apps", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text("1. Pick a format", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ShareFormat.entries.forEach { f ->
                        FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f.label) })
                    }
                }
                Text(format.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Text("2. Choose an app", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                FlowRow(maxItemsInEachRow = 4, horizontalArrangement = Arrangement.SpaceBetween, verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                    ShareTarget.entries.forEach { t ->
                        Column(
                            Modifier.width(76.dp).clip(RoundedCornerShape(14.dp)).clickable(enabled = !busy && p != null) {
                                if (p == null) return@clickable
                                busy = true
                                scope.launch {
                                    val payload = runCatching { ShareHelper.build(ctx, p, settings.shareFields, format) }.getOrNull()
                                    busy = false
                                    if (payload == null) {
                                        ctx.toast(if (format == ShareFormat.LINK) "Add a digital card link, website or LinkedIn in Edit first" else "Could not prepare your card")
                                    } else {
                                        ShareHelper.launch(ctx, payload, t)
                                        vm.recordShare("${format.label} via ${t.label}")
                                        showSheet = false
                                    }
                                }
                            }.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(Modifier.size(52.dp).clip(CircleShape).background(Color(t.brand)), contentAlignment = Alignment.Center) {
                                Icon(targetIcon(t), null, tint = Color.White)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(t.label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 1)
                        }
                    }
                }
                if (busy) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Preparing…")
                    }
                }
            }
        }
    }
}

@Composable
fun QrScreen(vm: CardViewModel, onBack: () -> Unit, onScan: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile by vm.activeProfile.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var withLogo by remember { mutableStateOf(true) }
    val p = profile
    val qr by rememberQr(Triple(p, settings.shareFields, withLogo)) { p?.let { ShareHelper.qrBitmap(it, settings.shareFields, withLogo, 900) } }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null && p != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openOutputStream(uri)?.use {
                        ShareHelper.qrBitmap(p, settings.shareFields, withLogo, 1200).compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
                    }
                }.isSuccess
            }
            ctx.toast(if (ok) "QR code saved" else "Could not save QR code")
        }
    }

    ScreenScaffold(title = "My QR Code", onBack = onBack, actions = {
        IconButton(onClick = onScan) { Icon(Icons.Filled.QrCodeScanner, "Scan") }
    }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SurfaceCard {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Color.White).padding(10.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        qr?.let { Image(it, "QR code", Modifier.fillMaxSize()) } ?: CircularProgressIndicator()
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(p?.fullName.orEmpty(), style = MaterialTheme.typography.titleLarge)
                    Text(listOf(p?.designation.orEmpty(), p?.company.orEmpty()).filter { it.isNotBlank() }.joinToString(" · "),
                        color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
            Text("Point any phone camera at this code to save your contact instantly — works offline, no app needed.",
                style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (p?.logoPath != null) Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show company logo in QR", Modifier.weight(1f)); Switch(withLogo, { withLogo = it })
            }
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { p?.let { saver.launch("${ShareHelper.safeName(it.fullName)}_QR.png") } }, Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Filled.Download, null); Spacer(Modifier.width(8.dp)); Text("Save")
                }
                GoldButton("Share", Icons.Filled.Share, {
                    if (p != null) scope.launch {
                        ShareHelper.build(ctx, p, settings.shareFields, ShareFormat.QR)?.let {
                            ShareHelper.launch(ctx, it, ShareTarget.MORE); vm.recordShare("QR code image")
                        }
                    }
                }, Modifier.weight(1f).height(56.dp))
            }
        }
    }
}
