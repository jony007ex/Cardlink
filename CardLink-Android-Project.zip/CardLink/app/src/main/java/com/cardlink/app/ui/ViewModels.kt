package com.cardlink.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cardlink.app.AppContainer
import com.cardlink.app.IncomingCard
import com.cardlink.app.data.AppSettings
import com.cardlink.app.data.CardProfile
import com.cardlink.app.data.SavedContact
import com.cardlink.app.data.ShareField
import com.cardlink.app.data.ShareHistory
import com.cardlink.app.data.toCardData
import com.cardlink.app.data.toContact
import com.cardlink.app.nearby.NearbyViewModel
import com.cardlink.app.util.BackupManager
import com.cardlink.app.util.ImageStore
import com.cardlink.app.util.VCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VmFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(CardViewModel::class.java) -> CardViewModel(c)
        modelClass.isAssignableFrom(ContactsViewModel::class.java) -> ContactsViewModel(c)
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(c)
        modelClass.isAssignableFrom(NearbyViewModel::class.java) -> NearbyViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel $modelClass")
    } as T
}

class CardViewModel(private val c: AppContainer) : ViewModel() {
    val profiles: StateFlow<List<CardProfile>> = c.repo.profiles.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings: StateFlow<AppSettings> = c.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val activeProfile: StateFlow<CardProfile?> = combine(profiles, settings) { list, s ->
        list.firstOrNull { it.id == s.activeProfileId } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init { viewModelScope.launch { c.repo.ensureDefaultProfile() } }

    fun save(p: CardProfile, onDone: () -> Unit = {}) = viewModelScope.launch {
        c.repo.saveProfile(p.copy(updatedAt = System.currentTimeMillis()))
        onDone()
    }

    fun setActive(id: Long) = viewModelScope.launch { c.settings.setActiveProfile(id) }

    fun createProfile(label: String, from: CardProfile? = null) = viewModelScope.launch {
        val base = from?.copy(id = 0, label = label) ?: CardProfile(label = label)
        val id = c.repo.saveProfile(base)
        c.settings.setActiveProfile(id)
    }

    fun deleteProfile(p: CardProfile) = viewModelScope.launch {
        if (profiles.value.size <= 1) return@launch
        c.repo.deleteProfile(p)
        if (settings.value.activeProfileId == p.id) {
            profiles.value.firstOrNull { it.id != p.id }?.let { c.settings.setActiveProfile(it.id) }
        }
    }

    fun setNfcMode(mode: String) = viewModelScope.launch { c.settings.setNfcMode(mode) }

    fun recordShare(method: String, detail: String = activeProfile.value?.label.orEmpty()) = viewModelScope.launch {
        c.repo.addHistory(ShareHistory(method = method, direction = "SENT", detail = detail))
    }

    /** Card data respecting the user's privacy choices (optionally with a small photo). */
    suspend fun shareableCard(withPhoto: Boolean) = withContext(Dispatchers.IO) {
        val p = activeProfile.value ?: return@withContext null
        val fields = settings.value.shareFields
        val photo = if (withPhoto && ShareField.PHOTO in fields) ImageStore.toBase64(p.photoPath, 200, 70) else null
        p.toCardData(fields).copy(photoBase64 = photo)
    }
}

class ContactsViewModel(private val c: AppContainer) : ViewModel() {
    val query = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val contacts: StateFlow<List<SavedContact>> = query.flatMapLatest { c.repo.searchContacts(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun contact(id: Long): Flow<SavedContact?> = c.repo.observeContact(id)

    fun saveIncoming(inc: IncomingCard, onSaved: (Long) -> Unit) = viewModelScope.launch {
        val photo = withContext(Dispatchers.IO) { ImageStore.saveBase64(c.context, inc.card.photoBase64) }
        val id = c.repo.saveContact(inc.card.copy(photoBase64 = null).toContact(photo, inc.source))
        c.repo.addHistory(ShareHistory(method = inc.source, direction = "RECEIVED", detail = inc.card.fullName))
        onSaved(id)
    }

    fun update(contact: SavedContact) = viewModelScope.launch { c.repo.updateContact(contact) }

    fun delete(contact: SavedContact) = viewModelScope.launch {
        c.repo.deleteContact(contact)
        ImageStore.delete(contact.photoPath)
    }

    suspend fun importVcf(uri: Uri): Int = withContext(Dispatchers.IO) {
        val text = c.context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return@withContext 0
        val cards = VCard.parseAll(text)
        cards.forEach { card ->
            val photo = ImageStore.saveBase64(c.context, card.photoBase64)
            c.repo.saveContact(card.copy(photoBase64 = null).toContact(photo, "vCard import"))
        }
        cards.size
    }

    suspend fun exportVcf(uri: Uri): Int = withContext(Dispatchers.IO) {
        val all = c.repo.allContacts()
        val text = all.joinToString("") { s ->
            VCard.build(s.toCardData().copy(photoBase64 = ImageStore.toBase64(s.photoPath, 240, 75)))
        }
        c.context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) }
        all.size
    }
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val history: StateFlow<List<ShareHistory>> = c.repo.history.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun setTheme(t: String) = viewModelScope.launch { c.settings.setTheme(t) }
    fun setOnboarded() = viewModelScope.launch { c.settings.setOnboarded(true) }
    fun toggleField(f: ShareField, on: Boolean) = viewModelScope.launch {
        val cur = settings.value.shareFields
        c.settings.setShareFields(if (on) cur + f else cur - f)
    }
    fun clearHistory() = viewModelScope.launch { c.repo.clearHistory() }

    suspend fun backup(uri: Uri): Result<Unit> = runCatching { BackupManager.export(c.context, c.repo, uri) }
    suspend fun restore(uri: Uri): Result<Int> = runCatching { BackupManager.import(c.context, c.repo, uri) }
}
