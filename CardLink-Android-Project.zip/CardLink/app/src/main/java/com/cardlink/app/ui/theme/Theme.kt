package com.cardlink.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0B1F3A)
val NavyLight = Color(0xFF1C3A63)
val NavyDeep = Color(0xFF06101F)
val Gold = Color(0xFFC9A646)
val GoldLight = Color(0xFFE6CF8A)
val Charcoal = Color(0xFF2B2D33)
val Ivory = Color(0xFFF7F5F0)
val Success = Color(0xFF2E7D5B)

private val LightColors = lightColorScheme(
    primary = Navy, onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE4F2), onPrimaryContainer = Navy,
    secondary = Gold, onSecondary = Navy,
    secondaryContainer = Color(0xFFF4EACB), onSecondaryContainer = Color(0xFF3B2F00),
    tertiary = Charcoal, onTertiary = Color.White,
    background = Ivory, onBackground = Charcoal,
    surface = Color.White, onSurface = Charcoal,
    surfaceVariant = Color(0xFFECEEF2), onSurfaceVariant = Color(0xFF555A66),
    outline = Color(0xFFC5C9D2),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB3C7EA), onPrimary = Navy,
    primaryContainer = NavyLight, onPrimaryContainer = Color.White,
    secondary = Gold, onSecondary = Color(0xFF1B1500),
    secondaryContainer = Color(0xFF4A3D12), onSecondaryContainer = GoldLight,
    tertiary = Color(0xFFD0D3DA), onTertiary = Charcoal,
    background = Color(0xFF0D1117), onBackground = Color(0xFFE6E8EC),
    surface = Color(0xFF151A22), onSurface = Color(0xFFE6E8EC),
    surfaceVariant = Color(0xFF222936), onSurfaceVariant = Color(0xFFB7BCC6),
    outline = Color(0xFF3A4252),
)

private val base = Typography()
private val Serif = FontFamily.Serif

val AppTypography = base.copy(
    displayLarge = base.displayLarge.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    displayMedium = base.displayMedium.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    displaySmall = base.displaySmall.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineLarge = base.headlineLarge.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineMedium = base.headlineMedium.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineSmall = base.headlineSmall.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp),
)

@Composable
fun CardLinkTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, typography = AppTypography, content = content)
}
