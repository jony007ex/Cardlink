@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.cardlink.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.AppContainer
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.components.LogoMark
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.ui.theme.Navy
import com.cardlink.app.ui.theme.NavyDeep
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(container: AppContainer, onFinished: (onboarded: Boolean) -> Unit) {
    val scale = remember { Animatable(0.6f) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(700)) }
        scale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
        delay(600)
        onFinished(container.settings.settings.first().onboarded)
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyDeep))),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value; this.alpha = alpha.value },
        ) {
            LogoMark(104.dp)
            Spacer(Modifier.height(24.dp))
            Text("CardLink", style = MaterialTheme.typography.displaySmall, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text("SMART DIGITAL BUSINESS CARD", color = Gold, letterSpacing = 3.sp, style = MaterialTheme.typography.labelMedium)
        }
    }
}

private data class Page(val icon: ImageVector, val title: String, val text: String)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = listOf(
        Page(Icons.Filled.Badge, "Your card, reimagined", "Design a premium digital business card with your photo, logo, contact details and social profiles."),
        Page(Icons.Filled.Nfc, "Share in seconds", "Tap phones with NFC, send over Bluetooth / Nearby, show a QR code, or share through WhatsApp, LinkedIn and more."),
        Page(Icons.Filled.QrCode2, "Collect contacts", "Scan and save cards you receive into My Contacts, add notes, and export them to your phone."),
        Page(Icons.Filled.Lock, "Private by design", "Everything stays on your phone. No account, no cloud. You choose exactly what you share."),
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyDeep)))) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onFinish) { Text("Skip", color = Color.White.copy(alpha = 0.8f)) }
            }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { i ->
                val pg = pages[i]
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        Modifier.size(150.dp).clip(CircleShape).background(Gold.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(Modifier.size(104.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) {
                            Icon(pg.icon, null, tint = Navy, modifier = Modifier.size(52.dp))
                        }
                    }
                    Spacer(Modifier.height(40.dp))
                    Text(pg.title, style = MaterialTheme.typography.headlineMedium, color = Color.White, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Text(pg.text, style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalArrangement = Arrangement.Center) {
                pages.indices.forEach { i ->
                    val w by animateDpAsState(if (pager.currentPage == i) 26.dp else 8.dp, label = "dot")
                    Box(
                        Modifier.padding(horizontal = 4.dp).height(8.dp).width(w).clip(RoundedCornerShape(4.dp))
                            .background(if (pager.currentPage == i) Gold else Color.White.copy(alpha = 0.3f)),
                    )
                }
            }
            val last = pager.currentPage == pages.lastIndex
            GoldButton(if (last) "Get started" else "Next", null, onClick = {
                if (last) onFinish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            })
        }
    }
}
