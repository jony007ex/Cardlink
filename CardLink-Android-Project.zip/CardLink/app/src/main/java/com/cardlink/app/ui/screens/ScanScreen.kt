package com.cardlink.app.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.cardlink.app.IncomingCard
import com.cardlink.app.appContainer
import com.cardlink.app.ui.components.GoldButton
import com.cardlink.app.ui.theme.Gold
import com.cardlink.app.util.Actions
import com.cardlink.app.util.Links
import com.cardlink.app.util.VCard
import com.cardlink.app.util.toast
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

private class QrAnalyzer(private val onFound: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val scanner = BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    @Volatile var paused = false

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    override fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || paused) { proxy.close(); return }
        val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(img)
            .addOnSuccessListener { list ->
                val raw = list.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                if (raw != null && !paused) { paused = true; onFound(raw) }
            }
            .addOnCompleteListener { proxy.close() }
    }
}

/** Decides what to do with scanned / picked QR content. Returns non-null text if a dialog should be shown. */
private fun handleScan(ctx: Context, raw: String, onCard: () -> Unit): String? {
    val cards = if (raw.contains("BEGIN:VCARD", ignoreCase = true)) VCard.parseAll(raw) else emptyList()
    val card = cards.firstOrNull() ?: VCard.parseMeCard(raw)
    if (card != null) {
        ctx.appContainer.incoming.value = IncomingCard(card, "QR scan")
        onCard()
        return null
    }
    return raw
}

@Composable
fun ScanScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCamera by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCamera = it }
    var result by remember { mutableStateOf<String?>(null) }
    var torch by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    val analyzer = remember { QrAnalyzer { raw -> android.os.Handler(android.os.Looper.getMainLooper()).post { result = handleScan(ctx, raw, onBack) } } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            analyzer.paused = true
            runCatching {
                val img = InputImage.fromFilePath(ctx, uri)
                BarcodeScanning.getClient().process(img).addOnSuccessListener { list ->
                    val raw = list.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                    if (raw == null) { ctx.toast("No QR code found in that image"); analyzer.paused = false }
                    else result = handleScan(ctx, raw, onBack)
                }.addOnFailureListener { ctx.toast("Could not read that image"); analyzer.paused = false }
            }.onFailure { ctx.toast("Could not open that image"); analyzer.paused = false }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (hasCamera) {
            val executor = remember { Executors.newSingleThreadExecutor() }
            var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val pv = PreviewView(c).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
                    val future = ProcessCameraProvider.getInstance(c)
                    future.addListener({
                        runCatching {
                            val p = future.get()
                            provider = p
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                            analysis.setAnalyzer(executor, analyzer)
                            p.unbindAll()
                            camera = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        }.onFailure { c.toast("Camera unavailable") }
                    }, ContextCompat.getMainExecutor(c))
                    pv
                },
            )
            DisposableEffect(Unit) { onDispose { runCatching { provider?.unbindAll() }; executor.shutdown() } }
            // Viewfinder
            Box(
                Modifier.align(Alignment.Center).size(260.dp).border(BorderStroke(3.dp, Gold), RoundedCornerShape(28.dp)),
            )
        } else {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Icon(Icons.Filled.PhotoCamera, null, tint = Gold, modifier = Modifier.size(64.dp))
                Text("Camera access needed", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("CardLink uses the camera only to scan business card QR codes. Nothing is recorded or uploaded.",
                    color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                GoldButton("Allow camera", Icons.Filled.PhotoCamera, { permLauncher.launch(Manifest.permission.CAMERA) })
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack, Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.4f))) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            Text("Scan a card", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            IconButton(
                onClick = { torch = !torch; camera?.cameraControl?.enableTorch(torch) },
                modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)),
                enabled = camera?.cameraInfo?.hasFlashUnit() == true,
            ) { Icon(if (torch) Icons.Filled.FlashOn else Icons.Filled.FlashOff, "Torch", tint = Color.White) }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Point at a CardLink or any contact QR code", color = Color.White)
            Spacer(Modifier.height(12.dp))
            FilledTonalButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Icon(Icons.Filled.Image, null); Spacer(Modifier.size(8.dp)); Text("Scan from gallery")
            }
        }
    }

    result?.let { raw ->
        val isUrl = Links.isWebUrl(raw)
        AlertDialog(
            onDismissRequest = { result = null; analyzer.paused = false },
            title = { Text(if (isUrl) "Open this link?" else "Scanned text") },
            text = {
                Text(if (isUrl) "$raw\n\nWebsite: ${Links.host(raw)}\nOnly open links from people you trust." else raw)
            },
            confirmButton = {
                if (isUrl) TextButton(onClick = { Actions.openUrl(ctx, raw); result = null; analyzer.paused = false }) { Text("Open") }
                else TextButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("QR", raw))
                    ctx.toast("Copied"); result = null; analyzer.paused = false
                }) { Text("Copy") }
            },
            dismissButton = { TextButton(onClick = { result = null; analyzer.paused = false }) { Text("Close") } },
        )
    }
}
