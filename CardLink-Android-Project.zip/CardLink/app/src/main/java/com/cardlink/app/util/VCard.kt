package com.cardlink.app.util

import com.cardlink.app.data.CardData
import com.cardlink.app.data.SocialLink

/** vCard 3.0 builder / parser (also understands vCard 2.1/4.0 basics and MECARD). */
object VCard {

    fun build(c: CardData, includePhoto: Boolean = true): String {
        val sb = StringBuilder()
        fun line(s: String) { sb.append(fold(s)).append("\r\n") }
        line("BEGIN:VCARD")
        line("VERSION:3.0")
        val parts = c.fullName.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val (first, last) = if (parts.size > 1) parts.dropLast(1).joinToString(" ") to parts.last()
        else (parts.firstOrNull() ?: "") to ""
        line("N:${esc(last)};${esc(first)};;;")
        line("FN:${esc(c.fullName.trim())}")
        if (c.company.isNotBlank() || c.department.isNotBlank()) line("ORG:${esc(c.company)};${esc(c.department)}")
        if (c.designation.isNotBlank()) line("TITLE:${esc(c.designation)}")
        if (c.phone.isNotBlank()) line("TEL;TYPE=WORK,VOICE:${c.phone.trim()}")
        if (c.whatsapp.isNotBlank()) {
            if (c.whatsapp.trim() != c.phone.trim()) line("TEL;TYPE=CELL:${c.whatsapp.trim()}")
            line("X-WHATSAPP:${c.whatsapp.trim()}")
        }
        if (c.email.isNotBlank()) line("EMAIL;TYPE=INTERNET,WORK:${c.email.trim()}")
        if (c.address.isNotBlank()) line("ADR;TYPE=WORK:;;${esc(c.address)};;;;")
        if (c.website.isNotBlank()) line("URL;TYPE=WORK:${c.website.trim()}")
        if (c.linkedin.isNotBlank()) line("URL;TYPE=LinkedIn:${c.linkedin.trim()}")
        if (c.facebook.isNotBlank()) line("URL;TYPE=Facebook:${c.facebook.trim()}")
        c.otherLinks.forEach { l ->
            val type = l.label.filter { it.isLetterOrDigit() }.ifEmpty { "Link" }
            line("URL;TYPE=$type:${l.url.trim()}")
        }
        if (c.cardUrl.isNotBlank()) line("URL;TYPE=CardLink:${c.cardUrl.trim()}")
        if (c.bio.isNotBlank()) line("NOTE:${esc(c.bio)}")
        if (includePhoto && !c.photoBase64.isNullOrBlank()) line("PHOTO;ENCODING=b;TYPE=JPEG:${c.photoBase64}")
        line("END:VCARD")
        return sb.toString()
    }

    private fun esc(s: String) = s.trim()
        .replace("\\", "\\\\").replace("\r\n", "\\n").replace("\n", "\\n")
        .replace(",", "\\,").replace(";", "\\;")

    private fun unesc(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    'n', 'N' -> sb.append('\n')
                    else -> sb.append(n)
                }
                i += 2
            } else { sb.append(ch); i++ }
        }
        return sb.toString().trim()
    }

    private fun fold(line: String): String {
        if (line.length <= 75) return line
        val sb = StringBuilder(line.substring(0, 75))
        var i = 75
        while (i < line.length) {
            val end = minOf(line.length, i + 74)
            sb.append("\r\n ").append(line, i, end)
            i = end
        }
        return sb.toString()
    }

    /** Splits on separators that are not escaped with a backslash. */
    private fun splitUnescaped(s: String, sep: Char): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) { cur.append(ch).append(s[i + 1]); i += 2; continue }
            if (ch == sep) { out += cur.toString(); cur.clear() } else cur.append(ch)
            i++
        }
        out += cur.toString()
        return out
    }

    fun parseAll(text: String): List<CardData> {
        val normalized = text.replace("\r\n", "\n").replace("\r", "\n")
        val lines = mutableListOf<String>()
        for (raw in normalized.split("\n")) {
            if ((raw.startsWith(" ") || raw.startsWith("\t")) && lines.isNotEmpty()) {
                lines[lines.size - 1] = lines.last() + raw.substring(1)
            } else lines += raw
        }
        val result = mutableListOf<CardData>()
        var current: MutableMap<String, Any>? = null
        var card = CardData()
        val tels = mutableListOf<Pair<String, String>>()
        var nameFromN = ""
        for (line in lines) {
            val upper = line.trim().uppercase()
            if (upper == "BEGIN:VCARD") {
                current = mutableMapOf(); card = CardData(); tels.clear(); nameFromN = ""; continue
            }
            if (upper == "END:VCARD") {
                if (current != null) {
                    var c = card
                    val wa = c.whatsapp
                    if (c.phone.isBlank()) {
                        val work = tels.firstOrNull { it.first.contains("WORK") }?.second
                        c = c.copy(phone = work ?: tels.firstOrNull { it.second != wa }?.second ?: tels.firstOrNull()?.second.orEmpty())
                    }
                    if (c.whatsapp.isBlank()) {
                        tels.firstOrNull { it.first.contains("CELL") && it.second != c.phone }?.second?.let { c = c.copy(whatsapp = it) }
                    }
                    if (c.fullName.isBlank()) c = c.copy(fullName = nameFromN)
                    if (c.fullName.isNotBlank() || c.phone.isNotBlank() || c.email.isNotBlank()) result += c
                }
                current = null; continue
            }
            if (current == null) continue
            val idx = line.indexOf(':')
            if (idx <= 0) continue
            val left = line.substring(0, idx)
            val value = line.substring(idx + 1)
            val nameParts = left.split(';')
            val name = nameParts[0].substringAfter('.').uppercase()
            val params = nameParts.drop(1).joinToString(";").uppercase()
            when (name) {
                "FN" -> card = card.copy(fullName = unesc(value))
                "N" -> {
                    val p = splitUnescaped(value, ';').map { unesc(it) }
                    nameFromN = listOf(p.getOrNull(3), p.getOrNull(1), p.getOrNull(2), p.getOrNull(0), p.getOrNull(4))
                        .filter { !it.isNullOrBlank() }.joinToString(" ")
                }
                "ORG" -> {
                    val p = splitUnescaped(value, ';').map { unesc(it) }
                    card = card.copy(company = p.getOrNull(0).orEmpty(), department = p.drop(1).filter { it.isNotBlank() }.joinToString(", "))
                }
                "TITLE" -> card = card.copy(designation = unesc(value))
                "TEL" -> tels += params to value.removePrefix("tel:").trim()
                "X-WHATSAPP" -> card = card.copy(whatsapp = value.trim())
                "EMAIL" -> if (card.email.isBlank()) card = card.copy(email = value.removePrefix("mailto:").trim())
                "ADR" -> {
                    val p = splitUnescaped(value, ';').map { unesc(it) }.filter { it.isNotBlank() }
                    if (card.address.isBlank()) card = card.copy(address = p.joinToString(", "))
                }
                "NOTE" -> card = card.copy(bio = unesc(value))
                "URL", "X-SOCIALPROFILE" -> {
                    val url = value.replace("\\:", ":").replace("\\,", ",").replace("\\;", ";").trim()
                    val lowerUrl = url.lowercase()
                    card = when {
                        params.contains("LINKEDIN") || lowerUrl.contains("linkedin.com") -> card.copy(linkedin = url)
                        params.contains("FACEBOOK") || lowerUrl.contains("facebook.com") || lowerUrl.contains("fb.com") -> card.copy(facebook = url)
                        params.contains("CARDLINK") -> card.copy(cardUrl = url)
                        card.website.isBlank() && (params.isEmpty() || params.contains("WORK") || params.contains("HOME")) -> card.copy(website = url)
                        else -> {
                            val label = Regex("TYPE=([A-Z0-9]+)").find(params)?.groupValues?.get(1)
                                ?.lowercase()?.replaceFirstChar { it.uppercase() } ?: Links.host(url)
                            card.copy(otherLinks = card.otherLinks + SocialLink(label, url))
                        }
                    }
                }
                "PHOTO" -> {
                    if (!value.startsWith("http", ignoreCase = true)) {
                        val b64 = if (value.contains("base64,")) value.substringAfter("base64,") else value
                        card = card.copy(photoBase64 = b64.filter { !it.isWhitespace() })
                    }
                }
            }
        }
        return result
    }

    /** Parses the simple MECARD format used by many QR generators. */
    fun parseMeCard(text: String): CardData? {
        if (!text.startsWith("MECARD:", ignoreCase = true)) return null
        var c = CardData()
        splitUnescaped(text.substring(7), ';').forEach { field ->
            val i = field.indexOf(':')
            if (i <= 0) return@forEach
            val k = field.substring(0, i).uppercase()
            val v = unesc(field.substring(i + 1))
            c = when (k) {
                "N" -> c.copy(fullName = v.split(',').map { it.trim() }.reversed().joinToString(" ").trim())
                "TEL" -> if (c.phone.isBlank()) c.copy(phone = v) else c
                "EMAIL" -> c.copy(email = v)
                "URL" -> c.copy(website = v)
                "ADR" -> c.copy(address = v)
                "NOTE" -> c.copy(bio = v)
                "ORG" -> c.copy(company = v)
                "TITLE" -> c.copy(designation = v)
                else -> c
            }
        }
        return if (c.fullName.isBlank() && c.phone.isBlank()) null else c
    }
}
