# CardLink – Smart Digital Business Card (Android)

Kotlin · Jetpack Compose · Material 3 · MVVM · Room · DataStore · CameraX · ML Kit · ZXing · Nearby Connections · NFC HCE

## Get the APK (choose one)

### Option A – GitHub (no Android setup needed, ~6 minutes)
1. Create a new **private** GitHub repository and upload the contents of this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build CardLink APK** → it runs automatically on every push (or press **Run workflow**).
3. When it finishes, download **CardLink-APK** from the run's *Artifacts* section and unzip it → `CardLink-1.0.0.apk`.
4. Copy the APK to your phone and open it (allow "Install unknown apps" when asked).

### Option B – Android Studio (Ladybug 2024.2 or newer)
1. **File → Open** → select this folder. Let Gradle sync (it downloads Gradle 8.9 and all libraries).
2. **Build → Generate App Bundles or APKs → Build APK(s)**, or run `./gradlew assembleRelease`.
   *If Android Studio says the Gradle wrapper is missing, run `gradle wrapper --gradle-version 8.9` once, or accept its prompt to use Gradle 8.9.*
3. The APK is in `app/build/outputs/apk/release/`.

### Release signing
Without a keystore the release APK is signed with the debug key, so it installs and runs normally but **cannot be uploaded to Google Play**.
For a Play-ready build, create a keystore and set `CARDLINK_KEYSTORE`, `CARDLINK_KEYSTORE_PASSWORD`, `CARDLINK_KEY_ALIAS`, `CARDLINK_KEY_PASSWORD`
(on GitHub: add the secrets `CARDLINK_KEYSTORE_BASE64` (base64 of the .jks file), `CARDLINK_KEYSTORE_PASSWORD`, `CARDLINK_KEY_ALIAS`, `CARDLINK_KEY_PASSWORD`).

## Feature map

| Requirement | Implementation |
|---|---|
| Digital card (photo, logo, all fields, intro) | `EditCardScreen`, `BusinessCard` composable, Room `CardProfile` |
| Customization & templates | `DesignScreen` – 8 templates (corporate/personal), 3 layouts, 3 fonts, 3 backgrounds, colour pickers, QR colour |
| NFC sharing (no Android Beam) | `CardHceService` emulates an NFC Forum Type 4 tag (Host Card Emulation). Any NFC phone reading it gets a vCard or a web link. Receive mode uses `NfcAdapter.enableReaderMode`. Detects unsupported / disabled NFC with instructions. |
| Bluetooth / Nearby | Google Nearby Connections (`P2P_POINT_TO_POINT`, encrypted). Device discovery list, verification code, receiver must accept, progress/success/failure states, runtime permissions per Android version. |
| WhatsApp & social sharing | Share sheet with formats **Card link, vCard, Card image, QR, PDF, Text** and direct targets WhatsApp, WhatsApp Business, LinkedIn, Facebook, Telegram, Gmail, SMS + Android Sharesheet. Falls back to the Sharesheet if an app isn't installed. |
| QR code | Auto-generated vCard QR (optional company logo), full-screen view, share, save PNG. Scanner with CameraX + ML Kit (on-device), torch, scan from gallery, vCard & MECARD parsing, safe URL handling. |
| My Contacts | Save received cards, search, private notes, delete, share, add to Android Contacts (pre-filled, no permission needed), import/export `.vcf`. |
| Multiple profiles | Profile switcher on Home, Manage profiles (create, duplicate, delete). |
| Download PNG / PDF | High-resolution card renderer (`CardRenderer`), saved through the system file picker. |
| Backup & restore | JSON backup (profiles, logos/photos, contacts, history) via the system file picker. |
| Sharing history | Every send/receive is logged; viewable and clearable. |
| Privacy | Local-only storage, `allowBackup=false`, nothing sent without explicit action, per-field share toggles, link validation (blocks `javascript:`, `file:`, `intent:` etc.), Nearby accept dialog, HCE answers only while “Start NFC sharing” is active. |
| Light / dark mode | System / Light / Dark setting. |

## NFC notes
* **Contact card mode** sends a vCard. Between two CardLink phones the receiver sees a preview and saves it. Phones without CardLink may offer to open it with Contacts, depending on the manufacturer.
* **Web link mode** sends your *Digital card link* (or website/LinkedIn) and opens on almost any NFC phone.
* Some phones need **Settings → Connected devices → NFC → Contactless payments → "Open app" / "Use default"** adjusted to let a foreground app receive the tap. CardLink requests priority automatically while the NFC screen is open.
* iPhones cannot read Android HCE tags; use QR or app sharing with iPhone users.

## Project structure
```
app/src/main/java/com/cardlink/app/
 ├─ CardLinkApp.kt / MainActivity.kt      app container, NFC & .vcf intent handling
 ├─ data/        Room entities, DAOs, repositories, DataStore settings, templates
 ├─ util/        VCard, QR, card renderer (PNG/PDF), sharing, link validation, backup
 ├─ nfc/         HCE Type-4 tag service + NDEF helpers
 ├─ nearby/      Nearby Connections ViewModel
 └─ ui/          theme, components, 14 screens, navigation, ViewModels
```
Min SDK 26 (Android 8.0) · Target SDK 35 (Android 15).
