package com.cardlink.app.ui.screens

import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IphoneNfcShareScreen(
    activeCard: BusinessCardEntity,
    nfcReaderManager: NfcReaderManager,
    onSaveCard: (BusinessCardEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    val effectiveCard = remember(activeCard, selectedProfile) {
        SharingProfileManager.applyProfile(activeCard, selectedProfile)
    }

    var selectedAction by remember { mutableStateOf(IphoneNfcActionType.PROFILE_LINK) }
    var customProfileUrl by remember(effectiveCard) { mutableStateOf(effectiveCard.resolveNfcShareUrl()) }
    var includeDualAndroidVcard by remember { mutableStateOf(true) }

    val activePayloadSpec = remember(effectiveCard, selectedAction, customProfileUrl) {
        if (selectedAction == IphoneNfcActionType.PROFILE_LINK) {
            val clean = customProfileUrl.trim()
            IphoneNfcPayloadSpec(
                actionType = IphoneNfcActionType.PROFILE_LINK,
                uriString = clean,
                isAvailable = clean.startsWith("https://", true) || clean.startsWith("http://", true),
                requiresInternetOnIphone = true
            )
        } else {
            IphoneNfcShareHelper.buildUriForAction(effectiveCard, selectedAction)
        }
    }

    val vcardPayload = remember(effectiveCard) { CardShareHelper.toVCardString(effectiveCard) }

    // Configure Android HCE in IPHONE_SHARE mode (Well-Known URI record first so iPhone Background Tag Reading triggers!)
    DisposableEffect(activePayloadSpec, vcardPayload, includeDualAndroidVcard) {
        if (activePayloadSpec.isAvailable) {
            CardLinkHceService.shareMode = NfcShareMode.IPHONE_SHARE
            CardLinkHceService.activeIphoneUri = activePayloadSpec.uriString
            CardLinkHceService.includeSecondaryVcardOnIphone = includeDualAndroidVcard
            CardLinkHceService.activeVCardPayload = vcardPayload
        }
        // Reader mode MUST stay disabled during HCE broadcast
        nfcReaderManager.disableReaderMode()
        onDispose {
            // Restore standard HCE profile state when leaving screen
            CardLinkHceService.shareMode = NfcShareMode.VCARD
            CardLinkHceService.activeVCardPayload = vcardPayload
        }
    }

    // Offline Full-vCard QR Code fallback (iPhone Camera reads full vCard offline with zero internet!)
    val offlineVcardQr = remember(vcardPayload) {
        CardShareHelper.generateQrCodeBitmap(vcardPayload, 640)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.nfc_share_iphone_title), fontWeight = FontWeight.Bold)
                        Text(
                            text = stringResource(R.string.nfc_share_iphone_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hardware Availability Check
            if (!nfcReaderManager.isNfcSupported()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.nfc_unsupported_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        Text(stringResource(R.string.nfc_iphone_use_qr_fallback), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            } else if (!nfcReaderManager.isNfcEnabled()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.nfc_disabled_title), fontWeight = FontWeight.Bold)
                        Button(onClick = {
                            runCatching { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }) {
                            Text(stringResource(R.string.nfc_open_settings_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // 2. Visual iPhone Top-Edge Alignment & Ready-to-Tap Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        val accent = MaterialTheme.colorScheme.primary
                        val muted = MaterialTheme.colorScheme.onSurfaceVariant
                        Canvas(modifier = Modifier.size(64.dp)) {
                            // Android phone back outline
                            drawRoundRect(
                                color = muted.copy(alpha = 0.45f),
                                topLeft = Offset(size.width * 0.14f, size.height * 0.22f),
                                size = Size(size.width * 0.46f, size.height * 0.72f),
                                cornerRadius = CornerRadius(10f, 10f),
                                style = Stroke(width = 3f)
                            )
                            // iPhone top-edge NFC antenna touching center-back of Android
                            drawRoundRect(
                                color = accent,
                                topLeft = Offset(size.width * 0.36f, size.height * 0.06f),
                                size = Size(size.width * 0.48f, size.height * 0.34f),
                                cornerRadius = CornerRadius(10f, 10f),
                                style = Stroke(width = 4f)
                            )
                            drawCircle(
                                color = accent,
                                radius = 7f,
                                center = Offset(size.width * 0.48f, size.height * 0.36f)
                            )
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = stringResource(R.string.nfc_iphone_ready_title),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 15.sp
                            )
                            Text(
                                text = stringResource(R.string.nfc_iphone_tap_guide),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 3. Sharing Profile Selector (Respects Privacy Boundaries)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.sharing_profile_label), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SharingProfileType.values().forEach { prof ->
                            FilterChip(
                                selected = selectedProfile == prof,
                                onClick = {
                                    selectedProfile = prof
                                    SharingProfileManager.setActiveProfile(context, prof)
                                },
                                label = { Text(prof.label, fontSize = 11.5.sp) }
                            )
                        }
                    }
                }
            }

            // 4. iOS-Compatible Action Mode Selector (Digital Card URL + 100% Offline iOS Native Schemes)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.nfc_iphone_action_header), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    Text(stringResource(R.string.nfc_iphone_action_explain), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    val actionItems = listOf(
                        IphoneNfcActionType.PROFILE_LINK to R.string.nfc_iphone_mode_card_link,
                        IphoneNfcActionType.PHONE_CALL to R.string.nfc_iphone_mode_call,
                        IphoneNfcActionType.EMAIL to R.string.nfc_iphone_mode_email,
                        IphoneNfcActionType.SMS to R.string.nfc_iphone_mode_sms,
                        IphoneNfcActionType.WHATSAPP to R.string.nfc_iphone_mode_whatsapp,
                        IphoneNfcActionType.APPLE_MAPS to R.string.nfc_iphone_mode_maps
                    )

                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        actionItems.forEach { (actionType, labelRes) ->
                            val spec = if (actionType == IphoneNfcActionType.PROFILE_LINK) {
                                activePayloadSpec
                            } else {
                                IphoneNfcShareHelper.buildUriForAction(effectiveCard, actionType)
                            }
                            FilterChip(
                                selected = selectedAction == actionType,
                                enabled = spec.isAvailable || actionType == IphoneNfcActionType.PROFILE_LINK,
                                onClick = { selectedAction = actionType },
                                label = { Text(stringResource(labelRes), fontSize = 11.5.sp) }
                            )
                        }
                    }

                    if (selectedAction == IphoneNfcActionType.PROFILE_LINK) {
                        OutlinedTextField(
                            value = customProfileUrl,
                            onValueChange = { customProfileUrl = it },
                            label = { Text(stringResource(R.string.nfc_iphone_url_lbl)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = {
                                    val clean = customProfileUrl.trim()
                                    if (clean.startsWith("https://", true) || clean.startsWith("http://", true)) {
                                        onSaveCard(activeCard.copy(publicCardUrl = clean))
                                        Toast.makeText(context, context.getString(R.string.nfc_iphone_url_saved), Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, context.getString(R.string.nfc_iphone_url_invalid), Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) { Text(stringResource(R.string.nfc_iphone_save_url_btn), fontSize = 12.sp) }

                            Text(
                                text = stringResource(R.string.nfc_iphone_online_badge),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else if (activePayloadSpec.isAvailable) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = if (activePayloadSpec.requiresInternetOnIphone) {
                                        stringResource(R.string.nfc_iphone_online_badge)
                                    } else {
                                        stringResource(R.string.nfc_iphone_offline_badge)
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = activePayloadSpec.uriString,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.nfc_iphone_dual_vcard_title), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(stringResource(R.string.nfc_iphone_dual_vcard_sub), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = includeDualAndroidVcard, onCheckedChange = { includeDualAndroidVcard = it })
                    }
                }
            }

            // 5. Instant Offline Full-vCard QR Fallback (iPhone Camera reads full vCard without internet!)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(stringResource(R.string.nfc_iphone_qr_card_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    Text(stringResource(R.string.nfc_iphone_qr_card_sub), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 2.dp) {
                        Image(
                            bitmap = offlineVcardQr.asImageBitmap(),
                            contentDescription = "Offline vCard QR for iPhone Camera",
                            modifier = Modifier.size(196.dp).padding(10.dp)
                        )
                    }
                    OutlinedButton(
                        onClick = { CardShareHelper.shareVCardFile(context, effectiveCard) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.quick_nfc_share_vcf_btn), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
            }
        }
    }
}
