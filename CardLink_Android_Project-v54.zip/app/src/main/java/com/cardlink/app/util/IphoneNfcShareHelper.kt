package com.cardlink.app.util

import android.net.Uri
import com.cardlink.app.data.model.BusinessCardEntity

enum class IphoneNfcActionType(val id: String) {
    PROFILE_LINK("PROFILE_LINK"),
    PHONE_CALL("PHONE_CALL"),
    EMAIL("EMAIL"),
    SMS("SMS"),
    WHATSAPP("WHATSAPP"),
    APPLE_MAPS("APPLE_MAPS")
}

data class IphoneNfcPayloadSpec(
    val actionType: IphoneNfcActionType,
    val uriString: String,
    val isAvailable: Boolean,
    val requiresInternetOnIphone: Boolean
)

object IphoneNfcShareHelper {

    /**
     * Builds an iOS Background Tag Reading compliant NDEF Well-Known URI for the projected
     * BusinessCardEntity (already filtered through SharingProfileManager).
     */
    fun buildUriForAction(card: BusinessCardEntity, actionType: IphoneNfcActionType): IphoneNfcPayloadSpec {
        return when (actionType) {
            IphoneNfcActionType.PROFILE_LINK -> {
                val url = card.resolveNfcShareUrl().trim().ifBlank { "https://cardlink.app" }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = url,
                    isAvailable = url.startsWith("https://", true) || url.startsWith("http://", true),
                    requiresInternetOnIphone = true
                )
            }
            IphoneNfcActionType.PHONE_CALL -> {
                val rawPhone = if (card.sharePhone) card.phone.trim() else ""
                val clean = rawPhone.filter { it.isDigit() || it == '+' }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (clean.isNotBlank()) "tel:$clean" else "",
                    isAvailable = clean.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.EMAIL -> {
                val email = if (card.shareEmail) card.email.trim() else ""
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (email.isNotBlank()) "mailto:$email" else "",
                    isAvailable = email.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.SMS -> {
                val rawPhone = if (card.sharePhone) card.phone.trim() else ""
                val clean = rawPhone.filter { it.isDigit() || it == '+' }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (clean.isNotBlank()) "sms:$clean" else "",
                    isAvailable = clean.isNotBlank(),
                    requiresInternetOnIphone = false
                )
            }
            IphoneNfcActionType.WHATSAPP -> {
                val rawWa = when {
                    card.shareWhatsapp && card.whatsapp.isNotBlank() -> card.whatsapp
                    card.sharePhone && card.phone.isNotBlank() -> card.phone
                    else -> ""
                }
                val digits = rawWa.filter { it.isDigit() }
                val e164 = if (digits.startsWith("0") && digits.length == 11) "880" + digits.drop(1) else digits
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = if (e164.length >= 7) "https://wa.me/$e164" else "",
                    isAvailable = e164.length >= 7,
                    requiresInternetOnIphone = true
                )
            }
            IphoneNfcActionType.APPLE_MAPS -> {
                val lat = card.latitude
                val lng = card.longitude
                val addr = if (card.shareAddress) card.officeAddress.trim() else ""
                val mapUri = when {
                    card.shareAddress && lat != null && lng != null ->
                        "https://maps.apple.com/?q=${Uri.encode(card.companyName.ifBlank { card.fullName })}&ll=$lat,$lng"
                    addr.isNotBlank() ->
                        "https://maps.apple.com/?q=${Uri.encode(addr)}"
                    else -> ""
                }
                IphoneNfcPayloadSpec(
                    actionType = actionType,
                    uriString = mapUri,
                    isAvailable = mapUri.isNotBlank(),
                    requiresInternetOnIphone = true
                )
            }
        }
    }
}
