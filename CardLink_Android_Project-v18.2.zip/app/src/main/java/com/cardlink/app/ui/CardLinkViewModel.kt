package com.cardlink.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkWidgetUpdater
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CardLinkViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CardLinkDatabase.getDatabase(application).dao()

    val myCards: StateFlow<List<BusinessCardEntity>> = dao.getAllMyCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCard: StateFlow<BusinessCardEntity> = myCards.map { list ->
        val card = list.firstOrNull { it.isDefault } ?: list.firstOrNull() ?: defaultSeedCard()
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(card)
        CardLinkHceService.activeShareUrl = card.resolveNfcShareUrl()
        card
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), defaultSeedCard())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val contacts: StateFlow<List<SavedContactEntity>> = _searchQuery
        .flatMapLatest { q -> dao.searchContacts(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allContacts: StateFlow<List<SavedContactEntity>> = dao.getAllContactsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shareHistory: StateFlow<List<ShareHistoryEntity>> = dao.getShareHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val followUps: StateFlow<List<FollowUpEntity>> = dao.getAllFollowUpsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loyaltyCards: StateFlow<List<LoyaltyCardEntity>> = dao.getAllLoyaltyCardsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val idDocuments: StateFlow<List<IdDocumentEntity>> = dao.getAllIdDocumentsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val idPages: StateFlow<List<IdDocumentPageEntity>> = dao.getAllIdPagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _appCustomTheme = MutableStateFlow(ThemeContrastHelper.loadAppTheme(application))
    val appCustomTheme: StateFlow<AppCustomThemeConfig> = _appCustomTheme

    private val _darkThemeOverride = MutableStateFlow<Boolean?>(LanguageManager.getSavedThemeOverride(application))
    val darkThemeOverride: StateFlow<Boolean?> = _darkThemeOverride

    private val _appLanguage = MutableStateFlow(LanguageManager.getSavedLanguage(application))
    val appLanguage: StateFlow<String> = _appLanguage

    private val _notificationsEnabled = MutableStateFlow(LanguageManager.isNotificationsEnabled(application))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled

    private val _quickPrivacyMode = MutableStateFlow(false)
    val quickPrivacyMode: StateFlow<Boolean> = _quickPrivacyMode

    private val _eventMode = MutableStateFlow(EventModeHelper.load(application))
    val eventMode: StateFlow<EventModeConfig> = _eventMode

    init {
        viewModelScope.launch {
            cleanupDuplicateProfiles()
            if (dao.getAllMyCardsSnapshot().isEmpty()) {
                dao.upsertMyCard(defaultSeedCard())
            }
            FollowUpScheduler.rescheduleAllPending(getApplication())
            IdExpiryReminderScheduler.rescheduleAll(getApplication())
        }
    }

    private fun isUntouchedSeedCard(c: BusinessCardEntity): Boolean {
        return c.phone == "+880 1700-000000" && c.email == "contact@cardlink.app"
    }

    private suspend fun cleanupDuplicateProfiles() {
        val all = dao.getAllMyCardsSnapshot()
        if (all.size <= 1) return

        val nonSeed = all.filterNot { isUntouchedSeedCard(it) }
        val toDelete = mutableListOf<BusinessCardEntity>()

        // If user has any real edited profile, remove untouched default seed duplicates
        if (nonSeed.isNotEmpty()) {
            toDelete.addAll(all.filter { isUntouchedSeedCard(it) })
        }

        val remaining = all - toDelete.toSet()
        val seenKeys = mutableSetOf<String>()
        for (card in remaining) {
            val key = listOf(
                card.profileTitle.trim().lowercase(),
                card.fullName.trim().lowercase(),
                card.phone.filter { it.isDigit() },
                card.email.trim().lowercase()
            ).joinToString("|")
            if (!seenKeys.add(key)) {
                toDelete.add(card)
            }
        }

        toDelete.forEach { dao.deleteMyCard(it) }

        val finalCards = dao.getAllMyCardsSnapshot()
        if (finalCards.isNotEmpty() && finalCards.none { it.isDefault }) {
            dao.setActiveCard(finalCards.first().id)
        }
    }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }

    fun saveCard(card: BusinessCardEntity) {
        viewModelScope.launch {
            var enriched = card
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val id = dao.upsertMyCard(enriched)
            if (enriched.isDefault) dao.setActiveCard(if (enriched.id == 0L) id else enriched.id)
            CardLinkHceService.activeShareUrl = enriched.resolveNfcShareUrl()
            CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(enriched)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun saveCardAndAppTheme(card: BusinessCardEntity, appTheme: AppCustomThemeConfig) {
        viewModelScope.launch {
            ThemeContrastHelper.saveAppTheme(getApplication(), appTheme)
            _appCustomTheme.value = appTheme
            saveCard(card)
        }
    }

    fun resetCardAndAppThemeToDefaults(): Pair<BusinessCardEntity, AppCustomThemeConfig> {
        val defApp = ThemeContrastHelper.resetAppTheme(getApplication())
        _appCustomTheme.value = defApp
        val defCard = activeCard.value.copy(
            template = CardTemplate.EXECUTIVE_NAVY, primaryColorHex = 0xFF0A192F, secondaryColorHex = 0xFF112240,
            accentColorHex = 0xFFD4AF37, textColorHex = 0xFFFFFFFF, buttonColorHex = 0xFFD4AF37,
            iconColorHex = 0xFFD4AF37, cardGradientEndHex = 0xFF172A46, fontFamilyName = "Serif"
        )
        saveCard(defCard)
        return Pair(defCard, defApp)
    }

    fun switchActiveProfile(cardId: Long) {
        viewModelScope.launch {
            dao.setActiveCard(cardId)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun activateEventMode(eventName: String, location: String) {
        val cfg = EventModeConfig(
            isActive = true,
            eventName = eventName.trim(),
            location = location.trim(),
            startedAtTimestamp = System.currentTimeMillis()
        )
        EventModeHelper.save(getApplication(), cfg)
        _eventMode.value = cfg
    }

    fun deactivateEventMode() {
        val cfg = _eventMode.value.copy(isActive = false)
        EventModeHelper.save(getApplication(), cfg)
        _eventMode.value = cfg
    }

    fun saveReceivedContact(contact: SavedContactEntity, updatePendingWaNumberTo: String? = null) {
        viewModelScope.launch {
            var enriched = if (contact.id == 0L) {
                EventModeHelper.applyIfActive(contact, _eventMode.value)
            } else contact
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val savedId = dao.upsertContact(enriched)
            val targetId = if (enriched.id != 0L) enriched.id else savedId
            if (!updatePendingWaNumberTo.isNullOrBlank()) {
                dao.getPendingWhatsAppFollowUpsForContact(targetId).forEach { fu ->
                    val updatedFu = fu.copy(whatsappNumber = updatePendingWaNumberTo)
                    dao.upsertFollowUp(updatedFu)
                    FollowUpScheduler.scheduleForItem(getApplication(), updatedFu)
                }
            }
        }
    }

    fun deleteContact(contact: SavedContactEntity) {
        viewModelScope.launch { ScannedCardStorageHelper.deleteSavedCardImage(contact.profilePhotoUri); ScannedCardStorageHelper.deleteSavedCardImage(contact.backPhotoUri); dao.deleteContact(contact) }
    }

    fun saveFollowUp(item: FollowUpEntity) {
        viewModelScope.launch {
            val id = dao.upsertFollowUp(item)
            FollowUpScheduler.scheduleForItem(getApplication(), item.copy(id = if (item.id == 0L) id else item.id))
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun toggleFollowUpCompleted(item: FollowUpEntity) {
        viewModelScope.launch {
            val nextDone = !item.isCompleted
            val updated = item.copy(isCompleted = nextDone, status = if (nextDone) FollowUpStatus.COMPLETED.name else FollowUpStatus.PENDING.name)
            dao.upsertFollowUp(updated)
            if (nextDone) FollowUpScheduler.cancelForItem(getApplication(), updated.id) else FollowUpScheduler.scheduleForItem(getApplication(), updated)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun cancelFollowUp(item: FollowUpEntity) {
        viewModelScope.launch { FollowUpScheduler.cancelForItem(getApplication(), item.id); dao.upsertFollowUp(item.copy(status = FollowUpStatus.CANCELLED.name)); CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun deleteFollowUp(item: FollowUpEntity) {
        viewModelScope.launch { FollowUpScheduler.cancelForItem(getApplication(), item.id); dao.deleteFollowUp(item); CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun saveLoyaltyCard(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val toSave = if (card.id == 0L) {
                card.copy(createdAtTimestamp = now, updatedAtTimestamp = now)
            } else {
                card.copy(updatedAtTimestamp = now)
            }
            dao.upsertLoyaltyCard(toSave)
        }
    }

    fun deleteLoyaltyCard(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            ScannedCardStorageHelper.deleteSavedCardImage(card.frontPhotoUri)
            ScannedCardStorageHelper.deleteSavedCardImage(card.backPhotoUri)
            dao.deleteLoyaltyCard(card)
        }
    }

    fun saveIdDocument(doc: IdDocumentEntity, pages: List<IdDocumentPageEntity>) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val toSave = if (doc.id == 0L) {
                doc.copy(createdAtTimestamp = now, updatedAtTimestamp = now)
            } else {
                doc.copy(updatedAtTimestamp = now)
            }
            dao.upsertIdDocument(toSave)
            dao.deletePagesForDocument(toSave.stableUuid)
            if (pages.isNotEmpty()) {
                val normalized = pages.mapIndexed { idx, p ->
                    p.copy(id = 0L, documentUuid = toSave.stableUuid, pageIndex = idx)
                }
                dao.insertIdPagesBatch(normalized)
            }
            // Always cancel old reminders and schedule only applicable future reminders for confirmed expiry date
            IdExpiryReminderScheduler.scheduleForDocument(getApplication(), toSave)
        }
    }

    fun deleteIdDocument(doc: IdDocumentEntity) {
        viewModelScope.launch {
            IdExpiryReminderScheduler.cancelForDocument(getApplication(), doc.stableUuid)
            val existingPages = dao.getPagesForDocumentSnapshot(doc.stableUuid)
            existingPages.forEach { ScannedCardStorageHelper.deleteSavedCardImage(it.imageUri) }
            dao.deletePagesForDocument(doc.stableUuid)
            dao.deleteIdDocument(doc)
        }
    }

    fun logShare(method: String, recipient: String = "External") {
        viewModelScope.launch { dao.logShareEvent(ShareHistoryEntity(cardProfileTitle = activeCard.value.profileTitle, method = method, recipientInfo = recipient)) }
    }

    fun toggleTheme(isDark: Boolean?) {
        LanguageManager.saveThemeOverride(getApplication(), isDark)
        _darkThemeOverride.value = isDark
        viewModelScope.launch { CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun setAppLanguage(languageCode: String) {
        LanguageManager.saveLanguage(getApplication(), languageCode)
        _appLanguage.value = LanguageManager.getSavedLanguage(getApplication())
        viewModelScope.launch { CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        LanguageManager.setNotificationsEnabled(getApplication(), enabled)
        _notificationsEnabled.value = enabled
        viewModelScope.launch {
            if (enabled) {
                FollowUpScheduler.rescheduleAllPending(getApplication())
            IdExpiryReminderScheduler.rescheduleAll(getApplication())
            }
        }
    }
    fun toggleQuickPrivacyMode() { _quickPrivacyMode.value = !_quickPrivacyMode.value }

    fun exportFullJsonBackup(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            onComplete(
                CardLinkBackupManager.exportFullBackupToUri(
                    getApplication(),
                    uri,
                    dao.getAllMyCardsSnapshot(),
                    dao.getAllContactsSnapshot(),
                    dao.getAllLoyaltyCardsSnapshot(),
                    dao.getAllIdDocumentsSnapshot(),
                    dao.getAllIdPagesSnapshot()
                )
            )
        }
    }

    fun importFullJsonBackup(uri: Uri, replaceExisting: Boolean, onComplete: (Result<RestoreSummary>) -> Unit) {
        viewModelScope.launch {
            CardLinkBackupManager.importFullBackupFromUri(getApplication(), uri).onSuccess { bundle ->
                val existingLoyalty = dao.getAllLoyaltyCardsSnapshot()
                val existingIds = dao.getAllIdDocumentsSnapshot()
                val existingIdPages = dao.getAllIdPagesSnapshot()
                if (replaceExisting) {
                    existingIds.forEach { IdExpiryReminderScheduler.cancelForDocument(getApplication(), it.stableUuid) }
                    CloudBackupManager.savePreReplaceRecoverySnapshot(
                        getApplication(),
                        dao.getAllMyCardsSnapshot(),
                        dao.getAllContactsSnapshot(),
                        dao.getAllFollowUpsSnapshot(),
                        existingLoyalty,
                        existingIds,
                        existingIdPages
                    )
                    dao.clearAllMyCards()
                    dao.clearAllContacts()
                    dao.clearAllLoyaltyCards()
                    dao.clearAllIdPages()
                    dao.clearAllIdDocuments()
                }
                if (bundle.myCards.isNotEmpty()) {
                    dao.insertMyCardsBatch(bundle.myCards)
                    cleanupDuplicateProfiles()
                }
                if (bundle.contacts.isNotEmpty()) dao.insertContactsBatch(bundle.contacts)
                val loyaltyToInsert = if (replaceExisting) {
                    bundle.loyaltyCards
                } else {
                    val existingUuids = existingLoyalty.map { it.stableUuid }.toSet()
                    bundle.loyaltyCards.filterNot { it.stableUuid in existingUuids }
                }
                if (loyaltyToInsert.isNotEmpty()) dao.insertLoyaltyCardsBatch(loyaltyToInsert)

                val existingIdUuids = existingIds.map { it.stableUuid }.toSet()
                val idsToInsert = if (replaceExisting) bundle.idDocuments else bundle.idDocuments.filterNot { it.first.stableUuid in existingIdUuids }
                if (idsToInsert.isNotEmpty()) {
                    dao.insertIdDocumentsBatch(idsToInsert.map { it.first })
                    dao.insertIdPagesBatch(idsToInsert.flatMap { it.second })
                }
                IdExpiryReminderScheduler.rescheduleAll(getApplication())
                onComplete(Result.success(RestoreSummary(bundle.myCards.size, bundle.contacts.size, loyaltyToInsert.size, idsToInsert.size)))
            }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    suspend fun createCloudSnapshot(context: Context, providerKey: String): Result<CloudSnapshotBundle> =
        CloudBackupManager.createCloudSnapshot(
            context,
            providerKey,
            dao.getAllMyCardsSnapshot(),
            dao.getAllContactsSnapshot(),
            dao.getAllFollowUpsSnapshot(),
            dao.getAllLoyaltyCardsSnapshot(),
            dao.getAllIdDocumentsSnapshot(),
            dao.getAllIdPagesSnapshot()
        )

    suspend fun restoreFromCloudSnapshot(context: Context, bundle: CloudSnapshotBundle, replaceExisting: Boolean): Result<Unit> = runCatching {
        if (!CloudBackupManager.verifyIntegrity(bundle)) error("Backup integrity check failed.")
        val existingFollowUps = dao.getAllFollowUpsSnapshot()
        val existingLoyalty = dao.getAllLoyaltyCardsSnapshot()
        val existingIds = dao.getAllIdDocumentsSnapshot()
        val existingIdPages = dao.getAllIdPagesSnapshot()
        existingFollowUps.forEach { FollowUpScheduler.cancelForItem(context, it.id) }
        existingIds.forEach { IdExpiryReminderScheduler.cancelForDocument(context, it.stableUuid) }
        if (replaceExisting) {
            CloudBackupManager.savePreReplaceRecoverySnapshot(
                context,
                dao.getAllMyCardsSnapshot(),
                dao.getAllContactsSnapshot(),
                existingFollowUps,
                existingLoyalty,
                existingIds,
                existingIdPages
            )
            dao.clearAllMyCards()
            dao.clearAllContacts()
            dao.clearAllFollowUps()
            dao.clearAllLoyaltyCards()
            dao.clearAllIdPages()
            dao.clearAllIdDocuments()
        }
        if (bundle.cards.isNotEmpty()) {
            dao.insertMyCardsBatch(bundle.cards.map { it.copy(id = if (replaceExisting) it.id else 0L) })
            cleanupDuplicateProfiles()
        }
        if (bundle.contacts.isNotEmpty()) dao.insertContactsBatch(bundle.contacts.map { it.copy(id = if (replaceExisting) it.id else 0L) })
        if (bundle.followUps.isNotEmpty()) {
            val deduped = bundle.followUps.filterNot { r -> !replaceExisting && existingFollowUps.any { ex -> ex.title == r.title && ex.dueAtTimestamp == r.dueAtTimestamp && ex.contactName == r.contactName } }.map { it.copy(id = 0L) }
            if (deduped.isNotEmpty()) dao.insertFollowUpsBatch(deduped)
        }
        if (bundle.loyaltyCards.isNotEmpty()) {
            val restoredLoyalty = bundle.loyaltyCards.map { CardLinkBackupManager.restoreBackedUpLoyaltyCard(context, it) }
            val loyaltyToInsert = if (replaceExisting) {
                restoredLoyalty
            } else {
                val existingUuids = existingLoyalty.map { it.stableUuid }.toSet()
                restoredLoyalty.filterNot { it.stableUuid in existingUuids }
            }
            if (loyaltyToInsert.isNotEmpty()) dao.insertLoyaltyCardsBatch(loyaltyToInsert)
        }
        if (bundle.idDocuments.isNotEmpty()) {
            val restoredIds = bundle.idDocuments.map { CardLinkBackupManager.restoreBackedUpIdDocument(context, it) }
            val existingIdUuids = existingIds.map { it.stableUuid }.toSet()
            val idsToInsert = if (replaceExisting) restoredIds else restoredIds.filterNot { it.first.stableUuid in existingIdUuids }
            if (idsToInsert.isNotEmpty()) {
                dao.insertIdDocumentsBatch(idsToInsert.map { it.first })
                dao.insertIdPagesBatch(idsToInsert.flatMap { it.second })
            }
        }
        ThemeContrastHelper.saveAppTheme(context, bundle.themeConfig); _appCustomTheme.value = bundle.themeConfig
        BiometricLockHelper.setLockEnabled(context, bundle.biometricLockEnabled)
        FollowUpScheduler.rescheduleAllPending(context)
        IdExpiryReminderScheduler.rescheduleAll(context)
    }

    fun exportContactsCsv(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportContactsToCsv(getApplication(), uri, dao.getAllContactsSnapshot())) }
    }
    fun exportBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportContactsToBatchVcf(getApplication(), uri, dao.getAllContactsSnapshot())) }
    }
    fun importBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            CardLinkBackupManager.importContactsFromBatchVcf(getApplication(), uri).onSuccess { dao.insertContactsBatch(it); onComplete(Result.success(it.size)) }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    private fun defaultSeedCard() = BusinessCardEntity(
        profileTitle = "Executive Profile", isDefault = true, fullName = "Md. Mazharul Islam",
        designation = "Head of Central Procurement", companyName = "Corporate Division", department = "Central Procurement",
        bio = "Driving strategic sourcing, agile procurement, and digital transformation.",
        phone = "+880 1700-000000", whatsapp = "+8801700000000", email = "contact@cardlink.app",
        officeAddress = "Motijheel C/A, Dhaka, Bangladesh", latitude = 23.7330, longitude = 90.4172,
        website = "https://cardlink.app", publicCardUrl = "https://drive.google.com/"
    )
}
