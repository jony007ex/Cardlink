# CardLink Production R8 Rules (Defense-in-Depth)
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod

# Kotlinx Serialization
-keepattributes RuntimeVisibleAnnotations, AnnotationDefault
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.cardlink.app.**$$serializer { *; }
-keepclassmembers class com.cardlink.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.cardlink.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Room Entities & Database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }

# SQLCipher Native Bridge
-keep class net.zetetic.** { *; }
-keep class net.sqlcipher.** { *; }
-dontwarn net.zetetic.**
-dontwarn net.sqlcipher.**

# WorkManager Workers
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# BiometricPrompt & Fragment
-keep class androidx.biometric.** { *; }

# ML Kit, ZXing, CameraX, Glance
-dontwarn com.google.zxing.**
-dontwarn com.google.mlkit.**
-dontwarn org.bouncycastle.**
-dontwarn javax.annotation.**
-dontwarn java.lang.invoke.StringConcatFactory

# Strip verbose debug logs in Release builds
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
    public static int i(...);
}
# CameraX, ML Kit Barcode/OCR, ZXing, Coil (Required for Loyalty Cards & Scanners in R8 Release)
-keep class com.google.mlkit.vision.barcode.** { *; }
-keep class com.google.mlkit.vision.text.** { *; }
-keep class com.google.zxing.** { *; }
-keep class androidx.camera.** { *; }
-keep class coil.** { *; }

# Google Nearby Connections (BLE + Wi-Fi Direct)
-keep class com.google.android.gms.nearby.** { *; }
-dontwarn com.google.android.gms.nearby.**
