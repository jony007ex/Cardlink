package com.cardlink.app

import com.cardlink.app.util.ContactBirthdayHelper
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ContactBirthdayHelperTest {

    @Test
    fun ageAfterBirthdayThisYear_isExact() {
        val today = LocalDate.of(2026, 11, 25)
        val info = ContactBirthdayHelper.computeBirthdayInfo("1985-03-15", today)
        assertNotNull(info)
        assertEquals(41, info?.ageYears)
        assertFalse(info?.isBirthdaySoon ?: true)
    }

    @Test
    fun ageBeforeBirthdayThisYear_subtractsOneYear() {
        val today = LocalDate.of(2026, 11, 25)
        val info = ContactBirthdayHelper.computeBirthdayInfo("1991-12-26", today)
        assertNotNull(info)
        assertEquals(34, info?.ageYears)
        assertEquals(31, info?.daysUntilNextBirthday)
        assertFalse(info?.isBirthdaySoon ?: true)
    }

    @Test
    fun birthdayToday_hasZeroDaysUntilAndExactAge() {
        val today = LocalDate.of(2026, 11, 25)
        val info = ContactBirthdayHelper.computeBirthdayInfo("1990-11-25", today)
        assertNotNull(info)
        assertEquals(36, info?.ageYears)
        assertEquals(0, info?.daysUntilNextBirthday)
        assertTrue(info?.isBirthdaySoon == true)
    }

    @Test
    fun birthdayWithin30Days_flaggedAsBirthdaySoon() {
        val today = LocalDate.of(2026, 11, 25)
        val info = ContactBirthdayHelper.computeBirthdayInfo("1992-12-10", today)
        assertNotNull(info)
        assertEquals(15, info?.daysUntilNextBirthday)
        assertTrue(info?.isBirthdaySoon == true)
    }

    @Test
    fun leapDayBirthday_handledSafelyInNonLeapYear() {
        val today = LocalDate.of(2026, 2, 20)
        val info = ContactBirthdayHelper.computeBirthdayInfo("1996-02-29", today)
        assertNotNull(info)
        assertEquals(29, info?.ageYears)
        assertEquals(8, info?.daysUntilNextBirthday)
        assertTrue(info?.isBirthdaySoon == true)
    }

    @Test
    fun futureDobAndInvalidStrings_returnNull() {
        val today = LocalDate.of(2026, 11, 25)
        assertNull(ContactBirthdayHelper.computeBirthdayInfo("2030-01-01", today))
        assertNull(ContactBirthdayHelper.computeBirthdayInfo("", today))
        assertNull(ContactBirthdayHelper.computeBirthdayInfo(null, today))
        assertNull(ContactBirthdayHelper.computeBirthdayInfo("not-a-date", today))
    }
}
