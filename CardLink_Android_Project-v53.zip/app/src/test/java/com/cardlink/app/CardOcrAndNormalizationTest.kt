package com.cardlink.app

import com.cardlink.app.util.CardOcrPipeline
import com.cardlink.app.util.DetectedScript
import com.cardlink.app.util.OcrBenchmarkEvaluator
import com.cardlink.app.util.PhoneContactsHelper
import org.junit.Assert.*
import org.junit.Test

class CardOcrAndNormalizationTest {

    @Test
    fun banglaDigitsConvertToAsciiAccurately() {
        val converted = CardOcrPipeline.convertBanglaDigitsToAscii("০১৭১১-২২৩৩৪৪")
        assertEquals("01711-223344", converted)
    }

    @Test
    fun bangladeshPhoneNormalization_unifiesFormats() {
        assertEquals("+8801711223344", CardOcrPipeline.normalizeBangladeshPhone("01711-223344"))
        assertEquals("+8801711223344", CardOcrPipeline.normalizeBangladeshPhone("+880 1711 223344"))
        assertEquals("+8801711223344", CardOcrPipeline.normalizeBangladeshPhone("8801711223344"))
        assertEquals("+8801711223344", CardOcrPipeline.normalizeBangladeshPhone("০১৭১১২২৩৩৪৪"))
    }

    @Test
    fun scriptClassification_detectsBanglaEnglishMixedAndNumeric() {
        assertEquals(DetectedScript.BANGLA, CardOcrPipeline.classifyScript("মোঃ রহিম উদ্দিন"))
        assertEquals(DetectedScript.ENGLISH, CardOcrPipeline.classifyScript("Md. Rahim Uddin"))
        assertEquals(DetectedScript.MIXED, CardOcrPipeline.classifyScript("আইএফআইসি Bank PLC"))
        assertEquals(DetectedScript.NUMERIC, CardOcrPipeline.classifyScript("+880-1711-000000"))
    }

    @Test
    fun unicodeNormalization_stripsZeroWidthButPreservesBangla() {
        val raw = "  আইএফআইসি\u200B   ব্যাংক  "
        assertEquals("আইএফআইসি ব্যাংক", CardOcrPipeline.normalizeUnicodeText(raw))
    }

    @Test
    fun ocrBenchmarkEvaluator_calculatesCerAndWerCorrectly() {
        assertEquals(0.0, OcrBenchmarkEvaluator.characterErrorRate("CardLink", "CardLink"), 0.0001)
        assertEquals(0.25, OcrBenchmarkEvaluator.characterErrorRate("abcd", "abce"), 0.0001)
        assertEquals(0.5, OcrBenchmarkEvaluator.wordErrorRate("IFIC Bank", "IFIC Corp"), 0.0001)
    }

    @Test
    fun phoneContactsHelper_validatesAndNormalizes() {
        assertTrue(PhoneContactsHelper.isValidInternationalOrLocalPhone("+8801711000000"))
        assertTrue(PhoneContactsHelper.isValidInternationalOrLocalPhone("01711000000"))
        assertFalse(PhoneContactsHelper.isValidInternationalOrLocalPhone("123"))
        assertEquals("+8801711000000", PhoneContactsHelper.normalizeWithCountryCode("01711000000"))
    }
}
