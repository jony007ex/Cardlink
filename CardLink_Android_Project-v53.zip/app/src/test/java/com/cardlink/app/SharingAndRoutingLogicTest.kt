package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.util.ExternalIntentGateway
import com.cardlink.app.util.SharingProfileManager
import com.cardlink.app.util.SharingProfileType
import com.cardlink.app.util.UniversalQrParser
import com.cardlink.app.util.UniversalQrType
import org.junit.Assert.*
import org.junit.Test

class SharingAndRoutingLogicTest {

    @Test
    fun externalIntentGateway_allowsAllWidgetTileShortcutAndNotificationRoutes() {
        val requiredRoutes = listOf(
            "home", "share", "scan_qr", "scan_ocr", "contacts", "contacts_import",
            "calendar", "calendar_new", "followups", "qr_screen", "quick_nfc_qr_share",
            "meeting_brief/42", "contact_detail/99", "my_ids", "loyalty_cards"
        )
        for (r in requiredRoutes) {
            assertTrue("Expected route '$r' to be allowed", ExternalIntentGateway.isRouteAllowedFromExternal(r))
        }
    }

    @Test
    fun externalIntentGateway_blocksMaliciousOrUnknownRoutes() {
        val forbiddenRoutes = listOf(
            "javascript:alert(1)",
            "meeting_brief/abc",
            "contact_detail/-1",
            "../etc/passwd",
            "unknown_admin_route",
            ""
        )
        for (r in forbiddenRoutes) {
            assertFalse("Expected route '$r' to be blocked", ExternalIntentGateway.isRouteAllowedFromExternal(r))
        }
    }

    @Test
    fun sharingProfileManager_enforcesPrivacyBoundariesAcrossProfiles() {
        val base = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            phone = "+8801700000001",
            whatsapp = "+8801700000002",
            email = "work@ificbank.com",
            officeAddress = "IFIC Tower, Dhaka",
            linkedInUrl = "https://linkedin.com/in/example",
            sharePhone = true,
            shareWhatsapp = true,
            shareEmail = true,
            shareAddress = true,
            shareSocials = true
        )

        val conference = SharingProfileManager.applyProfile(base, SharingProfileType.CONFERENCE)
        assertTrue(conference.shareEmail)
        assertFalse(conference.shareWhatsapp)
        assertFalse(conference.shareAddress)

        val business = SharingProfileManager.applyProfile(base, SharingProfileType.BUSINESS)
        assertTrue(business.sharePhone)
        assertTrue(business.shareEmail)
        assertTrue(business.shareAddress)
    }

    @Test
    fun universalQrParser_classifiesVCardWifiAndRejectsDangerousSchemes() {
        val vcard = UniversalQrParser.parse("BEGIN:VCARD\nVERSION:3.0\nFN:Arif Hoque\nTEL:+8801610002693\nEND:VCARD")
        assertEquals(UniversalQrType.VCARD, vcard.type)
        assertEquals("Arif Hoque", vcard.parsedContact?.fullName)

        val wifi = UniversalQrParser.parse("WIFI:T:WPA;S:OfficeNet;P:Secret123;;")
        assertEquals(UniversalQrType.WIFI, wifi.type)
        assertEquals("OfficeNet", wifi.parsedFields["SSID"])

        val xss = UniversalQrParser.parse("javascript:alert(1)")
        assertTrue(xss.warningMessage.isNotBlank())
    }
}
