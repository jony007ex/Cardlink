package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.util.CardCropMetadata
import com.cardlink.app.util.CardTemplateRegistry
import com.cardlink.app.util.IdExpiryHelper
import com.cardlink.app.util.LoyaltyCodeHelper
import org.junit.Assert.*
import org.junit.Test

class CoreDomainModelsTest {

    @Test
    fun cardTemplateRegistry_resolvesEveryEnumSafelyWithoutNullCrash() {
        for (tpl in CardTemplate.values()) {
            val resolved = CardTemplateRegistry.resolveForCard(
                BusinessCardEntity(template = tpl, selectedTemplateId = "")
            )
            assertTrue(resolved.id.isNotBlank())
        }
        val fallback = CardTemplateRegistry.resolveForCard(
            BusinessCardEntity(selectedTemplateId = "non_existent_id:v99")
        )
        assertTrue(fallback.id.isNotBlank())
    }

    @Test
    fun loyaltyCodeHelper_masksCardNumberSafely() {
        assertEquals("•••• 5678", LoyaltyCodeHelper.maskCardNumber("12345678"))
        assertEquals("1234", LoyaltyCodeHelper.maskCardNumber("1234"))
        assertEquals("Code 128", LoyaltyCodeHelper.formatDisplayName("CODE_128"))
    }

    @Test
    fun cardCropMetadata_roundTripsJsonCleanly() {
        val original = CardCropMetadata(
            topLeftX = 0.08f,
            topLeftY = 0.12f,
            topRightX = 0.91f,
            topRightY = 0.10f,
            bottomRightX = 0.93f,
            bottomRightY = 0.89f,
            bottomLeftX = 0.06f,
            bottomLeftY = 0.90f,
            rotationDegrees = 90,
            enhanceReadability = true
        )
        val encoded = CardCropMetadata.toJson(original)
        val decoded = CardCropMetadata.fromJson(encoded)
        assertNotNull(decoded)
        assertEquals(90, decoded?.rotationDegrees)
        assertEquals(0.08f, decoded?.topLeftX ?: 0f, 0.0001f)
    }

    @Test
    fun idExpiryHelper_parsesAndFormatsIsoDate() {
        val iso = IdExpiryHelper.toIsoDate(2028, 5, 9)
        assertEquals("2028-05-09", iso)
        val parsed = IdExpiryHelper.parseIsoDate(iso)
        assertNotNull(parsed)
        assertEquals(2028, parsed?.year)
        assertEquals(5, parsed?.monthValue)
        assertEquals(9, parsed?.dayOfMonth)
    }


    @Test
    fun backupPreferences_preservesNewSettingsAndDecodesLegacyJsonSafely() {
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val prefs = com.cardlink.app.util.CardLinkPackagePreferences(
            autoSavePhoneContacts = true,
            birthdayReminderMode = "7_DAYS",
            ocrQualityTier = "HIGHER_ACCURACY",
            activeSharingProfileId = "CONFERENCE",
            recycleBinRetentionDays = 7,
            autoLockDurationName = "FIVE_MINUTES"
        )
        val encoded = json.encodeToString(com.cardlink.app.util.CardLinkPackagePreferences.serializer(), prefs)
        val decoded = json.decodeFromString(com.cardlink.app.util.CardLinkPackagePreferences.serializer(), encoded)
        assertTrue(decoded.autoSavePhoneContacts)
        assertEquals("7_DAYS", decoded.birthdayReminderMode)
        assertEquals("HIGHER_ACCURACY", decoded.ocrQualityTier)
        assertEquals("CONFERENCE", decoded.activeSharingProfileId)
        assertEquals(7, decoded.recycleBinRetentionDays)
        assertEquals("FIVE_MINUTES", decoded.autoLockDurationName)

        // Legacy backup JSON without new fields must decode cleanly with safe defaults
        val legacy = json.decodeFromString(com.cardlink.app.util.CardLinkPackagePreferences.serializer(), """{"languageCode":"bn"}""")
        assertEquals("bn", legacy.languageCode)
        assertFalse(legacy.autoSavePhoneContacts)
        assertEquals("OFF", legacy.birthdayReminderMode)
        assertEquals("BALANCED", legacy.ocrQualityTier)
    }
}
