package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.MeetingInviteHelper
import org.junit.Assert.*
import org.junit.Test

class VCardAndMeetingIcsTest {

    @Test
    fun vCardGenerator_usesRfcEscapingCrlfAndRespectsPrivacyFlags() {
        val card = BusinessCardEntity(
            fullName = "Md. Mazharul Islam",
            designation = "AVP, Procurement; Archiving",
            companyName = "IFIC Bank PLC",
            phone = "+8801700000001",
            whatsapp = "+8801700000002",
            email = "work@ificbank.com",
            officeAddress = "IFIC Tower, Dhaka",
            sharePhone = true,
            shareWhatsapp = false,
            shareEmail = true,
            shareAddress = false,
            shareSocials = false,
            linkedInUrl = "https://linkedin.com/in/hidden"
        )

        val vcf = CardShareHelper.toVCardString(card)
        assertTrue(vcf.startsWith("BEGIN:VCARD\r\nVERSION:3.0\r\n"))
        assertTrue(vcf.endsWith("END:VCARD\r\n"))
        assertTrue(vcf.contains("FN:Md. Mazharul Islam\r\n"))
        assertTrue(vcf.contains("N:Islam;Md. Mazharul;;;\r\n"))
        assertTrue(vcf.contains("TITLE:AVP\\, Procurement\\; Archiving\r\n"))
        assertTrue(vcf.contains("TEL;TYPE=WORK,VOICE:+8801700000001\r\n"))
        assertTrue(vcf.contains("EMAIL;TYPE=WORK,INTERNET:work@ificbank.com\r\n"))
        // Excluded fields must NEVER appear in generated vCard
        assertFalse(vcf.contains("+8801700000002"))
        assertFalse(vcf.contains("IFIC Tower"))
        assertFalse(vcf.contains("linkedin.com"))
    }

    @Test
    fun vCardGenerator_preservesMixedBanglaAndEnglishUnicode() {
        val card = BusinessCardEntity(
            fullName = "মোঃ মাজহারুল ইসলাম",
            companyName = "আইএফআইসি ব্যাংক পিএলসি",
            phone = "+8801711111111",
            sharePhone = true
        )
        val vcf = CardShareHelper.toVCardString(card)
        assertTrue(vcf.contains("FN:মোঃ মাজহারুল ইসলাম"))
        assertTrue(vcf.contains("ORG:আইএফআইসি ব্যাংক পিএলসি"))
    }

    @Test
    fun meetingIcsGenerator_buildsValidRfc5545CalendarPayload() {
        val fu = FollowUpEntity(
            contactId = 42L,
            contactName = "Rahim Ahmed",
            companyName = "ABC Industries",
            title = "Vendor Contract Review",
            dueAtTimestamp = 1795500000000L,
            followUpType = "MEETING",
            meetingMethod = "TEAMS",
            meetingLink = "https://teams.microsoft.com/l/meetup-join/sample",
            meetingAgenda = "Review SLA, Pricing; Terms"
        )
        val ics = MeetingInviteHelper.generateIcsContent(fu, "Md. Mazharul Islam")
        assertTrue(ics.startsWith("BEGIN:VCALENDAR\r\nVERSION:2.0\r\n"))
        assertTrue(ics.contains("BEGIN:VEVENT\r\n"))
        assertTrue(ics.contains("SUMMARY:Vendor Contract Review\r\n"))
        assertTrue(ics.contains("URL:https://teams.microsoft.com/l/meetup-join/sample\r\n"))
        assertTrue(ics.contains("Review SLA\\, Pricing\\; Terms"))
        assertTrue(ics.endsWith("END:VCALENDAR\r\n"))
    }

    @Test
    fun meetingUrlValidation_rejectsNonHttpSchemes() {
        assertTrue(MeetingInviteHelper.isValidMeetingUrl(""))
        assertTrue(MeetingInviteHelper.isValidMeetingUrl("https://zoom.us/j/123456"))
        assertFalse(MeetingInviteHelper.isValidMeetingUrl("javascript:alert(1)"))
        assertFalse(MeetingInviteHelper.isValidMeetingUrl("file:///etc/passwd"))
    }
}
