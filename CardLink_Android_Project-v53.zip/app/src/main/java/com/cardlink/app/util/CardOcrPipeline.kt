package com.cardlink.app.util

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Patterns
import com.cardlink.app.data.model.SavedContactEntity
import com.google.mlkit.vision.text.Text
import java.text.Normalizer

enum class DetectedScript {
    BANGLA,
    ENGLISH,
    MIXED,
    NUMERIC
}

enum class FieldConfidence {
    CONFIDENT,
    NEEDS_REVIEW,
    MISSING
}

data class ImageQualityReport(
    val isAcceptable: Boolean,
    val warningTitle: String = "",
    val warningMessage: String = "",
    val sharpnessScore: Float = 1f,
    val glareFraction: Float = 0f,
    val meanLuma: Float = 128f
)

data class ExtractedContactReviewModel(
    val contact: SavedContactEntity,
    val fieldConfidences: Map<String, FieldConfidence>,
    val detectedScripts: Set<DetectedScript>,
    val missingRequiredHints: List<String>,
    val uncertainFieldKeys: List<String>
) {
    val isReadyToBatchSave: Boolean
        get() = contact.fullName.isNotBlank() &&
            contact.fullName != "Scanned Contact" &&
            (contact.phone.isNotBlank() || contact.email.isNotBlank()) &&
            uncertainFieldKeys.isEmpty()
}

object CardOcrPipeline {

    private val BANGLA_CHAR_REGEX = Regex("""[\u0980-\u09FF]""")
    private val LATIN_CHAR_REGEX = Regex("""[A-Za-z]""")
    private val PHONE_REGEX = Regex("""(?:\+?880|0)?1[3-9]\d[\s.-]?\d{2}[\s.-]?\d{5}|(?:\+?\d{1,4}[\s.-]?)?(?:\(?\d{2,5}\)?[\s.-]?)?\d{3,4}[\s.-]?\d{3,5}""")
    private val EMAIL_REGEX = Regex("""[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}""")

    private val EN_DESIGNATION_KEYWORDS = listOf(
        "chief", "ceo", "cto", "cfo", "coo", "president", "vice president", "vp", "svp", "evp",
        "director", "head", "manager", "lead", "engineer", "developer", "architect", "consultant",
        "analyst", "specialist", "officer", "coordinator", "executive", "partner", "founder",
        "professor", "lecturer", "advisor", "associate", "secretary", "chairman", "principal"
    )

    private val BN_DESIGNATION_KEYWORDS = listOf(
        "ব্যবস্থাপক", "পরিচালক", "অফিসার", "কর্মকর্তা", "নির্বাহী", "প্রধান", "সভাপতি",
        "অধ্যাপক", "প্রভাষক", "উপদেষ্টা", "প্রকৌশলী", "সচিব", "চেয়ারম্যান", "অধ্যক্ষ"
    )

    private val EN_COMPANY_KEYWORDS = listOf(
        "plc", "ltd", "limited", "inc", "corp", "corporation", "llc", "group",
        "bank", "technologies", "solutions", "systems", "enterprises", "global", "holdings",
        "associates", "agency", "studio", "labs", "ventures", "foundation", "institute", "college", "university"
    )

    private val BN_COMPANY_KEYWORDS = listOf(
        "লিমিটেড", "পিএলসি", "ব্যাংক", "গ্রুপ", "ইন্ডাস্ট্রিজ", "কর্পোরেশন", "প্রতিষ্ঠান",
        "ইনস্টিটিউট", "কলেজ", "বিশ্ববিদ্যালয়", "মন্ত্রণালয়", "অধিদপ্তর", "সংস্থা", "এন্টারপ্রাইজ"
    )

    private val DEPARTMENT_KEYWORDS = listOf(
        "department", "division", "unit", "procurement", "finance", "operations", "marketing",
        "sales", "human resources", "hr", "it", "technology", "legal", "strategy", "credit",
        "banking", "administration", "supply chain", "logistics", "engineering", "বিভাগ", "শাখা"
    )

    private val ADDRESS_KEYWORDS = listOf(
        "road", "rd", "street", "st", "avenue", "ave", "lane", "plot", "house", "building",
        "tower", "plaza", "floor", "level", "suite", "sector", "block", "area", "city",
        "dhaka", "po box", "zip", "highway", "bazar", "commercial", "gulshan", "motijheel", "banani",
        "রোড", "সড়ক", "ভবন", "টাওয়ার", "প্লাজা", "তলা", "সেক্টর", "ব্লক", "ঢাকা", "গুলশান", "মতিঝিল", "বনানী"
    )

    fun assessImageQuality(bitmap: Bitmap): ImageQualityReport {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 320 || h < 200) {
            return ImageQualityReport(
                isAcceptable = false,
                warningTitle = "Image Resolution Too Small",
                warningMessage = "Move closer so the business card fills the frame clearly."
            )
        }

        val stepX = (w / 96).coerceAtLeast(1)
        val stepY = (h / 64).coerceAtLeast(1)
        var totalSamples = 0
        var glarePixels = 0
        var lumaSum = 0.0
        var edgeDiffSum = 0.0

        var y = stepY
        while (y < h - stepY) {
            var x = stepX
            while (x < w - stepX) {
                val c = bitmap.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                val luma = 0.299 * r + 0.587 * g + 0.114 * b
                lumaSum += luma
                if (r > 246 && g > 246 && b > 246) glarePixels++

                val cRight = bitmap.getPixel(x + stepX, y)
                val lumaRight = 0.299 * Color.red(cRight) + 0.587 * Color.green(cRight) + 0.114 * Color.blue(cRight)
                edgeDiffSum += kotlin.math.abs(luma - lumaRight)
                totalSamples++
                x += stepX
            }
            y += stepY
        }

        if (totalSamples == 0) return ImageQualityReport(true)
        val meanLuma = (lumaSum / totalSamples).toFloat()
        val glareFrac = glarePixels.toFloat() / totalSamples.toFloat()
        val sharpness = (edgeDiffSum / totalSamples).toFloat()

        return when {
            meanLuma < 36f -> ImageQualityReport(
                isAcceptable = false,
                warningTitle = "Image May Be Too Dark",
                warningMessage = "Improve lighting or turn on flash so card text is readable.",
                sharpnessScore = sharpness,
                glareFraction = glareFrac,
                meanLuma = meanLuma
            )
            glareFrac > 0.42f -> ImageQualityReport(
                isAcceptable = false,
                warningTitle = "Glare Detected on Card",
                warningMessage = "Glare is covering part of the business card. Tilt the card slightly and try again.",
                sharpnessScore = sharpness,
                glareFraction = glareFrac,
                meanLuma = meanLuma
            )
            sharpness < 4.2f -> ImageQualityReport(
                isAcceptable = false,
                warningTitle = "Image May Be Blurry",
                warningMessage = "Hold steady and let the camera focus on the business card.",
                sharpnessScore = sharpness,
                glareFraction = glareFrac,
                meanLuma = meanLuma
            )
            else -> ImageQualityReport(
                isAcceptable = true,
                sharpnessScore = sharpness,
                glareFraction = glareFrac,
                meanLuma = meanLuma
            )
        }
    }

    fun normalizeUnicodeText(raw: String): String {
        val nfc = Normalizer.normalize(raw, Normalizer.Form.NFC)
        return nfc
            .replace("\u200B", "")
            .replace("\uFEFF", "")
            .replace(Regex("""[ \t]+"""), " ")
            .trim()
    }

    fun convertBanglaDigitsToAscii(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                '০' -> sb.append('0')
                '১' -> sb.append('1')
                '২' -> sb.append('2')
                '৩' -> sb.append('3')
                '৪' -> sb.append('4')
                '৫' -> sb.append('5')
                '৬' -> sb.append('6')
                '৭' -> sb.append('7')
                '৮' -> sb.append('8')
                '৯' -> sb.append('9')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun classifyScript(text: String): DetectedScript {
        val hasBn = BANGLA_CHAR_REGEX.containsMatchIn(text)
        val hasEn = LATIN_CHAR_REGEX.containsMatchIn(text)
        return when {
            hasBn && hasEn -> DetectedScript.MIXED
            hasBn -> DetectedScript.BANGLA
            hasEn -> DetectedScript.ENGLISH
            else -> DetectedScript.NUMERIC
        }
    }

    fun normalizeBangladeshPhone(raw: String): String {
        val ascii = convertBanglaDigitsToAscii(raw)
        val digits = ascii.filter { it.isDigit() }
        return when {
            digits.length == 11 && digits.startsWith("01") -> "+88$digits"
            digits.length == 13 && digits.startsWith("8801") -> "+$digits"
            digits.length == 10 && digits.startsWith("1") -> "+880$digits"
            else -> ascii.trim()
        }
    }

    fun extractContactWithConfidence(visionText: Text): ExtractedContactReviewModel {
        data class LineBox(
            val text: String,
            val asciiForDigits: String,
            val script: DetectedScript,
            val height: Int,
            val top: Int
        )

        val rawLines = visionText.textBlocks
            .flatMap { it.lines }
            .mapNotNull { line ->
                val clean = normalizeUnicodeText(line.text)
                if (clean.length < 2) null
                else LineBox(
                    text = clean,
                    asciiForDigits = convertBanglaDigitsToAscii(clean),
                    script = classifyScript(clean),
                    height = line.boundingBox?.height() ?: 0,
                    top = line.boundingBox?.top ?: Int.MAX_VALUE
                )
            }
            .sortedBy { it.top }

        val scriptsFound = rawLines.map { it.script }.toSet()
        val consumed = mutableSetOf<Int>()

        var email = ""
        var website = ""
        var linkedInUrl = ""
        val phones = mutableListOf<String>()
        var whatsapp = ""
        var designation = ""
        var companyName = ""
        var alternateCompany = ""
        var department = ""
        val addressLines = mutableListOf<String>()

        rawLines.forEachIndexed { idx, box ->
            val line = box.text
            val lower = line.lowercase()

            EMAIL_REGEX.find(box.asciiForDigits)?.let { m ->
                if (email.isEmpty()) {
                    email = m.value.lowercase()
                    consumed.add(idx)
                }
            }

            for (word in box.asciiForDigits.split(Regex("""\s+"""))) {
                val cleaned = word.trim(',', ';', '|')
                if (!cleaned.contains("@") && Patterns.WEB_URL.matcher(cleaned).matches()) {
                    when {
                        cleaned.contains("linkedin.com", true) -> linkedInUrl = cleaned
                        website.isEmpty() -> website = if (cleaned.startsWith("http", true)) cleaned else "https://$cleaned"
                    }
                    consumed.add(idx)
                }
            }

            PHONE_REGEX.findAll(box.asciiForDigits).forEach { m ->
                val digitsOnly = m.value.filter { it.isDigit() || it == '+' }
                if (digitsOnly.count { it.isDigit() } in 7..15) {
                    val formatted = m.value.trim()
                    if (lower.contains("whatsapp") || lower.contains("wa:") || lower.contains("হোয়াটসঅ্যাপ")) {
                        whatsapp = formatted
                    } else if (!phones.contains(formatted)) {
                        phones.add(formatted)
                    }
                    consumed.add(idx)
                }
            }
        }

        rawLines.forEachIndexed { idx, box ->
            if (idx in consumed) return@forEachIndexed
            val line = box.text
            val lower = line.lowercase()

            if (department.isEmpty() && DEPARTMENT_KEYWORDS.any { lower.contains(it) || line.contains(it) } &&
                !EN_COMPANY_KEYWORDS.any { lower.contains(it) } &&
                !BN_COMPANY_KEYWORDS.any { line.contains(it) }
            ) {
                department = line
                consumed.add(idx)
                return@forEachIndexed
            }

            if (designation.isEmpty() && (EN_DESIGNATION_KEYWORDS.any { lower.contains(it) } || BN_DESIGNATION_KEYWORDS.any { line.contains(it) })) {
                designation = line
                consumed.add(idx)
                return@forEachIndexed
            }

            val isCompany = EN_COMPANY_KEYWORDS.any { lower.contains(it) } || BN_COMPANY_KEYWORDS.any { line.contains(it) }
            if (isCompany) {
                if (companyName.isEmpty()) {
                    companyName = line
                } else if (alternateCompany.isEmpty() && classifyScript(line) != classifyScript(companyName)) {
                    alternateCompany = line
                }
                consumed.add(idx)
                return@forEachIndexed
            }

            if (ADDRESS_KEYWORDS.any { lower.contains(it) || line.contains(it) } || (line.contains(",") && box.asciiForDigits.any { it.isDigit() })) {
                addressLines.add(line)
                consumed.add(idx)
            }
        }

        val nameCandidates = rawLines.filterIndexed { idx, box ->
            idx !in consumed && box.asciiForDigits.count { it.isDigit() } == 0 && box.text.split(" ").size in 1..6
        }
        val primaryNameBox = nameCandidates.maxByOrNull { it.height } ?: nameCandidates.firstOrNull()
        val fullName = primaryNameBox?.text.orEmpty()
        val altName = nameCandidates
            .firstOrNull { it.text != fullName && it.script != primaryNameBox?.script }
            ?.text.orEmpty()

        if (companyName.isEmpty()) {
            companyName = nameCandidates.firstOrNull { it.text != fullName && it.text != altName }?.text.orEmpty()
        }

        val primaryPhone = phones.firstOrNull().orEmpty()
        val secondaryPhone = whatsapp.ifEmpty { phones.getOrNull(1).orEmpty() }
        val resolvedFullName = fullName.ifBlank { "Scanned Contact" }

        val contact = SavedContactEntity(
            fullName = resolvedFullName,
            alternateName = altName,
            designation = designation,
            companyName = companyName,
            alternateCompany = alternateCompany,
            department = department,
            phone = primaryPhone,
            whatsapp = secondaryPhone,
            email = email,
            officeAddress = addressLines.joinToString(", "),
            website = website,
            linkedInUrl = linkedInUrl,
            notes = "",
            rawOcrText = normalizeUnicodeText(visionText.text),
            receivedVia = if (DetectedScript.BANGLA in scriptsFound || DetectedScript.MIXED in scriptsFound) {
                "Bangla-English OCR"
            } else {
                "OCR Scan"
            }
        )

        val confMap = linkedMapOf<String, FieldConfidence>()
        confMap["fullName"] = when {
            resolvedFullName == "Scanned Contact" || resolvedFullName.length < 3 -> FieldConfidence.NEEDS_REVIEW
            else -> FieldConfidence.CONFIDENT
        }
        confMap["designation"] = when {
            designation.isBlank() -> FieldConfidence.MISSING
            designation.length < 3 -> FieldConfidence.NEEDS_REVIEW
            else -> FieldConfidence.CONFIDENT
        }
        confMap["companyName"] = when {
            companyName.isBlank() -> FieldConfidence.MISSING
            companyName.length < 3 -> FieldConfidence.NEEDS_REVIEW
            else -> FieldConfidence.CONFIDENT
        }
        confMap["phone"] = when {
            primaryPhone.isBlank() -> FieldConfidence.MISSING
            normalizeBangladeshPhone(primaryPhone).count { it.isDigit() } < 8 -> FieldConfidence.NEEDS_REVIEW
            else -> FieldConfidence.CONFIDENT
        }
        confMap["email"] = when {
            email.isBlank() -> FieldConfidence.MISSING
            !EMAIL_REGEX.matches(email) -> FieldConfidence.NEEDS_REVIEW
            else -> FieldConfidence.CONFIDENT
        }

        val uncertain = confMap.filterValues { it == FieldConfidence.NEEDS_REVIEW }.keys.toList()
        val missing = confMap.filterValues { it == FieldConfidence.MISSING }.keys.toList()

        return ExtractedContactReviewModel(
            contact = contact,
            fieldConfidences = confMap,
            detectedScripts = scriptsFound,
            missingRequiredHints = missing,
            uncertainFieldKeys = uncertain
        )
    }
}
