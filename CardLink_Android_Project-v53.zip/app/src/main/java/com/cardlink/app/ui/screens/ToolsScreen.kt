package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ToolsScreen(
    activeCard: BusinessCardEntity,
    eventMode: EventModeConfig,
    favoriteToolIds: List<String>,
    recentToolIds: List<String>,
    onToggleFavoriteTool: (String) -> Boolean,
    onMoveFavoriteTool: (String, Int) -> Unit,
    onLaunchCanonicalTool: (CanonicalToolMeta) -> Unit,
    onLogShare: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showWallpaperConfirmDialog by remember { mutableStateOf(false) }
    var isApplyingWallpaper by remember { mutableStateOf(false) }

    val hideSensitive = remember { SecurityHardeningManager.isSensitiveAreaHidden(context) }
    val visibleTools = remember(hideSensitive) {
        ToolsRegistry.all.filter { !hideSensitive || !it.isSensitive }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(stringResource(R.string.tools_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.tools_subtitle), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }

        // 0.5 PERSONALIZED SUGGESTION (Local-only usage frequency; user decides!)
        var suggestionDismissTick by remember { mutableIntStateOf(0) }
        val suggestedToolMeta = remember(favoriteToolIds, recentToolIds, suggestionDismissTick, hideSensitive) {
            UxExperiencePrefs.getSuggestedFavoriteToolId(context, favoriteToolIds, hideSensitive)
                ?.let { ToolsRegistry.findById(it) }
        }
        if (suggestedToolMeta != null) {
            val sugName = stringResource(suggestedToolMeta.titleRes)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.suggested_for_you_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    }
                    Text(
                        text = stringResource(R.string.suggested_tool_msg, sugName),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            UxExperiencePrefs.dismissToolSuggestion(context, suggestedToolMeta.id)
                            suggestionDismissTick++
                        }) { Text(stringResource(R.string.qa_not_now_btn), fontSize = 12.sp) }
                        Button(onClick = {
                            onToggleFavoriteTool(suggestedToolMeta.id)
                            suggestionDismissTick++
                            Toast.makeText(context, context.getString(R.string.tools_added_favorite), Toast.LENGTH_SHORT).show()
                        }) { Text(stringResource(R.string.suggested_add_favorite), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        // 1. FAVORITES (Single source of truth synced live with My Card + Quick Tools)
        val favTools = favoriteToolIds.mapNotNull { id -> visibleTools.firstOrNull { it.id == id } }
        if (favTools.isNotEmpty()) {
            ToolsSectionHeader("${stringResource(R.string.ux_tools_favorites)} (${favTools.size}/4)")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                favTools.forEachIndexed { idx, tool ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onLaunchCanonicalTool(tool) },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(tool.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = stringResource(tool.titleRes),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (idx > 0) {
                                IconButton(onClick = { onMoveFavoriteTool(tool.id, -1) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move up", modifier = Modifier.size(18.dp))
                                }
                            }
                            if (idx < favTools.lastIndex) {
                                IconButton(onClick = { onMoveFavoriteTool(tool.id, 1) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move down", modifier = Modifier.size(18.dp))
                                }
                            }
                            IconButton(
                                onClick = {
                                    onToggleFavoriteTool(tool.id)
                                    Toast.makeText(context, context.getString(R.string.tools_removed_favorite), Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = "Remove from Favorites", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // 2. RECENTLY USED
        val recentTools = recentToolIds.mapNotNull { id -> visibleTools.firstOrNull { it.id == id } }
        if (recentTools.isNotEmpty()) {
            ToolsSectionHeader(stringResource(R.string.ux_tools_recent))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                recentTools.forEach { t ->
                    AssistChip(
                        onClick = { onLaunchCanonicalTool(t) },
                        leadingIcon = { Icon(Icons.Default.History, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp)) },
                        label = { Text(stringResource(t.titleRes), fontSize = 12.sp) }
                    )
                }
            }
        }

        // 3. CATEGORIZED TOOLS
        val categories = listOf("Scan & Create", "Secure Wallet", "Share & Personalize")
        categories.forEach { cat ->
            val itemsInCat = visibleTools.filter { it.category == cat }
            if (itemsInCat.isNotEmpty()) {
                ToolsSectionHeader(cat)
                itemsInCat.forEach { tool ->
                    val isFav = tool.id in favoriteToolIds
                    val title = if (tool.id == "event_mode" && eventMode.isActive) {
                        "${stringResource(R.string.home_event_mode_on)} ${eventMode.eventName}"
                    } else stringResource(tool.titleRes)
                    ToolItemCard(
                        icon = tool.icon,
                        title = title,
                        subtitle = stringResource(tool.subtitleRes),
                        highlighted = tool.id == "event_mode" && eventMode.isActive,
                        isFavorite = isFav,
                        onToggleFavorite = {
                            val ok = onToggleFavoriteTool(tool.id)
                            val msg = when {
                                !ok -> "You can pin up to 4 favorite tools."
                                isFav -> context.getString(R.string.tools_removed_favorite)
                                else -> context.getString(R.string.tools_added_favorite)
                            }
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        },
                        onClick = { onLaunchCanonicalTool(tool) }
                    )
                }
            }
        }

        // Additional Export & Utility Cards
        ToolItemCard(
            icon = Icons.Default.Print,
            title = stringResource(R.string.tools_print_pdf),
            subtitle = stringResource(R.string.tools_print_pdf_sub),
            showStar = false,
            onClick = {
                onLogShare("Print-Ready PDF (3.5x2)")
                CardShareHelper.sharePrintReadyPhysicalCardPdf(context, activeCard)
            }
        )

        ToolItemCard(
            icon = Icons.Default.Draw,
            title = stringResource(R.string.tools_email_sig),
            subtitle = stringResource(R.string.tools_email_sig_sub),
            showStar = false,
            onClick = { PremiumExtrasHelper.copyEmailSignatureToClipboard(context, activeCard) }
        )

        // Lock-Screen QR Wallpaper
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(modifier = Modifier.size(42.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Wallpaper, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(stringResource(R.string.tools_lock_wallpaper), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(stringResource(R.string.tools_lock_wallpaper_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = true },
                        enabled = !isApplyingWallpaper,
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.share_set_wallpaper), fontSize = 12.sp) }

                    OutlinedButton(
                        onClick = { PremiumExtrasHelper.shareLockScreenWallpaper(context, activeCard) },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.share_wallpaper), fontSize = 12.sp) }
                }
            }
        }
    }

    if (showWallpaperConfirmDialog) {
        AlertDialog(
            onDismissRequest = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = false },
            title = { Text(stringResource(R.string.wallpaper_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.wallpaper_confirm_msg)) },
            confirmButton = {
                Button(
                    enabled = !isApplyingWallpaper,
                    onClick = {
                        if (isApplyingWallpaper) return@Button
                        isApplyingWallpaper = true
                        showWallpaperConfirmDialog = false
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) {
                                PremiumExtrasHelper.applyLockScreenWallpaper(context, activeCard)
                            }
                            isApplyingWallpaper = false
                            Toast.makeText(
                                context,
                                if (ok) context.getString(R.string.wallpaper_set_success)
                                else context.getString(R.string.wallpaper_set_failed),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                ) { Text(stringResource(R.string.wallpaper_confirm_action)) }
            },
            dismissButton = {
                TextButton(enabled = !isApplyingWallpaper, onClick = { showWallpaperConfirmDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun ToolsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun ToolItemCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    highlighted: Boolean = false,
    showStar: Boolean = true,
    isFavorite: Boolean = false,
    onToggleFavorite: () -> Unit = {},
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = if (highlighted) BorderStroke(1.2.dp, MaterialTheme.colorScheme.tertiary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = if (highlighted) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = if (highlighted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }
            if (showStar) {
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = if (isFavorite) "Remove from Favorites" else "Add to Favorites",
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
    }
}
