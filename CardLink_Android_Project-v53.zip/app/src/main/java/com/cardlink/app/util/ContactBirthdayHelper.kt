package com.cardlink.app.util

import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class BirthdayInfo(
    val isoDate: String,
    val formattedDate: String,
    val ageYears: Int,
    val daysUntilNextBirthday: Int
) {
    val isBirthdaySoon: Boolean
        get() = daysUntilNextBirthday in 0..30
}

object ContactBirthdayHelper {

    private val DISPLAY_FMT = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH)

    /**
     * Parses ISO YYYY-MM-DD and dynamically computes current age by checking whether
     * the contact's birthday has already occurred in the current calendar year.
     * Never stores age as static data. Rejects impossible future dates.
     */
    fun computeBirthdayInfo(dobIso: String?, today: LocalDate = LocalDate.now()): BirthdayInfo? {
        if (dobIso.isNullOrBlank()) return null
        val dob = runCatching { LocalDate.parse(dobIso.trim()) }.getOrNull() ?: return null
        if (dob.isAfter(today)) return null

        var age = today.year - dob.year
        val hadBirthdayThisYear = (today.monthValue > dob.monthValue) ||
            (today.monthValue == dob.monthValue && today.dayOfMonth >= dob.dayOfMonth)
        if (!hadBirthdayThisYear) {
            age -= 1
        }
        if (age < 0) return null

        // Next birthday (handles Feb 29 safely via LocalDate.withYear)
        var nextBday = runCatching { dob.withYear(today.year) }.getOrElse {
            LocalDate.of(today.year, 2, 28)
        }
        if (nextBday.isBefore(today)) {
            nextBday = runCatching { dob.withYear(today.year + 1) }.getOrElse {
                LocalDate.of(today.year + 1, 2, 28)
            }
        }
        val daysUntil = ChronoUnit.DAYS.between(today, nextBday).toInt().coerceAtLeast(0)

        return BirthdayInfo(
            isoDate = dob.toString(),
            formattedDate = dob.format(DISPLAY_FMT),
            ageYears = age,
            daysUntilNextBirthday = daysUntil
        )
    }

    fun millisToIsoDate(epochMillis: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return fmt.format(java.util.Date(epochMillis))
    }

    fun isoDateToMillis(dobIso: String?): Long? {
        if (dobIso.isNullOrBlank()) return null
        return runCatching {
            val ld = LocalDate.parse(dobIso.trim())
            ld.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
        }.getOrNull()
    }
}
