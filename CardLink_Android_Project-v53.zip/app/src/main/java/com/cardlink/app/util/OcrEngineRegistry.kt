package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

enum class OcrRecognitionTier(val id: String) {
    BALANCED("BALANCED"),
    HIGHER_ACCURACY("HIGHER_ACCURACY")
}

data class OcrEngineCapabilities(
    val engineId: String,
    val displayName: String,
    val supportsLatinOffline: Boolean,
    val supportsBanglaNativeModel: Boolean,
    val statusSummary: String
)

/**
 * Pluggable On-Device OCR Provider boundary.
 * Allows plugging in a verified offline Bangla model (e.g. Tesseract 5.5 / ONNX PP-OCR)
 * without touching scanner UI, parser, or contact persistence.
 */
interface CardOcrEngineProvider {
    val capabilities: OcrEngineCapabilities
    suspend fun recognize(bitmap: Bitmap, tier: OcrRecognitionTier): Text
}

class MlKitTextRecognitionProvider : CardOcrEngineProvider {
    override val capabilities = OcrEngineCapabilities(
        engineId = "mlkit_latin_v2",
        displayName = "On-Device ML Kit Text Recognition",
        supportsLatinOffline = true,
        supportsBanglaNativeModel = false,
        statusSummary = "Latin OCR active offline • Bangla script parser active (native Bangla model pack optional)"
    )

    override suspend fun recognize(bitmap: Bitmap, tier: OcrRecognitionTier): Text = withContext(Dispatchers.IO) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val primary = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
            if (tier == OcrRecognitionTier.HIGHER_ACCURACY && primary.text.trim().length < 18) {
                // Low-yield retry pass with mild grayscale contrast boost & OOM protection
                val enhanced = runCatching { createContrastEnhancedCopy(bitmap) }.getOrNull()
                if (enhanced != null) {
                    try {
                        val secondary = recognizer.process(InputImage.fromBitmap(enhanced, 0)).await()
                        if (secondary.text.trim().length > primary.text.trim().length) {
                            return@withContext secondary
                        }
                    } finally {
                        if (enhanced !== bitmap) enhanced.recycle()
                    }
                }
            }
            primary
        } finally {
            runCatching { recognizer.close() }
        }
    }

    private fun createContrastEnhancedCopy(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val cm = ColorMatrix().apply {
            setSaturation(0f)
            val c = 1.25f
            val t = (-0.5f * c + 0.5f) * 255f
            postConcat(
                ColorMatrix(
                    floatArrayOf(
                        c, 0f, 0f, 0f, t,
                        0f, c, 0f, 0f, t,
                        0f, 0f, c, 0f, t,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }
}

object OcrEngineRegistry {
    private const val PREFS = "cardlink_ocr_engine_prefs"
    private const val KEY_TIER = "ocr_quality_tier"

    @Volatile
    private var activeProvider: CardOcrEngineProvider = MlKitTextRecognitionProvider()

    fun registerProvider(provider: CardOcrEngineProvider) {
        activeProvider = provider
    }

    fun getCapabilities(): OcrEngineCapabilities = activeProvider.capabilities

    fun getQualityTier(context: Context): OcrRecognitionTier {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TIER, OcrRecognitionTier.BALANCED.id)
        return OcrRecognitionTier.values().firstOrNull { it.id == raw } ?: OcrRecognitionTier.BALANCED
    }

    fun setQualityTier(context: Context, tier: OcrRecognitionTier) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TIER, tier.id).apply()
    }

    suspend fun recognizeBitmap(context: Context, bitmap: Bitmap): Text {
        val tier = getQualityTier(context)
        return try {
            activeProvider.recognize(bitmap, tier)
        } catch (_: OutOfMemoryError) {
            // Safe low-memory fallback to Balanced tier
            activeProvider.recognize(bitmap, OcrRecognitionTier.BALANCED)
        }
    }
}

/**
 * Pure JVM OCR quality metrics (ISO/IEC 25010 functional accuracy evaluation):
 * Computes Character Error Rate (CER) and Word Error Rate (WER) via Levenshtein edit distance.
 */
object OcrBenchmarkEvaluator {

    fun levenshteinDistance(a: List<String>, b: List<String>): Int {
        if (a.isEmpty()) return b.size
        if (b.isEmpty()) return a.size
        var prev = IntArray(b.size + 1) { it }
        var curr = IntArray(b.size + 1)
        for (i in 1..a.lengthOrSize()) {
            curr[0] = i
            for (j in 1..b.size) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                curr[j] = minOf(
                    prev[j] + 1,
                    curr[j - 1] + 1,
                    prev[j - 1] + cost
                )
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[b.size]
    }

    private fun <T> List<T>.lengthOrSize(): Int = this.size

    fun characterErrorRate(reference: String, hypothesis: String): Double {
        val refChars = reference.trim().map { it.toString() }
        val hypChars = hypothesis.trim().map { it.toString() }
        if (refChars.isEmpty()) return if (hypChars.isEmpty()) 0.0 else 1.0
        return levenshteinDistance(refChars, hypChars).toDouble() / refChars.size.toDouble()
    }

    fun wordErrorRate(reference: String, hypothesis: String): Double {
        val refWords = reference.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val hypWords = hypothesis.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (refWords.isEmpty()) return if (hypWords.isEmpty()) 0.0 else 1.0
        return levenshteinDistance(refWords, hypWords).toDouble() / refWords.size.toDouble()
    }
}
