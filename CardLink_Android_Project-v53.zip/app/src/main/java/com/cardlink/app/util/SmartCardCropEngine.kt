package com.cardlink.app.util

import android.graphics.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.hypot

@Serializable
data class CardCropMetadata(
    val topLeftX: Float = 0.04f,
    val topLeftY: Float = 0.04f,
    val topRightX: Float = 0.96f,
    val topRightY: Float = 0.04f,
    val bottomRightX: Float = 0.96f,
    val bottomRightY: Float = 0.96f,
    val bottomLeftX: Float = 0.04f,
    val bottomLeftY: Float = 0.96f,
    val rotationDegrees: Int = 0,
    val enhanceReadability: Boolean = true,
    val isOriginalFullFrame: Boolean = false
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

        fun fullOriginal(rotationDegrees: Int = 0): CardCropMetadata = CardCropMetadata(
            topLeftX = 0f, topLeftY = 0f,
            topRightX = 1f, topRightY = 0f,
            bottomRightX = 1f, bottomRightY = 1f,
            bottomLeftX = 0f, bottomLeftY = 1f,
            rotationDegrees = rotationDegrees,
            enhanceReadability = false,
            isOriginalFullFrame = true
        )

        fun toJson(meta: CardCropMetadata): String =
            runCatching { json.encodeToString(serializer(), meta) }.getOrDefault("")

        fun fromJson(raw: String?): CardCropMetadata? {
            if (raw.isNullOrBlank()) return null
            return runCatching { json.decodeFromString(serializer(), raw) }.getOrNull()
        }
    }
}

object SmartCardCropEngine {

    /**
     * Automatically detects likely business-card edges by comparing border background luminance
     * against interior luminance/color gradients. Falls back gracefully to a safe standard card inset
     * when the card blends closely with the background.
     */
    fun detectAutoCrop(source: Bitmap): CardCropMetadata {
        val w = source.width
        val h = source.height
        if (w < 80 || h < 80) return CardCropMetadata.fullOriginal()

        return runCatching {
            val sampleW = 160
            val sampleH = ((h.toFloat() / w.toFloat()) * sampleW).toInt().coerceIn(80, 240)
            val thumb = Bitmap.createScaledBitmap(source, sampleW, sampleH, true)

            fun pixelLuma(x: Int, y: Int): Float {
                val c = thumb.getPixel(x.coerceIn(0, sampleW - 1), y.coerceIn(0, sampleH - 1))
                return 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
            }

            // Estimate background luminance from outer 4 corner patches
            var bgSum = 0f
            var bgCnt = 0
            for (dy in 0 until 6) {
                for (dx in 0 until 6) {
                    bgSum += pixelLuma(dx, dy)
                    bgSum += pixelLuma(sampleW - 1 - dx, dy)
                    bgSum += pixelLuma(dx, sampleH - 1 - dy)
                    bgSum += pixelLuma(sampleW - 1 - dx, sampleH - 1 - dy)
                    bgCnt += 4
                }
            }
            val bgLuma = bgSum / bgCnt.coerceAtLeast(1)

            // Scan inward from each edge for consistent contrast transition
            val threshold = 22f
            var left = 0
            for (x in 2 until (sampleW * 0.35f).toInt()) {
                var diffCount = 0
                for (y in (sampleH * 0.2f).toInt() until (sampleH * 0.8f).toInt() step 3) {
                    if (abs(pixelLuma(x, y) - bgLuma) > threshold) diffCount++
                }
                if (diffCount > sampleH / 12) { left = x; break }
            }

            var right = sampleW - 1
            for (x in (sampleW - 3) downTo (sampleW * 0.65f).toInt()) {
                var diffCount = 0
                for (y in (sampleH * 0.2f).toInt() until (sampleH * 0.8f).toInt() step 3) {
                    if (abs(pixelLuma(x, y) - bgLuma) > threshold) diffCount++
                }
                if (diffCount > sampleH / 12) { right = x; break }
            }

            var top = 0
            for (y in 2 until (sampleH * 0.35f).toInt()) {
                var diffCount = 0
                for (x in (sampleW * 0.2f).toInt() until (sampleW * 0.8f).toInt() step 3) {
                    if (abs(pixelLuma(x, y) - bgLuma) > threshold) diffCount++
                }
                if (diffCount > sampleW / 12) { top = y; break }
            }

            var bottom = sampleH - 1
            for (y in (sampleH - 3) downTo (sampleH * 0.65f).toInt()) {
                var diffCount = 0
                for (x in (sampleW * 0.2f).toInt() until (sampleW * 0.8f).toInt() step 3) {
                    if (abs(pixelLuma(x, y) - bgLuma) > threshold) diffCount++
                }
                if (diffCount > sampleW / 12) { bottom = y; break }
            }

            thumb.recycle()

            val lFrac = (left.toFloat() / sampleW).coerceIn(0.01f, 0.32f)
            val rFrac = (right.toFloat() / sampleW).coerceIn(0.68f, 0.99f)
            val tFrac = (top.toFloat() / sampleH).coerceIn(0.01f, 0.32f)
            val bFrac = (bottom.toFloat() / sampleH).coerceIn(0.68f, 0.99f)

            val spanW = rFrac - lFrac
            val spanH = bFrac - tFrac
            if (spanW < 0.35f || spanH < 0.35f) {
                CardCropMetadata()
            } else {
                CardCropMetadata(
                    topLeftX = lFrac, topLeftY = tFrac,
                    topRightX = rFrac, topRightY = tFrac,
                    bottomRightX = rFrac, bottomRightY = bFrac,
                    bottomLeftX = lFrac, bottomLeftY = bFrac,
                    rotationDegrees = 0,
                    enhanceReadability = true,
                    isOriginalFullFrame = false
                )
            }
        }.getOrDefault(CardCropMetadata())
    }

    /**
     * Applies non-destructive rotation, 4-point perspective rectification (Matrix.setPolyToPoly),
     * and optional mild contrast normalization to produce a clean business card bitmap.
     */
    fun applyCropAndPerspective(source: Bitmap, meta: CardCropMetadata): Bitmap {
        val rotated = if (meta.rotationDegrees % 360 != 0) {
            val m = Matrix().apply { postRotate((meta.rotationDegrees % 360).toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, m, true)
        } else {
            source
        }

        if (meta.isOriginalFullFrame) {
            return rotated
        }

        val w = rotated.width.toFloat()
        val h = rotated.height.toFloat()

        val srcPts = floatArrayOf(
            meta.topLeftX.coerceIn(0f, 1f) * w, meta.topLeftY.coerceIn(0f, 1f) * h,
            meta.topRightX.coerceIn(0f, 1f) * w, meta.topRightY.coerceIn(0f, 1f) * h,
            meta.bottomRightX.coerceIn(0f, 1f) * w, meta.bottomRightY.coerceIn(0f, 1f) * h,
            meta.bottomLeftX.coerceIn(0f, 1f) * w, meta.bottomLeftY.coerceIn(0f, 1f) * h
        )

        val topWidth = hypot((srcPts[2] - srcPts[0]).toDouble(), (srcPts[3] - srcPts[1]).toDouble()).toFloat()
        val bottomWidth = hypot((srcPts[4] - srcPts[6]).toDouble(), (srcPts[5] - srcPts[7]).toDouble()).toFloat()
        val leftHeight = hypot((srcPts[6] - srcPts[0]).toDouble(), (srcPts[7] - srcPts[1]).toDouble()).toFloat()
        val rightHeight = hypot((srcPts[4] - srcPts[2]).toDouble(), (srcPts[5] - srcPts[3]).toDouble()).toFloat()

        val outW = maxOf(topWidth, bottomWidth).toInt().coerceIn(320, 1800)
        val outH = maxOf(leftHeight, rightHeight).toInt().coerceIn(200, 1800)

        val dstPts = floatArrayOf(
            0f, 0f,
            outW.toFloat(), 0f,
            outW.toFloat(), outH.toFloat(),
            0f, outH.toFloat()
        )

        val polyMatrix = Matrix()
        val mapped = polyMatrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)
        if (!mapped) {
            return rotated
        }

        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (meta.enhanceReadability) {
            // Mild readability contrast boost (1.07x) without distorting text or colors
            val contrast = 1.07f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            paint.colorFilter = ColorMatrixColorFilter(
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        canvas.drawBitmap(rotated, polyMatrix, paint)
        if (rotated !== source) rotated.recycle()
        return output
    }
}
