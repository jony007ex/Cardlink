package com.cardlink.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cardlink.app.R

/**
 * Two compact reactive summary cards placed immediately above Search on My Contacts:
 * [ Total Contacts ]  |  [ Favorites ]
 */
@Composable
fun ContactsSummaryCardsRow(
    totalCount: Int,
    favoriteCount: Int,
    isFavoritesFilterActive: Boolean,
    onSelectAll: () -> Unit,
    onSelectFavorites: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CompactContactStatCard(
            icon = Icons.Default.People,
            count = totalCount,
            label = stringResource(R.string.contacts_total_label),
            isSelected = !isFavoritesFilterActive,
            onClick = onSelectAll,
            modifier = Modifier.weight(1f)
        )
        CompactContactStatCard(
            icon = Icons.Default.Star,
            count = favoriteCount,
            label = stringResource(R.string.contacts_favorites_label),
            isSelected = isFavoritesFilterActive,
            onClick = onSelectFavorites,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun CompactContactStatCard(
    icon: ImageVector,
    count: Int,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.28f)
    val bgColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f) else MaterialTheme.colorScheme.surface

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .semantics {
                role = Role.Button
                selected = isSelected
                contentDescription = "$label: $count"
                stateDescription = if (isSelected) "Active filter" else "Tap to filter"
            }
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Interactive Tap-to-Flip Business Card viewer for Contact Detail.
 * - Reuses CardLink's 480ms 3D rotationY flip interaction when both Front and Back images exist.
 * - Renders a clean single card with zero flip behavior when only one side exists.
 * - Includes screen-reader CustomAccessibilityAction ("Show Back Side" / "Show Front Side").
 */
@Composable
fun FlippableContactCardViewer(
    frontUri: String?,
    backUri: String?,
    contactName: String,
    onOpenFullScreen: () -> Unit,
    onAdjustCrop: ((isBackSide: Boolean) -> Unit)? = null
) {
    val hasFront = !frontUri.isNullOrBlank()
    val hasBack = !backUri.isNullOrBlank()
    if (!hasFront && !hasBack) return

    val hasBothSides = hasFront && hasBack
    val haptic = LocalHapticFeedback.current
    var showBack by remember(frontUri, backUri) { mutableStateOf(false) }

    val rotation by animateFloatAsState(
        targetValue = if (hasBothSides && showBack) 180f else 0f,
        animationSpec = tween(durationMillis = 460),
        label = "contact_card_flip"
    )

    val flipLabel = if (showBack) stringResource(R.string.tpl_show_front) else stringResource(R.string.tpl_show_back)
    val sideBadge = if (hasBothSides && rotation > 90f) stringResource(R.string.card_side_back) else stringResource(R.string.card_side_front)

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.586f)
                .clip(RoundedCornerShape(16.dp))
                .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                .then(
                    if (hasBothSides) {
                        Modifier
                            .semantics {
                                contentDescription = "$contactName business card, showing $sideBadge"
                                customActions = listOf(
                                    CustomAccessibilityAction(flipLabel) {
                                        showBack = !showBack
                                        true
                                    }
                                )
                            }
                            .clickable(role = Role.Button) {
                                showBack = !showBack
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                            .graphicsLayer {
                                rotationY = rotation
                                cameraDistance = 14f * density
                            }
                    } else {
                        Modifier.clickable(onClick = onOpenFullScreen)
                    }
                )
        ) {
            if (!hasBothSides || rotation <= 90f) {
                VaultImage(
                    uriString = frontUri ?: backUri,
                    contentDescription = "$contactName card front",
                    contentScale = ContentScale.Crop,
                    maxEdgePx = 1024,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                VaultImage(
                    uriString = backUri,
                    contentDescription = "$contactName card back",
                    contentScale = ContentScale.Crop,
                    maxEdgePx = 1024,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationY = 180f }
                )
            }

            // Subtle FRONT / BACK state pill overlay
            if (hasBothSides) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .graphicsLayer { if (rotation > 90f) rotationY = 180f }
                ) {
                    Text(
                        text = sideBadge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Helper hint + compact View Full Screen action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (hasBothSides) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                    Text(
                        text = stringResource(R.string.tpl_tap_to_flip_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Spacer(Modifier.width(1.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onAdjustCrop != null) {
                    TextButton(
                        onClick = { onAdjustCrop(hasBothSides && showBack) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 36.dp)
                    ) {
                        Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.crop_adjust_title), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                TextButton(
                    onClick = onOpenFullScreen,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.heightIn(min = 36.dp)
                ) {
                    Icon(Icons.Default.ZoomOutMap, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.card_view_fullscreen), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Full-screen zoomable, pannable & flippable Business Card viewer with zero edit/delete clutter.
 */
@Composable
fun FullScreenContactCardDialog(
    frontUri: String?,
    backUri: String?,
    contactName: String,
    onDismiss: () -> Unit
) {
    val hasBothSides = !frontUri.isNullOrBlank() && !backUri.isNullOrBlank()
    var showBack by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 4f)
                        offset = if (scale > 1f) offset + pan else Offset.Zero
                    }
                }
        ) {
            val activeUri = if (hasBothSides && showBack) backUri else frontUri ?: backUri
            VaultImage(
                uriString = activeUri,
                contentDescription = contactName,
                contentScale = ContentScale.Fit,
                maxEdgePx = 2048,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    }
                    .then(
                        if (hasBothSides) Modifier.clickable { showBack = !showBack } else Modifier
                    )
            )

            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (hasBothSides) "$contactName (${if (showBack) "Back" else "Front"})" else contactName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White)
                }
            }
        }
    }
}

/**
 * Filter & Sort Bottom Sheet for Contacts (Relationship, Source, Favorites, Birthday Soon, Nearby, Sort).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsFilterAndSortSheet(
    selectedTag: String,
    selectedSource: String,
    onlyFavorites: Boolean,
    onlyBirthdaySoon: Boolean,
    selectedSort: String,
    onApply: (tag: String, source: String, favOnly: Boolean, bdaySoon: Boolean, sort: String) -> Unit,
    onDismiss: () -> Unit
) {
    var draftTag by remember { mutableStateOf(selectedTag) }
    var draftSource by remember { mutableStateOf(selectedSource) }
    var draftFav by remember { mutableStateOf(onlyFavorites) }
    var draftBday by remember { mutableStateOf(onlyBirthdaySoon) }
    var draftSort by remember { mutableStateOf(selectedSort) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.contacts_filter_sort_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            Text(stringResource(R.string.cdash_quick_filters), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = draftFav, onClick = { draftFav = !draftFav }, label = { Text(stringResource(R.string.contacts_favorites_label), fontSize = 11.5.sp) })
                FilterChip(selected = draftBday, onClick = { draftBday = !draftBday }, label = { Text(stringResource(R.string.contacts_birthday_soon), fontSize = 11.5.sp) })
                FilterChip(selected = draftTag == "Nearby (<5 km)", onClick = { draftTag = if (draftTag == "Nearby (<5 km)") "All" else "Nearby (<5 km)" }, label = { Text(stringResource(R.string.cdash_nearby_chip), fontSize = 11.5.sp) })
            }

            Text(stringResource(R.string.cdash_relationship), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "Client", "Vendor", "Colleague", "VIP", "Event", "General").forEach { t ->
                    FilterChip(selected = draftTag == t, onClick = { draftTag = t }, label = { Text(t, fontSize = 11.5.sp) })
                }
            }

            Text(stringResource(R.string.cdash_source), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL" to "All Sources", "SCANNED" to "Scanned Card", "DUAL" to "Dual-Sided", "PHONE" to "Phone Contact", "QR" to "QR / NFC").forEach { (k, lbl) ->
                    FilterChip(selected = draftSource == k, onClick = { draftSource = k }, label = { Text(lbl, fontSize = 11.5.sp) })
                }
            }

            Text(stringResource(R.string.cdash_sort_by), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    "FAVORITES_FIRST" to "Favorites First",
                    "RECENT_ADDED" to "Recently Added",
                    "NAME_AZ" to "Name A–Z",
                    "NAME_ZA" to "Name Z–A"
                ).forEach { (k, lbl) ->
                    FilterChip(selected = draftSort == k, onClick = { draftSort = k }, label = { Text(lbl, fontSize = 11.5.sp) })
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        draftTag = "All"; draftSource = "ALL"; draftFav = false; draftBday = false; draftSort = "FAVORITES_FIRST"
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.qa_reset_btn)) }
                Button(
                    onClick = {
                        onApply(draftTag, draftSource, draftFav, draftBday, draftSort)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.qa_apply_btn), fontWeight = FontWeight.Bold) }
            }
        }
    }
}
