package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class WatermarkPlacement(val label: String) {
    CENTER_DIAGONAL("Center Diagonal"),
    REPEATED_PATTERN("Repeated Subtle Pattern"),
    FOOTER("Footer")
}

data class PurposeWatermarkConfig(
    val recipient: String = "",
    val purpose: String = "Verification Only",
    val dateText: String = "",
    val reference: String = "",
    val placement: WatermarkPlacement = WatermarkPlacement.CENTER_DIAGONAL,
    val opacityPercent: Int = 35
) {
    fun buildLines(): List<String> = buildList {
        val base = if (recipient.isNotBlank()) "For $purpose with $recipient only" else "For $purpose only"
        add(base)
        if (dateText.isNotBlank()) add("Shared on $dateText")
        if (reference.isNotBlank()) add("Ref: $reference")
        add("Not valid for any other purpose")
    }
}

/**
 * Normalized (0f..1f) rectangular region to destructively black out in exported copies.
 */
data class RedactionRegion(
    val label: String,
    val leftFrac: Float,
    val topFrac: Float,
    val rightFrac: Float,
    val bottomFrac: Float
)

object RedactedWatermarkShareHelper {

    val PRESET_REGIONS = listOf(
        RedactionRegion("Top / ID Number Area", 0.05f, 0.05f, 0.95f, 0.25f),
        RedactionRegion("Middle / DOB & Details", 0.05f, 0.35f, 0.95f, 0.60f),
        RedactionRegion("Bottom / Signature & Barcode", 0.05f, 0.72f, 0.95f, 0.96f),
        RedactionRegion("Left / Photo Area", 0.04f, 0.18f, 0.35f, 0.72f)
    )

    /**
     * Permanently flattens redacted pixels (solid black) and renders the purpose-bound watermark
     * onto a brand-new temporary export copy. Original .clenc vault image is NEVER modified.
     */
    fun renderExportCopy(
        source: Bitmap,
        redactions: List<RedactionRegion>,
        watermark: PurposeWatermarkConfig?
    ): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val w = out.width.toFloat()
        val h = out.height.toFloat()

        // 1. Destructive pixel redaction
        if (redactions.isNotEmpty()) {
            val redactPaint = Paint().apply {
                color = Color.BLACK
                style = Paint.Style.FILL
            }
            redactions.forEach { r ->
                canvas.drawRect(r.leftFrac * w, r.topFrac * h, r.rightFrac * w, r.bottomFrac * h, redactPaint)
            }
        }

        // 2. Purpose-Bound Watermark
        if (watermark != null) {
            val lines = watermark.buildLines()
            val alpha = ((watermark.opacityPercent.coerceIn(15, 70) / 100f) * 255f).toInt()
            val textSize = (minOf(w, h) * 0.036f).coerceIn(18f, 44f)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(alpha, 185, 28, 28)
                this.textSize = textSize
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }

            when (watermark.placement) {
                WatermarkPlacement.CENTER_DIAGONAL -> {
                    canvas.save()
                    canvas.rotate(-28f, w / 2f, h / 2f)
                    var y = h / 2f - (lines.size * textSize * 0.6f)
                    lines.forEach { line ->
                        canvas.drawText(line, w / 2f, y, paint)
                        y += textSize * 1.35f
                    }
                    canvas.restore()
                }
                WatermarkPlacement.REPEATED_PATTERN -> {
                    canvas.save()
                    canvas.rotate(-25f, w / 2f, h / 2f)
                    val summary = lines.take(2).joinToString(" • ")
                    var y = -h * 0.2f
                    val step = (h / 3.5f).coerceAtLeast(textSize * 3.5f)
                    while (y < h * 1.3f) {
                        canvas.drawText(summary, w / 2f, y, paint)
                        y += step
                    }
                    canvas.restore()
                }
                WatermarkPlacement.FOOTER -> {
                    val bandH = (lines.size * textSize * 1.3f + 24f).coerceAtMost(h * 0.3f)
                    val bgPaint = Paint().apply { color = Color.argb(215, 15, 23, 42) }
                    canvas.drawRect(0f, h - bandH, w, h, bgPaint)
                    paint.color = Color.WHITE
                    var y = h - bandH + textSize + 10f
                    lines.forEach { line ->
                        canvas.drawText(line, w / 2f, y, paint)
                        y += textSize * 1.25f
                    }
                }
            }
        }
        return out
    }

    suspend fun shareProcessedCopy(
        context: Context,
        documentName: String,
        sourceUri: String,
        redactions: List<RedactionRegion>,
        watermark: PurposeWatermarkConfig?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val src = VaultCryptoManager.decodeVaultBitmap(context, sourceUri, 1800)
                ?: error("Could not decode source document.")
            val processed = renderExportCopy(src, redactions, watermark)
            val outFile = TempSecureExportVault.createTempExportFile(context, "jpg")
            FileOutputStream(outFile).use { processed.compress(Bitmap.CompressFormat.JPEG, 94, it) }
            processed.recycle()

            val uri = TempSecureExportVault.toShareUri(context, outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share Protected Document Copy").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            SecurityHardeningManager.logAuditEventAsync(context, "DOC_REDACTED_SHARED", "MyIDs", true, "Protected copy shared")
        }
    }
}
