package com.cardlink.app.util

import android.content.Context
import android.nfc.NdefMessage
import android.nfc.Tag
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.NfcProjectEntity
import kotlinx.serialization.Serializable

/**
 * Platform-Neutral NFC Domain Layer shared across Android and future iOS (Apple Core NFC).
 * Never holds Android-specific Tag, Ndef, or IsoDep references.
 */
enum class NfcInteroperabilityTier(val labelRes: Int) {
    ANDROID_AND_IPHONE(com.cardlink.app.R.string.nfc_compat_both),
    BEST_WITH_CARDLINK(com.cardlink.app.R.string.nfc_compat_cardlink),
    LIMITED_COMPATIBILITY(com.cardlink.app.R.string.nfc_compat_limited)
}

@Serializable
data class SharedNfcContentModel(
    val contentType: String, // NfcContentType.name
    val primaryUriOrText: String,
    val fallbackHttpsUrl: String = "",
    val sharingProfileId: String = "BUSINESS",
    val estimatedEncodedBytes: Int = 0
)

interface CardLinkNfcPlatformAdapter {
    val platformName: String
    fun checkAvailability(): NfcHardwareState
    fun supportsTagFormatting(): Boolean
    fun supportsPermanentLock(): Boolean
    fun classifyInteroperability(type: NfcContentType, hasHttpsProfile: Boolean): NfcInteroperabilityTier
}

/**
 * Android NFC Platform Adapter backed by Android NFC / NDEF framework.
 */
class AndroidNfcPlatformAdapter(private val context: Context) : CardLinkNfcPlatformAdapter {
    override val platformName: String = "Android NFC"

    override fun checkAvailability(): NfcHardwareState =
        NfcStudioEngine.checkHardwareState(context)

    override fun supportsTagFormatting(): Boolean = true

    override fun supportsPermanentLock(): Boolean = true

    override fun classifyInteroperability(type: NfcContentType, hasHttpsProfile: Boolean): NfcInteroperabilityTier = when (type) {
        NfcContentType.URL, NfcContentType.PHONE, NfcContentType.EMAIL, NfcContentType.SMS, NfcContentType.LOCATION ->
            NfcInteroperabilityTier.ANDROID_AND_IPHONE
        NfcContentType.SHARING_PROFILE ->
            if (hasHttpsProfile) NfcInteroperabilityTier.ANDROID_AND_IPHONE else NfcInteroperabilityTier.BEST_WITH_CARDLINK
        NfcContentType.TEXT, NfcContentType.VCARD ->
            NfcInteroperabilityTier.BEST_WITH_CARDLINK
        NfcContentType.DEEP_LINK, NfcContentType.CUSTOM_URI ->
            NfcInteroperabilityTier.LIMITED_COMPATIBILITY
    }

    fun buildPlatformNdef(
        model: SharedNfcContentModel,
        activeCard: BusinessCardEntity?
    ): Result<NdefMessage> {
        val type = runCatching { NfcContentType.valueOf(model.contentType) }.getOrDefault(NfcContentType.URL)
        val prof = SharingProfileType.values().firstOrNull { it.id == model.sharingProfileId } ?: SharingProfileType.BUSINESS
        return NfcStudioEngine.buildNdefMessage(type, model.primaryUriOrText, activeCard, prof)
    }

    fun writeAndVerify(tag: Tag, message: NdefMessage): NfcOperationResult =
        NfcStudioEngine.writeAndVerifyTag(context, tag, message)
}

/**
 * Future iOS Core NFC Adapter Blueprint (Apple Core NFC NFCNDEFReaderSession contract).
 * Defines exact platform capabilities and honest limitations for iOS parity without breaking Android builds.
 */
class FutureIosCoreNfcAdapterBlueprint : CardLinkNfcPlatformAdapter {
    override val platformName: String = "iOS Core NFC"

    override fun checkAvailability(): NfcHardwareState = NfcHardwareState.UNSUPPORTED

    override fun supportsTagFormatting(): Boolean = false

    override fun supportsPermanentLock(): Boolean = true

    override fun classifyInteroperability(type: NfcContentType, hasHttpsProfile: Boolean): NfcInteroperabilityTier = when (type) {
        NfcContentType.URL, NfcContentType.SHARING_PROFILE -> NfcInteroperabilityTier.ANDROID_AND_IPHONE
        NfcContentType.TEXT, NfcContentType.PHONE, NfcContentType.EMAIL, NfcContentType.SMS, NfcContentType.LOCATION ->
            NfcInteroperabilityTier.BEST_WITH_CARDLINK
        else -> NfcInteroperabilityTier.LIMITED_COMPATIBILITY
    }
}

object SharedNfcDomainMapper {
    fun toSharedModel(
        type: NfcContentType,
        rawInput: String,
        activeCard: BusinessCardEntity?,
        sharingProfile: SharingProfileType
    ): SharedNfcContentModel {
        val projected = activeCard?.let { SharingProfileManager.applyProfile(it, sharingProfile) }
        val httpsFallback = projected?.resolveNfcShareUrl().orEmpty()
        val encodedSize = NfcStudioEngine.buildNdefMessage(type, rawInput, projected, sharingProfile)
            .getOrNull()?.toByteArray()?.size ?: 0
        return SharedNfcContentModel(
            contentType = type.name,
            primaryUriOrText = rawInput.trim(),
            fallbackHttpsUrl = httpsFallback,
            sharingProfileId = sharingProfile.id,
            estimatedEncodedBytes = encodedSize
        )
    }

    fun fromProjectEntity(project: NfcProjectEntity): SharedNfcContentModel =
        SharedNfcContentModel(
            contentType = project.contentType,
            primaryUriOrText = project.payload,
            sharingProfileId = project.sharingProfileId
        )
}
