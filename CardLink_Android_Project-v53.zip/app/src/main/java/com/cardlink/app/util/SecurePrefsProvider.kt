package com.cardlink.app.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.concurrent.ConcurrentHashMap

/**
 * Provides AES-256 EncryptedSharedPreferences backed by Android Keystore MasterKey
 * for security-sensitive policy flags (Biometric Lock, Sensitive Action Re-Auth, Pinned Cert).
 * Performs a safe one-time migration from legacy plaintext SharedPreferences without losing user settings.
 */
object SecurePrefsProvider {
    private val cache = ConcurrentHashMap<String, SharedPreferences>()

    fun getEncryptedPrefs(context: Context, legacyName: String): SharedPreferences {
        val encName = "${legacyName}_enc"
        cache[encName]?.let { return it }

        val appCtx = context.applicationContext
        val prefs = runCatching {
            val masterKey = MasterKey.Builder(appCtx)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val encPrefs = EncryptedSharedPreferences.create(
                appCtx,
                encName,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            migrateLegacyIfNeeded(appCtx, legacyName, encPrefs)
            encPrefs
        }.getOrElse {
            // Graceful fallback if Keystore is temporarily unavailable — never crashes or wipes data
            appCtx.getSharedPreferences(legacyName, Context.MODE_PRIVATE)
        }

        cache[encName] = prefs
        return prefs
    }

    private fun migrateLegacyIfNeeded(context: Context, legacyName: String, target: SharedPreferences) {
        if (target.getBoolean("__migrated_from_legacy__", false)) return
        val legacy = context.getSharedPreferences(legacyName, Context.MODE_PRIVATE)
        val all = legacy.all
        val editor = target.edit()
        for ((k, v) in all) {
            when (v) {
                is Boolean -> editor.putBoolean(k, v)
                is Int -> editor.putInt(k, v)
                is Long -> editor.putLong(k, v)
                is Float -> editor.putFloat(k, v)
                is String -> editor.putString(k, v)
            }
        }
        editor.putBoolean("__migrated_from_legacy__", true).apply()
        if (all.isNotEmpty()) {
            legacy.edit().clear().apply()
        }
    }
}
