package com.cardlink.app.ui.screens

import com.cardlink.app.ui.components.attachTapToFocus
import com.cardlink.app.ui.components.cardLinkPinchToZoom

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.cardlink.app.R
import com.cardlink.app.data.model.QrProjectEntity
import com.cardlink.app.data.model.QrScanHistoryEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.*
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.view.MotionEvent
import androidx.camera.core.FocusMeteringAction
import com.google.mlkit.vision.barcode.ZoomSuggestionOptions
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private fun universalTypeIcon(type: UniversalQrType): ImageVector = when (type) {
    UniversalQrType.VCARD, UniversalQrType.MECARD -> Icons.Default.ContactPage
    UniversalQrType.WIFI -> Icons.Default.Wifi
    UniversalQrType.EVENT -> Icons.Default.Event
    UniversalQrType.EMAIL -> Icons.Default.Email
    UniversalQrType.PHONE -> Icons.Default.Phone
    UniversalQrType.SMS -> Icons.Default.Sms
    UniversalQrType.WHATSAPP -> Icons.Default.Chat
    UniversalQrType.LOCATION -> Icons.Default.LocationOn
    UniversalQrType.CRYPTO -> Icons.Default.CurrencyBitcoin
    UniversalQrType.PAYMENT -> Icons.Default.Payments
    UniversalQrType.GS1 -> Icons.Default.Inventory2
    UniversalQrType.SOCIAL -> Icons.Default.Public
    UniversalQrType.FILE_LINK -> Icons.Default.AttachFile
    UniversalQrType.URL, UniversalQrType.DEEP_LINK -> Icons.Default.Link
    UniversalQrType.CARDLINK_PAYLOAD -> Icons.Default.QrCode2
    UniversalQrType.BINARY -> Icons.Default.Memory
    else -> Icons.Default.TextFields
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    scanHistory: List<QrScanHistoryEntity> = emptyList(),
    saveHistoryEnabled: Boolean = true,
    onToggleSaveHistory: (Boolean) -> Unit = {},
    onRecordScan: (ParsedUniversalQr) -> Unit = {},
    onToggleHistoryFavorite: (QrScanHistoryEntity) -> Unit = {},
    onDeleteHistoryEntry: (QrScanHistoryEntity) -> Unit = {},
    onClearHistory: () -> Unit = {},
    onSaveToQrStudio: (QrProjectEntity) -> Unit = {},
    onSaveContact: (SavedContactEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Active scan state
    var scannedResult by remember { mutableStateOf<ParsedUniversalQr?>(null) }
    var multiQrCandidates by remember { mutableStateOf<List<ParsedUniversalQr>>(emptyList()) }
    var showHistoryDialog by remember { mutableStateOf(false) }

    // Shared Camera Zoom & Flashlight state
    val zoomState = remember { com.cardlink.app.ui.components.CardLinkCameraZoomState() }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var hasFlashUnit by remember { mutableStateOf(false) }
    var torchEnabled by remember { mutableStateOf(false) }
    var lastScanTimeMs by remember { mutableLongStateOf(0L) }

    // Ensure flashlight is released when leaving scanner
    DisposableEffect(Unit) {
        onDispose {
            runCatching { cameraRef?.cameraControl?.enableTorch(false) }
        }
    }

    fun handleDecodedBarcodes(barcodes: List<Barcode>) {
        val valid = barcodes.mapNotNull { b ->
            val raw = b.rawValue
            val bytes = b.rawBytes
            if (raw.isNullOrEmpty() && (bytes == null || bytes.isEmpty())) null
            else UniversalQrParser.parse(raw, bytes)
        }
        if (valid.isEmpty()) return

        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (valid.size == 1) {
            val first = valid.first()
            scannedResult = first
            onRecordScan(first)
        } else {
            multiQrCandidates = valid
        }
    }

    // Multi-pass Gallery / Image QR Scanning (handles small dense QR codes on full business card photos & 90/180/270 rotations)
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val decoded = withContext(Dispatchers.IO) {
                    runCatching {
                        val options = BarcodeScannerOptions.Builder()
                            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                            .enableAllPotentialBarcodes()
                            .build()
                        val scanner = BarcodeScanning.getClient(options)
                        try {
                            // Pass 1: Direct file path
                            val directList = runCatching {
                                scanner.process(InputImage.fromFilePath(context, uri)).await()
                            }.getOrDefault(emptyList()).filter { !it.rawValue.isNullOrEmpty() || (it.rawBytes?.isNotEmpty() == true) }
                            if (directList.isNotEmpty()) return@runCatching directList

                            // Decode sampled bitmap (up to 2400px) for center/grid sub-crops & rotations
                            val rawBmp = ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2400) ?: return@runCatching emptyList()
                            val w = rawBmp.width
                            val h = rawBmp.height

                            // Pass 2: Center & 4 overlapping quadrant crops upscaled 2x (for small dense vCard QRs on a full card photo)
                            val cropRects = listOf(
                                android.graphics.Rect(w / 6, h / 6, (w * 5) / 6, (h * 5) / 6),
                                android.graphics.Rect(0, 0, (w * 2) / 3, (h * 2) / 3),
                                android.graphics.Rect(w / 3, 0, w, (h * 2) / 3),
                                android.graphics.Rect(0, h / 3, (w * 2) / 3, h),
                                android.graphics.Rect(w / 3, h / 3, w, h)
                            )
                            for (rect in cropRects) {
                                val cw = (rect.width()).coerceAtLeast(1)
                                val ch = (rect.height()).coerceAtLeast(1)
                                if (rect.left + cw <= w && rect.top + ch <= h) {
                                    val cropped = Bitmap.createBitmap(rawBmp, rect.left, rect.top, cw, ch)
                                    val scaled = Bitmap.createScaledBitmap(cropped, cw * 2, ch * 2, true)
                                    val hits = runCatching {
                                        scanner.process(InputImage.fromBitmap(scaled, 0)).await()
                                    }.getOrDefault(emptyList()).filter { !it.rawValue.isNullOrEmpty() || (it.rawBytes?.isNotEmpty() == true) }
                                    if (scaled !== cropped) scaled.recycle()
                                    cropped.recycle()
                                    if (hits.isNotEmpty()) return@runCatching hits
                                }
                            }

                            // Pass 3: Explicit 90, 180, 270 degree rotations
                            for (deg in listOf(90, 180, 270)) {
                                val hits = runCatching {
                                    scanner.process(InputImage.fromBitmap(rawBmp, deg)).await()
                                }.getOrDefault(emptyList()).filter { !it.rawValue.isNullOrEmpty() || (it.rawBytes?.isNotEmpty() == true) }
                                if (hits.isNotEmpty()) return@runCatching hits
                            }
                            emptyList()
                        } finally {
                            runCatching { scanner.close() }
                        }
                    }.getOrDefault(emptyList())
                }

                if (decoded.isEmpty()) {
                    Toast.makeText(context, context.getString(R.string.scanner_no_qr_found), Toast.LENGTH_LONG).show()
                } else {
                    handleDecodedBarcodes(decoded)
                }
            }
        }
    }

    // If a QR has been decoded, display the consistent Universal Scan Result Screen
    val activeResult = scannedResult
    if (activeResult != null) {
        UniversalQrResultScreen(
            result = activeResult,
            onSaveContact = onSaveContact,
            onSaveToQrStudio = {
                val studioType = activeResult.toStudioContentType()
                val entity = QrProjectEntity(
                    name = activeResult.displayTitle.ifBlank { activeResult.type.label },
                    qrType = studioType.name,
                    payload = activeResult.rawPayload,
                    contentFieldsJson = QrPayloadBuilder.serializeFields(activeResult.parsedFields),
                    designConfigJson = QrPayloadBuilder.serializeDesign(QrDesignConfig())
                )
                onSaveToQrStudio(entity)
                Toast.makeText(context, context.getString(R.string.scanner_saved_to_studio), Toast.LENGTH_SHORT).show()
            },
            onScanAgain = {
                scannedResult = null
                lastScanTimeMs = System.currentTimeMillis()
            },
            onNavigateBack = onNavigateBack
        )
        return
    }

    // =========================================================================
    // LIVE CAMERA SCANNER VIEW
    // =========================================================================
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.scanner_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.scanner_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = { showHistoryDialog = true }) {
                        Icon(Icons.Default.History, contentDescription = stringResource(R.string.scanner_history_title), tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color.Black)
        ) {
            if (hasCameraPermission) {
                val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
                val liveBarcodeScanner = remember {
                    val options = BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                        .build()
                    BarcodeScanning.getClient(options)
                }
                DisposableEffect(Unit) {
                    onDispose {
                        runCatching { liveBarcodeScanner.close() }
                        runCatching { cameraExecutor.shutdown() }
                    }
                }

                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            this.attachTapToFocus(zoomState)
                        }
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            runCatching {
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }


                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                                    val now = System.currentTimeMillis()
                                    if (scannedResult != null || multiQrCandidates.isNotEmpty() || (now - lastScanTimeMs < 900L)) {
                                        imageProxy.close()
                                        return@setAnalyzer
                                    }
                                    val mediaImage = imageProxy.image
                                    if (mediaImage != null) {
                                        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                        liveBarcodeScanner.process(inputImage)
                                            .addOnSuccessListener { barcodes ->
                                                if (barcodes.isNotEmpty() && scannedResult == null && multiQrCandidates.isEmpty()) {
                                                    lastScanTimeMs = System.currentTimeMillis()
                                                    handleDecodedBarcodes(barcodes)
                                                }
                                            }
                                            .addOnCompleteListener { imageProxy.close() }
                                    } else {
                                        imageProxy.close()
                                    }
                                }

                                cameraProvider.unbindAll()
                                val cam = cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    CameraSelector.DEFAULT_BACK_CAMERA,
                                    preview,
                                    analysis
                                )
                                cameraRef = cam
                                zoomState.bindCamera(ctx, cam)
                                hasFlashUnit = cam.cameraInfo.hasFlashUnit()
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState)
                )

                // Gold Scanner Frame & Animated Scan Line Overlay
                val infiniteTransition = rememberInfiniteTransition(label = "scan_line")
                val lineProgress by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1800, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "scan_beam"
                )

                val scannerAccent = MaterialTheme.colorScheme.primary
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val frameSize = size.minDimension * 0.68f
                    val left = (size.width - frameSize) / 2f
                    val top = (size.height - frameSize) / 2.2f
                    drawRoundRect(
                        color = scannerAccent,
                        topLeft = Offset(left, top),
                        size = Size(frameSize, frameSize),
                        cornerRadius = CornerRadius(28f, 28f),
                        style = Stroke(width = 6f)
                    )
                    val beamY = top + 20f + (frameSize - 40f) * lineProgress
                    drawLine(
                        color = scannerAccent.copy(alpha = 0.85f),
                        start = Offset(left + 20f, beamY),
                        end = Offset(left + frameSize - 20f, beamY),
                        strokeWidth = 4f
                    )
                }

                // Hardware-Aware Zoom Presets (0.5x | 1x | 3.5x) above Bottom Controls
                com.cardlink.app.ui.components.ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 92.dp)
                )

                // Bottom Controls Bar: Flashlight + Scan from Image
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasFlashUnit) {
                        Button(
                            onClick = {
                                val next = !torchEnabled
                                torchEnabled = next
                                runCatching { cameraRef?.cameraControl?.enableTorch(next) }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (torchEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.88f),
                                contentColor = if (torchEnabled) MaterialTheme.colorScheme.onPrimary else Color.White
                            ),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(if (torchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.scanner_flashlight), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Button(
                        onClick = {
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.scanner_from_image), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Camera permission fallback — still allows Scan from Image!
                Column(
                    modifier = Modifier.fillMaxSize().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
                ) {
                    Icon(Icons.Default.PhotoCamera, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(54.dp))
                    Text(stringResource(R.string.qr_scan_cam_perm_msg),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) { Text(stringResource(R.string.qa_open_settings_btn), fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = {
                            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    ) { Text(stringResource(R.string.scanner_from_image), color = Color.White) }
                }
            }
        }
    }

    // Multiple QR Codes Detected in One Image Picker
    if (multiQrCandidates.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { multiQrCandidates = emptyList() },
            title = { Text("Multiple QR Codes Found (${multiQrCandidates.size})", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    multiQrCandidates.forEach { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                scannedResult = item
                                onRecordScan(item)
                                multiQrCandidates = emptyList()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(universalTypeIcon(item.type), null, tint = MaterialTheme.colorScheme.primary)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.displayTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(item.type.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { multiQrCandidates = emptyList() }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    // Scan History Modal Dialog
    if (showHistoryDialog) {
        QrScanHistoryDialog(
            history = scanHistory,
            saveHistoryEnabled = saveHistoryEnabled,
            onToggleSaveHistory = onToggleSaveHistory,
            onReopen = { entry ->
                showHistoryDialog = false
                scannedResult = UniversalQrParser.parse(entry.rawPayload)
            },
            onToggleFavorite = onToggleHistoryFavorite,
            onDelete = onDeleteHistoryEntry,
            onClearAll = onClearHistory,
            onDismiss = { showHistoryDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UniversalQrResultScreen(
    result: ParsedUniversalQr,
    onSaveContact: (SavedContactEntity) -> Unit,
    onSaveToQrStudio: () -> Unit,
    onScanAgain: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var showRawContent by remember { mutableStateOf(false) }
    var revealSensitive by remember { mutableStateOf(false) }
    var showCopySensitiveConfirm by remember { mutableStateOf(false) }
    var showEditContactDialog by remember { mutableStateOf(false) }

    val statusColor = when {
        result.securityStatus == QrSecurityStatus.POTENTIAL_RISK -> Color(0xFFEF4444)
        result.securityStatus == QrSecurityStatus.NON_SECURE_HTTP || result.securityStatus == QrSecurityStatus.UNRECOGNIZED_SCHEME -> Color(0xFFF59E0B)
        result.confidence == QrParseConfidence.CONFIRMED -> Color(0xFF10B981)
        else -> MaterialTheme.colorScheme.primary
    }

    fun launchSafeUri(uriString: String) {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, "No compatible app found to open this link.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.scanner_result_title), fontWeight = FontWeight.Bold)
                        Text(result.type.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Header & Status Badge
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.65f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(modifier = Modifier.size(46.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(universalTypeIcon(result.type), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(result.displayTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = "${result.confidence.label} • ${result.securityStatus.label}",
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (result.warningMessage.isNotBlank()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF59E0B).copy(alpha = 0.14f)
                        ) {
                            Text(
                                text = result.warningMessage,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFF59E0B),
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            // 2. Human-Readable Preview
            if (result.previewRows.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.qa_label_preview), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                            if (result.type == UniversalQrType.WIFI && result.parsedFields["password"].orEmpty().isNotBlank()) {
                                TextButton(onClick = { revealSensitive = !revealSensitive }) {
                                    Text(if (revealSensitive) "Hide Password" else "Show Password", fontSize = 12.sp)
                                }
                            }
                        }
                        result.previewRows.forEach { (k, v) ->
                            val displayVal = if (k == "Password" && revealSensitive) {
                                result.parsedFields["password"].orEmpty()
                            } else v
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                                Text(displayVal, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }

            // 3. Context-Specific Primary Actions (NEVER auto-executed!)
            when (result.type) {
                UniversalQrType.VCARD, UniversalQrType.MECARD -> {
                    val contact = result.parsedContact
                    if (contact != null) {
                        Button(
                            onClick = { onSaveContact(contact) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.prod_save_contacts_btn), fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showEditContactDialog = true },
                                modifier = Modifier.weight(1f)
                            ) { Text(stringResource(R.string.qr_edit_before_save_btn), fontSize = 12.sp) }
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                                        type = ContactsContract.RawContacts.CONTENT_TYPE
                                        putExtra(ContactsContract.Intents.Insert.NAME, contact.fullName)
                                        putExtra(ContactsContract.Intents.Insert.COMPANY, contact.companyName)
                                        putExtra(ContactsContract.Intents.Insert.JOB_TITLE, contact.designation)
                                        putExtra(ContactsContract.Intents.Insert.PHONE, contact.phone)
                                        putExtra(ContactsContract.Intents.Insert.EMAIL, contact.email)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    runCatching { context.startActivity(intent) }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text(stringResource(R.string.qr_save_to_device_btn), fontSize = 12.sp) }
                        }
                    }
                }

                UniversalQrType.WIFI -> {
                    val ssid = result.parsedFields["ssid"].orEmpty()
                    val pass = result.parsedFields["password"].orEmpty()
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && ssid.isNotBlank()) {
                                val builder = WifiNetworkSuggestion.Builder().setSsid(ssid)
                                if (pass.isNotBlank()) builder.setWpa2Passphrase(pass)
                                val intent = Intent(Settings.ACTION_WIFI_ADD_NETWORKS).apply {
                                    putParcelableArrayListExtra(Settings.EXTRA_WIFI_NETWORK_LIST, arrayListOf(builder.build()))
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                runCatching { context.startActivity(intent) }.onFailure {
                                    runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                }
                            } else {
                                runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Wifi, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_connect_wifi_btn), fontWeight = FontWeight.Bold)
                    }
                    if (pass.isNotBlank()) {
                        OutlinedButton(
                            onClick = { showCopySensitiveConfirm = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(stringResource(R.string.qr_copy_wifi_pw_btn)) }
                    }
                }

                UniversalQrType.URL, UniversalQrType.SOCIAL, UniversalQrType.FILE_LINK, UniversalQrType.DEEP_LINK -> {
                    Button(
                        onClick = { launchSafeUri(result.rawPayload) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.OpenInBrowser, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qa_open_link_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.WHATSAPP -> {
                    Button(
                        onClick = { launchSafeUri(result.rawPayload) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Chat, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_open_wa_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.EMAIL -> {
                    Button(
                        onClick = {
                            val to = result.parsedFields["email"].orEmpty()
                            val subj = result.parsedFields["subject"].orEmpty()
                            val body = result.parsedFields["body"].orEmpty()
                            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$to")).apply {
                                putExtra(Intent.EXTRA_SUBJECT, subj)
                                putExtra(Intent.EXTRA_TEXT, body)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            runCatching { context.startActivity(intent) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Email, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_compose_email_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.PHONE -> {
                    val num = result.parsedFields["phone"].orEmpty()
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            runCatching { context.startActivity(intent) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Phone, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Call $num", fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.SMS -> {
                    val num = result.parsedFields["phone"].orEmpty()
                    val msg = result.parsedFields["message"].orEmpty()
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).apply {
                                putExtra("sms_body", msg)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            runCatching { context.startActivity(intent) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Sms, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_open_sms_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.LOCATION -> {
                    Button(
                        onClick = { launchSafeUri(result.rawPayload) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Map, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_open_maps_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.EVENT -> {
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_INSERT).apply {
                                data = CalendarContract.Events.CONTENT_URI
                                putExtra(CalendarContract.Events.TITLE, result.parsedFields["title"].orEmpty())
                                putExtra(CalendarContract.Events.EVENT_LOCATION, result.parsedFields["location"].orEmpty())
                                putExtra(CalendarContract.Events.DESCRIPTION, result.parsedFields["description"].orEmpty())
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            runCatching { context.startActivity(intent) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Event, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_add_to_cal_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.PAYMENT -> {
                    Button(
                        onClick = { launchSafeUri(result.rawPayload) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.Payments, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_open_payment_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.CRYPTO -> {
                    val addr = result.parsedFields["address"].orEmpty()
                    Button(
                        onClick = { SecureClipboardHelper.copySensitive(context, "Crypto Address", addr) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, null)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.qr_copy_wallet_btn), fontWeight = FontWeight.Bold)
                    }
                }

                UniversalQrType.GS1 -> {
                    val url = result.parsedFields["url"].orEmpty()
                    if (url.startsWith("http", true)) {
                        Button(
                            onClick = { launchSafeUri(url) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.qr_open_digital_link_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                else -> Unit
            }

            // 4. Universal Secondary Actions (Copy, Share, Save to QR Studio, View Raw Content, Scan Again)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        if (result.isSensitive) showCopySensitiveConfirm = true
                        else SecureClipboardHelper.copySensitive(context, result.type.label, result.rawPayload)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.qa_copy_btn), fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, result.rawPayload)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share QR Content").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.qa_share_btn), fontSize = 12.sp)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onSaveToQrStudio,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.QrCode2, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.qr_save_as_qr_btn), fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { showRawContent = !showRawContent },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Code, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (showRawContent) "Hide Raw" else "Raw Content", fontSize = 12.sp)
                }
            }

            if (showRawContent) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Exact Decoded Payload (${result.rawPayload.length} chars)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(
                            text = if (result.isSensitive && !revealSensitive) "Sensitive payload masked. Tap Reveal below to inspect." else result.rawPayload,
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (result.isSensitive) {
                            TextButton(onClick = { revealSensitive = !revealSensitive }) {
                                Text(if (revealSensitive) "Mask Raw Payload" else "Reveal Raw Payload", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onScanAgain,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.QrCodeScanner, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.scanner_scan_again), fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showCopySensitiveConfirm) {
        AlertDialog(
            onDismissRequest = { showCopySensitiveConfirm = false },
            title = { Text(stringResource(R.string.qr_copy_sensitive_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.qr_sensitive_copy_msg)) },
            confirmButton = {
                Button(onClick = {
                    showCopySensitiveConfirm = false
                    val textToCopy = if (result.type == UniversalQrType.WIFI) result.parsedFields["password"].orEmpty().ifBlank { result.rawPayload } else result.rawPayload
                    SecureClipboardHelper.copySensitive(context, result.type.label, textToCopy)
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = { TextButton(onClick = { showCopySensitiveConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showEditContactDialog && result.parsedContact != null) {
        val base = result.parsedContact
        var name by remember { mutableStateOf(base.fullName) }
        var org by remember { mutableStateOf(base.companyName) }
        var phone by remember { mutableStateOf(base.phone) }
        var email by remember { mutableStateOf(base.email) }
        AlertDialog(
            onDismissRequest = { showEditContactDialog = false },
            title = { Text(stringResource(R.string.qr_edit_contact_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(R.string.net_field_full_name)) }, singleLine = true)
                    OutlinedTextField(value = org, onValueChange = { org = it }, label = { Text(stringResource(R.string.qr_field_org)) }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text(stringResource(R.string.cal_src_phone)) }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(stringResource(R.string.net_field_email)) }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    showEditContactDialog = false
                    onSaveContact(base.copy(fullName = name.trim(), companyName = org.trim(), phone = phone.trim(), email = email.trim()))
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showEditContactDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}

@Composable
private fun QrScanHistoryDialog(
    history: List<QrScanHistoryEntity>,
    saveHistoryEnabled: Boolean,
    onToggleSaveHistory: (Boolean) -> Unit,
    onReopen: (QrScanHistoryEntity) -> Unit,
    onToggleFavorite: (QrScanHistoryEntity) -> Unit,
    onDelete: (QrScanHistoryEntity) -> Unit,
    onClearAll: () -> Unit,
    onDismiss: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val filtered = remember(history, search) {
        val q = search.trim()
        if (q.isBlank()) history
        else history.filter { it.displayTitle.contains(q, true) || it.detectedType.contains(q, true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.scanner_history_title), fontWeight = FontWeight.Bold)
                if (history.isNotEmpty()) {
                    TextButton(onClick = onClearAll) { Text(stringResource(R.string.qa_clear_btn), fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.scanner_save_history), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Switch(checked = saveHistoryEnabled, onCheckedChange = onToggleSaveHistory)
                }
                if (history.isNotEmpty()) {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        placeholder = { Text(stringResource(R.string.qr_search_history_hint)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f, fill = false)) {
                        items(filtered, key = { it.stableUuid }) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { onReopen(item) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.displayTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${item.detectedType} • ${fmt.format(Date(item.scannedAtTimestamp))}${if (item.isSensitive) " • Protected" else ""}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                    IconButton(onClick = { onToggleFavorite(item) }, modifier = Modifier.size(30.dp)) {
                                        Icon(if (item.isFavorite) Icons.Default.Star else Icons.Default.StarBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Default.DeleteOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Text(stringResource(R.string.qr_no_history_msg), style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) } }
    )
}
