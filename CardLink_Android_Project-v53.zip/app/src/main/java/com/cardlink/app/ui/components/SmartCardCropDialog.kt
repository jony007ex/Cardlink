package com.cardlink.app.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cardlink.app.R
import com.cardlink.app.util.CardCropMetadata
import com.cardlink.app.util.SmartCardCropEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

/**
 * Hybrid Smart Business Card Crop Dialog:
 * - Default mode: fast Auto-Crop preview computed off the UI thread (Dispatchers.Default).
 * - Adjust mode: preserves exact image aspect ratio (zero stretching), never allocates perspective
 *   bitmaps during 60fps corner drag, and supports 4-corner perspective handles + rotation.
 * Original encrypted bitmap is NEVER overwritten.
 */
@Composable
fun SmartCardCropDialog(
    sourceBitmap: Bitmap,
    initialMetadata: CardCropMetadata? = null,
    startInManualAdjust: Boolean = false,
    onConfirm: (croppedBitmap: Bitmap, metadata: CardCropMetadata) -> Unit,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val autoMeta = remember(sourceBitmap) { SmartCardCropEngine.detectAutoCrop(sourceBitmap) }
    var meta by remember(sourceBitmap, initialMetadata) { mutableStateOf(initialMetadata ?: autoMeta) }
    var isAdjustMode by remember(startInManualAdjust) { mutableStateOf(startInManualAdjust) }
    var isApplyingFinal by remember { mutableStateOf(false) }

    // Only render the perspective-corrected preview when NOT dragging corners in manual adjust mode
    val previewBitmap by produceState<Bitmap?>(initialValue = null, sourceBitmap, meta, isAdjustMode) {
        if (!isAdjustMode) {
            value = withContext(Dispatchers.Default) {
                SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta)
            }
        }
    }

    val rotatedSourceForManual = remember(sourceBitmap, meta.rotationDegrees) {
        if (meta.rotationDegrees % 360 == 0) sourceBitmap
        else {
            val m = android.graphics.Matrix().apply { postRotate((meta.rotationDegrees % 360).toFloat()) }
            Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.width, sourceBitmap.height, m, true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isAdjustMode) stringResource(R.string.crop_adjust_title) else stringResource(R.string.crop_detected_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isAdjustMode) stringResource(R.string.crop_adjust_sub) else stringResource(R.string.crop_detected_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                    }
                }

                // Main Visual Area
                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.88f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isAdjustMode) {
                        val readyBmp = previewBitmap
                        if (readyBmp != null) {
                            Image(
                                bitmap = readyBmp.asImageBitmap(),
                                contentDescription = "Auto-cropped card preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(14.dp)
                            )
                        } else {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        // Compute exact aspect-preserving fitted box so the image never stretches
                        // and normalized [0..1] quad coordinates align pixel-accurately with the card!
                        val padDp = 16.dp
                        val availW = (maxWidth - padDp * 2).coerceAtLeast(80.dp)
                        val availH = (maxHeight - padDp * 2).coerceAtLeast(80.dp)
                        val imgRatio = (rotatedSourceForManual.width.toFloat() / rotatedSourceForManual.height.coerceAtLeast(1).toFloat())
                            .coerceIn(0.35f, 3.0f)
                        val boxRatio = availW.value / availH.value.coerceAtLeast(1f)
                        val fitW = if (imgRatio >= boxRatio) availW else availH * imgRatio
                        val fitH = if (imgRatio >= boxRatio) availW / imgRatio else availH

                        var boxSize by remember { mutableStateOf(IntSize.Zero) }
                        var activeCorner by remember { mutableIntStateOf(-1) }
                        val handleColor = MaterialTheme.colorScheme.primary

                        Box(
                            modifier = Modifier
                                .size(width = fitW, height = fitH)
                                .onSizeChanged { boxSize = it }
                                .pointerInput(meta.rotationDegrees, fitW, fitH) {
                                    detectDragGestures(
                                        onDragStart = { start ->
                                            if (boxSize.width <= 0 || boxSize.height <= 0) return@detectDragGestures
                                            val bw = boxSize.width.toFloat()
                                            val bh = boxSize.height.toFloat()
                                            val corners = listOf(
                                                Offset(meta.topLeftX * bw, meta.topLeftY * bh),
                                                Offset(meta.topRightX * bw, meta.topRightY * bh),
                                                Offset(meta.bottomRightX * bw, meta.bottomRightY * bh),
                                                Offset(meta.bottomLeftX * bw, meta.bottomLeftY * bh)
                                            )
                                            var bestIdx = -1
                                            var bestDist = 110f
                                            corners.forEachIndexed { idx, pt ->
                                                val d = hypot((start.x - pt.x).toDouble(), (start.y - pt.y).toDouble()).toFloat()
                                                if (d < bestDist) {
                                                    bestDist = d
                                                    bestIdx = idx
                                                }
                                            }
                                            activeCorner = bestIdx
                                        },
                                        onDragEnd = { activeCorner = -1 },
                                        onDragCancel = { activeCorner = -1 },
                                        onDrag = { change, dragAmount ->
                                            if (activeCorner < 0 || boxSize.width <= 0 || boxSize.height <= 0) return@detectDragGestures
                                            change.consume()
                                            val dx = dragAmount.x / boxSize.width.toFloat()
                                            val dy = dragAmount.y / boxSize.height.toFloat()
                                            meta = when (activeCorner) {
                                                0 -> meta.copy(
                                                    topLeftX = (meta.topLeftX + dx).coerceIn(0f, meta.topRightX - 0.15f),
                                                    topLeftY = (meta.topLeftY + dy).coerceIn(0f, meta.bottomLeftY - 0.15f),
                                                    isOriginalFullFrame = false
                                                )
                                                1 -> meta.copy(
                                                    topRightX = (meta.topRightX + dx).coerceIn(meta.topLeftX + 0.15f, 1f),
                                                    topRightY = (meta.topRightY + dy).coerceIn(0f, meta.bottomRightY - 0.15f),
                                                    isOriginalFullFrame = false
                                                )
                                                2 -> meta.copy(
                                                    bottomRightX = (meta.bottomRightX + dx).coerceIn(meta.bottomLeftX + 0.15f, 1f),
                                                    bottomRightY = (meta.bottomRightY + dy).coerceIn(meta.topRightY + 0.15f, 1f),
                                                    isOriginalFullFrame = false
                                                )
                                                3 -> meta.copy(
                                                    bottomLeftX = (meta.bottomLeftX + dx).coerceIn(0f, meta.bottomRightX - 0.15f),
                                                    bottomLeftY = (meta.bottomLeftY + dy).coerceIn(meta.topLeftY + 0.15f, 1f),
                                                    isOriginalFullFrame = false
                                                )
                                                else -> meta
                                            }
                                        }
                                    )
                                }
                        ) {
                            Image(
                                bitmap = rotatedSourceForManual.asImageBitmap(),
                                contentDescription = "Original card for crop adjustment",
                                contentScale = ContentScale.FillBounds,
                                modifier = Modifier.fillMaxSize()
                            )
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val p0 = Offset(meta.topLeftX * size.width, meta.topLeftY * size.height)
                                val p1 = Offset(meta.topRightX * size.width, meta.topRightY * size.height)
                                val p2 = Offset(meta.bottomRightX * size.width, meta.bottomRightY * size.height)
                                val p3 = Offset(meta.bottomLeftX * size.width, meta.bottomLeftY * size.height)

                                val path = Path().apply {
                                    moveTo(p0.x, p0.y)
                                    lineTo(p1.x, p1.y)
                                    lineTo(p2.x, p2.y)
                                    lineTo(p3.x, p3.y)
                                    close()
                                }
                                drawPath(path, color = handleColor, style = Stroke(width = 4f))
                                listOf(p0, p1, p2, p3).forEach { pt ->
                                    drawCircle(color = Color.White, radius = 18f, center = pt)
                                    drawCircle(color = handleColor, radius = 12f, center = pt)
                                }
                            }
                        }
                    }
                }

                // Manual Controls Bar (Accessible non-gesture Rotate, Auto Crop, Original)
                if (isAdjustMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = {
                            meta = meta.copy(rotationDegrees = (meta.rotationDegrees + 270) % 360)
                        }) {
                            Icon(Icons.Default.RotateLeft, contentDescription = "Rotate Left", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.crop_rotate_left_lbl), fontSize = 11.5.sp)
                        }
                        TextButton(onClick = {
                            meta = meta.copy(rotationDegrees = (meta.rotationDegrees + 90) % 360)
                        }) {
                            Icon(Icons.Default.RotateRight, contentDescription = "Rotate Right", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.crop_rotate_right_lbl), fontSize = 11.5.sp)
                        }
                        TextButton(onClick = { meta = autoMeta.copy(rotationDegrees = meta.rotationDegrees) }) {
                            Text(stringResource(R.string.crop_auto_btn), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                        TextButton(onClick = { meta = CardCropMetadata.fullOriginal(meta.rotationDegrees) }) {
                            Text(stringResource(R.string.crop_reset_original_short), fontSize = 11.5.sp)
                        }
                    }
                }

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!isAdjustMode) {
                        OutlinedButton(
                            onClick = { isAdjustMode = true },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Crop, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.crop_adjust_btn), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                val cached = previewBitmap
                                if (cached != null) {
                                    onConfirm(cached, meta)
                                } else {
                                    isApplyingFinal = true
                                    scope.launch {
                                        val rendered = withContext(Dispatchers.Default) {
                                            SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta)
                                        }
                                        isApplyingFinal = false
                                        onConfirm(rendered, meta)
                                    }
                                }
                            },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            if (isApplyingFinal) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.crop_use_btn), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { isAdjustMode = false },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text(stringResource(R.string.qa_label_preview), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                isApplyingFinal = true
                                scope.launch {
                                    val finalBmp = withContext(Dispatchers.Default) {
                                        SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta)
                                    }
                                    isApplyingFinal = false
                                    onConfirm(finalBmp, meta)
                                }
                            },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            if (isApplyingFinal) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.ocr_done_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
