package com.cardlink.app.nearby

import android.content.Context
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.CardShareHelper
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NearbyPeerEndpoint(
    val endpointId: String,
    val endpointName: String
)

data class PendingNearbyAuth(
    val endpointId: String,
    val endpointName: String,
    val authDigits: String,
    val isIncoming: Boolean
)

class NearbyCardExchangeManager(private val context: Context) {

    companion object {
        private const val SERVICE_ID = "com.cardlink.app.NEARBY_CARD_SWAP_V1"
        private val STRATEGY = Strategy.P2P_POINT_TO_POINT
    }

    private val client: ConnectionsClient by lazy { Nearby.getConnectionsClient(context.applicationContext) }

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    private val _statusText = MutableStateFlow("Ready for instant BLE + Wi-Fi Direct swap")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<NearbyPeerEndpoint>>(emptyList())
    val discoveredPeers: StateFlow<List<NearbyPeerEndpoint>> = _discoveredPeers.asStateFlow()

    private val _pendingAuth = MutableStateFlow<PendingNearbyAuth?>(null)
    val pendingAuth: StateFlow<PendingNearbyAuth?> = _pendingAuth.asStateFlow()

    private val _connectedPeerName = MutableStateFlow<String?>(null)
    val connectedPeerName: StateFlow<String?> = _connectedPeerName.asStateFlow()

    private val _cardSent = MutableStateFlow(false)
    val cardSent: StateFlow<Boolean> = _cardSent.asStateFlow()

    private val _receivedContact = MutableStateFlow<SavedContactEntity?>(null)
    val receivedContact: StateFlow<SavedContactEntity?> = _receivedContact.asStateFlow()

    private var outgoingCard: BusinessCardEntity? = null

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val raw = payload.asBytes()?.toString(Charsets.UTF_8).orEmpty()
                if (raw.contains("BEGIN:VCARD")) {
                    val parsed = CardShareHelper.parseVCardToContact(raw, "Nearby (BLE + Wi-Fi Direct)")
                    _receivedContact.value = parsed
                    _statusText.value = "Received card from ${parsed.fullName}!"
                }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                _statusText.value = "High-speed transfer complete"
            }
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            _pendingAuth.value = PendingNearbyAuth(
                endpointId = endpointId,
                endpointName = info.endpointName.ifBlank { "CardLink User" },
                authDigits = info.authenticationDigits,
                isIncoming = info.isIncomingConnection
            )
            _statusText.value = "Verify 4-digit code with ${info.endpointName}"
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val peerName = _pendingAuth.value?.endpointName ?: "Peer"
            _pendingAuth.value = null
            if (result.status.isSuccess) {
                _connectedPeerName.value = peerName
                _statusText.value = "Connected via BLE + Wi-Fi Direct • Swapping cards…"
                sendActiveCardPayload(endpointId)
            } else {
                _statusText.value = "Connection cancelled or declined"
            }
        }

        override fun onDisconnected(endpointId: String) {
            _connectedPeerName.value = null
            _statusText.value = "Peer disconnected"
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val peer = NearbyPeerEndpoint(
                endpointId = endpointId,
                endpointName = info.endpointName.ifBlank { "CardLink User" }
            )
            val updated = _discoveredPeers.value.toMutableList()
            val idx = updated.indexOfFirst { it.endpointId == endpointId }
            if (idx >= 0) updated[idx] = peer else updated.add(peer)
            _discoveredPeers.value = updated
            _statusText.value = "Found ${updated.size} nearby CardLink device(s)"
        }

        override fun onEndpointLost(endpointId: String) {
            _discoveredPeers.value = _discoveredPeers.value.filterNot { it.endpointId == endpointId }
        }
    }

    fun startNearbySession(cardToShare: BusinessCardEntity) {
        outgoingCard = cardToShare
        _discoveredPeers.value = emptyList()
        _pendingAuth.value = null
        _connectedPeerName.value = null
        _cardSent.value = false
        _receivedContact.value = null

        val localLabel = buildString {
            append(cardToShare.fullName.ifBlank { "CardLink User" })
            if (cardToShare.companyName.isNotBlank()) append(" (${cardToShare.companyName})")
        }.take(42)

        runCatching { client.stopAllEndpoints() }
        runCatching { client.stopAdvertising() }
        runCatching { client.stopDiscovery() }

        val advOptions = AdvertisingOptions.Builder().setStrategy(STRATEGY).build()
        val discOptions = DiscoveryOptions.Builder().setStrategy(STRATEGY).build()

        client.startAdvertising(localLabel, SERVICE_ID, connectionLifecycleCallback, advOptions)
            .addOnSuccessListener {
                _isActive.value = true
                _statusText.value = "Scanning & visible via BLE + Wi-Fi Direct…"
            }
            .addOnFailureListener {
                _statusText.value = "Nearby advertising unavailable — check Bluetooth & Wi-Fi"
            }

        client.startDiscovery(SERVICE_ID, endpointDiscoveryCallback, discOptions)
            .addOnSuccessListener {
                _isActive.value = true
            }
            .addOnFailureListener {
                _statusText.value = "Nearby discovery unavailable — check permissions"
            }
    }

    fun requestConnectionToPeer(peer: NearbyPeerEndpoint) {
        val localLabel = outgoingCard?.fullName?.ifBlank { "CardLink User" } ?: "CardLink User"
        _statusText.value = "Connecting to ${peer.endpointName}…"
        client.requestConnection(localLabel, peer.endpointId, connectionLifecycleCallback)
            .addOnFailureListener {
                _statusText.value = "Could not connect to ${peer.endpointName}"
            }
    }

    fun acceptPendingConnection() {
        val pending = _pendingAuth.value ?: return
        client.acceptConnection(pending.endpointId, payloadCallback)
    }

    fun rejectPendingConnection() {
        val pending = _pendingAuth.value ?: return
        client.rejectConnection(pending.endpointId)
        _pendingAuth.value = null
        _statusText.value = "Connection rejected"
    }

    private fun sendActiveCardPayload(endpointId: String) {
        val card = outgoingCard ?: return
        val vcfBytes = CardShareHelper.toVCardString(card).toByteArray(Charsets.UTF_8)
        client.sendPayload(endpointId, Payload.fromBytes(vcfBytes))
            .addOnSuccessListener { _cardSent.value = true }
    }

    fun clearReceivedContact() {
        _receivedContact.value = null
    }

    fun stopSession() {
        runCatching { client.stopAdvertising() }
        runCatching { client.stopDiscovery() }
        runCatching { client.stopAllEndpoints() }
        _isActive.value = false
        _pendingAuth.value = null
        _connectedPeerName.value = null
    }
}
