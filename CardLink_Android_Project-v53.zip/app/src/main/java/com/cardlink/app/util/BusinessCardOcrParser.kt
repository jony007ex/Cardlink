package com.cardlink.app.util

import android.util.Patterns
import com.cardlink.app.data.model.SavedContactEntity
import com.google.mlkit.vision.text.Text

object BusinessCardOcrParser {

    private val PHONE_REGEX = Regex("""(?:\+?\d{1,4}[\s.-]?)?(?:\(?\d{2,5}\)?[\s.-]?)?\d{3,4}[\s.-]?\d{3,5}""")
    private val EMAIL_REGEX = Regex("""[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}""")

    private val DESIGNATION_KEYWORDS = listOf(
        "chief", "ceo", "cto", "cfo", "coo", "president", "vice president", "vp", "svp", "evp",
        "director", "head", "manager", "lead", "engineer", "developer", "architect", "consultant",
        "analyst", "specialist", "officer", "coordinator", "executive", "partner", "founder",
        "professor", "lecturer", "advisor", "associate", "secretary", "chairman"
    )

    private val COMPANY_KEYWORDS = listOf(
        "plc", "ltd", "limited", "inc", "corp", "corporation", "llc", "group",
        "bank", "technologies", "solutions", "systems", "enterprises", "global", "holdings",
        "associates", "agency", "studio", "labs", "ventures", "foundation", "institute", "college"
    )

    private val DEPARTMENT_KEYWORDS = listOf(
        "department", "division", "unit", "procurement", "finance", "operations", "marketing",
        "sales", "human resources", "hr", "it", "technology", "legal", "strategy", "credit",
        "banking", "administration", "supply chain", "logistics", "engineering"
    )

    private val ADDRESS_KEYWORDS = listOf(
        "road", "rd", "street", "st", "avenue", "ave", "lane", "plot", "house", "building",
        "tower", "plaza", "floor", "level", "suite", "sector", "block", "area", "city",
        "dhaka", "po box", "zip", "highway", "bazar", "commercial", "gulshan", "motijheel", "banani"
    )

    fun parse(visionText: Text): SavedContactEntity {
        return CardOcrPipeline.extractContactWithConfidence(visionText).contact
    }

    private fun legacyParseUnused(visionText: Text): SavedContactEntity {
        val rawLines = visionText.textBlocks
            .flatMap { it.lines }
            .map { line ->
                OcrLine(
                    text = line.text.trim(),
                    height = line.boundingBox?.height() ?: 0,
                    top = line.boundingBox?.top ?: Int.MAX_VALUE
                )
            }
            .filter { it.text.length >= 2 }
            .sortedBy { it.top }

        val consumedIndices = mutableSetOf<Int>()
        var email = ""
        var website = ""
        var linkedInUrl = ""
        val phones = mutableListOf<String>()
        var whatsapp = ""
        var designation = ""
        var companyName = ""
        var department = ""
        val addressLines = mutableListOf<String>()

        rawLines.forEachIndexed { index, ocrLine ->
            val line = ocrLine.text
            val lower = line.lowercase()

            val emailMatch = EMAIL_REGEX.find(line)
            if (emailMatch != null && email.isEmpty()) {
                email = emailMatch.value.lowercase()
                consumedIndices.add(index)
            }

            val words = line.split(Regex("""\s+"""))
            for (word in words) {
                val cleaned = word.trim(',', ';', '|')
                if (!cleaned.contains("@") && Patterns.WEB_URL.matcher(cleaned).matches()) {
                    when {
                        cleaned.contains("linkedin.com", ignoreCase = true) -> linkedInUrl = cleaned
                        website.isEmpty() -> website = if (cleaned.startsWith("http", true)) cleaned else "https://$cleaned"
                    }
                    consumedIndices.add(index)
                }
            }

            PHONE_REGEX.findAll(line).forEach { match ->
                val digitsOnly = match.value.filter { it.isDigit() || it == '+' }
                if (digitsOnly.count { it.isDigit() } in 7..15) {
                    val formatted = match.value.trim()
                    if (lower.contains("whatsapp") || lower.contains("wa:") || lower.contains("wa ")) {
                        whatsapp = formatted
                    } else if (!phones.contains(formatted)) {
                        phones.add(formatted)
                    }
                    consumedIndices.add(index)
                }
            }
        }

        rawLines.forEachIndexed { index, ocrLine ->
            if (index in consumedIndices) return@forEachIndexed
            val line = ocrLine.text
            val lower = line.lowercase()

            if (department.isEmpty() && DEPARTMENT_KEYWORDS.any { lower.contains(it) } &&
                !COMPANY_KEYWORDS.any { lower.contains(it) }
            ) {
                department = line
                consumedIndices.add(index)
                return@forEachIndexed
            }

            if (designation.isEmpty() && DESIGNATION_KEYWORDS.any { lower.contains(it) }) {
                designation = line
                consumedIndices.add(index)
                return@forEachIndexed
            }

            if (companyName.isEmpty() && COMPANY_KEYWORDS.any { lower.contains(it) }) {
                companyName = line
                consumedIndices.add(index)
                return@forEachIndexed
            }

            if (ADDRESS_KEYWORDS.any { lower.contains(it) } || (line.contains(",") && line.any { it.isDigit() })) {
                addressLines.add(line)
                consumedIndices.add(index)
            }
        }

        val remainingLines = rawLines.filterIndexed { idx, ocrLine ->
            idx !in consumedIndices && ocrLine.text.count { it.isDigit() } == 0 && ocrLine.text.split(" ").size in 1..6
        }

        val fullName = remainingLines.maxByOrNull { it.height }?.text ?: remainingLines.firstOrNull()?.text ?: ""

        if (companyName.isEmpty()) {
            companyName = remainingLines.firstOrNull { it.text != fullName }?.text.orEmpty()
        }

        return SavedContactEntity(
            fullName = fullName.ifBlank { "Scanned Contact" },
            designation = designation,
            companyName = companyName,
            department = department,
            phone = phones.firstOrNull().orEmpty(),
            whatsapp = whatsapp.ifEmpty { phones.getOrNull(1).orEmpty() },
            email = email,
            officeAddress = addressLines.joinToString(", "),
            website = website,
            linkedInUrl = linkedInUrl,
            notes = "Scanned via CardLink OCR\n${visionText.text.trim()}",
            receivedVia = "OCR Scan"
        )
    }

    private data class OcrLine(val text: String, val height: Int, val top: Int)

    /**
     * Merges Front and Back OCR results so missing fields (commonly address, secondary phone,
     * website, or social links on the back side) are automatically populated without losing front data.
     */
    fun mergeDualSide(front: SavedContactEntity, back: SavedContactEntity): SavedContactEntity {
        val mergedRawOcr = listOf(
            front.rawOcrText.takeIf { it.isNotBlank() }?.let { "Front Side:\n$it" },
            back.rawOcrText.takeIf { it.isNotBlank() }?.let { "Back Side:\n$it" }
        ).filterNotNull().joinToString("\n\n")

        val mergedAddress = listOf(front.officeAddress, back.officeAddress)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(", ")

        return front.copy(
            fullName = if (front.fullName.isNotBlank() && front.fullName != "Scanned Contact") front.fullName else back.fullName,
            designation = front.designation.ifBlank { back.designation },
            companyName = front.companyName.ifBlank { back.companyName },
            department = front.department.ifBlank { back.department },
            phone = front.phone.ifBlank { back.phone },
            whatsapp = front.whatsapp.ifBlank { back.whatsapp.ifBlank { if (back.phone != front.phone) back.phone else "" } },
            email = front.email.ifBlank { back.email },
            officeAddress = mergedAddress,
            website = front.website.ifBlank { back.website },
            linkedInUrl = front.linkedInUrl.ifBlank { back.linkedInUrl },
            notes = front.notes.ifBlank { back.notes },
            rawOcrText = mergedRawOcr,
            receivedVia = "Dual-Side OCR"
        )
    }

}
