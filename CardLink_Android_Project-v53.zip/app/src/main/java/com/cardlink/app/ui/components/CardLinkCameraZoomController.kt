package com.cardlink.app.ui.components

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.view.MotionEvent
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.view.PreviewView
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import java.util.Locale
import kotlin.math.abs

data class CameraZoomCapabilities(
    val minZoomRatio: Float = 1.0f,
    val maxZoomRatio: Float = 1.0f,
    val hasUltraWideHardware: Boolean = false
) {
    val supportsUltraWidePreset: Boolean
        get() = minZoomRatio <= 0.65f || hasUltraWideHardware

    val supportsCloserPreset: Boolean
        get() = maxZoomRatio >= 1.5f

    val effectiveCloserRatio: Float
        get() = 3.5f.coerceAtMost(maxZoomRatio).coerceAtLeast(1.0f)

    val effectiveWideRatio: Float
        get() = 0.5f.coerceAtLeast(minZoomRatio)
}

/**
 * Shared Hardware-Aware Camera Zoom Controller used across all CardLink CameraX scanners
 * (Business Card OCR, Universal QR Scanner, Loyalty Barcode/QR Scanner).
 */
class CardLinkCameraZoomState {
    var camera by mutableStateOf<Camera?>(null)
        private set

    var capabilities by mutableStateOf(CameraZoomCapabilities())
        private set

    var currentZoomRatio by mutableFloatStateOf(1.0f)
        private set

    fun detectHardwareCapabilities(context: Context): CameraZoomCapabilities {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return CameraZoomCapabilities()
        var hasUltraWide = false
        var minFound = 1.0f
        var maxFound = 1.0f
        runCatching {
            val focalLengths = mutableListOf<Float>()
            for (id in cm.cameraIdList) {
                val chars = cm.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { range ->
                            if (range.lower < minFound) minFound = range.lower
                            if (range.upper > maxFound) maxFound = range.upper
                        }
                    }
                    chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.forEach { fl ->
                        if (fl > 0f) focalLengths.add(fl)
                    }
                }
            }
            if (focalLengths.size >= 2) {
                val minFl = focalLengths.min()
                val maxFl = focalLengths.max()
                if (minFl <= maxFl * 0.65f) hasUltraWide = true
            }
        }
        return CameraZoomCapabilities(
            minZoomRatio = minFound,
            maxZoomRatio = maxFound,
            hasUltraWideHardware = hasUltraWide
        )
    }

    fun bindCamera(context: Context, cam: Camera) {
        camera = cam
        val hwCaps = detectHardwareCapabilities(context)
        val zoomState = cam.cameraInfo.zoomState.value
        val liveMin = zoomState?.minZoomRatio ?: hwCaps.minZoomRatio
        val liveMax = zoomState?.maxZoomRatio ?: hwCaps.maxZoomRatio
        capabilities = CameraZoomCapabilities(
            minZoomRatio = liveMin.coerceAtLeast(0.4f),
            maxZoomRatio = liveMax.coerceAtLeast(1.0f),
            hasUltraWideHardware = hwCaps.hasUltraWideHardware
        )
        setZoomRatio(1.0f)
    }

    fun setZoomRatio(targetRatio: Float) {
        val cam = camera ?: return
        if (targetRatio.isNaN() || targetRatio.isInfinite()) return
        val liveRange = cam.cameraInfo.zoomState.value
        val minR = liveRange?.minZoomRatio ?: capabilities.minZoomRatio
        val maxR = liveRange?.maxZoomRatio ?: capabilities.maxZoomRatio
        val clamped = targetRatio.coerceIn(minR, maxR)
        currentZoomRatio = clamped
        runCatching {
            cam.cameraControl.setZoomRatio(clamped)
        }
    }

    fun applyPinchZoomFactor(zoomChange: Float) {
        if (zoomChange.isNaN() || zoomChange.isInfinite() || zoomChange <= 0f) return
        setZoomRatio(currentZoomRatio * zoomChange)
    }
}

fun PreviewView.attachTapToFocus(zoomState: CardLinkCameraZoomState) {
    setOnTouchListener { v, event ->
        if (event.action == MotionEvent.ACTION_UP) {
            val pt = meteringPointFactory.createPoint(event.x, event.y)
            val action = FocusMeteringAction.Builder(pt).build()
            runCatching { zoomState.camera?.cameraControl?.startFocusAndMetering(action) }
            v.performClick()
        }
        true
    }
}

fun Modifier.cardLinkPinchToZoom(zoomState: CardLinkCameraZoomState): Modifier =
    this.pointerInput(zoomState) {
        detectTransformGestures { _, _, zoomChange, _ ->
            zoomState.applyPinchZoomFactor(zoomChange)
        }
    }

/**
 * Standardized Hardware-Aware Zoom Preset Bar (0.5x | 1x | 3.5x or actual max safe ratio).
 * Synchronizes automatically with pinch-to-zoom gestures and uses active semantic App Theme.
 */
@Composable
fun ScannerZoomPresetBar(
    zoomState: CardLinkCameraZoomState,
    modifier: Modifier = Modifier
) {
    val caps = zoomState.capabilities
    val cur = zoomState.currentZoomRatio

    val presets = remember(caps) {
        buildList {
            if (caps.supportsUltraWidePreset) {
                add(caps.effectiveWideRatio to formatZoomLabel(caps.effectiveWideRatio))
            }
            add(1.0f to "1×")
            if (caps.supportsCloserPreset) {
                val closer = caps.effectiveCloserRatio
                add(closer to formatZoomLabel(closer))
            }
        }
    }

    val matchesAnyPreset = presets.any { (ratio, _) -> abs(cur - ratio) <= 0.08f }
    val zoomA11y = stringResource(R.string.scanner_zoom_label)

    Surface(
        modifier = modifier.semantics { contentDescription = zoomA11y },
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            presets.forEach { (ratio, label) ->
                val isSelected = abs(cur - ratio) <= 0.08f
                Surface(
                    onClick = { zoomState.setZoomRatio(ratio) },
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier
                        .heightIn(min = 36.dp)
                        .semantics {
                            selected = isSelected
                            stateDescription = if (isSelected) "Selected $label" else label
                        }
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (!matchesAnyPreset) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = formatZoomLabel(cur),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

private fun formatZoomLabel(ratio: Float): String {
    val roundedTenths = (ratio * 10f).toInt() / 10f
    return if (abs(roundedTenths - roundedTenths.toInt()) < 0.05f) {
        "${roundedTenths.toInt()}×"
    } else {
        String.format(Locale.US, "%.1f×", roundedTenths)
    }
}
