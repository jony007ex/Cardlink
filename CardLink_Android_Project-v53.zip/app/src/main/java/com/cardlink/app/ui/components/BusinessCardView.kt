package com.cardlink.app.ui.components

import com.cardlink.app.R

import androidx.compose.ui.res.stringResource

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.util.*

private fun resolveFontFamily(fontFamilyName: String): FontFamily = when (fontFamilyName) {
    "Serif" -> FontFamily.Serif
    "Monospace" -> FontFamily.Monospace
    else -> FontFamily.SansSerif
}

/**
 * Renders the Front side of the Business Card using the active template's layout,
 * photo style, typography, and colors — strictly bound to the user's single BusinessCardEntity.
 */
@Composable
fun BusinessCardView(card: BusinessCardEntity, modifier: Modifier = Modifier) {
    val spec = remember(card.selectedTemplateId, card.template) {
        CardTemplateRegistry.resolveForCard(card)
    }

    val bgPrimary = Color(card.primaryColorHex)
    val bgSecondary = Color(card.cardGradientEndHex)
    val accentColor = Color(card.accentColorHex)
    val textColor = Color(card.textColorHex)
    val fontFamily = resolveFontFamily(card.fontFamilyName)
    val corner = card.cornerRadiusDp.dp

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 225.dp)
            .border(
                width = if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 2.dp else 1.2.dp,
                color = accentColor.copy(alpha = if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 0.85f else 0.55f),
                shape = RoundedCornerShape(corner)
            ),
        shape = RoundedCornerShape(corner),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 225.dp)
                .background(Brush.linearGradient(listOf(bgPrimary, bgSecondary)))
        ) {
            // Template-specific decorative geometry (never overlaps readable text)
            TemplateDecorationLayer(
                layoutStyle = spec.layoutStyle,
                accentColor = accentColor,
                modifier = Modifier.matchParentSize()
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = if (spec.layoutStyle == CardLayoutStyle.LEFT_ACCENT_BAR) 26.dp else 20.dp,
                        end = 20.dp,
                        top = if (spec.layoutStyle == CardLayoutStyle.TOP_BAND) 26.dp else 20.dp,
                        bottom = 20.dp
                    ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header Row: Photo (per template photoStyle) + Name/Designation/Company + Optional Logo
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (spec.photoStyle != CardPhotoStyle.NO_PHOTO) {
                        val photoShape = when (spec.photoStyle) {
                            CardPhotoStyle.CIRCLE -> CircleShape
                            CardPhotoStyle.ROUNDED_SQUARE -> RoundedCornerShape(14.dp)
                            CardPhotoStyle.SOFT_RECT -> RoundedCornerShape(10.dp)
                            CardPhotoStyle.NO_PHOTO -> CircleShape
                        }
                        val photoW = if (spec.photoStyle == CardPhotoStyle.SOFT_RECT) 50.dp else 58.dp
                        val photoH = if (spec.photoStyle == CardPhotoStyle.SOFT_RECT) 62.dp else 58.dp

                        if (!card.profilePhotoUri.isNullOrBlank()) {
                            AsyncImage(
                                model = Uri.parse(card.profilePhotoUri),
                                contentDescription = card.fullName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(width = photoW, height = photoH)
                                    .clip(photoShape)
                                    .border(1.5.dp, accentColor, photoShape)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(width = photoW, height = photoH)
                                    .clip(photoShape)
                                    .background(accentColor.copy(alpha = 0.16f))
                                    .border(1.2.dp, accentColor.copy(alpha = 0.7f), photoShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = card.fullName.trim().take(2).uppercase().ifBlank { "CL" },
                                    color = accentColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    fontFamily = fontFamily
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = card.fullName.ifBlank { "Your Name" },
                            color = textColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (card.fullName.length > 26) 17.sp else 19.sp,
                            lineHeight = 23.sp,
                            fontFamily = fontFamily,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (card.designation.isNotBlank()) {
                            Text(
                                text = card.designation,
                                color = accentColor,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp,
                                lineHeight = 16.sp,
                                fontFamily = fontFamily,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        val orgLine = listOf(card.companyName, card.department)
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .joinToString(" • ")
                        if (orgLine.isNotBlank()) {
                            Text(
                                text = orgLine,
                                color = textColor.copy(alpha = 0.8f),
                                fontSize = 11.5.sp,
                                lineHeight = 15.sp,
                                fontFamily = fontFamily,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    if (!card.companyLogoUri.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.92f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            AsyncImage(
                                model = Uri.parse(card.companyLogoUri),
                                contentDescription = card.companyName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(4.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = accentColor.copy(alpha = 0.35f), thickness = 1.dp)

                // Contact Details (Long text & Bangla-safe wrapping)
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    if (card.sharePhone && card.phone.isNotBlank()) {
                        CardDetailRow(Icons.Default.Phone, card.phone, accentColor, textColor, fontFamily)
                    }
                    if (card.shareEmail && card.email.isNotBlank()) {
                        CardDetailRow(Icons.Default.Email, card.email, accentColor, textColor, fontFamily)
                    }
                    if (card.website.isNotBlank()) {
                        CardDetailRow(Icons.Default.Language, card.website, accentColor, textColor, fontFamily)
                    }
                    if (card.shareAddress && card.officeAddress.isNotBlank()) {
                        CardDetailRow(Icons.Default.LocationOn, card.officeAddress, accentColor, textColor, fontFamily, maxLines = 2)
                    }
                }
            }
        }
    }
}

@Composable
private fun CardDetailRow(
    icon: ImageVector,
    value: String,
    accentColor: Color,
    textColor: Color,
    fontFamily: FontFamily,
    maxLines: Int = 1
) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(14.dp).padding(top = 2.dp)
        )
        Text(
            text = value,
            color = textColor.copy(alpha = 0.9f),
            fontSize = 12.sp,
            lineHeight = 16.sp,
            fontFamily = fontFamily,
            maxLines = maxLines,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TemplateDecorationLayer(
    layoutStyle: CardLayoutStyle,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        when (layoutStyle) {
            CardLayoutStyle.LEFT_ACCENT_BAR -> {
                drawRect(
                    color = accentColor,
                    topLeft = Offset.Zero,
                    size = androidx.compose.ui.geometry.Size(width = 8.dp.toPx(), height = size.height)
                )
            }
            CardLayoutStyle.TOP_BAND -> {
                drawRect(
                    color = accentColor,
                    topLeft = Offset.Zero,
                    size = androidx.compose.ui.geometry.Size(width = size.width, height = 7.dp.toPx())
                )
            }
            CardLayoutStyle.SPLIT_PANEL -> {
                drawRect(
                    color = accentColor.copy(alpha = 0.14f),
                    topLeft = Offset(size.width * 0.68f, 0f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.32f, size.height)
                )
            }
            CardLayoutStyle.DIAGONAL_ACCENT -> {
                val p = Path().apply {
                    moveTo(size.width * 0.72f, 0f)
                    lineTo(size.width, 0f)
                    lineTo(size.width, size.height)
                    lineTo(size.width * 0.56f, size.height)
                    close()
                }
                drawPath(p, color = accentColor.copy(alpha = 0.14f))
            }
            CardLayoutStyle.WAVE_CURVE -> {
                val p = Path().apply {
                    moveTo(0f, size.height * 0.78f)
                    cubicTo(
                        size.width * 0.3f, size.height * 0.62f,
                        size.width * 0.7f, size.height * 0.96f,
                        size.width, size.height * 0.72f
                    )
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(p, color = accentColor.copy(alpha = 0.16f))
            }
            CardLayoutStyle.MODERN_FRAME -> {
                val inset = 6.dp.toPx()
                drawLine(accentColor.copy(alpha = 0.4f), Offset(inset, inset), Offset(size.width - inset, inset), strokeWidth = 1.dp.toPx())
                drawLine(accentColor.copy(alpha = 0.4f), Offset(inset, size.height - inset), Offset(size.width - inset, size.height - inset), strokeWidth = 1.dp.toPx())
            }
            else -> Unit
        }
    }
}

/**
 * Coordinated Branded QR Back View matching the Front template's colors, border, geometry, and typography.
 * Strictly preserves a high-contrast white QR card with quiet zone — never shrunk by text.
 */
@Composable
fun BusinessCardBackView(
    card: BusinessCardEntity,
    modifier: Modifier = Modifier,
    showFlipHint: Boolean = true
) {
    val context = LocalContext.current
    val spec = remember(card.selectedTemplateId, card.template) {
        CardTemplateRegistry.resolveForCard(card)
    }
    val brandedQr = remember(card.fullName, card.phone, card.email, card.website, card.companyName, card.primaryColorHex, card.companyLogoUri) {
        PremiumExtrasHelper.generateBrandedQrBitmap(context, card, 420)
    }
    val accentColor = Color(card.accentColorHex)
    val textColor = Color(card.textColorHex)
    val fontFamily = resolveFontFamily(card.fontFamilyName)
    val headingText = card.backHeading.trim().ifBlank { card.companyName.trim().ifBlank { "Card Link" } }
    val messageText = card.backMessage.trim().ifBlank { card.bio.trim() }
    val messageFontSize = when {
        messageText.length > 130 -> 10.5.sp
        messageText.length > 90 -> 11.5.sp
        else -> 12.sp
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 225.dp)
            .border(
                width = if (spec.layoutStyle == CardLayoutStyle.MODERN_FRAME) 2.dp else 1.2.dp,
                color = accentColor.copy(alpha = 0.65f),
                shape = RoundedCornerShape(card.cornerRadiusDp.dp)
            ),
        shape = RoundedCornerShape(card.cornerRadiusDp.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 225.dp)
                .background(Brush.linearGradient(listOf(Color(card.primaryColorHex), Color(card.cardGradientEndHex))))
        ) {
            TemplateDecorationLayer(
                layoutStyle = spec.layoutStyle,
                accentColor = accentColor,
                modifier = Modifier.matchParentSize()
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Scanner-safe high-contrast white QR container with quiet zone
                Surface(shape = RoundedCornerShape(14.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.size(135.dp)) {
                    Image(
                        bitmap = brandedQr.asImageBitmap(),
                        contentDescription = "Branded QR",
                        modifier = Modifier.fillMaxSize().padding(6.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = headingText,
                        color = accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp,
                        fontFamily = fontFamily,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (messageText.isNotBlank()) {
                        Text(
                            text = messageText,
                            color = textColor.copy(alpha = 0.9f),
                            fontSize = messageFontSize,
                            lineHeight = (messageFontSize.value + 3.5f).sp,
                            fontFamily = fontFamily,
                            maxLines = 5,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (showFlipHint) {
                        Text(text = stringResource(R.string.bcv_tap_flip_front),
                            color = accentColor.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FlippableBusinessCardView(
    card: BusinessCardEntity,
    modifier: Modifier = Modifier,
    isFlippedExternal: Boolean? = null,
    onFlipToggle: (() -> Unit)? = null
) {
    var internalFlipped by remember(card.selectedTemplateId) { mutableStateOf(false) }
    val effectiveFlipped = isFlippedExternal ?: internalFlipped
    val toggleAction = onFlipToggle ?: { internalFlipped = !internalFlipped }

    val rotation by animateFloatAsState(
        targetValue = if (effectiveFlipped) 180f else 0f,
        animationSpec = tween(480),
        label = "card_flip"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = if (effectiveFlipped) "Show Front Side" else "Show Back Side"
            }
            .clickable(role = Role.Button, onClick = toggleAction)
            .graphicsLayer { rotationY = rotation; cameraDistance = 14f * density }
    ) {
        if (rotation <= 90f) {
            BusinessCardView(card = card)
        } else {
            BusinessCardBackView(
                card = card,
                modifier = Modifier.graphicsLayer { rotationY = 180f },
                showFlipHint = true
            )
        }
    }
}

/**
 * Lightweight miniature Front/Back preview thumbnail for the 2-column Template Gallery.
 * Avoids generating 20 heavy QR bitmaps simultaneously while still showing the user's real name & company.
 */
@Composable
fun BusinessCardTemplateThumbnail(
    spec: BusinessCardTemplateSpec,
    userName: String,
    userCompany: String,
    modifier: Modifier = Modifier
) {
    val bgPrimary = Color(spec.primaryHex)
    val bgEnd = Color(spec.gradientEndHex)
    val accent = Color(spec.accentHex)
    val text = Color(spec.textHex)
    val fontFamily = resolveFontFamily(spec.typography.fontFamilyKey)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.62f)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(bgPrimary, bgEnd)))
            .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
    ) {
        TemplateDecorationLayer(
            layoutStyle = spec.layoutStyle,
            accentColor = accent,
            modifier = Modifier.matchParentSize()
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (spec.photoStyle != CardPhotoStyle.NO_PHOTO) {
                    val pShape = if (spec.photoStyle == CardPhotoStyle.CIRCLE) CircleShape else RoundedCornerShape(5.dp)
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(pShape)
                            .background(accent.copy(alpha = 0.25f))
                            .border(1.dp, accent, pShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userName.trim().take(1).uppercase().ifBlank { "C" },
                            color = accent,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = userName.ifBlank { "Your Name" },
                        color = text,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        fontFamily = fontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = userCompany.ifBlank { "CardLink" },
                        color = accent,
                        fontSize = 8.sp,
                        fontFamily = fontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.width(46.dp).height(2.5.dp).clip(CircleShape).background(text.copy(alpha = 0.45f)))
                    Box(modifier = Modifier.width(34.dp).height(2.5.dp).clip(CircleShape).background(text.copy(alpha = 0.3f)))
                }
                // Mini QR Back indicator badge
                Surface(shape = RoundedCornerShape(4.dp), color = Color.White, modifier = Modifier.size(18.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.QrCode2, contentDescription = null, tint = Color(0xFF0A192F), modifier = Modifier.size(13.dp))
                    }
                }
            }
        }
    }
}
