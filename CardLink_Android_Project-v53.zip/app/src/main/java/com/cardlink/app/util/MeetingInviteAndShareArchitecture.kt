package com.cardlink.app.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.cardlink.app.data.model.FollowUpEntity
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// =============================================================================
// 1. PLATFORM-NEUTRAL CROSS-PLATFORM SHARE PACKAGE (Zero Android Dependencies)
// =============================================================================

enum class SharePackageType {
    VCF,
    DIGITAL_CARD_LINK,
    QR,
    NFC_NDEF,
    BUSINESS_CARD_IMAGE,
    PDF,
    HTML_CARD,
    ICS,
    MEETING_INVITATION,
    DOCUMENT,
    PLAIN_TEXT
}

@Serializable
data class CardLinkSharePackage(
    val packageType: SharePackageType,
    val title: String,
    val subject: String = "",
    val textBody: String = "",
    val mimeType: String = "text/plain",
    val fileExtension: String = "",
    val recipientEmail: String = "",
    val recipientPhone: String = "",
    val sharingProfileId: String = "BUSINESS"
)

interface CardLinkSharePlatformAdapter {
    val platformName: String
    fun supportsNativeShareSheet(): Boolean
    fun supportsIcsAttachment(): Boolean
}

class AndroidSharePlatformAdapter : CardLinkSharePlatformAdapter {
    override val platformName: String = "Android Sharesheet"
    override fun supportsNativeShareSheet(): Boolean = true
    override fun supportsIcsAttachment(): Boolean = true
}

class FutureIosShareAdapterBlueprint : CardLinkSharePlatformAdapter {
    override val platformName: String = "iOS UIActivityViewController"
    override fun supportsNativeShareSheet(): Boolean = true
    override fun supportsIcsAttachment(): Boolean = true
}

// =============================================================================
// 2. MEETING MODEL & PROVIDER-ADAPTER ARCHITECTURE (No External Cloud APIs!)
// =============================================================================

enum class FollowUpTypeOption(val code: String, val label: String) {
    MEETING("MEETING", "Meeting"),
    CALL("CALL", "Call"),
    WHATSAPP("WHATSAPP", "WhatsApp"),
    EMAIL("EMAIL", "Email"),
    SEND_DOCUMENT("SEND_DOCUMENT", "Send Document"),
    GENERAL("GENERAL", "General Follow-Up")
}

enum class MeetingMethodOption(val code: String, val label: String, val expectsOnlineLink: Boolean) {
    IN_PERSON("IN_PERSON", "In Person", false),
    PHONE("PHONE", "Phone", false),
    TEAMS("TEAMS", "Microsoft Teams", true),
    ZOOM("ZOOM", "Zoom", true),
    GOOGLE_MEET("GOOGLE_MEET", "Google Meet", true),
    OTHER_ONLINE("OTHER_ONLINE", "Other Online", true),
    CUSTOM_LINK("CUSTOM_LINK", "Custom Link", true)
}

/**
 * Clean extension boundary so future Teams / Zoom / Google Meet / Graph providers can plug in
 * without redesigning Contacts, Follow-Ups, or Calendar screens.
 */
interface MeetingProviderAdapter {
    val providerId: String
    val displayName: String
    val requiresExternalApi: Boolean
    fun isAvailableLocally(context: Context): Boolean
}

class DeviceCalendarMeetingAdapter : MeetingProviderAdapter {
    override val providerId: String = "device_calendar"
    override val displayName: String = "Device Calendar"
    override val requiresExternalApi: Boolean = false
    override fun isAvailableLocally(context: Context): Boolean = DeviceCalendarSyncManager.hasCalendarPermission(context)
}

class EmailIcsMeetingAdapter : MeetingProviderAdapter {
    override val providerId: String = "email_ics"
    override val displayName: String = "Email & .ics Calendar File"
    override val requiresExternalApi: Boolean = false
    override fun isAvailableLocally(context: Context): Boolean = true
}

// =============================================================================
// 3. RFC 5545 .ICS GENERATOR & EDITABLE EMAIL INVITATION HANDOFF
// =============================================================================

object MeetingInviteHelper {

    fun isValidMeetingUrl(raw: String): Boolean {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return true // Optional field
        return trimmed.startsWith("https://", ignoreCase = true) || trimmed.startsWith("http://", ignoreCase = true)
    }

    private fun escapeIcs(raw: String): String = raw
        .replace("\\", "\\\\")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
        .replace(",", "\\,")
        .replace(";", "\\;")

    fun generateIcsContent(followUp: FollowUpEntity, organizerName: String): String {
        val utcFmt = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val uid = followUp.followUpUuid.ifBlank { java.util.UUID.randomUUID().toString() }
        val dtStamp = utcFmt.format(Date())
        val dtStart = utcFmt.format(Date(followUp.dueAtTimestamp))
        val dtEnd = utcFmt.format(Date(followUp.dueAtTimestamp + 30L * 60_000L))

        val methodLabel = MeetingMethodOption.values().firstOrNull { it.code == followUp.meetingMethod }?.label ?: "Meeting"
        val location = followUp.meetingLink.ifBlank { followUp.companyName.ifBlank { methodLabel } }
        val desc = buildString {
            append("Method: $methodLabel")
            if (followUp.meetingAgenda.isNotBlank()) append("\nAgenda: ${followUp.meetingAgenda}")
            if (followUp.meetingLink.isNotBlank()) append("\nMeeting Link: ${followUp.meetingLink}")
            if (organizerName.isNotBlank()) append("\nOrganizer: $organizerName")
        }

        val lines = mutableListOf(
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//CardLink//Meeting Invitation//EN",
            "CALSCALE:GREGORIAN",
            "METHOD:PUBLISH",
            "BEGIN:VEVENT",
            "UID:$uid@cardlink.app",
            "DTSTAMP:$dtStamp",
            "DTSTART:$dtStart",
            "DTEND:$dtEnd",
            "SUMMARY:${escapeIcs(followUp.title.ifBlank { "Meeting with ${followUp.contactName}" })}",
            "LOCATION:${escapeIcs(location)}",
            "DESCRIPTION:${escapeIcs(desc)}"
        )
        if (followUp.meetingLink.isNotBlank()) {
            lines += "URL:${followUp.meetingLink.trim()}"
        }
        lines += "END:VEVENT"
        lines += "END:VCALENDAR"
        return lines.joinToString("\r\n") + "\r\n"
    }

    fun buildDefaultEmailDraft(followUp: FollowUpEntity, senderName: String): Pair<String, String> {
        val dateFmt = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault())
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val methodLabel = MeetingMethodOption.values().firstOrNull { it.code == followUp.meetingMethod }?.label ?: "In Person"
        val locationOrLink = followUp.meetingLink.ifBlank { followUp.companyName.ifBlank { methodLabel } }

        val subject = "Meeting Invitation – ${followUp.title.ifBlank { followUp.contactName }}"
        val body = buildString {
            appendLine("Dear ${followUp.contactName.ifBlank { "Sir/Madam" }},")
            appendLine()
            appendLine("Please find the proposed meeting details below:")
            appendLine()
            appendLine("Date: ${dateFmt.format(Date(followUp.dueAtTimestamp))}")
            appendLine("Time: ${timeFmt.format(Date(followUp.dueAtTimestamp))}")
            appendLine("Method: $methodLabel")
            appendLine("Location / Meeting Link: $locationOrLink")
            if (followUp.meetingAgenda.isNotBlank()) {
                appendLine("Agenda: ${followUp.meetingAgenda}")
            }
            appendLine()
            appendLine("Best regards,")
            append(senderName.ifBlank { "CardLink User" })
        }
        return subject to body
    }

    /**
     * Prepares a verified temporary .ics file in TempSecureExportVault and opens Android's Email / Share handoff.
     * Never sends email automatically — the user always reviews and taps Send in their email app.
     */
    fun launchEmailWithOptionalIcs(
        context: Context,
        recipientEmail: String,
        subject: String,
        body: String,
        followUp: FollowUpEntity,
        organizerName: String,
        attachIcs: Boolean
    ) {
        if (!attachIcs) {
            val mailto = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${recipientEmail.trim()}")).apply {
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(mailto) }.onFailure {
                val fallback = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, subject)
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                runCatching { context.startActivity(Intent.createChooser(fallback, "Prepare Meeting Email").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            SecurityHardeningManager.logAuditEventAsync(context, "MEETING_INVITE_PREPARED", "Calendar", true, "Meeting email handoff opened")
            return
        }

        val icsText = generateIcsContent(followUp, organizerName)
        val slug = followUp.title.trim().replace(Regex("\\s+"), "_").replace(Regex("[^a-zA-Z0-9_-]"), "").ifBlank { "Meeting" }
        val icsFile = TempSecureExportVault.createNamedTempExportFile(context, "CardLink_$slug", "ics")
        val uri = runCatching {
            icsFile.writeText(icsText, Charsets.UTF_8)
            val u = TempSecureExportVault.toShareUri(context, icsFile)
            val verify = context.contentResolver.openInputStream(u)?.use { it.bufferedReader(Charsets.UTF_8).readText() }.orEmpty()
            require(verify.contains("BEGIN:VCALENDAR") && verify.contains("END:VCALENDAR"))
            u
        }.getOrNull()

        if (uri == null) {
            Toast.makeText(context, "Could not prepare .ics calendar attachment.", Toast.LENGTH_LONG).show()
            return
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/calendar"
            if (recipientEmail.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(recipientEmail.trim()))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(icsFile.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, "Send Meeting Invitation (.ics)").apply {
            clipData = ClipData.newRawUri(icsFile.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching {
            context.startActivity(chooser)
            SecurityHardeningManager.logAuditEventAsync(context, "MEETING_ICS_PREPARED", "Calendar", true, "Meeting .ics invitation handoff opened")
        }.onFailure {
            Toast.makeText(context, "No compatible email or calendar app found.", Toast.LENGTH_LONG).show()
        }
    }
}
