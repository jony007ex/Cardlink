package com.cardlink.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkWidgetUpdater
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CardLinkViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CardLinkDatabase.getDatabase(application).dao()

    val myCards: StateFlow<List<BusinessCardEntity>> = dao.getAllMyCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCard: StateFlow<BusinessCardEntity> = myCards.map { list ->
        val card = list.firstOrNull { it.isDefault } ?: list.firstOrNull() ?: defaultSeedCard()
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(card)
        CardLinkHceService.activeShareUrl = card.resolveNfcShareUrl()
        card
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), defaultSeedCard())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val contacts: StateFlow<List<SavedContactEntity>> = _searchQuery
        .flatMapLatest { q -> dao.searchContacts(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allContacts: StateFlow<List<SavedContactEntity>> = dao.getAllContactsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalContactsCount: StateFlow<Int> = dao.getTotalContactsCountFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val favoriteContactsCount: StateFlow<Int> = dao.getFavoriteContactsCountFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _deviceSyncMessage = MutableStateFlow<String?>(null)
    val deviceSyncMessage: StateFlow<String?> = _deviceSyncMessage.asStateFlow()

    fun clearDeviceSyncMessage() {
        _deviceSyncMessage.value = null
    }

    fun toggleContactFavorite(contact: SavedContactEntity) {
        viewModelScope.launch {
            dao.upsertContact(contact.copy(isFavorite = !contact.isFavorite))
        }
    }

    val shareHistory: StateFlow<List<ShareHistoryEntity>> = dao.getShareHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val followUps: StateFlow<List<FollowUpEntity>> = dao.getAllFollowUpsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loyaltyCards: StateFlow<List<LoyaltyCardEntity>> = dao.getAllLoyaltyCardsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val idDocuments: StateFlow<List<IdDocumentEntity>> = dao.getAllIdDocumentsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val idPages: StateFlow<List<IdDocumentPageEntity>> = dao.getAllIdPagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val qrProjects: StateFlow<List<QrProjectEntity>> = dao.getAllQrProjectsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val qrDesignPresets: StateFlow<List<QrDesignPresetEntity>> = dao.getAllQrDesignPresetsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val qrScanHistory: StateFlow<List<QrScanHistoryEntity>> = dao.getAllQrScanHistoryFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val securityAuditLogs: StateFlow<List<SecurityAuditLogEntity>> = dao.getSecurityAuditLogsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val secureNotes: StateFlow<List<SecureNoteEntity>> = dao.getAllSecureNotesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nfcProjects: StateFlow<List<NfcProjectEntity>> = dao.getAllNfcProjectsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recycleBinItems: StateFlow<List<RecycleBinEntity>> = dao.getAllRecycleBinFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conferenceQueue: StateFlow<List<ConferenceQueueEntity>> = dao.getAllConferenceQueueFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingDrafts: StateFlow<List<PendingDraftEntity>> = dao.getAllPendingDraftsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _favoriteToolIds = MutableStateFlow(UxExperiencePrefs.getFavoriteToolIds(application))
    val favoriteToolIds: StateFlow<List<String>> = _favoriteToolIds.asStateFlow()

    private val _recentToolIds = MutableStateFlow(UxExperiencePrefs.getRecentToolIds(application))
    val recentToolIds: StateFlow<List<String>> = _recentToolIds.asStateFlow()

    private val _hasUnseenWhatsNew = MutableStateFlow(ReleaseNotesRepository.hasUnseenReleaseNotes(application))
    val hasUnseenWhatsNew: StateFlow<Boolean> = _hasUnseenWhatsNew.asStateFlow()

    private val _saveScanHistoryEnabled = MutableStateFlow(
        application.getSharedPreferences("cardlink_qr_scanner_prefs", android.content.Context.MODE_PRIVATE)
            .getBoolean("save_scan_history", true)
    )
    val saveScanHistoryEnabled: StateFlow<Boolean> = _saveScanHistoryEnabled.asStateFlow()

    private val _appCustomTheme = MutableStateFlow(ThemeContrastHelper.loadAppTheme(application))
    val appCustomTheme: StateFlow<AppCustomThemeConfig> = _appCustomTheme

    private val _darkThemeOverride = MutableStateFlow<Boolean?>(LanguageManager.getSavedThemeOverride(application))
    val darkThemeOverride: StateFlow<Boolean?> = _darkThemeOverride

    private val _appLanguage = MutableStateFlow(LanguageManager.getSavedLanguage(application))
    val appLanguage: StateFlow<String> = _appLanguage

    private val _notificationsEnabled = MutableStateFlow(LanguageManager.isNotificationsEnabled(application))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled

    private val _quickPrivacyMode = MutableStateFlow(false)
    val quickPrivacyMode: StateFlow<Boolean> = _quickPrivacyMode

    private val _eventMode = MutableStateFlow(EventModeHelper.load(application))
    val eventMode: StateFlow<EventModeConfig> = _eventMode

    init {
        viewModelScope.launch {
            cleanupDuplicateProfiles()
            if (dao.getAllMyCardsSnapshot().isEmpty()) {
                dao.upsertMyCard(defaultSeedCard())
            }
            FollowUpScheduler.rescheduleAllPending(getApplication())
            IdExpiryReminderScheduler.rescheduleAll(getApplication())
        }
    }

    private fun isUntouchedSeedCard(c: BusinessCardEntity): Boolean {
        return c.phone == "+880 1700-000000" && c.email == "contact@cardlink.app"
    }

    private suspend fun cleanupDuplicateProfiles() {
        val all = dao.getAllMyCardsSnapshot()
        if (all.size <= 1) return

        val nonSeed = all.filterNot { isUntouchedSeedCard(it) }
        val toDelete = mutableListOf<BusinessCardEntity>()

        // If user has any real edited profile, remove untouched default seed duplicates
        if (nonSeed.isNotEmpty()) {
            toDelete.addAll(all.filter { isUntouchedSeedCard(it) })
        }

        val remaining = all - toDelete.toSet()
        val seenKeys = mutableSetOf<String>()
        for (card in remaining) {
            val key = listOf(
                card.profileTitle.trim().lowercase(),
                card.fullName.trim().lowercase(),
                card.phone.filter { it.isDigit() },
                card.email.trim().lowercase()
            ).joinToString("|")
            if (!seenKeys.add(key)) {
                toDelete.add(card)
            }
        }

        toDelete.forEach { dao.deleteMyCard(it) }

        val finalCards = dao.getAllMyCardsSnapshot()
        if (finalCards.isNotEmpty() && finalCards.none { it.isDefault }) {
            dao.setActiveCard(finalCards.first().id)
        }
    }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }

    fun saveCard(card: BusinessCardEntity) {
        viewModelScope.launch {
            var enriched = card
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val id = dao.upsertMyCard(enriched)
            if (enriched.isDefault) dao.setActiveCard(if (enriched.id == 0L) id else enriched.id)
            val activeProf = SharingProfileManager.getActiveProfile(getApplication())
            val projected = SharingProfileManager.applyProfile(enriched, activeProf)
            CardLinkHceService.activeShareUrl = projected.resolveNfcShareUrl()
            CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(projected)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun saveAppCustomTheme(appTheme: AppCustomThemeConfig) {
        ThemeContrastHelper.saveAppTheme(getApplication(), appTheme)
        _appCustomTheme.value = appTheme
        viewModelScope.launch { CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun refreshWidgetsAndHce() {
        viewModelScope.launch {
            val activeProf = SharingProfileManager.getActiveProfile(getApplication())
            val projected = SharingProfileManager.applyProfile(activeCard.value, activeProf)
            CardLinkHceService.activeShareUrl = projected.resolveNfcShareUrl()
            CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(projected)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun saveCardAndAppTheme(card: BusinessCardEntity, appTheme: AppCustomThemeConfig) {
        viewModelScope.launch {
            ThemeContrastHelper.saveAppTheme(getApplication(), appTheme)
            _appCustomTheme.value = appTheme
            saveCard(card)
        }
    }

    fun resetCardAndAppThemeToDefaults(): Pair<BusinessCardEntity, AppCustomThemeConfig> {
        val defApp = ThemeContrastHelper.resetAppTheme(getApplication())
        _appCustomTheme.value = defApp
        val defCard = activeCard.value.copy(
            template = CardTemplate.EXECUTIVE_NAVY, primaryColorHex = 0xFF0A192F, secondaryColorHex = 0xFF112240,
            accentColorHex = 0xFFD4AF37, textColorHex = 0xFFFFFFFF, buttonColorHex = 0xFFD4AF37,
            iconColorHex = 0xFFD4AF37, cardGradientEndHex = 0xFF172A46, fontFamilyName = "Serif"
        )
        saveCard(defCard)
        return Pair(defCard, defApp)
    }

    fun switchActiveProfile(cardId: Long) {
        viewModelScope.launch {
            dao.setActiveCard(cardId)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun activateEventMode(eventName: String, location: String) {
        val cfg = EventModeConfig(
            isActive = true,
            eventName = eventName.trim(),
            location = location.trim(),
            startedAtTimestamp = System.currentTimeMillis()
        )
        EventModeHelper.save(getApplication(), cfg)
        _eventMode.value = cfg
    }

    fun deactivateEventMode() {
        val cfg = _eventMode.value.copy(isActive = false)
        EventModeHelper.save(getApplication(), cfg)
        _eventMode.value = cfg
    }

    fun saveReceivedContact(contact: SavedContactEntity, updatePendingWaNumberTo: String? = null) {
        viewModelScope.launch {
            val isNewContact = contact.id == 0L
            var enriched = if (isNewContact) {
                EventModeHelper.applyIfActive(contact, _eventMode.value)
            } else contact
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val savedId = dao.upsertContact(enriched)
            val targetId = if (enriched.id != 0L) enriched.id else savedId
            val persistedContact = enriched.copy(id = targetId)

            if (!updatePendingWaNumberTo.isNullOrBlank()) {
                dao.getPendingWhatsAppFollowUpsForContact(targetId).forEach { fu ->
                    val updatedFu = fu.copy(whatsappNumber = updatePendingWaNumberTo)
                    dao.upsertFollowUp(updatedFu)
                    FollowUpScheduler.scheduleForItem(getApplication(), updatedFu)
                }
            }

            // Optional User-Controlled Auto Save to Phone Contacts (Default: OFF)
            val appCtx = getApplication<Application>()
            if (isNewContact && DeviceContactSyncManager.isAutoSaveEnabled(appCtx)) {
                when (val outcome = DeviceContactSyncManager.syncContactToPhone(appCtx, persistedContact)) {
                    is DeviceContactSyncOutcome.Synced -> {
                        dao.upsertContact(
                            persistedContact.copy(
                                linkedDeviceContactId = outcome.deviceContactId,
                                deviceContactSyncState = "SYNCED",
                                lastDeviceContactSyncAt = System.currentTimeMillis()
                            )
                        )
                        _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_saved_both_msg)
                    }
                    is DeviceContactSyncOutcome.DuplicateFound -> {
                        dao.upsertContact(
                            persistedContact.copy(
                                linkedDeviceContactId = outcome.existingDeviceId,
                                deviceContactSyncState = "DUPLICATE_REVIEW"
                            )
                        )
                        _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_phone_dup_msg)
                    }
                    is DeviceContactSyncOutcome.PermissionMissing,
                    is DeviceContactSyncOutcome.Failed -> {
                        dao.upsertContact(persistedContact.copy(deviceContactSyncState = "FAILED"))
                        _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_phone_sync_failed_msg)
                    }
                    DeviceContactSyncOutcome.Disabled -> Unit
                }
            }
        }
    }

    fun syncSingleContactToPhone(
        contact: SavedContactEntity,
        forceCreateNew: Boolean = false,
        updateTargetDeviceId: String? = null
    ) {
        viewModelScope.launch {
            val appCtx = getApplication<Application>()
            when (val outcome = DeviceContactSyncManager.syncContactToPhone(appCtx, contact, forceCreateNew, updateTargetDeviceId)) {
                is DeviceContactSyncOutcome.Synced -> {
                    dao.upsertContact(
                        contact.copy(
                            linkedDeviceContactId = outcome.deviceContactId,
                            deviceContactSyncState = "SYNCED",
                            lastDeviceContactSyncAt = System.currentTimeMillis()
                        )
                    )
                    _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_saved_both_msg)
                }
                is DeviceContactSyncOutcome.DuplicateFound -> {
                    dao.upsertContact(
                        contact.copy(
                            linkedDeviceContactId = outcome.existingDeviceId,
                            deviceContactSyncState = "DUPLICATE_REVIEW"
                        )
                    )
                    _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_phone_dup_msg)
                }
                else -> {
                    _deviceSyncMessage.value = appCtx.getString(com.cardlink.app.R.string.contacts_phone_sync_failed_msg)
                }
            }
        }
    }

    fun deleteContact(contact: SavedContactEntity) {
        viewModelScope.launch {
            val moved = moveToRecycleBin(
                "CONTACT",
                contact.fullName.ifBlank { "Contact" },
                kotlinx.serialization.json.Json.encodeToString(SavedContactEntity.serializer(), contact)
            )
            if (!moved) {
                deleteContactImages(contact)
            }
            dao.deleteContact(contact)
        }
    }

    private fun deleteContactImages(contact: SavedContactEntity) {
        ScannedCardStorageHelper.deleteSavedCardImage(contact.profilePhotoUri)
        ScannedCardStorageHelper.deleteSavedCardImage(contact.backPhotoUri)
        ScannedCardStorageHelper.deleteSavedCardImage(contact.frontOriginalPhotoUri)
        ScannedCardStorageHelper.deleteSavedCardImage(contact.backOriginalPhotoUri)
    }

    fun saveFollowUp(item: FollowUpEntity) {
        viewModelScope.launch {
            val id = dao.upsertFollowUp(item)
            FollowUpScheduler.scheduleForItem(getApplication(), item.copy(id = if (item.id == 0L) id else item.id))
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun toggleFollowUpCompleted(item: FollowUpEntity) {
        viewModelScope.launch {
            val nextDone = !item.isCompleted
            val updated = item.copy(isCompleted = nextDone, status = if (nextDone) FollowUpStatus.COMPLETED.name else FollowUpStatus.PENDING.name)
            dao.upsertFollowUp(updated)
            if (nextDone) FollowUpScheduler.cancelForItem(getApplication(), updated.id) else FollowUpScheduler.scheduleForItem(getApplication(), updated)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun cancelFollowUp(item: FollowUpEntity) {
        viewModelScope.launch { FollowUpScheduler.cancelForItem(getApplication(), item.id); dao.upsertFollowUp(item.copy(status = FollowUpStatus.CANCELLED.name)); CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun deleteFollowUp(item: FollowUpEntity) {
        viewModelScope.launch {
            FollowUpScheduler.cancelForItem(getApplication(), item.id)
            DeviceCalendarSyncManager.deleteSyncedEvent(getApplication(), item)
            dao.deleteFollowUp(item)
            CardLinkWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun saveLoyaltyCard(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val toSave = if (card.id == 0L) {
                card.copy(createdAtTimestamp = now, updatedAtTimestamp = now)
            } else {
                card.copy(updatedAtTimestamp = now)
            }
            dao.upsertLoyaltyCard(toSave)
        }
    }

    fun toggleLoyaltyCardFavorite(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            dao.upsertLoyaltyCard(card.copy(isFavorite = !card.isFavorite, updatedAtTimestamp = System.currentTimeMillis()))
        }
    }

    fun recordLoyaltyCardUsed(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            dao.upsertLoyaltyCard(
                card.copy(
                    lastUsedTimestamp = System.currentTimeMillis(),
                    usageCount = card.usageCount + 1
                )
            )
        }
    }

    fun deleteLoyaltyCard(card: LoyaltyCardEntity) {
        viewModelScope.launch {
            val moved = moveToRecycleBin(
                "LOYALTY_CARD",
                card.brandName.ifBlank { "Loyalty Card" },
                kotlinx.serialization.json.Json.encodeToString(LoyaltyCardEntity.serializer(), card)
            )
            if (!moved) {
                ScannedCardStorageHelper.deleteSavedCardImage(card.frontPhotoUri)
                ScannedCardStorageHelper.deleteSavedCardImage(card.backPhotoUri)
            }
            dao.deleteLoyaltyCard(card)
        }
    }

    fun saveIdDocument(doc: IdDocumentEntity, pages: List<IdDocumentPageEntity>) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val toSave = if (doc.id == 0L) {
                doc.copy(createdAtTimestamp = now, updatedAtTimestamp = now)
            } else {
                doc.copy(updatedAtTimestamp = now)
            }
            dao.upsertIdDocument(toSave)
            dao.deletePagesForDocument(toSave.stableUuid)
            if (pages.isNotEmpty()) {
                val normalized = pages.mapIndexed { idx, p ->
                    p.copy(id = 0L, documentUuid = toSave.stableUuid, pageIndex = idx)
                }
                dao.insertIdPagesBatch(normalized)
            }
            // Always cancel old reminders and schedule only applicable future reminders for confirmed expiry date
            IdExpiryReminderScheduler.scheduleForDocument(getApplication(), toSave)
        }
    }

    fun deleteIdDocument(doc: IdDocumentEntity) {
        viewModelScope.launch {
            IdExpiryReminderScheduler.cancelForDocument(getApplication(), doc.stableUuid)
            val existingPages = dao.getPagesForDocumentSnapshot(doc.stableUuid)
            val bundleJson = kotlinx.serialization.json.Json.encodeToString(
                ArchivedIdDocumentBundle.serializer(),
                ArchivedIdDocumentBundle(document = doc, pages = existingPages)
            )
            val moved = moveToRecycleBin("ID_DOCUMENT", doc.documentName.ifBlank { "ID Document" }, bundleJson)
            if (!moved) {
                existingPages.forEach { ScannedCardStorageHelper.deleteSavedCardImage(it.imageUri) }
            }
            dao.deletePagesForDocument(doc.stableUuid)
            dao.deleteIdDocument(doc)
        }
    }

    fun saveQrProject(project: QrProjectEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val toSave = if (project.id == 0L) {
                project.copy(createdAtTimestamp = now, updatedAtTimestamp = now)
            } else {
                project.copy(updatedAtTimestamp = now)
            }
            dao.upsertQrProject(toSave)
        }
    }

    fun duplicateQrProject(source: QrProjectEntity) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val copy = source.copy(
                id = 0L,
                stableUuid = java.util.UUID.randomUUID().toString(),
                name = "${source.name} (Copy)",
                isFavorite = false,
                createdAtTimestamp = now,
                updatedAtTimestamp = now
            )
            dao.upsertQrProject(copy)
        }
    }

    fun toggleQrProjectFavorite(project: QrProjectEntity) {
        viewModelScope.launch {
            dao.upsertQrProject(project.copy(isFavorite = !project.isFavorite, updatedAtTimestamp = System.currentTimeMillis()))
        }
    }

    fun deleteQrProject(project: QrProjectEntity) {
        viewModelScope.launch {
            moveToRecycleBin(
                "QR_PROJECT",
                project.name.ifBlank { "QR Project" },
                kotlinx.serialization.json.Json.encodeToString(QrProjectEntity.serializer(), project)
            )
            dao.deleteQrProject(project)
        }
    }

    fun saveQrDesignPreset(name: String, designConfigJson: String) {
        viewModelScope.launch {
            dao.upsertQrDesignPreset(
                QrDesignPresetEntity(
                    name = name.trim(),
                    designConfigJson = designConfigJson,
                    createdAtTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun deleteQrDesignPreset(preset: QrDesignPresetEntity) {
        viewModelScope.launch {
            dao.deleteQrDesignPreset(preset)
        }
    }

    fun setSaveScanHistoryEnabled(enabled: Boolean) {
        getApplication<Application>()
            .getSharedPreferences("cardlink_qr_scanner_prefs", android.content.Context.MODE_PRIVATE)
            .edit()
            .putBoolean("save_scan_history", enabled)
            .apply()
        _saveScanHistoryEnabled.value = enabled
    }

    fun recordQrScan(parsed: ParsedUniversalQr) {
        if (!_saveScanHistoryEnabled.value) return
        if (parsed.rawPayload.isBlank()) return
        viewModelScope.launch {
            val hash = UniversalQrParser.sha256Hex(parsed.rawPayload)
            val existing = dao.getQrScanHistoryByHash(hash)
            val now = System.currentTimeMillis()
            if (existing != null) {
                dao.upsertQrScanHistory(existing.copy(scannedAtTimestamp = now))
            } else {
                dao.upsertQrScanHistory(
                    QrScanHistoryEntity(
                        detectedType = parsed.type.name,
                        displayTitle = parsed.displayTitle.ifBlank { parsed.type.label },
                        rawPayload = parsed.rawPayload,
                        payloadHash = hash,
                        isSensitive = parsed.isSensitive,
                        scannedAtTimestamp = now
                    )
                )
            }
        }
    }

    fun toggleQrScanHistoryFavorite(entry: QrScanHistoryEntity) {
        viewModelScope.launch {
            dao.upsertQrScanHistory(entry.copy(isFavorite = !entry.isFavorite))
        }
    }

    fun deleteQrScanHistory(entry: QrScanHistoryEntity) {
        viewModelScope.launch { dao.deleteQrScanHistory(entry) }
    }

    fun clearAllQrScanHistory() {
        viewModelScope.launch { dao.clearAllQrScanHistory() }
    }

    fun saveSecureNote(note: SecureNoteEntity) {
        viewModelScope.launch { dao.upsertSecureNote(note) }
    }

    fun deleteSecureNote(note: SecureNoteEntity) {
        viewModelScope.launch {
            moveToRecycleBin(
                "SECURE_NOTE",
                note.title.ifBlank { "Secure Note" },
                kotlinx.serialization.json.Json.encodeToString(SecureNoteEntity.serializer(), note)
            )
            dao.deleteSecureNote(note)
        }
    }

    fun clearSecurityAuditLogs() {
        viewModelScope.launch { dao.clearAllSecurityAuditLogs() }
    }

    fun saveNfcProject(project: NfcProjectEntity) {
        viewModelScope.launch {
            dao.upsertNfcProject(project.copy(updatedAtTimestamp = System.currentTimeMillis()))
        }
    }

    fun deleteNfcProject(project: NfcProjectEntity) {
        viewModelScope.launch {
            moveToRecycleBin("NFC_PROJECT", project.name, kotlinx.serialization.json.Json.encodeToString(NfcProjectEntity.serializer(), project))
            dao.deleteNfcProject(project)
        }
    }

    private fun cleanupRecycleBinItemMedia(item: RecycleBinEntity) {
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        runCatching {
            when (item.entityType) {
                "CONTACT" -> {
                    val c = json.decodeFromString(SavedContactEntity.serializer(), item.payloadJson)
                    deleteContactImages(c)
                }
                "LOYALTY_CARD" -> {
                    val lc = json.decodeFromString(LoyaltyCardEntity.serializer(), item.payloadJson)
                    ScannedCardStorageHelper.deleteSavedCardImage(lc.frontPhotoUri)
                    ScannedCardStorageHelper.deleteSavedCardImage(lc.backPhotoUri)
                }
                "ID_DOCUMENT" -> {
                    val bundle = json.decodeFromString(ArchivedIdDocumentBundle.serializer(), item.payloadJson)
                    bundle.pages.forEach { ScannedCardStorageHelper.deleteSavedCardImage(it.imageUri) }
                }
                else -> Unit
            }
        }
    }

    private suspend fun moveToRecycleBin(type: String, title: String, payloadJson: String): Boolean {
        val days = SharingProfileManager.getRecycleBinRetentionDays(getApplication())
        if (days <= 0) return false
        val now = System.currentTimeMillis()
        dao.insertRecycleBinItem(
            RecycleBinEntity(
                entityType = type,
                displayTitle = title,
                payloadJson = payloadJson,
                deletedAtTimestamp = now,
                expiresAtTimestamp = now + days.toLong() * 24L * 3600_000L
            )
        )
        dao.getExpiredRecycleBinSnapshot(now).forEach { cleanupRecycleBinItemMedia(it) }
        dao.pruneExpiredRecycleBin(now)
        return true
    }

    fun restoreRecycleBinItem(item: RecycleBinEntity) {
        viewModelScope.launch {
            val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
            runCatching {
                when (item.entityType) {
                    "CONTACT" -> dao.upsertContact(json.decodeFromString(SavedContactEntity.serializer(), item.payloadJson).copy(id = 0L))
                    "LOYALTY_CARD" -> dao.upsertLoyaltyCard(json.decodeFromString(LoyaltyCardEntity.serializer(), item.payloadJson).copy(id = 0L))
                    "SECURE_NOTE" -> dao.upsertSecureNote(json.decodeFromString(SecureNoteEntity.serializer(), item.payloadJson).copy(id = 0L))
                    "QR_PROJECT" -> dao.upsertQrProject(json.decodeFromString(QrProjectEntity.serializer(), item.payloadJson).copy(id = 0L))
                    "NFC_PROJECT" -> dao.upsertNfcProject(json.decodeFromString(NfcProjectEntity.serializer(), item.payloadJson).copy(id = 0L))
                    "ID_DOCUMENT" -> {
                        val bundle = json.decodeFromString(ArchivedIdDocumentBundle.serializer(), item.payloadJson)
                        val restoredDoc = bundle.document.copy(id = 0L)
                        dao.upsertIdDocument(restoredDoc)
                        if (bundle.pages.isNotEmpty()) {
                            dao.insertIdPagesBatch(bundle.pages.map { it.copy(id = 0L) })
                        }
                        IdExpiryReminderScheduler.scheduleForDocument(getApplication(), restoredDoc)
                    }
                    else -> Unit
                }
            }
            dao.deleteRecycleBinItem(item)
        }
    }

    fun deleteRecycleBinItemPermanently(item: RecycleBinEntity) {
        viewModelScope.launch {
            cleanupRecycleBinItemMedia(item)
            dao.deleteRecycleBinItem(item)
        }
    }

    fun emptyRecycleBin() {
        viewModelScope.launch {
            dao.getAllRecycleBinSnapshot().forEach { cleanupRecycleBinItemMedia(it) }
            dao.clearAllRecycleBin()
        }
    }

    /**
     * Captures a business card into the persistent encrypted Conference Queue and runs OCR asynchronously in background.
     */
    fun enqueueConferenceCardBitmap(bitmap: android.graphics.Bitmap) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val ev = _eventMode.value
            val encryptedUri = ScannedCardStorageHelper.saveEncryptedScannedCard(getApplication(), bitmap, "conf_card")
            val initialId = dao.upsertConferenceQueueItem(
                ConferenceQueueEntity(
                    eventName = ev.eventName,
                    eventLocation = ev.location,
                    encryptedFrontUri = encryptedUri,
                    queueStatus = "PROCESSING"
                )
            )
            val json = kotlinx.serialization.json.Json { encodeDefaults = true; ignoreUnknownKeys = true }
            runCatching {
                val visionText = OcrEngineRegistry.recognizeBitmap(getApplication(), bitmap)
                val model = CardOcrPipeline.extractContactWithConfidence(visionText)
                val enriched = model.contact.copy(
                    profilePhotoUri = encryptedUri,
                    meetingContext = if (ev.eventName.isNotBlank()) "Conference: ${ev.eventName}" else "",
                    categoryTag = if (ev.isActive) "Event" else "General"
                )
                val existing = dao.getAllContactsSnapshot()
                val normPhone = CardOcrPipeline.normalizeBangladeshPhone(enriched.phone)
                val normEmail = enriched.email.trim().lowercase()
                val dup = existing.firstOrNull { ex ->
                    (normPhone.length >= 8 && CardOcrPipeline.normalizeBangladeshPhone(ex.phone) == normPhone) ||
                        (normEmail.isNotBlank() && ex.email.trim().lowercase() == normEmail)
                }
                val status = when {
                    dup != null -> "POSSIBLE_DUPLICATE"
                    model.isReadyToBatchSave -> "READY"
                    else -> "NEEDS_REVIEW"
                }
                dao.upsertConferenceQueueItem(
                    ConferenceQueueEntity(
                        id = initialId,
                        eventName = ev.eventName,
                        eventLocation = ev.location,
                        encryptedFrontUri = encryptedUri,
                        queueStatus = status,
                        parsedContactJson = json.encodeToString(SavedContactEntity.serializer(), enriched),
                        suggestedName = enriched.fullName,
                        suggestedCompany = enriched.companyName,
                        duplicateContactId = dup?.id,
                        duplicateReason = if (dup != null) "Matches ${dup.fullName}" else ""
                    )
                )
            }.onFailure { err ->
                dao.upsertConferenceQueueItem(
                    ConferenceQueueEntity(
                        id = initialId,
                        eventName = ev.eventName,
                        eventLocation = ev.location,
                        encryptedFrontUri = encryptedUri,
                        queueStatus = "FAILED",
                        errorDetail = err.localizedMessage ?: "OCR processing error"
                    )
                )
            }
        }
    }

    fun batchSaveReadyConferenceQueue(items: List<ConferenceQueueEntity>) {
        viewModelScope.launch {
            val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
            items.forEach { item ->
                val contact = runCatching {
                    json.decodeFromString(SavedContactEntity.serializer(), item.parsedContactJson)
                }.getOrNull()
                if (contact != null) {
                    dao.upsertContact(contact.copy(id = 0L, profilePhotoUri = item.encryptedFrontUri, backPhotoUri = item.encryptedBackUri))
                    dao.deleteConferenceQueueItem(item)
                }
            }
        }
    }

    fun saveSingleConferenceQueueItem(item: ConferenceQueueEntity, contact: SavedContactEntity) {
        viewModelScope.launch {
            dao.upsertContact(contact.copy(id = 0L))
            dao.deleteConferenceQueueItem(item)
        }
    }

    fun deleteConferenceQueueItem(item: ConferenceQueueEntity) {
        viewModelScope.launch {
            ScannedCardStorageHelper.deleteSavedCardImage(item.encryptedFrontUri)
            ScannedCardStorageHelper.deleteSavedCardImage(item.encryptedBackUri)
            dao.deleteConferenceQueueItem(item)
        }
    }

    fun clearConferenceQueue() {
        viewModelScope.launch {
            dao.getAllConferenceQueueSnapshot().forEach {
                ScannedCardStorageHelper.deleteSavedCardImage(it.encryptedFrontUri)
                ScannedCardStorageHelper.deleteSavedCardImage(it.encryptedBackUri)
            }
            dao.clearAllConferenceQueue()
        }
    }

    fun savePendingDraft(draft: PendingDraftEntity) {
        viewModelScope.launch { dao.upsertPendingDraft(draft) }
    }

    fun deletePendingDraft(draft: PendingDraftEntity) {
        viewModelScope.launch { dao.deletePendingDraft(draft) }
    }

    fun toggleFavoriteTool(toolId: String): Boolean {
        val (updated, ok) = UxExperiencePrefs.toggleFavoriteTool(getApplication(), toolId)
        _favoriteToolIds.value = updated
        return ok
    }

    fun moveFavoriteTool(toolId: String, delta: Int) {
        _favoriteToolIds.value = UxExperiencePrefs.moveFavoriteTool(getApplication(), toolId, delta)
    }

    fun markWhatsNewViewed() {
        ReleaseNotesRepository.markCurrentVersionViewed(getApplication())
        _hasUnseenWhatsNew.value = false
    }

    fun recordToolUsed(toolId: String) {
        UxExperiencePrefs.recordToolUsed(getApplication(), toolId)
        _recentToolIds.value = UxExperiencePrefs.getRecentToolIds(getApplication())
    }

    fun logShare(method: String, recipient: String = "External") {
        viewModelScope.launch { dao.logShareEvent(ShareHistoryEntity(cardProfileTitle = activeCard.value.profileTitle, method = method, recipientInfo = recipient)) }
    }

    fun toggleTheme(isDark: Boolean?) {
        LanguageManager.saveThemeOverride(getApplication(), isDark)
        _darkThemeOverride.value = isDark
        viewModelScope.launch { CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun setAppLanguage(languageCode: String) {
        LanguageManager.saveLanguage(getApplication(), languageCode)
        _appLanguage.value = LanguageManager.getSavedLanguage(getApplication())
        viewModelScope.launch { CardLinkWidgetUpdater.updateAllWidgets(getApplication()) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        LanguageManager.setNotificationsEnabled(getApplication(), enabled)
        _notificationsEnabled.value = enabled
        viewModelScope.launch {
            if (enabled) {
                FollowUpScheduler.rescheduleAllPending(getApplication())
                BackupReminderScheduler.scheduleNextReminder(getApplication())
            IdExpiryReminderScheduler.rescheduleAll(getApplication())
            }
        }
    }
    fun toggleQuickPrivacyMode() { _quickPrivacyMode.value = !_quickPrivacyMode.value }

    fun refreshAppPreferencesFromDisk() {
        val app = getApplication<Application>()
        _appCustomTheme.value = ThemeContrastHelper.loadAppTheme(app)
        _darkThemeOverride.value = LanguageManager.getSavedThemeOverride(app)
        _appLanguage.value = LanguageManager.getSavedLanguage(app)
        _notificationsEnabled.value = LanguageManager.isNotificationsEnabled(app)
        _eventMode.value = EventModeHelper.load(app)
        _favoriteToolIds.value = UxExperiencePrefs.getFavoriteToolIds(app)
        viewModelScope.launch { cleanupDuplicateProfiles() }
    }

    fun exportContactsSelectiveCsv(
        uri: Uri,
        contactsList: List<SavedContactEntity>,
        fields: List<ContactExportField>,
        onComplete: (Result<Int>) -> Unit
    ) {
        viewModelScope.launch {
            onComplete(XlsxContactExporter.exportCsv(getApplication(), uri, contactsList, fields))
        }
    }

    fun exportContactsSelectiveXlsx(
        uri: Uri,
        contactsList: List<SavedContactEntity>,
        fields: List<ContactExportField>,
        onComplete: (Result<Int>) -> Unit
    ) {
        viewModelScope.launch {
            onComplete(XlsxContactExporter.exportXlsx(getApplication(), uri, contactsList, fields))
        }
    }

    fun exportBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportContactsToBatchVcf(getApplication(), uri, dao.getAllContactsSnapshot())) }
    }
    fun importBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            CardLinkBackupManager.importContactsFromBatchVcf(getApplication(), uri).onSuccess { dao.insertContactsBatch(it); onComplete(Result.success(it.size)) }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    private fun defaultSeedCard() = BusinessCardEntity(
        profileTitle = "Executive Profile", isDefault = true, fullName = "Md. Mazharul Islam",
        designation = "Head of Central Procurement", companyName = "Corporate Division", department = "Central Procurement",
        bio = "Driving strategic sourcing, agile procurement, and digital transformation.",
        phone = "+880 1700-000000", whatsapp = "+8801700000000", email = "contact@cardlink.app",
        officeAddress = "Motijheel C/A, Dhaka, Bangladesh", latitude = 23.7330, longitude = 90.4172,
        website = "https://cardlink.app", publicCardUrl = "https://drive.google.com/"
    )
}
