package com.cardlink.app.util

import android.content.Context
import com.cardlink.app.data.model.BusinessCardEntity

enum class SharingProfileType(val id: String, val label: String, val description: String) {
    BUSINESS("BUSINESS", "Business", "Name, title, company, work phone, email & office address"),
    NETWORKING("NETWORKING", "Networking", "Name, company, phone, email & LinkedIn"),
    CONFERENCE("CONFERENCE", "Conference", "Minimal professional details (Name, title, company & email)"),
    CUSTOM("CUSTOM", "Custom", "Uses your card's custom privacy toggles")
}

object SharingProfileManager {
    private const val PREFS = "cardlink_sharing_profile_prefs"
    private const val KEY_ACTIVE_PROFILE = "active_sharing_profile_id"
    private const val KEY_RECYCLE_RETENTION_DAYS = "recycle_bin_retention_days"

    fun getActiveProfile(context: Context): SharingProfileType {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_PROFILE, SharingProfileType.BUSINESS.id)
        return SharingProfileType.values().firstOrNull { it.id == raw } ?: SharingProfileType.BUSINESS
    }

    fun setActiveProfile(context: Context, profile: SharingProfileType) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ACTIVE_PROFILE, profile.id)
            .apply()
        runCatching { com.cardlink.app.widget.CardLinkWidgetUpdater.updateAllWidgetsAsync(context) }
    }

    fun getRecycleBinRetentionDays(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_RECYCLE_RETENTION_DAYS, 30)

    fun setRecycleBinRetentionDays(context: Context, days: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_RECYCLE_RETENTION_DAYS, days.coerceIn(0, 30))
            .apply()
    }

    /**
     * Projects a BusinessCardEntity through the selected SharingProfileType without mutating stored data.
     */
    fun applyProfile(card: BusinessCardEntity, profile: SharingProfileType): BusinessCardEntity = when (profile) {
        SharingProfileType.BUSINESS -> card.copy(
            sharePhone = true,
            shareWhatsapp = true,
            shareEmail = true,
            shareAddress = true,
            shareSocials = true
        )
        SharingProfileType.NETWORKING -> card.copy(
            sharePhone = true,
            shareWhatsapp = false,
            shareEmail = true,
            shareAddress = false,
            shareSocials = true
        )
        SharingProfileType.CONFERENCE -> card.copy(
            sharePhone = false,
            shareWhatsapp = false,
            shareEmail = true,
            shareAddress = false,
            shareSocials = true
        )
        SharingProfileType.CUSTOM -> card
    }
}
