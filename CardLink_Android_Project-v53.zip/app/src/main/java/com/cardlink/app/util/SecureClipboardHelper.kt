package com.cardlink.app.util

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.widget.Toast
import com.cardlink.app.R

object SecureClipboardHelper {
    private const val PREFS = "cardlink_security_hardening_prefs"
    private const val KEY_CLIPBOARD_TIMEOUT_SEC = "clipboard_auto_clear_sec"
    private const val DEFAULT_TIMEOUT_SEC = 30

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingClearRunnable: Runnable? = null

    @Volatile
    private var lastCopiedSensitiveText: String? = null

    fun getAutoClearSeconds(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_CLIPBOARD_TIMEOUT_SEC, DEFAULT_TIMEOUT_SEC)

    fun setAutoClearSeconds(context: Context, seconds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_CLIPBOARD_TIMEOUT_SEC, seconds.coerceIn(0, 120))
            .apply()
        SecurityHardeningManager.logAuditEventAsync(
            context,
            "CLIPBOARD_SETTING",
            "Security",
            true,
            if (seconds <= 0) "Clipboard auto-clear disabled" else "Clipboard auto-clear set to ${seconds}s"
        )
    }

    /**
     * Copies sensitive data (ID numbers, Secure Notes, loyalty numbers, Wi-Fi passwords)
     * with Android 13+ EXTRA_IS_SENSITIVE flag and auto-clears after the configured duration.
     * Tracks only CardLink-copied sensitive text so unrelated user clipboard data is never cleared.
     */
    fun copySensitive(context: Context, label: String, text: String) {
        if (text.isBlank()) return
        val appCtx = context.applicationContext
        val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return

        val clip = ClipData.newPlainText(label, text).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                description.extras = PersistableBundle().apply {
                    putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
                }
            }
        }
        cm.setPrimaryClip(clip)
        lastCopiedSensitiveText = text

        val timeoutSec = getAutoClearSeconds(appCtx)
        val toastMsg = if (timeoutSec > 0) {
            context.getString(R.string.sec_clipboard_copied_sec, timeoutSec)
        } else {
            context.getString(R.string.sec_clipboard_copied_simple)
        }
        Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()

        pendingClearRunnable?.let { mainHandler.removeCallbacks(it) }
        if (timeoutSec > 0) {
            val clearTask = Runnable { clearCardLinkClipboardNow(appCtx) }
            pendingClearRunnable = clearTask
            mainHandler.postDelayed(clearTask, timeoutSec * 1000L)
        }
    }

    /**
     * Clears the clipboard ONLY if it still holds sensitive text placed there by CardLink.
     * Called on timer expiry, Auto-Lock, Panic Lock, or explicit Clear Now.
     */
    fun clearCardLinkClipboardNow(context: Context) {
        val tracked = lastCopiedSensitiveText ?: return
        val appCtx = context.applicationContext
        val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        runCatching {
            val currentText = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
            if (currentText == tracked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    cm.clearPrimaryClip()
                } else {
                    cm.setPrimaryClip(ClipData.newPlainText("", ""))
                }
            }
        }
        lastCopiedSensitiveText = null
        pendingClearRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingClearRunnable = null
    }
}
