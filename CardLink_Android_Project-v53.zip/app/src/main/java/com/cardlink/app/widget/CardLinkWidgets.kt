package com.cardlink.app.widget

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.FollowUpStatus
import com.cardlink.app.util.BiometricLockHelper
import com.cardlink.app.util.SecurityHardeningManager
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.LanguageManager
import com.cardlink.app.util.SharingProfileManager
import com.cardlink.app.util.ThemeContrastHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun widgetRouteIntent(context: Context, route: String): Intent =
    Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        putExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE, route)
    }

object CardLinkWidgetUpdater {
    suspend fun updateAllWidgets(context: Context) {
        runCatching { CardLinkGlanceWidget().updateAll(context) }
        runCatching { QuickShareGlanceWidget().updateAll(context) }
        runCatching { ContactToolsGlanceWidget().updateAll(context) }
        runCatching { FollowUpSummaryGlanceWidget().updateAll(context) }
    }

    fun updateAllWidgetsAsync(context: Context) {
        val appCtx = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            updateAllWidgets(appCtx)
        }
    }
}

// =========================================================================
// WIDGET 1: CARDLINK QUICK SHARE
// =========================================================================
class QuickShareWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = QuickShareGlanceWidget()
}

class QuickShareGlanceWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val locCtx = LanguageManager.wrapBaseContext(context)
        val isLocked = BiometricLockHelper.isLockEnabled(context) || SecurityHardeningManager.isSensitiveAreaHidden(context)
        val themeCfg = ThemeContrastHelper.loadAppTheme(context)
        val activeProfile = SharingProfileManager.getActiveProfile(context)
        val rawCard = withContext(Dispatchers.IO) {
            CardLinkDatabase.getDatabase(context).dao().getDefaultCardSnapshot()
        }
        val activeCard = rawCard?.let { SharingProfileManager.applyProfile(it, activeProfile) }
        val qrBitmap: Bitmap? = if (!isLocked && activeCard != null) {
            val vcf = CardShareHelper.toVCardString(activeCard)
            withContext(Dispatchers.Default) {
                CardShareHelper.generateQrCodeBitmap(vcf, 280, themeCfg.backgroundHex.toInt(), AndroidColor.WHITE)
            }
        } else null

        provideContent {
            QuickShareContent(locCtx, activeCard, qrBitmap, isLocked, themeCfg)
        }
    }

    @Composable
    private fun QuickShareContent(
        context: Context,
        card: BusinessCardEntity?,
        qrBitmap: Bitmap?,
        isLocked: Boolean,
        themeCfg: com.cardlink.app.util.AppCustomThemeConfig
    ) {
        val navy = ColorProvider(Color(themeCfg.backgroundHex.toInt()))
        val surface = ColorProvider(Color(themeCfg.surfaceHex.toInt()))
        val gold = ColorProvider(Color(themeCfg.accentHex.toInt()))
        val white = ColorProvider(Color(themeCfg.textHex.toInt()))

        Box(
            modifier = GlanceModifier.fillMaxSize().background(navy).cornerRadius(18.dp).padding(12.dp)
                .clickable(actionStartActivity(widgetRouteIntent(context, "home")))
        ) {
            Row(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = GlanceModifier.defaultWeight()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            provider = ImageProvider(R.mipmap.ic_launcher),
                            contentDescription = "CardLink",
                            modifier = GlanceModifier.size(20.dp).cornerRadius(5.dp)
                        )
                        Spacer(GlanceModifier.width(6.dp))
                        Text(
                            text = context.getString(R.string.widget_quick_share_name),
                            style = TextStyle(color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                    }
                    Spacer(GlanceModifier.height(4.dp))
                    Text(
                        text = when {
                            isLocked -> "CardLink"
                            card == null -> context.getString(R.string.widget_setup_card)
                            else -> card.fullName.ifBlank { card.profileTitle }
                        },
                        style = TextStyle(color = white, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                        maxLines = 1
                    )
                    if (isLocked) {
                        Text(
                            text = context.getString(R.string.widget_locked_hint),
                            style = TextStyle(color = white, fontSize = 11.sp),
                            maxLines = 1
                        )
                    }
                    Spacer(GlanceModifier.height(8.dp))
                    Row {
                        Box(
                            modifier = GlanceModifier.background(gold).cornerRadius(8.dp).padding(horizontal = 10.dp, vertical = 6.dp)
                                .clickable(actionStartActivity(widgetRouteIntent(context, "share")))
                        ) {
                            Text(context.getString(R.string.home_share_my_card), style = TextStyle(color = navy, fontSize = 11.sp, fontWeight = FontWeight.Bold), maxLines = 1)
                        }
                        Spacer(GlanceModifier.width(6.dp))
                        Box(
                            modifier = GlanceModifier.background(surface).cornerRadius(8.dp).padding(horizontal = 10.dp, vertical = 6.dp)
                                .clickable(actionStartActivity(widgetRouteIntent(context, "home")))
                        ) {
                            Text(context.getString(R.string.widget_open_my_card), style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Medium), maxLines = 1)
                        }
                    }
                }
                if (qrBitmap != null) {
                    Spacer(GlanceModifier.width(8.dp))
                    Box(
                        modifier = GlanceModifier.size(88.dp).background(ColorProvider(Color.White)).cornerRadius(12.dp).padding(4.dp)
                            .clickable(actionStartActivity(widgetRouteIntent(context, "qr_screen")))
                    ) {
                        Image(provider = ImageProvider(qrBitmap), contentDescription = "QR", modifier = GlanceModifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

// =========================================================================
// WIDGET 2: CARDLINK CONTACT TOOLS (2x2 GRID)
// =========================================================================
class ContactToolsWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ContactToolsGlanceWidget()
}

class ContactToolsGlanceWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val locCtx = LanguageManager.wrapBaseContext(context)
        provideContent { ContactToolsContent(locCtx) }
    }

    @Composable
    private fun ContactToolsContent(context: Context) {
        val themeCfg = ThemeContrastHelper.loadAppTheme(context)
        val navy = ColorProvider(Color(themeCfg.backgroundHex.toInt()))
        val surface = ColorProvider(Color(themeCfg.surfaceHex.toInt()))
        val gold = ColorProvider(Color(themeCfg.accentHex.toInt()))
        val white = ColorProvider(Color(themeCfg.textHex.toInt()))

        Column(modifier = GlanceModifier.fillMaxSize().background(navy).cornerRadius(18.dp).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    provider = ImageProvider(R.mipmap.ic_launcher),
                    contentDescription = "CardLink",
                    modifier = GlanceModifier.size(20.dp).cornerRadius(5.dp)
                )
                Spacer(GlanceModifier.width(6.dp))
                Text(
                    text = context.getString(R.string.widget_contact_tools_name),
                    style = TextStyle(color = gold, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                    maxLines = 1
                )
            }
            Spacer(GlanceModifier.height(8.dp))
            Row(modifier = GlanceModifier.fillMaxWidth().defaultWeight()) {
                ActionCell(
                    label = context.getString(R.string.contacts_import_short),
                    bg = surface, fg = white,
                    modifier = GlanceModifier.defaultWeight().fillMaxHeight(),
                    onClick = actionStartActivity(widgetRouteIntent(context, "contacts_import"))
                )
                Spacer(GlanceModifier.width(6.dp))
                ActionCell(
                    label = context.getString(R.string.home_scan_qr),
                    bg = gold, fg = navy,
                    modifier = GlanceModifier.defaultWeight().fillMaxHeight(),
                    onClick = actionStartActivity(widgetRouteIntent(context, "scan_qr"))
                )
            }
            Spacer(GlanceModifier.height(6.dp))
            Row(modifier = GlanceModifier.fillMaxWidth().defaultWeight()) {
                ActionCell(
                    label = context.getString(R.string.home_scan_card),
                    bg = gold, fg = navy,
                    modifier = GlanceModifier.defaultWeight().fillMaxHeight(),
                    onClick = actionStartActivity(widgetRouteIntent(context, "scan_ocr"))
                )
                Spacer(GlanceModifier.width(6.dp))
                ActionCell(
                    label = context.getString(R.string.widget_open_contacts),
                    bg = surface, fg = white,
                    modifier = GlanceModifier.defaultWeight().fillMaxHeight(),
                    onClick = actionStartActivity(widgetRouteIntent(context, "contacts"))
                )
            }
        }
    }

    @Composable
    private fun ActionCell(
        label: String,
        bg: ColorProvider,
        fg: ColorProvider,
        modifier: GlanceModifier,
        onClick: androidx.glance.action.Action
    ) {
        Box(
            modifier = modifier.background(bg).cornerRadius(10.dp).padding(6.dp).clickable(onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(text = label, style = TextStyle(color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold), maxLines = 1)
        }
    }
}

// =========================================================================
// WIDGET 3: CARDLINK FOLLOW-UPS SUMMARY
// =========================================================================
class FollowUpSummaryWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = FollowUpSummaryGlanceWidget()
}

class FollowUpSummaryGlanceWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val locCtx = LanguageManager.wrapBaseContext(context)
        val isLocked = BiometricLockHelper.isLockEnabled(context) || SecurityHardeningManager.isSensitiveAreaHidden(context)
        val allFollowUps = withContext(Dispatchers.IO) {
            CardLinkDatabase.getDatabase(context).dao().getAllFollowUpsSnapshot()
        }
        val active = allFollowUps.filter { !it.isCompleted && it.status != FollowUpStatus.CANCELLED.name }
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val tomorrowStart = todayStart + 24L * 3600_000L
        val dueTodayCount = active.count { it.dueAtTimestamp in todayStart until tomorrowStart }
        val nextItem = active.minByOrNull { it.dueAtTimestamp }
        val nextSummary = if (isLocked) {
            locCtx.getString(R.string.widget_locked_hint)
        } else if (nextItem != null) {
            val dt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(nextItem.dueAtTimestamp))
            "${nextItem.title} • $dt"
        } else {
            locCtx.getString(R.string.widget_no_followups)
        }

        provideContent {
            FollowUpSummaryContent(locCtx, dueTodayCount, active.size, nextSummary)
        }
    }

    @Composable
    private fun FollowUpSummaryContent(context: Context, dueToday: Int, activeCount: Int, nextLine: String) {
        val themeCfg = ThemeContrastHelper.loadAppTheme(context)
        val navy = ColorProvider(Color(themeCfg.backgroundHex.toInt()))
        val surface = ColorProvider(Color(themeCfg.surfaceHex.toInt()))
        val gold = ColorProvider(Color(themeCfg.accentHex.toInt()))
        val white = ColorProvider(Color(themeCfg.textHex.toInt()))

        Column(
            modifier = GlanceModifier.fillMaxSize().background(navy).cornerRadius(18.dp).padding(12.dp)
                .clickable(actionStartActivity(widgetRouteIntent(context, "calendar")))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    provider = ImageProvider(R.mipmap.ic_launcher),
                    contentDescription = "CardLink",
                    modifier = GlanceModifier.size(20.dp).cornerRadius(5.dp)
                )
                Spacer(GlanceModifier.width(6.dp))
                Text(
                    text = context.getString(R.string.widget_followups_name),
                    style = TextStyle(color = gold, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                    maxLines = 1
                )
            }
            Spacer(GlanceModifier.height(6.dp))
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                Box(modifier = GlanceModifier.defaultWeight().background(surface).cornerRadius(10.dp).padding(8.dp)) {
                    Text("${context.getString(R.string.calendar_due_today)}: $dueToday", style = TextStyle(color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold), maxLines = 1)
                }
                Spacer(GlanceModifier.width(6.dp))
                Box(modifier = GlanceModifier.defaultWeight().background(surface).cornerRadius(10.dp).padding(8.dp)) {
                    Text("${context.getString(R.string.calendar_active)}: $activeCount", style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Bold), maxLines = 1)
                }
            }
            Spacer(GlanceModifier.height(6.dp))
            Text(text = nextLine, style = TextStyle(color = white, fontSize = 11.sp), maxLines = 1)
            Spacer(GlanceModifier.height(8.dp))
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                Box(
                    modifier = GlanceModifier.defaultWeight().background(gold).cornerRadius(8.dp).padding(vertical = 6.dp)
                        .clickable(actionStartActivity(widgetRouteIntent(context, "calendar_new"))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(context.getString(R.string.calendar_new_followup), style = TextStyle(color = navy, fontSize = 11.sp, fontWeight = FontWeight.Bold), maxLines = 1)
                }
                Spacer(GlanceModifier.width(6.dp))
                Box(
                    modifier = GlanceModifier.defaultWeight().background(surface).cornerRadius(8.dp).padding(vertical = 6.dp)
                        .clickable(actionStartActivity(widgetRouteIntent(context, "calendar"))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(context.getString(R.string.widget_open_calendar), style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Medium), maxLines = 1)
                }
            }
        }
    }
}
