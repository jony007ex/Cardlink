package com.cardlink.app.util

import android.content.Context
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

enum class CardTemplateCategory(val label: String) {
    EXECUTIVE("Executive"),
    CORPORATE("Corporate"),
    MINIMAL("Minimal"),
    MODERN("Modern"),
    PREMIUM_DARK("Premium Dark"),
    CREATIVE("Creative")
}

enum class CardLayoutStyle {
    EXECUTIVE_CLASSIC,
    LEFT_ACCENT_BAR,
    SPLIT_PANEL,
    MINIMAL_CLEAN,
    DIAGONAL_ACCENT,
    TOP_BAND,
    WAVE_CURVE,
    MODERN_FRAME
}

enum class CardPhotoStyle(val label: String) {
    CIRCLE("Circular"),
    ROUNDED_SQUARE("Rounded Square"),
    SOFT_RECT("Soft Portrait"),
    NO_PHOTO("No Photo (Typographic)")
}

enum class CardTypographyStyle(val label: String, val fontFamilyKey: String) {
    EXECUTIVE("Executive", "Serif"),
    PROFESSIONAL("Professional", "SansSerif"),
    MODERN("Modern", "SansSerif"),
    MINIMAL("Minimal", "SansSerif"),
    COMPACT("Compact", "Monospace")
}

data class TemplateColorVariant(
    val name: String,
    val primaryHex: Long,
    val gradientEndHex: Long,
    val accentHex: Long,
    val textHex: Long
)

data class BusinessCardTemplateSpec(
    val id: String,
    val name: String,
    val category: CardTemplateCategory,
    val legacyEnum: CardTemplate,
    val layoutStyle: CardLayoutStyle,
    val photoStyle: CardPhotoStyle,
    val typography: CardTypographyStyle,
    val isLight: Boolean,
    val primaryHex: Long,
    val gradientEndHex: Long,
    val accentHex: Long,
    val textHex: Long,
    val cornerRadiusDp: Int = 20,
    val colorVariants: List<TemplateColorVariant> = emptyList()
)

object CardTemplateRegistry {
    const val DEFAULT_TEMPLATE_ID = "executive_navy_gold:v1"

    private val darkExecVariants = listOf(
        TemplateColorVariant("Navy & Gold", 0xFF0A192FL, 0xFF172A46L, 0xFFD4AF37L, 0xFFFFFFFFL),
        TemplateColorVariant("Charcoal & Platinum", 0xFF18181BL, 0xFF27272AL, 0xFFE2E8F0L, 0xFFFFFFFFL),
        TemplateColorVariant("Emerald & Gold", 0xFF064E3BL, 0xFF022C22L, 0xFFFBBF24L, 0xFFECFDF5L),
        TemplateColorVariant("Midnight Blue", 0xFF0F172AL, 0xFF1E3A8AL, 0xFF38BDF8L, 0xFFF8FAFCL),
        TemplateColorVariant("Burgundy & Gold", 0xFF4C0519L, 0xFF2D0610L, 0xFFF4B6A8L, 0xFFFFF1F2L)
    )

    private val lightMinimalVariants = listOf(
        TemplateColorVariant("White & Navy", 0xFFFFFFFFL, 0xFFF1F5F9L, 0xFF0A192FL, 0xFF0F172AL),
        TemplateColorVariant("Ivory & Gold", 0xFFFAF9F6L, 0xFFF1EFEAL, 0xFF9A7209L, 0xFF1E293BL),
        TemplateColorVariant("White & Graphite", 0xFFFFFFFFL, 0xFFE4E4E7L, 0xFF27272AL, 0xFF18181BL),
        TemplateColorVariant("Soft Sky & Blue", 0xFFF0F9FFL, 0xFFE0F2FEL, 0xFF0369A1L, 0xFF0C4A6EL)
    )

    val all: List<BusinessCardTemplateSpec> = listOf(
        // ==================== EXECUTIVE (4) ====================
        BusinessCardTemplateSpec(
            id = "executive_navy_gold:v1",
            name = "Executive Navy & Gold",
            category = CardTemplateCategory.EXECUTIVE,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.EXECUTIVE_CLASSIC,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.EXECUTIVE,
            isLight = false,
            primaryHex = 0xFF0A192FL,
            gradientEndHex = 0xFF172A46L,
            accentHex = 0xFFD4AF37L,
            textHex = 0xFFFFFFFFL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "executive_black_platinum:v1",
            name = "Executive Black & Platinum",
            category = CardTemplateCategory.EXECUTIVE,
            legacyEnum = CardTemplate.CHARCOAL_GOLD,
            layoutStyle = CardLayoutStyle.MODERN_FRAME,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.EXECUTIVE,
            isLight = false,
            primaryHex = 0xFF121215L,
            gradientEndHex = 0xFF232329L,
            accentHex = 0xFFE2E8F0L,
            textHex = 0xFFFAFAFAL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "executive_emerald:v1",
            name = "Executive Emerald",
            category = CardTemplateCategory.EXECUTIVE,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.LEFT_ACCENT_BAR,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.EXECUTIVE,
            isLight = false,
            primaryHex = 0xFF052E24L,
            gradientEndHex = 0xFF0B4635L,
            accentHex = 0xFFFBBF24L,
            textHex = 0xFFECFDF5L,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "boardroom_blue:v1",
            name = "Boardroom Blue",
            category = CardTemplateCategory.EXECUTIVE,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.TOP_BAND,
            photoStyle = CardPhotoStyle.SOFT_RECT,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = false,
            primaryHex = 0xFF0C2340L,
            gradientEndHex = 0xFF1B3B6FL,
            accentHex = 0xFFD4AF37L,
            textHex = 0xFFF8FAFCL,
            colorVariants = darkExecVariants
        ),

        // ==================== CORPORATE (4) ====================
        BusinessCardTemplateSpec(
            id = "corporate_blue:v1",
            name = "Corporate Blue",
            category = CardTemplateCategory.CORPORATE,
            legacyEnum = CardTemplate.MODERN_SPLIT,
            layoutStyle = CardLayoutStyle.TOP_BAND,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = false,
            primaryHex = 0xFF1E3A8AL,
            gradientEndHex = 0xFF1D4ED8L,
            accentHex = 0xFF93C5FDL,
            textHex = 0xFFFFFFFFL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "corporate_white:v1",
            name = "Corporate White",
            category = CardTemplateCategory.CORPORATE,
            legacyEnum = CardTemplate.MINIMAL_IVORY,
            layoutStyle = CardLayoutStyle.LEFT_ACCENT_BAR,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = true,
            primaryHex = 0xFFFFFFFFL,
            gradientEndHex = 0xFFF1F5F9L,
            accentHex = 0xFF0A192FL,
            textHex = 0xFF0F172AL,
            colorVariants = lightMinimalVariants
        ),
        BusinessCardTemplateSpec(
            id = "corporate_split:v1",
            name = "Corporate Split",
            category = CardTemplateCategory.CORPORATE,
            legacyEnum = CardTemplate.MODERN_SPLIT,
            layoutStyle = CardLayoutStyle.SPLIT_PANEL,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = false,
            primaryHex = 0xFF0F172AL,
            gradientEndHex = 0xFF1E293BL,
            accentHex = 0xFF38BDF8L,
            textHex = 0xFFF8FAFCL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "business_edge:v1",
            name = "Business Edge",
            category = CardTemplateCategory.CORPORATE,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.DIAGONAL_ACCENT,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = true,
            primaryHex = 0xFFF8FAFCL,
            gradientEndHex = 0xFFE2E8F0L,
            accentHex = 0xFF0369A1L,
            textHex = 0xFF0F172AL,
            colorVariants = lightMinimalVariants
        ),

        // ==================== MINIMAL (4) ====================
        BusinessCardTemplateSpec(
            id = "minimal_white:v1",
            name = "Minimal White",
            category = CardTemplateCategory.MINIMAL,
            legacyEnum = CardTemplate.MINIMAL_IVORY,
            layoutStyle = CardLayoutStyle.MINIMAL_CLEAN,
            photoStyle = CardPhotoStyle.NO_PHOTO,
            typography = CardTypographyStyle.MINIMAL,
            isLight = true,
            primaryHex = 0xFFFAF9F6L,
            gradientEndHex = 0xFFF1EFEAL,
            accentHex = 0xFF0A192FL,
            textHex = 0xFF0F172AL,
            cornerRadiusDp = 16,
            colorVariants = lightMinimalVariants
        ),
        BusinessCardTemplateSpec(
            id = "minimal_navy:v1",
            name = "Minimal Navy",
            category = CardTemplateCategory.MINIMAL,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.MINIMAL_CLEAN,
            photoStyle = CardPhotoStyle.NO_PHOTO,
            typography = CardTypographyStyle.MINIMAL,
            isLight = false,
            primaryHex = 0xFF0A192FL,
            gradientEndHex = 0xFF0D213FL,
            accentHex = 0xFFD4AF37L,
            textHex = 0xFFF8FAFCL,
            cornerRadiusDp = 16,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "minimal_graphite:v1",
            name = "Minimal Graphite",
            category = CardTemplateCategory.MINIMAL,
            legacyEnum = CardTemplate.CHARCOAL_GOLD,
            layoutStyle = CardLayoutStyle.MINIMAL_CLEAN,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.MINIMAL,
            isLight = false,
            primaryHex = 0xFF1F2937L,
            gradientEndHex = 0xFF111827L,
            accentHex = 0xFFE5E7EBL,
            textHex = 0xFFF9FAFBL,
            cornerRadiusDp = 16,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "modern_minimal:v1",
            name = "Modern Minimal",
            category = CardTemplateCategory.MINIMAL,
            legacyEnum = CardTemplate.MODERN_MINIMAL,
            layoutStyle = CardLayoutStyle.LEFT_ACCENT_BAR,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.MODERN,
            isLight = true,
            primaryHex = 0xFFFFFFFFL,
            gradientEndHex = 0xFFF8FAFCL,
            accentHex = 0xFF9A7209L,
            textHex = 0xFF0F172AL,
            cornerRadiusDp = 18,
            colorVariants = lightMinimalVariants
        ),

        // ==================== MODERN (3) ====================
        BusinessCardTemplateSpec(
            id = "modern_split:v1",
            name = "Modern Split",
            category = CardTemplateCategory.MODERN,
            legacyEnum = CardTemplate.MODERN_SPLIT,
            layoutStyle = CardLayoutStyle.SPLIT_PANEL,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.MODERN,
            isLight = false,
            primaryHex = 0xFF0F172AL,
            gradientEndHex = 0xFF1E3A5FL,
            accentHex = 0xFFD4AF37L,
            textHex = 0xFFFFFFFFL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "modern_wave:v1",
            name = "Modern Wave",
            category = CardTemplateCategory.MODERN,
            legacyEnum = CardTemplate.FUTURISTIC_PROFESSIONAL,
            layoutStyle = CardLayoutStyle.WAVE_CURVE,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.MODERN,
            isLight = false,
            primaryHex = 0xFF082F49L,
            gradientEndHex = 0xFF0369A1L,
            accentHex = 0xFF38BDF8L,
            textHex = 0xFFF0F9FFL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "geometric_blue:v1",
            name = "Geometric Blue",
            category = CardTemplateCategory.MODERN,
            legacyEnum = CardTemplate.FUTURISTIC_PROFESSIONAL,
            layoutStyle = CardLayoutStyle.DIAGONAL_ACCENT,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.MODERN,
            isLight = false,
            primaryHex = 0xFF0A192FL,
            gradientEndHex = 0xFF1D4ED8L,
            accentHex = 0xFF60A5FAL,
            textHex = 0xFFFFFFFFL,
            colorVariants = darkExecVariants
        ),

        // ==================== PREMIUM DARK (3) ====================
        BusinessCardTemplateSpec(
            id = "midnight_gold:v1",
            name = "Midnight Gold",
            category = CardTemplateCategory.PREMIUM_DARK,
            legacyEnum = CardTemplate.CHARCOAL_GOLD,
            layoutStyle = CardLayoutStyle.MODERN_FRAME,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.EXECUTIVE,
            isLight = false,
            primaryHex = 0xFF090D16L,
            gradientEndHex = 0xFF161E2EL,
            accentHex = 0xFFD4AF37L,
            textHex = 0xFFF8FAFCL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "graphite_platinum:v1",
            name = "Graphite Platinum",
            category = CardTemplateCategory.PREMIUM_DARK,
            legacyEnum = CardTemplate.CHARCOAL_GOLD,
            layoutStyle = CardLayoutStyle.LEFT_ACCENT_BAR,
            photoStyle = CardPhotoStyle.SOFT_RECT,
            typography = CardTypographyStyle.PROFESSIONAL,
            isLight = false,
            primaryHex = 0xFF18181BL,
            gradientEndHex = 0xFF2E2E34L,
            accentHex = 0xFFD4D4D8L,
            textHex = 0xFFFAFAFAL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "burgundy_gold:v1",
            name = "Burgundy & Gold",
            category = CardTemplateCategory.PREMIUM_DARK,
            legacyEnum = CardTemplate.EXECUTIVE_NAVY,
            layoutStyle = CardLayoutStyle.EXECUTIVE_CLASSIC,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.EXECUTIVE,
            isLight = false,
            primaryHex = 0xFF3B0A18L,
            gradientEndHex = 0xFF5C1126L,
            accentHex = 0xFFF4B6A8L,
            textHex = 0xFFFFF1F2L,
            colorVariants = darkExecVariants
        ),

        // ==================== CREATIVE (2) ====================
        BusinessCardTemplateSpec(
            id = "dynamic_curve:v1",
            name = "Dynamic Curve",
            category = CardTemplateCategory.CREATIVE,
            legacyEnum = CardTemplate.FUTURISTIC_PROFESSIONAL,
            layoutStyle = CardLayoutStyle.WAVE_CURVE,
            photoStyle = CardPhotoStyle.ROUNDED_SQUARE,
            typography = CardTypographyStyle.MODERN,
            isLight = false,
            primaryHex = 0xFF2E1065L,
            gradientEndHex = 0xFF4C1D95L,
            accentHex = 0xFF22D3EEL,
            textHex = 0xFFF5F3FFL,
            colorVariants = darkExecVariants
        ),
        BusinessCardTemplateSpec(
            id = "future_blue:v1",
            name = "Future Blue",
            category = CardTemplateCategory.CREATIVE,
            legacyEnum = CardTemplate.FUTURISTIC_PROFESSIONAL,
            layoutStyle = CardLayoutStyle.DIAGONAL_ACCENT,
            photoStyle = CardPhotoStyle.CIRCLE,
            typography = CardTypographyStyle.COMPACT,
            isLight = false,
            primaryHex = 0xFF042F2EL,
            gradientEndHex = 0xFF115E59L,
            accentHex = 0xFF2DD4BFL,
            textHex = 0xFFF0FDFAL,
            colorVariants = darkExecVariants
        )
    )

    fun findById(id: String?): BusinessCardTemplateSpec? =
        if (id.isNullOrBlank()) null else all.firstOrNull { it.id == id }

    /**
     * Resolves a card's template safely, migrating legacy CardTemplate enums
     * and gracefully falling back to Executive Navy & Gold if an unknown ID is restored.
     */
    fun resolveForCard(card: BusinessCardEntity): BusinessCardTemplateSpec {
        findById(card.selectedTemplateId)?.let { return it }
        return when (card.template) {
            CardTemplate.MINIMAL_IVORY -> findById("minimal_white:v1") ?: all.first()
            CardTemplate.CHARCOAL_GOLD -> findById("executive_black_platinum:v1") ?: all.first()
            CardTemplate.MODERN_SPLIT -> findById("modern_split:v1") ?: all.first()
            CardTemplate.MODERN_MINIMAL -> findById("modern_minimal:v1") ?: all.first()
            CardTemplate.FUTURISTIC_PROFESSIONAL -> findById("future_blue:v1") ?: all.first()
            CardTemplate.EXECUTIVE_NAVY -> all.first()
        }
    }

    /**
     * Applies a template's visual configuration onto a card WITHOUT touching any user profile data,
     * photos, logos, QR payloads, or back-side text.
     */
    fun applyTemplateToCard(card: BusinessCardEntity, spec: BusinessCardTemplateSpec): BusinessCardEntity {
        return card.copy(
            selectedTemplateId = spec.id,
            template = spec.legacyEnum,
            primaryColorHex = spec.primaryHex,
            secondaryColorHex = spec.primaryHex,
            cardGradientEndHex = spec.gradientEndHex,
            accentColorHex = spec.accentHex,
            buttonColorHex = spec.accentHex,
            iconColorHex = spec.accentHex,
            textColorHex = spec.textHex,
            fontFamilyName = spec.typography.fontFamilyKey,
            cornerRadiusDp = spec.cornerRadiusDp
        )
    }
}

/**
 * Independent storage for Favorite Card Designs & Recently Used Card Templates.
 * Completely separate from Tools Favorites.
 */
object CardTemplatePrefs {
    private const val PREFS = "cardlink_card_template_prefs"
    private const val KEY_FAV_TEMPLATES = "favorite_card_template_ids_v1"
    private const val KEY_RECENT_TEMPLATES = "recent_card_template_ids_v1"
    private val json = Json { ignoreUnknownKeys = true }

    fun getFavoriteIds(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_FAV_TEMPLATES, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    fun setFavoriteIds(context: Context, ids: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_FAV_TEMPLATES, json.encodeToString(ids.distinct()))
            .apply()
    }

    fun toggleFavorite(context: Context, templateId: String): List<String> {
        val cur = getFavoriteIds(context).toMutableList()
        if (templateId in cur) cur.remove(templateId) else cur.add(0, templateId)
        setFavoriteIds(context, cur)
        return cur
    }

    fun getRecentlyUsedIds(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT_TEMPLATES, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    fun recordAppliedTemplate(context: Context, templateId: String) {
        val updated = (listOf(templateId) + getRecentlyUsedIds(context).filterNot { it == templateId }).take(5)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_RECENT_TEMPLATES, json.encodeToString(updated))
            .apply()
    }
}
