package com.cardlink.app.util

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.FollowUpChannel
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.FollowUpStatus

object FollowUpScheduler {
    const val CHANNEL_REMINDER_ID = "cardlink_followup_reminders_v1"
    const val CHANNEL_ALARM_ID = "cardlink_followup_alarms_v1"

    const val EXTRA_FOLLOWUP_ID = "extra_followup_id"
    const val EXTRA_WHATSAPP_NUMBER = "extra_whatsapp_number"
    const val EXTRA_WHATSAPP_MESSAGE = "extra_whatsapp_message"
    const val EXTRA_IS_ALARM = "extra_is_alarm"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val remChannel = NotificationChannel(
                CHANNEL_REMINDER_ID,
                "Follow-Up & WhatsApp Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Scheduled follow-up notifications and WhatsApp message reminders"
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            }

            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val alarmChannel = NotificationChannel(
                CHANNEL_ALARM_ID,
                "Follow-Up Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High-priority alarm alerts for scheduled follow-ups"
                enableVibration(true)
                setSound(
                    alarmUri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }

            nm.createNotificationChannel(remChannel)
            nm.createNotificationChannel(alarmChannel)
        }
    }

    fun isNotificationsEffectivelyEnabled(context: Context): Boolean {
        return LanguageManager.isNotificationsEnabled(context) && hasNotificationPermission(context)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            return am?.canScheduleExactAlarms() == true
        }
        return true
    }

    fun triggerAtMillis(item: FollowUpEntity): Long {
        val offsetMillis = item.reminderOffsetMinutes.coerceAtLeast(0) * 60_000L
        return (item.dueAtTimestamp - offsetMillis).coerceAtLeast(System.currentTimeMillis() + 2_000L)
    }

    fun scheduleForItem(context: Context, item: FollowUpEntity): String {
        ensureChannels(context)
        cancelForItem(context, item.id)

        if (item.isCompleted || item.status == FollowUpStatus.CANCELLED.name) {
            return "Inactive"
        }
        if (!item.alarmEnabled && !item.notificationEnabled) {
            return "Saved without alarm or notification"
        }
        if (!LanguageManager.isNotificationsEnabled(context)) {
            return "Notifications are turned off in Settings"
        }
        if (item.notificationEnabled && !hasNotificationPermission(context)) {
            return "Notification permission missing — reminder not active"
        }

        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            ?: return "Alarm service unavailable"

        val intent = Intent(context, com.cardlink.app.receiver.FollowUpAlarmReceiver::class.java).apply {
            putExtra(EXTRA_FOLLOWUP_ID, item.id)
            putExtra(EXTRA_WHATSAPP_NUMBER, item.whatsappNumber)
            putExtra(EXTRA_WHATSAPP_MESSAGE, item.whatsappMessage)
            putExtra(EXTRA_IS_ALARM, item.alarmEnabled)
        }

        val pi = PendingIntent.getBroadcast(
            context,
            item.id.toInt().coerceIn(1, Int.MAX_VALUE - 10),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val atTime = triggerAtMillis(item)
        return try {
            if (item.alarmEnabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atTime, pi)
                    "Scheduled (inexact alarm — exact alarm permission not granted)"
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atTime, pi)
                    "Exact alarm & notification scheduled"
                }
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atTime, pi)
                "Notification reminder scheduled"
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atTime, pi)
            "Scheduled (exact alarm permission restricted)"
        }
    }

    fun cancelForItem(context: Context, followUpId: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, com.cardlink.app.receiver.FollowUpAlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            followUpId.toInt().coerceIn(1, Int.MAX_VALUE - 10),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        pi.cancel()
    }

    suspend fun rescheduleAllPending(context: Context) {
        val dao = CardLinkDatabase.getDatabase(context).dao()
        val items = dao.getAllFollowUpsSnapshot()
        items.filter { !it.isCompleted && it.status != FollowUpStatus.CANCELLED.name }.forEach {
            scheduleForItem(context, it)
        }
    }

    fun showNotification(context: Context, item: FollowUpEntity) {
        ensureChannels(context)
        if (!isNotificationsEffectivelyEnabled(context)) return

        val isWhatsApp = item.channel == FollowUpChannel.WHATSAPP.name
        val hasContactBrief = item.contactId > 0L
        val openRoute = if (hasContactBrief) "meeting_brief/${item.contactId}" else "calendar"

        val targetIntent: Intent = if (isWhatsApp && item.whatsappNumber.isNotBlank()) {
            val digits = item.whatsappNumber.filter { it.isDigit() }
            val e164 = if (digits.startsWith("0") && digits.length == 11) "880" + digits.drop(1) else digits
            val uri = Uri.parse("https://wa.me/$e164").buildUpon()
                .appendQueryParameter("text", item.whatsappMessage.ifBlank { item.title })
                .build()
            Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        } else {
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_route", openRoute)
            }
        }

        val contentPi = PendingIntent.getActivity(
            context,
            (item.id * 10 + 1).toInt().coerceIn(1, Int.MAX_VALUE - 5),
            targetIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = if (item.alarmEnabled) CHANNEL_ALARM_ID else CHANNEL_REMINDER_ID
        val isMeeting = item.followUpType.equals("MEETING", ignoreCase = true)
        val title = when {
            isWhatsApp -> "WhatsApp Ready: ${item.contactName}"
            isMeeting && item.reminderOffsetMinutes > 0 -> "Meeting in ${item.reminderOffsetMinutes} min: ${item.contactName.ifBlank { item.title }}"
            else -> "Follow-Up: ${item.title}"
        }
        // Privacy-safe unlocked body: never dump raw private contact notes or confidential WhatsApp text
        val bodyText = when {
            isWhatsApp -> "Tap to open WhatsApp chat with ${item.contactName.ifBlank { "recipient" }}"
            else -> listOf(item.contactName, item.companyName, item.title)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" • ")
                .ifBlank { context.getString(R.string.followup_notif_lockscreen_private) }
        }

        // Strict lock-screen redaction: hides contact identity, company, and notes when device is locked
        val publicVersion = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.followup_notif_lockscreen_private))
            .build()

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(title)
            .setContentText(bodyText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bodyText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (item.alarmEnabled) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setAutoCancel(true)
            .setContentIntent(contentPi)

        if (hasContactBrief) {
            val briefIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_route", "meeting_brief/${item.contactId}")
            }
            val briefPi = PendingIntent.getActivity(
                context,
                (item.id * 10 + 2).toInt().coerceIn(1, Int.MAX_VALUE - 5),
                briefIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, context.getString(R.string.open_brief_action), briefPi)
        }

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(item.id.toInt().coerceIn(100, Int.MAX_VALUE - 10), builder.build())
    }
}
