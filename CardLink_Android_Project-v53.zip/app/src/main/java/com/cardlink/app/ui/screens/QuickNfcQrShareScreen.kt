package com.cardlink.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.SharingProfileManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickNfcQrShareScreen(
    activeCard: BusinessCardEntity,
    nfcReaderManager: NfcReaderManager,
    onNavigateHome: () -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableStateOf(CardLinkHceService.shareMode) }
    val activeProfile = remember { SharingProfileManager.getActiveProfile(context) }
    val effectiveCard = remember(activeCard, activeProfile) {
        SharingProfileManager.applyProfile(activeCard, activeProfile)
    }

    // Keep Reader Mode disabled here so HCE (Send Mode) broadcasts Sharing-Profile-filtered vCard/Link reliably
    DisposableEffect(effectiveCard, selectedMode) {
        CardLinkHceService.shareMode = selectedMode
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(effectiveCard)
        CardLinkHceService.activeShareUrl = effectiveCard.resolveNfcShareUrl()
        nfcReaderManager.disableReaderMode()
        onDispose { }
    }

    val qrBitmap = remember(effectiveCard) {
        CardShareHelper.generateQrCodeBitmap(CardShareHelper.toVCardString(effectiveCard), 750)
    }

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.quick_nfc_qr_title), color = MaterialTheme.colorScheme.onBackground, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${activeProfile.label} • " + if (selectedMode == NfcShareMode.VCARD) "vCard" else effectiveCard.resolveNfcShareUrl(),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.5.sp
                    )
                }
                IconButton(onClick = onNavigateHome) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = MaterialTheme.colorScheme.onBackground)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedMode == NfcShareMode.VCARD,
                    onClick = { selectedMode = NfcShareMode.VCARD },
                    label = { Text(stringResource(R.string.quick_nfc_vcard_chip)) }
                )
                FilterChip(
                    selected = selectedMode == NfcShareMode.LINK,
                    onClick = { selectedMode = NfcShareMode.LINK },
                    label = { Text(stringResource(R.string.quick_nfc_link_chip)) }
                )
            }
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(240.dp))
                Spacer(Modifier.height(8.dp))
                Text(effectiveCard.fullName, color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("${effectiveCard.designation} • ${effectiveCard.companyName}", color = Color.DarkGray, fontSize = 12.sp)
            }
        }

        Button(
            onClick = { CardShareHelper.shareVCardFile(context, effectiveCard) },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Icon(Icons.Default.Share, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.quick_nfc_share_vcf_btn), fontWeight = FontWeight.Bold)
        }
    }
}
