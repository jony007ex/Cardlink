package com.cardlink.app.util

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class DeviceContactSyncOutcome {
    data class Synced(val deviceContactId: String, val updatedExisting: Boolean) : DeviceContactSyncOutcome()
    data class DuplicateFound(val existingDeviceId: String, val existingDisplayName: String) : DeviceContactSyncOutcome()
    object PermissionMissing : DeviceContactSyncOutcome()
    object Disabled : DeviceContactSyncOutcome()
    data class Failed(val reason: String) : DeviceContactSyncOutcome()
}

object DeviceContactSyncManager {
    private const val PREFS = "cardlink_contact_sync_prefs"
    private const val KEY_AUTO_SAVE_PHONE = "auto_save_to_phone_contacts"
    private const val KEY_BIRTHDAY_REMINDERS = "birthday_reminders_mode" // OFF, ON_DAY, 1_DAY, 7_DAYS

    fun isAutoSaveEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_SAVE_PHONE, false)

    fun setAutoSaveEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_SAVE_PHONE, enabled)
            .apply()
    }

    fun getBirthdayReminderMode(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_BIRTHDAY_REMINDERS, "OFF") ?: "OFF"

    fun setBirthdayReminderMode(context: Context, mode: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_BIRTHDAY_REMINDERS, mode)
            .apply()
    }

    fun hasContactsPermission(context: Context): Boolean {
        val r = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val w = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
        return r && w
    }

    /**
     * Synchronizes a CardLink contact to Android's native Contacts provider.
     * - Never matches duplicates by name alone (uses linkedDeviceContactId, normalized phone, or email).
     * - Updates linked contacts safely; flags unlinked high-confidence matches as DuplicateFound unless [forceCreateNew] or [updateTargetDeviceId] is specified.
     */
    suspend fun syncContactToPhone(
        context: Context,
        contact: SavedContactEntity,
        forceCreateNew: Boolean = false,
        updateTargetDeviceId: String? = null
    ): DeviceContactSyncOutcome = withContext(Dispatchers.IO) {
        if (!hasContactsPermission(context)) {
            return@withContext DeviceContactSyncOutcome.PermissionMissing
        }
        val resolver = context.contentResolver

        // 1. Check existing linked device contact ID
        val targetId = updateTargetDeviceId ?: contact.linkedDeviceContactId
        if (!targetId.isNullOrBlank()) {
            val exists = checkDeviceContactExists(context, targetId)
            if (exists) {
                val updated = updateRawContactFields(context, targetId, contact)
                if (updated) {
                    SecurityHardeningManager.logAuditEventAsync(context, "DEVICE_CONTACT_UPDATED", "Contacts", true, "Linked contact updated on device")
                    return@withContext DeviceContactSyncOutcome.Synced(targetId, updatedExisting = true)
                }
            }
        }

        // 2. High-confidence duplicate check using normalized phone or email (NEVER name alone!)
        if (!forceCreateNew) {
            val existingDevices = PhoneContactsHelper.loadDeviceContacts(context)
            val normPhone = contact.phone.filter(Char::isDigit).takeLast(8)
            val normWa = contact.whatsapp.filter(Char::isDigit).takeLast(8)
            val normEmail = contact.email.trim().lowercase()

            val match = existingDevices.firstOrNull { dev ->
                val phoneMatch = (normPhone.length >= 7 && dev.phones.any { it.filter(Char::isDigit).takeLast(8) == normPhone }) ||
                    (normWa.length >= 7 && dev.phones.any { it.filter(Char::isDigit).takeLast(8) == normWa })
                val emailMatch = normEmail.isNotBlank() && dev.emails.any { it.trim().lowercase() == normEmail }
                phoneMatch || emailMatch
            }
            if (match != null) {
                return@withContext DeviceContactSyncOutcome.DuplicateFound(match.contactId, match.displayName)
            }
        }

        // 3. Insert new Android RawContact cleanly
        runCatching {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, contact.fullName)
                    .build()
            )
            if (contact.phone.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, contact.phone)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
                        .build()
                )
            }
            if (contact.whatsapp.isNotBlank() && contact.whatsapp != contact.phone) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, contact.whatsapp)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
            }
            if (contact.email.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, contact.email)
                        .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                        .build()
                )
            }
            if (contact.companyName.isNotBlank() || contact.designation.isNotBlank()) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Organization.COMPANY, contact.companyName)
                        .withValue(ContactsContract.CommonDataKinds.Organization.TITLE, contact.designation)
                        .build()
                )
            }

            val results = resolver.applyBatch(ContactsContract.AUTHORITY, ops)
            val rawUri = results.firstOrNull()?.uri
            val rawId = rawUri?.lastPathSegment ?: ""
            var contactId = rawId
            if (rawId.isNotBlank()) {
                resolver.query(
                    ContactsContract.RawContacts.CONTENT_URI,
                    arrayOf(ContactsContract.RawContacts.CONTACT_ID),
                    "${ContactsContract.RawContacts._ID} = ?",
                    arrayOf(rawId),
                    null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        contactId = c.getString(0) ?: rawId
                    }
                }
            }
            SecurityHardeningManager.logAuditEventAsync(context, "DEVICE_CONTACT_SAVED", "Contacts", true, "Contact saved to device")
            DeviceContactSyncOutcome.Synced(contactId, updatedExisting = false)
        }.getOrElse { err ->
            DeviceContactSyncOutcome.Failed(err.localizedMessage ?: "Device contact write failed")
        }
    }

    private fun checkDeviceContactExists(context: Context, contactId: String): Boolean {
        val idLong = contactId.toLongOrNull() ?: return false
        val uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, idLong)
        return runCatching {
            context.contentResolver.query(uri, arrayOf(ContactsContract.Contacts._ID), null, null, null)?.use { it.moveToFirst() } ?: false
        }.getOrDefault(false)
    }

    private fun findRawContactId(context: Context, contactId: String): Long? = runCatching {
        context.contentResolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID),
            "${ContactsContract.RawContacts.CONTACT_ID} = ? AND ${ContactsContract.RawContacts.DELETED} = 0",
            arrayOf(contactId),
            null
        )?.use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    }.getOrNull()

    /**
     * Safely upserts (updates existing rows or inserts missing rows) Phone, WhatsApp, Email,
     * and Organization on the linked Android RawContact without overwriting unrelated numbers.
     */
    private fun updateRawContactFields(context: Context, contactId: String, contact: SavedContactEntity): Boolean = runCatching {
        val resolver = context.contentResolver
        val rawContactId = findRawContactId(context, contactId)

        // 1. Organization (Company & Title)
        if (contact.companyName.isNotBlank() || contact.designation.isNotBlank()) {
            val orgValues = android.content.ContentValues().apply {
                put(ContactsContract.CommonDataKinds.Organization.COMPANY, contact.companyName)
                put(ContactsContract.CommonDataKinds.Organization.TITLE, contact.designation)
            }
            val updatedRows = resolver.update(
                ContactsContract.Data.CONTENT_URI,
                orgValues,
                "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
            )
            if (updatedRows == 0 && rawContactId != null) {
                orgValues.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                orgValues.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE)
                resolver.insert(ContactsContract.Data.CONTENT_URI, orgValues)
            }
        }

        // 2. Primary Work Phone
        if (contact.phone.isNotBlank()) {
            val phoneValues = android.content.ContentValues().apply {
                put(ContactsContract.CommonDataKinds.Phone.NUMBER, contact.phone)
                put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
            }
            val updatedRows = resolver.update(
                ContactsContract.Data.CONTENT_URI,
                phoneValues,
                "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ? AND ${ContactsContract.CommonDataKinds.Phone.TYPE} = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_WORK.toString())
            )
            if (updatedRows == 0 && rawContactId != null) {
                phoneValues.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                phoneValues.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                resolver.insert(ContactsContract.Data.CONTENT_URI, phoneValues)
            }
        }

        // 3. Secondary Mobile / WhatsApp (if different from primary phone)
        if (contact.whatsapp.isNotBlank() && contact.whatsapp != contact.phone) {
            val waValues = android.content.ContentValues().apply {
                put(ContactsContract.CommonDataKinds.Phone.NUMBER, contact.whatsapp)
                put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
            }
            val updatedRows = resolver.update(
                ContactsContract.Data.CONTENT_URI,
                waValues,
                "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ? AND ${ContactsContract.CommonDataKinds.Phone.TYPE} = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE.toString())
            )
            if (updatedRows == 0 && rawContactId != null) {
                waValues.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                waValues.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                resolver.insert(ContactsContract.Data.CONTENT_URI, waValues)
            }
        }

        // 4. Work Email
        if (contact.email.isNotBlank()) {
            val emailValues = android.content.ContentValues().apply {
                put(ContactsContract.CommonDataKinds.Email.ADDRESS, contact.email)
                put(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
            }
            val updatedRows = resolver.update(
                ContactsContract.Data.CONTENT_URI,
                emailValues,
                "${ContactsContract.Data.CONTACT_ID} = ? AND ${ContactsContract.Data.MIMETYPE} = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
            )
            if (updatedRows == 0 && rawContactId != null) {
                emailValues.put(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
                emailValues.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                resolver.insert(ContactsContract.Data.CONTENT_URI, emailValues)
            }
        }
        true
    }.getOrDefault(false)
}
