package com.cardlink.app.util

import android.content.Context
import android.os.Build

enum class ProtectionStatusLevel(val label: String) {
    STRONG("Strong"),
    GOOD("Good"),
    NEEDS_ATTENTION("Needs Attention"),
    ELEVATED_RISK("Elevated Risk")
}

data class SecurityRecommendation(
    val id: String,
    val title: String,
    val description: String,
    val actionLabel: String,
    val targetRoute: String,
    val isHighPriority: Boolean = false,
    val isDismissible: Boolean = true
)

data class ProtectionSnapshot(
    val statusLevel: ProtectionStatusLevel,
    val activeProtectionsCount: Int,
    val recommendations: List<SecurityRecommendation>,
    val integrityReport: RuntimeIntegrityReport,
    val lastCheckupTimestamp: Long?
)

object SecurityCheckupEngine {
    private const val PREFS = "cardlink_security_checkup_prefs"
    private const val KEY_LAST_CHECKUP = "last_security_checkup_ts"
    private const val KEY_DISMISSED_PREFIX = "dismissed_rec_"
    private const val DISMISS_COOLDOWN_MS = 7L * 24L * 3600_000L // 7 days

    fun recordCheckupCompleted(context: Context) {
        val now = System.currentTimeMillis()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_LAST_CHECKUP, now)
            .apply()
        SecurityHardeningManager.logAuditEventAsync(context, "SECURITY_CHECKUP", "Security", true, "Security Checkup completed")
    }

    fun getLastCheckupTimestamp(context: Context): Long? {
        val ts = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_CHECKUP, -1L)
        return ts.takeIf { it > 0L }
    }

    fun dismissRecommendation(context: Context, recId: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("$KEY_DISMISSED_PREFIX$recId", System.currentTimeMillis())
            .apply()
    }

    private fun isDismissedWithinCooldown(context: Context, recId: String): Boolean {
        val ts = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("$KEY_DISMISSED_PREFIX$recId", -1L)
        if (ts <= 0L) return false
        return (System.currentTimeMillis() - ts) < DISMISS_COOLDOWN_MS
    }

    /**
     * Evaluates CardLink's live security posture cleanly without numeric gamification scores.
     */
    fun evaluateProtection(context: Context, includeDismissed: Boolean = false): ProtectionSnapshot {
        val bioEnabled = BiometricLockHelper.isLockEnabled(context)
        val autoLock = SecurityHardeningManager.getAutoLockDuration(context)
        val reauthEnabled = SensitiveActionAuthenticator.isReauthEnabled(context)
        val clipSec = SecureClipboardHelper.getAutoClearSeconds(context)
        val vaultActive = VaultCryptoManager.isVaultActive(context)
        val integrity = SecurityHardeningManager.evaluateRuntimeIntegrity(context)
        val masterInfo = MasterBackupManager.getMasterInfo(context)
        val lastBackupTs = maxOf(masterInfo.lastUpdatedTimestamp ?: 0L, BackupCenterPrefs.getLastBackupTimestamp(context) ?: 0L)
        val daysSinceBackup = if (lastBackupTs > 0L) ((System.currentTimeMillis() - lastBackupTs) / (24L * 3600_000L)).toInt() else -1

        var activeCount = 3 // Encrypted DB, .clenc Vault, Sensitive Screen Privacy
        if (bioEnabled) activeCount++
        if (autoLock != AutoLockDuration.NEVER) activeCount++
        if (reauthEnabled) activeCount++
        if (clipSec > 0) activeCount++
        if (masterInfo.isAccessible) activeCount++

        val recs = mutableListOf<SecurityRecommendation>()

        // 1. High-priority runtime integrity concern (never permanently dismissible)
        if (integrity.riskLevel == RuntimeRiskLevel.HIGH_RISK) {
            recs.add(
                SecurityRecommendation(
                    id = "integrity_high_risk",
                    title = "Security Risk Detected",
                    description = "CardLink detected a condition that may reduce protection for sensitive information. Some high-risk actions have been restricted.",
                    actionLabel = "Technical Info",
                    targetRoute = "security_tech_info",
                    isHighPriority = true,
                    isDismissible = false
                )
            )
        }

        // 2. Biometric Lock disabled
        if (!bioEnabled && (includeDismissed || !isDismissedWithinCooldown(context, "enable_biometric"))) {
            recs.add(
                SecurityRecommendation(
                    id = "enable_biometric",
                    title = "Enable Biometric Lock",
                    description = "Require device authentication before protected information is opened.",
                    actionLabel = "Review Lock",
                    targetRoute = "menu_privacy",
                    isHighPriority = false,
                    isDismissible = true
                )
            )
        }

        // 3. Auto-Lock disabled while Biometric is on
        if (bioEnabled && autoLock == AutoLockDuration.NEVER && (includeDismissed || !isDismissedWithinCooldown(context, "enable_autolock"))) {
            recs.add(
                SecurityRecommendation(
                    id = "enable_autolock",
                    title = "Enable Auto-Lock",
                    description = "Protect CardLink automatically when your phone is left unattended.",
                    actionLabel = "Review Lock",
                    targetRoute = "menu_privacy",
                    isHighPriority = false,
                    isDismissible = true
                )
            )
        }

        // 4. Master Backup missing or older than 30 days
        if ((daysSinceBackup < 0 || daysSinceBackup > 30) && (includeDismissed || !isDismissedWithinCooldown(context, "update_backup"))) {
            val desc = if (daysSinceBackup > 30) {
                "Your last verified backup is $daysSinceBackup days old."
            } else {
                "Set up Master Backup so your encrypted cards and IDs can be recovered on a new device."
            }
            recs.add(
                SecurityRecommendation(
                    id = "update_backup",
                    title = "Update Backup",
                    description = desc,
                    actionLabel = "Update Backup",
                    targetRoute = "menu_backup_export",
                    isHighPriority = false,
                    isDismissible = true
                )
            )
        }

        val level = when {
            integrity.riskLevel == RuntimeRiskLevel.HIGH_RISK -> ProtectionStatusLevel.ELEVATED_RISK
            recs.any { it.isHighPriority } || recs.size >= 2 -> ProtectionStatusLevel.NEEDS_ATTENTION
            recs.size == 1 -> ProtectionStatusLevel.GOOD
            else -> ProtectionStatusLevel.STRONG
        }

        return ProtectionSnapshot(
            statusLevel = level,
            activeProtectionsCount = activeCount,
            recommendations = recs,
            integrityReport = integrity,
            lastCheckupTimestamp = getLastCheckupTimestamp(context)
        )
    }
}
