package com.cardlink.app.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.ByteMatrix
import com.google.zxing.qrcode.encoder.Encoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.pow
import kotlin.math.roundToInt

enum class ScanReadinessLevel {
    READY_TO_EXPORT,
    NEEDS_ATTENTION,
    HIGH_RISK
}

data class ScanReadinessReport(
    val level: ScanReadinessLevel,
    val contentValid: Boolean,
    val contrastRatio: Double,
    val contrastGood: Boolean,
    val quietZoneSufficient: Boolean,
    val logoSizeSafe: Boolean,
    val internalDecodeMatched: Boolean,
    val summaryMessage: String
)

object QrStudioEngine {

    fun parseColorSafe(hex: String, fallback: Int): Int = runCatching {
        val clean = if (hex.startsWith("#")) hex else "#$hex"
        Color.parseColor(clean)
    }.getOrDefault(fallback)

    /**
     * WCAG 2.1 contrast ratio between foreground and background (range 1.0 to 21.0).
     * >= 4.5 is strong for QR scanning.
     */
    fun computeContrastRatio(fgHex: String, bgHex: String, transparentBg: Boolean): Double {
        val fg = parseColorSafe(fgHex, Color.BLACK)
        val bg = if (transparentBg) Color.WHITE else parseColorSafe(bgHex, Color.WHITE)
        val l1 = relativeLuminance(fg)
        val l2 = relativeLuminance(bg)
        val lighter = maxOf(l1, l2)
        val darker = minOf(l1, l2)
        return (lighter + 0.05) / (darker + 0.05)
    }

    private fun relativeLuminance(colorInt: Int): Double {
        fun channel(c: Int): Double {
            val s = c / 255.0
            return if (s <= 0.03928) s / 12.92 else ((s + 0.055) / 1.055).pow(2.4)
        }
        return 0.2126 * channel(Color.red(colorInt)) +
            0.7152 * channel(Color.green(colorInt)) +
            0.0722 * channel(Color.blue(colorInt))
    }

    private fun toZxingEc(ec: QrEcLevel): ErrorCorrectionLevel = when (ec) {
        QrEcLevel.LOW -> ErrorCorrectionLevel.L
        QrEcLevel.MEDIUM -> ErrorCorrectionLevel.M
        QrEcLevel.QUARTILE -> ErrorCorrectionLevel.Q
        QrEcLevel.HIGH -> ErrorCorrectionLevel.H
    }

    fun encodeMatrix(payload: String, config: QrDesignConfig): ByteMatrix? {
        if (payload.isBlank()) return null
        return runCatching {
            val hints = mapOf(EncodeHintType.CHARACTER_SET to "UTF-8")
            Encoder.encode(payload, toZxingEc(config.resolvedEcLevel()), hints).matrix
        }.getOrNull()
    }

    fun resolveLogoBitmap(
        context: Context,
        config: QrDesignConfig,
        activeCard: BusinessCardEntity?,
        customLogoUri: String?
    ): Bitmap? {
        return when (config.resolvedLogoSource()) {
            QrLogoSource.NONE -> null
            QrLogoSource.CARDLINK_ICON -> runCatching {
                BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher)
            }.getOrNull()
            QrLogoSource.MY_CARD_LOGO -> {
                val uri = activeCard?.companyLogoUri?.takeIf { it.isNotBlank() }
                    ?: activeCard?.profilePhotoUri?.takeIf { it.isNotBlank() }
                if (uri != null) ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(uri)) else null
            }
            QrLogoSource.CUSTOM_IMAGE -> {
                if (!customLogoUri.isNullOrBlank()) {
                    ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(customLogoUri))
                } else null
            }
        }
    }

    fun saveQrLogoLocally(context: Context, sourceUri: Uri): String? = runCatching {
        val bmp = ScannedCardStorageHelper.decodeGalleryUri(context, sourceUri) ?: return null
        val maxEdge = 512
        val longest = maxOf(bmp.width, bmp.height)
        val scaled = if (longest > maxEdge) {
            val r = maxEdge.toFloat() / longest
            Bitmap.createScaledBitmap(bmp, (bmp.width * r).toInt().coerceAtLeast(1), (bmp.height * r).toInt().coerceAtLeast(1), true)
        } else bmp
        val dir = File(context.filesDir, "qr_logos").apply { if (!exists()) mkdirs() }
        val file = File(dir, "qr_logo_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (scaled !== bmp) scaled.recycle()
        Uri.fromFile(file).toString()
    }.getOrNull()

    /**
     * Renders a styled, scanner-safe QR Bitmap with custom body shapes, finder eye shapes,
     * optional gradient, quiet zone, centered logo, and optional CTA frame outside the quiet zone.
     */
    fun renderQrBitmap(
        payload: String,
        config: QrDesignConfig,
        sizePx: Int,
        logoBitmap: Bitmap? = null,
        forceOpaqueBackground: Boolean = false
    ): Bitmap? {
        val matrix = encodeMatrix(payload, config) ?: return null
        val n = matrix.width
        val quiet = config.quietZoneModules.coerceIn(2, 6)
        val totalModules = n + quiet * 2

        val frameExtraHeight = if (config.frameEnabled && config.frameLabel.isNotBlank()) {
            (sizePx * 0.16f).roundToInt()
        } else 0
        val outW = sizePx
        val outH = sizePx + frameExtraHeight

        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val fgColor = parseColorSafe(config.foregroundHex, Color.parseColor("#0A192F"))
        val gradEnd = parseColorSafe(config.gradientEndHex, fgColor)
        val bgColor = parseColorSafe(config.backgroundHex, Color.WHITE)

        if (!config.transparentBackground || forceOpaqueBackground) {
            canvas.drawColor(bgColor)
        } else {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        }

        val moduleSize = sizePx.toFloat() / totalModules.toFloat()
        val offset = quiet * moduleSize

        val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = fgColor
            if (config.useGradient) {
                shader = LinearGradient(
                    offset, offset, sizePx - offset, sizePx - offset,
                    fgColor, gradEnd, Shader.TileMode.CLAMP
                )
            }
        }
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = bgColor
        }

        // Draw data modules (excluding the three 7x7 finder eyes)
        val bodyStyle = config.resolvedBodyStyle()
        for (y in 0 until n) {
            for (x in 0 until n) {
                if (matrix.get(x, y).toInt() != 1) continue
                if (isInsideFinderPattern(x, y, n)) continue
                val left = offset + x * moduleSize
                val top = offset + y * moduleSize
                drawBodyModule(canvas, left, top, moduleSize, bodyStyle, fgPaint)
            }
        }

        // Draw the three 7x7 finder eyes (top-left, top-right, bottom-left)
        val eyePositions = listOf(0 to 0, (n - 7) to 0, 0 to (n - 7))
        val eyeFrameStyle = config.resolvedEyeFrameStyle()
        val eyeCenterStyle = config.resolvedEyeCenterStyle()
        for ((ex, ey) in eyePositions) {
            val left = offset + ex * moduleSize
            val top = offset + ey * moduleSize
            drawFinderEye(
                canvas = canvas,
                left = left,
                top = top,
                moduleSize = moduleSize,
                frameStyle = eyeFrameStyle,
                centerStyle = eyeCenterStyle,
                fgPaint = fgPaint,
                bgPaint = bgPaint,
                transparentBg = config.transparentBackground && !forceOpaqueBackground
            )
        }

        // Draw centered Logo safely clamped so QR remains readable
        if (logoBitmap != null && config.resolvedLogoSource() != QrLogoSource.NONE) {
            val safePct = config.logoSizePercent.coerceIn(10, 24) / 100f
            val logoDim = (sizePx * safePct).roundToInt().coerceAtLeast(24)
            val padPx = (config.logoPaddingDp * (sizePx / 512f)).roundToInt().coerceIn(2, 24)
            val cx = sizePx / 2f
            val cy = sizePx / 2f
            val boxHalf = logoDim / 2f + padPx
            val boxRect = RectF(cx - boxHalf, cy - boxHalf, cx + boxHalf, cy + boxHalf)
            val cornerR = if (config.logoRoundedCorners) logoDim * 0.22f else 0f

            if (config.logoSolidBackground) {
                val backingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (config.transparentBackground && !forceOpaqueBackground) Color.WHITE else bgColor
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(boxRect, cornerR, cornerR, backingPaint)
            }

            val logoRect = RectF(cx - logoDim / 2f, cy - logoDim / 2f, cx + logoDim / 2f, cy + logoDim / 2f)
            val saveCount = canvas.save()
            if (config.logoRoundedCorners) {
                val clipPath = Path().apply { addRoundRect(logoRect, cornerR * 0.8f, cornerR * 0.8f, Path.Direction.CW) }
                canvas.clipPath(clipPath)
            }
            canvas.drawBitmap(logoBitmap, null, logoRect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.restoreToCount(saveCount)
        }

        // Optional Frame & Call-To-Action Label cleanly outside the quiet zone
        if (frameExtraHeight > 0) {
            val bannerTop = sizePx.toFloat()
            val bannerRect = RectF(offset * 0.5f, bannerTop + 4f, outW - offset * 0.5f, outH - offset * 0.35f)
            val bannerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = fgColor
                style = Paint.Style.FILL
            }
            val bannerRadius = (frameExtraHeight * 0.28f)
            canvas.drawRoundRect(bannerRect, bannerRadius, bannerRadius, bannerPaint)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textSize = (frameExtraHeight * 0.42f).coerceIn(16f, 96f)
            }
            val fm = textPaint.fontMetrics
            val textY = bannerRect.centerY() - (fm.ascent + fm.descent) / 2f
            canvas.drawText(config.frameLabel.trim().take(28), bannerRect.centerX(), textY, textPaint)
        }

        return bitmap
    }

    private fun isInsideFinderPattern(x: Int, y: Int, n: Int): Boolean {
        val topLeft = x < 7 && y < 7
        val topRight = x >= n - 7 && y < 7
        val bottomLeft = x < 7 && y >= n - 7
        return topLeft || topRight || bottomLeft
    }

    private fun drawBodyModule(
        canvas: Canvas,
        left: Float,
        top: Float,
        size: Float,
        style: QrBodyStyle,
        paint: Paint
    ) {
        val right = left + size
        val bottom = top + size
        val cx = left + size / 2f
        val cy = top + size / 2f
        when (style) {
            QrBodyStyle.SQUARE -> canvas.drawRect(left, top, right + 0.4f, bottom + 0.4f, paint)
            QrBodyStyle.ROUNDED -> {
                val inset = size * 0.06f
                canvas.drawRoundRect(left + inset, top + inset, right - inset, bottom - inset, size * 0.32f, size * 0.32f, paint)
            }
            QrBodyStyle.DOTS -> canvas.drawCircle(cx, cy, size * 0.43f, paint)
            QrBodyStyle.SOFT_SQUARES -> {
                val inset = size * 0.05f
                canvas.drawRoundRect(left + inset, top + inset, right - inset, bottom - inset, size * 0.18f, size * 0.18f, paint)
            }
            QrBodyStyle.DIAMOND -> {
                val r = size * 0.48f
                val path = Path().apply {
                    moveTo(cx, cy - r)
                    lineTo(cx + r, cy)
                    lineTo(cx, cy + r)
                    lineTo(cx - r, cy)
                    close()
                }
                canvas.drawPath(path, paint)
            }
            QrBodyStyle.CLASSY -> {
                val r = size * 0.45f
                val path = Path().apply {
                    addRoundRect(
                        RectF(left + 0.5f, top + 0.5f, right - 0.5f, bottom - 0.5f),
                        floatArrayOf(r, r, 0f, 0f, r, r, 0f, 0f),
                        Path.Direction.CW
                    )
                }
                canvas.drawPath(path, paint)
            }
            QrBodyStyle.EXTRA_ROUNDED -> {
                val inset = size * 0.04f
                canvas.drawRoundRect(left + inset, top + inset, right - inset, bottom - inset, size * 0.46f, size * 0.46f, paint)
            }
            QrBodyStyle.CONNECTED -> {
                canvas.drawRoundRect(left - 0.3f, top - 0.3f, right + 0.3f, bottom + 0.3f, size * 0.25f, size * 0.25f, paint)
            }
            QrBodyStyle.MODERN_PIXEL -> {
                val inset = size * 0.11f
                canvas.drawRect(left + inset, top + inset, right - inset, bottom - inset, paint)
            }
        }
    }

    private fun drawFinderEye(
        canvas: Canvas,
        left: Float,
        top: Float,
        moduleSize: Float,
        frameStyle: QrEyeFrameStyle,
        centerStyle: QrEyeCenterStyle,
        fgPaint: Paint,
        bgPaint: Paint,
        transparentBg: Boolean
    ) {
        val outerSize = moduleSize * 7f
        val innerCutLeft = left + moduleSize
        val innerCutTop = top + moduleSize
        val innerCutSize = moduleSize * 5f

        val outerRect = RectF(left, top, left + outerSize, top + outerSize)
        val innerRect = RectF(innerCutLeft, innerCutTop, innerCutLeft + innerCutSize, innerCutTop + innerCutSize)

        val cutPaint = if (transparentBg) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        } else bgPaint

        when (frameStyle) {
            QrEyeFrameStyle.SQUARE -> {
                canvas.drawRect(outerRect, fgPaint)
                canvas.drawRect(innerRect, cutPaint)
            }
            QrEyeFrameStyle.ROUNDED_SQUARE -> {
                val rOut = moduleSize * 1.6f
                val rIn = moduleSize * 1.1f
                canvas.drawRoundRect(outerRect, rOut, rOut, fgPaint)
                canvas.drawRoundRect(innerRect, rIn, rIn, cutPaint)
            }
            QrEyeFrameStyle.CIRCLE -> {
                canvas.drawCircle(outerRect.centerX(), outerRect.centerY(), outerSize / 2f, fgPaint)
                canvas.drawCircle(innerRect.centerX(), innerRect.centerY(), innerCutSize / 2f, cutPaint)
            }
            QrEyeFrameStyle.SOFT_CORNER -> {
                val rOut = moduleSize * 2.2f
                val rIn = moduleSize * 1.4f
                val pOut = Path().apply { addRoundRect(outerRect, floatArrayOf(rOut, rOut, rOut, rOut, 0f, 0f, rOut, rOut), Path.Direction.CW) }
                val pIn = Path().apply { addRoundRect(innerRect, floatArrayOf(rIn, rIn, rIn, rIn, 0f, 0f, rIn, rIn), Path.Direction.CW) }
                canvas.drawPath(pOut, fgPaint)
                canvas.drawPath(pIn, cutPaint)
            }
            QrEyeFrameStyle.MODERN_BORDER -> {
                val rOut = moduleSize * 0.9f
                val rIn = moduleSize * 0.6f
                canvas.drawRoundRect(outerRect, rOut, rOut, fgPaint)
                canvas.drawRoundRect(innerRect, rIn, rIn, cutPaint)
            }
        }

        // Center 3x3 eye ball
        val cLeft = left + moduleSize * 2f
        val cTop = top + moduleSize * 2f
        val cSize = moduleSize * 3f
        val cRect = RectF(cLeft, cTop, cLeft + cSize, cTop + cSize)

        when (centerStyle) {
            QrEyeCenterStyle.SQUARE -> canvas.drawRect(cRect, fgPaint)
            QrEyeCenterStyle.CIRCLE -> canvas.drawCircle(cRect.centerX(), cRect.centerY(), cSize / 2f, fgPaint)
            QrEyeCenterStyle.ROUNDED -> canvas.drawRoundRect(cRect, moduleSize * 0.9f, moduleSize * 0.9f, fgPaint)
            QrEyeCenterStyle.SOFT_SQUARE -> canvas.drawRoundRect(cRect, moduleSize * 0.5f, moduleSize * 0.5f, fgPaint)
            QrEyeCenterStyle.DIAMOND -> {
                val cx = cRect.centerX()
                val cy = cRect.centerY()
                val r = cSize * 0.52f
                val path = Path().apply {
                    moveTo(cx, cy - r); lineTo(cx + r, cy); lineTo(cx, cy + r); lineTo(cx - r, cy); close()
                }
                canvas.drawPath(path, fgPaint)
            }
        }
    }

    /**
     * Internal Scan Validation: decodes the rendered QR bitmap locally with ZXing
     * and checks for an exact character-for-character match with the original payload.
     */
    fun verifyRenderedBitmap(bitmap: Bitmap, expectedPayload: String): Boolean {
        return runCatching {
            val w = bitmap.width
            val h = bitmap.height
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            // Flatten transparency against white for decoding test
            for (i in pixels.indices) {
                val a = Color.alpha(pixels[i])
                if (a < 128) pixels[i] = Color.WHITE
            }
            val source = RGBLuminanceSource(w, h, pixels)
            val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
            val hints = mapOf(
                DecodeHintType.TRY_HARDER to true,
                DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)
            )
            val decoded = MultiFormatReader().decode(binaryBitmap, hints).text
            decoded == expectedPayload
        }.getOrDefault(false)
    }

    fun evaluateScanReadiness(
        payload: String,
        isContentValid: Boolean,
        config: QrDesignConfig,
        renderedBitmap: Bitmap?
    ): ScanReadinessReport {
        val ratio = computeContrastRatio(config.foregroundHex, config.backgroundHex, config.transparentBackground)
        val contrastGood = ratio >= 4.5
        val quietGood = config.quietZoneModules >= 3
        val logoSafe = config.resolvedLogoSource() == QrLogoSource.NONE ||
            (config.logoSizePercent <= 22 && (config.resolvedEcLevel() == QrEcLevel.HIGH || config.resolvedEcLevel() == QrEcLevel.QUARTILE))

        val decodedExact = if (isContentValid && renderedBitmap != null) {
            verifyRenderedBitmap(renderedBitmap, payload)
        } else false

        val level = when {
            !isContentValid || !decodedExact || ratio < 2.8 -> ScanReadinessLevel.HIGH_RISK
            !contrastGood || !quietGood || !logoSafe -> ScanReadinessLevel.NEEDS_ATTENTION
            else -> ScanReadinessLevel.READY_TO_EXPORT
        }

        val msg = when {
            !isContentValid -> "Enter valid content first."
            !decodedExact -> "This design could not be verified. Increase contrast, reduce logo size or reset the QR style."
            !contrastGood -> "Low contrast (${String.format("%.1f", ratio)}:1) — scanning may fail on some devices."
            !logoSafe -> "Logo is large for current error correction. Use High error correction or reduce logo size."
            !quietGood -> "Quiet zone is narrow — increase margin for safer printing."
            else -> "Verified: QR decoded cleanly with exact payload match."
        }

        return ScanReadinessReport(
            level = level,
            contentValid = isContentValid,
            contrastRatio = ratio,
            contrastGood = contrastGood,
            quietZoneSufficient = quietGood,
            logoSizeSafe = logoSafe,
            internalDecodeMatched = decodedExact,
            summaryMessage = msg
        )
    }

    /**
     * Generates a true scalable vector SVG document preserving module shapes, finder eyes,
     * quiet zone, colors, and optional CTA frame.
     */
    fun generateSvgString(payload: String, config: QrDesignConfig, viewBoxSize: Int = 1024): String? {
        val matrix = encodeMatrix(payload, config) ?: return null
        val n = matrix.width
        val quiet = config.quietZoneModules.coerceIn(2, 6)
        val totalModules = n + quiet * 2
        val m = viewBoxSize.toFloat() / totalModules.toFloat()
        val offset = quiet * m
        val frameExtra = if (config.frameEnabled && config.frameLabel.isNotBlank()) (viewBoxSize * 0.16f).roundToInt() else 0
        val outH = viewBoxSize + frameExtra

        val fg = config.foregroundHex
        val bg = config.backgroundHex
        val fillRef = if (config.useGradient) "url(#qrGrad)" else fg

        fun escXml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        return buildString {
            appendLine("""<?xml version="1.0" encoding="UTF-8"?>""")
            appendLine("""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 $viewBoxSize $outH" width="$viewBoxSize" height="$outH">""")
            if (config.useGradient) {
                appendLine("""  <defs><linearGradient id="qrGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="$fg"/><stop offset="100%" stop-color="${config.gradientEndHex}"/></linearGradient></defs>""")
            }
            if (!config.transparentBackground) {
                appendLine("""  <rect width="$viewBoxSize" height="$outH" fill="$bg"/>""")
            }

            val bodyStyle = config.resolvedBodyStyle()
            for (y in 0 until n) {
                for (x in 0 until n) {
                    if (matrix.get(x, y).toInt() != 1 || isInsideFinderPattern(x, y, n)) continue
                    val px = offset + x * m
                    val py = offset + y * m
                    when (bodyStyle) {
                        QrBodyStyle.DOTS -> {
                            val cx = px + m / 2f; val cy = py + m / 2f; val r = m * 0.43f
                            appendLine("""  <circle cx="$cx" cy="$cy" r="$r" fill="$fillRef"/>""")
                        }
                        QrBodyStyle.DIAMOND -> {
                            val cx = px + m / 2f; val cy = py + m / 2f; val r = m * 0.48f
                            appendLine("""  <polygon points="$cx,${cy - r} ${cx + r},$cy $cx,${cy + r} ${cx - r},$cy" fill="$fillRef"/>""")
                        }
                        QrBodyStyle.ROUNDED, QrBodyStyle.EXTRA_ROUNDED, QrBodyStyle.SOFT_SQUARES -> {
                            val rx = when (bodyStyle) {
                                QrBodyStyle.EXTRA_ROUNDED -> m * 0.45f
                                QrBodyStyle.ROUNDED -> m * 0.30f
                                else -> m * 0.18f
                            }
                            appendLine("""  <rect x="$px" y="$py" width="$m" height="$m" rx="$rx" fill="$fillRef"/>""")
                        }
                        else -> {
                            appendLine("""  <rect x="$px" y="$py" width="${m + 0.2f}" height="${m + 0.2f}" fill="$fillRef"/>""")
                        }
                    }
                }
            }

            // Finder eyes
            val eyePositions = listOf(0 to 0, (n - 7) to 0, 0 to (n - 7))
            val eyeFrame = config.resolvedEyeFrameStyle()
            val eyeCenter = config.resolvedEyeCenterStyle()
            for ((ex, ey) in eyePositions) {
                val lx = offset + ex * m
                val ly = offset + ey * m
                val outer = m * 7f
                val inner = m * 5f
                val cSz = m * 3f
                val rxOut = when (eyeFrame) {
                    QrEyeFrameStyle.CIRCLE -> outer / 2f
                    QrEyeFrameStyle.ROUNDED_SQUARE, QrEyeFrameStyle.SOFT_CORNER -> m * 1.6f
                    QrEyeFrameStyle.MODERN_BORDER -> m * 0.9f
                    QrEyeFrameStyle.SQUARE -> 0f
                }
                val rxIn = when (eyeFrame) {
                    QrEyeFrameStyle.CIRCLE -> inner / 2f
                    QrEyeFrameStyle.ROUNDED_SQUARE, QrEyeFrameStyle.SOFT_CORNER -> m * 1.1f
                    QrEyeFrameStyle.MODERN_BORDER -> m * 0.6f
                    QrEyeFrameStyle.SQUARE -> 0f
                }
                appendLine("""  <rect x="$lx" y="$ly" width="$outer" height="$outer" rx="$rxOut" fill="$fillRef"/>""")
                appendLine("""  <rect x="${lx + m}" y="${ly + m}" width="$inner" height="$inner" rx="$rxIn" fill="${if (config.transparentBackground) "#FFFFFF" else bg}"/>""")
                val rxC = when (eyeCenter) {
                    QrEyeCenterStyle.CIRCLE -> cSz / 2f
                    QrEyeCenterStyle.ROUNDED -> m * 0.9f
                    QrEyeCenterStyle.SOFT_SQUARE -> m * 0.5f
                    else -> 0f
                }
                appendLine("""  <rect x="${lx + 2 * m}" y="${ly + 2 * m}" width="$cSz" height="$cSz" rx="$rxC" fill="$fillRef"/>""")
            }

            if (frameExtra > 0) {
                val bx = offset * 0.5f
                val bw = viewBoxSize - offset
                val by = viewBoxSize + 4f
                val bh = frameExtra - offset * 0.35f
                val ty = by + bh * 0.64f
                val fontSize = (frameExtra * 0.42f).roundToInt()
                appendLine("""  <rect x="$bx" y="$by" width="$bw" height="$bh" rx="${(frameExtra * 0.28f).roundToInt()}" fill="$fg"/>""")
                appendLine("""  <text x="${viewBoxSize / 2}" y="$ty" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-weight="bold" font-size="$fontSize">${escXml(config.frameLabel.trim().take(28))}</text>""")
            }
            appendLine("</svg>")
        }
    }

    suspend fun exportToUri(
        context: Context,
        destinationUri: Uri,
        payload: String,
        config: QrDesignConfig,
        format: QrExportFormat,
        resolutionPx: Int,
        printSizeMm: Int,
        logoBitmap: Bitmap?
    ): kotlin.Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            when (format) {
                QrExportFormat.SVG -> {
                    val svg = generateSvgString(payload, config, resolutionPx.coerceIn(512, 4096))
                        ?: error("Could not generate SVG vector.")
                    context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                        out.write(svg.toByteArray(Charsets.UTF_8))
                        out.flush()
                    } ?: error("Could not open output file.")
                }
                QrExportFormat.PNG -> {
                    val bmp = renderQrBitmap(payload, config, resolutionPx.coerceIn(512, 4096), logoBitmap, forceOpaqueBackground = false)
                        ?: error("Could not render PNG.")
                    try {
                        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                            out.flush()
                        } ?: error("Could not open output file.")
                    } finally {
                        bmp.recycle()
                    }
                }
                QrExportFormat.JPG -> {
                    val bmp = renderQrBitmap(payload, config, resolutionPx.coerceIn(512, 4096), logoBitmap, forceOpaqueBackground = true)
                        ?: error("Could not render JPG.")
                    try {
                        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                            bmp.compress(Bitmap.CompressFormat.JPEG, 96, out)
                            out.flush()
                        } ?: error("Could not open output file.")
                    } finally {
                        bmp.recycle()
                    }
                }
                QrExportFormat.PDF -> {
                    val bmp = renderQrBitmap(payload, config, resolutionPx.coerceIn(1024, 2048), logoBitmap, forceOpaqueBackground = true)
                        ?: error("Could not render PDF.")
                    try {
                        // PDF points: 1 inch = 72 pt = 25.4 mm
                        val mm = printSizeMm.coerceIn(25, 200)
                        val qrPt = ((mm / 25.4f) * 72f).roundToInt()
                        val pageW = maxOf(qrPt + 72, 300)
                        val pageH = maxOf((qrPt * (bmp.height.toFloat() / bmp.width)).roundToInt() + 72, 300)
                        val pdf = PdfDocument()
                        val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, 1).create()
                        val page = pdf.startPage(pageInfo)
                        val canvas = page.canvas
                        canvas.drawColor(Color.WHITE)
                        val drawW = qrPt
                        val drawH = (qrPt * (bmp.height.toFloat() / bmp.width)).roundToInt()
                        val left = (pageW - drawW) / 2
                        val top = (pageH - drawH) / 2
                        canvas.drawBitmap(bmp, null, Rect(left, top, left + drawW, top + drawH), null)
                        pdf.finishPage(page)
                        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                            pdf.writeTo(out)
                            out.flush()
                        } ?: error("Could not open PDF output.")
                        pdf.close()
                    } finally {
                        bmp.recycle()
                    }
                }
            }
        }
    }

    suspend fun shareQrCode(
        context: Context,
        projectName: String,
        payload: String,
        config: QrDesignConfig,
        format: QrExportFormat,
        resolutionPx: Int,
        printSizeMm: Int,
        logoBitmap: Bitmap?
    ): kotlin.Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = projectName.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "CardLink_QR" }
            val outFile = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_${System.currentTimeMillis()}", format.ext)
            val fileUri = Uri.fromFile(outFile)
            exportToUri(context, fileUri, payload, config, format, resolutionPx, printSizeMm, logoBitmap).getOrThrow()

            val shareUri = TempSecureExportVault.toShareUri(context, outFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = format.mime
                putExtra(Intent.EXTRA_STREAM, shareUri)
                clipData = ClipData.newRawUri(outFile.name, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share QR Code (${format.label})").apply {
                clipData = ClipData.newRawUri(outFile.name, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }
}
