package com.cardlink.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.FollowUpChannel
import com.cardlink.app.data.model.FollowUpStatus
import com.cardlink.app.util.FollowUpScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FollowUpAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val followUpId = intent?.getLongExtra(FollowUpScheduler.EXTRA_FOLLOWUP_ID, -1L) ?: -1L
        if (followUpId <= 0L) return

        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            try {
                val dao = CardLinkDatabase.getDatabase(context).dao()
                val item = dao.getFollowUpById(followUpId) ?: return@launch
                if (item.isCompleted || item.status == FollowUpStatus.CANCELLED.name) return@launch

                val updatedStatus = if (item.channel == FollowUpChannel.WHATSAPP.name) {
                    FollowUpStatus.READY_TO_SEND.name
                } else {
                    item.status
                }

                val updatedItem = item.copy(status = updatedStatus)
                dao.upsertFollowUp(updatedItem)

                if (updatedItem.notificationEnabled || updatedItem.alarmEnabled) {
                    FollowUpScheduler.showNotification(context, updatedItem)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class BootRescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val pendingResult = goAsync()
            val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope.launch {
                try {
                    FollowUpScheduler.rescheduleAllPending(context)
                    com.cardlink.app.util.IdExpiryReminderScheduler.rescheduleAll(context)
                    com.cardlink.app.util.BackupReminderScheduler.scheduleNextReminder(context)
                    com.cardlink.app.util.BirthdayReminderScheduler.syncSchedule(context)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
class IdExpiryAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val docUuid = intent?.getStringExtra(com.cardlink.app.util.IdExpiryReminderScheduler.EXTRA_ID_DOC_UUID) ?: return
        val milestoneDays = intent.getIntExtra(com.cardlink.app.util.IdExpiryReminderScheduler.EXTRA_ID_MILESTONE_DAYS, 30)

        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            try {
                val doc = CardLinkDatabase.getDatabase(context).dao().getIdDocumentByUuid(docUuid) ?: return@launch
                if (!doc.expiryRemindersEnabled) return@launch
                com.cardlink.app.util.IdExpiryReminderScheduler.showExpiryNotification(context, doc, milestoneDays)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
class BackupReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        com.cardlink.app.util.BackupReminderScheduler.showBackupReminderNotification(context)
        com.cardlink.app.util.BackupReminderScheduler.scheduleNextReminder(context)
    }
}
