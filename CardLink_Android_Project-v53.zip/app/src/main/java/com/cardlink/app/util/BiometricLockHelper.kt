package com.cardlink.app.util

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

object BiometricLockHelper {
    private const val PREFS_NAME = "cardlink_security_prefs"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_lock_enabled"
    private const val BIO_KEY_ALIAS = "cardlink_biometric_auth_key_v1"

    fun isLockEnabled(context: Context): Boolean =
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS_NAME).getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun setLockEnabled(context: Context, enabled: Boolean) {
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS_NAME).edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    fun canAuthenticate(context: Context): Boolean {
        val manager = BiometricManager.from(context)
        val combined = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        } else {
            Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        }
        if (manager.canAuthenticate(combined) == BiometricManager.BIOMETRIC_SUCCESS) return true
        if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) return true
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return km?.isDeviceSecure == true
    }

    @Suppress("DEPRECATION")
    fun createDeviceCredentialIntent(context: Context): Intent? {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return if (km?.isDeviceSecure == true) {
            km.createConfirmDeviceCredentialIntent("Unlock Card Link", "Authenticate using your device screen lock")
        } else null
    }

    /**
     * Builds a hardware-backed BiometricPrompt.CryptoObject for BIOMETRIC_STRONG devices.
     * Gracefully recovers from KeyPermanentlyInvalidatedException without touching user data.
     */
    private fun createStrongCryptoObject(): BiometricPrompt.CryptoObject? = runCatching {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        fun generateKey() {
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val builder = KeyGenParameterSpec.Builder(
                BIO_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            }
            kg.init(builder.build())
            kg.generateKey()
        }

        if (!ks.containsAlias(BIO_KEY_ALIAS)) {
            generateKey()
        }
        val key = ks.getKey(BIO_KEY_ALIAS, null) as SecretKey
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        try {
            cipher.init(Cipher.ENCRYPT_MODE, key)
        } catch (_: KeyPermanentlyInvalidatedException) {
            ks.deleteEntry(BIO_KEY_ALIAS)
            generateKey()
            val refreshedKey = ks.getKey(BIO_KEY_ALIAS, null) as SecretKey
            cipher.init(Cipher.ENCRYPT_MODE, refreshedKey)
        }
        BiometricPrompt.CryptoObject(cipher)
    }.getOrNull()

    fun showPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onFallbackToDeviceCredential: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result); onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) onFallbackToDeviceCredential()
                else onError(errString.toString())
            }
        })

        val manager = BiometricManager.from(activity)

        // Prefer CryptoObject-bound BIOMETRIC_STRONG when available
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            manager.canAuthenticate(Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        ) {
            val cryptoObj = createStrongCryptoObject()
            if (cryptoObj != null) {
                val strongInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock Card Link")
                    .setSubtitle("Verify with Fingerprint or Face")
                    .setAllowedAuthenticators(Authenticators.BIOMETRIC_STRONG)
                    .setNegativeButtonText("Use Device Lock")
                    .build()
                val launched = runCatching { prompt.authenticate(strongInfo, cryptoObj) }.isSuccess
                if (launched) return
            }
        }

        val rCombo = Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        val promptInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && manager.canAuthenticate(rCombo) == BiometricManager.BIOMETRIC_SUCCESS) {
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Use Fingerprint, Face, or Device Screen Lock").setAllowedAuthenticators(rCombo).build()
            } else if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) {
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Authenticate with Biometrics").setAllowedAuthenticators(Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Use Device Lock").build()
            } else {
                @Suppress("DEPRECATION")
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Authenticate to access Card Link").setDeviceCredentialAllowed(true).build()
            }
        } catch (_: Exception) {
            onFallbackToDeviceCredential(); return
        }
        runCatching { prompt.authenticate(promptInfo) }.onFailure { onFallbackToDeviceCredential() }
    }
}
