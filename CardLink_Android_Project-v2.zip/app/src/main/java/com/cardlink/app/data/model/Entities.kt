package com.cardlink.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class CardTemplate {
    EXECUTIVE_NAVY, MINIMAL_IVORY, CHARCOAL_GOLD, MODERN_SPLIT
}

@Serializable
@Entity(tableName = "my_cards")
data class BusinessCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileTitle: String = "Corporate",
    val isDefault: Boolean = true,
    val fullName: String = "",
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val profilePhotoUri: String? = null,
    val companyLogoUri: String? = null,
    val template: CardTemplate = CardTemplate.EXECUTIVE_NAVY,
    val primaryColorHex: Long = 0xFF0A192F,
    val accentColorHex: Long = 0xFFD4AF37,
    val textColorHex: Long = 0xFFFFFFFF,
    val fontFamilyName: String = "Serif",
    val cornerRadiusDp: Int = 16,
    val sharePhone: Boolean = true,
    val shareWhatsapp: Boolean = true,
    val shareEmail: Boolean = true,
    val shareAddress: Boolean = true,
    val shareSocials: Boolean = true
) {
    fun sanitizedForSharing(): BusinessCardEntity = copy(
        phone = if (sharePhone) phone else "",
        whatsapp = if (shareWhatsapp) whatsapp else "",
        email = if (shareEmail) email else "",
        officeAddress = if (shareAddress) officeAddress else "",
        linkedInUrl = if (shareSocials) linkedInUrl else "",
        facebookUrl = if (shareSocials) facebookUrl else "",
        otherSocialUrl = if (shareSocials) otherSocialUrl else "",
        profilePhotoUri = null,
        companyLogoUri = null
    )
}

@Serializable
@Entity(tableName = "saved_contacts")
data class SavedContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val profilePhotoUri: String? = null,
    val notes: String = "",
    val receivedVia: String = "QR Code",
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "share_history")
data class ShareHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardProfileTitle: String,
    val method: String,
    val recipientInfo: String,
    val timestamp: Long = System.currentTimeMillis()
)
