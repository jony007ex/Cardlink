package com.cardlink.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.CardShareHelper

@Composable
fun QuickNfcQrShareScreen(
    activeCard: BusinessCardEntity,
    nfcReaderManager: NfcReaderManager,
    onNavigateHome: () -> Unit
) {
    val context = LocalContext.current
    DisposableEffect(activeCard) {
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(activeCard)
        nfcReaderManager.enableReaderMode()
        onDispose { nfcReaderManager.disableReaderMode() }
    }

    val qrBitmap = remember(activeCard) {
        CardShareHelper.generateQrCodeBitmap(CardShareHelper.toVCardString(activeCard), 750)
    }

    Column(
        modifier = Modifier.fillMaxSize().background(NavyPrimary).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Express NFC + QR Share", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onNavigateHome) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(250.dp))
                Spacer(Modifier.height(8.dp))
                Text(activeCard.fullName, color = NavyPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("${activeCard.designation} • ${activeCard.companyName}", color = Color.DarkGray, fontSize = 12.sp)
            }
        }

        Button(
            onClick = { CardShareHelper.shareVCardFile(context, activeCard) },
            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Icon(Icons.Default.Share, null)
            Spacer(Modifier.width(8.dp))
            Text("Share vCard (.vcf) via WhatsApp / Apps", fontWeight = FontWeight.Bold)
        }
    }
}
