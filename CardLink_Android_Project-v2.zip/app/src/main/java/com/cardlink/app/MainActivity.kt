package com.cardlink.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.cardlink.app.nearby.*
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.tile.CardLinkTileService
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.components.BackupRestoreSection
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.screens.*
import com.cardlink.app.ui.theme.*
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.widget.CardLinkGlanceWidget
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val viewModel: CardLinkViewModel by viewModels()
    private lateinit var nfcReaderManager: NfcReaderManager
    private lateinit var nearbyShareManager: NearbyShareManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        nearbyShareManager = NearbyShareManager(this)
        nfcReaderManager = NfcReaderManager(this) { vcfPayload ->
            val contact = CardShareHelper.parseVCardToContact(vcfPayload, "NFC Tap")
            viewModel.saveReceivedContact(contact)
            Toast.makeText(this, "Saved ${contact.fullName} via NFC!", Toast.LENGTH_LONG).show()
        }

        val initialRoute = intent?.getStringExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE) ?: "splash"

        setContent {
            val darkOverride by viewModel.darkThemeOverride.collectAsState()
            CardLinkTheme(darkTheme = darkOverride ?: isSystemInDarkTheme()) {
                CardLinkAppScaffold(
                    viewModel = viewModel,
                    nfcReaderManager = nfcReaderManager,
                    nearbyShareManager = nearbyShareManager,
                    startRoute = initialRoute
                )
            }
        }
    }

    override fun onPause() {
        super.onPause()
        nfcReaderManager.disableReaderMode()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkAppScaffold(
    viewModel: CardLinkViewModel,
    nfcReaderManager: NfcReaderManager,
    nearbyShareManager: NearbyShareManager,
    startRoute: String
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val activeCard by viewModel.activeCard.collectAsState()
    val myCards by viewModel.myCards.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current

    val bottomNavRoutes = listOf("home", "share", "contacts", "settings")

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomNavRoutes) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Badge, null) },
                        label = { Text("My Card") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "share",
                        onClick = { navController.navigate("share") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Share, null) },
                        label = { Text("Share") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "contacts",
                        onClick = { navController.navigate("contacts") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Contacts, null) },
                        label = { Text("Contacts") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "settings",
                        onClick = { navController.navigate("settings") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startRoute,
            modifier = Modifier.padding(padding)
        ) {
            composable("splash") {
                LaunchedEffect(Unit) {
                    delay(900)
                    navController.navigate("home") { popUpTo("splash") { inclusive = true } }
                }
                Box(modifier = Modifier.fillMaxSize().background(NavyPrimary), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Contactless, null, tint = GoldAccent, modifier = Modifier.size(80.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("CardLink", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text("Smart Digital Business Card", color = GoldAccent, fontSize = 14.sp)
                    }
                }
            }

            composable("home") {
                val qrBitmap = remember(activeCard) {
                    CardShareHelper.generateQrCodeBitmap(CardShareHelper.toVCardString(activeCard), 480)
                }
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CardLink", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Active: ${activeCard.profileTitle}", style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            IconButton(onClick = { navController.navigate("scan_ocr") }) {
                                Icon(Icons.Default.DocumentScanner, contentDescription = "Scan Paper Card")
                            }
                            IconButton(onClick = { navController.navigate("customize") }) {
                                Icon(Icons.Default.Palette, contentDescription = "Customize")
                            }
                            IconButton(onClick = { navController.navigate("edit_card") }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit")
                            }
                        }
                    }

                    if (myCards.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            myCards.forEach { profile ->
                                FilterChip(
                                    selected = profile.id == activeCard.id,
                                    onClick = { viewModel.switchActiveProfile(profile.id) },
                                    label = { Text(profile.profileTitle) }
                                )
                            }
                        }
                    }

                    BusinessCardView(card = activeCard)

                    Button(
                        onClick = { navController.navigate("share") },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Share, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share My Card", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Instant Scan QR", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(150.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                TextButton(onClick = { navController.navigate("qr_screen") }) { Text("Full QR") }
                                TextButton(onClick = { navController.navigate("scan_qr") }) { Text("Scan QR") }
                                TextButton(onClick = { navController.navigate("scan_ocr") }) { Text("Scan Paper Card") }
                            }
                        }
                    }
                }
            }

            composable("edit_card") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Edit Business Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = draft.profileTitle, onValueChange = { draft = draft.copy(profileTitle = it) }, label = { Text("Profile Label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.fullName, onValueChange = { draft = draft.copy(fullName = it) }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.department, onValueChange = { draft = draft.copy(department = it) }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.phone, onValueChange = { draft = draft.copy(phone = it) }, label = { Text("Business Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text("WhatsApp Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.officeAddress, onValueChange = { draft = draft.copy(officeAddress = it) }, label = { Text("Office Address") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text("Website") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.linkedInUrl, onValueChange = { draft = draft.copy(linkedInUrl = it) }, label = { Text("LinkedIn URL") }, modifier = Modifier.fillMaxWidth())

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.saveCard(draft.copy(id = 0, profileTitle = "New Profile", isDefault = true)); navController.popBackStack() },
                            modifier = Modifier.weight(1f)
                        ) { Text("Save as New") }
                        Button(
                            onClick = { viewModel.saveCard(draft); navController.popBackStack() },
                            modifier = Modifier.weight(1f)
                        ) { Text("Save Changes") }
                    }
                }
            }

            composable("customize") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                val presets = listOf(
                    Triple("Executive Navy & Gold", 0xFF0A192FL, 0xFFD4AF37L),
                    Triple("Charcoal & Platinum", 0xFF1E293BL, 0xFFE2E8F0L),
                    Triple("Royal Emerald", 0xFF064E3BL, 0xFFFBBF24L),
                    Triple("Midnight Crimson", 0xFF3B0764L, 0xFFF43F5EL)
                )
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Customize Card Theme", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = draft)
                    presets.forEach { (name, bg, acc) ->
                        OutlinedButton(onClick = { draft = draft.copy(primaryColorHex = bg, accentColorHex = acc) }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                    }
                    Button(onClick = { viewModel.saveCard(draft); navController.popBackStack() }, modifier = Modifier.fillMaxWidth()) { Text("Apply Theme") }
                }
            }

            composable("share") {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Share My Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = activeCard)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { navController.navigate("nfc_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("NFC Tap") }
                        Button(onClick = { navController.navigate("nearby_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Bluetooth Nearby") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { navController.navigate("qr_screen") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("QR Code") }
                        Button(onClick = { CardShareHelper.shareVCardFile(context, activeCard) }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Share via Apps") }
                    }

                    OutlinedButton(onClick = { CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as PNG Image") }
                    OutlinedButton(onClick = { CardShareHelper.shareCardAsPdf(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Export as PDF Document") }
                    OutlinedButton(onClick = { CardShareHelper.shareAsText(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as Text / WhatsApp") }
                }
            }

            composable("nfc_share") {
                DisposableEffect(Unit) {
                    nfcReaderManager.enableReaderMode()
                    onDispose { nfcReaderManager.disableReaderMode() }
                }
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Contactless, null, tint = GoldAccent, modifier = Modifier.size(90.dp))
                    Spacer(Modifier.height(12.dp))
                    if (!nfcReaderManager.isNfcSupported()) {
                        Text("NFC is not supported on this phone.", fontWeight = FontWeight.Bold)
                    } else if (!nfcReaderManager.isNfcEnabled()) {
                        Text("NFC is disabled. Enable it in Settings.", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Open NFC Settings") }
                    } else {
                        Text("Ready for NFC Tap", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Hold the back of your phone to another NFC-enabled smartphone.")
                        Spacer(Modifier.height(16.dp))
                        BusinessCardView(card = activeCard)
                    }
                }
            }

            composable("nearby_share") {
                val peers by nearbyShareManager.peers.collectAsState()
                val state by nearbyShareManager.uiState.collectAsState()
                val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    nearbyShareManager.startNearbySession(activeCard.fullName, activeCard)
                }

                DisposableEffect(Unit) {
                    val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        perms.addAll(listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT))
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                    }
                    permLauncher.launch(perms.toTypedArray())
                    onDispose { nearbyShareManager.stopSession() }
                }

                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Bluetooth / Nearby Radar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    if (state is NearbyUiState.ReceivedCardPreview) {
                        val rxCard = (state as NearbyUiState.ReceivedCardPreview).card
                        BusinessCardView(card = rxCard)
                        Button(onClick = {
                            val saved = CardShareHelper.parseVCardToContact(CardShareHelper.toVCardString(rxCard), "Bluetooth Nearby")
                            viewModel.saveReceivedContact(saved)
                            navController.navigate("contacts")
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save Received Card") }
                    }
                    LazyColumn {
                        items(peers) { peer ->
                            ListItem(
                                headlineContent = { Text(peer.endpointName) },
                                supportingContent = { Text("Tap to send your digital business card") },
                                modifier = Modifier.clickable { nearbyShareManager.connectAndSendToPeer(peer, activeCard.fullName) }
                            )
                        }
                    }
                }
            }

            composable("qr_screen") {
                val qr = remember(activeCard) { CardShareHelper.generateQrCodeBitmap(CardShareHelper.toVCardString(activeCard), 750) }
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(activeCard.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Image(bitmap = qr.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(260.dp))
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share QR & Card Image") }
                }
            }

            composable("scan_qr") {
                var hasCam by remember { mutableStateOf(false) }
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
                LaunchedEffect(Unit) { launcher.launch(Manifest.permission.CAMERA) }
                if (hasCam) {
                    val lifecycleOwner = LocalLifecycleOwner.current
                    var done by remember { mutableStateOf(false) }
                    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                        val pv = PreviewView(ctx)
                        val fut = ProcessCameraProvider.getInstance(ctx)
                        fut.addListener({
                            val prov = fut.get()
                            val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                            val scanner = BarcodeScanning.getClient()
                            val analysis = ImageAnalysis.Builder().build().apply {
                                setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                    @Suppress("UnsafeOptInUsageError")
                                    val img = proxy.image
                                    if (img != null && !done) {
                                        scanner.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                                            .addOnSuccessListener { list ->
                                                for (b in list) {
                                                    val raw = b.rawValue ?: continue
                                                    if (raw.contains("BEGIN:VCARD", true)) {
                                                        done = true
                                                        viewModel.saveReceivedContact(CardShareHelper.parseVCardToContact(raw, "QR Scan"))
                                                        navController.navigate("contacts")
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener { proxy.close() }
                                    } else proxy.close()
                                }
                            }
                            prov.unbindAll()
                            prov.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, prev, analysis)
                        }, ContextCompat.getMainExecutor(ctx))
                        pv
                    })
                }
            }

            composable("scan_ocr") {
                OcrCardScannerScreen(
                    onContactSaved = { contact ->
                        viewModel.saveReceivedContact(contact)
                        navController.navigate("contacts") { popUpTo("scan_ocr") { inclusive = true } }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(CardLinkTileService.ROUTE_QUICK_SHARE) {
                QuickNfcQrShareScreen(
                    activeCard = activeCard,
                    nfcReaderManager = nfcReaderManager,
                    onNavigateHome = { navController.navigate("home") }
                )
            }

            composable("contacts") {
                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("My Contacts", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Row {
                            IconButton(onClick = { navController.navigate("scan_ocr") }) { Icon(Icons.Default.DocumentScanner, null) }
                            IconButton(onClick = { navController.navigate("scan_qr") }) { Icon(Icons.Default.QrCodeScanner, null) }
                        }
                    }
                    OutlinedTextField(value = searchQuery, onValueChange = viewModel::updateSearchQuery, placeholder = { Text("Search contacts...") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(contacts, key = { it.id }) { contact ->
                            Card(modifier = Modifier.fillMaxWidth().clickable { navController.navigate("contact_detail/${contact.id}") }) {
                                ListItem(
                                    leadingContent = {
                                        if (!contact.profilePhotoUri.isNullOrBlank()) {
                                            AsyncImage(
                                                model = android.net.Uri.parse(contact.profilePhotoUri),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(56.dp, 36.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, GoldAccent, RoundedCornerShape(6.dp))
                                            )
                                        } else {
                                            Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = GoldAccent.copy(alpha = 0.2f)) {
                                                Box(contentAlignment = Alignment.Center) { Text(contact.fullName.take(2).uppercase(), color = GoldAccent, fontWeight = FontWeight.Bold) }
                                            }
                                        }
                                    },
                                    headlineContent = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                                    supportingContent = { Text("${contact.designation} • ${contact.companyName}") },
                                    trailingContent = { AssistChip(onClick = {}, label = { Text(contact.receivedVia) }) }
                                )
                            }
                        }
                    }
                }
            }

            composable(
                route = "contact_detail/{contactId}",
                arguments = listOf(navArgument("contactId") { type = NavType.LongType })
            ) { entry ->
                val id = entry.arguments?.getLong("contactId") ?: 0L
                val contact = contacts.firstOrNull { it.id == id }
                if (contact != null) {
                    ContactDetailScreen(
                        contact = contact,
                        mySenderName = activeCard.fullName,
                        onSaveNotes = { viewModel.saveReceivedContact(contact.copy(notes = it)) },
                        onDeleteContact = { viewModel.deleteContact(contact); navController.popBackStack() },
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            composable("settings") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Settings & Privacy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Phone Number")
                        Switch(checked = draft.sharePhone, onCheckedChange = { draft = draft.copy(sharePhone = it); viewModel.saveCard(draft) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Email Address")
                        Switch(checked = draft.shareEmail, onCheckedChange = { draft = draft.copy(shareEmail = it); viewModel.saveCard(draft) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Office Address")
                        Switch(checked = draft.shareAddress, onCheckedChange = { draft = draft.copy(shareAddress = it); viewModel.saveCard(draft) })
                    }

                    BackupRestoreSection(viewModel = viewModel)

                    OutlinedButton(
                        onClick = { CardLinkTileService.requestAddTile(context) { Toast.makeText(context, it, Toast.LENGTH_LONG).show() } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Add Quick Settings Tile") }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.toggleTheme(false) }, modifier = Modifier.weight(1f)) { Text("Light") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(true) }, modifier = Modifier.weight(1f)) { Text("Dark") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(null) }, modifier = Modifier.weight(1f)) { Text("System") }
                    }
                }
            }
        }
    }
}
