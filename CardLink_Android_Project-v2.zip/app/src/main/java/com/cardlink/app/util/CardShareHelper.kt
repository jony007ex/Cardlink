package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.provider.ContactsContract
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

object CardShareHelper {

    fun toVCardString(card: BusinessCardEntity): String {
        val clean = card.sanitizedForSharing()
        return buildString {
            appendLine("BEGIN:VCARD")
            appendLine("VERSION:3.0")
            appendLine("FN:${clean.fullName}")
            appendLine("N:${clean.fullName};;;;")
            if (clean.companyName.isNotBlank() || clean.department.isNotBlank()) {
                appendLine("ORG:${clean.companyName};${clean.department}")
            }
            if (clean.designation.isNotBlank()) appendLine("TITLE:${clean.designation}")
            if (clean.phone.isNotBlank()) appendLine("TEL;TYPE=WORK,VOICE:${clean.phone}")
            if (clean.whatsapp.isNotBlank()) appendLine("TEL;TYPE=CELL,WHATSAPP:${clean.whatsapp}")
            if (clean.email.isNotBlank()) appendLine("EMAIL;TYPE=PREF,INTERNET:${clean.email}")
            if (clean.officeAddress.isNotBlank()) appendLine("ADR;TYPE=WORK:;;${clean.officeAddress};;;;")
            if (clean.website.isNotBlank()) appendLine("URL:${clean.website}")
            if (clean.linkedInUrl.isNotBlank()) appendLine("X-SOCIALPROFILE;TYPE=linkedin:${clean.linkedInUrl}")
            if (clean.facebookUrl.isNotBlank()) appendLine("X-SOCIALPROFILE;TYPE=facebook:${clean.facebookUrl}")
            if (clean.otherSocialUrl.isNotBlank()) appendLine("X-SOCIALPROFILE;TYPE=other:${clean.otherSocialUrl}")
            if (clean.bio.isNotBlank()) appendLine("NOTE:${clean.bio.replace("\n", " ")}")
            appendLine("END:VCARD")
        }
    }

    fun parseVCardToContact(vcf: String, source: String): SavedContactEntity {
        var fn = ""
        var org = ""
        var dept = ""
        var title = ""
        var phone = ""
        var whatsapp = ""
        var email = ""
        var address = ""
        var website = ""
        var linkedin = ""
        var facebook = ""
        var otherSocial = ""
        var bio = ""

        vcf.lines().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                line.startsWith("FN:", true) -> fn = line.substringAfter(":")
                line.startsWith("ORG:", true) -> {
                    val parts = line.substringAfter(":").split(";")
                    org = parts.getOrNull(0).orEmpty()
                    dept = parts.getOrNull(1).orEmpty()
                }
                line.startsWith("TITLE:", true) -> title = line.substringAfter(":")
                line.startsWith("TEL", true) && line.contains("WHATSAPP", true) ->
                    whatsapp = line.substringAfter(":")
                line.startsWith("TEL", true) -> if (phone.isEmpty()) phone = line.substringAfter(":")
                line.startsWith("EMAIL", true) -> email = line.substringAfter(":")
                line.startsWith("ADR", true) -> address = line.substringAfter(":").replace(";", " ").trim()
                line.startsWith("URL:", true) -> website = line.substringAfter(":")
                line.contains("linkedin", true) -> linkedin = line.substringAfter(":")
                line.contains("facebook", true) -> facebook = line.substringAfter(":")
                line.startsWith("X-SOCIALPROFILE", true) -> otherSocial = line.substringAfter(":")
                line.startsWith("NOTE:", true) -> bio = line.substringAfter(":")
            }
        }

        return SavedContactEntity(
            fullName = fn.ifBlank { "Unknown Contact" },
            designation = title,
            companyName = org,
            department = dept,
            bio = bio,
            phone = phone,
            whatsapp = whatsapp,
            email = email,
            officeAddress = address,
            website = website,
            linkedInUrl = linkedin,
            facebookUrl = facebook,
            otherSocialUrl = otherSocial,
            receivedVia = source
        )
    }

    fun generateQrCodeBitmap(
        content: String,
        sizePx: Int = 700,
        foregroundColor: Int = Color.parseColor("#0A192F"),
        backgroundColor: Int = Color.WHITE
    ): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 2
        )
        val safeContent = content.ifBlank { "CardLink" }
        val bitMatrix = QRCodeWriter().encode(safeContent, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        for (y in 0 until sizePx) {
            for (x in 0 until sizePx) {
                pixels[y * sizePx + x] = if (bitMatrix[x, y]) foregroundColor else backgroundColor
            }
        }
        return Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        }
    }

    fun renderCardToBitmap(card: BusinessCardEntity): Bitmap {
        val width = 1050
        val height = 600
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.primaryColorHex.toInt() }
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 40f, 40f, bgPaint)

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt() }
        canvas.drawRect(0f, 0f, 24f, height.toFloat(), accentPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.textColorHex.toInt()
            textSize = 52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.accentColorHex.toInt()
            textSize = 30f
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.textColorHex.toInt()
            textSize = 25f
        }

        val clean = card.sanitizedForSharing()
        canvas.drawText(clean.fullName.ifBlank { "Your Name" }, 70f, 110f, titlePaint)
        canvas.drawText("${clean.designation} • ${clean.companyName}", 70f, 165f, subtitlePaint)

        var yPos = 245f
        if (clean.phone.isNotBlank()) { canvas.drawText("Tel: ${clean.phone}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.email.isNotBlank()) { canvas.drawText("Email: ${clean.email}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.website.isNotBlank()) { canvas.drawText("Web: ${clean.website}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.officeAddress.isNotBlank()) { canvas.drawText(clean.officeAddress, 70f, yPos, bodyPaint) }

        val qrBitmap = generateQrCodeBitmap(toVCardString(clean), 250, Color.BLACK, Color.WHITE)
        canvas.drawBitmap(qrBitmap, width - 310f, height - 310f, null)

        return bitmap
    }

    fun shareVCardFile(context: Context, card: BusinessCardEntity) {
        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val safeName = card.fullName.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "cardlink" }
        val vcfFile = File(dir, "$safeName.vcf")
        vcfFile.writeText(toVCardString(card))

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", vcfFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/x-vcard"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${card.fullName} - Digital Business Card")
            putExtra(Intent.EXTRA_TEXT, buildTextSummary(card))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Business Card (.vcf)"))
    }

    fun shareCardAsPng(context: Context, card: BusinessCardEntity) {
        val bitmap = renderCardToBitmap(card)
        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val file = File(dir, "card_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, buildTextSummary(card))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Business Card Image"))
    }

    fun shareCardAsPdf(context: Context, card: BusinessCardEntity) {
        val bitmap = renderCardToBitmap(card)
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)
        pdfDocument.finishPage(page)

        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val file = File(dir, "CardLink_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { pdfDocument.writeTo(it) }
        pdfDocument.close()

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export Business Card PDF"))
    }

    fun shareAsText(context: Context, card: BusinessCardEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, buildTextSummary(card))
        }
        context.startActivity(Intent.createChooser(intent, "Share Contact Details"))
    }

    fun buildTextSummary(card: BusinessCardEntity): String {
        val c = card.sanitizedForSharing()
        return buildString {
            appendLine(c.fullName)
            if (c.designation.isNotBlank()) appendLine("${c.designation} | ${c.companyName}")
            if (c.phone.isNotBlank()) appendLine("Phone: ${c.phone}")
            if (c.email.isNotBlank()) appendLine("Email: ${c.email}")
            if (c.website.isNotBlank()) appendLine("Web: ${c.website}")
            if (c.linkedInUrl.isNotBlank()) appendLine("LinkedIn: ${c.linkedInUrl}")
        }.trim()
    }

    fun exportToAndroidContacts(context: Context, contact: SavedContactEntity) {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, contact.fullName)
            putExtra(ContactsContract.Intents.Insert.COMPANY, contact.companyName)
            putExtra(ContactsContract.Intents.Insert.JOB_TITLE, contact.designation)
            putExtra(ContactsContract.Intents.Insert.PHONE, contact.phone)
            putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, contact.whatsapp)
            putExtra(ContactsContract.Intents.Insert.EMAIL, contact.email)
            putExtra(ContactsContract.Intents.Insert.POSTAL, contact.officeAddress)
            putExtra(ContactsContract.Intents.Insert.NOTES, contact.bio + "\n" + contact.notes)
        }
        context.startActivity(intent)
    }
}
