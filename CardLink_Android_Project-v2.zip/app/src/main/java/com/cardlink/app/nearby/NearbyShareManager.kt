package com.cardlink.app.nearby

import android.content.Context
import com.cardlink.app.data.model.BusinessCardEntity
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.charset.StandardCharsets

data class DiscoveredPeer(val endpointId: String, val endpointName: String)

sealed class NearbyUiState {
    object Idle : NearbyUiState()
    object Searching : NearbyUiState()
    data class Connecting(val peerName: String) : NearbyUiState()
    data class TransferSuccess(val message: String) : NearbyUiState()
    data class ReceivedCardPreview(val card: BusinessCardEntity) : NearbyUiState()
    data class Error(val reason: String) : NearbyUiState()
}

class NearbyShareManager(context: Context) {
    private val connectionsClient = Nearby.getConnectionsClient(context)
    private val serviceId = "com.cardlink.app.NEARBY_SHARE"
    private val json = Json { ignoreUnknownKeys = true }

    private val _peers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val peers: StateFlow<List<DiscoveredPeer>> = _peers

    private val _uiState = MutableStateFlow<NearbyUiState>(NearbyUiState.Idle)
    val uiState: StateFlow<NearbyUiState> = _uiState

    private var outboundCard: BusinessCardEntity? = null

    fun startNearbySession(localUserName: String, cardToShare: BusinessCardEntity) {
        outboundCard = cardToShare.sanitizedForSharing()
        _peers.value = emptyList()
        _uiState.value = NearbyUiState.Searching

        val advOptions = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        connectionsClient.startAdvertising(
            localUserName.ifBlank { "CardLink User" },
            serviceId,
            connectionLifecycleCallback,
            advOptions
        ).addOnFailureListener {
            _uiState.value = NearbyUiState.Error("Advertising error: ${it.localizedMessage}")
        }

        val discOptions = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        connectionsClient.startDiscovery(serviceId, endpointDiscoveryCallback, discOptions)
    }

    fun connectAndSendToPeer(peer: DiscoveredPeer, localUserName: String) {
        _uiState.value = NearbyUiState.Connecting(peer.endpointName)
        connectionsClient.requestConnection(
            localUserName.ifBlank { "CardLink User" },
            peer.endpointId,
            connectionLifecycleCallback
        )
    }

    fun stopSession() {
        connectionsClient.stopAdvertising()
        connectionsClient.stopDiscovery()
        connectionsClient.stopAllEndpoints()
        _peers.value = emptyList()
        _uiState.value = NearbyUiState.Idle
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val current = _peers.value.toMutableList()
            if (current.none { it.endpointId == endpointId }) {
                current.add(DiscoveredPeer(endpointId, info.endpointName))
                _peers.value = current
            }
        }
        override fun onEndpointLost(endpointId: String) {
            _peers.value = _peers.value.filterNot { it.endpointId == endpointId }
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                outboundCard?.let { card ->
                    val bytes = json.encodeToString(card).toByteArray(StandardCharsets.UTF_8)
                    connectionsClient.sendPayload(endpointId, Payload.fromBytes(bytes))
                    _uiState.value = NearbyUiState.TransferSuccess("Business card sent!")
                }
            } else {
                _uiState.value = NearbyUiState.Error("Connection failed.")
            }
        }
        override fun onDisconnected(endpointId: String) {}
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            runCatching {
                val card = json.decodeFromString<BusinessCardEntity>(String(bytes, StandardCharsets.UTF_8))
                _uiState.value = NearbyUiState.ReceivedCardPreview(card)
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }
}
