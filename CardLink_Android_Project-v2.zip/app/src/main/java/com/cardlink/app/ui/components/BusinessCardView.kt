package com.cardlink.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.BusinessCardEntity

@Composable
fun BusinessCardView(card: BusinessCardEntity, modifier: Modifier = Modifier) {
    val bgColor = Color(card.primaryColorHex)
    val accentColor = Color(card.accentColorHex)
    val textColor = Color(card.textColorHex)
    val fontFamily = when (card.fontFamilyName) {
        "Serif" -> FontFamily.Serif
        "Monospace" -> FontFamily.Monospace
        else -> FontFamily.SansSerif
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 215.dp)
            .border(1.5.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(card.cornerRadiusDp.dp)),
        shape = RoundedCornerShape(card.cornerRadiusDp.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(bgColor, bgColor.copy(alpha = 0.88f))))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(54.dp).clip(CircleShape).border(2.dp, accentColor, CircleShape),
                        color = accentColor.copy(alpha = 0.2f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = card.fullName.take(2).uppercase().ifBlank { "CL" },
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp,
                                fontFamily = fontFamily
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(card.fullName.ifBlank { "Your Full Name" }, color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = fontFamily)
                        Text(card.designation.ifBlank { "Designation" }, color = accentColor, fontSize = 14.sp, fontWeight = FontWeight.Medium, fontFamily = fontFamily)
                        Text(
                            text = listOf(card.department, card.companyName).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "Company Name" },
                            color = textColor.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            fontFamily = fontFamily
                        )
                    }
                }

                HorizontalDivider(color = accentColor.copy(alpha = 0.3f))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (card.phone.isNotBlank() && card.sharePhone) InfoRow(Icons.Default.Phone, card.phone, accentColor, textColor, fontFamily)
                    if (card.email.isNotBlank() && card.shareEmail) InfoRow(Icons.Default.Email, card.email, accentColor, textColor, fontFamily)
                    if (card.website.isNotBlank()) InfoRow(Icons.Default.Language, card.website, accentColor, textColor, fontFamily)
                    if (card.officeAddress.isNotBlank() && card.shareAddress) InfoRow(Icons.Default.LocationOn, card.officeAddress, accentColor, textColor, fontFamily)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, tint: Color, color: Color, fontFamily: FontFamily) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Text(text = text, color = color, fontSize = 13.sp, fontFamily = fontFamily)
    }
}
