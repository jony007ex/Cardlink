package com.cardlink.app.ui

import android.app.Application
import android.net.Uri
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkGlanceWidget
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CardLinkViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CardLinkDatabase.getDatabase(application).dao()

    val myCards: StateFlow<List<BusinessCardEntity>> = dao.getAllMyCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCard: StateFlow<BusinessCardEntity> = myCards.map { list ->
        val card = list.firstOrNull { it.isDefault } ?: list.firstOrNull() ?: defaultSeedCard()
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(card)
        card
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), defaultSeedCard())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val contacts: StateFlow<List<SavedContactEntity>> = _searchQuery
        .flatMapLatest { q -> dao.searchContacts(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shareHistory: StateFlow<List<ShareHistoryEntity>> = dao.getShareHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _darkThemeOverride = MutableStateFlow<Boolean?>(null)
    val darkThemeOverride: StateFlow<Boolean?> = _darkThemeOverride

    init {
        viewModelScope.launch {
            if (dao.getDefaultCardSnapshot() == null) {
                dao.upsertMyCard(defaultSeedCard())
            }
        }
    }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }

    fun saveCard(card: BusinessCardEntity) {
        viewModelScope.launch {
            val id = dao.upsertMyCard(card)
            if (card.isDefault) dao.setActiveCard(if (card.id == 0L) id else card.id)
            runCatching { CardLinkGlanceWidget().updateAll(getApplication()) }
        }
    }

    fun switchActiveProfile(cardId: Long) {
        viewModelScope.launch {
            dao.setActiveCard(cardId)
            runCatching { CardLinkGlanceWidget().updateAll(getApplication()) }
        }
    }

    fun saveReceivedContact(contact: SavedContactEntity) {
        viewModelScope.launch { dao.upsertContact(contact) }
    }

    fun deleteContact(contact: SavedContactEntity) {
        viewModelScope.launch {
            ScannedCardStorageHelper.deleteSavedCardImage(contact.profilePhotoUri)
            dao.deleteContact(contact)
        }
    }

    fun logShare(method: String, recipient: String = "External") {
        viewModelScope.launch {
            dao.logShareEvent(ShareHistoryEntity(cardProfileTitle = activeCard.value.profileTitle, method = method, recipientInfo = recipient))
        }
    }

    fun toggleTheme(isDark: Boolean?) { _darkThemeOverride.value = isDark }

    fun exportFullJsonBackup(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val res = CardLinkBackupManager.exportFullBackupToUri(getApplication(), uri, dao.getAllMyCardsSnapshot(), dao.getAllContactsSnapshot())
            onComplete(res)
        }
    }

    fun importFullJsonBackup(uri: Uri, replaceExisting: Boolean, onComplete: (Result<RestoreSummary>) -> Unit) {
        viewModelScope.launch {
            val res = CardLinkBackupManager.importFullBackupFromUri(getApplication(), uri)
            res.onSuccess { (cards, cts) ->
                if (replaceExisting) { dao.clearAllMyCards(); dao.clearAllContacts() }
                if (cards.isNotEmpty()) dao.insertMyCardsBatch(cards)
                if (cts.isNotEmpty()) dao.insertContactsBatch(cts)
                onComplete(Result.success(RestoreSummary(cards.size, cts.size)))
            }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    fun exportBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            onComplete(CardLinkBackupManager.exportContactsToBatchVcf(getApplication(), uri, dao.getAllContactsSnapshot()))
        }
    }

    fun importBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val res = CardLinkBackupManager.importContactsFromBatchVcf(getApplication(), uri)
            res.onSuccess { dao.insertContactsBatch(it); onComplete(Result.success(it.size)) }
                .onFailure { onComplete(Result.failure(it)) }
        }
    }

    private fun defaultSeedCard() = BusinessCardEntity(
        profileTitle = "Executive Profile",
        isDefault = true,
        fullName = "Md. Mazharul Islam",
        designation = "Head of Central Procurement",
        companyName = "Corporate Division",
        department = "Central Procurement",
        bio = "Driving strategic sourcing, agile procurement, and digital transformation.",
        phone = "+880 1700-000000",
        whatsapp = "+8801700000000",
        email = "contact@cardlink.app",
        officeAddress = "Motijheel C/A, Dhaka, Bangladesh",
        website = "https://cardlink.app"
    )
}
