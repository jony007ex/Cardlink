package com.cardlink.app.tile

import android.app.PendingIntent
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.widget.CardLinkGlanceWidget

class CardLinkTileService : TileService() {
    companion object {
        const val ROUTE_QUICK_SHARE = "quick_nfc_qr_share"

        fun requestAddTile(context: Context, onResult: (String) -> Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val sbm = context.getSystemService(StatusBarManager::class.java)
                val cn = ComponentName(context, CardLinkTileService::class.java)
                sbm?.requestAddTileService(
                    cn,
                    "CardLink Share",
                    Icon.createWithResource(context, R.drawable.ic_qs_cardlink),
                    context.mainExecutor
                ) {
                    onResult("Quick Settings tile request completed!")
                }
            } else {
                onResult("Swipe down notification shade and tap Edit to add 'CardLink Share' tile.")
            }
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_ACTIVE
            label = "CardLink Share"
            updateTile()
        }
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE, ROUTE_QUICK_SHARE)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 101, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pi)
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
