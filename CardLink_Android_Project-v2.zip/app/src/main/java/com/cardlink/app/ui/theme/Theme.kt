package com.cardlink.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0A192F)
val NavySurface = Color(0xFF112240)
val CharcoalDark = Color(0xFF1E293B)
val GoldAccent = Color(0xFFD4AF37)
val OffWhite = Color(0xFFF8FAFC)

private val DarkColors = darkColorScheme(
    primary = GoldAccent,
    onPrimary = NavyPrimary,
    secondary = Color(0xFF64FFDA),
    background = NavyPrimary,
    surface = NavySurface,
    onBackground = OffWhite,
    onSurface = OffWhite
)

private val LightColors = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    secondary = GoldAccent,
    background = OffWhite,
    surface = Color.White,
    onBackground = NavyPrimary,
    onSurface = CharcoalDark
)

@Composable
fun CardLinkTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
