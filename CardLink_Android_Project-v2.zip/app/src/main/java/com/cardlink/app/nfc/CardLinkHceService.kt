package com.cardlink.app.nfc

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import java.nio.charset.StandardCharsets

class CardLinkHceService : HostApduService() {
    companion object {
        @Volatile
        var activeVCardPayload: String = "BEGIN:VCARD\nVERSION:3.0\nFN:CardLink User\nEND:VCARD"
        private val STATUS_SUCCESS = byteArrayOf(0x90.toByte(), 0x00.toByte())
        private val STATUS_FAILED = byteArrayOf(0x6F.toByte(), 0x00.toByte())

        val SELECT_CARDLINK_AID = byteArrayOf(
            0x00.toByte(), 0xA4.toByte(), 0x04.toByte(), 0x00.toByte(),
            0x08.toByte(), 0xF0.toByte(), 0x43.toByte(), 0x41.toByte(),
            0x52.toByte(), 0x44.toByte(), 0x4C.toByte(), 0x49.toByte(),
            0x4E.toByte(), 0x4B.toByte()
        )
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null) return STATUS_FAILED
        if (commandApdu.contentEquals(SELECT_CARDLINK_AID)) {
            return activeVCardPayload.toByteArray(StandardCharsets.UTF_8) + STATUS_SUCCESS
        }
        val ndefRecord = NdefRecord.createMime("text/x-vcard", activeVCardPayload.toByteArray(StandardCharsets.UTF_8))
        val ndefMessage = NdefMessage(arrayOf(ndefRecord))
        return ndefMessage.toByteArray() + STATUS_SUCCESS
    }

    override fun onDeactivated(reason: Int) {}
}
