package com.cardlink.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.NfcProjectEntity
import com.cardlink.app.ui.components.SmartPrivacyPreviewCard
import com.cardlink.app.util.*

private tailrec fun Context.findNfcActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findNfcActivity()
    else -> null
}

private enum class NfcArmMode {
    NONE, WRITE, READ, CLEAR, LOCK_READ_ONLY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NfcStudioScreen(
    activeCard: BusinessCardEntity,
    savedProjects: List<NfcProjectEntity>,
    onSaveProject: (NfcProjectEntity) -> Unit,
    onDeleteProject: (NfcProjectEntity) -> Unit,
    onUpdateCardSharing: (BusinessCardEntity) -> Unit,
    onOpenQrStudio: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findNfcActivity() }
    val hardwareState = remember { NfcStudioEngine.checkHardwareState(context) }

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Write, 1 = Read / Inspector, 2 = Saved Projects
    var selectedType by remember { mutableStateOf(NfcContentType.SHARING_PROFILE) }
    var sharingProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    var rawInput by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("") }

    var armMode by remember { mutableStateOf(NfcArmMode.NONE) }
    var preparedMessage by remember { mutableStateOf<NdefMessage?>(null) }
    var lastOperationResult by remember { mutableStateOf<NfcOperationResult?>(null) }
    var lastInspection by remember { mutableStateOf<NfcTagInspection?>(null) }

    var showClearConfirm by remember { mutableStateOf(false) }
    var showLockReadOnlyConfirm by remember { mutableStateOf(false) }
    var showSaveProjectDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    val projectedCard = remember(activeCard, sharingProfile) {
        SharingProfileManager.applyProfile(activeCard, sharingProfile)
    }

    // Lifecycle-aware Android NfcAdapter.enableReaderMode when armed
    DisposableEffect(armMode, preparedMessage) {
        val adapter = NfcAdapter.getDefaultAdapter(context)
        if (armMode != NfcArmMode.NONE && adapter != null && adapter.isEnabled && activity != null) {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS

            adapter.enableReaderMode(activity, { tag ->
                val result = when (armMode) {
                    NfcArmMode.WRITE -> {
                        val msg = preparedMessage
                        if (msg != null) NfcStudioEngine.writeAndVerifyTag(context, tag, msg)
                        else NfcOperationResult.Failure("No prepared NDEF message.")
                    }
                    NfcArmMode.READ -> NfcOperationResult.ReadSuccess(NfcStudioEngine.inspectTag(tag))
                    NfcArmMode.CLEAR -> NfcStudioEngine.clearTagAndVerify(context, tag)
                    NfcArmMode.LOCK_READ_ONLY -> NfcStudioEngine.makeTagReadOnly(context, tag)
                    NfcArmMode.NONE -> null
                }
                activity.runOnUiThread {
                    if (result != null) {
                        lastOperationResult = result
                        when (result) {
                            is NfcOperationResult.WriteVerified -> {
                                lastInspection = result.inspection
                                armMode = NfcArmMode.NONE
                            }
                            is NfcOperationResult.ReadSuccess -> {
                                lastInspection = result.inspection
                                armMode = NfcArmMode.NONE
                            }
                            is NfcOperationResult.ClearedVerified -> {
                                lastInspection = result.inspection
                                armMode = NfcArmMode.NONE
                            }
                            is NfcOperationResult.MadeReadOnly -> armMode = NfcArmMode.NONE
                            is NfcOperationResult.CapacityExceeded -> armMode = NfcArmMode.NONE
                            is NfcOperationResult.Failure -> armMode = NfcArmMode.NONE
                        }
                    }
                }
            }, flags, null)
        }
        onDispose {
            runCatching {
                if (activity != null) adapter?.disableReaderMode(activity)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.nfc_studio_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.nfc_studio_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = { showHelpDialog = true }) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "NFC Compatibility Help")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Hardware Status Banner
            when (hardwareState) {
                NfcHardwareState.UNSUPPORTED -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                            Text("NFC Not Supported on This Device", fontWeight = FontWeight.Bold)
                            Text(
                                "This device does not have NFC hardware. You can still use QR Code Studio for contactless sharing.",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            Button(onClick = onOpenQrStudio, modifier = Modifier.fillMaxWidth()) {
                                Text(stringResource(R.string.qr_studio_title), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    return@Column
                }
                NfcHardwareState.DISABLED -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null, tint = Color(0xFFF59E0B))
                            Text("Turn on NFC to read or write tags.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                runCatching { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }) { Text("Open Settings", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        }
                    }
                }
                NfcHardwareState.READY -> Unit
            }

            TabRow(selectedTabIndex = activeTab) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text(stringResource(R.string.nfc_write_tab), fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text(stringResource(R.string.nfc_read_tab), fontSize = 12.sp, fontWeight = FontWeight.Bold) })
                Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("Saved (${savedProjects.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Active Tap-Tag Banner when Armed
                if (armMode != NfcArmMode.NONE) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Contactless, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(40.dp))
                            Text(
                                text = stringResource(R.string.nfc_hold_tag_near),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = when (armMode) {
                                    NfcArmMode.WRITE -> "Ready to write & verify (${preparedMessage?.toByteArray()?.size ?: 0} bytes)"
                                    NfcArmMode.READ -> "Hold any compatible NFC tag to read & inspect"
                                    NfcArmMode.CLEAR -> "Hold writable NFC tag to clear NDEF content"
                                    NfcArmMode.LOCK_READ_ONLY -> "Hold NFC tag to permanently lock as Read-Only"
                                    NfcArmMode.NONE -> ""
                                },
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            TextButton(onClick = { armMode = NfcArmMode.NONE }) {
                                Text(stringResource(R.string.action_cancel), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Operation Result Banner
                lastOperationResult?.let { res ->
                    val (title, msg, isErr) = when (res) {
                        is NfcOperationResult.WriteVerified -> Triple(
                            stringResource(R.string.nfc_tag_verified),
                            "Written & verified (${res.bytesWritten} / ${res.maxBytes} bytes).",
                            false
                        )
                        is NfcOperationResult.ReadSuccess -> Triple(
                            "NFC Tag Read",
                            "${res.inspection.recordCount} record(s) • ${res.inspection.usedBytes} / ${res.inspection.maxSizeBytes} bytes",
                            false
                        )
                        is NfcOperationResult.ClearedVerified -> Triple("NFC Tag Cleared", "Tag cleared and verified empty.", false)
                        is NfcOperationResult.MadeReadOnly -> Triple("Tag Locked Read-Only", "This NFC tag is now permanently read-only.", false)
                        is NfcOperationResult.CapacityExceeded -> Triple(
                            "Content Too Large for Tag",
                            "Prepared size: ${res.neededBytes} bytes • Tag capacity: ${res.maxBytes} bytes. Use a shorter Sharing Profile, URL, or larger tag.",
                            true
                        )
                        is NfcOperationResult.Failure -> Triple("NFC Operation Failed", res.message, true)
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (isErr) MaterialTheme.colorScheme.error else Color(0xFF10B981))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, color = if (isErr) MaterialTheme.colorScheme.error else Color(0xFF10B981))
                            Text(msg, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                when (activeTab) {
                    0 -> {
                        // WRITE NFC TAG TAB
                        Text("Content Type", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            NfcContentType.values().forEach { t ->
                                FilterChip(
                                    selected = selectedType == t,
                                    onClick = { selectedType = t },
                                    label = { Text(t.label, fontSize = 11.5.sp) }
                                )
                            }
                        }

                        if (selectedType == NfcContentType.SHARING_PROFILE || selectedType == NfcContentType.VCARD) {
                            Text(stringResource(R.string.sharing_profile_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                SharingProfileType.values().forEach { p ->
                                    FilterChip(
                                        selected = sharingProfile == p,
                                        onClick = {
                                            sharingProfile = p
                                            SharingProfileManager.setActiveProfile(context, p)
                                        },
                                        label = { Text(p.label, fontSize = 11.5.sp) }
                                    )
                                }
                            }
                            SmartPrivacyPreviewCard(
                                card = projectedCard,
                                onUpdateSharingPreferences = onUpdateCardSharing
                            )
                        } else {
                            OutlinedTextField(
                                value = rawInput,
                                onValueChange = { rawInput = it },
                                label = { Text("${selectedType.label} Content *") },
                                singleLine = selectedType != NfcContentType.TEXT,
                                minLines = if (selectedType == NfcContentType.TEXT) 3 else 1,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        val previewBuild = remember(selectedType, rawInput, projectedCard, sharingProfile) {
                            NfcStudioEngine.buildNdefMessage(selectedType, rawInput, projectedCard, sharingProfile)
                        }
                        val encodedBytes = previewBuild.getOrNull()?.toByteArray()?.size ?: 0
                        if (encodedBytes > 0) {
                            Text(
                                text = "Encoded NDEF Size: $encodedBytes bytes (includes headers & metadata)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Button(
                            onClick = {
                                previewBuild.onSuccess { msg ->
                                    preparedMessage = msg
                                    lastOperationResult = null
                                    armMode = NfcArmMode.WRITE
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Enter valid content first.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.nfc_write_tab), fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showSaveProjectDialog = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Save as Reusable NFC Project")
                        }
                    }

                    1 -> {
                        // READ & TAG INSPECTOR TAB
                        Button(
                            onClick = {
                                lastOperationResult = null
                                armMode = NfcArmMode.READ
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Default.Contactless, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.nfc_read_tab), fontWeight = FontWeight.Bold)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showClearConfirm = true }, modifier = Modifier.weight(1f)) {
                                Text("Clear Tag", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { showLockReadOnlyConfirm = true },
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Make Read-Only", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }

                        lastInspection?.let { insp ->
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Tag Inspector", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text("Technologies: ${insp.techList.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                                    Text("NDEF Formatted: ${if (insp.isNdefFormatted) "Yes" else "No"} • Writable: ${if (insp.isWritable) "Yes" else "Read-Only"}", style = MaterialTheme.typography.bodySmall)
                                    Text("Capacity: ${insp.usedBytes} / ${insp.maxSizeBytes} bytes • Records: ${insp.recordCount}", style = MaterialTheme.typography.bodySmall)
                                    if (insp.parsedRecords.isNotEmpty()) {
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                        insp.parsedRecords.forEach { (recType, recVal) ->
                                            Text("$recType: $recVal", style = MaterialTheme.typography.labelSmall)
                                        }
                                        if (insp.primaryPayload.startsWith("http", true)) {
                                            OutlinedButton(
                                                onClick = {
                                                    runCatching {
                                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(insp.primaryPayload)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth()
                                            ) { Text("Open Link") }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        // SAVED NFC PROJECTS TAB
                        if (savedProjects.isEmpty()) {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Nfc, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
                                    Text("No Saved NFC Projects Yet", fontWeight = FontWeight.Bold)
                                    Text("Save your business card, conference profile, or website links here to rewrite onto NFC tags anytime.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                                }
                            }
                        } else {
                            savedProjects.forEach { proj ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        selectedType = runCatching { NfcContentType.valueOf(proj.contentType) }.getOrDefault(NfcContentType.URL)
                                        rawInput = proj.payload
                                        projectName = proj.name
                                        activeTab = 0
                                    },
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(Icons.Default.Nfc, null, tint = MaterialTheme.colorScheme.primary)
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(proj.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(proj.contentType, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        IconButton(onClick = { onDeleteProject(proj) }) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear NFC Tag?", fontWeight = FontWeight.Bold) },
            text = { Text("This will remove the current NDEF content from the compatible tag.") },
            confirmButton = {
                Button(onClick = { showClearConfirm = false; armMode = NfcArmMode.CLEAR }) { Text(stringResource(R.string.action_continue)) }
            },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showLockReadOnlyConfirm) {
        AlertDialog(
            onDismissRequest = { showLockReadOnlyConfirm = false },
            title = { Text("Make NFC Tag Permanently Read-Only?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = { Text("This action may be permanent. The NFC tag may never be editable again.") },
            confirmButton = {
                Button(
                    onClick = { showLockReadOnlyConfirm = false; armMode = NfcArmMode.LOCK_READ_ONLY },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Lock Permanently") }
            },
            dismissButton = { TextButton(onClick = { showLockReadOnlyConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showSaveProjectDialog) {
        var nameInput by remember(projectName) { mutableStateOf(projectName.ifBlank { selectedType.label }) }
        AlertDialog(
            onDismissRequest = { showSaveProjectDialog = false },
            title = { Text("Save NFC Project", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Project Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    val trimmed = nameInput.trim().ifBlank { selectedType.label }
                    onSaveProject(
                        NfcProjectEntity(
                            name = trimmed,
                            contentType = selectedType.name,
                            payload = rawInput.trim(),
                            sharingProfileId = sharingProfile.id
                        )
                    )
                    showSaveProjectDialog = false
                    Toast.makeText(context, "NFC project saved!", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showSaveProjectDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("NFC Tag Guidance", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• Small URL / Text: A standard NFC Forum NDEF tag (e.g. NTAG213/215) works well.", style = MaterialTheme.typography.bodySmall)
                    Text("• vCard / Multiple Records: Requires larger usable capacity (e.g. NTAG215/216). Usable space is slightly less than marketing capacity due to NDEF headers.", style = MaterialTheme.typography.bodySmall)
                    Text("• Metal Surfaces: Use anti-metal NFC tags for metal desks or phone cases.", style = MaterialTheme.typography.bodySmall)
                    Text("• Security Note: Standard NDEF tags are readable by nearby phones. Never write passwords, ID numbers, or Secure Notes to an NFC tag.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showHelpDialog = false }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
