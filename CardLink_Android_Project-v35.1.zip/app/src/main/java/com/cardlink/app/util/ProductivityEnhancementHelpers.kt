package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.cardlink.app.data.model.*
import kotlinx.serialization.Serializable

@Serializable
data class NotificationCategoryPrefs(
    val followUpEnabled: Boolean = true,
    val idExpiryEnabled: Boolean = true,
    val backupReminderEnabled: Boolean = true,
    val securityAlertsEnabled: Boolean = true
)

object NotificationCategoryManager {
    private const val PREFS = "cardlink_notif_categories_prefs"
    private const val K_FOLLOWUP = "cat_followup"
    private const val K_ID_EXPIRY = "cat_id_expiry"
    private const val K_BACKUP = "cat_backup"
    private const val K_SECURITY = "cat_security"

    fun load(context: Context): NotificationCategoryPrefs {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return NotificationCategoryPrefs(
            followUpEnabled = p.getBoolean(K_FOLLOWUP, true),
            idExpiryEnabled = p.getBoolean(K_ID_EXPIRY, true),
            backupReminderEnabled = p.getBoolean(K_BACKUP, true),
            securityAlertsEnabled = p.getBoolean(K_SECURITY, true)
        )
    }

    fun save(context: Context, cfg: NotificationCategoryPrefs) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(K_FOLLOWUP, cfg.followUpEnabled)
            .putBoolean(K_ID_EXPIRY, cfg.idExpiryEnabled)
            .putBoolean(K_BACKUP, cfg.backupReminderEnabled)
            .putBoolean(K_SECURITY, cfg.securityAlertsEnabled)
            .apply()
    }
}

data class DuplicateContactPair(
    val primary: SavedContactEntity,
    val duplicate: SavedContactEntity,
    val matchReason: String
)

object SmartDuplicateDetector {
    /**
     * Identifies possible duplicate contacts using multiple normalized signals:
     * 1. Normalized phone number (last 8+ digits match)
     * 2. Normalized email address match
     * 3. Name similarity + same Company (NEVER name alone!)
     */
    fun findDuplicatePairs(contacts: List<SavedContactEntity>): List<DuplicateContactPair> {
        val pairs = mutableListOf<DuplicateContactPair>()
        val seenIds = mutableSetOf<Pair<Long, Long>>()

        for (i in contacts.indices) {
            val a = contacts[i]
            val phoneA = a.phone.filter { it.isDigit() }.takeLast(8)
            val emailA = a.email.trim().lowercase()
            val nameA = a.fullName.trim().lowercase()
            val compA = a.companyName.trim().lowercase()

            for (j in i + 1 until contacts.size) {
                val b = contacts[j]
                val key = minOf(a.id, b.id) to maxOf(a.id, b.id)
                if (key in seenIds) continue

                val phoneB = b.phone.filter { it.isDigit() }.takeLast(8)
                val emailB = b.email.trim().lowercase()
                val nameB = b.fullName.trim().lowercase()
                val compB = b.companyName.trim().lowercase()

                val reason = when {
                    phoneA.length >= 7 && phoneA == phoneB -> "Matching phone number"
                    emailA.isNotBlank() && emailA == emailB -> "Matching email address"
                    nameA.length >= 3 && compA.length >= 2 && nameA == nameB && compA == compB -> "Same name & company"
                    else -> null
                }
                if (reason != null) {
                    seenIds.add(key)
                    pairs.add(DuplicateContactPair(a, b, reason))
                }
            }
        }
        return pairs
    }
}

data class BackupChangeSummary(
    val contactsChanged: Int,
    val idsChanged: Int,
    val loyaltyChanged: Int,
    val qrProjectsChanged: Int,
    val secureNotesChanged: Int
) {
    val totalChanges: Int
        get() = contactsChanged + idsChanged + loyaltyChanged + qrProjectsChanged + secureNotesChanged

    fun nonZeroLines(): List<String> = buildList {
        if (contactsChanged > 0) add("$contactsChanged Contact(s) added or updated")
        if (idsChanged > 0) add("$idsChanged ID(s) added or updated")
        if (loyaltyChanged > 0) add("$loyaltyChanged Loyalty Card(s) updated")
        if (qrProjectsChanged > 0) add("$qrProjectsChanged QR Project(s) changed")
        if (secureNotesChanged > 0) add("$secureNotesChanged Secure Note(s) updated")
    }
}

object BackupChangeTracker {
    fun computeSinceLastBackup(
        context: Context,
        contacts: List<SavedContactEntity>,
        idDocuments: List<IdDocumentEntity>,
        loyaltyCards: List<LoyaltyCardEntity>,
        qrProjects: List<QrProjectEntity>,
        secureNotes: List<SecureNoteEntity>
    ): BackupChangeSummary {
        val masterTs = MasterBackupManager.getMasterInfo(context).lastUpdatedTimestamp ?: 0L
        val legacyTs = BackupCenterPrefs.getLastBackupTimestamp(context) ?: 0L
        val lastTs = maxOf(masterTs, legacyTs)
        if (lastTs <= 0L) {
            return BackupChangeSummary(
                contactsChanged = contacts.size,
                idsChanged = idDocuments.size,
                loyaltyChanged = loyaltyCards.size,
                qrProjectsChanged = qrProjects.size,
                secureNotesChanged = secureNotes.size
            )
        }
        return BackupChangeSummary(
            contactsChanged = contacts.count { it.savedAtTimestamp > lastTs },
            idsChanged = idDocuments.count { it.updatedAtTimestamp > lastTs },
            loyaltyChanged = loyaltyCards.count { it.updatedAtTimestamp > lastTs },
            qrProjectsChanged = qrProjects.count { it.updatedAtTimestamp > lastTs },
            secureNotesChanged = secureNotes.count { it.updatedAtTimestamp > lastTs }
        )
    }
}

enum class IncomingShareKind {
    URL,
    VCARD,
    IMAGE,
    PDF,
    TEXT
}

data class IncomingSharePayload(
    val kind: IncomingShareKind,
    val text: String = "",
    val uris: List<Uri> = emptyList(),
    val mimeType: String = ""
)

object ShareIntentExtractor {
    fun extract(intent: Intent?): IncomingSharePayload? {
        if (intent == null) return null
        val action = intent.action ?: return null
        if (action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return null
        val mime = intent.type.orEmpty().lowercase()

        if (action == Intent.ACTION_SEND_MULTIPLE && mime.startsWith("image/")) {
            val list = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
            }.orEmpty()
            return if (list.isNotEmpty()) IncomingSharePayload(IncomingShareKind.IMAGE, uris = list, mimeType = mime) else null
        }

        val streamUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty().trim()

        return when {
            mime.contains("vcard") || sharedText.startsWith("BEGIN:VCARD", true) -> {
                IncomingSharePayload(IncomingShareKind.VCARD, text = sharedText, uris = listOfNotNull(streamUri), mimeType = mime)
            }
            mime.contains("pdf") && streamUri != null -> {
                IncomingSharePayload(IncomingShareKind.PDF, uris = listOf(streamUri), mimeType = mime)
            }
            mime.startsWith("image/") && streamUri != null -> {
                IncomingSharePayload(IncomingShareKind.IMAGE, uris = listOf(streamUri), mimeType = mime)
            }
            sharedText.startsWith("http://", true) || sharedText.startsWith("https://", true) -> {
                IncomingSharePayload(IncomingShareKind.URL, text = sharedText, mimeType = mime)
            }
            sharedText.isNotBlank() -> {
                IncomingSharePayload(IncomingShareKind.TEXT, text = sharedText, mimeType = mime)
            }
            else -> null
        }
    }
}
