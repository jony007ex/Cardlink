package com.cardlink.app.ui.screens

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.cardlink.app.R
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.BusinessCardOcrParser
import com.cardlink.app.util.ScannedCardStorageHelper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

@Composable
fun OcrCardScannerScreen(
    onContactSaved: (SavedContactEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var isProcessing by remember { mutableStateOf(false) }

    // Dual-Side state: Front capture -> optional Back capture -> Verify merged result
    var scanningSide by remember { mutableStateOf("FRONT") } // "FRONT" or "BACK"
    var frontParsed by remember { mutableStateOf<SavedContactEntity?>(null) }
    var frontPhotoUri by remember { mutableStateOf<String?>(null) }
    var backPhotoUri by remember { mutableStateOf<String?>(null) }
    var extractedDraft by remember { mutableStateOf<SavedContactEntity?>(null) }

    val imageCapture = remember { ImageCapture.Builder().build() }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasCameraPermission = it
    }

    fun handleRecognizedBitmap(bmp: Bitmap) {
        scope.launch {
            isProcessing = true
            runCatching {
                val savedUri = withContext(Dispatchers.IO) { ScannedCardStorageHelper.saveCardBitmapLocally(context, bmp) }
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val visionText = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                val parsed = BusinessCardOcrParser.parse(visionText)

                if (scanningSide == "FRONT") {
                    frontParsed = parsed
                    frontPhotoUri = savedUri
                    scanningSide = "BACK"
                    Toast.makeText(context, "Front scanned! Now scan Back side or tap 'Verify Now'.", Toast.LENGTH_LONG).show()
                } else {
                    backPhotoUri = savedUri
                    val merged = if (frontParsed != null) {
                        BusinessCardOcrParser.mergeDualSide(frontParsed!!, parsed)
                    } else {
                        parsed
                    }
                    extractedDraft = merged.copy(
                        profilePhotoUri = frontPhotoUri ?: savedUri,
                        backPhotoUri = savedUri
                    )
                }
            }.onFailure {
                Toast.makeText(context, "OCR error: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
            isProcessing = false
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri) }
                if (bmp != null) {
                    handleRecognizedBitmap(bmp)
                } else {
                    Toast.makeText(context, "Cannot decode selected image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) permLauncher.launch(Manifest.permission.CAMERA)
    }

    // Verification & Edit Screen after Front (or Front + Back) OCR
    if (extractedDraft != null) {
        var draft by remember(extractedDraft) { mutableStateOf(extractedDraft!!) }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = if (!draft.backPhotoUri.isNullOrBlank()) stringResource(R.string.ocr_verify_dual) else stringResource(R.string.ocr_verify_single),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!draft.profilePhotoUri.isNullOrBlank()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.detail_front_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Card(
                            modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            AsyncImage(model = Uri.parse(draft.profilePhotoUri), contentDescription = "Front", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
                if (!draft.backPhotoUri.isNullOrBlank()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.detail_back_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Card(
                            modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            AsyncImage(model = Uri.parse(draft.backPhotoUri), contentDescription = "Back", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }

            OutlinedTextField(value = draft.fullName, onValueChange = { draft = draft.copy(fullName = it) }, label = { Text(stringResource(R.string.edit_full_name)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text(stringResource(R.string.edit_designation)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text(stringResource(R.string.edit_company)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.phone, onValueChange = { draft = draft.copy(phone = it) }, label = { Text(stringResource(R.string.detail_phone)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text(stringResource(R.string.detail_whatsapp)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text(stringResource(R.string.edit_email)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.officeAddress, onValueChange = { draft = draft.copy(officeAddress = it) }, label = { Text(stringResource(R.string.edit_office_address)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text(stringResource(R.string.edit_website)) }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        extractedDraft = null
                        frontParsed = null
                        frontPhotoUri = null
                        backPhotoUri = null
                        scanningSide = "FRONT"
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.ocr_rescan)) }
                Button(onClick = { onContactSaved(draft) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.ocr_save_contact)) }
            }
        }
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (hasCameraPermission) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val future = ProcessCameraProvider.getInstance(ctx)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                        provider.unbindAll()
                        provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )

            val scannerAccent = MaterialTheme.colorScheme.primary
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            ) {
                val cardW = size.width * 0.88f
                val cardH = cardW / 1.586f
                val left = (size.width - cardW) / 2f
                val top = (size.height - cardH) / 2.2f
                drawRect(color = Color.Black.copy(alpha = 0.55f))
                drawRoundRect(color = Color.Transparent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), blendMode = BlendMode.Clear)
                drawRoundRect(color = scannerAccent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), style = Stroke(width = 6f))
            }

            // Dual-Side Status Banner at Top
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF0A192F).copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (scanningSide == "FRONT") Icons.Default.DocumentScanner else Icons.Default.Flip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (scanningSide == "FRONT") stringResource(R.string.ocr_step_front) else stringResource(R.string.ocr_step_back),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                if (frontParsed != null) {
                    Button(
                        onClick = {
                            extractedDraft = frontParsed!!.copy(profilePhotoUri = frontPhotoUri)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) {
                        Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.ocr_skip_back), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) { Text(stringResource(R.string.qr_gallery)) }

                Button(
                    onClick = {
                        isProcessing = true
                        imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                val bmp = imageProxy.toBitmapSafe()
                                imageProxy.close()
                                if (bmp == null) {
                                    isProcessing = false
                                    return
                                }
                                val cropped = ScannedCardStorageHelper.cropToCardFrame(bmp)
                                handleRecognizedBitmap(cropped)
                            }
                            override fun onError(exc: ImageCaptureException) { isProcessing = false }
                        })
                    },
                    enabled = !isProcessing,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.size(68.dp)
                ) {
                    if (isProcessing) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(28.dp))
                    else Icon(Icons.Default.DocumentScanner, null, tint = MaterialTheme.colorScheme.onPrimary)
                }

                OutlinedButton(onClick = onNavigateBack, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                    Text(stringResource(R.string.action_back))
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Camera permission is required to scan paper business cards.", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Pick from Gallery", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

private fun ImageProxy.toBitmapSafe(): Bitmap? {
    val buffer = planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rot = imageInfo.rotationDegrees
    if (rot == 0) return raw
    val m = Matrix().apply { postRotate(rot.toFloat()) }
    return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
}
