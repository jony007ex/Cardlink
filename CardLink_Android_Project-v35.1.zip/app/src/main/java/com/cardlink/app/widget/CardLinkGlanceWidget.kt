package com.cardlink.app.widget

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.util.BiometricLockHelper
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.LanguageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CardLinkWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = CardLinkGlanceWidget()
}

class CardLinkGlanceWidget : GlanceAppWidget() {
    companion object {
        const val EXTRA_WIDGET_ROUTE = "com.cardlink.app.EXTRA_WIDGET_ROUTE"
    }

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val locCtx = LanguageManager.wrapBaseContext(context)
        val isLocked = BiometricLockHelper.isLockEnabled(context)
        val activeCard = withContext(Dispatchers.IO) {
            CardLinkDatabase.getDatabase(context).dao().getDefaultCardSnapshot()
        }

        val qrBitmap = if (!isLocked && activeCard != null) {
            val vcf = CardShareHelper.toVCardString(activeCard)
            CardLinkHceService.activeVCardPayload = vcf
            CardLinkHceService.activeShareUrl = activeCard.resolveNfcShareUrl()
            withContext(Dispatchers.Default) {
                CardShareHelper.generateQrCodeBitmap(vcf, 320, AndroidColor.parseColor("#0A192F"), AndroidColor.WHITE)
            }
        } else null

        provideContent { WidgetBody(locCtx, activeCard, qrBitmap, isLocked) }
    }

    @Composable
    private fun WidgetBody(context: Context, card: BusinessCardEntity?, qrBitmap: Bitmap?, isLocked: Boolean) {
        val navy = ColorProvider(Color(0xFF0A192F))
        val gold = ColorProvider(Color(0xFFD4AF37))
        val white = ColorProvider(Color(0xFFF8FAFC))

        Box(modifier = GlanceModifier.fillMaxSize().background(navy).cornerRadius(18.dp).padding(12.dp)) {
            Row(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = GlanceModifier.defaultWeight()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            provider = ImageProvider(R.mipmap.ic_launcher),
                            contentDescription = "CardLink",
                            modifier = GlanceModifier.size(20.dp).cornerRadius(5.dp)
                        )
                        Spacer(GlanceModifier.width(6.dp))
                        Text(
                            text = (card?.profileTitle ?: "CARDLINK").uppercase(),
                            style = TextStyle(color = gold, fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                    }
                    Spacer(GlanceModifier.height(4.dp))
                    Text(
                        text = if (isLocked) "CardLink" else card?.fullName?.ifBlank { "CardLink" } ?: context.getString(R.string.widget_setup_card),
                        style = TextStyle(color = white, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                        maxLines = 1
                    )
                    Text(
                        text = if (isLocked) context.getString(R.string.widget_locked_hint)
                        else listOfNotNull(card?.designation?.takeIf { it.isNotBlank() }, card?.companyName?.takeIf { it.isNotBlank() }).joinToString(" • "),
                        style = TextStyle(color = white, fontSize = 11.sp),
                        maxLines = 1
                    )
                    Spacer(GlanceModifier.height(8.dp))
                    Row {
                        Box(
                            modifier = GlanceModifier.background(gold).cornerRadius(8.dp).padding(horizontal = 10.dp, vertical = 5.dp)
                                .clickable(actionStartActivity(routeIntent(context, "quick_nfc_qr_share")))
                        ) {
                            Text("NFC + QR", style = TextStyle(color = navy, fontSize = 11.sp, fontWeight = FontWeight.Bold))
                        }
                        Spacer(GlanceModifier.width(6.dp))
                        Box(
                            modifier = GlanceModifier.background(white).cornerRadius(8.dp).padding(horizontal = 10.dp, vertical = 5.dp)
                                .clickable(actionStartActivity(routeIntent(context, "scan_ocr")))
                        ) {
                            Text(context.getString(R.string.home_scan_card), style = TextStyle(color = navy, fontSize = 11.sp, fontWeight = FontWeight.Bold))
                        }
                    }
                }
                if (qrBitmap != null) {
                    Spacer(GlanceModifier.width(8.dp))
                    Box(
                        modifier = GlanceModifier.size(96.dp).background(ColorProvider(Color.White)).cornerRadius(12.dp).padding(4.dp)
                            .clickable(actionStartActivity(routeIntent(context, "qr_screen")))
                    ) {
                        Image(provider = ImageProvider(qrBitmap), contentDescription = "QR", modifier = GlanceModifier.fillMaxSize())
                    }
                }
            }
        }
    }

    private fun routeIntent(context: Context, route: String): Intent =
        Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_WIDGET_ROUTE, route)
        }
}
