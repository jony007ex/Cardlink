package com.cardlink.app.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.cardlink.app.MainActivity
import com.cardlink.app.R
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.IdDocumentEntity
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

object IdExpiryReminderScheduler {
    const val EXTRA_ID_DOC_UUID = "extra_id_doc_uuid"
    const val EXTRA_ID_MILESTONE_DAYS = "extra_id_milestone_days"

    private val MILESTONES_DAYS = listOf(60, 30, 0)

    private fun requestCodeFor(docUuid: String, milestoneDays: Int): Int {
        val base = (docUuid.hashCode() and 0x0FFFFFFF) % 100_000
        return 500_000 + base * 10 + when (milestoneDays) {
            60 -> 1
            30 -> 2
            else -> 3
        }
    }

    /**
     * Cancels obsolete reminders and schedules only applicable FUTURE milestones
     * (60 days before, 30 days before, and on expiry day at 09:00 local time).
     */
    fun scheduleForDocument(context: Context, doc: IdDocumentEntity): Int {
        FollowUpScheduler.ensureChannels(context)
        cancelForDocument(context, doc.stableUuid)

        if (!doc.expiryRemindersEnabled) return 0
        if (!FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) return 0

        val expiryDate = IdExpiryHelper.parseIsoDate(doc.expiryDateIso) ?: return 0
        val today = LocalDate.now()
        if (expiryDate.isBefore(today)) return 0

        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return 0
        val nowMillis = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        var scheduledCount = 0

        for (daysBefore in MILESTONES_DAYS) {
            val triggerDate = expiryDate.minusDays(daysBefore.toLong())
            val triggerMillis = triggerDate.atTime(LocalTime.of(9, 0)).atZone(zone).toInstant().toEpochMilli()
            if (triggerMillis <= nowMillis + 5_000L) {
                // Skip past milestones — never schedule historical alarms
                continue
            }

            val intent = Intent(context, com.cardlink.app.receiver.IdExpiryAlarmReceiver::class.java).apply {
                putExtra(EXTRA_ID_DOC_UUID, doc.stableUuid)
                putExtra(EXTRA_ID_MILESTONE_DAYS, daysBefore)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                requestCodeFor(doc.stableUuid, daysBefore),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
                }
                scheduledCount++
            }.onFailure {
                runCatching {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
                    scheduledCount++
                }
            }
        }
        return scheduledCount
    }

    fun cancelForDocument(context: Context, docUuid: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        for (daysBefore in MILESTONES_DAYS) {
            val intent = Intent(context, com.cardlink.app.receiver.IdExpiryAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context,
                requestCodeFor(docUuid, daysBefore),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
            pi.cancel()
        }
    }

    suspend fun rescheduleAll(context: Context) {
        val docs = CardLinkDatabase.getDatabase(context).dao().getAllIdDocumentsSnapshot()
        docs.forEach { scheduleForDocument(context, it) }
    }

    fun showExpiryNotification(context: Context, doc: IdDocumentEntity, milestoneDays: Int) {
        FollowUpScheduler.ensureChannels(context)
        if (!FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) return

        val locCtx = LanguageManager.wrapBaseContext(context)
        val title = when (milestoneDays) {
            60 -> locCtx.getString(R.string.id_notif_60d_title)
            30 -> locCtx.getString(R.string.id_notif_30d_title)
            else -> locCtx.getString(R.string.id_notif_today_title)
        }
        val body = when (milestoneDays) {
            60 -> locCtx.getString(R.string.id_notif_60d_msg, doc.documentName)
            30 -> locCtx.getString(R.string.id_notif_30d_msg, doc.documentName)
            else -> locCtx.getString(R.string.id_notif_today_msg, doc.documentName)
        }

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ID_DOC_UUID, doc.stableUuid)
        }
        val contentPi = PendingIntent.getActivity(
            context,
            requestCodeFor(doc.stableUuid, milestoneDays),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, FollowUpScheduler.CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(requestCodeFor(doc.stableUuid, milestoneDays), notif)
    }
}
