package com.cardlink.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

enum class FeedbackType(val templateLabel: String) {
    FEATURE_REQUEST("Feature Request"),
    REPORT_PROBLEM("Bug Report"),
    IMPROVEMENT("Improvement Suggestion"),
    UI_UX("UI/UX Feedback"),
    GENERAL("General Feedback")
}

data class FeedbackDraft(
    val type: FeedbackType,
    val message: String,
    val includeDiagnostics: Boolean
)

/**
 * Accurately distinguishes handoff outcomes so CardLink never falsely claims
 * "Feedback Sent Successfully" merely because an external app was opened.
 */
sealed class FeedbackSubmissionResult {
    object WhatsAppHandoffOpened : FeedbackSubmissionResult()
    object CommunityLinkOpened : FeedbackSubmissionResult()
    object DirectBackendAccepted : FeedbackSubmissionResult()
    data class Failed(val reason: String) : FeedbackSubmissionResult()
}

/**
 * Service abstraction designed so CardLink can later plug in an official
 * backend -> WhatsApp Business Cloud / Groups API submission channel
 * without storing any permanent API tokens inside the APK.
 */
interface FeedbackSubmissionService {
    fun formatFeedbackMessage(context: Context, draft: FeedbackDraft): String
    fun submitFeedback(context: Context, draft: FeedbackDraft): FeedbackSubmissionResult
    fun openCommunityLink(context: Context): FeedbackSubmissionResult
}

object WhatsAppFeedbackSubmissionService : FeedbackSubmissionService {

    const val CARDLINK_WHATSAPP_COMMUNITY_URL =
        "https://chat.whatsapp.com/BZMGBSV5y5z86IsnbRxdbd?s=cl&p=a&iam=2"

    private val WHATSAPP_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")

    override fun formatFeedbackMessage(context: Context, draft: FeedbackDraft): String {
        val (verName, _) = readSafeAppVersion(context)
        val cleanMsg = draft.message.trim()

        if (draft.type == FeedbackType.REPORT_PROBLEM) {
            return buildString {
                appendLine("CardLink Bug Report")
                appendLine()
                appendLine("Issue:")
                appendLine(cleanMsg)
                if (draft.includeDiagnostics) {
                    val deviceModel = listOf(Build.MANUFACTURER, Build.MODEL)
                        .map { it.orEmpty().trim() }
                        .filter { it.isNotBlank() }
                        .distinct()
                        .joinToString(" ")
                    appendLine()
                    appendLine("CardLink Version: $verName")
                    appendLine("Android Version: ${Build.VERSION.RELEASE}")
                    if (deviceModel.isNotBlank()) {
                        appendLine("Device: $deviceModel")
                    }
                } else {
                    appendLine()
                    appendLine("App Version: $verName")
                }
            }.trim()
        }

        return buildString {
            appendLine("CardLink Feedback")
            appendLine()
            appendLine("Type: ${draft.type.templateLabel}")
            appendLine()
            appendLine("Message:")
            appendLine(cleanMsg)
            appendLine()
            appendLine("App Version: $verName")
        }.trim()
    }

    /**
     * Officially supported Android handoff:
     * 1. If WhatsApp / WhatsApp Business is installed, launches ACTION_SEND (text/plain)
     *    directly into WhatsApp with EXTRA_TEXT pre-populated — no manual Copy/Paste needed.
     * 2. If WhatsApp is not installed, gracefully falls back to opening the exact
     *    CardLink Community URL in an available browser.
     * Never uses clipboard hacks, accessibility automation, or private WhatsApp endpoints.
     */
    override fun submitFeedback(context: Context, draft: FeedbackDraft): FeedbackSubmissionResult {
        val formatted = formatFeedbackMessage(context, draft)
        val installedWhatsApp = findInstalledWhatsAppPackage(context)

        if (installedWhatsApp != null) {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage(installedWhatsApp)
                putExtra(Intent.EXTRA_TEXT, formatted)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val opened = runCatching {
                context.startActivity(sendIntent)
                true
            }.getOrDefault(false)
            if (opened) {
                return FeedbackSubmissionResult.WhatsAppHandoffOpened
            }
        }

        // Fallback to exact community URL via browser / compatible handler
        return openCommunityLink(context)
    }

    override fun openCommunityLink(context: Context): FeedbackSubmissionResult {
        val uri = Uri.parse(CARDLINK_WHATSAPP_COMMUNITY_URL)
        return try {
            val viewIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
            FeedbackSubmissionResult.CommunityLinkOpened
        } catch (_: ActivityNotFoundException) {
            FeedbackSubmissionResult.Failed("No compatible application found.")
        } catch (_: Exception) {
            FeedbackSubmissionResult.Failed("Unable to open WhatsApp or browser.")
        }
    }

    private fun findInstalledWhatsAppPackage(context: Context): String? {
        val pm = context.packageManager
        for (pkg in WHATSAPP_PACKAGES) {
            val installed = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, 0)
                }
                true
            }.getOrDefault(false)
            if (installed) return pkg
        }
        return null
    }

    private fun readSafeAppVersion(context: Context): Pair<String, Long> = runCatching {
        val pi = context.packageManager.getPackageInfo(context.packageName, 0)
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pi.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pi.versionCode.toLong()
        }
        Pair(pi.versionName ?: "8.2.0", code)
    }.getOrDefault(Pair("8.2.0", 27L))
}
