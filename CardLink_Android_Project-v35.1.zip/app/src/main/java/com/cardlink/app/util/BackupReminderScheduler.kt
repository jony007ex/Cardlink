package com.cardlink.app.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.cardlink.app.MainActivity
import com.cardlink.app.R

object BackupReminderScheduler {
    private const val REQUEST_CODE = 770_101
    private const val NOTIFICATION_ID = 770_102

    fun scheduleNextReminder(context: Context) {
        cancel(context)
        val days = BackupCenterPrefs.getReminderIntervalDays(context)
        if (days <= 0) return
        if (!FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) return

        val lastTs = BackupCenterPrefs.getLastBackupTimestamp(context) ?: System.currentTimeMillis()
        val intervalMs = days.toLong() * 24L * 3600_000L
        val now = System.currentTimeMillis()
        val triggerAt = maxOf(lastTs + intervalMs, now + 6L * 3600_000L)

        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, com.cardlink.app.receiver.BackupReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, com.cardlink.app.receiver.BackupReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        pi.cancel()
    }

    fun showBackupReminderNotification(context: Context) {
        FollowUpScheduler.ensureChannels(context)
        if (!FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) return

        val locCtx = LanguageManager.wrapBaseContext(context)
        val days = BackupCenterPrefs.getReminderIntervalDays(context)
        if (days <= 0) return

        val lastTs = BackupCenterPrefs.getLastBackupTimestamp(context)
        val elapsedDays = if (lastTs != null) ((System.currentTimeMillis() - lastTs) / (24L * 3600_000L)).toInt().coerceAtLeast(1) else days

        val title = locCtx.getString(R.string.backup_reminder_notif_title)
        val body = locCtx.getString(R.string.backup_reminder_notif_body, elapsedDays)

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_route", "menu_backup_export")
        }
        val contentPi = PendingIntent.getActivity(
            context,
            REQUEST_CODE,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, FollowUpScheduler.CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.ic_qs_cardlink)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notif)
    }
}
