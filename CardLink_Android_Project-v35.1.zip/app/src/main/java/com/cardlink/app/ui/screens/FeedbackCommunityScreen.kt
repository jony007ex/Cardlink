package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.util.FeedbackDraft
import com.cardlink.app.util.FeedbackSubmissionResult
import com.cardlink.app.util.FeedbackSubmissionService
import com.cardlink.app.util.FeedbackType
import com.cardlink.app.util.WhatsAppFeedbackSubmissionService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val MAX_FEEDBACK_LENGTH = 2000

private data class FeedbackCategoryOption(
    val type: FeedbackType,
    val icon: ImageVector,
    val titleRes: Int,
    val descRes: Int
)

private val FEEDBACK_CATEGORY_OPTIONS = listOf(
    FeedbackCategoryOption(
        type = FeedbackType.FEATURE_REQUEST,
        icon = Icons.Default.Lightbulb,
        titleRes = R.string.feedback_cat_feature,
        descRes = R.string.feedback_cat_feature_desc
    ),
    FeedbackCategoryOption(
        type = FeedbackType.REPORT_PROBLEM,
        icon = Icons.Default.Build,
        titleRes = R.string.feedback_cat_bug,
        descRes = R.string.feedback_cat_bug_desc
    ),
    FeedbackCategoryOption(
        type = FeedbackType.IMPROVEMENT,
        icon = Icons.Default.AutoAwesome,
        titleRes = R.string.feedback_cat_improvement,
        descRes = R.string.feedback_cat_improvement_desc
    ),
    FeedbackCategoryOption(
        type = FeedbackType.UI_UX,
        icon = Icons.Default.Palette,
        titleRes = R.string.feedback_cat_uiux,
        descRes = R.string.feedback_cat_uiux_desc
    ),
    FeedbackCategoryOption(
        type = FeedbackType.GENERAL,
        icon = Icons.Default.Forum,
        titleRes = R.string.feedback_cat_general,
        descRes = R.string.feedback_cat_general_desc
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackCommunityScreen(
    onNavigateBack: () -> Unit,
    submissionService: FeedbackSubmissionService = WhatsAppFeedbackSubmissionService
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()

    var selectedType by remember { mutableStateOf<FeedbackType?>(null) }
    var feedbackMessage by remember { mutableStateOf("") }
    var includeDiagnostics by remember { mutableStateOf(true) }
    var showEmptyValidationError by remember { mutableStateOf(false) }

    var isPreparing by remember { mutableStateOf(false) }
    var showConfirmSheet by remember { mutableStateOf(false) }
    var showUnavailableDialog by remember { mutableStateOf(false) }
    var lastStatusBanner by remember { mutableStateOf<String?>(null) }

    val selectedOption = remember(selectedType) {
        FEEDBACK_CATEGORY_OPTIONS.firstOrNull { it.type == selectedType }
    }

    fun executeWhatsAppHandoff() {
        if (isPreparing) return
        scope.launch {
            isPreparing = true
            lastStatusBanner = null
            // Brief preparing state prevents accidental rapid double-taps
            delay(220L)
            val chosenType = selectedType ?: FeedbackType.GENERAL
            val draft = FeedbackDraft(
                type = chosenType,
                message = feedbackMessage.trim(),
                includeDiagnostics = chosenType == FeedbackType.REPORT_PROBLEM && includeDiagnostics
            )
            when (submissionService.submitFeedback(context, draft)) {
                is FeedbackSubmissionResult.WhatsAppHandoffOpened -> {
                    lastStatusBanner = context.getString(R.string.feedback_status_whatsapp_opened)
                }
                is FeedbackSubmissionResult.CommunityLinkOpened -> {
                    lastStatusBanner = context.getString(R.string.feedback_status_community_opened)
                }
                is FeedbackSubmissionResult.DirectBackendAccepted -> {
                    lastStatusBanner = context.getString(R.string.feedback_status_prepared)
                }
                is FeedbackSubmissionResult.Failed -> {
                    showUnavailableDialog = true
                }
            }
            // Keep feedbackMessage intact so user never loses their draft if handoff fails or is cancelled
            isPreparing = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.feedback_title),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.feedback_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = stringResource(R.string.feedback_intro),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            // Compact 2-Column Responsive Feedback Type Selector
            Text(
                text = stringResource(R.string.feedback_choose_type_header),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp
            )

            val pairedRows = remember { FEEDBACK_CATEGORY_OPTIONS.chunked(2) }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pairedRows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { option ->
                            CompactFeedbackCategoryCard(
                                option = option,
                                isSelected = selectedType == option.type,
                                onSelect = { selectedType = option.type },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            // Optional Safe Diagnostics Toggle for Bug Reports
            AnimatedVisibility(
                visible = selectedType == FeedbackType.REPORT_PROBLEM,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = stringResource(R.string.feedback_include_app_info),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = stringResource(R.string.feedback_include_app_info_sub),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = includeDiagnostics,
                            onCheckedChange = { includeDiagnostics = it }
                        )
                    }
                }
            }

            // Required Multi-Line Feedback Field with Character Counter
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.feedback_your_feedback_label),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${feedbackMessage.length} / $MAX_FEEDBACK_LENGTH",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }

                OutlinedTextField(
                    value = feedbackMessage,
                    onValueChange = { updated ->
                        if (updated.length <= MAX_FEEDBACK_LENGTH) {
                            feedbackMessage = updated
                            if (showEmptyValidationError && updated.isNotBlank()) {
                                showEmptyValidationError = false
                            }
                        }
                    },
                    placeholder = { Text(stringResource(R.string.feedback_note_placeholder)) },
                    isError = showEmptyValidationError,
                    supportingText = if (showEmptyValidationError) {
                        {
                            Text(
                                text = stringResource(R.string.feedback_empty_error),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    } else null,
                    minLines = 5,
                    maxLines = 9,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Accurate Handoff Status Feedback (never falsely claims "Sent")
            if (lastStatusBanner != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(
                            text = lastStatusBanner!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Explicit Clear Feedback action (draft is never cleared automatically on failed handoff)
            if (feedbackMessage.isNotBlank()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(
                        onClick = {
                            feedbackMessage = ""
                            lastStatusBanner = null
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(stringResource(R.string.feedback_clear_btn), fontSize = 12.sp)
                    }
                }
            }

            // Single Unified Primary Action: Submit Feedback
            Button(
                onClick = {
                    focusManager.clearFocus()
                    if (selectedType == null) {
                        Toast.makeText(
                            context,
                            context.getString(R.string.feedback_select_type_error),
                            Toast.LENGTH_SHORT
                        ).show()
                        return@Button
                    }
                    if (feedbackMessage.isBlank()) {
                        showEmptyValidationError = true
                        Toast.makeText(
                            context,
                            context.getString(R.string.feedback_empty_error),
                            Toast.LENGTH_SHORT
                        ).show()
                        return@Button
                    }
                    showEmptyValidationError = false
                    showConfirmSheet = true
                },
                enabled = !isPreparing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                if (isPreparing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.feedback_preparing),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.feedback_submit_btn),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp
                    )
                }
            }

            // Concise Privacy Notice directly under Submit
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PrivacyTip,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                    modifier = Modifier.size(16.dp).padding(top = 2.dp)
                )
                Text(
                    text = stringResource(R.string.feedback_privacy_notice),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                )
            }

            // Subtle Secondary Link: View CardLink Community
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                TextButton(
                    onClick = {
                        when (submissionService.openCommunityLink(context)) {
                            is FeedbackSubmissionResult.Failed -> showUnavailableDialog = true
                            else -> Unit
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.feedback_view_community_link),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
        }
    }

    // Lightweight Confirmation Dialog before handing off to WhatsApp (No Copy button)
    if (showConfirmSheet && selectedOption != null) {
        val previewType = stringResource(selectedOption.titleRes)
        val previewText = feedbackMessage.trim()

        AlertDialog(
            onDismissRequest = { showConfirmSheet = false },
            icon = { Icon(Icons.Default.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = {
                Text(
                    text = stringResource(R.string.feedback_confirm_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.feedback_confirm_msg),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "${stringResource(R.string.feedback_preview_type)}: $previewType",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = previewText,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmSheet = false
                        executeWhatsAppHandoff()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        text = stringResource(R.string.action_continue),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmSheet = false }) {
                    Text(text = stringResource(R.string.action_cancel))
                }
            }
        )
    }

    // Graceful Fallback Error Dialog (preserves user's draft)
    if (showUnavailableDialog) {
        AlertDialog(
            onDismissRequest = { showUnavailableDialog = false },
            title = {
                Text(
                    text = stringResource(R.string.feedback_unable_open_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(text = stringResource(R.string.feedback_unable_open_msg))
            },
            confirmButton = {
                Button(onClick = { showUnavailableDialog = false }) {
                    Text(text = stringResource(R.string.action_close))
                }
            }
        )
    }
}

@Composable
private fun CompactFeedbackCategoryCard(
    option: FeedbackCategoryOption,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val title = stringResource(option.titleRes)
    val desc = stringResource(option.descRes)

    Card(
        modifier = modifier
            .heightIn(min = 66.dp)
            .clip(RoundedCornerShape(14.dp))
            .semantics {
                selected = isSelected
                contentDescription = "$title. $desc"
            }
            .clickable(role = Role.RadioButton, onClick = onSelect),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            }
        ),
        border = BorderStroke(
            width = if (isSelected) 1.6.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier.size(32.dp),
                shape = CircleShape,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = option.icon,
                        contentDescription = null,
                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
            Text(
                text = title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.5.sp,
                lineHeight = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
