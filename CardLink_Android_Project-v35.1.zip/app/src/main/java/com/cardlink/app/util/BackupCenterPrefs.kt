package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

enum class BackupHealthStatus {
    NO_BACKUP_FOUND,
    UP_TO_DATE,
    BACKUP_RECOMMENDED,
    BACKUP_OVERDUE
}

@Serializable
data class RecentBackupEntry(
    val fileName: String,
    val uriString: String,
    val createdAtTimestamp: Long,
    val sizeBytes: Long,
    val isCompleteBackup: Boolean = true,
    val isEncrypted: Boolean = false,
    val verified: Boolean = true
)

data class BackupHealthInfo(
    val status: BackupHealthStatus,
    val lastBackupTimestamp: Long?,
    val changesSinceBackup: Int,
    val lastBackupEncrypted: Boolean,
    val reminderIntervalDays: Int
)

object BackupCenterPrefs {
    private const val PREFS = "cardlink_local_backup_center_prefs"
    private const val LEGACY_CLOUD_PREFS = "cardlink_cloud_prefs"

    private const val KEY_LAST_BACKUP_TS = "last_complete_backup_ts"
    private const val KEY_LAST_BACKUP_COUNT = "last_complete_backup_record_count"
    private const val KEY_LAST_BACKUP_ENC = "last_complete_backup_encrypted"
    private const val KEY_REMINDER_DAYS = "backup_reminder_interval_days"
    private const val KEY_DEFAULT_ENCRYPT = "backup_default_encrypt_enabled"
    private const val KEY_RECENT_LIST = "recent_backups_json"
    private const val KEY_CLOUD_NOTICE_DISMISSED = "cloud_removal_notice_dismissed"
    private const val KEY_PRE_RESTORE_SNAPSHOT = "pre_restore_snapshot_path"

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun shouldShowCloudRemovalNotice(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_CLOUD_NOTICE_DISMISSED, false)) return false
        val legacy = context.getSharedPreferences(LEGACY_CLOUD_PREFS, Context.MODE_PRIVATE)
        val hadGoogle = legacy.getBoolean("GOOGLE_DRIVE_connected", false) || legacy.getLong("GOOGLE_DRIVE_last_ts", -1L) > 0L
        val hadOneDrive = legacy.getBoolean("ONEDRIVE_connected", false) || legacy.getLong("ONEDRIVE_last_ts", -1L) > 0L
        return hadGoogle || hadOneDrive
    }

    fun dismissCloudRemovalNotice(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_CLOUD_NOTICE_DISMISSED, true)
            .apply()
    }

    fun getReminderIntervalDays(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_REMINDER_DAYS, 30)
    }

    fun setReminderIntervalDays(context: Context, days: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_REMINDER_DAYS, days)
            .apply()
        BackupReminderScheduler.scheduleNextReminder(context)
    }

    fun isDefaultPasswordProtectionEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_DEFAULT_ENCRYPT, false)
    }

    fun setDefaultPasswordProtectionEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_DEFAULT_ENCRYPT, enabled)
            .apply()
    }

    fun getLastBackupTimestamp(context: Context): Long? {
        val ts = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_BACKUP_TS, -1L)
        return ts.takeIf { it > 0L }
    }

    fun recordSuccessfulBackup(
        context: Context,
        entry: RecentBackupEntry,
        totalRecordsNow: Int
    ) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val updatedRecent = (listOf(entry) + loadRecentBackups(context).filterNot { it.uriString == entry.uriString }).take(10)
        val editor = prefs.edit()
            .putString(KEY_RECENT_LIST, json.encodeToString(updatedRecent))
        if (entry.isCompleteBackup) {
            editor.putLong(KEY_LAST_BACKUP_TS, entry.createdAtTimestamp)
            editor.putInt(KEY_LAST_BACKUP_COUNT, totalRecordsNow)
            editor.putBoolean(KEY_LAST_BACKUP_ENC, entry.isEncrypted)
        }
        editor.apply()
        BackupReminderScheduler.scheduleNextReminder(context)
    }

    fun loadRecentBackups(context: Context): List<RecentBackupEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT_LIST, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<RecentBackupEntry>>(raw) }.getOrDefault(emptyList())
    }

    fun isBackupUriAccessible(context: Context, uriString: String): Boolean {
        if (uriString.isBlank()) return false
        return runCatching {
            context.contentResolver.openInputStream(Uri.parse(uriString))?.use { true } ?: false
        }.getOrDefault(false)
    }

    fun computeBackupHealth(context: Context, currentTotalRecords: Int): BackupHealthInfo {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastTs = prefs.getLong(KEY_LAST_BACKUP_TS, -1L).takeIf { it > 0L }
        val lastCount = prefs.getInt(KEY_LAST_BACKUP_COUNT, 0)
        val lastEnc = prefs.getBoolean(KEY_LAST_BACKUP_ENC, false)
        val reminderDays = getReminderIntervalDays(context)

        if (lastTs == null) {
            return BackupHealthInfo(BackupHealthStatus.NO_BACKUP_FOUND, null, currentTotalRecords, false, reminderDays)
        }

        val elapsedDays = ((System.currentTimeMillis() - lastTs) / (24L * 3600_000L)).toInt()
        val delta = kotlin.math.abs(currentTotalRecords - lastCount)
        val status = when {
            reminderDays > 0 && elapsedDays >= reminderDays -> BackupHealthStatus.BACKUP_OVERDUE
            delta >= 5 || elapsedDays >= 14 -> BackupHealthStatus.BACKUP_RECOMMENDED
            else -> BackupHealthStatus.UP_TO_DATE
        }
        return BackupHealthInfo(status, lastTs, delta, lastEnc, reminderDays)
    }

    fun savePreRestoreSnapshotPath(context: Context, path: String?) {
        val ed = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (path.isNullOrBlank()) ed.remove(KEY_PRE_RESTORE_SNAPSHOT) else ed.putString(KEY_PRE_RESTORE_SNAPSHOT, path)
        ed.apply()
    }

    fun getPreRestoreSnapshotPath(context: Context): String? {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PRE_RESTORE_SNAPSHOT, null)
            ?.takeIf { java.io.File(it).exists() }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        return when {
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> String.format("%.1f KB", bytes / 1024.0)
            else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
