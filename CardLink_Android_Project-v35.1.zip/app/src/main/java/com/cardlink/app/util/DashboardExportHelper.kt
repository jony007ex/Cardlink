package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.data.model.ShareHistoryEntity
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DashboardExportHelper {

    private fun timestampNow(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

    private fun fileStamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())

    private fun makeStaticLayout(text: String, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.25f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1.25f, 0f, true)
        }
    }

    fun renderDashboardBitmap(
        periodLabel: String,
        contactsInPeriod: List<SavedContactEntity>,
        allContacts: List<SavedContactEntity>,
        sharesInPeriod: List<ShareHistoryEntity>,
        followUps: List<FollowUpEntity>
    ): Bitmap {
        val width = 1080
        val categoryOrder = listOf("Client", "Vendor", "VIP", "Colleague", "Event", "General")
        val catCounts = categoryOrder.map { cat ->
            cat to allContacts.count { it.categoryTag.equals(cat, ignoreCase = true) }
        }
        val maxCat = (catCounts.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

        val height = 1480
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        canvas.drawColor(Color.parseColor("#0A192F"))

        val gold = Color.parseColor("#D4AF37")
        val white = Color.WHITE
        val muted = Color.parseColor("#CBD5E1")
        val cardBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#112240") }

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = white
            textSize = 44f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; textSize = 24f }
        val secPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = white; textSize = 30f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 24f }

        val headerLayout = makeStaticLayout(
            "Card Link — Networking Dashboard ($periodLabel)\nGenerated: ${timestampNow()}",
            metaPaint, width - 96
        )
        canvas.drawText("Networking & CRM Insights", 48f, 84f, titlePaint)
        canvas.save()
        canvas.translate(48f, 108f)
        headerLayout.draw(canvas)
        canvas.restore()

        val kpiTop = 210f
        val kpiW = (width - 96f - 24f) / 3f
        val kpis = listOf(
            "Cards Shared" to sharesInPeriod.size.toString(),
            "New Contacts" to contactsInPeriod.size.toString(),
            "Total Vault" to allContacts.size.toString()
        )
        kpis.forEachIndexed { idx, (label, valStr) ->
            val left = 48f + idx * (kpiW + 12f)
            canvas.drawRoundRect(left, kpiTop, left + kpiW, kpiTop + 150f, 20f, 20f, cardBg)
            val vPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white; textSize = 44f; typeface = Typeface.DEFAULT_BOLD }
            val lPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; textSize = 22f }
            canvas.drawText(valStr, left + 20f, kpiTop + 68f, vPaint)
            canvas.drawText(label, left + 20f, kpiTop + 114f, lPaint)
        }

        val catBoxTop = 400f
        canvas.drawRoundRect(48f, catBoxTop, width - 48f, catBoxTop + 470f, 22f, 22f, cardBg)
        canvas.drawText("Contacts by Category (All Vault)", 72f, catBoxTop + 50f, secPaint)

        var barY = catBoxTop + 92f
        val barMaxW = width - 340f
        catCounts.forEach { (cat, count) ->
            val pct = if (allContacts.isNotEmpty()) count * 100 / allContacts.size else 0
            canvas.drawText("$cat ($count • $pct%)", 72f, barY + 22f, bodyPaint)
            val trackLeft = 310f
            canvas.drawRoundRect(trackLeft, barY, trackLeft + barMaxW, barY + 28f, 12f, 12f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E293B") })
            val fillW = ((count.toFloat() / maxCat) * barMaxW).coerceAtLeast(if (count > 0) 16f else 0f)
            if (fillW > 0f) {
                canvas.drawRoundRect(trackLeft, barY, trackLeft + fillW, barY + 28f, 12f, 12f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold })
            }
            barY += 58f
        }

        val sumTop = 910f
        canvas.drawRoundRect(48f, sumTop, width - 48f, sumTop + 490f, 22f, 22f, cardBg)
        val channels = sharesInPeriod.groupingBy { it.method }.eachCount().entries.sortedByDescending { it.value }
        val channelText = if (channels.isEmpty()) {
            "No sharing events recorded in $periodLabel."
        } else {
            channels.joinToString("\n") { "• ${it.key}: ${it.value} share(s)" }
        }
        val pendingFollowUps = followUps.count { !it.isCompleted }
        val summaryBlock = makeStaticLayout(
            "Sharing Channels ($periodLabel)\n$channelText\n\nFollow-Ups: $pendingFollowUps pending out of ${followUps.size} total",
            bodyPaint, width - 144
        )
        canvas.drawText("Activity & Follow-Up Summary", 72f, sumTop + 50f, secPaint)
        canvas.save()
        canvas.translate(72f, sumTop + 80f)
        summaryBlock.draw(canvas)
        canvas.restore()

        return bmp
    }

    fun exportAndSharePng(
        context: Context,
        periodLabel: String,
        contactsInPeriod: List<SavedContactEntity>,
        allContacts: List<SavedContactEntity>,
        sharesInPeriod: List<ShareHistoryEntity>,
        followUps: List<FollowUpEntity>
    ): Result<File> = runCatching {
        val bmp = renderDashboardBitmap(periodLabel, contactsInPeriod, allContacts, sharesInPeriod, followUps)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "CardLink_Dashboard_${fileStamp()}.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
        shareFile(context, file, "image/png", "Share Networking Dashboard (PNG)")
        file
    }

    fun exportAndSharePdf(
        context: Context,
        periodLabel: String,
        contactsInPeriod: List<SavedContactEntity>,
        allContacts: List<SavedContactEntity>,
        sharesInPeriod: List<ShareHistoryEntity>,
        followUps: List<FollowUpEntity>
    ): Result<File> = runCatching {
        val pageWidth = 595
        val pageHeight = 842
        val margin = 36
        val contentWidth = pageWidth - margin * 2

        val pdf = PdfDocument()
        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = margin.toFloat()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0A192F"); textSize = 20f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#475569"); textSize = 11f }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A"); textSize = 12f }

        fun ensureSpace(neededHeight: Int) {
            if (y + neededHeight > pageHeight - margin) {
                pdf.finishPage(page)
                pageNum += 1
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                y = margin.toFloat()
            }
        }

        val titleLayout = makeStaticLayout("Card Link — Networking Dashboard Report", titlePaint, contentWidth)
        canvas.save(); canvas.translate(margin.toFloat(), y); titleLayout.draw(canvas); canvas.restore()
        y += titleLayout.height + 6f

        val metaLayout = makeStaticLayout("Filter / Period: $periodLabel  |  Exported: ${timestampNow()}", subPaint, contentWidth)
        canvas.save(); canvas.translate(margin.toFloat(), y); metaLayout.draw(canvas); canvas.restore()
        y += metaLayout.height + 16f

        val kpiSummary = buildString {
            appendLine("Summary Metrics ($periodLabel):")
            appendLine("• Cards Shared: ${sharesInPeriod.size}")
            appendLine("• New Contacts Added: ${contactsInPeriod.size}")
            appendLine("• Total Saved Contacts: ${allContacts.size}")
            appendLine("• Pending Follow-Ups: ${followUps.count { !it.isCompleted }} / ${followUps.size}")
        }
        val kpiLayout = makeStaticLayout(kpiSummary.trim(), bodyPaint, contentWidth)
        ensureSpace(kpiLayout.height + 16)
        canvas.save(); canvas.translate(margin.toFloat(), y); kpiLayout.draw(canvas); canvas.restore()
        y += kpiLayout.height + 16f

        val catLines = listOf("Client", "Vendor", "VIP", "Colleague", "Event", "General").joinToString("\n") { cat ->
            "• $cat: ${allContacts.count { it.categoryTag.equals(cat, ignoreCase = true) }}"
        }
        val catLayout = makeStaticLayout("Category Distribution:\n$catLines", bodyPaint, contentWidth)
        ensureSpace(catLayout.height + 16)
        canvas.save(); canvas.translate(margin.toFloat(), y); catLayout.draw(canvas); canvas.restore()
        y += catLayout.height + 16f

        val shareLines = if (sharesInPeriod.isEmpty()) "No share history in selected period." else {
            sharesInPeriod.take(25).joinToString("\n") { s ->
                val dt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(s.timestamp))
                "• [$dt] ${s.method} (${s.cardProfileTitle})"
            }
        }
        val shareLayout = makeStaticLayout("Recent Share Activity:\n$shareLines", bodyPaint, contentWidth)
        ensureSpace(shareLayout.height + 16)
        canvas.save(); canvas.translate(margin.toFloat(), y); shareLayout.draw(canvas); canvas.restore()

        pdf.finishPage(page)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "CardLink_Dashboard_${fileStamp()}.pdf")
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()

        shareFile(context, file, "application/pdf", "Share Networking Dashboard (PDF)")
        file
    }

    fun exportAndShareXlsx(
        context: Context,
        periodLabel: String,
        contactsInPeriod: List<SavedContactEntity>,
        allContacts: List<SavedContactEntity>,
        sharesInPeriod: List<ShareHistoryEntity>,
        followUps: List<FollowUpEntity>
    ): Result<File> = runCatching {
        fun xmlEsc(s: String): String = s
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\"", "&quot;").replace("'", "&apos;")

        fun colName(index: Int): String {
            var i = index
            val sb = StringBuilder()
            while (i >= 0) { sb.insert(0, ('A' + (i % 26))); i = i / 26 - 1 }
            return sb.toString()
        }

        fun buildSheetXml(rows: List<List<String>>): String {
            val rowXml = rows.mapIndexed { rIdx, cells ->
                val rowNum = rIdx + 1
                val cellXml = cells.mapIndexed { cIdx, v ->
                    "<c r=\"${colName(cIdx)}$rowNum\" t=\"inlineStr\"><is><t>${xmlEsc(v)}</t></is></c>"
                }.joinToString("")
                "<row r=\"$rowNum\">$cellXml</row>"
            }.joinToString("")
            return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$rowXml</sheetData></worksheet>"""
        }

        val summaryRows = listOf(
            listOf("Card Link Dashboard Report", periodLabel),
            listOf("Generated At", timestampNow()),
            listOf("Cards Shared", sharesInPeriod.size.toString()),
            listOf("New Contacts (Period)", contactsInPeriod.size.toString()),
            listOf("Total Saved Contacts", allContacts.size.toString()),
            listOf("Pending Follow-Ups", followUps.count { !it.isCompleted }.toString()),
            listOf("", ""),
            listOf("Category", "Contact Count"),
            listOf("Client", allContacts.count { it.categoryTag.equals("Client", true) }.toString()),
            listOf("Vendor", allContacts.count { it.categoryTag.equals("Vendor", true) }.toString()),
            listOf("VIP", allContacts.count { it.categoryTag.equals("VIP", true) }.toString()),
            listOf("Colleague", allContacts.count { it.categoryTag.equals("Colleague", true) }.toString()),
            listOf("Event", allContacts.count { it.categoryTag.equals("Event", true) }.toString()),
            listOf("General", allContacts.count { it.categoryTag.equals("General", true) }.toString())
        )

        val contactRows = buildList {
            add(listOf("Full Name", "Designation", "Company", "Category", "Phone", "WhatsApp", "Email", "Address"))
            allContacts.forEach { c ->
                add(listOf(c.fullName, c.designation, c.companyName, c.categoryTag, c.phone, c.whatsapp, c.email, c.officeAddress))
            }
        }

        val shareRows = buildList {
            add(listOf("Timestamp", "Profile", "Channel", "Recipient"))
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            sharesInPeriod.forEach { s -> add(listOf(fmt.format(Date(s.timestamp)), s.cardProfileTitle, s.method, s.recipientInfo)) }
        }

        val followUpRows = buildList {
            add(listOf("Title", "Contact", "Channel", "Due Time", "Status"))
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            followUps.forEach { f -> add(listOf(f.title, f.contactName, f.channel, fmt.format(Date(f.dueAtTimestamp)), if (f.isCompleted) "Completed" else f.status)) }
        }

        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>"""
        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
        val workbookXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Contacts" sheetId="2" r:id="rId2"/><sheet name="Share Activity" sheetId="3" r:id="rId3"/><sheet name="Follow-Ups" sheetId="4" r:id="rId4"/></sheets></workbook>"""
        val workbookRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/></Relationships>"""

        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "CardLink_Dashboard_${fileStamp()}.xlsx")
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            fun addEntry(name: String, content: String) {
                zos.putNextEntry(ZipEntry(name)); zos.write(content.toByteArray(Charsets.UTF_8)); zos.closeEntry()
            }
            addEntry("[Content_Types].xml", contentTypes)
            addEntry("_rels/.rels", rootRels)
            addEntry("xl/workbook.xml", workbookXml)
            addEntry("xl/_rels/workbook.xml.rels", workbookRels)
            addEntry("xl/worksheets/sheet1.xml", buildSheetXml(summaryRows))
            addEntry("xl/worksheets/sheet2.xml", buildSheetXml(contactRows))
            addEntry("xl/worksheets/sheet3.xml", buildSheetXml(shareRows))
            addEntry("xl/worksheets/sheet4.xml", buildSheetXml(followUpRows))
        }
        FileOutputStream(file).use { it.write(baos.toByteArray()) }

        shareFile(context, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Share Networking Dashboard (Excel .xlsx)")
        file
    }

    private fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}
