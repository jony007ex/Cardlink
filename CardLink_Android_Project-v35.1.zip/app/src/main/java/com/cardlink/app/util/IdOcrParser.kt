package com.cardlink.app.util

import java.util.Locale

data class ExtractedIdField(
    val key: String,
    val value: String
)

object IdOcrParser {

    val STANDARD_FIELD_KEYS = listOf(
        "Name",
        "Document Number",
        "Date of Birth",
        "Nationality",
        "Issue Date",
        "Expiry Date",
        "Issuing Authority",
        "Blood Group",
        "Address"
    )

    private val NOISE_SUBSTRINGS = listOf(
        "government of the people",
        "people's republic",
        "republic of bangladesh",
        "national id card",
        "national identity",
        "গণপ্রজাতন্ত্রী বাংলাদেশ",
        "জাতীয় পরিচয় পত্র",
        "জাতীয় পরিচয় পত্র",
        "terms and conditions",
        "if found please return",
        "this card is the property",
        "signature of holder",
        "holder's signature",
        "passport",
        "driving licence",
        "driving license",
        "bangladesh road transport",
        "brta",
        "department of immigration"
    )

    private val FIELD_PATTERNS: List<Pair<String, List<String>>> = listOf(
        "Name" to listOf("full name", "name", "surname", "given name", "holder", "নাম"),
        "Document Number" to listOf(
            "passport no", "passport number", "id no", "nid no", "id number",
            "licence no", "license no", "document no", "card no", "employee id",
            "student id", "member id", "membership no", "নম্বর", "আইডি নং", "পাসপোর্ট নং"
        ),
        "Date of Birth" to listOf("date of birth", "dob", "birth date", "জন্ম তারিখ"),
        "Nationality" to listOf("nationality", "citizen", "জাতীয়তা", "জাতীয়তা"),
        "Issue Date" to listOf("date of issue", "issue date", "issued on", "প্রদানের তারিখ"),
        "Expiry Date" to listOf(
            "expiry date", "date of expiry", "valid until", "valid thru", "expires", "exp.", "exp:",
            "মেয়াদ শেষ", "মেয়াদ শেষ", "মেয়াদ উত্তীর্ণের তারিখ", "বৈধতার শেষ তারিখ"
        ),
        "Issuing Authority" to listOf("issuing authority", "authority", "issued by", "কর্তৃপক্ষ"),
        "Blood Group" to listOf("blood group", "blood", "রক্তের গ্রুপ"),
        "Address" to listOf("address", "permanent address", "present address", "ঠিকানা")
    )

    private val BLOOD_GROUP_REGEX = Regex("""\b(AB|A|B|O)[+-]\b""", RegexOption.IGNORE_CASE)
    private val ID_NUM_STANDALONE_REGEX = Regex("""\b(?:[A-Z]{1,3}[0-9]{6,9}|[0-9]{10,17})\b""")
    private val MRZ_NOISE_REGEX = Regex("""^[A-Z0-9<]{15,}$""")

    /**
     * Parses raw OCR text into clean, structured personal/document fields while filtering out
     * decorative headings, security text, MRZ noise, and long unrelated paragraphs.
     * Never fabricates values when uncertain.
     */
    fun extractPersonalFields(rawOcrText: String): List<ExtractedIdField> {
        if (rawOcrText.isBlank()) return emptyList()

        val lines = rawOcrText.lines()
            .map { it.trim() }
            .filter { it.length >= 2 }
            .filterNot { isNoiseLine(it) }

        val extracted = linkedMapOf<String, String>()

        lines.forEachIndexed { idx, line ->
            val lower = line.lowercase(Locale.ROOT)
            for ((fieldKey, labels) in FIELD_PATTERNS) {
                if (extracted.containsKey(fieldKey)) continue
                val matchedLabel = labels.firstOrNull { lbl ->
                    lower == lbl || lower.startsWith("$lbl:") || lower.startsWith("$lbl ") || lower.contains("$lbl:")
                }
                if (matchedLabel != null) {
                    val afterColon = line.substringAfter(":", "").trim()
                    val candidateValue = when {
                        afterColon.isNotBlank() && !isNoiseLine(afterColon) -> afterColon
                        line.length > matchedLabel.length + 2 && lower.startsWith(matchedLabel) -> {
                            line.substring(matchedLabel.length).trim(' ', ':', '-', '.')
                        }
                        idx + 1 < lines.size && !looksLikeAnyLabel(lines[idx + 1]) && !isNoiseLine(lines[idx + 1]) -> {
                            lines[idx + 1]
                        }
                        else -> ""
                    }
                    if (candidateValue.isNotBlank() && candidateValue.length <= 120) {
                        if (fieldKey == "Blood Group") {
                            BLOOD_GROUP_REGEX.find(candidateValue)?.value?.uppercase()?.let {
                                extracted[fieldKey] = it
                            }
                        } else {
                            extracted[fieldKey] = candidateValue
                        }
                    }
                }
            }
        }

        // Only detect blood group if clearly present in format like A+, O-, AB+
        if (!extracted.containsKey("Blood Group")) {
            val bloodLine = lines.firstOrNull {
                val l = it.lowercase(Locale.ROOT)
                l.contains("blood") || l.contains("রক্ত")
            }
            if (bloodLine != null) {
                BLOOD_GROUP_REGEX.find(bloodLine)?.value?.uppercase()?.let {
                    extracted["Blood Group"] = it
                }
            }
        }

        // Only detect a standalone ID/Passport number if it matches a clear alphanumeric/numeric ID pattern
        if (!extracted.containsKey("Document Number")) {
            for (line in lines) {
                val m = ID_NUM_STANDALONE_REGEX.find(line.replace(" ", ""))
                if (m != null && !line.contains("/") && !line.contains("-")) {
                    extracted["Document Number"] = m.value
                    break
                }
            }
        }

        return extracted.entries.map { ExtractedIdField(it.key, it.value) }
    }

    /**
     * Serializes structured fields to a clean, human-readable, backward-compatible string
     * stored in IdDocumentEntity.extractedText (no DB schema migration required).
     */
    fun serializeFields(fields: List<ExtractedIdField>): String {
        return fields
            .filter { it.key.isNotBlank() && it.value.isNotBlank() }
            .joinToString("\n") { "${it.key.trim()}: ${it.value.trim()}" }
    }

    /**
     * Parses stored extractedText back into structured fields.
     * Gracefully supports legacy free-text entries created in earlier versions.
     */
    fun parseStoredText(stored: String): List<ExtractedIdField> {
        if (stored.isBlank()) return emptyList()
        val result = mutableListOf<ExtractedIdField>()
        stored.lines().map { it.trim() }.filter { it.isNotBlank() && it != "---" }.forEach { line ->
            val colonIdx = line.indexOf(':')
            if (colonIdx in 2..36) {
                val k = line.substring(0, colonIdx).trim()
                val v = line.substring(colonIdx + 1).trim()
                if (k.isNotBlank() && v.isNotBlank()) {
                    result.add(ExtractedIdField(k, v))
                    return@forEach
                }
            }
            // Legacy free-text line fallback
            if (!isNoiseLine(line)) {
                result.add(ExtractedIdField("Info", line))
            }
        }
        return result
    }

    private fun looksLikeAnyLabel(line: String): Boolean {
        val lower = line.lowercase(Locale.ROOT).trimEnd(':', ' ')
        return FIELD_PATTERNS.any { (_, labels) -> labels.any { lower == it || lower.startsWith("$it:") } }
    }

    private fun isNoiseLine(line: String): Boolean {
        val cleaned = line.trim()
        if (cleaned.length < 2 || cleaned.length > 140) return true
        if (MRZ_NOISE_REGEX.matches(cleaned.replace(" ", ""))) return true
        val lower = cleaned.lowercase(Locale.ROOT)
        if (NOISE_SUBSTRINGS.any { lower.contains(it) }) return true
        // Filter out random symbol/punctuation fragments
        val meaningfulChars = cleaned.count { it.isLetterOrDigit() }
        if (meaningfulChars < 2 || meaningfulChars.toFloat() / cleaned.length < 0.45f) return true
        return false
    }
}
