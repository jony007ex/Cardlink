package com.cardlink.app.nearby

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class ScannedBtDevice(
    val name: String,
    val address: String,
    val isPaired: Boolean,
    val device: BluetoothDevice
)

class BluetoothDiscoveryManager(private val context: Context) {

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _pairedDevices = MutableStateFlow<List<ScannedBtDevice>>(emptyList())
    val pairedDevices: StateFlow<List<ScannedBtDevice>> = _pairedDevices

    private val _discoveredDevices = MutableStateFlow<List<ScannedBtDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<ScannedBtDevice>> = _discoveredDevices

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private var isReceiverRegistered = false

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null
    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    if (device != null) {
                        val devName = runCatching { device.name }.getOrNull().orEmpty().ifBlank { "Bluetooth Device" }
                        val devAddr = device.address ?: return
                        val bonded = runCatching { device.bondState == BluetoothDevice.BOND_BONDED }.getOrDefault(false)
                        val item = ScannedBtDevice(devName, devAddr, bonded, device)
                        val current = _discoveredDevices.value.toMutableList()
                        val existingIdx = current.indexOfFirst { it.address == devAddr }
                        if (existingIdx >= 0) current[existingIdx] = item else current.add(item)
                        _discoveredDevices.value = current
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _isScanning.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isScanning.value = false
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    loadPairedDevices()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun loadPairedDevices() {
        val adapter = bluetoothAdapter ?: return
        runCatching {
            val bonded = adapter.bondedDevices.orEmpty().map { dev ->
                ScannedBtDevice(
                    name = dev.name.orEmpty().ifBlank { "Paired Device" },
                    address = dev.address,
                    isPaired = true,
                    device = dev
                )
            }
            _pairedDevices.value = bonded
        }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        val adapter = bluetoothAdapter ?: return
        loadPairedDevices()
        _discoveredDevices.value = emptyList()

        if (!isReceiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
                addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
            isReceiverRegistered = true
        }

        runCatching {
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            val started = adapter.startDiscovery()
            _isScanning.value = started
        }
    }

    @SuppressLint("MissingPermission")
    fun pairDevice(device: BluetoothDevice): Boolean {
        return runCatching {
            bluetoothAdapter?.cancelDiscovery()
            device.createBond()
        }.getOrDefault(false)
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        runCatching { bluetoothAdapter?.cancelDiscovery() }
        if (isReceiverRegistered) {
            runCatching { context.unregisterReceiver(receiver) }
            isReceiverRegistered = false
        }
        _isScanning.value = false
    }
}
