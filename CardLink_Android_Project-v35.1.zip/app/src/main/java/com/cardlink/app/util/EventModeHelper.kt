package com.cardlink.app.util

import android.content.Context
import kotlinx.serialization.Serializable
import com.cardlink.app.data.model.SavedContactEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Serializable
data class EventModeConfig(
    val isActive: Boolean = false,
    val eventName: String = "",
    val location: String = "",
    val startedAtTimestamp: Long = 0L
)

object EventModeHelper {
    private const val PREFS = "cardlink_event_mode_prefs"
    private const val KEY_ACTIVE = "event_active"
    private const val KEY_NAME = "event_name"
    private const val KEY_LOCATION = "event_location"
    private const val KEY_STARTED = "event_started_at"

    fun load(context: Context): EventModeConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return EventModeConfig(
            isActive = p.getBoolean(KEY_ACTIVE, false),
            eventName = p.getString(KEY_NAME, "").orEmpty(),
            location = p.getString(KEY_LOCATION, "").orEmpty(),
            startedAtTimestamp = p.getLong(KEY_STARTED, 0L)
        )
    }

    fun save(context: Context, config: EventModeConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, config.isActive)
            .putString(KEY_NAME, config.eventName.trim())
            .putString(KEY_LOCATION, config.location.trim())
            .putLong(KEY_STARTED, config.startedAtTimestamp)
            .apply()
    }

    fun applyIfActive(contact: SavedContactEntity, config: EventModeConfig): SavedContactEntity {
        if (!config.isActive || config.eventName.isBlank()) return contact
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        val locationPart = if (config.location.isNotBlank()) " • ${config.location}" else ""
        val stamp = "[Event Mode] ${config.eventName} • $dateStr$locationPart"

        if (contact.notes.contains("[Event Mode] ${config.eventName}")) return contact

        val updatedNotes = if (contact.notes.isBlank()) stamp else "$stamp\n${contact.notes}"
        val updatedTag = if (contact.categoryTag.isBlank() || contact.categoryTag.equals("General", true)) {
            "Event"
        } else {
            contact.categoryTag
        }
        return contact.copy(
            categoryTag = updatedTag,
            notes = updatedNotes
        )
    }
}
