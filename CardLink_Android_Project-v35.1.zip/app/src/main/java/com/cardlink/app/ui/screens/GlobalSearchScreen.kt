package com.cardlink.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.util.SecurityHardeningManager

private data class GlobalSearchResultItem(
    val category: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    contacts: List<SavedContactEntity>,
    followUps: List<FollowUpEntity>,
    loyaltyCards: List<LoyaltyCardEntity>,
    idDocuments: List<IdDocumentEntity>,
    qrProjects: List<QrProjectEntity>,
    secureNotes: List<SecureNoteEntity>,
    onNavigateToRoute: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val hideSensitive = remember { SecurityHardeningManager.isSensitiveAreaHidden(context) }
    var query by remember { mutableStateOf("") }

    val staticEntries = remember(hideSensitive) {
        buildList {
            add(GlobalSearchResultItem("Tools", "Universal QR Scanner", "Scan any QR code", Icons.Default.QrCodeScanner, "scan_qr"))
            add(GlobalSearchResultItem("Tools", "QR Code Studio", "Create & style QR codes", Icons.Default.QrCode2, "qr_studio"))
            add(GlobalSearchResultItem("Tools", "Scan Card", "Scan physical business cards", Icons.Default.DocumentScanner, "scan_ocr"))
            if (!hideSensitive) {
                add(GlobalSearchResultItem("Tools", "My IDs", "Encrypted ID documents", Icons.Default.Badge, "my_ids"))
                add(GlobalSearchResultItem("Tools", "Loyalty Cards", "Membership & rewards wallet", Icons.Default.CardMembership, "loyalty_cards"))
                add(GlobalSearchResultItem("Tools", "Secure Notes", "Encrypted memo vault", Icons.Default.Lock, "secure_notes"))
            }
            add(GlobalSearchResultItem("Settings", "Backup & Export", "Master Backup & Restore", Icons.Default.Backup, "menu_backup_export"))
            add(GlobalSearchResultItem("Settings", "Privacy & Security", "Biometric Lock, Auto-Lock, Panic Lock", Icons.Default.Security, "menu_privacy"))
            add(GlobalSearchResultItem("Settings", "Theme Colors", "App Theme Studio", Icons.Default.Palette, "menu_theme_studio"))
            add(GlobalSearchResultItem("Help", "Help & Tips", "Offline guides & checklist", Icons.Default.HelpOutline, "menu_help_tips"))
        }
    }

    val results = remember(query, contacts, followUps, loyaltyCards, idDocuments, qrProjects, secureNotes, hideSensitive) {
        val q = query.trim()
        if (q.isBlank()) return@remember staticEntries.take(8)
        buildList {
            contacts.filter { it.fullName.contains(q, true) || it.companyName.contains(q, true) || it.categoryTag.contains(q, true) }
                .take(8)
                .forEach { c ->
                    add(GlobalSearchResultItem("Contacts", c.fullName, c.companyName.ifBlank { c.designation }, Icons.Default.Person, "contact_detail/${c.id}"))
                }
            followUps.filter { it.title.contains(q, true) || it.contactName.contains(q, true) }
                .take(6)
                .forEach { f ->
                    add(GlobalSearchResultItem("Follow-Ups", f.title, f.contactName, Icons.Default.Event, "followups"))
                }
            if (!hideSensitive) {
                // Privacy-safe: match & show ONLY document/card names — NEVER numbers or OCR content
                idDocuments.filter { it.documentName.contains(q, true) || it.documentType.contains(q, true) }
                    .take(6)
                    .forEach { d ->
                        add(GlobalSearchResultItem("My IDs", d.documentName, d.documentType, Icons.Default.Badge, "my_ids"))
                    }
                loyaltyCards.filter { it.brandName.contains(q, true) || it.cardNickname.contains(q, true) }
                    .take(6)
                    .forEach { l ->
                        add(GlobalSearchResultItem("Loyalty Cards", l.brandName, l.cardNickname.ifBlank { "Loyalty Card" }, Icons.Default.CardMembership, "loyalty_cards"))
                    }
                secureNotes.filter { it.title.contains(q, true) || it.category.contains(q, true) }
                    .take(6)
                    .forEach { n ->
                        add(GlobalSearchResultItem("Secure Notes", n.title, n.category, Icons.Default.Lock, "secure_notes"))
                    }
            }
            qrProjects.filter { it.name.contains(q, true) || it.qrType.contains(q, true) }
                .take(6)
                .forEach { qp ->
                    add(GlobalSearchResultItem("Saved QR Projects", qp.name, qp.qrType, Icons.Default.QrCode2, "qr_studio"))
                }
            staticEntries.filter { it.title.contains(q, true) || it.subtitle.contains(q, true) || it.category.contains(q, true) }
                .forEach { add(it) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.ux_global_search_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(stringResource(R.string.ux_global_search_hint)) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (results.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No matching results found.", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onNavigateToRoute(item.route) },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(item.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${item.category}${if (item.subtitle.isNotBlank()) " • ${item.subtitle}" else ""}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
