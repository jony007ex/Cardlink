package com.cardlink.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity

data class CardLinkSheetAction(
    val icon: ImageVector,
    val label: String,
    val isDestructive: Boolean = false,
    val onClick: () -> Unit
)

/**
 * Standardized Universal Action Sheet (⋮ More) consuming CardLink's active semantic theme.
 * Destructive actions are visually separated and rendered with MaterialTheme.colorScheme.error.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkActionSheet(
    title: String,
    actions: List<CardLinkSheetAction>,
    onDismiss: () -> Unit
) {
    val regularActions = actions.filterNot { it.isDestructive }
    val destructiveActions = actions.filter { it.isDestructive }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            regularActions.forEach { act ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable {
                            onDismiss()
                            act.onClick()
                        }
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(act.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    Text(act.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                }
            }
            if (destructiveActions.isNotEmpty()) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                destructiveActions.forEach { act ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clickable {
                                onDismiss()
                                act.onClick()
                            }
                            .padding(horizontal = 6.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(act.icon, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(22.dp))
                        Text(act.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

/**
 * Smart Privacy Preview displayed before sharing a CardLink Business Card.
 * Reflects the exact live BusinessCardEntity sharing flags (single source of truth).
 */
@Composable
fun SmartPrivacyPreviewCard(
    card: BusinessCardEntity,
    onUpdateSharingPreferences: (BusinessCardEntity) -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }

    val sharedFields = buildList {
        if (card.fullName.isNotBlank()) add("Name")
        if (card.designation.isNotBlank()) add("Job Title")
        if (card.companyName.isNotBlank()) add("Company")
        if (card.sharePhone && card.phone.isNotBlank()) add("Work Phone")
        if (card.shareWhatsapp && card.whatsapp.isNotBlank()) add("WhatsApp")
        if (card.shareEmail && card.email.isNotBlank()) add("Email")
        if (card.website.isNotBlank()) add("Website")
        if (card.shareSocials && (card.linkedInUrl.isNotBlank() || card.facebookUrl.isNotBlank())) add("Social Links")
        if (card.shareAddress && card.officeAddress.isNotBlank()) add("Office Address")
    }

    val excludedFields = buildList {
        if (!card.sharePhone && card.phone.isNotBlank()) add("Work Phone")
        if (!card.shareWhatsapp && card.whatsapp.isNotBlank()) add("WhatsApp")
        if (!card.shareEmail && card.email.isNotBlank()) add("Email")
        if (!card.shareSocials && (card.linkedInUrl.isNotBlank() || card.facebookUrl.isNotBlank())) add("Social Links")
        if (!card.shareAddress && card.officeAddress.isNotBlank()) add("Office Address")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.PrivacyTip, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Column {
                        Text(stringResource(R.string.privacy_preview_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Text(
                            "${stringResource(R.string.privacy_preview_profile)}: ${card.profileTitle}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                TextButton(
                    onClick = { showEditDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Text(stringResource(R.string.privacy_preview_edit_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = "${stringResource(R.string.privacy_preview_sharing)}: " + sharedFields.joinToString("  •  ") { "✓ $it" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (excludedFields.isNotEmpty()) {
                Text(
                    text = "${stringResource(R.string.privacy_preview_not_shared)}: " + excludedFields.joinToString("  •  ") { "○ $it" },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showEditDialog) {
        var sharePhone by remember(card) { mutableStateOf(card.sharePhone) }
        var shareWhatsapp by remember(card) { mutableStateOf(card.shareWhatsapp) }
        var shareEmail by remember(card) { mutableStateOf(card.shareEmail) }
        var shareAddress by remember(card) { mutableStateOf(card.shareAddress) }
        var shareSocials by remember(card) { mutableStateOf(card.shareSocials) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text(stringResource(R.string.privacy_preview_edit_btn), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SharingPrefRow("Phone", sharePhone) { sharePhone = it }
                    SharingPrefRow("WhatsApp", shareWhatsapp) { shareWhatsapp = it }
                    SharingPrefRow("Email", shareEmail) { shareEmail = it }
                    SharingPrefRow("Office Address", shareAddress) { shareAddress = it }
                    SharingPrefRow("Social Links", shareSocials) { shareSocials = it }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateSharingPreferences(
                        card.copy(
                            sharePhone = sharePhone,
                            shareWhatsapp = shareWhatsapp,
                            shareEmail = shareEmail,
                            shareAddress = shareAddress,
                            shareSocials = shareSocials
                        )
                    )
                    showEditDialog = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun SharingPrefRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
