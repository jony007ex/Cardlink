package com.cardlink.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object ScannedCardStorageHelper {

    private const val CARD_ASPECT_RATIO = 1.586f

    fun cropToCardFrame(source: Bitmap): Bitmap {
        val srcWidth = source.width
        val srcHeight = source.height
        val targetWidth = (srcWidth * 0.88f).toInt().coerceAtMost(srcWidth)
        val targetHeight = (targetWidth / CARD_ASPECT_RATIO).toInt().coerceAtMost(srcHeight)
        val left = ((srcWidth - targetWidth) / 2f).toInt().coerceAtLeast(0)
        val top = ((srcHeight - targetHeight) / 2.2f).toInt().coerceIn(0, (srcHeight - targetHeight).coerceAtLeast(0))
        return Bitmap.createBitmap(source, left, top, targetWidth.coerceAtLeast(1), targetHeight.coerceAtLeast(1))
    }

    fun decodeGalleryUri(context: Context, uri: Uri, maxEdgePx: Int = 1800): Bitmap? {
        if (uri.toString().endsWith(".clenc", ignoreCase = true)) {
            return VaultCryptoManager.decodeVaultBitmap(context, uri.toString(), maxEdgePx)
        }
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, bounds)
            }
            val srcW = bounds.outWidth
            val srcH = bounds.outHeight
            if (srcW <= 0 || srcH <= 0) return@runCatching null
            var sample = 1
            while (maxOf(srcW / sample, srcH / sample) > maxEdgePx) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, opts)
            }
        }.getOrNull()
    }

    /** Copies a picked gallery image (Profile Photo or Company Logo) into permanent local storage */
    fun saveProfileAssetLocally(context: Context, sourceUri: Uri, prefix: String): String? {
        return runCatching {
            val bitmap = decodeGalleryUri(context, sourceUri) ?: return null
            val dir = File(context.filesDir, "profile_assets").apply { if (!exists()) mkdirs() }
            val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            Uri.fromFile(file).toString()
        }.getOrNull()
    }

    fun saveCardBitmapLocally(context: Context, bitmap: Bitmap): String {
        val directory = File(context.filesDir, "scanned_cards").apply { if (!exists()) mkdirs() }
        val file = File(directory, "scanned_card_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        return Uri.fromFile(file).toString()
    }

    fun deleteSavedCardImage(uriString: String?) {
        if (uriString.isNullOrBlank()) return
        runCatching {
            val path = Uri.parse(uriString).path ?: return
            val file = File(path)
            if (file.exists()) file.delete()
        }
    }

    /**
     * Saves a Loyalty Card front or back photo to durable internal app storage with sensible
     * downscaling (max 1600px edge) and 88% JPEG quality so text & codes remain readable
     * without destructive cropping or excessive file size.
     */
    fun saveLoyaltyPhotoBitmap(context: Context, source: Bitmap, sidePrefix: String): String {
        val scaled = scaleDownIfNeeded(source, 1600)
        val uriStr = VaultCryptoManager.saveEncryptedBitmap(
            context = context,
            bitmap = scaled,
            subFolder = "loyalty_cards",
            prefix = "loyalty_$sidePrefix",
            quality = 88
        )
        if (scaled !== source) scaled.recycle()
        return uriStr
    }

    fun saveLoyaltyPhotoFromUri(context: Context, uri: Uri, sidePrefix: String): String? {
        return runCatching {
            val bmp = decodeGalleryUri(context, uri) ?: return null
            saveLoyaltyPhotoBitmap(context, bmp, sidePrefix)
        }.getOrNull()
    }

    private fun scaleDownIfNeeded(src: Bitmap, maxEdge: Int): Bitmap {
        val w = src.width
        val h = src.height
        val longest = maxOf(w, h)
        if (longest <= maxEdge) return src
        val ratio = maxEdge.toFloat() / longest.toFloat()
        return Bitmap.createScaledBitmap(
            src,
            (w * ratio).toInt().coerceAtLeast(1),
            (h * ratio).toInt().coerceAtLeast(1),
            true
        )
    }

}
