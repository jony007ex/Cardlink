package com.cardlink.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.cardlink.app.util.AppCustomThemeConfig

// Default CardLink Navy & Gold fallback constants (used only as defaults in Theme definitions)
val NavyPrimary = Color(0xFF0A192F)
val NavySurface = Color(0xFF112240)
val CharcoalDark = Color(0xFF1E293B)
val GoldAccent = Color(0xFFD4AF37)
val OffWhite = Color(0xFFF8FAFC)

@Immutable
data class CardLinkSemanticColors(
    val success: Color = Color(0xFF10B981),
    val warning: Color = Color(0xFFF59E0B),
    val info: Color = Color(0xFF38BDF8),
    val favoriteActive: Color = GoldAccent,
    val favoriteInactive: Color = Color(0xFF94A3B8)
)

val LocalCardLinkSemanticColors = staticCompositionLocalOf { CardLinkSemanticColors() }

fun resolveColorScheme(
    config: AppCustomThemeConfig?,
    darkTheme: Boolean
): ColorScheme {
    if (config == null) {
        return if (darkTheme) {
            darkColorScheme(
                primary = GoldAccent,
                onPrimary = NavyPrimary,
                primaryContainer = GoldAccent.copy(alpha = 0.22f),
                onPrimaryContainer = GoldAccent,
                secondary = Color(0xFF64FFDA),
                onSecondary = NavyPrimary,
                secondaryContainer = GoldAccent.copy(alpha = 0.18f),
                onSecondaryContainer = OffWhite,
                background = NavyPrimary,
                onBackground = OffWhite,
                surface = NavySurface,
                onSurface = OffWhite,
                surfaceVariant = Color(0xFF1B2B48),
                onSurfaceVariant = OffWhite.copy(alpha = 0.72f),
                outline = Color(0xFF4A5D7A),
                outlineVariant = Color(0xFF2B3C59),
                error = Color(0xFFEF4444),
                onError = Color.White
            )
        } else {
            lightColorScheme(
                primary = NavyPrimary,
                onPrimary = Color.White,
                primaryContainer = Color(0xFFDCE6F5),
                onPrimaryContainer = NavyPrimary,
                secondary = Color(0xFF9A7209),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFE8EEF8),
                onSecondaryContainer = NavyPrimary,
                background = OffWhite,
                onBackground = NavyPrimary,
                surface = Color.White,
                onSurface = CharcoalDark,
                surfaceVariant = Color(0xFFE2E8F0),
                onSurfaceVariant = Color(0xFF475569),
                outline = Color(0xFF64748B),
                outlineVariant = Color(0xFFCBD5E1),
                error = Color(0xFFDC2626),
                onError = Color.White
            )
        }
    }

    return if (darkTheme) {
        val prim = Color(config.buttonHex.toInt())
        val onPrim = Color(config.onPrimaryHex.toInt())
        val sec = Color(config.secondaryHex.toInt())
        val onSec = Color(config.onSecondaryHex.toInt())
        val bg = Color(config.backgroundHex.toInt())
        val surf = Color(config.surfaceHex.toInt())
        val txt = Color(config.textHex.toInt())
        val surfVar = Color(config.surfaceVariantHex.toInt())
        val outl = Color(config.outlineHex.toInt())
        val primContainer = lerp(surf, prim, 0.24f)
        val secContainer = lerp(surf, sec, 0.20f)

        darkColorScheme(
            primary = prim,
            onPrimary = onPrim,
            primaryContainer = primContainer,
            onPrimaryContainer = prim,
            secondary = sec,
            onSecondary = onSec,
            secondaryContainer = secContainer,
            onSecondaryContainer = txt,
            background = bg,
            onBackground = txt,
            surface = surf,
            onSurface = txt,
            surfaceVariant = surfVar,
            onSurfaceVariant = txt.copy(alpha = 0.72f),
            outline = outl,
            outlineVariant = outl.copy(alpha = 0.45f),
            error = Color(config.errorHex.toInt()),
            onError = Color(config.onErrorHex.toInt())
        )
    } else {
        val prim = Color(config.lightPrimaryHex.toInt())
        val onPrim = Color(config.lightOnPrimaryHex.toInt())
        val sec = Color(config.lightSecondaryHex.toInt())
        val onSec = Color(config.lightOnSecondaryHex.toInt())
        val bg = Color(config.lightBackgroundHex.toInt())
        val surf = Color(config.lightSurfaceHex.toInt())
        val txt = Color(config.lightTextHex.toInt())
        val surfVar = Color(config.lightSurfaceVariantHex.toInt())
        val outl = Color(config.lightOutlineHex.toInt())
        val primContainer = lerp(surf, prim, 0.14f)
        val secContainer = lerp(surf, sec, 0.14f)

        lightColorScheme(
            primary = prim,
            onPrimary = onPrim,
            primaryContainer = primContainer,
            onPrimaryContainer = prim,
            secondary = sec,
            onSecondary = onSec,
            secondaryContainer = secContainer,
            onSecondaryContainer = txt,
            background = bg,
            onBackground = txt,
            surface = surf,
            onSurface = txt,
            surfaceVariant = surfVar,
            onSurfaceVariant = txt.copy(alpha = 0.68f),
            outline = outl,
            outlineVariant = outl.copy(alpha = 0.45f),
            error = Color(config.errorHex.toInt()),
            onError = Color(config.onErrorHex.toInt())
        )
    }
}

@Composable
fun CardLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    customConfig: AppCustomThemeConfig? = null,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val scheme = if (customConfig?.useDeviceColors == true && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        resolveColorScheme(customConfig, darkTheme)
    }

    val semanticColors = CardLinkSemanticColors(
        success = Color((customConfig?.successHex ?: 0xFF10B981L).toInt()),
        warning = Color((customConfig?.warningHex ?: 0xFFF59E0BL).toInt()),
        info = Color(0xFF38BDF8),
        favoriteActive = scheme.primary,
        favoriteInactive = scheme.onSurfaceVariant
    )

    CompositionLocalProvider(LocalCardLinkSemanticColors provides semanticColors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
