package com.cardlink.app.util

import android.content.Context
import android.provider.ContactsContract
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DevicePhoneContact(
    val contactId: String,
    val displayName: String,
    val phones: List<String>,
    val emails: List<String>,
    val organization: String = "",
    val jobTitle: String = ""
)

object PhoneContactsHelper {

    fun isValidInternationalOrLocalPhone(raw: String): Boolean {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return false
        val digits = trimmed.filter { it.isDigit() }
        if (digits.length !in 7..15) return false
        return if (trimmed.startsWith("+")) digits.length in 8..15 else true
    }

    fun normalizeWithCountryCode(raw: String, defaultCountryCode: String = "880"): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("+")) return trimmed
        val digits = trimmed.filter { it.isDigit() }
        return when {
            digits.startsWith("00") -> "+${digits.drop(2)}"
            digits.startsWith("0") && digits.length == 11 -> "+$defaultCountryCode${digits.drop(1)}"
            digits.length >= 10 -> "+$digits"
            else -> trimmed
        }
    }

    suspend fun loadDeviceContacts(context: Context): List<DevicePhoneContact> = withContext(Dispatchers.IO) {
        val result = mutableListOf<DevicePhoneContact>()
        val resolver = context.contentResolver

        val phoneMap = mutableMapOf<String, MutableList<String>>()
        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val cid = cursor.getString(idIdx) ?: continue
                val num = cursor.getString(numIdx)?.trim().orEmpty()
                if (num.isNotBlank()) {
                    val list = phoneMap.getOrPut(cid) { mutableListOf() }
                    if (list.none { it.filter(Char::isDigit) == num.filter(Char::isDigit) }) list.add(num)
                }
            }
        }

        val emailMap = mutableMapOf<String, MutableList<String>>()
        resolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Email.CONTACT_ID, ContactsContract.CommonDataKinds.Email.ADDRESS),
            null, null, null
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
            val addrIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)
            while (cursor.moveToNext()) {
                val cid = cursor.getString(idIdx) ?: continue
                val addr = cursor.getString(addrIdx)?.trim().orEmpty()
                if (addr.isNotBlank()) {
                    val list = emailMap.getOrPut(cid) { mutableListOf() }
                    if (!list.contains(addr)) list.add(addr)
                }
            }
        }

        val orgMap = mutableMapOf<String, Pair<String, String>>()
        resolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(
                ContactsContract.Data.CONTACT_ID,
                ContactsContract.CommonDataKinds.Organization.COMPANY,
                ContactsContract.CommonDataKinds.Organization.TITLE
            ),
            "${ContactsContract.Data.MIMETYPE} = ?",
            arrayOf(ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE),
            null
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.Data.CONTACT_ID)
            val compIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.COMPANY)
            val titleIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.TITLE)
            while (cursor.moveToNext()) {
                val cid = cursor.getString(idIdx) ?: continue
                val comp = cursor.getString(compIdx)?.trim().orEmpty()
                val title = cursor.getString(titleIdx)?.trim().orEmpty()
                if (comp.isNotBlank() || title.isNotBlank()) orgMap[cid] = Pair(comp, title)
            }
        }

        resolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
            null, null, "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} ASC"
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.Contacts._ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            while (cursor.moveToNext()) {
                val cid = cursor.getString(idIdx) ?: continue
                val name = cursor.getString(nameIdx)?.trim().orEmpty()
                val phones = phoneMap[cid].orEmpty()
                val emails = emailMap[cid].orEmpty()
                if (name.isNotBlank() || phones.isNotEmpty() || emails.isNotEmpty()) {
                    val orgPair = orgMap[cid]
                    result.add(
                        DevicePhoneContact(
                            contactId = cid,
                            displayName = name.ifBlank { "Phone Contact" },
                            phones = phones,
                            emails = emails,
                            organization = orgPair?.first.orEmpty(),
                            jobTitle = orgPair?.second.orEmpty()
                        )
                    )
                }
            }
        }
        result
    }

    fun findDuplicateContact(
        existing: List<SavedContactEntity>,
        name: String,
        phone: String,
        email: String
    ): SavedContactEntity? {
        val normPhone = phone.filter(Char::isDigit).takeLast(8)
        val normEmail = email.trim().lowercase()
        val normName = name.trim().lowercase()

        if (normPhone.length >= 7) {
            existing.firstOrNull { it.phone.filter(Char::isDigit).takeLast(8) == normPhone }?.let { return it }
        }
        if (normEmail.isNotBlank()) {
            existing.firstOrNull { it.email.trim().lowercase() == normEmail }?.let { return it }
        }
        if (normName.length >= 3) {
            existing.firstOrNull { it.fullName.trim().lowercase() == normName }?.let { return it }
        }
        return null
    }
}
