package com.cardlink.app.util

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.MultiFormatWriter
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object LoyaltyCodeHelper {

    val SUPPORTED_1D_FORMATS = listOf(
        "CODE_128",
        "CODE_39",
        "EAN_13",
        "EAN_8",
        "UPC_A",
        "UPC_E",
        "ITF",
        "CODABAR"
    )

    fun mlKitFormatToName(mlKitFormat: Int): String? = when (mlKitFormat) {
        Barcode.FORMAT_CODE_128 -> "CODE_128"
        Barcode.FORMAT_CODE_39 -> "CODE_39"
        Barcode.FORMAT_EAN_13 -> "EAN_13"
        Barcode.FORMAT_EAN_8 -> "EAN_8"
        Barcode.FORMAT_UPC_A -> "UPC_A"
        Barcode.FORMAT_UPC_E -> "UPC_E"
        Barcode.FORMAT_ITF -> "ITF"
        Barcode.FORMAT_CODABAR -> "CODABAR"
        Barcode.FORMAT_QR_CODE -> "QR_CODE"
        else -> null
    }

    fun formatDisplayName(formatName: String): String = when (formatName.uppercase()) {
        "CODE_128" -> "Code 128"
        "CODE_39" -> "Code 39"
        "EAN_13" -> "EAN-13"
        "EAN_8" -> "EAN-8"
        "UPC_A" -> "UPC-A"
        "UPC_E" -> "UPC-E"
        "ITF" -> "ITF"
        "CODABAR" -> "Codabar"
        "QR_CODE" -> "QR Code"
        else -> formatName
    }

    private fun nameToZxingFormat(formatName: String): BarcodeFormat? = when (formatName.uppercase()) {
        "CODE_128" -> BarcodeFormat.CODE_128
        "CODE_39" -> BarcodeFormat.CODE_39
        "EAN_13" -> BarcodeFormat.EAN_13
        "EAN_8" -> BarcodeFormat.EAN_8
        "UPC_A" -> BarcodeFormat.UPC_A
        "UPC_E" -> BarcodeFormat.UPC_E
        "ITF" -> BarcodeFormat.ITF
        "CODABAR" -> BarcodeFormat.CODABAR
        else -> null
    }

    /**
     * Re-generates a crisp, high-contrast 1D barcode directly from the stored format + exact payload.
     * Never guesses an unsupported format or fabricates data; returns null if encoding fails.
     */
    fun generateBarcodeBitmap(
        payload: String,
        formatName: String,
        widthPx: Int = 960,
        heightPx: Int = 320
    ): Bitmap? {
        if (payload.isBlank() || formatName.isBlank()) return null
        val zxingFormat = nameToZxingFormat(formatName) ?: return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.MARGIN to 12,
                EncodeHintType.CHARACTER_SET to "UTF-8"
            )
            val matrix = MultiFormatWriter().encode(payload, zxingFormat, widthPx, heightPx, hints)
            val w = matrix.width
            val h = matrix.height
            val pixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, w, 0, 0, w, h)
            }
        }.getOrNull()
    }

    /**
     * Re-generates a clean, high-contrast QR Code from the exact verbatim stored QR payload.
     */
    fun generateQrBitmap(
        payload: String,
        sizePx: Int = 640
    ): Bitmap? {
        if (payload.isBlank()) return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
                EncodeHintType.CHARACTER_SET to "UTF-8",
                EncodeHintType.MARGIN to 2
            )
            val matrix = MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val w = matrix.width
            val h = matrix.height
            val pixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, w, 0, 0, w, h)
            }
        }.getOrNull()
    }

    fun maskCardNumber(raw: String): String {
        val clean = raw.trim()
        if (clean.length <= 4) return clean
        return "•••• ${clean.takeLast(4)}"
    }

    fun verifyCodeBitmap(bitmap: Bitmap?, expectedPayload: String): Boolean {
        if (bitmap == null || expectedPayload.isBlank()) return false
        return runCatching {
            val w = bitmap.width
            val h = bitmap.height
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            val source = RGBLuminanceSource(w, h, pixels)
            val binary = BinaryBitmap(HybridBinarizer(source))
            val hints = mapOf(DecodeHintType.TRY_HARDER to true)
            MultiFormatReader().decode(binary, hints).text == expectedPayload
        }.getOrDefault(false)
    }
}
