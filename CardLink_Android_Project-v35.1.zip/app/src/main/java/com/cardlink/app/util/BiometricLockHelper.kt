package com.cardlink.app.util

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricLockHelper {
    private const val PREFS_NAME = "cardlink_security_prefs"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_lock_enabled"

    fun isLockEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun setLockEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    fun canAuthenticate(context: Context): Boolean {
        val manager = BiometricManager.from(context)
        val combined = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        } else {
            Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        }
        if (manager.canAuthenticate(combined) == BiometricManager.BIOMETRIC_SUCCESS) return true
        if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) return true
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return km?.isDeviceSecure == true
    }

    @Suppress("DEPRECATION")
    fun createDeviceCredentialIntent(context: Context): Intent? {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return if (km?.isDeviceSecure == true) {
            km.createConfirmDeviceCredentialIntent("Unlock Card Link", "Authenticate using your device screen lock")
        } else null
    }

    fun showPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onFallbackToDeviceCredential: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result); onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) onFallbackToDeviceCredential()
                else onError(errString.toString())
            }
        })

        val manager = BiometricManager.from(activity)
        val rCombo = Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL

        val promptInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && manager.canAuthenticate(rCombo) == BiometricManager.BIOMETRIC_SUCCESS) {
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Use Fingerprint, Face, or Device Screen Lock").setAllowedAuthenticators(rCombo).build()
            } else if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) {
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Authenticate with Biometrics").setAllowedAuthenticators(Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Use Device Lock").build()
            } else {
                @Suppress("DEPRECATION")
                BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Card Link").setSubtitle("Authenticate to access Card Link").setDeviceCredentialAllowed(true).build()
            }
        } catch (_: Exception) {
            onFallbackToDeviceCredential(); return
        }
        runCatching { prompt.authenticate(promptInfo) }.onFailure { onFallbackToDeviceCredential() }
    }
}
