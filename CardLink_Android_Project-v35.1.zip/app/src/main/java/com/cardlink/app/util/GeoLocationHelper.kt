package com.cardlink.app.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

object GeoLocationHelper {

    /**
     * Resolves an office address string into (Latitude, Longitude) using Android's native Geocoder.
     */
    @Suppress("DEPRECATION")
    suspend fun geocodeAddress(context: Context, addressText: String): Pair<Double, Double>? =
        withContext(Dispatchers.IO) {
            if (addressText.isBlank() || !Geocoder.isPresent()) return@withContext null
            runCatching {
                val geocoder = Geocoder(context, Locale.getDefault())
                val results = geocoder.getFromLocationName(addressText.trim(), 1)
                val first = results?.firstOrNull() ?: return@withContext null
                Pair(first.latitude, first.longitude)
            }.getOrNull()
        }

    /**
     * Reverse-geocodes (Latitude, Longitude) into a readable street/office address if the address field is empty.
     */
    @Suppress("DEPRECATION")
    suspend fun reverseGeocode(context: Context, lat: Double, lng: Double): String? =
        withContext(Dispatchers.IO) {
            if (!Geocoder.isPresent()) return@withContext null
            runCatching {
                val geocoder = Geocoder(context, Locale.getDefault())
                val results = geocoder.getFromLocation(lat, lng, 1)
                results?.firstOrNull()?.getAddressLine(0)
            }.getOrNull()
        }

    /**
     * Retrieves the most recent accurate device GPS/Network location (requires ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION).
     */
    @SuppressLint("MissingPermission")
    fun getCurrentGpsCoordinates(context: Context): Pair<Double, Double>? {
        return runCatching {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
            val providers = lm.getProviders(true)
            var bestLocation: Location? = null
            for (provider in providers) {
                val loc = runCatching { lm.getLastKnownLocation(provider) }.getOrNull() ?: continue
                if (bestLocation == null || loc.accuracy < bestLocation.accuracy) {
                    bestLocation = loc
                }
            }
            bestLocation?.let { Pair(it.latitude, it.longitude) }
        }.getOrNull()
    }

    /**
     * Calculates straight-line distance in kilometers between two GPS points.
     */
    fun distanceInKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val result = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, result)
        return (result[0] / 100.0).roundToInt() / 10.0
    }

    fun formatCoordinates(lat: Double?, lng: Double?): String {
        if (lat == null || lng == null) return ""
        return String.format(Locale.US, "%.5f, %.5f", lat, lng)
    }
}
