package com.cardlink.app.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

enum class IdExpiryStatus {
    NO_EXPIRY,
    VALID,
    RENEWAL_RECOMMENDED,
    EXPIRING_SOON,
    EXPIRES_TODAY,
    EXPIRED
}

object IdExpiryHelper {

    private val DISPLAY_FORMAT = DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.getDefault())

    fun parseIsoDate(iso: String?): LocalDate? {
        if (iso.isNullOrBlank()) return null
        return runCatching { LocalDate.parse(iso.trim(), DateTimeFormatter.ISO_LOCAL_DATE) }.getOrNull()
    }

    fun toIsoDate(year: Int, month1Based: Int, dayOfMonth: Int): String {
        return LocalDate.of(year, month1Based, dayOfMonth).format(DateTimeFormatter.ISO_LOCAL_DATE)
    }

    fun formatDisplayDate(iso: String?): String {
        val d = parseIsoDate(iso) ?: return ""
        return d.format(DISPLAY_FORMAT)
    }

    /**
     * Dynamically calculates calendar days remaining from the user's local today to expiryDateIso.
     * Positive = future, 0 = expires today, Negative = expired N days ago.
     */
    fun daysUntilExpiry(iso: String?, today: LocalDate = LocalDate.now()): Long? {
        val expiry = parseIsoDate(iso) ?: return null
        return ChronoUnit.DAYS.between(today, expiry)
    }

    fun resolveStatus(iso: String?, today: LocalDate = LocalDate.now()): IdExpiryStatus {
        val days = daysUntilExpiry(iso, today) ?: return IdExpiryStatus.NO_EXPIRY
        return when {
            days < 0L -> IdExpiryStatus.EXPIRED
            days == 0L -> IdExpiryStatus.EXPIRES_TODAY
            days <= 30L -> IdExpiryStatus.EXPIRING_SOON
            days <= 60L -> IdExpiryStatus.RENEWAL_RECOMMENDED
            else -> IdExpiryStatus.VALID
        }
    }

    private val EXPIRY_LABELS = listOf(
        "expiry date", "date of expiry", "valid until", "valid thru", "expires", "exp.", "exp:",
        "মেয়াদ শেষ", "মেয়াদ শেষ", "মেয়াদ উত্তীর্ণের তারিখ", "বৈধতার শেষ তারিখ"
    )

    private val DATE_REGEX = Regex(
        """(\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b|\b\d{1,2}[-/.\s](?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[-/.\s,]*\d{4}\b|\b\d{1,2}[-/.]\d{1,2}[-/.]\d{4}\b)""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Scans OCR text for possible expiry dates near known English/Bangla expiry labels.
     * Returns distinct ISO dates ("YYYY-MM-DD") for explicit user confirmation — never auto-saved.
     */
    fun detectExpiryDateCandidates(rawText: String): List<String> {
        if (rawText.isBlank()) return emptyList()
        val lines = rawText.lines()
        val prioritized = mutableListOf<String>()
        val fallback = mutableListOf<String>()

        lines.forEachIndexed { idx, line ->
            val lower = line.lowercase(Locale.ROOT)
            val hasLabel = EXPIRY_LABELS.any { lower.contains(it) }
            val window = if (hasLabel && idx + 1 < lines.size) "$line ${lines[idx + 1]}" else line
            DATE_REGEX.findAll(window).forEach { match ->
                val parsed = tryParseFlexibleDate(match.value)
                if (parsed != null) {
                    val iso = parsed.format(DateTimeFormatter.ISO_LOCAL_DATE)
                    if (hasLabel) prioritized.add(iso) else fallback.add(iso)
                }
            }
        }
        return (prioritized.ifEmpty { fallback }).distinct()
    }

    private fun tryParseFlexibleDate(raw: String): LocalDate? {
        val cleaned = raw.trim().replace(",", "").replace(Regex("\\s+"), " ")
        val formatters = listOf(
            DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US),
            DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US),
            DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.US),
            DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.US),
            DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.US),
            DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US),
            DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.US),
            DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.US),
            DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.US)
        )
        for (fmt in formatters) {
            val d = runCatching { LocalDate.parse(cleaned, fmt) }.getOrNull()
            if (d != null && d.year in 2000..2100) return d
        }
        return null
    }
}
