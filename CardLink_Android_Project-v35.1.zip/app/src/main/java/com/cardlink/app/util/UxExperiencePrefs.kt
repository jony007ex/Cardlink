package com.cardlink.app.util

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object UxExperiencePrefs {
    private const val PREFS = "cardlink_ux_experience_prefs"
    private const val KEY_ONBOARDING_DONE = "onboarding_completed_v1"
    private const val KEY_CHECKLIST_DISMISSED = "get_started_dismissed_v1"
    private const val KEY_WHATS_NEW_VER = "whats_new_last_seen_ver"
    private const val KEY_FAV_TOOLS = "favorite_tool_ids_v1"
    private const val KEY_RECENT_TOOLS = "recent_tool_ids_v1"
    private const val KEY_TESTED_SHARE = "checklist_tested_share_v1"
    private const val KEY_TOOL_COUNTS = "tool_launch_counts_v1"
    private const val KEY_DISMISSED_SUGGESTIONS = "dismissed_tool_suggestions_v1"

    private const val CURRENT_WHATS_NEW_VER = 32
    private val json = Json { ignoreUnknownKeys = true }

    fun isOnboardingCompleted(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ONBOARDING_DONE, false)

    fun setOnboardingCompleted(context: Context, done: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ONBOARDING_DONE, done)
            .apply()
    }

    fun isChecklistDismissed(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CHECKLIST_DISMISSED, false)

    fun setChecklistDismissed(context: Context, dismissed: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_CHECKLIST_DISMISSED, dismissed)
            .apply()
    }

    fun markShareTested(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_TESTED_SHARE, true)
            .apply()
    }

    fun hasTestedShare(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_TESTED_SHARE, false)

    fun shouldShowWhatsNew(context: Context): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(KEY_ONBOARDING_DONE, false)) return false
        return p.getInt(KEY_WHATS_NEW_VER, 0) < CURRENT_WHATS_NEW_VER
    }

    fun markWhatsNewSeen(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_WHATS_NEW_VER, CURRENT_WHATS_NEW_VER)
            .apply()
    }

    fun getFavoriteToolIds(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_FAV_TOOLS, null)
            ?: return listOf("my_ids", "loyalty_cards", "qr_studio", "secure_notes")
        return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    fun toggleFavoriteTool(context: Context, toolId: String): Pair<List<String>, Boolean> {
        val current = getFavoriteToolIds(context).toMutableList()
        return if (toolId in current) {
            current.remove(toolId)
            saveStringList(context, KEY_FAV_TOOLS, current)
            Pair(current, true)
        } else if (current.size >= 4) {
            Pair(current, false) // Max 4 pinned favorite tools to prevent clutter
        } else {
            current.add(toolId)
            saveStringList(context, KEY_FAV_TOOLS, current)
            Pair(current, true)
        }
    }

    fun setFavoriteToolIds(context: Context, ids: List<String>) {
        saveStringList(context, KEY_FAV_TOOLS, ids.distinct().take(4))
    }

    fun moveFavoriteTool(context: Context, toolId: String, delta: Int): List<String> {
        val list = getFavoriteToolIds(context).toMutableList()
        val idx = list.indexOf(toolId)
        if (idx == -1) return list
        val target = (idx + delta).coerceIn(0, list.lastIndex)
        if (target != idx) {
            val item = list.removeAt(idx)
            list.add(target, item)
            saveStringList(context, KEY_FAV_TOOLS, list)
        }
        return list
    }

    fun getRecentToolIds(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT_TOOLS, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    fun recordToolUsed(context: Context, toolId: String) {
        val updated = (listOf(toolId) + getRecentToolIds(context).filterNot { it == toolId }).take(4)
        saveStringList(context, KEY_RECENT_TOOLS, updated)
        val counts = getToolLaunchCounts(context).toMutableMap()
        counts[toolId] = (counts[toolId] ?: 0) + 1
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TOOL_COUNTS, json.encodeToString(counts))
            .apply()
    }

    fun getToolLaunchCounts(context: Context): Map<String, Int> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOOL_COUNTS, null)
            ?: return emptyMap()
        return runCatching { json.decodeFromString<Map<String, Int>>(raw) }.getOrDefault(emptyMap())
    }

    fun dismissToolSuggestion(context: Context, toolId: String) {
        val cur = getDismissedSuggestions(context).toMutableList()
        if (toolId !in cur) cur.add(toolId)
        saveStringList(context, KEY_DISMISSED_SUGGESTIONS, cur)
    }

    fun getDismissedSuggestions(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DISMISSED_SUGGESTIONS, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

    /**
     * Returns a frequently used (>= 3 launches) non-favorite, non-dismissed tool ID to suggest adding to Favorites.
     */
    fun getSuggestedFavoriteToolId(context: Context, currentFavorites: List<String>, hideSensitive: Boolean): String? {
        if (currentFavorites.size >= 4) return null
        val dismissed = getDismissedSuggestions(context).toSet()
        return getToolLaunchCounts(context).entries
            .filter { (id, count) ->
                count >= 3 && id !in currentFavorites && id !in dismissed &&
                    ToolsRegistry.findById(id)?.let { it.quickActionEligible && (!hideSensitive || !it.isSensitive) } == true
            }
            .maxByOrNull { it.value }
            ?.key
    }

    private fun saveStringList(context: Context, key: String, items: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(key, json.encodeToString(items))
            .apply()
    }
}
