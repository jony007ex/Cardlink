package com.cardlink.app.util

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.pow

@Serializable
data class AppCustomThemeConfig(
    val presetId: String = "cardlink_navy_gold",
    val customThemeUuid: String? = null,
    val themeName: String = "CardLink Navy & Gold",
    val useDeviceColors: Boolean = false,
    // Dark mode semantic roles (backward-compatible with legacy fields)
    val primaryHex: Long = 0xFF0A192F,
    val secondaryHex: Long = 0xFFD4AF37,
    val backgroundHex: Long = 0xFF0A192F,
    val surfaceHex: Long = 0xFF112240,
    val textHex: Long = 0xFFF8FAFC,
    val accentHex: Long = 0xFFD4AF37,
    val buttonHex: Long = 0xFFD4AF37,
    val iconHex: Long = 0xFFD4AF37,
    // Extended semantic roles (Light + Status + Outline)
    val onPrimaryHex: Long = 0xFF0A192F,
    val onSecondaryHex: Long = 0xFF0A192F,
    val surfaceVariantHex: Long = 0xFF1B2B48,
    val outlineHex: Long = 0xFF3B4D6B,
    val errorHex: Long = 0xFFEF4444,
    val onErrorHex: Long = 0xFFFFFFFF,
    val successHex: Long = 0xFF10B981,
    val warningHex: Long = 0xFFF59E0B,
    // Coordinated Light Mode semantic roles
    val lightPrimaryHex: Long = 0xFF0A192F,
    val lightOnPrimaryHex: Long = 0xFFFFFFFF,
    val lightSecondaryHex: Long = 0xFFB58900,
    val lightOnSecondaryHex: Long = 0xFFFFFFFF,
    val lightBackgroundHex: Long = 0xFFF8FAFC,
    val lightSurfaceHex: Long = 0xFFFFFFFF,
    val lightTextHex: Long = 0xFF0F172A,
    val lightSurfaceVariantHex: Long = 0xFFE2E8F0,
    val lightOutlineHex: Long = 0xFF94A3B8,
    val updatedAtTimestamp: Long = 0L
)

enum class ThemeAccessibilityLevel {
    ACCESSIBLE,
    NEEDS_ADJUSTMENT,
    LOW_CONTRAST
}

data class ThemeAccessibilityReport(
    val level: ThemeAccessibilityLevel,
    val textOnBgRatio: Double,
    val textOnSurfaceRatio: Double,
    val onPrimaryRatio: Double,
    val summaryText: String
)

data class BuiltInAppThemePreset(
    val id: String,
    val name: String,
    val config: AppCustomThemeConfig
)

object AppThemePresets {
    val all: List<BuiltInAppThemePreset> = listOf(
        BuiltInAppThemePreset(
            id = "cardlink_navy_gold",
            name = "CardLink Navy & Gold",
            config = AppCustomThemeConfig(
                presetId = "cardlink_navy_gold",
                themeName = "CardLink Navy & Gold",
                primaryHex = 0xFF0A192F, secondaryHex = 0xFFD4AF37, backgroundHex = 0xFF0A192F,
                surfaceHex = 0xFF112240, textHex = 0xFFF8FAFC, accentHex = 0xFFD4AF37,
                buttonHex = 0xFFD4AF37, iconHex = 0xFFD4AF37, onPrimaryHex = 0xFF0A192F,
                surfaceVariantHex = 0xFF1B2B48, outlineHex = 0xFF4A5D7A,
                lightPrimaryHex = 0xFF0A192F, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF9A7209, lightBackgroundHex = 0xFFF8FAFC,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF0F172A,
                lightSurfaceVariantHex = 0xFFE2E8F0, lightOutlineHex = 0xFF64748B
            )
        ),
        BuiltInAppThemePreset(
            id = "midnight_blue",
            name = "Midnight Blue",
            config = AppCustomThemeConfig(
                presetId = "midnight_blue",
                themeName = "Midnight Blue",
                primaryHex = 0xFF0F172A, secondaryHex = 0xFF38BDF8, backgroundHex = 0xFF0B1120,
                surfaceHex = 0xFF1E293B, textHex = 0xFFF1F5F9, accentHex = 0xFF38BDF8,
                buttonHex = 0xFF38BDF8, iconHex = 0xFF38BDF8, onPrimaryHex = 0xFF0B1120,
                surfaceVariantHex = 0xFF283548, outlineHex = 0xFF475569,
                lightPrimaryHex = 0xFF0369A1, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF0284C7, lightBackgroundHex = 0xFFF0F9FF,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF0F172A,
                lightSurfaceVariantHex = 0xFFE0F2FE, lightOutlineHex = 0xFF64748B
            )
        ),
        BuiltInAppThemePreset(
            id = "royal_emerald",
            name = "Royal Emerald",
            config = AppCustomThemeConfig(
                presetId = "royal_emerald",
                themeName = "Royal Emerald",
                primaryHex = 0xFF052E24, secondaryHex = 0xFFFBBF24, backgroundHex = 0xFF041F18,
                surfaceHex = 0xFF0B352A, textHex = 0xFFECFDF5, accentHex = 0xFF34D399,
                buttonHex = 0xFF34D399, iconHex = 0xFFFBBF24, onPrimaryHex = 0xFF041F18,
                surfaceVariantHex = 0xFF134E3E, outlineHex = 0xFF2D6A58,
                lightPrimaryHex = 0xFF065F46, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFFB45309, lightBackgroundHex = 0xFFF0FDF4,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF064E3B,
                lightSurfaceVariantHex = 0xFFDCFCE7, lightOutlineHex = 0xFF4B7F6E
            )
        ),
        BuiltInAppThemePreset(
            id = "graphite_platinum",
            name = "Graphite & Platinum",
            config = AppCustomThemeConfig(
                presetId = "graphite_platinum",
                themeName = "Graphite & Platinum",
                primaryHex = 0xFF18181B, secondaryHex = 0xFFE4E4E7, backgroundHex = 0xFF121215,
                surfaceHex = 0xFF1F1F24, textHex = 0xFFFAFAFA, accentHex = 0xFFE4E4E7,
                buttonHex = 0xFFE4E4E7, iconHex = 0xFFD4D4D8, onPrimaryHex = 0xFF121215,
                surfaceVariantHex = 0xFF2C2C33, outlineHex = 0xFF52525B,
                lightPrimaryHex = 0xFF27272A, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF52525B, lightBackgroundHex = 0xFFFAFAFA,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF18181B,
                lightSurfaceVariantHex = 0xFFE4E4E7, lightOutlineHex = 0xFF71717A
            )
        ),
        BuiltInAppThemePreset(
            id = "violet_cyan",
            name = "Violet & Cyan",
            config = AppCustomThemeConfig(
                presetId = "violet_cyan",
                themeName = "Violet & Cyan",
                primaryHex = 0xFF1E1035, secondaryHex = 0xFF22D3EE, backgroundHex = 0xFF140B24,
                surfaceHex = 0xFF23153D, textHex = 0xFFF5F3FF, accentHex = 0xFF22D3EE,
                buttonHex = 0xFFA78BFA, iconHex = 0xFF22D3EE, onPrimaryHex = 0xFF140B24,
                surfaceVariantHex = 0xFF322054, outlineHex = 0xFF5B438A,
                lightPrimaryHex = 0xFF5B21B6, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF0E7490, lightBackgroundHex = 0xFFF5F3FF,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF2E1065,
                lightSurfaceVariantHex = 0xFFEDE9FE, lightOutlineHex = 0xFF7C3AED
            )
        ),
        BuiltInAppThemePreset(
            id = "ocean_blue",
            name = "Ocean Blue",
            config = AppCustomThemeConfig(
                presetId = "ocean_blue",
                themeName = "Ocean Blue",
                primaryHex = 0xFF0C2438, secondaryHex = 0xFF2DD4BF, backgroundHex = 0xFF081A29,
                surfaceHex = 0xFF112D44, textHex = 0xFFF0FDFA, accentHex = 0xFF2DD4BF,
                buttonHex = 0xFF2DD4BF, iconHex = 0xFF2DD4BF, onPrimaryHex = 0xFF081A29,
                surfaceVariantHex = 0xFF1A3D5A, outlineHex = 0xFF3B6688,
                lightPrimaryHex = 0xFF0F4C81, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF0F766E, lightBackgroundHex = 0xFFF0F9FF,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF0C2438,
                lightSurfaceVariantHex = 0xFFE0F2FE, lightOutlineHex = 0xFF476B8A
            )
        ),
        BuiltInAppThemePreset(
            id = "burgundy_rose_gold",
            name = "Burgundy & Rose Gold",
            config = AppCustomThemeConfig(
                presetId = "burgundy_rose_gold",
                themeName = "Burgundy & Rose Gold",
                primaryHex = 0xFF2D0F18, secondaryHex = 0xFFF4B6A8, backgroundHex = 0xFF1F0A11,
                surfaceHex = 0xFF35131E, textHex = 0xFFFFF1F2, accentHex = 0xFFF4B6A8,
                buttonHex = 0xFFF4B6A8, iconHex = 0xFFF4B6A8, onPrimaryHex = 0xFF1F0A11,
                surfaceVariantHex = 0xFF4A1D2C, outlineHex = 0xFF7A384D,
                lightPrimaryHex = 0xFF881337, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF9F1239, lightBackgroundHex = 0xFFFFF1F2,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF4C0519,
                lightSurfaceVariantHex = 0xFFFFE4E6, lightOutlineHex = 0xFF9F4A60
            )
        ),
        BuiltInAppThemePreset(
            id = "high_contrast",
            name = "High Contrast",
            config = AppCustomThemeConfig(
                presetId = "high_contrast",
                themeName = "High Contrast",
                primaryHex = 0xFF000000, secondaryHex = 0xFFFFD700, backgroundHex = 0xFF000000,
                surfaceHex = 0xFF121212, textHex = 0xFFFFFFFF, accentHex = 0xFFFFD700,
                buttonHex = 0xFFFFD700, iconHex = 0xFFFFD700, onPrimaryHex = 0xFF000000,
                surfaceVariantHex = 0xFF222222, outlineHex = 0xFFFFFFFF,
                lightPrimaryHex = 0xFF000000, lightOnPrimaryHex = 0xFFFFFFFF,
                lightSecondaryHex = 0xFF003399, lightBackgroundHex = 0xFFFFFFFF,
                lightSurfaceHex = 0xFFFFFFFF, lightTextHex = 0xFF000000,
                lightSurfaceVariantHex = 0xFFE5E7EB, lightOutlineHex = 0xFF000000
            )
        )
    )

    fun findById(id: String): BuiltInAppThemePreset? = all.firstOrNull { it.id == id }
}

object ThemeContrastHelper {
    private const val PREFS = "cardlink_custom_theme_prefs"
    private const val KEY_THEME_JSON = "app_theme_studio_v2_json"
    private const val KEY_CUSTOM_THEMES_JSON = "app_custom_themes_list_v1"
    private const val KEY_RECENT_COLORS_JSON = "app_theme_recent_colors_v1"

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun loadAppTheme(context: Context): AppCustomThemeConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val modernJson = p.getString(KEY_THEME_JSON, null)
        if (!modernJson.isNullOrBlank()) {
            val parsed = runCatching { json.decodeFromString<AppCustomThemeConfig>(modernJson) }.getOrNull()
            if (parsed != null) return parsed
        }
        val legacyBg = p.getLong("app_bg", 0xFF0A192F)
        val legacySurface = p.getLong("app_surface", 0xFF112240)
        val legacyText = p.getLong("app_text", 0xFFF8FAFC)
        val legacyBtn = p.getLong("app_button", 0xFFD4AF37)
        val legacyPrimary = p.getLong("app_primary", 0xFF0A192F)
        val legacySec = p.getLong("app_secondary", 0xFFD4AF37)
        val isDefault = legacyBg == 0xFF0A192F && legacyBtn == 0xFFD4AF37 && legacySurface == 0xFF112240
        val migrated = if (isDefault) {
            AppThemePresets.all.first().config
        } else {
            AppCustomThemeConfig(
                presetId = "custom",
                themeName = "Custom Theme",
                primaryHex = legacyPrimary,
                secondaryHex = legacySec,
                backgroundHex = legacyBg,
                surfaceHex = legacySurface,
                textHex = legacyText,
                accentHex = p.getLong("app_accent", legacyBtn),
                buttonHex = legacyBtn,
                iconHex = p.getLong("app_icon", legacyBtn),
                onPrimaryHex = bestOnColor(legacyBtn)
            )
        }
        saveAppTheme(context, migrated)
        return migrated
    }

    fun saveAppTheme(context: Context, cfg: AppCustomThemeConfig) {
        val updated = cfg.copy(updatedAtTimestamp = System.currentTimeMillis())
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_THEME_JSON, json.encodeToString(updated))
            .putLong("app_primary", updated.primaryHex)
            .putLong("app_secondary", updated.secondaryHex)
            .putLong("app_bg", updated.backgroundHex)
            .putLong("app_surface", updated.surfaceHex)
            .putLong("app_text", updated.textHex)
            .putLong("app_accent", updated.accentHex)
            .putLong("app_button", updated.buttonHex)
            .putLong("app_icon", updated.iconHex)
            .apply()
    }

    fun resetAppTheme(context: Context): AppCustomThemeConfig {
        val def = AppThemePresets.all.first().config
        saveAppTheme(context, def)
        return def
    }

    fun loadSavedCustomThemes(context: Context): List<AppCustomThemeConfig> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CUSTOM_THEMES_JSON, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<AppCustomThemeConfig>>(raw) }.getOrDefault(emptyList())
    }

    fun saveCustomThemeToList(context: Context, theme: AppCustomThemeConfig): List<AppCustomThemeConfig> {
        val uuid = theme.customThemeUuid ?: java.util.UUID.randomUUID().toString()
        val entry = theme.copy(presetId = "custom", customThemeUuid = uuid, updatedAtTimestamp = System.currentTimeMillis())
        val updated = (listOf(entry) + loadSavedCustomThemes(context).filterNot { it.customThemeUuid == uuid }).take(12)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_CUSTOM_THEMES_JSON, json.encodeToString(updated))
            .apply()
        return updated
    }

    fun deleteCustomThemeFromList(context: Context, uuid: String): List<AppCustomThemeConfig> {
        val updated = loadSavedCustomThemes(context).filterNot { it.customThemeUuid == uuid }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_CUSTOM_THEMES_JSON, json.encodeToString(updated))
            .apply()
        return updated
    }

    fun loadRecentColors(context: Context): List<Long> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT_COLORS_JSON, null)
            ?: return emptyList()
        return runCatching { json.decodeFromString<List<Long>>(raw) }.getOrDefault(emptyList())
    }

    fun recordRecentColor(context: Context, colorLong: Long) {
        val updated = (listOf(colorLong) + loadRecentColors(context).filterNot { it == colorLong }).take(8)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_RECENT_COLORS_JSON, json.encodeToString(updated))
            .apply()
    }

    fun generateSimplePalette(mainHex: Long, accentHex: Long, themeName: String = "Custom Theme"): AppCustomThemeConfig {
        val darkBg = blendColor(mainHex, 0xFF050A14L, 0.45f)
        val darkSurface = blendColor(mainHex, 0xFF162032L, 0.28f)
        val darkSurfaceVar = blendColor(darkSurface, 0xFFFFFFFFL, 0.08f)
        val darkOutline = blendColor(darkSurface, 0xFFFFFFFFL, 0.25f)
        val darkText = bestOnColor(darkBg)
        val onDarkBtn = bestOnColor(accentHex)

        val lightBg = blendColor(mainHex, 0xFFFFFFFFL, 0.94f)
        val lightSurfaceVar = blendColor(mainHex, 0xFFFFFFFFL, 0.85f)
        val lightPrimary = if (contrastRatio(mainHex, 0xFFFFFFFFL) >= 4.5) mainHex else blendColor(mainHex, 0xFF000000L, 0.45f)
        val lightSec = if (contrastRatio(accentHex, 0xFFFFFFFFL) >= 3.2) accentHex else blendColor(accentHex, 0xFF000000L, 0.35f)

        return AppCustomThemeConfig(
            presetId = "custom",
            themeName = themeName,
            primaryHex = mainHex,
            secondaryHex = accentHex,
            backgroundHex = darkBg,
            surfaceHex = darkSurface,
            textHex = darkText,
            accentHex = accentHex,
            buttonHex = accentHex,
            iconHex = accentHex,
            onPrimaryHex = onDarkBtn,
            onSecondaryHex = onDarkBtn,
            surfaceVariantHex = darkSurfaceVar,
            outlineHex = darkOutline,
            lightPrimaryHex = lightPrimary,
            lightOnPrimaryHex = bestOnColor(lightPrimary),
            lightSecondaryHex = lightSec,
            lightOnSecondaryHex = bestOnColor(lightSec),
            lightBackgroundHex = lightBg,
            lightSurfaceHex = 0xFFFFFFFFL,
            lightTextHex = 0xFF0F172AL,
            lightSurfaceVariantHex = lightSurfaceVar,
            lightOutlineHex = 0xFF64748BL
        )
    }

    fun evaluateAccessibility(cfg: AppCustomThemeConfig, isDarkMode: Boolean): ThemeAccessibilityReport {
        val bg = if (isDarkMode) cfg.backgroundHex else cfg.lightBackgroundHex
        val surface = if (isDarkMode) cfg.surfaceHex else cfg.lightSurfaceHex
        val text = if (isDarkMode) cfg.textHex else cfg.lightTextHex
        val primaryBtn = if (isDarkMode) cfg.buttonHex else cfg.lightPrimaryHex
        val onPrimary = if (isDarkMode) cfg.onPrimaryHex else cfg.lightOnPrimaryHex

        val rTextBg = contrastRatio(text, bg)
        val rTextSurf = contrastRatio(text, surface)
        val rBtn = contrastRatio(onPrimary, primaryBtn)
        val minNormal = minOf(rTextBg, rTextSurf, rBtn)

        val level = when {
            minNormal >= 4.5 -> ThemeAccessibilityLevel.ACCESSIBLE
            minNormal >= 3.0 -> ThemeAccessibilityLevel.NEEDS_ADJUSTMENT
            else -> ThemeAccessibilityLevel.LOW_CONTRAST
        }
        val summary = when (level) {
            ThemeAccessibilityLevel.ACCESSIBLE -> "Meets WCAG AA (≥ 4.5:1) for text & buttons."
            ThemeAccessibilityLevel.NEEDS_ADJUSTMENT -> "Some text/button contrast is below 4.5:1 (${String.format("%.1f", minNormal)}:1)."
            ThemeAccessibilityLevel.LOW_CONTRAST -> "Low contrast (${String.format("%.1f", minNormal)}:1) — readability is impaired."
        }
        return ThemeAccessibilityReport(level, rTextBg, rTextSurf, rBtn, summary)
    }

    fun autoFixContrast(cfg: AppCustomThemeConfig, isDarkMode: Boolean): AppCustomThemeConfig {
        return if (isDarkMode) {
            val fixedText = bestOnColor(cfg.backgroundHex)
            val fixedOnPrimary = bestOnColor(cfg.buttonHex)
            val fixedSurface = if (contrastRatio(fixedText, cfg.surfaceHex) >= 4.5) cfg.surfaceHex else blendColor(cfg.backgroundHex, 0xFFFFFFFFL, 0.08f)
            cfg.copy(
                textHex = fixedText,
                onPrimaryHex = fixedOnPrimary,
                onSecondaryHex = bestOnColor(cfg.secondaryHex),
                surfaceHex = fixedSurface
            )
        } else {
            val fixedText = bestOnColor(cfg.lightBackgroundHex)
            val fixedOnPrimary = bestOnColor(cfg.lightPrimaryHex)
            cfg.copy(
                lightTextHex = fixedText,
                lightOnPrimaryHex = fixedOnPrimary,
                lightOnSecondaryHex = bestOnColor(cfg.lightSecondaryHex)
            )
        }
    }

    fun bestOnColor(bgHex: Long): Long {
        val whiteRatio = contrastRatio(0xFFFFFFFFL, bgHex)
        val darkRatio = contrastRatio(0xFF0A192FL, bgHex)
        return if (whiteRatio >= darkRatio) 0xFFF8FAFCL else 0xFF0A192FL
    }

    private fun blendColor(c1: Long, c2: Long, ratio: Float): Long {
        val r = ratio.coerceIn(0f, 1f)
        val a1 = Color(c1.toInt()); val a2 = Color(c2.toInt())
        val red = ((a1.red * (1f - r) + a2.red * r) * 255f).toInt().coerceIn(0, 255)
        val green = ((a1.green * (1f - r) + a2.green * r) * 255f).toInt().coerceIn(0, 255)
        val blue = ((a1.blue * (1f - r) + a2.blue * r) * 255f).toInt().coerceIn(0, 255)
        return (0xFFL shl 24) or (red.toLong() shl 16) or (green.toLong() shl 8) or blue.toLong()
    }

    fun parseHexColorOrNull(input: String): Long? {
        val cleaned = input.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
        return when (cleaned.length) {
            6 -> cleaned.toLongOrNull(16)?.let { 0xFF000000L or it }
            8 -> cleaned.toLongOrNull(16)
            else -> null
        }
    }

    fun formatHex(colorLong: Long): String {
        val rgb = colorLong and 0x00FFFFFFL
        return String.format("#%06X", rgb)
    }

    private fun relativeLuminance(color: Color): Double {
        fun channel(v: Float): Double {
            val d = v.toDouble()
            return if (d <= 0.03928) d / 12.92 else ((d + 0.055) / 1.055).pow(2.4)
        }
        return 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
    }

    fun contrastRatio(fgHex: Long, bgHex: Long): Double {
        val l1 = relativeLuminance(Color(fgHex.toInt()))
        val l2 = relativeLuminance(Color(bgHex.toInt()))
        val lighter = maxOf(l1, l2)
        val darker = minOf(l1, l2)
        return (lighter + 0.05) / (darker + 0.05)
    }

    fun lowContrastWarning(fgHex: Long, bgHex: Long, label: String = "Text"): String? {
        val ratio = contrastRatio(fgHex, bgHex)
        return if (ratio < 3.0) {
            "Low contrast (${String.format("%.1f", ratio)}:1) between $label and background — readability may be poor."
        } else null
    }

    fun safeQrForegroundInt(cardPrimaryHex: Long): Int {
        val ratioWithWhite = contrastRatio(cardPrimaryHex, 0xFFFFFFFFL)
        return if (ratioWithWhite >= 4.5) Color(cardPrimaryHex.toInt()).toArgb()
        else android.graphics.Color.parseColor("#0A192F")
    }
}
