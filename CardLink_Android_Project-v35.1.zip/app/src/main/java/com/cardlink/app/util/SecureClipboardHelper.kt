package com.cardlink.app.util

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.widget.Toast
import com.cardlink.app.R

object SecureClipboardHelper {
    private const val AUTO_CLEAR_DELAY_MS = 45_000L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingClearRunnable: Runnable? = null

    /**
     * Copies sensitive data (ID fields, loyalty numbers) with Android 13+ EXTRA_IS_SENSITIVE flag
     * and automatically clears the clipboard after 45 seconds if the same text is still present.
     */
    fun copySensitive(context: Context, label: String, text: String) {
        if (text.isBlank()) return
        val appCtx = context.applicationContext
        val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return

        val clip = ClipData.newPlainText(label, text).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                description.extras = PersistableBundle().apply {
                    putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
                }
            }
        }
        cm.setPrimaryClip(clip)

        Toast.makeText(
            context,
            context.getString(R.string.security_clipboard_copied_auto_clear),
            Toast.LENGTH_SHORT
        ).show()

        pendingClearRunnable?.let { mainHandler.removeCallbacks(it) }
        val clearTask = Runnable {
            runCatching {
                val currentText = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
                if (currentText == text) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        cm.clearPrimaryClip()
                    } else {
                        cm.setPrimaryClip(ClipData.newPlainText("", ""))
                    }
                }
            }
        }
        pendingClearRunnable = clearTask
        mainHandler.postDelayed(clearTask, AUTO_CLEAR_DELAY_MS)
    }
}
