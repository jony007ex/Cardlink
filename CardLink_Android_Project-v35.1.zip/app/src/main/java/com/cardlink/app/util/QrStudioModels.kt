package com.cardlink.app.util

import com.cardlink.app.data.model.BusinessCardEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

enum class QrTypeCategory {
    POPULAR,
    COMMUNICATION,
    BUSINESS,
    MEDIA_SOCIAL,
    ADVANCED
}

enum class QrContentType(
    val displayName: String,
    val category: QrTypeCategory,
    val isSensitive: Boolean = false
) {
    URL("Website / URL", QrTypeCategory.POPULAR),
    TEXT("Plain Text", QrTypeCategory.POPULAR),
    VCARD("vCard / Contact", QrTypeCategory.POPULAR, isSensitive = true),
    WIFI("Wi-Fi", QrTypeCategory.POPULAR, isSensitive = true),
    WHATSAPP("WhatsApp", QrTypeCategory.POPULAR),
    LOCATION("Location", QrTypeCategory.POPULAR),

    EMAIL("Email", QrTypeCategory.COMMUNICATION),
    PHONE("Phone", QrTypeCategory.COMMUNICATION),
    SMS("SMS", QrTypeCategory.COMMUNICATION),

    EVENT("Event", QrTypeCategory.BUSINESS),
    PAYMENT("Payment Link", QrTypeCategory.BUSINESS, isSensitive = true),
    GOOGLE_MAPS("Google Maps", QrTypeCategory.BUSINESS),

    YOUTUBE("YouTube", QrTypeCategory.MEDIA_SOCIAL),
    SOCIAL("Social Profile", QrTypeCategory.MEDIA_SOCIAL),

    CRYPTO("Cryptocurrency", QrTypeCategory.ADVANCED, isSensitive = true),
    FILE_LINK("File Link", QrTypeCategory.ADVANCED),
    CUSTOM("Custom Data", QrTypeCategory.ADVANCED)
}

enum class QrBodyStyle(val label: String) {
    SQUARE("Square"),
    ROUNDED("Rounded"),
    DOTS("Dots"),
    SOFT_SQUARES("Soft Squares"),
    DIAMOND("Diamond"),
    CLASSY("Classy"),
    EXTRA_ROUNDED("Extra Rounded"),
    CONNECTED("Connected"),
    MODERN_PIXEL("Modern Pixel")
}

enum class QrEyeFrameStyle(val label: String) {
    SQUARE("Square"),
    ROUNDED_SQUARE("Rounded Square"),
    CIRCLE("Circle"),
    SOFT_CORNER("Soft Corner"),
    MODERN_BORDER("Modern Border")
}

enum class QrEyeCenterStyle(val label: String) {
    SQUARE("Square"),
    CIRCLE("Circle"),
    ROUNDED("Rounded"),
    DIAMOND("Diamond"),
    SOFT_SQUARE("Soft Square")
}

enum class QrEcLevel(val label: String) {
    LOW("Low (7%)"),
    MEDIUM("Medium (15%)"),
    QUARTILE("Quartile (25%)"),
    HIGH("High (30%)")
}

enum class QrLogoSource {
    NONE,
    CARDLINK_ICON,
    MY_CARD_LOGO,
    CUSTOM_IMAGE
}

enum class QrExportFormat(val label: String, val ext: String, val mime: String) {
    PNG("PNG", "png", "image/png"),
    JPG("JPG", "jpg", "image/jpeg"),
    SVG("SVG", "svg", "image/svg+xml"),
    PDF("PDF", "pdf", "application/pdf")
}

@Serializable
data class QrDesignConfig(
    val foregroundHex: String = "#0A192F",
    val useGradient: Boolean = false,
    val gradientEndHex: String = "#1D4ED8",
    val backgroundHex: String = "#FFFFFF",
    val transparentBackground: Boolean = false,
    val bodyStyle: String = QrBodyStyle.SQUARE.name,
    val eyeFrameStyle: String = QrEyeFrameStyle.ROUNDED_SQUARE.name,
    val eyeCenterStyle: String = QrEyeCenterStyle.SQUARE.name,
    val errorCorrection: String = QrEcLevel.MEDIUM.name,
    val quietZoneModules: Int = 4,
    val logoSource: String = QrLogoSource.NONE.name,
    val logoSizePercent: Int = 18,
    val logoSolidBackground: Boolean = true,
    val logoRoundedCorners: Boolean = true,
    val logoPaddingDp: Int = 6,
    val frameEnabled: Boolean = false,
    val frameLabel: String = "Scan Me"
) {
    fun resolvedBodyStyle(): QrBodyStyle =
        runCatching { QrBodyStyle.valueOf(bodyStyle) }.getOrDefault(QrBodyStyle.SQUARE)

    fun resolvedEyeFrameStyle(): QrEyeFrameStyle =
        runCatching { QrEyeFrameStyle.valueOf(eyeFrameStyle) }.getOrDefault(QrEyeFrameStyle.ROUNDED_SQUARE)

    fun resolvedEyeCenterStyle(): QrEyeCenterStyle =
        runCatching { QrEyeCenterStyle.valueOf(eyeCenterStyle) }.getOrDefault(QrEyeCenterStyle.SQUARE)

    fun resolvedEcLevel(): QrEcLevel =
        runCatching { QrEcLevel.valueOf(errorCorrection) }.getOrDefault(QrEcLevel.MEDIUM)

    fun resolvedLogoSource(): QrLogoSource =
        runCatching { QrLogoSource.valueOf(logoSource) }.getOrDefault(QrLogoSource.NONE)
}

data class QrPalettePreset(
    val name: String,
    val fgHex: String,
    val bgHex: String,
    val useGradient: Boolean = false,
    val gradEndHex: String = "#0A192F"
)

data class QrBuiltInDesignPreset(
    val name: String,
    val config: QrDesignConfig
)

data class QrPayloadBuildResult(
    val payload: String,
    val isValid: Boolean,
    val validationMessage: String = "",
    val warningMessage: String = "",
    val previewSummaryLines: List<Pair<String, String>> = emptyList(),
    val suggestedHttpsFix: String? = null
)

object QrStudioPresets {
    val colorPalettes = listOf(
        QrPalettePreset("Classic Black & White", "#000000", "#FFFFFF"),
        QrPalettePreset("CardLink Navy & Gold", "#0A192F", "#FFFFFF", useGradient = true, gradEndHex = "#1E3A5F"),
        QrPalettePreset("Midnight Blue", "#0F172A", "#F8FAFC"),
        QrPalettePreset("Emerald", "#065F46", "#FFFFFF"),
        QrPalettePreset("Purple", "#4C1D95", "#FFFFFF"),
        QrPalettePreset("Corporate Blue", "#1D4ED8", "#FFFFFF")
    )

    val builtInDesigns = listOf(
        QrBuiltInDesignPreset(
            "Classic",
            QrDesignConfig(foregroundHex = "#000000", backgroundHex = "#FFFFFF", bodyStyle = QrBodyStyle.SQUARE.name, eyeFrameStyle = QrEyeFrameStyle.SQUARE.name, eyeCenterStyle = QrEyeCenterStyle.SQUARE.name)
        ),
        QrBuiltInDesignPreset(
            "CardLink Gold",
            QrDesignConfig(foregroundHex = "#0A192F", useGradient = true, gradientEndHex = "#1E3A5F", backgroundHex = "#FFFFFF", bodyStyle = QrBodyStyle.ROUNDED.name, eyeFrameStyle = QrEyeFrameStyle.ROUNDED_SQUARE.name, eyeCenterStyle = QrEyeCenterStyle.ROUNDED.name, frameEnabled = true, frameLabel = "Scan Me")
        ),
        QrBuiltInDesignPreset(
            "Professional Navy",
            QrDesignConfig(foregroundHex = "#0A192F", backgroundHex = "#F8FAFC", bodyStyle = QrBodyStyle.SOFT_SQUARES.name, eyeFrameStyle = QrEyeFrameStyle.MODERN_BORDER.name, eyeCenterStyle = QrEyeCenterStyle.SOFT_SQUARE.name)
        ),
        QrBuiltInDesignPreset(
            "Minimal",
            QrDesignConfig(foregroundHex = "#111827", backgroundHex = "#FFFFFF", bodyStyle = QrBodyStyle.DOTS.name, eyeFrameStyle = QrEyeFrameStyle.CIRCLE.name, eyeCenterStyle = QrEyeCenterStyle.CIRCLE.name)
        ),
        QrBuiltInDesignPreset(
            "Rounded",
            QrDesignConfig(foregroundHex = "#1E3A8A", backgroundHex = "#FFFFFF", bodyStyle = QrBodyStyle.EXTRA_ROUNDED.name, eyeFrameStyle = QrEyeFrameStyle.SOFT_CORNER.name, eyeCenterStyle = QrEyeCenterStyle.ROUNDED.name)
        ),
        QrBuiltInDesignPreset(
            "High Contrast",
            QrDesignConfig(foregroundHex = "#000000", backgroundHex = "#FFFFFF", bodyStyle = QrBodyStyle.SQUARE.name, eyeFrameStyle = QrEyeFrameStyle.SQUARE.name, eyeCenterStyle = QrEyeCenterStyle.SQUARE.name, errorCorrection = QrEcLevel.HIGH.name, quietZoneModules = 5)
        )
    )

    val socialPlatforms = listOf(
        "LinkedIn" to "https://www.linkedin.com/in/",
        "Facebook" to "https://www.facebook.com/",
        "Instagram" to "https://www.instagram.com/",
        "X / Twitter" to "https://x.com/",
        "TikTok" to "https://www.tiktok.com/@",
        "GitHub" to "https://github.com/",
        "Other" to ""
    )

    val cryptoNetworks = listOf(
        "Bitcoin (BTC)" to "bitcoin",
        "Ethereum (ETH)" to "ethereum",
        "Solana (SOL)" to "solana",
        "Litecoin (LTC)" to "litecoin",
        "USDT (ERC-20)" to "ethereum"
    )
}

object QrPayloadBuilder {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val EMAIL_REGEX = Regex("""^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$""")

    fun serializeFields(fields: Map<String, String>): String =
        runCatching { json.encodeToString(fields) }.getOrDefault("{}")

    fun deserializeFields(raw: String): Map<String, String> =
        runCatching { json.decodeFromString<Map<String, String>>(raw) }.getOrDefault(emptyMap())

    fun serializeDesign(config: QrDesignConfig): String =
        runCatching { json.encodeToString(config) }.getOrDefault("{}")

    fun deserializeDesign(raw: String): QrDesignConfig =
        runCatching { json.decodeFromString<QrDesignConfig>(raw) }.getOrDefault(QrDesignConfig())

    fun fieldsFromMyCard(card: BusinessCardEntity): Map<String, String> {
        val parts = card.fullName.trim().split(Regex("\\s+"))
        val first = parts.firstOrNull().orEmpty()
        val last = if (parts.size > 1) parts.drop(1).joinToString(" ") else ""
        return mapOf(
            "vcardVersion" to "3.0",
            "firstName" to first,
            "lastName" to last,
            "displayName" to card.fullName.trim(),
            "org" to card.companyName.trim(),
            "title" to card.designation.trim(),
            "mobilePhone" to if (card.sharePhone) card.phone.trim() else "",
            "workPhone" to "",
            "personalPhone" to "",
            "email" to if (card.shareEmail) card.email.trim() else "",
            "website" to card.website.trim(),
            "street" to if (card.shareAddress) card.officeAddress.trim() else "",
            "city" to "",
            "state" to "",
            "postalCode" to "",
            "country" to "",
            "notes" to ""
        )
    }

    fun build(type: QrContentType, fields: Map<String, String>): QrPayloadBuildResult {
        fun f(k: String) = fields[k].orEmpty().trim()

        return when (type) {
            QrContentType.URL -> {
                val rawUrl = f("url")
                if (rawUrl.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter a website URL to preview your QR code.")
                } else if (!rawUrl.startsWith("http://", true) && !rawUrl.startsWith("https://", true)) {
                    val looksLikeDomain = rawUrl.contains(".") && !rawUrl.contains(" ")
                    if (looksLikeDomain) {
                        QrPayloadBuildResult(
                            payload = "",
                            isValid = false,
                            validationMessage = "URL should start with https:// or http://.",
                            suggestedHttpsFix = "https://$rawUrl"
                        )
                    } else {
                        QrPayloadBuildResult("", false, "Enter a valid URL (e.g. https://example.com).")
                    }
                } else {
                    val parsedOk = runCatching { java.net.URI(rawUrl).host != null }.getOrDefault(false)
                    if (!parsedOk) {
                        QrPayloadBuildResult("", false, "Enter a valid website address.")
                    } else {
                        QrPayloadBuildResult(
                            payload = rawUrl,
                            isValid = true,
                            previewSummaryLines = listOf("Type" to "Website", "Destination" to rawUrl)
                        )
                    }
                }
            }

            QrContentType.TEXT -> {
                val txt = fields["text"].orEmpty()
                if (txt.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter text content to generate your QR code.")
                } else {
                    val warn = if (txt.length > 600) "Long text creates a very dense QR code that may be harder to scan." else ""
                    QrPayloadBuildResult(
                        payload = txt,
                        isValid = true,
                        warningMessage = warn,
                        previewSummaryLines = listOf("Type" to "Plain Text", "Length" to "${txt.length} characters")
                    )
                }
            }

            QrContentType.VCARD -> {
                val ver = f("vcardVersion").ifBlank { "3.0" }
                val first = f("firstName")
                val last = f("lastName")
                val display = f("displayName").ifBlank { listOf(first, last).filter { it.isNotBlank() }.joinToString(" ") }
                val org = f("org")
                val title = f("title")
                val mobile = f("mobilePhone")
                val work = f("workPhone")
                val personal = f("personalPhone")
                val email = f("email")
                val website = f("website")
                val street = f("street")
                val city = f("city")
                val state = f("state")
                val postal = f("postalCode")
                val country = f("country")
                val notes = f("notes")

                if (display.isBlank() && org.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter at least a Name or Organization.")
                } else {
                    val vcard = buildString {
                        appendLine("BEGIN:VCARD")
                        appendLine("VERSION:$ver")
                        appendLine("N:${escapeVCard(last)};${escapeVCard(first)};;;")
                        appendLine("FN:${escapeVCard(display.ifBlank { org })}")
                        if (org.isNotBlank()) appendLine("ORG:${escapeVCard(org)}")
                        if (title.isNotBlank()) appendLine("TITLE:${escapeVCard(title)}")
                        if (mobile.isNotBlank()) appendLine(if (ver == "4.0") "TEL;TYPE=cell:$mobile" else "TEL;TYPE=CELL:$mobile")
                        if (work.isNotBlank()) appendLine(if (ver == "4.0") "TEL;TYPE=work:$work" else "TEL;TYPE=WORK,VOICE:$work")
                        if (personal.isNotBlank()) appendLine(if (ver == "4.0") "TEL;TYPE=home:$personal" else "TEL;TYPE=HOME,VOICE:$personal")
                        if (email.isNotBlank()) appendLine("EMAIL:$email")
                        if (website.isNotBlank()) appendLine("URL:$website")
                        if (listOf(street, city, state, postal, country).any { it.isNotBlank() }) {
                            appendLine("ADR;TYPE=WORK:;;${escapeVCard(street)};${escapeVCard(city)};${escapeVCard(state)};${escapeVCard(postal)};${escapeVCard(country)}")
                        }
                        if (notes.isNotBlank()) appendLine("NOTE:${escapeVCard(notes)}")
                        append("END:VCARD")
                    }
                    val warn = if (vcard.length > 750) "Large vCard creates a dense QR code. Consider keeping fields concise." else ""
                    val lines = buildList {
                        add("Type" to "vCard $ver")
                        if (display.isNotBlank()) add("Name" to display)
                        if (org.isNotBlank()) add("Organization" to org)
                        if (mobile.isNotBlank()) add("Mobile" to mobile)
                    }
                    QrPayloadBuildResult(vcard, true, warningMessage = warn, previewSummaryLines = lines)
                }
            }

            QrContentType.EMAIL -> {
                val to = f("email")
                val subject = f("subject")
                val body = f("body")
                if (to.isBlank() || !EMAIL_REGEX.matches(to)) {
                    QrPayloadBuildResult("", false, "Enter a valid recipient email address.")
                } else {
                    val params = mutableListOf<String>()
                    if (subject.isNotBlank()) params.add("subject=${urlEnc(subject)}")
                    if (body.isNotBlank()) params.add("body=${urlEnc(body)}")
                    val uri = if (params.isEmpty()) "mailto:$to" else "mailto:$to?${params.joinToString("&")}"
                    QrPayloadBuildResult(
                        payload = uri,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "Email", "Recipient" to to, "Subject" to subject.ifBlank { "—" })
                    )
                }
            }

            QrContentType.PHONE -> {
                val rawPhone = f("phone")
                val normalized = normalizePhoneKeepPlus(rawPhone)
                if (normalized.filter { it.isDigit() }.length < 4) {
                    QrPayloadBuildResult("", false, "Enter a valid phone number.")
                } else {
                    QrPayloadBuildResult(
                        payload = "tel:$normalized",
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "Phone", "Number" to normalized)
                    )
                }
            }

            QrContentType.SMS -> {
                val rawPhone = f("phone")
                val normalized = normalizePhoneKeepPlus(rawPhone)
                val msg = f("message")
                if (normalized.filter { it.isDigit() }.length < 4) {
                    QrPayloadBuildResult("", false, "Enter a valid phone number for SMS.")
                } else {
                    val payload = if (msg.isBlank()) "SMSTO:$normalized:" else "SMSTO:$normalized:$msg"
                    QrPayloadBuildResult(
                        payload = payload,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "SMS", "Number" to normalized)
                    )
                }
            }

            QrContentType.WHATSAPP -> {
                val rawPhone = f("phone")
                val digitsOnly = rawPhone.filter { it.isDigit() }
                val msg = f("message")
                if (digitsOnly.length < 7) {
                    QrPayloadBuildResult("", false, "Enter a phone number with country code (e.g. 8801700000000).")
                } else {
                    val url = if (msg.isBlank()) "https://wa.me/$digitsOnly"
                    else "https://wa.me/$digitsOnly?text=${urlEnc(msg)}"
                    QrPayloadBuildResult(
                        payload = url,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "WhatsApp", "Destination" to url)
                    )
                }
            }

            QrContentType.WIFI -> {
                val ssid = f("ssid")
                val password = fields["password"].orEmpty()
                val security = f("security").ifBlank { "WPA" } // WPA, WEP, nopass
                val hidden = f("hidden").equals("true", true)
                if (ssid.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter the Wi-Fi Network Name (SSID).")
                } else if (security != "nopass" && password.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter the Wi-Fi password or select No Password.")
                } else {
                    val secCode = when (security) {
                        "WEP" -> "WEP"
                        "nopass" -> "nopass"
                        else -> "WPA"
                    }
                    val escSsid = escapeWifiField(ssid)
                    val escPass = if (secCode == "nopass") "" else escapeWifiField(password)
                    val hiddenPart = if (hidden) "H:true;" else ""
                    val payload = "WIFI:T:$secCode;S:$escSsid;P:$escPass;$hiddenPart;"
                    QrPayloadBuildResult(
                        payload = payload,
                        isValid = true,
                        previewSummaryLines = listOf(
                            "Type" to "Wi-Fi",
                            "Network" to ssid,
                            "Security" to if (secCode == "nopass") "Open (No Password)" else secCode,
                            "Password" to if (secCode == "nopass") "None" else "••••••••"
                        )
                    )
                }
            }

            QrContentType.LOCATION -> {
                val latStr = f("latitude")
                val lngStr = f("longitude")
                val place = f("placeTitle")
                val lat = latStr.toDoubleOrNull()
                val lng = lngStr.toDoubleOrNull()
                if (lat == null || lng == null || lat !in -90.0..90.0 || lng !in -180.0..180.0) {
                    QrPayloadBuildResult("", false, "Enter valid Latitude (-90 to 90) and Longitude (-180 to 180).")
                } else {
                    val qPart = if (place.isNotBlank()) "?q=$lat,$lng(${urlEnc(place)})" else ""
                    val payload = "geo:$lat,$lng$qPart"
                    QrPayloadBuildResult(
                        payload = payload,
                        isValid = true,
                        previewSummaryLines = listOf(
                            "Type" to "Location",
                            "Coordinates" to "$lat, $lng",
                            "Place" to place.ifBlank { "—" }
                        )
                    )
                }
            }

            QrContentType.EVENT -> {
                val title = f("eventTitle")
                val loc = f("eventLocation")
                val startDate = f("startDate") // yyyy-MM-dd
                val startTime = f("startTime").ifBlank { "09:00" } // HH:mm
                val endDate = f("endDate").ifBlank { startDate }
                val endTime = f("endTime").ifBlank { "10:00" }
                val desc = f("description")
                val organizer = f("organizer")
                val website = f("website")
                val tz = f("timeZone").ifBlank { ZoneId.systemDefault().id }
                val allDay = f("allDay").equals("true", true)

                if (title.isBlank() || startDate.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter an Event Title and Start Date.")
                } else {
                    val parsedStart = runCatching {
                        if (allDay) LocalDate.parse(startDate).atStartOfDay()
                        else LocalDateTime.parse("${startDate}T$startTime")
                    }.getOrNull()
                    val parsedEnd = runCatching {
                        if (allDay) LocalDate.parse(endDate).atStartOfDay()
                        else LocalDateTime.parse("${endDate}T$endTime")
                    }.getOrNull()

                    if (parsedStart == null || parsedEnd == null) {
                        QrPayloadBuildResult("", false, "Use valid YYYY-MM-DD date and HH:MM time values.")
                    } else if (parsedEnd.isBefore(parsedStart)) {
                        QrPayloadBuildResult("", false, "End date/time cannot be earlier than Start date/time.")
                    } else {
                        val dtStartLine = if (allDay) {
                            "DTSTART;VALUE=DATE:${parsedStart.toLocalDate().format(DateTimeFormatter.BASIC_ISO_DATE)}"
                        } else {
                            "DTSTART;TZID=$tz:${parsedStart.format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"))}"
                        }
                        val dtEndLine = if (allDay) {
                            val exclusiveEnd = parsedEnd.toLocalDate().plusDays(1)
                            "DTEND;VALUE=DATE:${exclusiveEnd.format(DateTimeFormatter.BASIC_ISO_DATE)}"
                        } else {
                            "DTEND;TZID=$tz:${parsedEnd.format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"))}"
                        }
                        val ics = buildString {
                            appendLine("BEGIN:VEVENT")
                            appendLine("SUMMARY:${escapeIcs(title)}")
                            appendLine(dtStartLine)
                            appendLine(dtEndLine)
                            if (loc.isNotBlank()) appendLine("LOCATION:${escapeIcs(loc)}")
                            if (desc.isNotBlank()) appendLine("DESCRIPTION:${escapeIcs(desc)}")
                            if (organizer.isNotBlank()) appendLine("ORGANIZER:${escapeIcs(organizer)}")
                            if (website.isNotBlank()) appendLine("URL:$website")
                            append("END:VEVENT")
                        }
                        QrPayloadBuildResult(
                            payload = ics,
                            isValid = true,
                            previewSummaryLines = listOf(
                                "Type" to "Calendar Event",
                                "Event" to title,
                                "Start" to if (allDay) "$startDate (All Day)" else "$startDate $startTime ($tz)"
                            )
                        )
                    }
                }
            }

            QrContentType.GOOGLE_MAPS -> {
                val url = f("mapsUrl")
                val title = f("locationTitle")
                if (url.isBlank() || (!url.startsWith("http://", true) && !url.startsWith("https://", true))) {
                    QrPayloadBuildResult("", false, "Paste a valid Google Maps link starting with https://.")
                } else {
                    QrPayloadBuildResult(
                        payload = url,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "Google Maps", "Place" to title.ifBlank { "Map Link" }, "Destination" to url)
                    )
                }
            }

            QrContentType.YOUTUBE -> {
                val url = f("youtubeUrl")
                val validYt = url.startsWith("https://", true) && (
                    url.contains("youtube.com", true) || url.contains("youtu.be", true)
                )
                if (!validYt) {
                    QrPayloadBuildResult("", false, "Enter a valid YouTube video, channel, playlist, or Shorts URL.")
                } else {
                    QrPayloadBuildResult(
                        payload = url,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "YouTube", "Destination" to url)
                    )
                }
            }

            QrContentType.SOCIAL -> {
                val platform = f("platform").ifBlank { "LinkedIn" }
                val handleOrUrl = f("handleOrUrl")
                if (handleOrUrl.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter your $platform profile link or username.")
                } else {
                    val finalUrl = if (handleOrUrl.startsWith("http://", true) || handleOrUrl.startsWith("https://", true)) {
                        handleOrUrl
                    } else {
                        val prefix = QrStudioPresets.socialPlatforms.firstOrNull { it.first == platform }?.second.orEmpty()
                        if (prefix.isNotBlank()) prefix + handleOrUrl.trimStart('@', '/') else "https://$handleOrUrl"
                    }
                    QrPayloadBuildResult(
                        payload = finalUrl,
                        isValid = true,
                        previewSummaryLines = listOf("Type" to "Social ($platform)", "Destination" to finalUrl)
                    )
                }
            }

            QrContentType.PAYMENT -> {
                val uri = f("paymentUri")
                if (uri.isBlank() || !uri.contains(":")) {
                    QrPayloadBuildResult("", false, "Enter a valid payment URL (https://...) or supported payment URI.")
                } else {
                    QrPayloadBuildResult(
                        payload = uri,
                        isValid = true,
                        warningMessage = "Verify the payment destination carefully. Displaying a QR code does not verify the merchant.",
                        previewSummaryLines = listOf("Type" to "Payment Link", "Destination" to uri)
                    )
                }
            }

            QrContentType.CRYPTO -> {
                val network = f("network").ifBlank { "Bitcoin (BTC)" }
                val address = f("address") // Never silently modify wallet address!
                val amount = f("amount")
                val note = f("note")
                if (address.length < 16 || address.contains(" ")) {
                    QrPayloadBuildResult("", false, "Enter a valid $network wallet address.")
                } else {
                    val scheme = QrStudioPresets.cryptoNetworks.firstOrNull { it.first == network }?.second ?: "bitcoin"
                    val params = mutableListOf<String>()
                    if (amount.isNotBlank()) params.add("amount=$amount")
                    if (note.isNotBlank()) params.add("message=${urlEnc(note)}")
                    val payload = if (params.isEmpty()) "$scheme:$address" else "$scheme:$address?${params.joinToString("&")}"
                    QrPayloadBuildResult(
                        payload = payload,
                        isValid = true,
                        warningMessage = "Always double-check the exact wallet address and network ($network) before sharing.",
                        previewSummaryLines = listOf("Network" to network, "Address" to "${address.take(8)}…${address.takeLast(6)}")
                    )
                }
            }

            QrContentType.FILE_LINK -> {
                val url = f("fileUrl")
                if (url.isBlank() || (!url.startsWith("http://", true) && !url.startsWith("https://", true))) {
                    QrPayloadBuildResult("", false, "Enter a valid shared/downloadable URL (https://...). Local device files are not uploaded.")
                } else {
                    QrPayloadBuildResult(
                        payload = url,
                        isValid = true,
                        warningMessage = "Recipients must have access permission to open the linked file URL.",
                        previewSummaryLines = listOf("Type" to "File Link", "Destination" to url)
                    )
                }
            }

            QrContentType.CUSTOM -> {
                val raw = fields["rawData"].orEmpty()
                if (raw.isBlank()) {
                    QrPayloadBuildResult("", false, "Enter custom QR payload text.")
                } else {
                    QrPayloadBuildResult(
                        payload = raw,
                        isValid = true,
                        warningMessage = "Custom raw data is encoded verbatim and may not be recognized by all scanner apps.",
                        previewSummaryLines = listOf("Type" to "Custom Data", "Length" to "${raw.length} characters")
                    )
                }
            }
        }
    }

    private fun escapeWifiField(v: String): String =
        v.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:")

    private fun escapeVCard(v: String): String =
        v.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

    private fun escapeIcs(v: String): String =
        v.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

    private fun normalizePhoneKeepPlus(raw: String): String {
        val trimmed = raw.trim()
        val hasPlus = trimmed.startsWith("+")
        val digits = trimmed.filter { it.isDigit() }
        return if (hasPlus) "+$digits" else digits
    }

    private fun urlEnc(s: String): String =
        runCatching { URLEncoder.encode(s, "UTF-8").replace("+", "%20") }.getOrDefault(s)
}
