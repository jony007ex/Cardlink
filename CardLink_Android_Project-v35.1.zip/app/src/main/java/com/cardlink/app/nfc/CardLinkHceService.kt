package com.cardlink.app.nfc

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import java.nio.charset.StandardCharsets

enum class NfcShareMode {
    VCARD, LINK
}

/**
 * Full NFC Forum Type 4 Tag NDEF Emulation over Host Card Emulation (HCE).
 * Supports both:
 *  - VCARD mode (Default): Emulates a standard "text/x-vcard" NDEF MIME record so
 *    receiving Android phones automatically open the Contact Import / Save dialog.
 *  - LINK mode: Emulates an NDEF URI record so any Android or iPhone opens the URL.
 */
class CardLinkHceService : HostApduService() {

    companion object {
        @Volatile
        var shareMode: NfcShareMode = NfcShareMode.VCARD

        @Volatile
        var activeShareUrl: String = "https://cardlink.app"

        @Volatile
        var activeVCardPayload: String = "BEGIN:VCARD\nVERSION:3.0\nFN:CardLink User\nEND:VCARD"

        val SELECT_CARDLINK_AID = byteArrayOf(
            0x00, 0xA4.toByte(), 0x04, 0x00, 0x08,
            0xF0.toByte(), 0x43, 0x41, 0x52, 0x44, 0x4C, 0x49, 0x4E, 0x4B
        )

        // Standard 15-byte Capability Container (CC) for NFC Forum Type 4 Tag (Read-Only, 4095 bytes max)
        private val CC_FILE = byteArrayOf(
            0x00, 0x0F,       // CCLEN = 15 bytes
            0x20,             // Mapping Version 2.0
            0x00, 0x3B,       // MLe = 59 bytes (safe max R-APDU data per chunk)
            0x00, 0x34,       // MLc = 52 bytes
            0x04, 0x06,       // NDEF File Control TLV (T=04, L=06)
            0xE1.toByte(), 0x04, // NDEF File ID = E104
            0x0F, 0xFF.toByte(), // Max NDEF size = 4095 bytes (fits full vCard)
            0x00,             // Read access: granted without security
            0xFF.toByte()     // Write access: read-only
        )

        private val SW_OK = byteArrayOf(0x90.toByte(), 0x00.toByte())
        private val SW_NOT_FOUND = byteArrayOf(0x6A.toByte(), 0x82.toByte())
    }

    private var selectedFile: Int = 0 // 1 = CC, 2 = NDEF
    private var cachedNdefFileBytes: ByteArray? = null

    private fun buildNdefFileBytes(): ByteArray {
        val record = when (shareMode) {
            NfcShareMode.VCARD -> {
                val cleanVcf = activeVCardPayload.trim()
                NdefRecord.createMime(
                    "text/x-vcard",
                    cleanVcf.toByteArray(StandardCharsets.UTF_8)
                )
            }
            NfcShareMode.LINK -> {
                NdefRecord.createUri(activeShareUrl.trim().ifBlank { "https://cardlink.app" })
            }
        }
        val ndefMessage = NdefMessage(arrayOf(record))
        val msgBytes = ndefMessage.toByteArray()
        val len = msgBytes.size
        // Type 4 NDEF file starts with 2-byte big-endian NLEN
        return byteArrayOf(((len shr 8) and 0xFF).toByte(), (len and 0xFF).toByte()) + msgBytes
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null || commandApdu.size < 4) return SW_NOT_FOUND

        // 1. Direct CardLink-to-CardLink vCard Exchange
        if (commandApdu.contentEquals(SELECT_CARDLINK_AID)) {
            return activeVCardPayload.toByteArray(StandardCharsets.UTF_8) + SW_OK
        }

        // 2. SELECT NDEF Tag Application (D2760000850101)
        if (commandApdu.size >= 12 &&
            commandApdu[0] == 0x00.toByte() &&
            commandApdu[1] == 0xA4.toByte() &&
            commandApdu[2] == 0x04.toByte()
        ) {
            selectedFile = 0
            cachedNdefFileBytes = null
            return SW_OK
        }

        // 3. SELECT File by ID (handles both 7-byte and 8-byte APDUs with trailing Le)
        if (commandApdu.size >= 7 &&
            commandApdu[0] == 0x00.toByte() &&
            commandApdu[1] == 0xA4.toByte() &&
            commandApdu[2] == 0x00.toByte() &&
            commandApdu[4] == 0x02.toByte() &&
            commandApdu[5] == 0xE1.toByte()
        ) {
            when (commandApdu[6]) {
                0x03.toByte() -> {
                    selectedFile = 1
                    return SW_OK
                }
                0x04.toByte() -> {
                    selectedFile = 2
                    cachedNdefFileBytes = buildNdefFileBytes()
                    return SW_OK
                }
            }
        }

        // 4. READ BINARY (00 B0 P1 P2 Le)
        if (commandApdu[0] == 0x00.toByte() && commandApdu[1] == 0xB0.toByte() && commandApdu.size >= 5) {
            val offset = ((commandApdu[2].toInt() and 0xFF) shl 8) or (commandApdu[3].toInt() and 0xFF)
            val rawLen = commandApdu[4].toInt() and 0xFF
            val length = if (rawLen == 0) 256 else rawLen
            val source = when (selectedFile) {
                1 -> CC_FILE
                2 -> cachedNdefFileBytes ?: buildNdefFileBytes().also { cachedNdefFileBytes = it }
                else -> return SW_NOT_FOUND
            }
            if (offset >= source.size) return SW_OK
            val end = (offset + length).coerceAtMost(source.size)
            return source.copyOfRange(offset, end) + SW_OK
        }

        return SW_NOT_FOUND
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = 0
        cachedNdefFileBytes = null
    }
}
