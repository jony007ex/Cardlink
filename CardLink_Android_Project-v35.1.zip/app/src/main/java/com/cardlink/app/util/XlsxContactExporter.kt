package com.cardlink.app.util

import android.content.Context
import android.net.Uri
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class ContactExportField(val header: String) {
    NAME("Name"),
    COMPANY("Company"),
    DESIGNATION("Designation"),
    PHONE("Phone"),
    EMAIL("Email"),
    ADDRESS("Address"),
    NOTES("Notes"),
    TAGS("Tags"),
    CREATED_DATE("Created Date")
}

object XlsxContactExporter {

    private fun extractValue(c: SavedContactEntity, field: ContactExportField, dateFmt: SimpleDateFormat): String =
        when (field) {
            ContactExportField.NAME -> c.fullName
            ContactExportField.COMPANY -> c.companyName
            ContactExportField.DESIGNATION -> c.designation
            ContactExportField.PHONE -> c.phone.ifBlank { c.whatsapp }
            ContactExportField.EMAIL -> c.email
            ContactExportField.ADDRESS -> c.officeAddress
            ContactExportField.NOTES -> c.notes
            ContactExportField.TAGS -> c.categoryTag
            ContactExportField.CREATED_DATE -> dateFmt.format(Date(c.savedAtTimestamp))
        }

    suspend fun exportCsv(
        context: Context,
        destinationUri: Uri,
        contacts: List<SavedContactEntity>,
        fields: List<ContactExportField>
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val activeFields = fields.ifEmpty { ContactExportField.values().toList() }
            val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            fun esc(v: String): String = "\"${v.replace("\"", "\"\"").replace("\n", " ")}\""
            val csv = buildString {
                appendLine(activeFields.joinToString(",") { esc(it.header) })
                contacts.forEach { c ->
                    appendLine(activeFields.joinToString(",") { esc(extractValue(c, it, dateFmt)) })
                }
            }
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                out.write(csv.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: error("Could not open CSV output stream.")
            contacts.size
        }
    }

    /**
     * Generates a valid standards-compliant OOXML Excel Workbook (.xlsx) without heavy external libraries.
     */
    suspend fun exportXlsx(
        context: Context,
        destinationUri: Uri,
        contacts: List<SavedContactEntity>,
        fields: List<ContactExportField>
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val activeFields = fields.ifEmpty { ContactExportField.values().toList() }
            val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

            fun xmlEsc(s: String): String = s
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;")
                .replace("\r", " ")
                .replace("\n", " ")

            fun colLetter(idx0: Int): String {
                var n = idx0 + 1
                val sb = StringBuilder()
                while (n > 0) {
                    val rem = (n - 1) % 26
                    sb.insert(0, ('A'.code + rem).toChar())
                    n = (n - 1) / 26
                }
                return sb.toString()
            }

            val sheetXml = buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
                append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
                // Header row (row 1)
                append("""<row r="1">""")
                activeFields.forEachIndexed { cIdx, f ->
                    val ref = "${colLetter(cIdx)}1"
                    append("""<c r="$ref" t="inlineStr"><is><t>${xmlEsc(f.header)}</t></is></c>""")
                }
                append("</row>")
                // Data rows
                contacts.forEachIndexed { rIdx, contact ->
                    val rowNum = rIdx + 2
                    append("""<row r="$rowNum">""")
                    activeFields.forEachIndexed { cIdx, f ->
                        val ref = "${colLetter(cIdx)}$rowNum"
                        val v = xmlEsc(extractValue(contact, f, dateFmt))
                        append("""<c r="$ref" t="inlineStr"><is><t>$v</t></is></c>""")
                    }
                    append("</row>")
                }
                append("</sheetData></worksheet>")
            }

            val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>"""

            val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

            val workbookXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="CardLink Contacts" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""

            val wbRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>"""

            context.contentResolver.openOutputStream(destinationUri)?.use { rawOut ->
                ZipOutputStream(rawOut).use { zos ->
                    fun putText(path: String, text: String) {
                        zos.putNextEntry(ZipEntry(path))
                        zos.write(text.toByteArray(Charsets.UTF_8))
                        zos.closeEntry()
                    }
                    putText("[Content_Types].xml", contentTypes)
                    putText("_rels/.rels", rootRels)
                    putText("xl/workbook.xml", workbookXml)
                    putText("xl/_rels/workbook.xml.rels", wbRels)
                    putText("xl/worksheets/sheet1.xml", sheetXml)
                }
            } ?: error("Could not open .xlsx output stream.")
            contacts.size
        }
    }
}
