package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object ContactActionLauncher {

    fun launchDialer(context: Context, rawPhone: String) {
        val cleaned = rawPhone.filter { it.isDigit() || it == '+' || it == '#' || it == '*' }
        if (cleaned.isBlank()) return
        safeStart(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleaned")), "No dialer found.")
    }

    fun launchWhatsAppChat(
        context: Context,
        rawNumber: String,
        recipientName: String = "",
        customMessage: String? = null,
        defaultCountryCode: String = "880"
    ) {
        val digits = rawNumber.filter { it.isDigit() }
        val e164 = when {
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") && digits.length == 11 -> defaultCountryCode + digits.drop(1)
            else -> digits
        }
        if (e164.length < 7) {
            Toast.makeText(context, "Invalid WhatsApp number", Toast.LENGTH_SHORT).show()
            return
        }
        val text = customMessage ?: if (recipientName.isNotBlank()) {
            "Hello $recipientName, great connecting with you via CardLink!"
        } else "Hello!"
        val uri = Uri.parse("https://wa.me/$e164").buildUpon().appendQueryParameter("text", text).build()
        safeStart(context, Intent(Intent.ACTION_VIEW, uri), "WhatsApp not installed.")
    }

    fun launchEmailComposer(
        context: Context,
        emailAddress: String,
        recipientName: String = "",
        senderName: String = "",
        customSubject: String? = null,
        customBody: String? = null
    ) {
        val clean = emailAddress.trim()
        if (clean.isBlank()) {
            Toast.makeText(context, "No email address available", Toast.LENGTH_SHORT).show()
            return
        }
        val subject = customSubject ?: "Following up — $senderName"
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", clean, null)).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(clean))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            if (!customBody.isNullOrBlank()) {
                putExtra(Intent.EXTRA_TEXT, customBody)
            }
        }
        safeStart(context, intent, "No email app found.")
    }

    fun launchGoogleMaps(
        context: Context,
        officeAddress: String,
        companyName: String = "",
        latitude: Double? = null,
        longitude: Double? = null
    ) {
        if (latitude != null && longitude != null) {
            val label = Uri.encode(companyName.ifBlank { officeAddress.ifBlank { "Office Location" } })
            val geoUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude($label)")
            safeStart(context, Intent(Intent.ACTION_VIEW, geoUri), "Could not open Maps.")
            return
        }
        val query = listOf(companyName.trim(), officeAddress.trim()).filter { it.isNotBlank() }.joinToString(", ")
        if (query.isBlank()) {
            Toast.makeText(context, "No address or GPS pin set", Toast.LENGTH_SHORT).show()
            return
        }
        val encoded = Uri.encode(query)
        val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$encoded")
        safeStart(context, Intent(Intent.ACTION_VIEW, webUri), "Could not open Maps.")
    }

    fun launchTurnByTurnNavigation(
        context: Context,
        latitude: Double?,
        longitude: Double?,
        officeAddress: String
    ) {
        val dest = if (latitude != null && longitude != null) {
            "$latitude,$longitude"
        } else {
            Uri.encode(officeAddress.trim())
        }
        if (dest.isBlank()) return
        val navUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$dest")
        safeStart(context, Intent(Intent.ACTION_VIEW, navUri), "Could not open navigation.")
    }

    fun launchExternalUrl(context: Context, rawUrl: String) {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) return
        val url = if (trimmed.startsWith("http", true)) trimmed else "https://$trimmed"
        safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Could not open link.")
    }

    private fun safeStart(context: Context, intent: Intent, err: String) {
        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
        }
    }
}
