package com.cardlink.app.nfc

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import java.nio.charset.StandardCharsets

class NfcReaderManager(
    private val activity: Activity,
    private val onVCardReceived: (String) -> Unit
) : NfcAdapter.ReaderCallback {

    private val nfcAdapter: NfcAdapter? = NfcAdapter.getDefaultAdapter(activity)

    fun isNfcSupported(): Boolean = nfcAdapter != null
    fun isNfcEnabled(): Boolean = nfcAdapter?.isEnabled == true

    fun enableReaderMode() {
        nfcAdapter?.enableReaderMode(
            activity,
            this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    fun disableReaderMode() {
        nfcAdapter?.disableReaderMode(activity)
    }

    override fun onTagDiscovered(tag: Tag?) {
        val isoDep = IsoDep.get(tag) ?: return
        try {
            isoDep.connect()
            val response = isoDep.transceive(CardLinkHceService.SELECT_CARDLINK_AID)
            if (response.size > 2) {
                val sw1 = response[response.size - 2]
                val sw2 = response[response.size - 1]
                if (sw1 == 0x90.toByte() && sw2 == 0x00.toByte()) {
                    val vcf = String(response, 0, response.size - 2, StandardCharsets.UTF_8)
                    activity.runOnUiThread { onVCardReceived(vcf) }
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { isoDep.close() }
        }
    }
}
