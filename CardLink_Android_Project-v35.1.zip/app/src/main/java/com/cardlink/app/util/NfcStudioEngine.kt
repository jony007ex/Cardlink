package com.cardlink.app.util

import android.content.Context
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import com.cardlink.app.data.model.BusinessCardEntity
import java.nio.charset.Charset
import java.util.Locale

enum class NfcHardwareState {
    READY,
    DISABLED,
    UNSUPPORTED
}

enum class NfcContentType(val label: String) {
    SHARING_PROFILE("CardLink Sharing Profile"),
    URL("Website / URL"),
    VCARD("vCard / Contact"),
    TEXT("Plain Text"),
    PHONE("Phone"),
    EMAIL("Email"),
    SMS("SMS"),
    LOCATION("Location"),
    DEEP_LINK("CardLink Deep Link"),
    CUSTOM_URI("Custom URI")
}

data class NfcTagInspection(
    val techList: List<String>,
    val isNdefSupported: Boolean,
    val isNdefFormatted: Boolean,
    val isWritable: Boolean,
    val canMakeReadOnly: Boolean,
    val maxSizeBytes: Int,
    val usedBytes: Int,
    val recordCount: Int,
    val parsedRecords: List<Pair<String, String>>,
    val primaryPayload: String
)

sealed class NfcOperationResult {
    data class WriteVerified(val bytesWritten: Int, val maxBytes: Int, val inspection: NfcTagInspection) : NfcOperationResult()
    data class ReadSuccess(val inspection: NfcTagInspection) : NfcOperationResult()
    data class ClearedVerified(val inspection: NfcTagInspection) : NfcOperationResult()
    object MadeReadOnly : NfcOperationResult()
    data class CapacityExceeded(val neededBytes: Int, val maxBytes: Int) : NfcOperationResult()
    data class Failure(val message: String) : NfcOperationResult()
}

object NfcStudioEngine {

    fun checkHardwareState(context: Context): NfcHardwareState {
        val adapter = NfcAdapter.getDefaultAdapter(context) ?: return NfcHardwareState.UNSUPPORTED
        return if (adapter.isEnabled) NfcHardwareState.READY else NfcHardwareState.DISABLED
    }

    /**
     * Builds a standards-compliant NdefMessage before arming the physical NFC writer.
     */
    fun buildNdefMessage(
        type: NfcContentType,
        rawInput: String,
        activeCard: BusinessCardEntity? = null,
        sharingProfile: SharingProfileType = SharingProfileType.BUSINESS
    ): Result<NdefMessage> = runCatching {
        val record = when (type) {
            NfcContentType.SHARING_PROFILE -> {
                val card = activeCard ?: error("No active CardLink profile available.")
                val projected = SharingProfileManager.applyProfile(card, sharingProfile)
                val url = projected.resolveNfcShareUrl().trim()
                if (url.startsWith("https://", true) || url.startsWith("http://", true)) {
                    NdefRecord.createUri(url)
                } else {
                    val vcf = CardShareHelper.toVCardString(projected)
                    NdefRecord.createMime("text/vcard", vcf.toByteArray(Charsets.UTF_8))
                }
            }
            NfcContentType.URL -> {
                val u = rawInput.trim()
                require(u.startsWith("https://", true) || u.startsWith("http://", true)) {
                    "Enter a valid URL starting with https:// or http://."
                }
                NdefRecord.createUri(u)
            }
            NfcContentType.VCARD -> {
                val card = activeCard ?: error("No active CardLink profile available.")
                val projected = SharingProfileManager.applyProfile(card, sharingProfile)
                val vcf = CardShareHelper.toVCardString(projected)
                NdefRecord.createMime("text/vcard", vcf.toByteArray(Charsets.UTF_8))
            }
            NfcContentType.TEXT -> {
                val t = rawInput.trim()
                require(t.isNotBlank()) { "Enter text content to write." }
                NdefRecord.createTextRecord(Locale.getDefault().language.ifBlank { "en" }, t)
            }
            NfcContentType.PHONE -> {
                val p = rawInput.trim()
                require(p.any { it.isDigit() }) { "Enter a valid phone number." }
                NdefRecord.createUri(if (p.startsWith("tel:", true)) p else "tel:$p")
            }
            NfcContentType.EMAIL -> {
                val e = rawInput.trim()
                require(e.contains("@")) { "Enter a valid email address." }
                NdefRecord.createUri(if (e.startsWith("mailto:", true)) e else "mailto:$e")
            }
            NfcContentType.SMS -> {
                val s = rawInput.trim()
                require(s.any { it.isDigit() }) { "Enter a valid phone number for SMS." }
                NdefRecord.createUri(if (s.startsWith("sms:", true)) s else "sms:$s")
            }
            NfcContentType.LOCATION -> {
                val loc = rawInput.trim()
                require(loc.isNotBlank()) { "Enter coordinates (e.g. 23.7808,90.4192) or a map link." }
                val uri = if (loc.startsWith("geo:", true) || loc.startsWith("https://", true)) loc else "geo:$loc"
                NdefRecord.createUri(uri)
            }
            NfcContentType.DEEP_LINK -> {
                val path = rawInput.trim().ifBlank { "profile" }
                val uri = if (path.startsWith("cardlink://", true)) path else "cardlink://v1/$path"
                NdefRecord.createUri(uri)
            }
            NfcContentType.CUSTOM_URI -> {
                val u = rawInput.trim()
                require(u.contains(":") && !u.startsWith("javascript:", true)) { "Enter a valid supported URI." }
                NdefRecord.createUri(u)
            }
        }
        NdefMessage(arrayOf(record))
    }

    fun inspectTag(tag: Tag): NfcTagInspection {
        val techs = tag.techList.map { it.substringAfterLast('.') }
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return runCatching {
                ndef.connect()
                val msg = ndef.ndefMessage ?: ndef.cachedNdefMessage
                val used = msg?.toByteArray()?.size ?: 0
                val parsed = parseNdefRecords(msg)
                val inspection = NfcTagInspection(
                    techList = techs,
                    isNdefSupported = true,
                    isNdefFormatted = true,
                    isWritable = ndef.isWritable,
                    canMakeReadOnly = ndef.canMakeReadOnly(),
                    maxSizeBytes = ndef.maxSize,
                    usedBytes = used,
                    recordCount = msg?.records?.size ?: 0,
                    parsedRecords = parsed,
                    primaryPayload = parsed.firstOrNull()?.second.orEmpty()
                )
                ndef.close()
                inspection
            }.getOrElse {
                runCatching { ndef.close() }
                NfcTagInspection(techs, true, true, false, false, 0, 0, 0, emptyList(), "")
            }
        }
        val formatable = NdefFormatable.get(tag)
        return NfcTagInspection(
            techList = techs,
            isNdefSupported = formatable != null,
            isNdefFormatted = false,
            isWritable = formatable != null,
            canMakeReadOnly = false,
            maxSizeBytes = 0,
            usedBytes = 0,
            recordCount = 0,
            parsedRecords = emptyList(),
            primaryPayload = ""
        )
    }

    /**
     * Write -> Read Back -> Exact Byte-for-Byte Verification.
     * Never reports success unless read-back verification matches exactly.
     */
    fun writeAndVerifyTag(context: Context, tag: Tag, message: NdefMessage): NfcOperationResult {
        val expectedBytes = message.toByteArray()
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            return try {
                ndef.connect()
                if (!ndef.isWritable) {
                    ndef.close()
                    return NfcOperationResult.Failure("This NFC tag is read-only and cannot be written.")
                }
                if (expectedBytes.size > ndef.maxSize) {
                    val max = ndef.maxSize
                    ndef.close()
                    return NfcOperationResult.CapacityExceeded(expectedBytes.size, max)
                }
                ndef.writeNdefMessage(message)
                // Read back immediately to verify exact payload!
                val readBack = ndef.ndefMessage
                val max = ndef.maxSize
                val verified = readBack != null && readBack.toByteArray().contentEquals(expectedBytes)
                val parsed = parseNdefRecords(readBack)
                val inspection = NfcTagInspection(
                    techList = tag.techList.map { it.substringAfterLast('.') },
                    isNdefSupported = true,
                    isNdefFormatted = true,
                    isWritable = ndef.isWritable,
                    canMakeReadOnly = ndef.canMakeReadOnly(),
                    maxSizeBytes = max,
                    usedBytes = readBack?.toByteArray()?.size ?: 0,
                    recordCount = readBack?.records?.size ?: 0,
                    parsedRecords = parsed,
                    primaryPayload = parsed.firstOrNull()?.second.orEmpty()
                )
                ndef.close()

                if (verified) {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_WRITTEN", "NFC", true, "NFC tag written and verified (${expectedBytes.size} bytes)")
                    NfcOperationResult.WriteVerified(expectedBytes.size, max, inspection)
                } else {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_VERIFY_FAILED", "NFC", false, "Read-back mismatch")
                    NfcOperationResult.Failure("Tag Could Not Be Verified: Keep the tag near the phone and try again.")
                }
            } catch (e: Exception) {
                runCatching { ndef.close() }
                NfcOperationResult.Failure("Tag moved or connection lost during write. Hold steady and try again.")
            }
        }

        val formatable = NdefFormatable.get(tag)
        if (formatable != null) {
            return try {
                formatable.connect()
                formatable.format(message)
                formatable.close()
                // Re-inspect as NDEF to verify
                val inspection = inspectTag(tag)
                if (inspection.usedBytes == expectedBytes.size) {
                    SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_WRITTEN", "NFC", true, "Formatted and verified (${expectedBytes.size} bytes)")
                    NfcOperationResult.WriteVerified(expectedBytes.size, inspection.maxSizeBytes, inspection)
                } else {
                    NfcOperationResult.Failure("Tag formatted, but verification could not confirm exact content. Try again.")
                }
            } catch (_: Exception) {
                runCatching { formatable.close() }
                NfcOperationResult.Failure("Could not format NFC tag. Ensure it is an NDEF-compatible tag.")
            }
        }

        return NfcOperationResult.Failure("Unsupported NFC tag technology. Use an NFC Forum-compatible NDEF tag.")
    }

    fun clearTagAndVerify(context: Context, tag: Tag): NfcOperationResult {
        val emptyMsg = NdefMessage(arrayOf(NdefRecord(NdefRecord.TNF_EMPTY, ByteArray(0), ByteArray(0), ByteArray(0))))
        val res = writeAndVerifyTag(context, tag, emptyMsg)
        return when (res) {
            is NfcOperationResult.WriteVerified -> {
                SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_CLEARED", "NFC", true, "NFC tag cleared and verified")
                NfcOperationResult.ClearedVerified(res.inspection)
            }
            else -> res
        }
    }

    fun makeTagReadOnly(context: Context, tag: Tag): NfcOperationResult {
        val ndef = Ndef.get(tag) ?: return NfcOperationResult.Failure("Tag does not support NDEF read-only locking.")
        return try {
            ndef.connect()
            if (!ndef.canMakeReadOnly()) {
                ndef.close()
                return NfcOperationResult.Failure("This NFC tag does not support permanent read-only locking.")
            }
            val ok = ndef.makeReadOnly()
            ndef.close()
            if (ok) {
                SecurityHardeningManager.logAuditEventAsync(context, "NFC_TAG_LOCKED", "NFC", true, "NFC tag made permanently read-only")
                NfcOperationResult.MadeReadOnly
            } else {
                NfcOperationResult.Failure("Could not lock this NFC tag.")
            }
        } catch (_: Exception) {
            runCatching { ndef.close() }
            NfcOperationResult.Failure("Connection lost while locking tag.")
        }
    }

    private fun parseNdefRecords(message: NdefMessage?): List<Pair<String, String>> {
        if (message == null) return emptyList()
        return message.records.mapNotNull { rec ->
            when (rec.tnf) {
                NdefRecord.TNF_EMPTY -> null
                NdefRecord.TNF_WELL_KNOWN -> {
                    if (rec.type.contentEquals(NdefRecord.RTD_URI)) {
                        "URI" to (rec.toUri()?.toString() ?: "")
                    } else if (rec.type.contentEquals(NdefRecord.RTD_TEXT)) {
                        val payload = rec.payload
                        if (payload.isEmpty()) "Text" to ""
                        else {
                            val encoding = if ((payload[0].toInt() and 128) == 0) Charsets.UTF_8 else Charset.forName("UTF-16")
                            val langLen = payload[0].toInt() and 63
                            "Text" to String(payload, langLen + 1, (payload.size - langLen - 1).coerceAtLeast(0), encoding)
                        }
                    } else {
                        "Well-Known" to String(rec.payload, Charsets.UTF_8)
                    }
                }
                NdefRecord.TNF_MIME_MEDIA -> {
                    val mime = String(rec.type, Charsets.US_ASCII)
                    "MIME ($mime)" to String(rec.payload, Charsets.UTF_8)
                }
                NdefRecord.TNF_ABSOLUTE_URI -> "URI" to String(rec.type, Charsets.UTF_8)
                else -> "Record (TNF ${rec.tnf})" to String(rec.payload, Charsets.UTF_8)
            }
        }
    }
}
