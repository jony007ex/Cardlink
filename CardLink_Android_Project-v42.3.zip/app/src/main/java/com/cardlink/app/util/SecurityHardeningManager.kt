package com.cardlink.app.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.os.SystemClock
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.SecurityAuditLogEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest

enum class AutoLockDuration(val durationMs: Long, val labelKey: String) {
    IMMEDIATELY(0L, "Immediately"),
    ONE_MINUTE(60_000L, "After 1 Minute"),
    FIVE_MINUTES(5 * 60_000L, "After 5 Minutes"),
    FIFTEEN_MINUTES(15 * 60_000L, "After 15 Minutes"),
    NEVER(-1L, "Never")
}

enum class RuntimeRiskLevel(val label: String) {
    NORMAL("Normal"),
    ELEVATED_RISK("Elevated Risk"),
    HIGH_RISK("High Risk")
}

data class RuntimeIntegrityReport(
    val riskLevel: RuntimeRiskLevel,
    val isDebugBuild: Boolean,
    val signingCertSha256: String,
    val signals: List<String>
)

object SecurityHardeningManager {
    private const val PREFS = "cardlink_security_hardening_prefs"
    private const val KEY_AUTOLOCK_ENUM = "auto_lock_duration_enum"
    private const val KEY_PANIC_LOCK_ACTIVE = "panic_lock_active"
    private const val KEY_DECOY_MODE_ACTIVE = "decoy_privacy_mode_active"
    private const val KEY_AUDIT_RETENTION_DAYS = "audit_retention_days"
    private const val KEY_EXPECTED_CERT_SHA256 = "pinned_release_cert_sha256"

    // Monotonic timestamp (SystemClock.elapsedRealtime) so wall-clock changes cannot bypass Auto-Lock
    @Volatile
    private var lastBackgroundElapsedMs: Long = -1L

    fun getAutoLockDuration(context: Context): AutoLockDuration {
        val raw = SecurePrefsProvider.getEncryptedPrefs(context, PREFS)
            .getString(KEY_AUTOLOCK_ENUM, AutoLockDuration.ONE_MINUTE.name)
        return runCatching { AutoLockDuration.valueOf(raw ?: AutoLockDuration.ONE_MINUTE.name) }
            .getOrDefault(AutoLockDuration.ONE_MINUTE)
    }

    fun setAutoLockDuration(context: Context, duration: AutoLockDuration) {
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).edit()
            .putString(KEY_AUTOLOCK_ENUM, duration.name)
            .apply()
        logAuditEventAsync(context, "SETTING_CHANGED", "Security", true, "Auto-Lock set to ${duration.labelKey}")
    }

    fun recordAppBackgrounded() {
        lastBackgroundElapsedMs = SystemClock.elapsedRealtime()
    }

    fun shouldLockOnResume(context: Context): Boolean {
        if (!BiometricLockHelper.isLockEnabled(context)) return false
        val bgTs = lastBackgroundElapsedMs
        if (bgTs < 0L) return false
        val policy = getAutoLockDuration(context)
        if (policy == AutoLockDuration.NEVER) return false
        val elapsed = SystemClock.elapsedRealtime() - bgTs
        return elapsed >= policy.durationMs
    }

    fun clearBackgroundTimestamp() {
        lastBackgroundElapsedMs = -1L
    }

    // Panic Lock & Privacy/Decoy Mode (Visibility policy over same encrypted DB — never deletes or copies data)
    fun isPanicLockActive(context: Context): Boolean =
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).getBoolean(KEY_PANIC_LOCK_ACTIVE, false)

    fun setPanicLockActive(context: Context, active: Boolean) {
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).edit()
            .putBoolean(KEY_PANIC_LOCK_ACTIVE, active)
            .apply()
        logAuditEventAsync(
            context,
            if (active) "PANIC_LOCK_ON" else "PANIC_LOCK_OFF",
            "Security",
            true,
            if (active) "Panic Lock activated" else "Panic Lock deactivated"
        )
    }

    fun isDecoyModeActive(context: Context): Boolean =
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).getBoolean(KEY_DECOY_MODE_ACTIVE, false)

    fun setDecoyModeActive(context: Context, active: Boolean) {
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).edit()
            .putBoolean(KEY_DECOY_MODE_ACTIVE, active)
            .apply()
        logAuditEventAsync(
            context,
            "DECOY_MODE_CHANGED",
            "Security",
            true,
            if (active) "Privacy / Decoy Mode enabled" else "Privacy / Decoy Mode disabled"
        )
    }

    fun isSensitiveAreaHidden(context: Context): Boolean =
        isPanicLockActive(context) || isDecoyModeActive(context)

    fun getAuditRetentionDays(context: Context): Int =
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).getInt(KEY_AUDIT_RETENTION_DAYS, 90)

    fun setAuditRetentionDays(context: Context, days: Int) {
        SecurePrefsProvider.getEncryptedPrefs(context, PREFS).edit()
            .putInt(KEY_AUDIT_RETENTION_DAYS, days)
            .apply()
    }

    /**
     * Privacy-safe local audit logger: stores ONLY generic event type, feature tag, and safe metadata
     * inside the SQLCipher AES-256 encrypted database. Never logs IDs, numbers, emails, or passwords.
     */
    fun logAuditEventAsync(
        context: Context,
        eventType: String,
        featureTag: String,
        success: Boolean = true,
        safeDetail: String = ""
    ) {
        val appCtx = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val dao = CardLinkDatabase.getDatabase(appCtx).dao()
                dao.insertSecurityAuditLog(
                    SecurityAuditLogEntity(
                        eventType = eventType,
                        featureTag = featureTag,
                        success = success,
                        safeDetail = safeDetail.take(120),
                        timestamp = System.currentTimeMillis()
                    )
                )
                val retentionDays = getAuditRetentionDays(appCtx).coerceAtLeast(30)
                val cutoff = System.currentTimeMillis() - retentionDays.toLong() * 24L * 3600_000L
                dao.pruneSecurityAuditLogsBefore(cutoff)
            }
        }
    }

    /**
     * Layered Runtime Integrity & Risk Assessment:
     * - Checks signing certificate SHA-256 (separate Debug vs Release handling).
     * - Evaluates root / su / Magisk / debugger / Frida signals using a graded policy.
     * - NEVER deletes user data.
     */
    fun evaluateRuntimeIntegrity(context: Context): RuntimeIntegrityReport {
        val isDebug = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val certSha = readSigningCertSha256(context)
        val signals = mutableListOf<String>()

        if (!isDebug && certSha.isNotBlank()) {
            val buildPinned = com.cardlink.app.BuildConfig.EXPECTED_RELEASE_CERT_SHA256.trim()
            if (buildPinned.isNotBlank()) {
                if (!buildPinned.equals(certSha, ignoreCase = true)) {
                    signals.add("Signing certificate mismatch detected")
                }
            } else {
                val prefs = SecurePrefsProvider.getEncryptedPrefs(context, PREFS)
                val pinned = prefs.getString(KEY_EXPECTED_CERT_SHA256, null)
                if (pinned == null) {
                    prefs.edit().putString(KEY_EXPECTED_CERT_SHA256, certSha).apply()
                } else if (!pinned.equals(certSha, ignoreCase = true)) {
                    signals.add("Signing certificate mismatch detected")
                }
            }
        }

        if (!isDebug && (Debug.isDebuggerConnected() || Debug.waitingForDebugger())) {
            signals.add("Unexpected debugger attached")
        }

        val suPaths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/su/bin/su"
        )
        if (suPaths.any { runCatching { File(it).exists() }.getOrDefault(false) }) {
            signals.add("Root binary (su) indicator present")
        }

        val magiskPaths = listOf("/sbin/.magisk", "/data/adb/magisk", "/cache/.disable_magisk")
        if (magiskPaths.any { runCatching { File(it).exists() }.getOrDefault(false) }) {
            signals.add("Magisk indicator present")
        }

        val fridaFound = runCatching {
            File("/proc/self/maps").takeIf { it.canRead() }?.readText()?.contains("frida", ignoreCase = true) == true
        }.getOrDefault(false)
        if (fridaFound) {
            signals.add("Runtime instrumentation (Frida) signal detected")
        }

        val level = when {
            signals.any { it.contains("certificate mismatch", true) || it.contains("Frida", true) } -> RuntimeRiskLevel.HIGH_RISK
            signals.isNotEmpty() -> RuntimeRiskLevel.ELEVATED_RISK
            else -> RuntimeRiskLevel.NORMAL
        }

        if (level != RuntimeRiskLevel.NORMAL) {
            logAuditEventAsync(context, "INTEGRITY_SIGNAL", "Security", false, "Runtime risk: ${level.label}")
        }

        return RuntimeIntegrityReport(
            riskLevel = level,
            isDebugBuild = isDebug,
            signingCertSha256 = certSha,
            signals = signals
        )
    }

    private fun readSigningCertSha256(context: Context): String = runCatching {
        val pm = context.packageManager
        val sigBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val pi = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            pi.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
        } else {
            @Suppress("DEPRECATION")
            val pi = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            pi.signatures?.firstOrNull()?.toByteArray()
        } ?: return ""
        MessageDigest.getInstance("SHA-256").digest(sigBytes).joinToString(":") { "%02X".format(it) }
    }.getOrDefault("")
}
