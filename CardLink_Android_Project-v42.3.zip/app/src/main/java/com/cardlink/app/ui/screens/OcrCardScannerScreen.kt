package com.cardlink.app.ui.screens

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.PendingDraftEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.util.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

@Composable
fun OcrCardScannerScreen(
    existingContacts: List<SavedContactEntity> = emptyList(),
    eventMode: EventModeConfig = EventModeConfig(),
    activeCard: BusinessCardEntity = BusinessCardEntity(),
    queuedCount: Int = 0,
    onEnqueueConferenceCard: (Bitmap) -> Unit = {},
    onOpenConferenceQueue: () -> Unit = {},
    onUpdateSharingPreferences: (BusinessCardEntity) -> Unit = {},
    onSavePendingDraft: (PendingDraftEntity) -> Unit = {},
    onScheduleFollowUpForContact: (SavedContactEntity) -> Unit = {},
    onContactSaved: (SavedContactEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var isQuickQueueMode by remember { mutableStateOf(eventMode.isActive) }
    var stageMessage by remember { mutableStateOf<String?>(null) }
    var pendingQualityGate by remember { mutableStateOf<Pair<Bitmap, ImageQualityReport>?>(null) }

    var scanningSide by remember { mutableStateOf("FRONT") }
    var frontReviewModel by remember { mutableStateOf<ExtractedContactReviewModel?>(null) }
    var frontPhotoUri by remember { mutableStateOf<String?>(null) }
    var backPhotoUri by remember { mutableStateOf<String?>(null) }
    var activeReviewModel by remember { mutableStateOf<ExtractedContactReviewModel?>(null) }

    var savedContactForPostAction by remember { mutableStateOf<SavedContactEntity?>(null) }
    var showSendMyCardBackDialog by remember { mutableStateOf(false) }

    val imageCapture = remember { ImageCapture.Builder().build() }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasCameraPermission = it
    }

    fun executeOcrOnBitmap(bmp: Bitmap) {
        if (isQuickQueueMode) {
            onEnqueueConferenceCard(bmp)
            Toast.makeText(context, "Added to Conference Queue (#${queuedCount + 1})", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            stageMessage = "Improving image…"
            runCatching {
                val savedUri = withContext(Dispatchers.IO) { ScannedCardStorageHelper.saveCardBitmapLocally(context, bmp) }
                stageMessage = "Recognizing বাংলা and English…"
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val visionText = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                stageMessage = "Organizing contact information…"
                val reviewModel = CardOcrPipeline.extractContactWithConfidence(visionText)

                if (scanningSide == "FRONT") {
                    frontReviewModel = reviewModel
                    frontPhotoUri = savedUri
                    scanningSide = "BACK"
                    Toast.makeText(context, "Front scanned! Scan Back side or tap 'Review Now'.", Toast.LENGTH_LONG).show()
                } else {
                    backPhotoUri = savedUri
                    val mergedContact = if (frontReviewModel != null) {
                        BusinessCardOcrParser.mergeDualSide(frontReviewModel!!.contact, reviewModel.contact)
                    } else {
                        reviewModel.contact
                    }
                    val prefilled = if (eventMode.isActive && eventMode.eventName.isNotBlank()) {
                        mergedContact.copy(
                            meetingContext = "Conference: ${eventMode.eventName}",
                            categoryTag = "Event",
                            profilePhotoUri = frontPhotoUri ?: savedUri,
                            backPhotoUri = savedUri
                        )
                    } else {
                        mergedContact.copy(
                            profilePhotoUri = frontPhotoUri ?: savedUri,
                            backPhotoUri = savedUri
                        )
                    }
                    activeReviewModel = reviewModel.copy(contact = prefilled)
                }
            }.onFailure {
                Toast.makeText(context, "Could not read card clearly. You can retake or enter details manually.", Toast.LENGTH_SHORT).show()
            }
            stageMessage = null
        }
    }

    fun processCapturedBitmapWithQualityGate(bmp: Bitmap) {
        val quality = CardOcrPipeline.assessImageQuality(bmp)
        if (!quality.isAcceptable && !isQuickQueueMode) {
            pendingQualityGate = bmp to quality
        } else {
            executeOcrOnBitmap(bmp)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri) }
                if (bmp != null) {
                    processCapturedBitmapWithQualityGate(bmp)
                } else {
                    Toast.makeText(context, "Cannot decode selected image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) permLauncher.launch(Manifest.permission.CAMERA)
    }

    pendingQualityGate?.let { (bmp, report) ->
        AlertDialog(
            onDismissRequest = { pendingQualityGate = null },
            title = { Text(report.warningTitle.ifBlank { "Image May Be Difficult to Read" }, fontWeight = FontWeight.Bold) },
            text = { Text(report.warningMessage) },
            confirmButton = {
                Button(onClick = {
                    pendingQualityGate = null
                    executeOcrOnBitmap(bmp)
                }) { Text("Use Anyway") }
            },
            dismissButton = {
                TextButton(onClick = { pendingQualityGate = null }) { Text("Retake") }
            }
        )
    }

    savedContactForPostAction?.let { savedContact ->
        AlertDialog(
            onDismissRequest = {
                savedContactForPostAction = null
                onContactSaved(savedContact)
            },
            title = { Text(stringResource(R.string.contact_saved_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${savedContact.fullName} has been added to CardLink.", style = MaterialTheme.typography.bodyMedium)
                    Button(
                        onClick = { showSendMyCardBackDialog = true },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.send_my_card_back_title), fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            savedContactForPostAction = null
                            onContactSaved(savedContact)
                            onScheduleFollowUpForContact(savedContact)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Event, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Schedule Follow-Up")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    savedContactForPostAction = null
                    onContactSaved(savedContact)
                }) { Text("Done", fontWeight = FontWeight.Bold) }
            }
        )
    }

    if (showSendMyCardBackDialog && savedContactForPostAction != null) {
        SendMyCardBackDialog(
            recipient = savedContactForPostAction!!,
            activeCard = activeCard,
            onUpdateSharingPreferences = onUpdateSharingPreferences,
            onSavePendingDraft = onSavePendingDraft,
            onDismiss = { showSendMyCardBackDialog = false }
        )
    }

    activeReviewModel?.let { model ->
        var draft by remember(model) { mutableStateOf(model.contact) }
        var showAlternateScripts by remember(model) {
            mutableStateOf(model.contact.alternateName.isNotBlank() || model.contact.alternateCompany.isNotBlank())
        }
        var selectedContextType by remember(model) {
            mutableStateOf(if (eventMode.isActive) "Conference" else "Meeting")
        }
        var contextDetail by remember(model) {
            mutableStateOf(if (eventMode.isActive) eventMode.eventName else "")
        }

        val possibleDuplicate = remember(draft.phone, draft.email, draft.fullName, draft.companyName, existingContacts) {
            val normPhone = CardOcrPipeline.normalizeBangladeshPhone(draft.phone)
            val normEmail = draft.email.trim().lowercase()
            existingContacts.firstOrNull { ex ->
                (normPhone.length >= 8 && CardOcrPipeline.normalizeBangladeshPhone(ex.phone) == normPhone) ||
                    (normEmail.isNotBlank() && ex.email.trim().lowercase() == normEmail) ||
                    (draft.fullName.length >= 3 && draft.companyName.length >= 2 &&
                        ex.fullName.equals(draft.fullName.trim(), true) &&
                        ex.companyName.equals(draft.companyName.trim(), true))
            }
        }

        val nameNeedsReview = model.fieldConfidences["fullName"] == FieldConfidence.NEEDS_REVIEW
        val phoneNeedsReview = model.fieldConfidences["phone"] == FieldConfidence.NEEDS_REVIEW

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(stringResource(R.string.review_contact_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val isReady = draft.fullName.isNotBlank() && draft.fullName != "Scanned Contact" && (draft.phone.isNotBlank() || draft.email.isNotBlank())
                    Text(
                        text = if (isReady) "Contact Ready" else stringResource(R.string.needs_review_badge),
                        fontWeight = FontWeight.Bold,
                        color = if (isReady) Color(0xFF10B981) else Color(0xFFF59E0B),
                        fontSize = 13.sp
                    )
                    Text(
                        text = listOf(
                            if (draft.fullName.isNotBlank()) "✓ Name" else "○ Name missing",
                            if (draft.companyName.isNotBlank()) "✓ Company" else "○ Company missing",
                            if (draft.phone.isNotBlank()) "✓ Mobile" else "○ Mobile missing",
                            if (draft.email.isNotBlank()) "✓ Email" else "○ Email not found"
                        ).joinToString("  •  "),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            possibleDuplicate?.let { dup ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, Color(0xFFF59E0B))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Possible Existing Contact: ${dup.fullName}", fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 13.sp)
                        Text("${dup.companyName} • ${dup.phone.ifBlank { dup.email }}", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val merged = dup.copy(
                                    designation = dup.designation.ifBlank { draft.designation },
                                    companyName = dup.companyName.ifBlank { draft.companyName },
                                    phone = dup.phone.ifBlank { draft.phone },
                                    email = dup.email.ifBlank { draft.email },
                                    officeAddress = dup.officeAddress.ifBlank { draft.officeAddress },
                                    website = dup.website.ifBlank { draft.website }
                                )
                                savedContactForPostAction = merged
                            }) { Text("Update Existing", fontSize = 11.5.sp) }
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!draft.profilePhotoUri.isNullOrBlank()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.detail_front_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Card(
                            modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            AsyncImage(model = Uri.parse(draft.profilePhotoUri), contentDescription = "Front", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
                if (!draft.backPhotoUri.isNullOrBlank()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.detail_back_side), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Card(
                            modifier = Modifier.fillMaxWidth().aspectRatio(1.586f).border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            AsyncImage(model = Uri.parse(draft.backPhotoUri), contentDescription = "Back", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }

            OutlinedTextField(
                value = draft.fullName,
                onValueChange = { draft = draft.copy(fullName = it) },
                isError = nameNeedsReview,
                label = { Text(if (nameNeedsReview) "${stringResource(R.string.edit_full_name)} (${stringResource(R.string.needs_review_badge)})" else stringResource(R.string.edit_full_name)) },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text(stringResource(R.string.edit_designation)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text(stringResource(R.string.edit_company)) }, modifier = Modifier.fillMaxWidth())

            TextButton(onClick = { showAlternateScripts = !showAlternateScripts }, contentPadding = PaddingValues(0.dp)) {
                Text(if (showAlternateScripts) "Hide বাংলা / Alternate Script Fields" else "+ Add বাংলা / Alternate Name & Company", fontSize = 12.sp)
            }
            if (showAlternateScripts) {
                OutlinedTextField(value = draft.alternateName, onValueChange = { draft = draft.copy(alternateName = it) }, label = { Text("বাংলা / Alternate Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = draft.alternateCompany, onValueChange = { draft = draft.copy(alternateCompany = it) }, label = { Text("বাংলা / Alternate Organization") }, modifier = Modifier.fillMaxWidth())
            }

            OutlinedTextField(
                value = draft.phone,
                onValueChange = { draft = draft.copy(phone = it) },
                isError = phoneNeedsReview,
                label = { Text(stringResource(R.string.detail_phone)) },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text(stringResource(R.string.detail_whatsapp)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text(stringResource(R.string.edit_email)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.officeAddress, onValueChange = { draft = draft.copy(officeAddress = it) }, label = { Text(stringResource(R.string.edit_office_address)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text(stringResource(R.string.edit_website)) }, modifier = Modifier.fillMaxWidth())

            Text("How did you meet?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Event", "Meeting", "Referral", "Office Visit", "Conference", "Other").forEach { ctxType ->
                    FilterChip(selected = selectedContextType == ctxType, onClick = { selectedContextType = ctxType }, label = { Text(ctxType, fontSize = 11.sp) })
                }
            }
            OutlinedTextField(
                value = contextDetail,
                onValueChange = { contextDetail = it },
                label = { Text("Event / Context Name (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        activeReviewModel = null
                        frontReviewModel = null
                        frontPhotoUri = null
                        backPhotoUri = null
                        scanningSide = "FRONT"
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.ocr_rescan)) }
                Button(
                    onClick = {
                        val fullContext = listOf(selectedContextType, contextDetail.trim()).filter { it.isNotBlank() }.joinToString(": ")
                        savedContactForPostAction = draft.copy(
                            meetingContext = fullContext,
                            categoryTag = if (selectedContextType == "Conference" || selectedContextType == "Event") "Event" else draft.categoryTag
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.ocr_save_contact)) }
            }
        }
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (hasCameraPermission) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val future = ProcessCameraProvider.getInstance(ctx)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                        provider.unbindAll()
                        provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }
            )

            val scannerAccent = MaterialTheme.colorScheme.primary
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            ) {
                val cardW = size.width * 0.88f
                val cardH = cardW / 1.586f
                val left = (size.width - cardW) / 2f
                val top = (size.height - cardH) / 2.2f
                drawRect(color = Color.Black.copy(alpha = 0.55f))
                drawRoundRect(color = Color.Transparent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), blendMode = BlendMode.Clear)
                drawRoundRect(color = scannerAccent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), style = Stroke(width = 6f))
            }

            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isQuickQueueMode,
                        onClick = { isQuickQueueMode = false },
                        label = { Text("Single Card", fontSize = 11.5.sp) }
                    )
                    FilterChip(
                        selected = isQuickQueueMode,
                        onClick = { isQuickQueueMode = true },
                        label = { Text("${stringResource(R.string.conf_queue_title)} ($queuedCount)", fontSize = 11.5.sp) }
                    )
                }

                if (stageMessage != null) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF0A192F).copy(alpha = 0.88f)) {
                        Text(stageMessage!!, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                    }
                } else if (!isQuickQueueMode && frontReviewModel != null) {
                    Button(
                        onClick = {
                            val prefilled = if (eventMode.isActive && eventMode.eventName.isNotBlank()) {
                                frontReviewModel!!.contact.copy(meetingContext = "Conference: ${eventMode.eventName}", categoryTag = "Event", profilePhotoUri = frontPhotoUri)
                            } else {
                                frontReviewModel!!.contact.copy(profilePhotoUri = frontPhotoUri)
                            }
                            activeReviewModel = frontReviewModel!!.copy(contact = prefilled)
                        }
                    ) {
                        Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.ocr_skip_back), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else if (isQuickQueueMode && queuedCount > 0) {
                    Button(onClick = onOpenConferenceQueue) {
                        Text("Review Queue ($queuedCount)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) { Text(stringResource(R.string.qr_gallery)) }

                Button(
                    onClick = {
                        stageMessage = "Improving image…"
                        imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                val bmp = imageProxy.toBitmapSafe()
                                imageProxy.close()
                                stageMessage = null
                                if (bmp == null) return
                                val cropped = ScannedCardStorageHelper.cropToCardFrame(bmp)
                                processCapturedBitmapWithQualityGate(cropped)
                            }
                            override fun onError(exc: ImageCaptureException) { stageMessage = null }
                        })
                    },
                    enabled = stageMessage == null,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.size(68.dp)
                ) {
                    if (stageMessage != null) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(28.dp))
                    else Icon(Icons.Default.DocumentScanner, null, tint = MaterialTheme.colorScheme.onPrimary)
                }

                OutlinedButton(onClick = onNavigateBack, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                    Text(stringResource(R.string.action_back))
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Camera permission is required to scan paper business cards.", color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Pick from Gallery", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

private fun ImageProxy.toBitmapSafe(): Bitmap? {
    val buffer = planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rot = imageInfo.rotationDegrees
    if (rot == 0) return raw
    val m = Matrix().apply { postRotate(rot.toFloat()) }
    return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
}
