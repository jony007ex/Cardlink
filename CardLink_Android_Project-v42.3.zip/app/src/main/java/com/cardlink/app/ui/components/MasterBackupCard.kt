package com.cardlink.app.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MasterBackupCard(
    onRestoredPreferences: () -> Unit,
    onOpenMigrationAssistant: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    var tick by remember { mutableIntStateOf(0) }
    val info = remember(tick) { MasterBackupManager.getMasterInfo(context) }
    var stageMsg by remember { mutableStateOf<String?>(null) }
    var backupPassword by remember { mutableStateOf("") }
    val isEncrypted = remember(tick) { MasterBackupManager.isMasterBackupEncryptedPref(context) }
    var verifyManifest by remember { mutableStateOf<MasterBackupManifest?>(null) }
    var showSnapshotRestoreDialog by remember { mutableStateOf(false) }
    var showUndoRestoreConfirm by remember { mutableStateOf(false) }
    val canUndoRestore = remember(tick, stageMsg) { MasterBackupManager.hasVerifiedPreRestoreRecovery(context) }

    val setupMasterLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            MasterBackupManager.saveMasterFileSelection(context, uri, "CardLink_Master.cardlink")
            tick++
            scope.launch {
                stageMsg = "Initializing Master Backup…"
                MasterBackupManager.updateMasterBackup(context, password = backupPassword.takeIf { it.isNotBlank() }) { stageMsg = it }
                    .onSuccess { res ->
                        tick++
                        Toast.makeText(
                            context,
                            "Master Backup created (${BackupCenterPrefs.formatBytes(res.containerSizeBytes)})",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    .onFailure {
                        Toast.makeText(context, it.localizedMessage ?: "Master Backup setup failed", Toast.LENGTH_LONG).show()
                    }
                stageMsg = null
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.3.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Storage, null, tint = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.master_backup_title), fontWeight = FontWeight.Bold, fontSize = 15.5.sp, color = MaterialTheme.colorScheme.primary)
            }

            if (stageMsg != null) {
                Text(stageMsg!!, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
            }

            if (info.uriString == null) {
                Text(
                    stringResource(R.string.master_backup_setup_desc),
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { setupMasterLauncher.launch("CardLink_Master.cardlink") },
                    enabled = stageMsg == null,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.CreateNewFolder, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.master_backup_setup_btn), fontWeight = FontWeight.Bold)
                }
            } else if (!info.isAccessible) {
                Text(
                    stringResource(R.string.master_backup_unavailable_title),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
                Text(
                    stringResource(R.string.master_backup_unavailable_msg),
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { setupMasterLauncher.launch("CardLink_Master.cardlink") },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Choose New Master File", fontWeight = FontWeight.Bold) }
            } else {
                Text("File: ${info.fileName} • ${if (isEncrypted) "AES-256-GCM Encrypted" else "Standard"}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                OutlinedTextField(
                    value = backupPassword,
                    onValueChange = { backupPassword = it },
                    label = { Text(stringResource(R.string.master_backup_password_label)) },
                    placeholder = { Text(stringResource(R.string.master_backup_password_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (backupPassword.isNotBlank()) {
                    Text(
                        text = stringResource(R.string.master_backup_password_warning),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Text(
                    "Last updated: ${info.lastUpdatedTimestamp?.let { fmt.format(Date(it)) } ?: "Never"} • Snapshots: ${info.snapshotCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                )

                Button(
                    onClick = {
                        scope.launch {
                            stageMsg = "Updating Master Backup…"
                            MasterBackupManager.updateMasterBackup(context, password = backupPassword.takeIf { it.isNotBlank() }) { stageMsg = it }
                                .onSuccess { res ->
                                    tick++
                                    Toast.makeText(
                                        context,
                                        "Updated! Reused ${res.reusedBlobs} blobs, added ${res.newBlobsWritten} new (${BackupCenterPrefs.formatBytes(res.containerSizeBytes)})",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                                .onFailure {
                                    Toast.makeText(context, it.localizedMessage ?: "Update failed", Toast.LENGTH_LONG).show()
                                }
                            stageMsg = null
                        }
                    },
                    enabled = stageMsg == null,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Sync, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.master_backup_update_btn), fontWeight = FontWeight.Bold)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = stageMsg == null,
                        onClick = {
                            scope.launch {
                                stageMsg = "Verifying Master Backup…"
                                MasterBackupManager.inspectMasterBackup(context, password = backupPassword.takeIf { it.isNotBlank() })
                                    .onSuccess { m ->
                                        verifyManifest = m
                                        Toast.makeText(context, "✅ Master Backup Verified (${m.snapshots.size} snapshots)", Toast.LENGTH_LONG).show()
                                    }
                                    .onFailure {
                                        Toast.makeText(context, "❌ ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                stageMsg = null
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.backup_verify_title), fontSize = 11.5.sp) }

                    OutlinedButton(
                        enabled = stageMsg == null,
                        onClick = {
                            scope.launch {
                                stageMsg = "Loading Snapshots…"
                                MasterBackupManager.inspectMasterBackup(context, password = backupPassword.takeIf { it.isNotBlank() })
                                    .onSuccess { m ->
                                        verifyManifest = m
                                        showSnapshotRestoreDialog = true
                                    }
                                    .onFailure {
                                        Toast.makeText(context, it.localizedMessage ?: "Could not load snapshots", Toast.LENGTH_LONG).show()
                                    }
                                stageMsg = null
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.master_backup_restore_snapshot), fontSize = 11.5.sp) }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Automatic Local Backup (WorkManager) & Snapshot Retention
                Text(stringResource(R.string.master_backup_auto_title), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0 to "Off", 7 to "7 Days", 14 to "14 Days", 30 to "30 Days").forEach { (days, lbl) ->
                        FilterChip(
                            selected = info.autoBackupDays == days,
                            onClick = {
                                MasterBackupManager.configureAutomaticBackup(context, days, info.chargingOnly)
                                tick++
                            },
                            label = { Text(lbl, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Keep Rolling Snapshots", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 3, 5).forEach { keep ->
                            FilterChip(
                                selected = info.retentionCount == keep,
                                onClick = {
                                    MasterBackupManager.setRetentionCount(context, keep)
                                    tick++
                                },
                                label = { Text("$keep", fontSize = 11.sp) }
                            )
                        }
                    }
                }
                if (canUndoRestore) {
                    OutlinedButton(
                        enabled = stageMsg == null,
                        onClick = { showUndoRestoreConfirm = true },
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.65f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Undo, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.undo_restore_btn), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                OutlinedButton(
                    onClick = onOpenMigrationAssistant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PhoneAndroid, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.migration_assistant_title), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(
                    onClick = { setupMasterLauncher.launch("CardLink_Master.cardlink") },
                    modifier = Modifier.align(Alignment.End)
                ) { Text("Choose New Master File", fontSize = 12.sp) }
            }
        }
    }

    if (showUndoRestoreConfirm) {
        AlertDialog(
            onDismissRequest = { showUndoRestoreConfirm = false },
            title = { Text(stringResource(R.string.undo_restore_btn), fontWeight = FontWeight.Bold) },
            text = { Text("Revert CardLink to the verified state captured right before your last snapshot restore?") },
            confirmButton = {
                Button(
                    onClick = {
                        showUndoRestoreConfirm = false
                        SensitiveActionAuthenticator.verifyBeforeSensitiveAction(
                            context = context,
                            actionLabel = "Undo Restore",
                            onAuthorized = {
                        scope.launch {
                            stageMsg = "Reverting to pre-restore state…"
                            MasterBackupManager.undoLastRestore(context)
                                .onSuccess {
                                    tick++
                                    onRestoredPreferences()
                                    Toast.makeText(context, "Previous state restored safely!", Toast.LENGTH_LONG).show()
                                }
                                .onFailure {
                                    Toast.makeText(context, it.localizedMessage ?: "Undo restore failed", Toast.LENGTH_LONG).show()
                                }
                            stageMsg = null
                        }
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.undo_restore_btn)) }
            },
            dismissButton = { TextButton(onClick = { showUndoRestoreConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showSnapshotRestoreDialog && verifyManifest != null) {
        val snaps = verifyManifest!!.snapshots
        var replaceMode by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showSnapshotRestoreDialog = false },
            title = { Text(stringResource(R.string.master_backup_restore_snapshot), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !replaceMode, onClick = { replaceMode = false }, label = { Text("Merge", fontSize = 11.sp) })
                        FilterChip(selected = replaceMode, onClick = { replaceMode = true }, label = { Text("Replace", fontSize = 11.sp) })
                    }
                    snaps.forEachIndexed { idx, s ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showSnapshotRestoreDialog = false
                                scope.launch {
                                    stageMsg = "Restoring snapshot…"
                                    MasterBackupManager.restoreSnapshotFromMaster(context, s.snapshotId, replaceMode, password = backupPassword.takeIf { it.isNotBlank() })
                                        .onSuccess { res ->
                                            onRestoredPreferences()
                                            Toast.makeText(
                                                context,
                                                "Restored ${res.contactsRestored} contacts, ${res.myIdsRestored} IDs, ${res.assetsRestored} assets!",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                        .onFailure {
                                            Toast.makeText(context, it.localizedMessage ?: "Restore failed", Toast.LENGTH_LONG).show()
                                        }
                                    stageMsg = null
                                }
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "${fmt.format(Date(s.createdAtTimestamp))}${if (idx == 0) " (Latest)" else ""}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "Contacts: ${s.contactsCount} • Loyalty: ${s.loyaltyCardsCount} • IDs: ${s.myIdsCount} • QR: ${s.qrProjectsCount}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSnapshotRestoreDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}
