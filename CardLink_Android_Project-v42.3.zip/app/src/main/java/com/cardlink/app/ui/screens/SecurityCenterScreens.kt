package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.SecurityAuditLogEntity
import com.cardlink.app.util.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================================================================
// 1. USER-INITIATED SECURITY CHECKUP (Stage-Based Progress, Actionable Results)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityCheckupScreen(
    onNavigateRoute: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isRunning by remember { mutableStateOf(false) }
    var stageMessage by remember { mutableStateOf<String?>(null) }
    var snapshot by remember { mutableStateOf<ProtectionSnapshot?>(null) }
    var refreshTick by remember { mutableIntStateOf(0) }

    fun runCheckup() {
        if (isRunning) return
        scope.launch {
            isRunning = true
            stageMessage = "Checking app protection…"
            delay(280)
            stageMessage = "Reviewing privacy settings…"
            delay(260)
            stageMessage = "Checking backup protection…"
            delay(260)
            stageMessage = "Checking permissions…"
            TempSecureExportVault.cleanupExpiredExportsSync(context, forceAll = false)
            delay(240)
            stageMessage = "Finalizing…"
            SecurityCheckupEngine.recordCheckupCompleted(context)
            snapshot = SecurityCheckupEngine.evaluateProtection(context, includeDismissed = false)
            delay(180)
            isRunning = false
            stageMessage = null
        }
    }

    LaunchedEffect(Unit) {
        runCheckup()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.sec_checkup_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (isRunning) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Text(
                            text = stageMessage ?: "Checking app protection…",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                val res = snapshot ?: SecurityCheckupEngine.evaluateProtection(context, includeDismissed = false)
                val statusColor = when (res.statusLevel) {
                    ProtectionStatusLevel.STRONG -> Color(0xFF10B981)
                    ProtectionStatusLevel.GOOD -> MaterialTheme.colorScheme.primary
                    ProtectionStatusLevel.NEEDS_ATTENTION -> Color(0xFFF59E0B)
                    ProtectionStatusLevel.ELEVATED_RISK -> MaterialTheme.colorScheme.error
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.55f))
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(
                                imageVector = if (res.statusLevel == ProtectionStatusLevel.STRONG) Icons.Default.VerifiedUser else Icons.Default.Info,
                                contentDescription = null,
                                tint = statusColor,
                                modifier = Modifier.size(26.dp)
                            )
                            Column {
                                Text("Security Checkup Complete", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "Protection ${res.statusLevel.label}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = statusColor
                                )
                            }
                        }
                        Text(
                            text = "${res.activeProtectionsCount} protections active",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (res.recommendations.isEmpty()) {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF10B981))
                            Text("All main protections are active. No action required.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    Text(
                        text = "${res.recommendations.size} Recommendation(s)",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.5.sp
                    )
                    res.recommendations.forEach { rec ->
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(rec.title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                                Text(rec.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    if (rec.isDismissible) {
                                        TextButton(onClick = {
                                            SecurityCheckupEngine.dismissRecommendation(context, rec.id)
                                            refreshTick++
                                            snapshot = SecurityCheckupEngine.evaluateProtection(context, includeDismissed = false)
                                        }) { Text("Not Now", fontSize = 12.sp) }
                                    }
                                    Button(onClick = { onNavigateRoute(rec.targetRoute) }) {
                                        Text(rec.actionLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = { runCheckup() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.sec_run_checkup), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// =============================================================================
// 2. RECENT SECURITY ACTIVITY SCREEN (Privacy-Safe, 30/90/180-Day Retention)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityActivityScreen(
    auditLogs: List<SecurityAuditLogEntity>,
    onClearAuditLogs: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var retentionDays by remember { mutableIntStateOf(SecurityHardeningManager.getAuditRetentionDays(context)) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var selectedEvent by remember { mutableStateOf<SecurityAuditLogEntity?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.sec_recent_activity_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (auditLogs.isNotEmpty()) {
                        TextButton(onClick = { showClearConfirm = true }) {
                            Text("Clear", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Activity Retention", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30, 90, 180).forEach { days ->
                            FilterChip(
                                selected = retentionDays == days,
                                onClick = {
                                    retentionDays = days
                                    SecurityHardeningManager.setAuditRetentionDays(context, days)
                                },
                                label = { Text("$days Days", fontSize = 11.5.sp) }
                            )
                        }
                    }
                }
            }

            if (auditLogs.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.History, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        Text("No recent security activity", fontWeight = FontWeight.Bold)
                        Text("Meaningful events such as unlocks, protected document shares, and backup restores appear here without storing personal details.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                auditLogs.take(20).forEach { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectedEvent = log },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = if (log.success) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = if (log.success) Color(0xFF10B981) else Color(0xFFF59E0B),
                                modifier = Modifier.size(20.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(log.safeDetail.ifBlank { log.eventType }, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
                                Text(
                                    "${fmt.format(Date(log.timestamp))} • ${log.featureTag}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    selectedEvent?.let { ev ->
        AlertDialog(
            onDismissRequest = { selectedEvent = null },
            title = { Text("Event Details", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Date & Time: ${fmt.format(Date(ev.timestamp))}", style = MaterialTheme.typography.bodySmall)
                    Text("Category: ${ev.featureTag}", style = MaterialTheme.typography.bodySmall)
                    Text("Status: ${if (ev.success) "Succeeded" else "Attention / Blocked"}", style = MaterialTheme.typography.bodySmall)
                    Text("Summary: ${ev.safeDetail.ifBlank { ev.eventType }}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { selectedEvent = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Security Activity?", fontWeight = FontWeight.Bold) },
            text = { Text("This clears your local security activity log. Your Contacts, IDs, Loyalty Cards, and Backups will not be affected.") },
            confirmButton = {
                Button(
                    onClick = {
                        showClearConfirm = false
                        SensitiveActionAuthenticator.verifyBeforeSensitiveAction(
                            context = context,
                            actionLabel = "Clear Security Activity",
                            onAuthorized = {
                                onClearAuditLogs()
                                Toast.makeText(context, "Security activity cleared.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Clear History") }
            },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}

// =============================================================================
// 3. TECHNICAL SECURITY INFORMATION (Read-Only, User-Friendly)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TechnicalSecurityInfoScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val integrity = remember { SecurityHardeningManager.evaluateRuntimeIntegrity(context) }
    val (verName, verCode) = remember { ReleaseNotesRepository.getInstalledVersion(context) }
    val strongBox = remember { VaultCryptoManager.isStrongBoxSupported(context) }
    val hwKeystore = remember { VaultCryptoManager.isHardwareKeystoreAvailable() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.sec_tech_info_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TechInfoRow("Encrypted local database", "Active")
                    TechInfoRow("Protected document vault", if (VaultCryptoManager.isVaultActive(context)) "Active" else "Initializing")
                    TechInfoRow("Hardware Keystore", if (hwKeystore) "Active" else "Standard Keystore")
                    TechInfoRow("StrongBox readiness", if (strongBox) "Supported on device" else "Standard hardware fallback")
                    TechInfoRow("Cryptographic key version", "v${VaultCryptoManager.CURRENT_KEY_VERSION}")
                    TechInfoRow("Release integrity state", integrity.riskLevel.label)
                    TechInfoRow("Application version", "$verName ($verCode)")
                }
            }

            if (integrity.signals.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFF59E0B))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Environment Notes", fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 13.sp)
                        Text("Device security environment may be modified or running in a non-standard state.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TechInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}
