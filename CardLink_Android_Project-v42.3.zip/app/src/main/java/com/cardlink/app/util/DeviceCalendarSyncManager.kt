package com.cardlink.app.util

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.cardlink.app.data.model.FollowUpEntity
import java.util.TimeZone

data class DeviceCalendarAccount(
    val calendarId: Long,
    val displayName: String,
    val accountName: String
)

enum class CalendarSyncCheckState {
    NOT_SYNCED,
    IN_SYNC,
    EXTERNAL_CHANGED,
    EXTERNAL_DELETED
}

object DeviceCalendarSyncManager {

    fun hasCalendarPermission(context: Context): Boolean {
        val r = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
        val w = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
        return r && w
    }

    fun getWritableCalendars(context: Context): List<DeviceCalendarAccount> {
        if (!hasCalendarPermission(context)) return emptyList()
        val result = mutableListOf<DeviceCalendarAccount>()
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
        )
        val selection = "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        runCatching {
            context.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                projection,
                selection,
                null,
                null
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val name = cursor.getString(1).orEmpty().ifBlank { "Device Calendar" }
                    val acct = cursor.getString(2).orEmpty()
                    result.add(DeviceCalendarAccount(id, name, acct))
                }
            }
        }
        return result
    }

    fun upsertFollowUpEvent(
        context: Context,
        followUp: FollowUpEntity,
        calendarId: Long,
        reminderMinutesBefore: Int = 15
    ): Result<FollowUpEntity> = runCatching {
        require(hasCalendarPermission(context)) { "Calendar permission is required." }

        val title = "Meeting with ${followUp.contactName.ifBlank { followUp.title }}"
        val description = buildString {
            append(followUp.title)
            if (followUp.companyName.isNotBlank()) append(" • ${followUp.companyName}")
            append("\nManaged in CardLink (cardlink://contacts)")
        }
        val startMs = followUp.dueAtTimestamp
        val endMs = startMs + 30L * 60_000L

        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startMs)
            put(CalendarContract.Events.DTEND, endMs)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.EVENT_LOCATION, followUp.companyName)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }

        val existingEventId = followUp.deviceEventId
        val resolvedEventId: Long = if (existingEventId != null && existingEventId > 0L) {
            val updateUri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existingEventId)
            val rows = context.contentResolver.update(updateUri, values, null, null)
            if (rows > 0) existingEventId else {
                val inserted = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                    ?: error("Could not create device calendar event.")
                inserted.lastPathSegment?.toLongOrNull() ?: error("Invalid calendar event ID.")
            }
        } else {
            val inserted = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                ?: error("Could not create device calendar event.")
            inserted.lastPathSegment?.toLongOrNull() ?: error("Invalid calendar event ID.")
        }

        if (reminderMinutesBefore > 0) {
            runCatching {
                val remValues = ContentValues().apply {
                    put(CalendarContract.Reminders.MINUTES, reminderMinutesBefore)
                    put(CalendarContract.Reminders.EVENT_ID, resolvedEventId)
                    put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                }
                context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, remValues)
            }
        }

        followUp.copy(
            deviceCalendarId = calendarId,
            deviceEventId = resolvedEventId,
            lastSyncedTimestamp = System.currentTimeMillis(),
            calendarSyncStatus = "SYNCED"
        )
    }

    fun inspectExternalEventState(context: Context, followUp: FollowUpEntity): Pair<CalendarSyncCheckState, Long?> {
        val eventId = followUp.deviceEventId ?: return CalendarSyncCheckState.NOT_SYNCED to null
        if (!hasCalendarPermission(context)) return CalendarSyncCheckState.NOT_SYNCED to null
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        val projection = arrayOf(CalendarContract.Events.DTSTART, CalendarContract.Events.DELETED)
        return runCatching {
            context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
                if (!c.moveToFirst()) return@use CalendarSyncCheckState.EXTERNAL_DELETED to null
                val deleted = c.getInt(1) == 1
                if (deleted) return@use CalendarSyncCheckState.EXTERNAL_DELETED to null
                val extStart = c.getLong(0)
                if (extStart != followUp.dueAtTimestamp) {
                    CalendarSyncCheckState.EXTERNAL_CHANGED to extStart
                } else {
                    CalendarSyncCheckState.IN_SYNC to extStart
                }
            } ?: (CalendarSyncCheckState.EXTERNAL_DELETED to null)
        }.getOrDefault(CalendarSyncCheckState.IN_SYNC to followUp.dueAtTimestamp)
    }
}
