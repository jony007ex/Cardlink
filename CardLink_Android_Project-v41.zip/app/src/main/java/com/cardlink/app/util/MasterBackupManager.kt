package com.cardlink.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.room.withTransaction
import androidx.work.*
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.widget.CardLinkWidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.*
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class MasterSnapshotMeta(
    val snapshotId: String,
    val createdAtTimestamp: Long,
    val appVersionName: String,
    val myCardsCount: Int,
    val contactsCount: Int,
    val followUpsCount: Int,
    val loyaltyCardsCount: Int,
    val myIdsCount: Int,
    val qrProjectsCount: Int,
    val secureNotesCount: Int,
    val nfcProjectsCount: Int = 0,
    val referencedBlobHashes: List<String> = emptyList(),
    val snapshotSha256: String = ""
)

@Serializable
data class MasterBackupManifest(
    val backupFormatVersion: Int = 4,
    val containerType: String = "CARDLINK_MASTER_INCREMENTAL",
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis(),
    val retentionCount: Int = 3,
    val snapshots: List<MasterSnapshotMeta> = emptyList(),
    val blobChecksums: Map<String, String> = emptyMap()
)

@Serializable
data class MasterSnapshotPayload(
    val snapshotId: String,
    val createdAtTimestamp: Long,
    val myCards: List<BusinessCardEntity> = emptyList(),
    val savedContacts: List<SavedContactEntity> = emptyList(),
    val followUps: List<FollowUpEntity> = emptyList(),
    val loyaltyCards: List<LoyaltyCardEntity> = emptyList(),
    val idDocuments: List<IdDocumentEntity> = emptyList(),
    val idPages: List<IdDocumentPageEntity> = emptyList(),
    val qrProjects: List<QrProjectEntity> = emptyList(),
    val qrDesignPresets: List<QrDesignPresetEntity> = emptyList(),
    val secureNotes: List<SecureNoteEntity> = emptyList(),
    val nfcProjects: List<NfcProjectEntity> = emptyList(),
    val preferences: CardLinkPackagePreferences? = null,
    // Maps original local URI -> SHA-256 content hash (blobs/<sha256>.bin)
    val uriToBlobHash: Map<String, String> = emptyMap()
)

data class MasterBackupInfo(
    val uriString: String?,
    val fileName: String,
    val isAccessible: Boolean,
    val lastUpdatedTimestamp: Long?,
    val snapshotCount: Int,
    val retentionCount: Int,
    val autoBackupDays: Int,
    val chargingOnly: Boolean
)

data class MasterUpdateResult(
    val snapshotId: String,
    val totalBlobs: Int,
    val reusedBlobs: Int,
    val newBlobsWritten: Int,
    val prunedBlobs: Int,
    val retainedSnapshots: Int,
    val containerSizeBytes: Long
)

object MasterBackupManager {
    private const val PREFS = "cardlink_master_backup_prefs"
    private const val KEY_MASTER_URI = "master_backup_uri"
    private const val KEY_MASTER_NAME = "master_backup_name"
    private const val KEY_LAST_UPDATED = "master_backup_last_updated"
    private const val KEY_SNAPSHOT_COUNT = "master_backup_snapshot_count"
    private const val KEY_RETENTION = "master_backup_retention_count"
    private const val KEY_AUTO_DAYS = "master_backup_auto_days"
    private const val KEY_AUTO_CHARGING = "master_backup_auto_charging_only"
    private const val WORK_NAME = "cardlink_periodic_master_backup"

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }

    fun saveMasterFileSelection(context: Context, uri: Uri, displayName: String) {
        runCatching {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_MASTER_URI, uri.toString())
            .putString(KEY_MASTER_NAME, displayName.ifBlank { "CardLink_Master.cardlink" })
            .apply()
    }

    fun getMasterInfo(context: Context): MasterBackupInfo {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val uriStr = p.getString(KEY_MASTER_URI, null)
        val name = p.getString(KEY_MASTER_NAME, "CardLink_Master.cardlink") ?: "CardLink_Master.cardlink"
        val accessible = !uriStr.isNullOrBlank() && BackupCenterPrefs.isBackupUriAccessible(context, uriStr)
        val lastTs = p.getLong(KEY_LAST_UPDATED, -1L).takeIf { it > 0L }
        val snapCount = p.getInt(KEY_SNAPSHOT_COUNT, 0)
        val retention = p.getInt(KEY_RETENTION, 3)
        val autoDays = p.getInt(KEY_AUTO_DAYS, 0)
        val charging = p.getBoolean(KEY_AUTO_CHARGING, false)
        return MasterBackupInfo(uriStr, name, accessible, lastTs, snapCount, retention, autoDays, charging)
    }

    fun setRetentionCount(context: Context, count: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_RETENTION, count.coerceIn(1, 5))
            .apply()
    }

    fun configureAutomaticBackup(context: Context, intervalDays: Int, chargingOnly: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_AUTO_DAYS, intervalDays)
            .putBoolean(KEY_AUTO_CHARGING, chargingOnly)
            .apply()

        val wm = WorkManager.getInstance(context)
        if (intervalDays <= 0) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .setRequiresStorageNotLow(true)
            .setRequiresCharging(chargingOnly)
            .build()

        val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(intervalDays.toLong(), TimeUnit.DAYS)
            .setConstraints(constraints)
            .build()

        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    /**
     * Content-Addressable Incremental Master Backup Update:
     * 1. Reads existing blobs & snapshots from the Master Backup file (if present).
     * 2. Hashes current assets with SHA-256 and reuses unchanged blobs.
     * 3. Appends a new immutable Snapshot and rotates to keep the latest N snapshots (default 3).
     * 4. Runs Reference-Counted Garbage Collection (deletes blobs with refCount == 0).
     * 5. Writes & verifies the entire container in private temp storage BEFORE committing to SAF URI.
     */
    suspend fun updateMasterBackup(
        context: Context,
        password: String? = null,
        onStage: (String) -> Unit = {}
    ): Result<MasterUpdateResult> = withContext(Dispatchers.IO) {
        runCatching {
            val info = getMasterInfo(context)
            val uriStr = info.uriString ?: error("Master Backup file is not configured.")
            val masterUri = Uri.parse(uriStr)

            val availBytes = runCatching { StatFs(context.cacheDir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
            if (availBytes < 24L * 1024L * 1024L) {
                error("Not Enough Storage: CardLink needs additional free space to safely update the Master Backup.")
            }

            onStage("Reading existing Master Backup…")
            val existingZipEntries = linkedMapOf<String, ByteArray>()
            var existingManifest: MasterBackupManifest? = null
            val existingRaw = runCatching {
                context.contentResolver.openInputStream(masterUri)?.use { it.readBytes() }
            }.getOrNull()
            if (existingRaw != null && existingRaw.isNotEmpty()) {
                val plainZip = decryptEnvelopeIfNeeded(existingRaw, password)
                runCatching {
                    ZipInputStream(BufferedInputStream(ByteArrayInputStream(plainZip))).use { zis ->
                        var e = zis.nextEntry
                        while (e != null) {
                            if (!e.isDirectory) existingZipEntries[e.name] = zis.readBytes()
                            zis.closeEntry()
                            e = zis.nextEntry
                        }
                    }
                    existingZipEntries["master_manifest.json"]?.let { mBytes ->
                        existingManifest = json.decodeFromString<MasterBackupManifest>(mBytes.toString(Charsets.UTF_8))
                    }
                }
            }

            onStage("Collecting & hashing changed data…")
            val dao = CardLinkDatabase.getDatabase(context).dao()
            val cards = dao.getAllMyCardsSnapshot()
            val contacts = dao.getAllContactsSnapshot()
            val followUps = dao.getAllFollowUpsSnapshot()
            val loyalty = dao.getAllLoyaltyCardsSnapshot()
            val idDocs = dao.getAllIdDocumentsSnapshot()
            val idPages = dao.getAllIdPagesSnapshot()
            val qrProjects = dao.getAllQrProjectsSnapshot()
            val qrPresets = dao.getAllQrDesignPresetsSnapshot()
            val secureNotes = dao.getAllSecureNotesSnapshot()
            val nfcProjects = dao.getAllNfcProjectsSnapshot()

            val prefs = CardLinkPackagePreferences(
                languageCode = LanguageManager.getSavedLanguage(context),
                darkThemeMode = when (LanguageManager.getSavedThemeOverride(context)) {
                    false -> "LIGHT"
                    true -> "DARK"
                    null -> "SYSTEM"
                },
                notificationsEnabled = LanguageManager.isNotificationsEnabled(context),
                biometricLockEnabled = BiometricLockHelper.isLockEnabled(context),
                appThemeConfig = ThemeContrastHelper.loadAppTheme(context),
                eventMode = EventModeHelper.load(context),
                reminderIntervalDays = BackupCenterPrefs.getReminderIntervalDays(context)
            )

            // Collect all current local assets and compute content-addressable SHA-256 hashes
            val currentAssetUris = linkedSetOf<String>()
            fun addIfFile(u: String?) { if (!u.isNullOrBlank() && Uri.parse(u).scheme == "file") currentAssetUris.add(u) }
            cards.forEach { addIfFile(it.profilePhotoUri); addIfFile(it.companyLogoUri) }
            contacts.forEach { addIfFile(it.profilePhotoUri); addIfFile(it.backPhotoUri) }
            loyalty.forEach { addIfFile(it.frontPhotoUri); addIfFile(it.backPhotoUri) }
            idPages.forEach { addIfFile(it.imageUri) }
            qrProjects.forEach { addIfFile(it.logoUri) }

            val uriToHash = linkedMapOf<String, String>()
            val newBlobsMap = linkedMapOf<String, ByteArray>()
            var reusedBlobs = 0
            var newBlobsWritten = 0

            for (u in currentAssetUris) {
                val path = Uri.parse(u).path ?: continue
                val f = File(path)
                if (!f.exists() || !f.isFile) continue
                val plainBytes = VaultCryptoManager.readDecryptedBytesFromFile(f) ?: f.readBytes()
                val hash = sha256(plainBytes)
                uriToHash[u] = hash
                val blobEntryName = "blobs/$hash.bin"
                if (existingZipEntries.containsKey(blobEntryName)) {
                    reusedBlobs++
                } else if (!newBlobsMap.containsKey(blobEntryName)) {
                    newBlobsMap[blobEntryName] = plainBytes
                    newBlobsWritten++
                }
            }

            val now = System.currentTimeMillis()
            val snapId = "snap_$now"
            val snapPayload = MasterSnapshotPayload(
                snapshotId = snapId,
                createdAtTimestamp = now,
                myCards = cards,
                savedContacts = contacts,
                followUps = followUps,
                loyaltyCards = loyalty,
                idDocuments = idDocs,
                idPages = idPages,
                qrProjects = qrProjects,
                qrDesignPresets = qrPresets,
                secureNotes = secureNotes,
                nfcProjects = nfcProjects,
                preferences = prefs,
                uriToBlobHash = uriToHash
            )
            val snapBytes = json.encodeToString(snapPayload).toByteArray(Charsets.UTF_8)
            val snapMeta = MasterSnapshotMeta(
                snapshotId = snapId,
                createdAtTimestamp = now,
                appVersionName = readAppVersionName(context),
                myCardsCount = cards.size,
                contactsCount = contacts.size,
                followUpsCount = followUps.size,
                loyaltyCardsCount = loyalty.size,
                myIdsCount = idDocs.size,
                qrProjectsCount = qrProjects.size,
                secureNotesCount = secureNotes.size,
                nfcProjectsCount = nfcProjects.size,
                referencedBlobHashes = uriToHash.values.distinct(),
                snapshotSha256 = sha256(snapBytes)
            )

            // Rolling Snapshot Rotation (keep latest N snapshots)
            val retention = info.retentionCount.coerceIn(1, 5)
            val prevSnaps = existingManifest?.snapshots.orEmpty()
            val retainedSnaps = (listOf(snapMeta) + prevSnaps).take(retention)

            // Reference-Counted Garbage Collection: retain ONLY blobs referenced by at least 1 retained snapshot
            val liveBlobHashes = retainedSnaps.flatMap { it.referencedBlobHashes }.toSet()
            val finalBlobs = linkedMapOf<String, ByteArray>()
            val finalChecksums = linkedMapOf<String, String>()
            var prunedBlobs = 0

            for ((entryName, bytes) in existingZipEntries) {
                if (entryName.startsWith("blobs/") && entryName.endsWith(".bin")) {
                    val h = entryName.removePrefix("blobs/").removeSuffix(".bin")
                    if (h in liveBlobHashes) {
                        finalBlobs[entryName] = bytes
                        finalChecksums[entryName] = h
                    } else {
                        prunedBlobs++
                    }
                }
            }
            for ((entryName, bytes) in newBlobsMap) {
                val h = entryName.removePrefix("blobs/").removeSuffix(".bin")
                if (h in liveBlobHashes) {
                    finalBlobs[entryName] = bytes
                    finalChecksums[entryName] = h
                }
            }

            val updatedManifest = MasterBackupManifest(
                backupFormatVersion = 4,
                createdAtTimestamp = existingManifest?.createdAtTimestamp ?: now,
                updatedAtTimestamp = now,
                retentionCount = retention,
                snapshots = retainedSnaps,
                blobChecksums = finalChecksums
            )

            // Atomic Temp-Build & Verification BEFORE touching the destination Master Backup file
            onStage("Building & verifying incremental package…")
            val tempFile = File(context.cacheDir, "master_tmp_$now.cardlink")
            try {
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                    zos.putNextEntry(ZipEntry("master_manifest.json"))
                    zos.write(json.encodeToString(updatedManifest).toByteArray(Charsets.UTF_8))
                    zos.closeEntry()

                    zos.putNextEntry(ZipEntry("snapshots/$snapId.json"))
                    zos.write(snapBytes)
                    zos.closeEntry()

                    // Carry forward retained previous snapshots
                    for (oldMeta in retainedSnaps.drop(1)) {
                        val sKey = "snapshots/${oldMeta.snapshotId}.json"
                        val oldBytes = existingZipEntries[sKey] ?: continue
                        zos.putNextEntry(ZipEntry(sKey))
                        zos.write(oldBytes)
                        zos.closeEntry()
                    }

                    // Write deduplicated content-addressed blobs
                    for ((bKey, bBytes) in finalBlobs) {
                        zos.putNextEntry(ZipEntry(bKey))
                        zos.write(bBytes)
                        zos.closeEntry()
                    }
                }

                // Verify temp file integrity before committing
                val verifyManifest = inspectMasterFile(tempFile).getOrThrow()
                if (verifyManifest.snapshots.isEmpty()) error("Verification failed: no snapshots in built Master Backup.")

                val finalBytes = if (!password.isNullOrBlank()) {
                    onStage("Encrypting Master Backup (AES-256-GCM)…")
                    encryptEnvelope(tempFile.readBytes(), password)
                } else {
                    tempFile.readBytes()
                }

                onStage("Committing to Master Backup file…")
                context.contentResolver.openOutputStream(masterUri, "wt")?.use { out ->
                    out.write(finalBytes)
                    out.flush()
                } ?: error("Master Backup Unavailable: Could not write to selected Master Backup URI.")

                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putLong(KEY_LAST_UPDATED, now)
                    .putInt(KEY_SNAPSHOT_COUNT, retainedSnaps.size)
                    .putBoolean(KEY_IS_ENCRYPTED, !password.isNullOrBlank())
                    .apply()

                SecurityHardeningManager.logAuditEventAsync(
                    context, "MASTER_BACKUP_UPDATED", "Backup", true,
                    "Snapshots: ${retainedSnaps.size}, New blobs: $newBlobsWritten, Reused: $reusedBlobs"
                )

                MasterUpdateResult(
                    snapshotId = snapId,
                    totalBlobs = finalBlobs.size,
                    reusedBlobs = reusedBlobs,
                    newBlobsWritten = newBlobsWritten,
                    prunedBlobs = prunedBlobs,
                    retainedSnapshots = retainedSnaps.size,
                    containerSizeBytes = tempFile.length()
                )
            } finally {
                if (tempFile.exists()) tempFile.delete()
            }
        }
    }

    suspend fun inspectMasterBackup(context: Context, password: String? = null): Result<MasterBackupManifest> = withContext(Dispatchers.IO) {
        runCatching {
            val info = getMasterInfo(context)
            val uriStr = info.uriString ?: error("Master Backup file is not configured.")
            val temp = File(context.cacheDir, "master_inspect_${System.currentTimeMillis()}.tmp")
            try {
                val raw = context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { it.readBytes() }
                    ?: error("Master Backup Unavailable: File is no longer accessible.")
                val plainZip = decryptEnvelopeIfNeeded(raw, password)
                temp.writeBytes(plainZip)
                inspectMasterFile(temp).getOrThrow()
            } finally {
                if (temp.exists()) temp.delete()
            }
        }
    }

    private fun inspectMasterFile(file: File): Result<MasterBackupManifest> = runCatching {
        val entriesMap = linkedMapOf<String, ByteArray>()
        ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                if (!e.isDirectory) entriesMap[e.name] = zis.readBytes()
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
        val mBytes = entriesMap["master_manifest.json"] ?: error("Invalid Master Backup: missing master_manifest.json")
        val manifest = json.decodeFromString<MasterBackupManifest>(mBytes.toString(Charsets.UTF_8))

        // Verify SHA-256 of every snapshot and every referenced blob
        for (snap in manifest.snapshots) {
            val sBytes = entriesMap["snapshots/${snap.snapshotId}.json"]
                ?: error("Incomplete Master Backup: missing snapshot ${snap.snapshotId}")
            if (snap.snapshotSha256.isNotBlank() && !sha256(sBytes).equals(snap.snapshotSha256, true)) {
                error("Corrupted Master Backup: snapshot checksum mismatch.")
            }
            for (h in snap.referencedBlobHashes) {
                val bBytes = entriesMap["blobs/$h.bin"] ?: error("Incomplete Master Backup: missing asset blob.")
                if (!sha256(bBytes).equals(h, true)) {
                    error("Corrupted Master Backup: blob hash mismatch.")
                }
            }
        }
        manifest
    }

    suspend fun restoreSnapshotFromMaster(
        context: Context,
        snapshotId: String,
        replaceExisting: Boolean,
        password: String? = null
    ): Result<DetailedRestoreResult> = withContext(Dispatchers.IO) {
        runCatching {
            val info = getMasterInfo(context)
            val uriStr = info.uriString ?: error("Master Backup file is not configured.")
            val raw = context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { it.readBytes() }
                ?: error("Master Backup Unavailable.")
            val plainZip = decryptEnvelopeIfNeeded(raw, password)
            val entriesMap = linkedMapOf<String, ByteArray>()
            ZipInputStream(BufferedInputStream(ByteArrayInputStream(plainZip))).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    if (!e.isDirectory) entriesMap[e.name] = zis.readBytes()
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }

            val sBytes = entriesMap["snapshots/$snapshotId.json"] ?: error("Selected snapshot not found.")
            val payload = json.decodeFromString<MasterSnapshotPayload>(sBytes.toString(Charsets.UTF_8))

            val oldUriToNewUri = mutableMapOf<String, String>()
            var assetsRestored = 0
            for ((oldUri, hash) in payload.uriToBlobHash) {
                val bytes = entriesMap["blobs/$hash.bin"] ?: continue
                val subFolder = when {
                    oldUri.contains("loyalty_cards") -> "loyalty_cards"
                    oldUri.contains("my_ids") -> "my_ids"
                    oldUri.contains("scanned_cards") -> "scanned_cards"
                    oldUri.contains("qr_logos") -> "qr_logos"
                    else -> "profile_assets"
                }
                oldUriToNewUri[oldUri] = if (subFolder == "loyalty_cards" || subFolder == "my_ids") {
                    VaultCryptoManager.saveEncryptedBytes(context, bytes, subFolder, "mrest_${assetsRestored}")
                } else {
                    val dir = File(context.filesDir, subFolder).apply { if (!exists()) mkdirs() }
                    val out = File(dir, "mrest_${System.currentTimeMillis()}_${assetsRestored}.jpg")
                    out.writeBytes(bytes)
                    Uri.fromFile(out).toString()
                }
                assetsRestored++
            }
            fun remap(u: String?): String? = u?.let { oldUriToNewUri[it] ?: it }

            capturePreRestoreRecoverySnapshot(context)
            val db = CardLinkDatabase.getDatabase(context)
            val dao = db.dao()

            db.withTransaction {
                if (replaceExisting) {
                    dao.clearAllMyCards()
                    dao.clearAllContacts()
                    dao.clearAllFollowUps()
                    dao.clearAllLoyaltyCards()
                    dao.clearAllIdPages()
                    dao.clearAllIdDocuments()
                    dao.clearAllQrProjects()
                    dao.clearAllQrDesignPresets()
                    dao.clearAllSecureNotes()
                    dao.clearAllNfcProjects()
                }
                payload.myCards.forEach { dao.upsertMyCard(it.copy(id = 0L, profilePhotoUri = remap(it.profilePhotoUri), companyLogoUri = remap(it.companyLogoUri))) }
                payload.savedContacts.forEach { dao.upsertContact(it.copy(id = 0L, profilePhotoUri = remap(it.profilePhotoUri), backPhotoUri = remap(it.backPhotoUri))) }
                payload.followUps.forEach { dao.upsertFollowUp(it.copy(id = 0L)) }
                payload.loyaltyCards.forEach { dao.upsertLoyaltyCard(it.copy(id = 0L, frontPhotoUri = remap(it.frontPhotoUri), backPhotoUri = remap(it.backPhotoUri))) }
                val pagesByUuid = payload.idPages.groupBy { it.documentUuid }
                payload.idDocuments.forEach { doc ->
                    dao.upsertIdDocument(doc.copy(id = 0L))
                    pagesByUuid[doc.stableUuid]?.let { list ->
                        dao.insertIdPagesBatch(list.map { it.copy(id = 0L, imageUri = remap(it.imageUri) ?: it.imageUri) })
                    }
                }
                payload.qrProjects.forEach { dao.upsertQrProject(it.copy(id = 0L, logoUri = remap(it.logoUri))) }
                payload.qrDesignPresets.forEach { dao.upsertQrDesignPreset(it.copy(id = 0L)) }
                payload.secureNotes.forEach { dao.upsertSecureNote(it.copy(id = 0L)) }
                payload.nfcProjects.forEach { dao.upsertNfcProject(it.copy(id = 0L)) }
            }

            payload.preferences?.let { p ->
                LanguageManager.saveLanguage(context, p.languageCode)
                LanguageManager.saveThemeOverride(context, when (p.darkThemeMode) { "LIGHT" -> false; "DARK" -> true; else -> null })
                LanguageManager.setNotificationsEnabled(context, p.notificationsEnabled)
                ThemeContrastHelper.saveAppTheme(context, p.appThemeConfig)
                EventModeHelper.save(context, p.eventMode)
            }

            FollowUpScheduler.rescheduleAllPending(context)
            IdExpiryReminderScheduler.rescheduleAll(context)
            CardLinkWidgetUpdater.updateAllWidgets(context)
            SecurityHardeningManager.logAuditEventAsync(context, "MASTER_SNAPSHOT_RESTORED", "Backup", true, "Snapshot $snapshotId restored")

            DetailedRestoreResult(
                myCardsRestored = payload.myCards.size,
                contactsRestored = payload.savedContacts.size,
                followUpsRestored = payload.followUps.size,
                loyaltyCardsRestored = payload.loyaltyCards.size,
                myIdsRestored = payload.idDocuments.size,
                qrProjectsRestored = payload.qrProjects.size,
                assetsRestored = assetsRestored
            )
        }
    }

    private const val RECOVERY_FILE_NAME = "pre_restore_recovery_snapshot.cardlink"

    fun hasVerifiedPreRestoreRecovery(context: Context): Boolean {
        val f = File(context.filesDir, RECOVERY_FILE_NAME)
        return f.exists() && f.length() > 100L
    }

    private suspend fun capturePreRestoreRecoverySnapshot(context: Context): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val dao = CardLinkDatabase.getDatabase(context).dao()
            val now = System.currentTimeMillis()
            val payload = MasterSnapshotPayload(
                snapshotId = "pre_restore_$now",
                createdAtTimestamp = now,
                myCards = dao.getAllMyCardsSnapshot(),
                savedContacts = dao.getAllContactsSnapshot(),
                followUps = dao.getAllFollowUpsSnapshot(),
                loyaltyCards = dao.getAllLoyaltyCardsSnapshot(),
                idDocuments = dao.getAllIdDocumentsSnapshot(),
                idPages = dao.getAllIdPagesSnapshot(),
                qrProjects = dao.getAllQrProjectsSnapshot(),
                qrDesignPresets = dao.getAllQrDesignPresetsSnapshot(),
                secureNotes = dao.getAllSecureNotesSnapshot()
            )
            val recoveryFile = File(context.filesDir, RECOVERY_FILE_NAME)
            val tmpFile = File(context.cacheDir, "rec_tmp_$now.cardlink")
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmpFile))).use { zos ->
                zos.putNextEntry(ZipEntry("recovery_snapshot.json"))
                zos.write(json.encodeToString(payload).toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            if (tmpFile.exists() && tmpFile.length() > 50L) {
                tmpFile.copyTo(recoveryFile, overwrite = true)
                tmpFile.delete()
                true
            } else false
        }.getOrDefault(false)
    }

    suspend fun undoLastRestore(context: Context): Result<DetailedRestoreResult> = withContext(Dispatchers.IO) {
        runCatching {
            val recoveryFile = File(context.filesDir, RECOVERY_FILE_NAME)
            require(recoveryFile.exists()) { "No verified pre-restore recovery snapshot is available." }
            var snapBytes: ByteArray? = null
            ZipInputStream(BufferedInputStream(FileInputStream(recoveryFile))).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    if (e.name == "recovery_snapshot.json") {
                        snapBytes = zis.readBytes()
                        break
                    }
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }
            val bytes = snapBytes ?: error("Recovery snapshot is corrupted.")
            val payload = json.decodeFromString<MasterSnapshotPayload>(bytes.toString(Charsets.UTF_8))
            val db = CardLinkDatabase.getDatabase(context)
            val dao = db.dao()
            db.withTransaction {
                dao.clearAllMyCards()
                dao.clearAllContacts()
                dao.clearAllFollowUps()
                dao.clearAllLoyaltyCards()
                dao.clearAllIdPages()
                dao.clearAllIdDocuments()
                dao.clearAllQrProjects()
                dao.clearAllQrDesignPresets()
                dao.clearAllSecureNotes()
                payload.myCards.forEach { dao.upsertMyCard(it.copy(id = 0L)) }
                payload.savedContacts.forEach { dao.upsertContact(it.copy(id = 0L)) }
                payload.followUps.forEach { dao.upsertFollowUp(it.copy(id = 0L)) }
                payload.loyaltyCards.forEach { dao.upsertLoyaltyCard(it.copy(id = 0L)) }
                val pagesByUuid = payload.idPages.groupBy { it.documentUuid }
                payload.idDocuments.forEach { doc ->
                    dao.upsertIdDocument(doc.copy(id = 0L))
                    pagesByUuid[doc.stableUuid]?.let { list -> dao.insertIdPagesBatch(list.map { it.copy(id = 0L) }) }
                }
                payload.qrProjects.forEach { dao.upsertQrProject(it.copy(id = 0L)) }
                payload.qrDesignPresets.forEach { dao.upsertQrDesignPreset(it.copy(id = 0L)) }
                payload.secureNotes.forEach { dao.upsertSecureNote(it.copy(id = 0L)) }
                payload.nfcProjects.forEach { dao.upsertNfcProject(it.copy(id = 0L)) }
            }
            recoveryFile.delete()
            FollowUpScheduler.rescheduleAllPending(context)
            IdExpiryReminderScheduler.rescheduleAll(context)
            CardLinkWidgetUpdater.updateAllWidgets(context)
            SecurityHardeningManager.logAuditEventAsync(context, "UNDO_RESTORE_COMPLETED", "Backup", true, "Pre-restore state recovered")
            DetailedRestoreResult(
                myCardsRestored = payload.myCards.size,
                contactsRestored = payload.savedContacts.size,
                followUpsRestored = payload.followUps.size,
                loyaltyCardsRestored = payload.loyaltyCards.size,
                myIdsRestored = payload.idDocuments.size,
                qrProjectsRestored = payload.qrProjects.size,
                assetsRestored = 0
            )
        }
    }

    private val ENCRYPTED_MAGIC = byteArrayOf('C'.code.toByte(), 'L'.code.toByte(), 'M'.code.toByte(), 'E'.code.toByte())
    private const val PBKDF2_ITERATIONS = 210_000
    private const val KEY_IS_ENCRYPTED = "master_backup_is_encrypted"

    fun isMasterBackupEncryptedPref(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_IS_ENCRYPTED, false)

    fun isFileEncryptedEnvelope(bytes: ByteArray): Boolean =
        bytes.size > 32 &&
            bytes[0] == ENCRYPTED_MAGIC[0] &&
            bytes[1] == ENCRYPTED_MAGIC[1] &&
            bytes[2] == ENCRYPTED_MAGIC[2] &&
            bytes[3] == ENCRYPTED_MAGIC[3]

    private fun deriveAes256Key(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = skf.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun encryptEnvelope(plainZipBytes: ByteArray, password: String): ByteArray {
        val rng = SecureRandom()
        val salt = ByteArray(16).also { rng.nextBytes(it) }
        val nonce = ByteArray(12).also { rng.nextBytes(it) }
        val key = deriveAes256Key(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        val ciphertext = cipher.doFinal(plainZipBytes)
        val out = ByteArrayOutputStream(4 + 16 + 12 + ciphertext.size)
        out.write(ENCRYPTED_MAGIC)
        out.write(salt)
        out.write(nonce)
        out.write(ciphertext)
        return out.toByteArray()
    }

    private fun decryptEnvelopeIfNeeded(rawBytes: ByteArray, password: String?): ByteArray {
        if (!isFileEncryptedEnvelope(rawBytes)) return rawBytes
        val pwd = password?.takeIf { it.isNotEmpty() }
            ?: error("Authentication Failed: This Master Backup is password-protected. Please enter your backup password.")
        val salt = rawBytes.copyOfRange(4, 20)
        val nonce = rawBytes.copyOfRange(20, 32)
        val ciphertext = rawBytes.copyOfRange(32, rawBytes.size)
        return try {
            val key = deriveAes256Key(pwd, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce))
            cipher.doFinal(ciphertext)
        } catch (_: Exception) {
            error("Authentication Failed: Incorrect backup password or corrupted Master Backup.")
        }
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private fun readAppVersionName(context: Context): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "10.0.0"
    }.getOrDefault("10.0.0")
}

class AutoBackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val info = MasterBackupManager.getMasterInfo(applicationContext)
        if (!info.isAccessible) return Result.success()
        val res = MasterBackupManager.updateMasterBackup(applicationContext)
        return if (res.isSuccess) Result.success() else Result.retry()
    }
}
