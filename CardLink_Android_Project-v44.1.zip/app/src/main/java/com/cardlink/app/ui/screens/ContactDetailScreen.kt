package com.cardlink.app.ui.screens

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.ui.components.FlippableContactCardViewer
import com.cardlink.app.ui.components.FullScreenContactCardDialog
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contact: SavedContactEntity,
    mySenderName: String,
    mySenderCompany: String = "",
    contactFollowUps: List<FollowUpEntity> = emptyList(),
    onSaveContact: (SavedContactEntity, String?) -> Unit,
    onToggleFavorite: (SavedContactEntity) -> Unit = {},
    onSyncToPhone: (SavedContactEntity, Boolean, String?) -> Unit = { _, _, _ -> },
    onAddFollowUp: (FollowUpEntity) -> Unit = {},
    onToggleFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteFollowUp: (FollowUpEntity) -> Unit = {},
    onSendMyCardBack: () -> Unit = {},
    onDeleteContact: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var isEditingNumbers by remember(contact.id) { mutableStateOf(false) }
    var phoneDraft by remember(contact) { mutableStateOf(contact.phone) }
    var whatsappDraft by remember(contact) { mutableStateOf(contact.whatsapp) }
    var showWaScheduleConfirmDialog by remember { mutableStateOf<SavedContactEntity?>(null) }

    var notes by remember(contact) { mutableStateOf(contact.notes) }
    var selectedTag by remember(contact) { mutableStateOf(contact.categoryTag) }
    var currentLat by remember(contact) { mutableStateOf(contact.latitude) }
    var currentLng by remember(contact) { mutableStateOf(contact.longitude) }
    var userGps by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var showTemplateSheetFor by remember { mutableStateOf<String?>(null) }
    var newActionTitle by remember { mutableStateOf("") }

    var showMoreActionSheet by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showFullScreenCard by remember { mutableStateOf(false) }
    var showDobDatePicker by remember { mutableStateOf(false) }
    var expandPersonalInfo by remember(contact.id) { mutableStateOf(!contact.dateOfBirthIso.isNullOrBlank()) }

    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val whatsAppTarget = contact.whatsapp.ifBlank { contact.phone }
    val hasPhone = primaryPhone.isNotBlank()
    val hasWhatsApp = whatsAppTarget.isNotBlank()
    val hasEmail = contact.email.isNotBlank()
    val hasLocation = contact.officeAddress.isNotBlank() || (currentLat != null && currentLng != null)

    val birthdayInfo = remember(contact.dateOfBirthIso) {
        ContactBirthdayHelper.computeBirthdayInfo(contact.dateOfBirthIso)
    }

    val tagOptions = listOf("General", "Client", "Vendor", "VIP", "Colleague", "Event")
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val shortDateFmt = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val hasPendingWaSchedules = remember(contactFollowUps) {
        contactFollowUps.any { !it.isCompleted && it.channel == "WHATSAPP" && it.status != "CANCELLED" }
    }

    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                val ts = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                notes = if (notes.isBlank()) "[$ts (Voice Note)] $spokenText" else "$notes\n[$ts (Voice Note)] $spokenText"
            }
        }
    }

    LaunchedEffect(contact.officeAddress) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
        if ((currentLat == null || currentLng == null) && contact.officeAddress.isNotBlank()) {
            GeoLocationHelper.geocodeAddress(context, contact.officeAddress)?.let { (la, lo) ->
                currentLat = la; currentLng = lo
                onSaveContact(contact.copy(latitude = la, longitude = lo), null)
            }
        }
    }

    val distanceKm = remember(userGps, currentLat, currentLng) {
        val u = userGps; val la = currentLat; val lo = currentLng
        if (u != null && la != null && lo != null) GeoLocationHelper.distanceInKm(u.first, u.second, la, lo) else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(contact.fullName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (contact.alternateName.isNotBlank()) {
                            Text(contact.alternateName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onToggleFavorite(contact)
                    }) {
                        Icon(
                            imageVector = if (contact.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (contact.isFavorite) "Remove from Favorites" else "Add to Favorites",
                            tint = if (contact.isFavorite) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showMoreActionSheet = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.action_more))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Interactive Tap-to-Flip Business Card Section (Single card surface; never duplicates static images)
            if (!contact.profilePhotoUri.isNullOrBlank() || !contact.backPhotoUri.isNullOrBlank()) {
                FlippableContactCardViewer(
                    frontUri = contact.profilePhotoUri,
                    backUri = contact.backPhotoUri,
                    contactName = contact.fullName,
                    onOpenFullScreen = { showFullScreenCard = true }
                )
            }

            // Subtitle: Designation • Company
            val roleLine = listOf(contact.designation, contact.companyName).filter { it.isNotBlank() }.joinToString(" • ")
            if (roleLine.isNotBlank()) {
                Text(roleLine, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
            }

            // Upcoming Birthday Callout (when DOB is set and birthday is within 30 days)
            if (birthdayInfo != null && birthdayInfo.isBirthdaySoon) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Cake, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(
                            text = if (birthdayInfo.daysUntilNextBirthday == 0) {
                                stringResource(R.string.contacts_birthday_today)
                            } else {
                                stringResource(R.string.contacts_birthday_in_days, birthdayInfo.daysUntilNextBirthday)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Device-Contact Duplicate Review Banner (only shown if Auto-Save found an unlinked match)
            if (contact.deviceContactSyncState == "DUPLICATE_REVIEW") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, Color(0xFFF59E0B))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.contacts_phone_dup_title), fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B), fontSize = 13.sp)
                        Text(stringResource(R.string.contacts_phone_dup_msg), style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onSyncToPhone(contact, false, contact.linkedDeviceContactId) }) {
                                Text("Update Existing", fontSize = 11.5.sp)
                            }
                            OutlinedButton(onClick = { onSyncToPhone(contact, true, null) }) {
                                Text("Create New", fontSize = 11.5.sp)
                            }
                            TextButton(onClick = { onSaveContact(contact.copy(deviceContactSyncState = "SKIPPED"), null) }) {
                                Text("Skip", fontSize = 11.5.sp)
                            }
                        }
                    }
                }
            }

            // 2. Context-Aware Quick Actions Row (Only shows actions when relevant data exists!)
            if (hasPhone || hasWhatsApp || hasEmail || hasLocation) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hasPhone) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchDialer(context, primaryPhone)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(stringResource(R.string.detail_call), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (hasWhatsApp) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(stringResource(R.string.detail_whatsapp_full), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (hasEmail) {
                        Button(
                            onClick = {
                                onSaveContact(contact.copy(lastContactedTimestamp = System.currentTimeMillis()), null)
                                ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(stringResource(R.string.detail_email), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (hasLocation) {
                        Button(
                            onClick = { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName, currentLat, currentLng) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(stringResource(R.string.detail_map), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            // Grouped Message Templates (WhatsApp Templates & Email Templates)
            if (hasWhatsApp || hasEmail) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.detail_msg_templates_header), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (hasWhatsApp) {
                            OutlinedButton(onClick = { showTemplateSheetFor = "WA" }, modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.detail_wa_templates), fontSize = 12.sp)
                            }
                        }
                        if (hasEmail) {
                            OutlinedButton(onClick = { showTemplateSheetFor = "EMAIL" }, modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.detail_email_templates), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 3. Phone & WhatsApp Numbers Card
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_phone_wa_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (!isEditingNumbers) {
                            TextButton(onClick = { phoneDraft = contact.phone; whatsappDraft = contact.whatsapp; isEditingNumbers = true }) { Text(stringResource(R.string.action_edit)) }
                        }
                    }
                    if (!isEditingNumbers) {
                        Text("${stringResource(R.string.detail_phone)}: ${contact.phone.ifBlank { stringResource(R.string.detail_not_set) }}", fontSize = 13.sp)
                        Text("${stringResource(R.string.detail_whatsapp)}: ${contact.whatsapp.ifBlank { stringResource(R.string.detail_not_set) }}", fontSize = 13.sp)
                    } else {
                        OutlinedTextField(value = phoneDraft, onValueChange = { phoneDraft = it }, label = { Text("Phone (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = whatsappDraft, onValueChange = { whatsappDraft = it }, label = { Text("WhatsApp (+880...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { phoneDraft = contact.phone; whatsappDraft = contact.whatsapp; isEditingNumbers = false }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_cancel)) }
                            Button(onClick = {
                                val cleanPhone = if (phoneDraft.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(phoneDraft)
                                val cleanWa = if (whatsappDraft.isBlank()) "" else PhoneContactsHelper.normalizeWithCountryCode(whatsappDraft)
                                if (cleanPhone.isNotBlank() && !PhoneContactsHelper.isValidInternationalOrLocalPhone(cleanPhone)) { Toast.makeText(context, "Invalid phone number", Toast.LENGTH_SHORT).show(); return@Button }
                                if (cleanWa.isNotBlank() && !PhoneContactsHelper.isValidInternationalOrLocalPhone(cleanWa)) { Toast.makeText(context, "Invalid WhatsApp number", Toast.LENGTH_SHORT).show(); return@Button }
                                val updated = contact.copy(phone = cleanPhone, whatsapp = cleanWa)
                                val waChanged = cleanWa != contact.whatsapp && cleanWa.isNotBlank()
                                if (waChanged && hasPendingWaSchedules) showWaScheduleConfirmDialog = updated
                                else { onSaveContact(updated, if (waChanged) cleanWa else null); isEditingNumbers = false; Toast.makeText(context, "Numbers updated", Toast.LENGTH_SHORT).show() }
                            }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.action_save)) }
                        }
                    }
                }
            }

            // 4. Business Information Section
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.detail_business_info_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        if (distanceKm != null) Text("$distanceKm km away", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    if (contact.companyName.isNotBlank()) Text("Company: ${contact.companyName}", style = MaterialTheme.typography.bodySmall)
                    if (contact.alternateCompany.isNotBlank()) Text("Organization (Alt): ${contact.alternateCompany}", style = MaterialTheme.typography.bodySmall)
                    if (contact.designation.isNotBlank()) Text("Designation: ${contact.designation}", style = MaterialTheme.typography.bodySmall)
                    if (contact.department.isNotBlank()) Text("Department: ${contact.department}", style = MaterialTheme.typography.bodySmall)
                    if (contact.email.isNotBlank()) Text("Email: ${contact.email}", style = MaterialTheme.typography.bodySmall)
                    if (contact.website.isNotBlank()) Text("Website: ${contact.website}", style = MaterialTheme.typography.bodySmall)
                    if (contact.officeAddress.isNotBlank()) Text("Address: ${contact.officeAddress}", style = MaterialTheme.typography.bodySmall)
                    if (currentLat != null && currentLng != null) {
                        Text("GPS Pin: ${GeoLocationHelper.formatCoordinates(currentLat, currentLng)}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { ContactActionLauncher.launchTurnByTurnNavigation(context, currentLat, currentLng, contact.officeAddress) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_directions), fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                            scope.launch {
                                val coords = (if (contact.officeAddress.isNotBlank()) GeoLocationHelper.geocodeAddress(context, contact.officeAddress) else null) ?: GeoLocationHelper.getCurrentGpsCoordinates(context)
                                if (coords != null) { currentLat = coords.first; currentLng = coords.second; onSaveContact(contact.copy(latitude = coords.first, longitude = coords.second), null); Toast.makeText(context, "GPS Pinned!", Toast.LENGTH_SHORT).show() }
                            }
                        }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_detect_gps), fontSize = 12.sp) }
                    }
                }
            }

            // 5. Personal Information & Date of Birth / Dynamic Age Section (Progressive Disclosure)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandPersonalInfo = !expandPersonalInfo },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.detail_personal_info_title), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Icon(if (expandPersonalInfo) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                    }

                    if (birthdayInfo != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(stringResource(R.string.contacts_dob_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(birthdayInfo.formattedDate, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.contacts_age_label), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(stringResource(R.string.contacts_age_years, birthdayInfo.ageYears), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    AnimatedVisibility(visible = expandPersonalInfo) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { showDobDatePicker = true },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Cake, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (birthdayInfo == null) stringResource(R.string.contacts_set_dob) else stringResource(R.string.contacts_change_dob), fontSize = 12.sp)
                                }
                                if (birthdayInfo != null) {
                                    TextButton(onClick = {
                                        onSaveContact(contact.copy(dateOfBirthIso = null), null)
                                        Toast.makeText(context, "Date of Birth cleared", Toast.LENGTH_SHORT).show()
                                    }) { Text(stringResource(R.string.action_clear), fontSize = 12.sp) }
                                }
                            }
                            if (contact.meetingContext.isNotBlank()) {
                                Text("Context: ${contact.meetingContext}", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("First Met: ${shortDateFmt.format(Date(contact.savedAtTimestamp))}", style = MaterialTheme.typography.bodySmall)
                            if (contact.lastContactedTimestamp > 0L) {
                                Text("Last Contacted: ${shortDateFmt.format(Date(contact.lastContactedTimestamp))}", style = MaterialTheme.typography.bodySmall)
                            }

                            // Category Tags inside Personal/Context section
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                tagOptions.forEach { tag ->
                                    FilterChip(selected = selectedTag == tag, onClick = { selectedTag = tag; onSaveContact(contact.copy(categoryTag = tag, notes = notes, latitude = currentLat, longitude = currentLng), null) }, label = { Text(tag) })
                                }
                            }
                        }
                    }
                }
            }

            // Subtle Non-Gamified Contact Information Completeness Checklist
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.detail_completeness_title), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = listOf(
                            if (hasPhone) "✓ Phone" else "○ Phone",
                            if (hasEmail) "✓ Email" else "○ Email",
                            if (contact.companyName.isNotBlank()) "✓ Company" else "○ Company",
                            if (birthdayInfo != null) "✓ Date of Birth" else "○ Date of Birth"
                        ).joinToString("  •  "),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            OutlinedButton(
                onClick = onSendMyCardBack,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Send, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.send_my_card_back_title), fontWeight = FontWeight.Bold)
            }

            // Meeting Brief + On-Device Voice-to-Contact Notes
            MeetingBriefAndVoiceNoteCard(
                contact = contact,
                contactFollowUps = contactFollowUps,
                onAppendNote = { transcript ->
                    val combined = if (contact.notes.isBlank()) transcript else "${contact.notes}\n• $transcript"
                    onSaveContact(contact.copy(notes = combined), null)
                }
            )

            // Follow-Ups & Tasks Card
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.detail_tasks_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newActionTitle, onValueChange = { newActionTitle = it }, label = { Text(stringResource(R.string.detail_add_task)) }, singleLine = true, modifier = Modifier.weight(1f))
                        Button(onClick = {
                            if (newActionTitle.isNotBlank()) {
                                val item = FollowUpEntity(contactId = contact.id, contactName = contact.fullName, companyName = contact.companyName, title = newActionTitle.trim(), dueAtTimestamp = System.currentTimeMillis() + 24L * 3600_000L)
                                onAddFollowUp(item); FollowUpScheduler.scheduleForItem(context, item); newActionTitle = ""
                            }
                        }) { Text(stringResource(R.string.action_add)) }
                    }
                    contactFollowUps.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(checked = item.isCompleted, onCheckedChange = { onToggleFollowUp(item) })
                                Column {
                                    Text(item.title, fontSize = 13.sp, textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None)
                                    Text(dateFmt.format(Date(item.dueAtTimestamp)), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            IconButton(onClick = { onDeleteFollowUp(item) }) { Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
            }

            // Lightweight Privacy-Safe Relationship Timeline
            val timelineFmt = remember { SimpleDateFormat("dd MMM", Locale.getDefault()) }
            val timelineEvents = remember(contact, contactFollowUps) {
                buildList {
                    val sourceLabel = if (contact.receivedVia.contains("OCR", true) || contact.receivedVia.contains("Scan", true)) {
                        "Business Card scanned"
                    } else "Contact added (${contact.receivedVia.ifBlank { "Manual" }})"
                    add(contact.savedAtTimestamp to sourceLabel)
                    if (contact.meetingContext.isNotBlank()) {
                        add(contact.savedAtTimestamp + 1L to "Event / Context tagged: ${contact.meetingContext}")
                    }
                    if (contact.notes.isNotBlank()) {
                        add(contact.savedAtTimestamp + 2L to "Note saved")
                    }
                    contactFollowUps.forEach { fu ->
                        add(fu.createdAtTimestamp to "Follow-Up scheduled: ${fu.title}")
                        if (fu.isCompleted) {
                            add(fu.dueAtTimestamp to "Follow-Up completed: ${fu.title}")
                        }
                    }
                }.sortedByDescending { it.first }
            }
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Timeline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(stringResource(R.string.relationship_timeline_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                    }
                    timelineEvents.take(8).forEach { (ts, desc) ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(timelineFmt.format(Date(ts)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(desc, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            OutlinedTextField(
                value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.detail_notes_label)) },
                modifier = Modifier.fillMaxWidth(), minLines = 3,
                trailingIcon = {
                    IconButton(onClick = {
                        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak meeting notes...")
                        }
                        runCatching { speechRecognizerLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Speech recognition not available", Toast.LENGTH_SHORT).show() }
                    }) { Icon(Icons.Default.Mic, "Voice Dictation", tint = MaterialTheme.colorScheme.primary) }
                }
            )
            Button(
                onClick = {
                    onSaveContact(contact.copy(notes = notes, categoryTag = selectedTag, latitude = currentLat, longitude = currentLng), null)
                    Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.detail_save_notes)) }
        }
    }

    // Native Material3 DatePickerDialog for Date of Birth (prevents impossible future dates)
    if (showDobDatePicker) {
        val nowMs = remember { System.currentTimeMillis() }
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = ContactBirthdayHelper.isoDateToMillis(contact.dateOfBirthIso) ?: (nowMs - 30L * 365L * 24L * 3600_000L),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= nowMs
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDobDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { pickedMs ->
                        val iso = ContactBirthdayHelper.millisToIsoDate(pickedMs)
                        onSaveContact(contact.copy(dateOfBirthIso = iso), null)
                        expandPersonalInfo = true
                    }
                    showDobDatePicker = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showDobDatePicker = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }

    // Universal ⋮ More Action Sheet (Send My Card Back, Share .vcf, Save to Phone Contacts, Full-Screen Card, Delete)
    if (showMoreActionSheet) {
        val sheetActions = buildList {
            add(CardLinkSheetAction(Icons.Default.Send, stringResource(R.string.send_my_card_back_title), onClick = onSendMyCardBack))
            add(CardLinkSheetAction(Icons.Default.Share, stringResource(R.string.share_contact_vcf_btn)) {
                CardShareHelper.shareSavedContactVcf(context, contact)
            })
            add(CardLinkSheetAction(Icons.Default.PersonAdd, stringResource(R.string.contacts_save_to_phone_btn)) {
                CardShareHelper.exportToAndroidContacts(context, contact)
            })
            if (!contact.profilePhotoUri.isNullOrBlank() || !contact.backPhotoUri.isNullOrBlank()) {
                add(CardLinkSheetAction(Icons.Default.ZoomOutMap, stringResource(R.string.card_view_fullscreen)) {
                    showFullScreenCard = true
                })
            }
            add(CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) {
                showDeleteConfirmDialog = true
            })
        }
        CardLinkActionSheet(
            title = contact.fullName,
            actions = sheetActions,
            onDismiss = { showMoreActionSheet = false }
        )
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Contact?", fontWeight = FontWeight.Bold) },
            text = { Text("Remove ${contact.fullName} and associated card images from CardLink?") },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirmDialog = false; onDeleteContact() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirmDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showFullScreenCard) {
        FullScreenContactCardDialog(
            frontUri = contact.profilePhotoUri,
            backUri = contact.backPhotoUri,
            contactName = contact.fullName,
            onDismiss = { showFullScreenCard = false }
        )
    }

    if (showWaScheduleConfirmDialog != null) {
        val u = showWaScheduleConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showWaScheduleConfirmDialog = null },
            title = { Text(stringResource(R.string.detail_update_wa_title)) },
            text = { Text("Update scheduled WhatsApp recipients for this contact to ${u.whatsapp}?") },
            confirmButton = { Button(onClick = { onSaveContact(u, u.whatsapp); showWaScheduleConfirmDialog = null; isEditingNumbers = false }) { Text(stringResource(R.string.detail_update_btn)) } },
            dismissButton = { TextButton(onClick = { onSaveContact(u, null); showWaScheduleConfirmDialog = null; isEditingNumbers = false }) { Text(stringResource(R.string.detail_keep_existing)) } }
        )
    }

    if (showTemplateSheetFor != null) {
        val mode = showTemplateSheetFor!!
        AlertDialog(
            onDismissRequest = { showTemplateSheetFor = null },
            title = { Text(if (mode == "WA") "WhatsApp Templates" else "Email Templates", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MessageTemplateHelper.defaultTemplates.forEach { tmpl ->
                        val body = tmpl.buildBody(contact, mySenderName, mySenderCompany)
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            if (mode == "WA") ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName, body)
                            else ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName, tmpl.buildSubject(contact, mySenderName, mySenderCompany), body)
                            showTemplateSheetFor = null
                        }) { Column(modifier = Modifier.padding(10.dp)) { Text(tmpl.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp); Text(body, style = MaterialTheme.typography.bodySmall, maxLines = 2) } }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTemplateSheetFor = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
