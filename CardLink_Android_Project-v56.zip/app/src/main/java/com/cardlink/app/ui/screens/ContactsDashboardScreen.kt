package com.cardlink.app.ui.screens

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.components.ContactsFilterAndSortSheet
import com.cardlink.app.ui.components.ContactsSummaryCardsRow
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.util.ContactBirthdayHelper
import com.cardlink.app.util.DevicePhoneContact
import com.cardlink.app.util.GeoLocationHelper
import com.cardlink.app.util.PhoneContactsHelper
import kotlinx.coroutines.launch

@Composable
fun ContactsDashboardScreen(
    activeCard: BusinessCardEntity,
    contacts: List<SavedContactEntity>,
    allContacts: List<SavedContactEntity>,
    totalContactsCount: Int,
    favoriteContactsCount: Int,
    searchQuery: String,
    autoOpenContactsImport: Boolean,
    onConsumedAutoImport: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenContact: (Long) -> Unit,
    onScanQr: () -> Unit,
    onScanCard: () -> Unit,
    onSaveContact: (SavedContactEntity, String?) -> Unit,
    onDeleteContact: (SavedContactEntity) -> Unit
) {
    val context = LocalContext.current
    var showDuplicateMergeDialog by remember { mutableStateOf(false) }
    var showPhoneImportSheet by remember { mutableStateOf(autoOpenContactsImport) }
    var isFabExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (autoOpenContactsImport) onConsumedAutoImport()
    }

    // Close expandable + menu if navigating away
    DisposableEffect(Unit) {
        onDispose { isFabExpanded = false }
    }

    // System back closes expanded menu first before leaving Contacts
    BackHandler(enabled = isFabExpanded) {
        isFabExpanded = false
    }

    val fabRotation by animateFloatAsState(
        targetValue = if (isFabExpanded) 45f else 0f,
        animationSpec = tween(durationMillis = 200),
        label = "contacts_fab_rotation"
    )

    val duplicatesMap = remember(contacts) {
        val map = mutableMapOf<String, MutableList<SavedContactEntity>>()
        contacts.forEach { c ->
            val key = c.phone.filter { it.isDigit() }.takeLast(8).ifBlank { c.fullName.trim().lowercase() }
            if (key.length >= 4) map.getOrPut(key) { mutableListOf() }.add(c)
        }
        map.values.filter { it.size > 1 }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            var selectedFilterTag by remember { mutableStateOf("All") }
            var selectedSourceFilter by remember { mutableStateOf("ALL") }
            var onlyFavorites by remember { mutableStateOf(false) }
            var onlyBirthdaySoon by remember { mutableStateOf(false) }
            var selectedSort by remember { mutableStateOf("FAVORITES_FIRST") }
            var showFilterSortSheet by remember { mutableStateOf(false) }

            var myCurrentGps by remember { mutableStateOf(GeoLocationHelper.getCurrentGpsCoordinates(context)) }
            val radarLocLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                myCurrentGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
            }

            // Clean Contacts Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(stringResource(R.string.contacts_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    if (duplicatesMap.isNotEmpty()) {
                        Text("${duplicatesMap.size} duplicate group(s) found", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (duplicatesMap.isNotEmpty()) {
                        OutlinedButton(onClick = { showDuplicateMergeDialog = true }) {
                            Text(stringResource(R.string.action_merge), fontSize = 12.sp)
                        }
                    }
                    IconButton(onClick = { showFilterSortSheet = true }) {
                        Icon(
                            Icons.Default.Tune,
                            contentDescription = stringResource(R.string.contacts_filter_sort_title),
                            tint = if (onlyFavorites || onlyBirthdaySoon || selectedSourceFilter != "ALL" || selectedFilterTag != "All") MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                }
            }

            // 2 Compact Reactive Summary Cards immediately above Search: [ Total Contacts ] | [ Favorites ]
            ContactsSummaryCardsRow(
                totalCount = totalContactsCount,
                favoriteCount = favoriteContactsCount,
                isFavoritesFilterActive = onlyFavorites,
                onSelectAll = {
                    onlyFavorites = false
                    onlyBirthdaySoon = false
                    selectedFilterTag = "All"
                    selectedSourceFilter = "ALL"
                },
                onSelectFavorites = {
                    onlyFavorites = !onlyFavorites
                }
            )

            val primaryFilterChips = listOf("All", "Favorites", "Client", "Vendor", "VIP")
            val filteredContacts = remember(contacts, selectedFilterTag, selectedSourceFilter, onlyFavorites, onlyBirthdaySoon, selectedSort, myCurrentGps) {
                val base = contacts.filter { c ->
                    val tagMatch = when (selectedFilterTag) {
                        "All" -> true
                        "Nearby (<5 km)" -> {
                            val u = myCurrentGps ?: (activeCard.latitude?.let { lat -> activeCard.longitude?.let { lng -> Pair(lat, lng) } })
                            if (u == null) (c.latitude != null && c.longitude != null)
                            else (c.latitude != null && c.longitude != null && GeoLocationHelper.distanceInKm(u.first, u.second, c.latitude, c.longitude) <= 5.0)
                        }
                        else -> c.categoryTag.equals(selectedFilterTag, true)
                    }
                    val favMatch = !onlyFavorites || c.isFavorite
                    val bdayMatch = !onlyBirthdaySoon || (ContactBirthdayHelper.computeBirthdayInfo(c.dateOfBirthIso)?.isBirthdaySoon == true)
                    val srcMatch = when (selectedSourceFilter) {
                        "ALL" -> true
                        "SCANNED" -> c.receivedVia.contains("OCR", true) || c.receivedVia.contains("Scan", true)
                        "DUAL" -> c.receivedVia.contains("Dual", true) || (!c.profilePhotoUri.isNullOrBlank() && !c.backPhotoUri.isNullOrBlank())
                        "PHONE" -> c.receivedVia.contains("Phone", true)
                        "QR" -> c.receivedVia.contains("QR", true) || c.receivedVia.contains("NFC", true) || c.receivedVia.contains("Nearby", true)
                        else -> true
                    }
                    tagMatch && favMatch && bdayMatch && srcMatch
                }
                when (selectedSort) {
                    "NAME_AZ" -> base.sortedBy { it.fullName.lowercase() }
                    "NAME_ZA" -> base.sortedByDescending { it.fullName.lowercase() }
                    "RECENT_ADDED" -> base.sortedByDescending { it.savedAtTimestamp }
                    else -> base.sortedWith(compareByDescending<SavedContactEntity> { it.isFavorite }.thenByDescending { it.savedAtTimestamp })
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text(stringResource(R.string.contacts_search_placeholder)) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                primaryFilterChips.forEach { chip ->
                    val isSel = if (chip == "Favorites") onlyFavorites else (!onlyFavorites && selectedFilterTag == chip)
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            if (chip == "Favorites") {
                                onlyFavorites = !onlyFavorites
                            } else {
                                onlyFavorites = false
                                selectedFilterTag = chip
                                if (chip == "Nearby (<5 km)") {
                                    radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                }
                            }
                        },
                        label = { Text(chip) }
                    )
                }
                FilterChip(
                    selected = false,
                    onClick = { showFilterSortSheet = true },
                    label = { Text(stringResource(R.string.contacts_more_filters)) }
                )
            }

            if (showFilterSortSheet) {
                ContactsFilterAndSortSheet(
                    selectedTag = selectedFilterTag,
                    selectedSource = selectedSourceFilter,
                    onlyFavorites = onlyFavorites,
                    onlyBirthdaySoon = onlyBirthdaySoon,
                    selectedSort = selectedSort,
                    onApply = { tag, src, fav, bday, sort ->
                        selectedFilterTag = tag
                        selectedSourceFilter = src
                        onlyFavorites = fav
                        onlyBirthdaySoon = bday
                        selectedSort = sort
                        if (tag == "Nearby (<5 km)") {
                            radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        }
                    },
                    onDismiss = { showFilterSortSheet = false }
                )
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 88.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredContacts, key = { it.id }) { contact ->
                    val compactSource = when {
                        !contact.profilePhotoUri.isNullOrBlank() && !contact.backPhotoUri.isNullOrBlank() -> "Dual-Sided"
                        contact.receivedVia.contains("OCR", true) || contact.receivedVia.contains("Scan", true) -> "Scanned"
                        contact.receivedVia.contains("Phone", true) -> "Phone"
                        contact.receivedVia.contains("Nearby", true) -> "Nearby"
                        contact.receivedVia.contains("NFC", true) -> "NFC"
                        else -> "QR"
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenContact(contact.id) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (!contact.profilePhotoUri.isNullOrBlank()) {
                                VaultImage(
                                    uriString = contact.profilePhotoUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    maxEdgePx = 220,
                                    cacheBustKey = "${contact.id}_front_${contact.frontCropRevision}",
                                    modifier = Modifier
                                        .size(54.dp, 36.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                )
                            } else {
                                Surface(
                                    modifier = Modifier.size(40.dp),
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = contact.fullName.take(2).uppercase(),
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }

                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = contact.fullName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (contact.isFavorite) {
                                        Icon(Icons.Default.Star, contentDescription = "Favorite", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                    }
                                }
                                val subLine = listOf(contact.designation, contact.companyName).filter { it.isNotBlank() }.joinToString(" • ")
                                if (subLine.isNotBlank()) {
                                    Text(
                                        text = subLine,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                            ) {
                                Text(
                                    text = compactSource,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.5.sp,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Outside-tap scrim to close expandable + menu
        if (isFabExpanded) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.42f))
                    .clickable { isFabExpanded = false }
            )
        }

        // Expandable Floating + Speed-Dial Menu (Import Contacts, Scan QR, Scan Card)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnimatedVisibility(
                visible = isFabExpanded,
                enter = fadeIn(tween(200)) + expandVertically(tween(200), expandFrom = Alignment.Bottom),
                exit = fadeOut(tween(180)) + shrinkVertically(tween(180), shrinkTowards = Alignment.Bottom)
            ) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        onClick = {
                            isFabExpanded = false
                            showPhoneImportSheet = true
                        },
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.PersonSearch, contentDescription = stringResource(R.string.contacts_import_short), tint = MaterialTheme.colorScheme.primary)
                            Text(stringResource(R.string.contacts_import_short), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }

                    Surface(
                        onClick = {
                            isFabExpanded = false
                            onScanQr()
                        },
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = stringResource(R.string.home_scan_qr), tint = MaterialTheme.colorScheme.primary)
                            Text(stringResource(R.string.home_scan_qr), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }

                    Surface(
                        onClick = {
                            isFabExpanded = false
                            onScanCard()
                        },
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.DocumentScanner, contentDescription = stringResource(R.string.home_scan_card), tint = MaterialTheme.colorScheme.primary)
                            Text(stringResource(R.string.home_scan_card), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                }
            }

            FloatingActionButton(
                onClick = { isFabExpanded = !isFabExpanded },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (isFabExpanded) stringResource(R.string.contacts_fab_close) else stringResource(R.string.contacts_fab_open),
                    modifier = Modifier.rotate(fabRotation)
                )
            }
        }

        if (showPhoneImportSheet) {
            PhoneContactsImportDialog(existingContacts = allContacts, onDismiss = { showPhoneImportSheet = false }) { contactToSave, existingDup, mode ->
                when (mode) {
                    "SKIP" -> Unit
                    "MERGE" -> if (existingDup != null) {
                        onSaveContact(existingDup.copy(phone = existingDup.phone.ifBlank { contactToSave.phone }, whatsapp = existingDup.whatsapp.ifBlank { contactToSave.whatsapp }, email = existingDup.email.ifBlank { contactToSave.email }), null)
                    } else onSaveContact(contactToSave, null)
                    else -> onSaveContact(contactToSave, null)
                }
            }
        }

        if (showDuplicateMergeDialog && duplicatesMap.isNotEmpty()) {
            AlertDialog(
                onDismissRequest = { showDuplicateMergeDialog = false },
                title = { Text(stringResource(R.string.contacts_merge_title), fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        duplicatesMap.forEach { group ->
                            val primary = group.first(); val dups = group.drop(1)
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Primary: ${primary.fullName}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Button(onClick = {
                                        val combinedNotes = (listOf(primary.notes) + dups.map { it.notes }).filter { it.isNotBlank() }.joinToString("\n---\n")
                                        onSaveContact(primary.copy(notes = combinedNotes), null)
                                        dups.forEach { onDeleteContact(it) }
                                        showDuplicateMergeDialog = false
                                    }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contacts_merge_group)) }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showDuplicateMergeDialog = false }) { Text(stringResource(R.string.action_close)) } }
            )
        }
    }
}

@Composable
private fun PhoneContactsImportDialog(
    existingContacts: List<SavedContactEntity>,
    onDismiss: () -> Unit,
    onImportContact: (SavedContactEntity, SavedContactEntity?, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var deviceContacts by remember { mutableStateOf<List<DevicePhoneContact>>(emptyList()) }
    var permissionDenied by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var primaryPhoneOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var whatsappOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var showPreviewStep by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { permissionDenied = false; scope.launch { deviceContacts = PhoneContactsHelper.loadDeviceContacts(context) } }
        else permissionDenied = true
    }

    LaunchedEffect(Unit) {
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            deviceContacts = PhoneContactsHelper.loadDeviceContacts(context)
        } else permLauncher.launch(Manifest.permission.READ_CONTACTS)
    }

    val filtered = remember(deviceContacts, search) {
        deviceContacts.filter { search.isBlank() || it.displayName.contains(search, true) || it.phones.any { p -> p.contains(search, true) } }
    }
    val chosenList = remember(deviceContacts, selectedIds) { deviceContacts.filter { it.contactId in selectedIds } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (showPreviewStep) "${stringResource(R.string.contacts_import_preview)} (${chosenList.size})" else stringResource(R.string.contacts_import_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (permissionDenied) Text(stringResource(R.string.contacts_perm_denied), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (!showPreviewStep) {
                    OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text(stringResource(R.string.contacts_import_search)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    filtered.take(30).forEach { dc ->
                        val isSel = dc.contactId in selectedIds
                        Card(modifier = Modifier.fillMaxWidth().clickable { selectedIds = if (isSel) selectedIds - dc.contactId else selectedIds + dc.contactId }) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = isSel, onCheckedChange = { selectedIds = if (it) selectedIds + dc.contactId else selectedIds - dc.contactId })
                                Column { Text(dc.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(dc.phones.firstOrNull().orEmpty(), style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                } else {
                    chosenList.forEach { dc ->
                        val chosenPhone = primaryPhoneOverride[dc.contactId] ?: dc.phones.firstOrNull().orEmpty()
                        val chosenEmail = dc.emails.firstOrNull().orEmpty()
                        val waVal = whatsappOverride[dc.contactId].orEmpty()
                        val dup = remember(dc, chosenPhone, chosenEmail, existingContacts) { PhoneContactsHelper.findDuplicateContact(existingContacts, dc.displayName, chosenPhone, chosenEmail) }
                        var dupAction by remember(dc.contactId) { mutableStateOf(if (dup != null) "MERGE" else "IMPORT") }
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(dc.displayName, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                if (dc.phones.size > 1) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        dc.phones.forEach { p -> FilterChip(selected = chosenPhone == p, onClick = { primaryPhoneOverride = primaryPhoneOverride + (dc.contactId to p) }, label = { Text(p, fontSize = 11.sp) }) }
                                    }
                                }
                                OutlinedTextField(value = waVal, onValueChange = { whatsappOverride = whatsappOverride + (dc.contactId to it) }, label = { Text(stringResource(R.string.contacts_wa_optional)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                if (dup != null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("SKIP" to "Skip", "MERGE" to "Merge", "IMPORT" to "Separate").forEach { (k, l) -> FilterChip(selected = dupAction == k, onClick = { dupAction = k }, label = { Text(l, fontSize = 11.sp) }) }
                                    }
                                }
                                Button(onClick = {
                                    val entity = SavedContactEntity(
                                        fullName = dc.displayName, designation = dc.jobTitle, companyName = dc.organization,
                                        phone = if (chosenPhone.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(chosenPhone) else "",
                                        whatsapp = if (waVal.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(waVal) else "",
                                        email = chosenEmail, receivedVia = "Phone Contacts"
                                    )
                                    onImportContact(entity, dup, dupAction)
                                    selectedIds = selectedIds - dc.contactId
                                }, modifier = Modifier.fillMaxWidth()) { Text("Apply (${dupAction.lowercase()})") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!permissionDenied && selectedIds.isNotEmpty() && !showPreviewStep) Button(onClick = { showPreviewStep = true }) { Text("Preview (${selectedIds.size})") }
            else TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        },
        dismissButton = { if (showPreviewStep) TextButton(onClick = { showPreviewStep = false }) { Text(stringResource(R.string.action_back)) } }
    )
}
