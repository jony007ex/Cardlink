package com.cardlink.app.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cardlink.app.R
import com.cardlink.app.util.CardCropMetadata
import com.cardlink.app.util.SmartCardCropEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

/**
 * Hybrid Smart Business Card Crop Dialog:
 * - Supports fast Auto-Crop preview (startInManualAdjust = false -> Use Crop / Adjust)
 *   AND Post-Save Manual Adjust (startInManualAdjust = true -> Auto | Rotate | Original | Reset | Done -> Save Crop / Continue Editing).
 * - Enforces convex non-crossing 4-point perspective quads in real time.
 * - Renders perspective previews off the main UI thread (Dispatchers.Default) and preserves exact aspect ratio.
 * - Original encrypted bitmap is NEVER overwritten.
 */
@Composable
fun SmartCardCropDialog(
    sourceBitmap: Bitmap,
    initialMetadata: CardCropMetadata? = null,
    startInManualAdjust: Boolean = false,
    onConfirm: (croppedBitmap: Bitmap, metadata: CardCropMetadata) -> Unit,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val sanitizedInitial = remember(sourceBitmap, initialMetadata) {
        initialMetadata?.let { SmartCardCropEngine.sanitizeMetadata(it) }
    }
    var detectedAutoMeta by remember(sourceBitmap) { mutableStateOf<CardCropMetadata?>(null) }
    var userTouchedCorners by remember(sourceBitmap) { mutableStateOf(false) }
    var meta by remember(sourceBitmap, sanitizedInitial) { mutableStateOf(sanitizedInitial ?: CardCropMetadata()) }

    // Run edge detection off the main UI thread so high-res camera images never drop frames
    LaunchedEffect(sourceBitmap) {
        val auto = withContext(Dispatchers.Default) { SmartCardCropEngine.detectAutoCrop(sourceBitmap) }
        detectedAutoMeta = auto
        if (sanitizedInitial == null && !userTouchedCorners) {
            meta = auto
        }
    }
    var isAdjustMode by remember(startInManualAdjust) { mutableStateOf(startInManualAdjust) }
    var hasEnteredManualEdit by remember(startInManualAdjust) { mutableStateOf(startInManualAdjust) }
    var isApplyingFinal by remember { mutableStateOf(false) }

    // Only render the perspective-corrected preview when NOT dragging corners in manual adjust mode
    val previewBitmap by produceState<Bitmap?>(initialValue = null, sourceBitmap, meta, isAdjustMode) {
        if (!isAdjustMode) {
            value = withContext(Dispatchers.Default) {
                SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta, maxOutputEdgePx = 1600)
            }
        }
    }

    val rotatedSourceForManual = remember(sourceBitmap, meta.rotationDegrees) {
        val normRot = ((meta.rotationDegrees % 360) + 360) % 360
        if (normRot == 0) sourceBitmap
        else {
            val m = android.graphics.Matrix().apply { postRotate(normRot.toFloat()) }
            Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.width, sourceBitmap.height, m, true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when {
                                isAdjustMode -> stringResource(R.string.crop_adjust_title)
                                hasEnteredManualEdit -> stringResource(R.string.crop_preview_title)
                                else -> stringResource(R.string.crop_detected_title)
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isAdjustMode) stringResource(R.string.crop_adjust_sub) else stringResource(R.string.crop_detected_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                    }
                }

                // Main Visual Area
                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.88f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isAdjustMode) {
                        val readyBmp = previewBitmap
                        if (readyBmp != null) {
                            Image(
                                bitmap = readyBmp.asImageBitmap(),
                                contentDescription = "Rectified card preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(14.dp)
                            )
                        } else {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        val padDp = 16.dp
                        val availW = (maxWidth - padDp * 2).coerceAtLeast(80.dp)
                        val availH = (maxHeight - padDp * 2).coerceAtLeast(80.dp)
                        val imgRatio = (rotatedSourceForManual.width.toFloat() / rotatedSourceForManual.height.coerceAtLeast(1).toFloat())
                            .coerceIn(0.35f, 3.0f)
                        val boxRatio = availW.value / availH.value.coerceAtLeast(1f)
                        val fitW = if (imgRatio >= boxRatio) availW else availH * imgRatio
                        val fitH = if (imgRatio >= boxRatio) availW / imgRatio else availH

                        var boxSize by remember { mutableStateOf(IntSize.Zero) }
                        var activeCorner by remember { mutableIntStateOf(-1) }
                        val handleColor = MaterialTheme.colorScheme.primary

                        Box(
                            modifier = Modifier
                                .size(width = fitW, height = fitH)
                                .onSizeChanged { boxSize = it }
                                .pointerInput(meta.rotationDegrees, fitW, fitH) {
                                    detectDragGestures(
                                        onDragStart = { start ->
                                            if (boxSize.width <= 0 || boxSize.height <= 0) return@detectDragGestures
                                            val bw = boxSize.width.toFloat()
                                            val bh = boxSize.height.toFloat()
                                            val corners = listOf(
                                                Offset(meta.topLeftX * bw, meta.topLeftY * bh),
                                                Offset(meta.topRightX * bw, meta.topRightY * bh),
                                                Offset(meta.bottomRightX * bw, meta.bottomRightY * bh),
                                                Offset(meta.bottomLeftX * bw, meta.bottomLeftY * bh)
                                            )
                                            var bestIdx = -1
                                            var bestDist = 120f
                                            corners.forEachIndexed { idx, pt ->
                                                val d = hypot((start.x - pt.x).toDouble(), (start.y - pt.y).toDouble()).toFloat()
                                                if (d < bestDist) {
                                                    bestDist = d
                                                    bestIdx = idx
                                                }
                                            }
                                            activeCorner = bestIdx
                                        },
                                        onDragEnd = { activeCorner = -1 },
                                        onDragCancel = { activeCorner = -1 },
                                        onDrag = { change, dragAmount ->
                                            if (activeCorner < 0 || boxSize.width <= 0 || boxSize.height <= 0) return@detectDragGestures
                                            change.consume()
                                            val dx = dragAmount.x / boxSize.width.toFloat()
                                            val dy = dragAmount.y / boxSize.height.toFloat()
                                            val candidate = when (activeCorner) {
                                                0 -> meta.copy(
                                                    topLeftX = (meta.topLeftX + dx).coerceIn(0f, 0.92f),
                                                    topLeftY = (meta.topLeftY + dy).coerceIn(0f, 0.92f),
                                                    isOriginalFullFrame = false
                                                )
                                                1 -> meta.copy(
                                                    topRightX = (meta.topRightX + dx).coerceIn(0.08f, 1f),
                                                    topRightY = (meta.topRightY + dy).coerceIn(0f, 0.92f),
                                                    isOriginalFullFrame = false
                                                )
                                                2 -> meta.copy(
                                                    bottomRightX = (meta.bottomRightX + dx).coerceIn(0.08f, 1f),
                                                    bottomRightY = (meta.bottomRightY + dy).coerceIn(0.08f, 1f),
                                                    isOriginalFullFrame = false
                                                )
                                                3 -> meta.copy(
                                                    bottomLeftX = (meta.bottomLeftX + dx).coerceIn(0f, 0.92f),
                                                    bottomLeftY = (meta.bottomLeftY + dy).coerceIn(0.08f, 1f),
                                                    isOriginalFullFrame = false
                                                )
                                                else -> meta
                                            }
                                            // Reject crossing or collapsed zero-area quads in real time
                                            if (SmartCardCropEngine.isValidQuad(candidate)) {
                                                userTouchedCorners = true
                                                meta = candidate
                                            }
                                        }
                                    )
                                }
                        ) {
                            Image(
                                bitmap = rotatedSourceForManual.asImageBitmap(),
                                contentDescription = "Original card for crop adjustment",
                                contentScale = ContentScale.FillBounds,
                                modifier = Modifier.fillMaxSize()
                            )
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val p0 = Offset(meta.topLeftX * size.width, meta.topLeftY * size.height)
                                val p1 = Offset(meta.topRightX * size.width, meta.topRightY * size.height)
                                val p2 = Offset(meta.bottomRightX * size.width, meta.bottomRightY * size.height)
                                val p3 = Offset(meta.bottomLeftX * size.width, meta.bottomLeftY * size.height)

                                val path = Path().apply {
                                    moveTo(p0.x, p0.y)
                                    lineTo(p1.x, p1.y)
                                    lineTo(p2.x, p2.y)
                                    lineTo(p3.x, p3.y)
                                    close()
                                }
                                drawPath(path, color = handleColor, style = Stroke(width = 4.5f))
                                listOf(p0, p1, p2, p3).forEachIndexed { idx, pt ->
                                    val isActive = idx == activeCorner
                                    drawCircle(color = Color.White, radius = if (isActive) 22f else 18f, center = pt)
                                    drawCircle(color = handleColor, radius = if (isActive) 15f else 12f, center = pt)
                                }
                            }
                        }
                    }
                }

                // Essential 4-Tool Control Bar during Manual Adjust: Auto | Rotate | Original | Reset
                if (isAdjustMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val autoLbl = stringResource(R.string.crop_auto_short)
                        TextButton(
                            onClick = {
                                val targetBmp = rotatedSourceForManual
                                val curRot = meta.rotationDegrees
                                scope.launch {
                                    val detected = withContext(Dispatchers.Default) { SmartCardCropEngine.detectAutoCrop(targetBmp) }
                                    userTouchedCorners = true
                                    meta = detected.copy(rotationDegrees = curRot)
                                }
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = autoLbl }
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(autoLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val rotLbl = stringResource(R.string.crop_rotate_btn)
                        TextButton(
                            onClick = {
                                meta = meta.copy(rotationDegrees = (meta.rotationDegrees + 90) % 360)
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = rotLbl }
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(rotLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val origLbl = stringResource(R.string.crop_reset_original_short)
                        TextButton(
                            onClick = { meta = CardCropMetadata.fullOriginal(meta.rotationDegrees) },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = origLbl }
                        ) {
                            Text(origLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val resetLbl = stringResource(R.string.qa_reset_btn)
                        TextButton(
                            onClick = { meta = sanitizedInitial ?: detectedAutoMeta ?: CardCropMetadata() },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = resetLbl }
                        ) {
                            Text(resetLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!isAdjustMode) {
                        OutlinedButton(
                            onClick = {
                                isAdjustMode = true
                                hasEnteredManualEdit = true
                            },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Crop, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (hasEnteredManualEdit) stringResource(R.string.crop_continue_editing_btn) else stringResource(R.string.crop_adjust_btn),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Button(
                            onClick = {
                                isApplyingFinal = true
                                scope.launch {
                                    val rendered = withContext(Dispatchers.Default) {
                                        SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta, maxOutputEdgePx = 1800)
                                    }
                                    isApplyingFinal = false
                                    onConfirm(rendered, SmartCardCropEngine.sanitizeMetadata(meta))
                                }
                            },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            if (isApplyingFinal) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (hasEnteredManualEdit) stringResource(R.string.crop_save_btn) else stringResource(R.string.crop_use_btn),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = onDismiss,
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text(stringResource(R.string.action_cancel), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                hasEnteredManualEdit = true
                                isAdjustMode = false
                            },
                            enabled = !isApplyingFinal,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Check, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.ocr_done_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
