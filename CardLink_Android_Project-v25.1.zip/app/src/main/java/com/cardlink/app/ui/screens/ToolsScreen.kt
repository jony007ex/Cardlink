package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.EventModeConfig
import com.cardlink.app.util.PremiumExtrasHelper

@Composable
fun ToolsScreen(
    activeCard: BusinessCardEntity,
    eventMode: EventModeConfig,
    onOpenQrStudio: () -> Unit,
    onOpenQrScanner: () -> Unit,
    onOpenDualSideOcr: () -> Unit,
    onOpenLoyaltyCards: () -> Unit,
    onOpenMyIds: () -> Unit,
    onOpenEventMode: () -> Unit,
    onOpenMeetingBg: () -> Unit,
    onOpenQuickShare: () -> Unit,
    onLogShare: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showWallpaperConfirmDialog by remember { mutableStateOf(false) }
    var isApplyingWallpaper by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = stringResource(R.string.tools_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.tools_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        // 1. Card Tools
        ToolsSectionHeader(stringResource(R.string.tools_section_card))

        ToolItemCard(
            icon = Icons.Default.CardMembership,
            title = stringResource(R.string.loyalty_title),
            subtitle = stringResource(R.string.loyalty_tools_subtitle),
            onClick = onOpenLoyaltyCards
        )

        ToolItemCard(
            icon = Icons.Default.Badge,
            title = stringResource(R.string.my_ids_title),
            subtitle = stringResource(R.string.my_ids_tools_subtitle),
            onClick = onOpenMyIds
        )

        ToolItemCard(
            icon = Icons.Default.DocumentScanner,
            title = stringResource(R.string.tools_dual_ocr),
            subtitle = stringResource(R.string.tools_dual_ocr_sub),
            onClick = onOpenDualSideOcr
        )

        ToolItemCard(
            icon = Icons.Default.EventNote,
            title = if (eventMode.isActive) "${stringResource(R.string.home_event_mode_on)} ${eventMode.eventName}" else stringResource(R.string.tools_event_mode),
            subtitle = stringResource(R.string.tools_event_mode_sub),
            highlighted = eventMode.isActive,
            onClick = onOpenEventMode
        )

        // 2. QR Tools
        ToolsSectionHeader(stringResource(R.string.tools_section_qr))

        ToolItemCard(
            icon = Icons.Default.QrCode2,
            title = stringResource(R.string.qr_studio_title),
            subtitle = stringResource(R.string.qr_studio_tools_subtitle),
            onClick = onOpenQrStudio
        )

        ToolItemCard(
            icon = Icons.Default.QrCodeScanner,
            title = stringResource(R.string.tools_qr_scanner),
            subtitle = stringResource(R.string.tools_qr_scanner_sub),
            onClick = onOpenQrScanner
        )

        ToolItemCard(
            icon = Icons.Default.Contactless,
            title = stringResource(R.string.tools_quick_nfc_qr),
            subtitle = stringResource(R.string.tools_quick_nfc_qr_sub),
            onClick = onOpenQuickShare
        )

        // 3. Export & Utility Tools (Consolidated Premium Pro Tools)
        ToolsSectionHeader(stringResource(R.string.tools_section_export))

        ToolItemCard(
            icon = Icons.Default.VideoCameraFront,
            title = stringResource(R.string.tools_meeting_bg),
            subtitle = stringResource(R.string.tools_meeting_bg_sub),
            onClick = onOpenMeetingBg
        )

        ToolItemCard(
            icon = Icons.Default.Print,
            title = stringResource(R.string.tools_print_pdf),
            subtitle = stringResource(R.string.tools_print_pdf_sub),
            onClick = {
                onLogShare("Print-Ready PDF (3.5x2)")
                CardShareHelper.sharePrintReadyPhysicalCardPdf(context, activeCard)
            }
        )

        ToolItemCard(
            icon = Icons.Default.Draw,
            title = stringResource(R.string.tools_email_sig),
            subtitle = stringResource(R.string.tools_email_sig_sub),
            onClick = {
                PremiumExtrasHelper.copyEmailSignatureToClipboard(context, activeCard)
            }
        )

        // Lock-Screen QR Wallpaper (Set + Share consolidated without duplicating)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        color = GoldAccent.copy(alpha = 0.16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Wallpaper,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.tools_lock_wallpaper),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = stringResource(R.string.tools_lock_wallpaper_sub),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = true },
                        enabled = !isApplyingWallpaper,
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.share_set_wallpaper), fontSize = 12.sp) }

                    OutlinedButton(
                        onClick = { PremiumExtrasHelper.shareLockScreenWallpaper(context, activeCard) },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.share_wallpaper), fontSize = 12.sp) }
                }
            }
        }
    }

    if (showWallpaperConfirmDialog) {
        AlertDialog(
            onDismissRequest = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = false },
            title = { Text(stringResource(R.string.wallpaper_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.wallpaper_confirm_msg)) },
            confirmButton = {
                Button(
                    enabled = !isApplyingWallpaper,
                    onClick = {
                        if (isApplyingWallpaper) return@Button
                        isApplyingWallpaper = true
                        showWallpaperConfirmDialog = false
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) {
                                PremiumExtrasHelper.applyLockScreenWallpaper(context, activeCard)
                            }
                            isApplyingWallpaper = false
                            Toast.makeText(
                                context,
                                if (ok) context.getString(R.string.wallpaper_set_success)
                                else context.getString(R.string.wallpaper_set_failed),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                ) { Text(stringResource(R.string.wallpaper_confirm_action)) }
            },
            dismissButton = {
                TextButton(
                    enabled = !isApplyingWallpaper,
                    onClick = { showWallpaperConfirmDialog = false }
                ) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}

@Composable
private fun ToolsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = GoldAccent,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
private fun ToolItemCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = if (highlighted) BorderStroke(1.2.dp, Color(0xFF00E5FF)) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = if (highlighted) Color(0xFF00E5FF).copy(alpha = 0.16f) else GoldAccent.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (highlighted) Color(0xFF00E5FF) else GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
        }
    }
}
