package com.cardlink.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

enum class CardTemplate {
    EXECUTIVE_NAVY, MINIMAL_IVORY, CHARCOAL_GOLD, MODERN_SPLIT
}

@Serializable
@Entity(tableName = "my_cards")
data class BusinessCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileTitle: String = "Executive Profile",
    val isDefault: Boolean = true,
    val fullName: String = "",
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val publicCardUrl: String = "",
    val profilePhotoUri: String? = null,
    val companyLogoUri: String? = null,
    val template: CardTemplate = CardTemplate.EXECUTIVE_NAVY,
    val primaryColorHex: Long = 0xFF0A192F,
    val accentColorHex: Long = 0xFFD4AF37,
    val textColorHex: Long = 0xFFFFFFFF,
    val fontFamilyName: String = "Serif",
    val cornerRadiusDp: Int = 20,
    val sharePhone: Boolean = true,
    val shareWhatsapp: Boolean = true,
    val shareEmail: Boolean = true,
    val shareAddress: Boolean = true,
    val shareSocials: Boolean = true
) {
    fun resolveNfcShareUrl(): String {
        val candidate = listOf(publicCardUrl, linkedInUrl, website, facebookUrl)
            .firstOrNull { it.isNotBlank() }
            ?.trim()
            ?: "https://cardlink.app"
        return if (candidate.startsWith("http://", true) || candidate.startsWith("https://", true)) {
            candidate
        } else {
            "https://$candidate"
        }
    }

    fun sanitizedForSharing(): BusinessCardEntity = copy(
        phone = if (sharePhone) phone else "",
        whatsapp = if (shareWhatsapp) whatsapp else "",
        email = if (shareEmail) email else "",
        officeAddress = if (shareAddress) officeAddress else "",
        latitude = if (shareAddress) latitude else null,
        longitude = if (shareAddress) longitude else null,
        linkedInUrl = if (shareSocials) linkedInUrl else "",
        facebookUrl = if (shareSocials) facebookUrl else "",
        otherSocialUrl = if (shareSocials) otherSocialsOrEmpty() else "",
        profilePhotoUri = null,
        companyLogoUri = null
    )

    private fun otherSocialsOrEmpty(): String = otherSocialUrl
}

@Serializable
@Entity(tableName = "saved_contacts")
data class SavedContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val designation: String = "",
    val companyName: String = "",
    val department: String = "",
    val bio: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val email: String = "",
    val officeAddress: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val website: String = "",
    val linkedInUrl: String = "",
    val facebookUrl: String = "",
    val otherSocialUrl: String = "",
    val profilePhotoUri: String? = null,
    val notes: String = "",
    val receivedVia: String = "QR Code",
    val categoryTag: String = "General",
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "share_history")
data class ShareHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardProfileTitle: String,
    val method: String,
    val recipientInfo: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "follow_up_items")
data class FollowUpEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactId: Long,
    val contactName: String,
    val companyName: String = "",
    val title: String,
    val notes: String = "",
    val dueAtTimestamp: Long,
    val isCompleted: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)
