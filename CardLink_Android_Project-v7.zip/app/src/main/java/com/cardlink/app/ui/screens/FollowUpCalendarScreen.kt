package com.cardlink.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.PremiumExtrasHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class CalendarFilter(val label: String) {
    ALL("All Upcoming"),
    TODAY("Today"),
    TOMORROW("Tomorrow"),
    THIS_WEEK("This Week"),
    OVERDUE("Overdue"),
    COMPLETED("Completed")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FollowUpCalendarScreen(
    followUps: List<FollowUpEntity>,
    contacts: List<SavedContactEntity>,
    onAddFollowUp: (FollowUpEntity) -> Unit,
    onToggleCompleted: (FollowUpEntity) -> Unit,
    onDeleteFollowUp: (FollowUpEntity) -> Unit,
    onOpenContact: (Long) -> Unit
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableStateOf(CalendarFilter.ALL) }
    var showAddDialog by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val todayStart = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val tomorrowStart = todayStart + 24L * 60 * 60 * 1000
    val dayAfterTomorrowStart = tomorrowStart + 24L * 60 * 60 * 1000
    val weekEnd = todayStart + 7L * 24 * 60 * 60 * 1000

    val filteredList = remember(followUps, selectedFilter) {
        when (selectedFilter) {
            CalendarFilter.ALL -> followUps.filter { !it.isCompleted }
            CalendarFilter.TODAY -> followUps.filter { !it.isCompleted && it.dueAtTimestamp in todayStart until tomorrowStart }
            CalendarFilter.TOMORROW -> followUps.filter { !it.isCompleted && it.dueAtTimestamp in tomorrowStart until dayAfterTomorrowStart }
            CalendarFilter.THIS_WEEK -> followUps.filter { !it.isCompleted && it.dueAtTimestamp in todayStart..weekEnd }
            CalendarFilter.OVERDUE -> followUps.filter { !it.isCompleted && it.dueAtTimestamp < now }
            CalendarFilter.COMPLETED -> followUps.filter { it.isCompleted }
        }
    }

    val pendingCount = remember(followUps) { followUps.count { !it.isCompleted } }
    val todayCount = remember(followUps) { followUps.count { !it.isCompleted && it.dueAtTimestamp in todayStart until tomorrowStart } }
    val doneCount = remember(followUps) { followUps.count { it.isCompleted } }
    val dateFormatter = remember { SimpleDateFormat("EEE, dd MMM • hh:mm a", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = GoldAccent,
                contentColor = NavyPrimary,
                icon = { Icon(Icons.Default.AddAlert, null) },
                text = { Text("New Follow-Up", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Follow-Up Calendar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("In-app meetings, reminders & action items", style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.CalendarMonth, null, tint = GoldAccent, modifier = Modifier.size(32.dp))
            }

            // Summary KPI Strip
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalendarStatBox("Due Today", todayCount.toString(), NavyPrimary, GoldAccent, Modifier.weight(1f))
                CalendarStatBox("Pending", pendingCount.toString(), NavyPrimary, Color.White, Modifier.weight(1f))
                CalendarStatBox("Completed", doneCount.toString(), NavyPrimary, Color(0xFF4ADE80), Modifier.weight(1f))
            }

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalendarFilter.values().forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) }
                    )
                }
            }

            if (filteredList.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.EventAvailable, null, tint = GoldAccent, modifier = Modifier.size(44.dp))
                        Text("No follow-ups in '${selectedFilter.label}'", fontWeight = FontWeight.Bold)
                        Text(
                            "Tap 'New Follow-Up' below or schedule directly from any contact's detail page.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredList, key = { it.id }) { item ->
                        val isOverdue = !item.isCompleted && item.dueAtTimestamp < now
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { if (item.contactId > 0L) onOpenContact(item.contactId) },
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Checkbox(
                                            checked = item.isCompleted,
                                            onCheckedChange = { onToggleCompleted(item) }
                                        )
                                        Column {
                                            Text(
                                                text = item.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                            )
                                            Text(
                                                text = listOf(item.contactName, item.companyName).filter { it.isNotBlank() }.joinToString(" • "),
                                                color = GoldAccent,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = {
                                            val dummyContact = SavedContactEntity(
                                                id = item.contactId,
                                                fullName = item.contactName,
                                                companyName = item.companyName,
                                                notes = item.title + "\n" + item.notes
                                            )
                                            PremiumExtrasHelper.scheduleFollowUpMeeting(context, dummyContact)
                                        }) {
                                            Icon(Icons.Default.Event, contentDescription = "Sync to Google Calendar", tint = GoldAccent)
                                        }
                                        IconButton(onClick = { onDeleteFollowUp(item) }) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                if (item.notes.isNotBlank()) {
                                    Text(item.notes, style = MaterialTheme.typography.bodySmall)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = dateFormatter.format(Date(item.dueAtTimestamp)),
                                        fontSize = 12.sp,
                                        color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                        fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (isOverdue) {
                                        AssistChip(onClick = {}, label = { Text("Overdue", fontSize = 11.sp) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("Follow-up Meeting / Call") }
        var notes by remember { mutableStateOf("") }
        var selectedContact by remember { mutableStateOf(contacts.firstOrNull()) }
        var customContactName by remember { mutableStateOf("") }
        var selectedOffsetHours by remember { mutableStateOf(24) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Schedule Follow-Up", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Action Item / Meeting Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (contacts.isNotEmpty()) {
                        Text("Select Contact:", style = MaterialTheme.typography.labelSmall)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            contacts.take(12).forEach { c ->
                                FilterChip(
                                    selected = selectedContact?.id == c.id,
                                    onClick = { selectedContact = c },
                                    label = { Text(c.fullName) }
                                )
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = customContactName,
                            onValueChange = { customContactName = it },
                            label = { Text("Contact / Client Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text("When to Remind:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "Today (+3h)" to 3,
                            "Tomorrow (24h)" to 24,
                            "In 3 Days" to 72,
                            "Next Week (7d)" to 168
                        ).forEach { (label, hrs) ->
                            FilterChip(
                                selected = selectedOffsetHours == hrs,
                                onClick = { selectedOffsetHours = hrs },
                                label = { Text(label) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Checklist / Agenda Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val due = System.currentTimeMillis() + selectedOffsetHours * 3600L * 1000L
                    onAddFollowUp(
                        FollowUpEntity(
                            contactId = selectedContact?.id ?: 0L,
                            contactName = selectedContact?.fullName ?: customContactName.ifBlank { "General Follow-Up" },
                            companyName = selectedContact?.companyName.orEmpty(),
                            title = title.ifBlank { "Follow-Up" },
                            notes = notes,
                            dueAtTimestamp = due
                        )
                    )
                    showAddDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CalendarStatBox(
    label: String,
    count: String,
    bgColor: Color,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count, color = valueColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
        }
    }
}
