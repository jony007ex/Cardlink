package com.cardlink.app.util

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.provider.CalendarContract
import android.widget.Toast
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

object PremiumExtrasHelper {

    /**
     * Generates a Branded QR Code (Error Correction H) with an optional centered Company Logo.
     */
    fun generateBrandedQrBitmap(
        context: Context,
        card: BusinessCardEntity,
        sizePx: Int = 720
    ): Bitmap {
        val vcf = CardShareHelper.toVCardString(card)
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 2
        )
        val fgColor = card.primaryColorHex.toInt()
        val bgColor = Color.WHITE
        val bitMatrix = QRCodeWriter().encode(vcf.ifBlank { "CardLink" }, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        for (y in 0 until sizePx) {
            for (x in 0 until sizePx) {
                pixels[y * sizePx + x] = if (bitMatrix[x, y]) fgColor else bgColor
            }
        }
        val qrBitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        }

        val logoUriStr = card.companyLogoUri
        if (!logoUriStr.isNullOrBlank()) {
            val logoBmp = runCatching {
                val uri = Uri.parse(logoUriStr)
                if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
                else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()

            if (logoBmp != null) {
                val canvas = Canvas(qrBitmap)
                val badgeSize = (sizePx * 0.24f).toInt()
                val left = (sizePx - badgeSize) / 2f
                val top = (sizePx - badgeSize) / 2f

                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
                val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = card.accentColorHex.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 6f
                }
                val rect = RectF(left, top, left + badgeSize, top + badgeSize)
                canvas.drawRoundRect(rect, 22f, 22f, bgPaint)
                canvas.drawRoundRect(rect, 22f, 22f, borderPaint)

                val pad = 12f
                val logoDest = RectF(left + pad, top + pad, left + badgeSize - pad, top + badgeSize - pad)
                canvas.drawBitmap(logoBmp, null, logoDest, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        }
        return qrBitmap
    }

    /**
     * Renders a 1080x2400 Dark Executive Lock-Screen Wallpaper with the user's name & Branded QR.
     */
    fun renderLockScreenWallpaper(context: Context, card: BusinessCardEntity): Bitmap {
        val w = 1080
        val h = 2400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                card.primaryColorHex.toInt(),
                Color.parseColor("#020617"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt() }
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 68f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.accentColorHex.toInt()
            textSize = 38f
            textAlign = Paint.Align.CENTER
        }
        val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 30f
            textAlign = Paint.Align.CENTER
        }

        // Centered QR Card Container
        val qrSize = 560
        val qrLeft = (w - qrSize) / 2f
        val qrTop = 980f
        val cardRect = RectF(qrLeft - 45f, qrTop - 45f, qrLeft + qrSize + 45f, qrTop + qrSize + 45f)
        canvas.drawRoundRect(cardRect, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.accentColorHex.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        canvas.drawRoundRect(cardRect, 48f, 48f, borderPaint)

        val qrBmp = generateBrandedQrBitmap(context, card, qrSize)
        canvas.drawBitmap(qrBmp, qrLeft, qrTop, null)

        canvas.drawText(card.fullName.ifBlank { "CardLink User" }, w / 2f, 820f, namePaint)
        canvas.drawText(
            listOf(card.designation, card.companyName).filter { it.isNotBlank() }.joinToString(" • "),
            w / 2f,
            885f,
            subPaint
        )
        canvas.drawRect(w / 2f - 140f, 915f, w / 2f + 140f, 921f, accentPaint)
        canvas.drawText("Scan QR to Save Contact • Powered by CardLink", w / 2f, qrTop + qrSize + 130f, hintPaint)

        return bmp
    }

    fun applyLockScreenWallpaper(context: Context, card: BusinessCardEntity): Boolean {
        return runCatching {
            val bmp = renderLockScreenWallpaper(context, card)
            val wm = WallpaperManager.getInstance(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
            } else {
                wm.setBitmap(bmp)
            }
            true
        }.getOrDefault(false)
    }

    fun shareLockScreenWallpaper(context: Context, card: BusinessCardEntity) {
        val bmp = renderLockScreenWallpaper(context, card)
        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val file = File(dir, "CardLink_Wallpaper_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Save / Share Lock-Screen Wallpaper"))
    }

    /**
     * Generates a standalone, offline-ready, clickable HTML Business Card (ideal for Google Drive / GitHub Pages).
     */
    fun shareClickableHtmlCard(context: Context, card: BusinessCardEntity) {
        val c = card.sanitizedForSharing()
        val vcfEscaped = CardShareHelper.toVCardString(c)
            .replace("\\", "\\\\")
            .replace("`", "\\`")
            .replace("$", "\\$")
        val waDigits = c.whatsapp.ifBlank { c.phone }.filter { it.isDigit() }
        val html = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${c.fullName} — Digital Business Card</title>
<style>
  body { margin:0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background:#0A192F; color:#F8FAFC; display:flex; justify-content:center; align-items:center; min-height:100vh; padding:20px; box-sizing:border-box; }
  .card { width:100%; max-width:420px; background:#112240; border:1.5px solid #D4AF37; border-radius:24px; padding:28px; box-shadow:0 20px 45px rgba(0,0,0,0.45); }
  .badge { color:#D4AF37; font-size:12px; letter-spacing:1.4px; text-transform:uppercase; font-weight:700; }
  h1 { margin:8px 0 4px; font-size:26px; }
  .sub { color:#D4AF37; font-size:15px; font-weight:600; margin-bottom:4px; }
  .org { color:#94A3B8; font-size:13px; margin-bottom:18px; }
  .bio { font-size:13px; color:#CBD5E1; line-height:1.5; margin-bottom:20px; }
  .btn { display:block; width:100%; text-align:center; padding:13px; margin:10px 0; border-radius:12px; text-decoration:none; font-weight:700; font-size:14px; box-sizing:border-box; }
  .btn-gold { background:#D4AF37; color:#0A192F; border:none; cursor:pointer; }
  .btn-outline { border:1px solid rgba(212,175,55,0.5); color:#F8FAFC; background:rgba(255,255,255,0.03); }
  .footer { text-align:center; margin-top:18px; font-size:11px; color:#64748B; }
</style>
</head>
<body>
  <div class="card">
    <div class="badge">${c.profileTitle}</div>
    <h1>${c.fullName}</h1>
    <div class="sub">${c.designation}</div>
    <div class="org">${listOf(c.department, c.companyName).filter { it.isNotBlank() }.joinToString(" • ")}</div>
    ${if (c.bio.isNotBlank()) "<div class='bio'>${c.bio}</div>" else ""}
    <button class="btn btn-gold" onclick="downloadVcf()">Save Contact (.vcf)</button>
    ${if (c.phone.isNotBlank()) "<a class='btn btn-outline' href='tel:${c.phone}'>Call: ${c.phone}</a>" else ""}
    ${if (waDigits.isNotBlank()) "<a class='btn btn-outline' href='https://wa.me/$waDigits'>WhatsApp Chat</a>" else ""}
    ${if (c.email.isNotBlank()) "<a class='btn btn-outline' href='mailto:${c.email}'>Email: ${c.email}</a>" else ""}
    ${if (c.website.isNotBlank()) "<a class='btn btn-outline' href='${c.website}' target='_blank'>Visit Website</a>" else ""}
    ${if (c.linkedInUrl.isNotBlank()) "<a class='btn btn-outline' href='${c.linkedInUrl}' target='_blank'>LinkedIn Profile</a>" else ""}
    ${if (c.latitude != null && c.longitude != null) "<a class='btn btn-outline' href='https://www.google.com/maps/dir/?api=1&destination=${c.latitude},${c.longitude}' target='_blank'>Navigate to Office (GPS Pin)</a>" else if (c.officeAddress.isNotBlank()) "<a class='btn btn-outline' href='https://www.google.com/maps/search/?api=1&query=${Uri.encode(c.officeAddress)}' target='_blank'>View Office on Google Maps</a>" else ""}
    <div class="footer">Created with CardLink Smart Digital Business Card</div>
  </div>
  <script>
    function downloadVcf() {
      const vcf = `$vcfEscaped`;
      const blob = new Blob([vcf], { type: 'text/vcard' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = '${c.fullName.replace(Regex("[^a-zA-Z0-9]"), "_")}.vcf';
      a.click();
      URL.revokeObjectURL(url);
    }
  </script>
</body>
</html>
        """.trimIndent()

        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val safeName = c.fullName.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "CardLink" }
        val file = File(dir, "${safeName}_DigitalCard.html")
        file.writeText(html, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${c.fullName} — Interactive Digital Card (.html)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share / Upload HTML Card to Google Drive"))
    }

    /**
     * Copies a professional HTML & Plain-Text Email Signature (for Gmail / Outlook) to clipboard.
     */
    fun copyEmailSignatureToClipboard(context: Context, card: BusinessCardEntity) {
        val c = card.sanitizedForSharing()
        val plain = buildString {
            appendLine("--")
            appendLine(c.fullName)
            if (c.designation.isNotBlank() || c.companyName.isNotBlank()) {
                appendLine("${c.designation} | ${c.companyName}")
            }
            if (c.department.isNotBlank()) appendLine(c.department)
            if (c.phone.isNotBlank()) appendLine("Tel: ${c.phone}")
            if (c.email.isNotBlank()) appendLine("Email: ${c.email}")
            if (c.website.isNotBlank()) appendLine("Web: ${c.website}")
            if (c.officeAddress.isNotBlank()) appendLine("Office: ${c.officeAddress}")
        }.trim()

        val html = """
            <table style="font-family:Arial,sans-serif;color:#0A192F;border-left:3px solid #D4AF37;padding-left:12px;">
              <tr><td style="font-size:16px;font-weight:bold;">${c.fullName}</td></tr>
              <tr><td style="font-size:13px;color:#B8860B;font-weight:bold;">${c.designation} • ${c.companyName}</td></tr>
              <tr><td style="font-size:12px;color:#334155;">${c.phone} | ${c.email}</td></tr>
              <tr><td style="font-size:12px;color:#475569;">${c.officeAddress}</td></tr>
            </table>
        """.trimIndent()

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newHtmlText("CardLink Email Signature", plain, html))
        Toast.makeText(context, "Professional Email Signature copied! Paste in Gmail/Outlook.", Toast.LENGTH_LONG).show()
    }

    /**
     * One-Tap Follow-Up Meeting Scheduler in Google Calendar / Default Calendar App.
     */
    fun scheduleFollowUpMeeting(context: Context, contact: SavedContactEntity) {
        val startMillis = System.currentTimeMillis() + 24L * 60 * 60 * 1000 // Tomorrow same time
        val endMillis = startMillis + 30L * 60 * 1000 // 30-min meeting
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            putExtra(CalendarContract.Events.TITLE, "Follow-up: ${contact.fullName} (${contact.companyName})")
            putExtra(
                CalendarContract.Events.DESCRIPTION,
                "Contact: ${contact.fullName}\nDesignation: ${contact.designation}\nPhone: ${contact.phone}\nNotes: ${contact.notes}"
            )
            if (contact.officeAddress.isNotBlank()) {
                putExtra(CalendarContract.Events.EVENT_LOCATION, contact.officeAddress)
            }
            if (contact.email.isNotBlank()) {
                putExtra(Intent.EXTRA_EMAIL, contact.email)
            }
        }
        runCatching {
            context.startActivity(intent)
        }.onFailure {
            Toast.makeText(context, "No Calendar app found.", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Generates a 1920x1080 (16:9) Executive Virtual Meeting Background for Zoom / Teams / Google Meet.
     * Identity is in the top-left and Branded QR is in the top-right, keeping the center clear for the speaker.
     */
    fun renderMeetingBackgroundBitmap(context: Context, card: BusinessCardEntity): Bitmap {
        val w = 1920
        val h = 1080
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                card.primaryColorHex.toInt(),
                Color.parseColor("#020617"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

        val accentColor = card.accentColorHex.toInt()
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
        canvas.drawRect(0f, 0f, w.toFloat(), 10f, accentPaint)
        canvas.drawRect(0f, h - 10f, w.toFloat(), h.toFloat(), accentPaint)

        // Subtle geometric corner accents
        val cornerLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 55
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(RectF(36f, 36f, w - 36f, h - 36f), 28f, 28f, cornerLinePaint)

        // Top-Left Identity Block
        var textLeft = 78f
        if (!card.companyLogoUri.isNullOrBlank()) {
            val logoBmp = runCatching {
                val uri = Uri.parse(card.companyLogoUri)
                if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
                else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (logoBmp != null) {
                val logoBox = RectF(78f, 68f, 182f, 172f)
                canvas.drawRoundRect(logoBox, 20f, 20f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
                canvas.drawBitmap(logoBmp, null, RectF(88f, 78f, 172f, 162f), Paint(Paint.FILTER_BITMAP_FLAG))
                textLeft = 208f
            }
        }

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 54f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val rolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 30f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            textSize = 24f
        }

        val clean = card.sanitizedForSharing()
        canvas.drawText(clean.fullName.ifBlank { "CardLink User" }, textLeft, 118f, namePaint)
        val roleLine = listOf(clean.designation, clean.companyName).filter { it.isNotBlank() }.joinToString(" • ")
        if (roleLine.isNotBlank()) canvas.drawText(roleLine, textLeft, 162f, rolePaint)
        val infoLine = listOf(clean.email, clean.website).filter { it.isNotBlank() }.joinToString("  |  ")
        if (infoLine.isNotBlank()) canvas.drawText(infoLine, textLeft, 202f, subPaint)

        // Top-Right Branded QR Badge
        val qrSize = 300
        val pad = 24f
        val badgeRight = w - 74f
        val badgeTop = 64f
        val badgeLeft = badgeRight - qrSize - pad * 2
        val badgeBottom = badgeTop + qrSize + pad * 2 + 44f
        val badgeRect = RectF(badgeLeft, badgeTop, badgeRight, badgeBottom)

        canvas.drawRoundRect(badgeRect, 28f, 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        canvas.drawRoundRect(
            badgeRect, 28f, 28f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accentColor
                style = Paint.Style.STROKE
                strokeWidth = 6f
            }
        )

        val qrBmp = generateBrandedQrBitmap(context, card, qrSize)
        canvas.drawBitmap(qrBmp, badgeLeft + pad, badgeTop + pad, null)

        val scanLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0A192F")
            textSize = 23f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("Scan to Save Contact", (badgeLeft + badgeRight) / 2f, badgeBottom - 18f, scanLabelPaint)

        val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 22f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("Powered by CardLink", w - 74f, h - 54f, watermarkPaint)

        return bmp
    }

    fun shareMeetingBackground(context: Context, card: BusinessCardEntity) {
        val bmp = renderMeetingBackgroundBitmap(context, card)
        val dir = File(context.cacheDir, "cards").apply { mkdirs() }
        val file = File(dir, "CardLink_MeetingBG_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 96, it) }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${card.fullName} — 16:9 Virtual Meeting Background")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Save / Share 16:9 Meeting Background"))
    }

}
