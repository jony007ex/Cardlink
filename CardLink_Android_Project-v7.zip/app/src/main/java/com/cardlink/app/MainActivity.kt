package com.cardlink.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.nearby.BluetoothDiscoveryManager
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.tile.CardLinkTileService
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.components.BackupRestoreSection
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.components.FlippableBusinessCardView
import com.cardlink.app.ui.screens.*
import com.cardlink.app.ui.theme.*
import com.cardlink.app.util.CardShareHelper
import com.cardlink.app.util.ContactActionLauncher
import com.cardlink.app.util.BiometricLockHelper
import com.cardlink.app.util.PremiumExtrasHelper
import com.cardlink.app.util.GeoLocationHelper
import com.cardlink.app.util.ScannedCardStorageHelper
import kotlinx.coroutines.launch
import com.cardlink.app.widget.CardLinkGlanceWidget
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {

    private val viewModel: CardLinkViewModel by viewModels()
    private lateinit var nfcReaderManager: NfcReaderManager
    private lateinit var bluetoothDiscoveryManager: BluetoothDiscoveryManager
    private var isAppUnlocked by mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bluetoothDiscoveryManager = BluetoothDiscoveryManager(this)
        nfcReaderManager = NfcReaderManager(this) { vcfPayload ->
            val contact = CardShareHelper.parseVCardToContact(vcfPayload, "NFC Tap")
            viewModel.saveReceivedContact(contact)
            Toast.makeText(this, "Saved ${contact.fullName} via NFC!", Toast.LENGTH_LONG).show()
        }

        handleIncomingNfcIntent(intent)
        val initialRoute = if (intent?.action == NfcAdapter.ACTION_NDEF_DISCOVERED) "contacts"
            else intent?.getStringExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE) ?: "splash"

        isAppUnlocked = !BiometricLockHelper.isLockEnabled(this)

        setContent {
            val darkOverride by viewModel.darkThemeOverride.collectAsState()
            var enteredPin by remember { mutableStateOf("") }

            val keyguardLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { res ->
                if (res.resultCode == RESULT_OK) {
                    isAppUnlocked = true
                }
            }

            fun triggerAuth() {
                BiometricLockHelper.showPrompt(
                    activity = this@MainActivity,
                    onSuccess = { isAppUnlocked = true },
                    onFallbackToDeviceCredential = {
                        val intent = BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity)
                        if (intent != null) {
                            keyguardLauncher.launch(intent)
                        }
                    },
                    onError = { msg ->
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            CardLinkTheme(darkTheme = darkOverride ?: isSystemInDarkTheme()) {
                if (!isAppUnlocked) {
                    LaunchedEffect(Unit) { triggerAuth() }
                    Box(
                        modifier = Modifier.fillMaxSize().background(NavyPrimary).padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = NavySurface)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Icon(Icons.Default.Fingerprint, null, tint = GoldAccent, modifier = Modifier.size(68.dp))
                                Text("CardLink Security Lock", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    "Unlock using Fingerprint / Face Unlock or your Backup App PIN",
                                    color = Color.White.copy(alpha = 0.75f),
                                    fontSize = 13.sp
                                )

                                Button(
                                    onClick = { triggerAuth() },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) {
                                    Icon(Icons.Default.Fingerprint, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Unlock with Fingerprint / Face", fontWeight = FontWeight.Bold)
                                }

                                val credIntent = remember { BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity) }
                                if (credIntent != null) {
                                    OutlinedButton(
                                        onClick = { keyguardLauncher.launch(credIntent) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Unlock with Phone Screen Lock", color = GoldAccent)
                                    }
                                }

                                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))

                                OutlinedTextField(
                                    value = enteredPin,
                                    onValueChange = { enteredPin = it },
                                    label = { Text("Or enter CardLink App PIN") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedButton(
                                    onClick = {
                                        if (enteredPin.trim() == BiometricLockHelper.getAppPin(this@MainActivity)) {
                                            enteredPin = ""
                                            isAppUnlocked = true
                                        } else {
                                            Toast.makeText(this@MainActivity, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Unlock with App PIN", color = Color.White)
                                }
                            }
                        }
                    }
                } else {
                    CardLinkAppScaffold(
                        viewModel = viewModel,
                        nfcReaderManager = nfcReaderManager,
                        bluetoothDiscoveryManager = bluetoothDiscoveryManager,
                        startRoute = initialRoute,
                        onLockNow = { isAppUnlocked = false }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingNfcIntent(intent)
    }

    private fun handleIncomingNfcIntent(intent: Intent?) {
        if (intent?.action == NfcAdapter.ACTION_NDEF_DISCOVERED) {
            @Suppress("DEPRECATION")
            val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
            rawMsgs?.forEach { parcelable ->
                val ndefMsg = parcelable as? NdefMessage ?: return@forEach
                ndefMsg.records.forEach { record ->
                    val payloadText = String(record.payload, Charsets.UTF_8)
                    if (payloadText.contains("BEGIN:VCARD", ignoreCase = true)) {
                        val contact = CardShareHelper.parseVCardToContact(payloadText, "NFC vCard")
                        viewModel.saveReceivedContact(contact)
                        Toast.makeText(this, "Saved ${contact.fullName} via NFC vCard!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        nfcReaderManager.disableReaderMode()
    }

    override fun onStop() {
        super.onStop()
        if (BiometricLockHelper.isLockEnabled(this)) {
            isAppUnlocked = false
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkAppScaffold(
    viewModel: CardLinkViewModel,
    nfcReaderManager: NfcReaderManager,
    bluetoothDiscoveryManager: BluetoothDiscoveryManager,
    startRoute: String,
    onLockNow: () -> Unit = {}
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val activeCard by viewModel.activeCard.collectAsState()
    val myCards by viewModel.myCards.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val shareHistory by viewModel.shareHistory.collectAsState()
    val followUps by viewModel.followUps.collectAsState()
    val scope = rememberCoroutineScope()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current

    val bottomNavRoutes = listOf("home", "share", "contacts", "calendar", "analytics", "settings")

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomNavRoutes) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Badge, null) },
                        label = { Text("My Card") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "share",
                        onClick = { navController.navigate("share") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Share, null) },
                        label = { Text("Share") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "contacts",
                        onClick = { navController.navigate("contacts") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Contacts, null) },
                        label = { Text("Contacts") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "calendar",
                        onClick = { navController.navigate("calendar") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.CalendarMonth, null) },
                        label = { Text("Calendar") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "analytics",
                        onClick = { navController.navigate("analytics") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Analytics, null) },
                        label = { Text("Insights") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "settings",
                        onClick = { navController.navigate("settings") { launchSingleTop = true } },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startRoute,
            modifier = Modifier.padding(padding)
        ) {
            composable("splash") {
                LaunchedEffect(Unit) {
                    delay(850)
                    navController.navigate("home") { popUpTo("splash") { inclusive = true } }
                }
                Box(modifier = Modifier.fillMaxSize().background(NavyPrimary), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Contactless, null, tint = GoldAccent, modifier = Modifier.size(80.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("CardLink", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text("Smart Digital Business Card", color = GoldAccent, fontSize = 14.sp)
                    }
                }
            }

            composable("home") {
                val quickPrivacy by viewModel.quickPrivacyMode.collectAsState()
                val displayCard = remember(activeCard, quickPrivacy) {
                    if (quickPrivacy) activeCard.copy(sharePhone = false, shareAddress = false, shareEmail = false) else activeCard
                }
                val qrBitmap = remember(displayCard) {
                    PremiumExtrasHelper.generateBrandedQrBitmap(context, displayCard, 480)
                }
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CardLink", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("Active: ${activeCard.profileTitle}", style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            IconButton(onClick = { viewModel.toggleQuickPrivacyMode() }) {
                                Icon(
                                    imageVector = if (quickPrivacy) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Quick Privacy Mode",
                                    tint = if (quickPrivacy) GoldAccent else LocalContentColor.current
                                )
                            }
                            IconButton(onClick = { navController.navigate("scan_ocr") }) {
                                Icon(Icons.Default.DocumentScanner, contentDescription = "Scan Paper Card")
                            }
                            IconButton(onClick = { navController.navigate("customize") }) {
                                Icon(Icons.Default.Palette, contentDescription = "Customize")
                            }
                            IconButton(onClick = { navController.navigate("edit_card") }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit")
                            }
                        }
                    }

                    if (myCards.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            myCards.forEach { profile ->
                                FilterChip(
                                    selected = profile.id == activeCard.id,
                                    onClick = { viewModel.switchActiveProfile(profile.id) },
                                    label = { Text(profile.profileTitle) }
                                )
                            }
                        }
                    }

                    FlippableBusinessCardView(card = displayCard)
                    Text(
                        text = if (quickPrivacy) "Quick Privacy Mode ON (Phone/Email/Address hidden) • Tap card to flip" else "Tap card to flip 3D (Front & Branded QR Back)",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldAccent
                    )

                    Button(
                        onClick = { navController.navigate("share") },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Share, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share My Card", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Instant Scan QR", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(150.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                TextButton(onClick = { navController.navigate("qr_screen") }) { Text("Full QR") }
                                TextButton(onClick = { navController.navigate("scan_qr") }) { Text("Scan QR") }
                                TextButton(onClick = { navController.navigate("scan_ocr") }) { Text("Scan Paper") }
                            }
                        }
                    }
                }
            }

            // EDIT CARD SCREEN (With Profile Photo + Company Logo Upload + NFC Public/Drive Link)
            composable("edit_card") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }

                val profilePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) {
                        val saved = ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "profile")
                        if (saved != null) draft = draft.copy(profilePhotoUri = saved)
                    }
                }

                val companyLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) {
                        val saved = ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "logo")
                        if (saved != null) draft = draft.copy(companyLogoUri = saved)
                    }
                }

                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Edit Business Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = draft)

                    // Profile Photo & Company Logo Pickers
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { profilePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.AccountCircle, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Upload Photo")
                        }
                        OutlinedButton(
                            onClick = { companyLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Business, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Upload Logo")
                        }
                    }

                    OutlinedTextField(value = draft.profileTitle, onValueChange = { draft = draft.copy(profileTitle = it) }, label = { Text("Profile Label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.fullName, onValueChange = { draft = draft.copy(fullName = it) }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.department, onValueChange = { draft = draft.copy(department = it) }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = draft.publicCardUrl,
                        onValueChange = { draft = draft.copy(publicCardUrl = it) },
                        label = { Text("NFC Public / Google Drive Card Link") },
                        supportingText = { Text("Opens automatically on other phones when tapped via NFC") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(value = draft.phone, onValueChange = { draft = draft.copy(phone = it) }, label = { Text("Business Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text("WhatsApp Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                    val editLocPermLauncher = rememberLauncherForActivityResult(
                        ActivityResultContracts.RequestMultiplePermissions()
                    ) {
                        val gps = GeoLocationHelper.getCurrentGpsCoordinates(context)
                        if (gps != null) {
                            draft = draft.copy(latitude = gps.first, longitude = gps.second)
                            scope.launch {
                                if (draft.officeAddress.isBlank()) {
                                    val addr = GeoLocationHelper.reverseGeocode(context, gps.first, gps.second)
                                    if (!addr.isNullOrBlank()) draft = draft.copy(officeAddress = addr)
                                }
                            }
                            Toast.makeText(context, "Current GPS Location Pinned!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Could not fetch GPS. Make sure Location is ON.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    OutlinedTextField(
                        value = draft.officeAddress,
                        onValueChange = { draft = draft.copy(officeAddress = it) },
                        label = { Text("Office Address") },
                        supportingText = {
                            if (draft.latitude != null && draft.longitude != null) {
                                Text("GPS Pin: ${GeoLocationHelper.formatCoordinates(draft.latitude, draft.longitude)}", color = GoldAccent)
                            } else {
                                Text("Tap 'Auto-Pin Address' or 'Use Current GPS' below to attach map coordinates")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val coords = GeoLocationHelper.geocodeAddress(context, draft.officeAddress)
                                    if (coords != null) {
                                        draft = draft.copy(latitude = coords.first, longitude = coords.second)
                                        Toast.makeText(context, "Address Geocoded: ${GeoLocationHelper.formatCoordinates(coords.first, coords.second)}", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Could not geocode address. Try 'Current GPS'.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PinDrop, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Auto-Pin Address", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                editLocPermLauncher.launch(
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                )
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Current GPS", fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text("Company Website") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.linkedInUrl, onValueChange = { draft = draft.copy(linkedInUrl = it) }, label = { Text("LinkedIn URL") }, modifier = Modifier.fillMaxWidth())

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.saveCard(draft.copy(id = 0, profileTitle = "New Profile", isDefault = true)); navController.popBackStack() },
                            modifier = Modifier.weight(1f)
                        ) { Text("Save as New") }
                        Button(
                            onClick = { viewModel.saveCard(draft); navController.popBackStack() },
                            modifier = Modifier.weight(1f)
                        ) { Text("Save Changes") }
                    }
                }
            }

            // CUSTOMIZE CARD SCREEN (4 Premium Layouts + Color Themes + Typography)
            composable("customize") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                val presets = listOf(
                    Triple("Executive Navy & Gold", 0xFF0A192FL, 0xFFD4AF37L),
                    Triple("Charcoal & Platinum", 0xFF1E293BL, 0xFFE2E8F0L),
                    Triple("Royal Emerald & Gold", 0xFF064E3BL, 0xFFFBBF24L),
                    Triple("Midnight Crimson", 0xFF3B0764L, 0xFFF43F5EL)
                )
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Card Templates & Styling", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = draft)

                    Text("Select Layout Template", fontWeight = FontWeight.SemiBold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = draft.template == CardTemplate.EXECUTIVE_NAVY, onClick = { draft = draft.copy(template = CardTemplate.EXECUTIVE_NAVY) }, label = { Text("Executive") })
                        FilterChip(selected = draft.template == CardTemplate.MINIMAL_IVORY, onClick = { draft = draft.copy(template = CardTemplate.MINIMAL_IVORY) }, label = { Text("Ivory") })
                        FilterChip(selected = draft.template == CardTemplate.MODERN_SPLIT, onClick = { draft = draft.copy(template = CardTemplate.MODERN_SPLIT) }, label = { Text("Split") })
                    }

                    Text("Color Themes", fontWeight = FontWeight.SemiBold)
                    presets.forEach { (name, bg, acc) ->
                        OutlinedButton(onClick = { draft = draft.copy(primaryColorHex = bg, accentColorHex = acc) }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                    }

                    Text("Typography", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("SansSerif", "Serif", "Monospace").forEach { font ->
                            FilterChip(selected = draft.fontFamilyName == font, onClick = { draft = draft.copy(fontFamilyName = font) }, label = { Text(font) })
                        }
                    }

                    Button(onClick = { viewModel.saveCard(draft); navController.popBackStack() }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                        Text("Apply Design")
                    }
                }
            }

            composable("share") {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Share My Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = activeCard)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("NFC Tap"); navController.navigate("nfc_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("NFC Tap") }
                        Button(onClick = { navController.navigate("nearby_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Bluetooth Search") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("QR Code"); navController.navigate("qr_screen") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("QR Code") }
                        Button(onClick = { viewModel.logShare("vCard (.vcf)"); CardShareHelper.shareVCardFile(context, activeCard) }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Share via Apps") }
                    }

                    OutlinedButton(onClick = { viewModel.logShare("PNG Image"); CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as PNG Image") }
                    OutlinedButton(onClick = { viewModel.logShare("PDF Export"); CardShareHelper.shareCardAsPdf(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Export as PDF Document") }
                    OutlinedButton(onClick = { viewModel.logShare("WhatsApp / Text"); CardShareHelper.shareAsText(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as Text / WhatsApp") }

                    HorizontalDivider()
                    Text("Premium Pro Tools", fontWeight = FontWeight.Bold, color = GoldAccent)

                    OutlinedButton(
                        onClick = { viewModel.logShare("HTML Card"); PremiumExtrasHelper.shareClickableHtmlCard(context, activeCard) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Language, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Export Clickable HTML Card (Google Drive)")
                    }

                    OutlinedButton(
                        onClick = { PremiumExtrasHelper.copyEmailSignatureToClipboard(context, activeCard) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Draw, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Copy Email Signature (Gmail / Outlook)")
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val ok = PremiumExtrasHelper.applyLockScreenWallpaper(context, activeCard)
                                Toast.makeText(context, if (ok) "Lock-Screen QR Wallpaper applied!" else "Failed to set wallpaper", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Set Lock Wallpaper") }
                        OutlinedButton(
                            onClick = { PremiumExtrasHelper.shareLockScreenWallpaper(context, activeCard) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Share Wallpaper") }
                    }

                    Button(
                        onClick = { navController.navigate("meeting_bg") },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Icon(Icons.Default.VideoCameraFront, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Online Meeting Background (Zoom / Teams / Meet)")
                    }
                }
            }

            // NFC SHARING SCREEN (Broadcasts NDEF Type 4 URI Link so other phone opens it!)
            composable("nfc_share") {
                var nfcShareMode by remember { mutableStateOf(CardLinkHceService.shareMode) }
                var isReceiveMode by remember { mutableStateOf(false) }
                var nfcLinkDraft by remember(activeCard) { mutableStateOf(activeCard.resolveNfcShareUrl()) }

                // IMPORTANT: Keep Reader Mode OFF when sending via HCE so the OS broadcasts the NFC tag cleanly!
                DisposableEffect(activeCard, nfcShareMode, nfcLinkDraft, isReceiveMode) {
                    CardLinkHceService.shareMode = nfcShareMode
                    CardLinkHceService.activeShareUrl = nfcLinkDraft
                    CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(activeCard)
                    if (isReceiveMode) {
                        nfcReaderManager.enableReaderMode()
                    } else {
                        nfcReaderManager.disableReaderMode()
                    }
                    onDispose { nfcReaderManager.disableReaderMode() }
                }

                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(Icons.Default.Contactless, null, tint = GoldAccent, modifier = Modifier.size(80.dp))

                    if (!nfcReaderManager.isNfcSupported()) {
                        Text("NFC is not supported on this phone.", fontWeight = FontWeight.Bold)
                    } else if (!nfcReaderManager.isNfcEnabled()) {
                        Text("NFC is disabled. Enable it in Settings.", fontWeight = FontWeight.Bold)
                        Button(onClick = { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Open NFC Settings") }
                    } else {
                        Text(
                            text = if (isReceiveMode) "NFC Receive Mode Active"
                                   else if (nfcShareMode == NfcShareMode.VCARD) "NFC Tap Ready (vCard)"
                                   else "NFC Tap Ready (Link)",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )

                        // Send vs Receive Toggle
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !isReceiveMode,
                                onClick = { isReceiveMode = false },
                                label = { Text("Send My Card") }
                            )
                            FilterChip(
                                selected = isReceiveMode,
                                onClick = { isReceiveMode = true },
                                label = { Text("Receive Card") }
                            )
                        }

                        if (!isReceiveMode) {
                            // vCard vs Link Mode Toggle
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = nfcShareMode == NfcShareMode.VCARD,
                                    onClick = { nfcShareMode = NfcShareMode.VCARD },
                                    label = { Text("vCard Contact (Default)") }
                                )
                                FilterChip(
                                    selected = nfcShareMode == NfcShareMode.LINK,
                                    onClick = { nfcShareMode = NfcShareMode.LINK },
                                    label = { Text("Profile Link (URL)") }
                                )
                            }

                            if (nfcShareMode == NfcShareMode.VCARD) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("vCard Direct Contact Share", fontWeight = FontWeight.Bold, color = GoldAccent)
                                        Text(
                                            "Touch the back of your phone to another Android NFC phone. It will directly prompt to save '${activeCard.fullName}' (.vcf) into their Contacts.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            "Tip: For iPhone recipients, switch to 'Profile Link (URL)' above.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    "Touch the back of your phone to any Android or iPhone to auto-open this link:",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                OutlinedTextField(
                                    value = nfcLinkDraft,
                                    onValueChange = { nfcLinkDraft = it },
                                    label = { Text("Active NFC Tap URL (Google Drive / Website / LinkedIn)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = {
                                            viewModel.saveCard(activeCard.copy(publicCardUrl = nfcLinkDraft))
                                            Toast.makeText(context, "NFC Link updated!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Save NFC Link") }

                                    OutlinedButton(
                                        onClick = { ContactActionLauncher.launchExternalUrl(context, nfcLinkDraft) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Test Link") }
                                }
                            }
                        } else {
                            Text(
                                "Hold the back of your phone against another CardLink phone to receive and save their vCard automatically.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        BusinessCardView(card = activeCard)
                    }
                }
            }

            // BLUETOOTH DEVICE SEARCH, PAIRING & SHARE SCREEN
            composable("nearby_share") {
                val pairedDevices by bluetoothDiscoveryManager.pairedDevices.collectAsState()
                val discoveredDevices by bluetoothDiscoveryManager.discoveredDevices.collectAsState()
                val isScanning by bluetoothDiscoveryManager.isScanning.collectAsState()

                val btPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    bluetoothDiscoveryManager.startDiscovery()
                }

                fun requestAndScan() {
                    val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        perms.addAll(listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE))
                    }
                    btPermLauncher.launch(perms.toTypedArray())
                }

                DisposableEffect(Unit) {
                    requestAndScan()
                    onDispose { bluetoothDiscoveryManager.stopDiscovery() }
                }

                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Bluetooth Devices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Button(onClick = {
                            if (!bluetoothDiscoveryManager.isBluetoothEnabled()) {
                                context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                            } else {
                                requestAndScan()
                            }
                        }) {
                            Icon(Icons.Default.BluetoothSearching, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (isScanning) "Scanning..." else "Search")
                        }
                    }

                    if (!bluetoothDiscoveryManager.isBluetoothEnabled()) {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Bluetooth is turned OFF")
                                TextButton(onClick = { context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }) { Text("Turn On") }
                            }
                        }
                    }

                    if (isScanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (discoveredDevices.isNotEmpty()) {
                            item { Text("Nearby Discovered Devices (${discoveredDevices.size})", fontWeight = FontWeight.Bold, color = GoldAccent) }
                            items(discoveredDevices, key = { "disc_${it.address}" }) { dev ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    ListItem(
                                        leadingContent = { Icon(Icons.Default.Bluetooth, null, tint = GoldAccent) },
                                        headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) },
                                        supportingContent = { Text(dev.address) },
                                        trailingContent = {
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                if (!dev.isPaired) {
                                                    OutlinedButton(onClick = {
                                                        val ok = bluetoothDiscoveryManager.pairDevice(dev.device)
                                                        Toast.makeText(context, if (ok) "Pairing with ${dev.name}..." else "Pairing failed", Toast.LENGTH_SHORT).show()
                                                    }) { Text("Pair") }
                                                }
                                                Button(onClick = { viewModel.logShare("Bluetooth"); CardShareHelper.sendVCardViaBluetooth(context, activeCard) }) { Text("Send") }
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        item { Text("Paired Bluetooth Devices (${pairedDevices.size})", fontWeight = FontWeight.Bold) }
                        if (pairedDevices.isEmpty()) {
                            item { Text("No paired devices found. Tap 'Search' above to scan nearby devices.", style = MaterialTheme.typography.bodySmall) }
                        } else {
                            items(pairedDevices, key = { "pair_${it.address}" }) { dev ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    ListItem(
                                        leadingContent = { Icon(Icons.Default.BluetoothConnected, null) },
                                        headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) },
                                        supportingContent = { Text("${dev.address} • Paired") },
                                        trailingContent = {
                                            Button(onClick = { viewModel.logShare("Bluetooth"); CardShareHelper.sendVCardViaBluetooth(context, activeCard) }) { Text("Send Card") }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            composable("qr_screen") {
                val qr = remember(activeCard) { PremiumExtrasHelper.generateBrandedQrBitmap(context, activeCard, 750) }
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(activeCard.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Image(bitmap = qr.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(260.dp))
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share QR & Card Image") }
                }
            }

            // UPGRADED UNIVERSAL QR SCANNER (Handles vCard, MECARD, URLs/Links & Plain Text)
            composable("scan_qr") {
                var hasCam by remember { mutableStateOf(false) }
                var scannedRaw by remember { mutableStateOf<String?>(null) }

                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
                LaunchedEffect(Unit) { launcher.launch(Manifest.permission.CAMERA) }

                if (scannedRaw != null) {
                    val raw = scannedRaw!!
                    val isVCard = raw.contains("BEGIN:VCARD", ignoreCase = true)
                    val isMeCard = raw.startsWith("MECARD:", ignoreCase = true)
                    val isUrl = raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true) || raw.startsWith("www.", ignoreCase = true)

                    val parsedContact = remember(raw) {
                        when {
                            isVCard -> CardShareHelper.parseVCardToContact(raw, "QR Scan")
                            isMeCard -> CardShareHelper.parseMeCardToContact(raw, "QR Scan")
                            isUrl -> SavedContactEntity(fullName = "Scanned Web Card", website = raw, notes = "Scanned QR Link: $raw", receivedVia = "QR Link")
                            else -> SavedContactEntity(fullName = "Scanned QR Info", notes = raw, receivedVia = "QR Scan")
                        }
                    }

                    Column(
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("QR Code Scanned!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = GoldAccent)

                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (isVCard || isMeCard) {
                                    Text(parsedContact.fullName, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    if (parsedContact.designation.isNotBlank()) Text(parsedContact.designation, color = GoldAccent)
                                    if (parsedContact.companyName.isNotBlank()) Text(parsedContact.companyName)
                                    if (parsedContact.phone.isNotBlank()) Text("Phone: ${parsedContact.phone}")
                                    if (parsedContact.email.isNotBlank()) Text("Email: ${parsedContact.email}")
                                    if (parsedContact.website.isNotBlank()) Text("Link: ${parsedContact.website}")
                                } else {
                                    Text(if (isUrl) "Website / Profile Link Detected" else "QR Content", fontWeight = FontWeight.Bold)
                                    Text(raw, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }

                        if (isUrl || parsedContact.website.isNotBlank()) {
                            val targetUrl = if (isUrl) raw else parsedContact.website
                            Button(
                                onClick = { ContactActionLauncher.launchExternalUrl(context, targetUrl) },
                                modifier = Modifier.fillMaxWidth().height(52.dp)
                            ) {
                                Icon(Icons.Default.OpenInBrowser, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Open Link in Browser")
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.saveReceivedContact(parsedContact)
                                Toast.makeText(context, "Saved to My Contacts!", Toast.LENGTH_SHORT).show()
                                navController.navigate("contacts") { popUpTo("scan_qr") { inclusive = true } }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Save to My Contacts")
                        }

                        OutlinedButton(onClick = { scannedRaw = null }, modifier = Modifier.fillMaxWidth()) {
                            Text("Scan Another QR")
                        }
                    }
                } else if (hasCam) {
                    val lifecycleOwner = LocalLifecycleOwner.current
                    Box(modifier = Modifier.fillMaxSize()) {
                        AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                            val pv = PreviewView(ctx)
                            val fut = ProcessCameraProvider.getInstance(ctx)
                            fut.addListener({
                                val prov = fut.get()
                                val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                                val scanner = BarcodeScanning.getClient()
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build().apply {
                                        setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                            @Suppress("UnsafeOptInUsageError")
                                            val img = proxy.image
                                            if (img != null && scannedRaw == null) {
                                                scanner.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                                                    .addOnSuccessListener { list ->
                                                        val firstVal = list.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                                        if (firstVal != null) {
                                                            scannedRaw = firstVal
                                                        }
                                                    }
                                                    .addOnCompleteListener { proxy.close() }
                                            } else proxy.close()
                                        }
                                    }
                                prov.unbindAll()
                                prov.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, prev, analysis)
                            }, ContextCompat.getMainExecutor(ctx))
                            pv
                        })
                        Text(
                            "Point camera at any Business Card QR or Link QR",
                            color = Color.White,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp).background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(10.dp)).padding(12.dp)
                        )
                    }
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Grant Camera Permission") }
                    }
                }
            }

            composable("scan_ocr") {
                OcrCardScannerScreen(
                    onContactSaved = { contact ->
                        viewModel.saveReceivedContact(contact)
                        navController.navigate("contacts") { popUpTo("scan_ocr") { inclusive = true } }
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(CardLinkTileService.ROUTE_QUICK_SHARE) {
                QuickNfcQrShareScreen(
                    activeCard = activeCard,
                    nfcReaderManager = nfcReaderManager,
                    onNavigateHome = { navController.navigate("home") }
                )
            }

            composable("contacts") {
                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("My Contacts", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Row {
                            IconButton(onClick = { navController.navigate("scan_ocr") }) { Icon(Icons.Default.DocumentScanner, null) }
                            IconButton(onClick = { navController.navigate("scan_qr") }) { Icon(Icons.Default.QrCodeScanner, null) }
                        }
                    }
                    var selectedFilterTag by remember { mutableStateOf("All") }
                    var myCurrentGps by remember { mutableStateOf(GeoLocationHelper.getCurrentGpsCoordinates(context)) }
                    val radarLocLauncher = rememberLauncherForActivityResult(
                        ActivityResultContracts.RequestMultiplePermissions()
                    ) {
                        myCurrentGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
                    }
                    val filterTags = listOf("All", "Nearby (<5 km)", "Client", "Vendor", "VIP", "Colleague", "Event", "General")
                    val filteredContacts = remember(contacts, selectedFilterTag, myCurrentGps) {
                        when (selectedFilterTag) {
                            "All" -> contacts
                            "Nearby (<5 km)" -> {
                                val u = myCurrentGps ?: (activeCard.latitude?.let { lat -> activeCard.longitude?.let { lng -> Pair(lat, lng) } })
                                if (u == null) contacts.filter { it.latitude != null && it.longitude != null }
                                else contacts.filter { c ->
                                    c.latitude != null && c.longitude != null &&
                                        GeoLocationHelper.distanceInKm(u.first, u.second, c.latitude, c.longitude) <= 5.0
                                }
                            }
                            else -> contacts.filter { it.categoryTag.equals(selectedFilterTag, ignoreCase = true) }
                        }
                    }

                    OutlinedTextField(value = searchQuery, onValueChange = viewModel::updateSearchQuery, placeholder = { Text("Search contacts...") }, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        filterTags.forEach { tag ->
                            FilterChip(
                                selected = selectedFilterTag == tag,
                                onClick = {
                                    selectedFilterTag = tag
                                    if (tag == "Nearby (<5 km)") {
                                        radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                    }
                                },
                                label = { Text(tag) }
                            )
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filteredContacts, key = { it.id }) { contact ->
                            Card(modifier = Modifier.fillMaxWidth().clickable { navController.navigate("contact_detail/${contact.id}") }) {
                                ListItem(
                                    leadingContent = {
                                        if (!contact.profilePhotoUri.isNullOrBlank()) {
                                            AsyncImage(
                                                model = Uri.parse(contact.profilePhotoUri),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(56.dp, 36.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, GoldAccent, RoundedCornerShape(6.dp))
                                            )
                                        } else {
                                            Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = GoldAccent.copy(alpha = 0.2f)) {
                                                Box(contentAlignment = Alignment.Center) { Text(contact.fullName.take(2).uppercase(), color = GoldAccent, fontWeight = FontWeight.Bold) }
                                            }
                                        }
                                    },
                                    headlineContent = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                                    supportingContent = {
                                        val refGps = myCurrentGps ?: (activeCard.latitude?.let { lat -> activeCard.longitude?.let { lng -> Pair(lat, lng) } })
                                        val distLabel = if (refGps != null && contact.latitude != null && contact.longitude != null) {
                                            " • ${GeoLocationHelper.distanceInKm(refGps.first, refGps.second, contact.latitude, contact.longitude)} km"
                                        } else ""
                                        Text("${contact.designation} • ${contact.companyName}$distLabel")
                                    },
                                    trailingContent = { AssistChip(onClick = {}, label = { Text(contact.receivedVia) }) }
                                )
                            }
                        }
                    }
                }
            }

            composable(
                route = "contact_detail/{contactId}",
                arguments = listOf(navArgument("contactId") { type = NavType.LongType })
            ) { entry ->
                val id = entry.arguments?.getLong("contactId") ?: 0L
                val contact = contacts.firstOrNull { it.id == id }
                if (contact != null) {
                    val contactTasks = remember(followUps, contact.id) {
                        followUps.filter { it.contactId == contact.id }
                    }
                    ContactDetailScreen(
                        contact = contact,
                        mySenderName = activeCard.fullName,
                        mySenderCompany = activeCard.companyName,
                        contactFollowUps = contactTasks,
                        onSaveContact = { viewModel.saveReceivedContact(it) },
                        onAddFollowUp = { viewModel.saveFollowUp(it) },
                        onToggleFollowUp = { viewModel.toggleFollowUpCompleted(it) },
                        onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                        onDeleteContact = { viewModel.deleteContact(contact); navController.popBackStack() },
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            composable("calendar") {
                FollowUpCalendarScreen(
                    followUps = followUps,
                    contacts = allContacts,
                    onAddFollowUp = { viewModel.saveFollowUp(it) },
                    onToggleCompleted = { viewModel.toggleFollowUpCompleted(it) },
                    onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                    onOpenContact = { cId -> navController.navigate("contact_detail/$cId") }
                )
            }

            composable("analytics") {
                AnalyticsScreen(
                    contacts = allContacts,
                    shareHistory = shareHistory
                )
            }

            composable("meeting_bg") {
                MeetingBackgroundScreen(
                    activeCard = activeCard,
                    onExported = { viewModel.logShare("Meeting Background") },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("settings") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Settings & Privacy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Phone Number")
                        Switch(checked = draft.sharePhone, onCheckedChange = { draft = draft.copy(sharePhone = it); viewModel.saveCard(draft) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Email Address")
                        Switch(checked = draft.shareEmail, onCheckedChange = { draft = draft.copy(shareEmail = it); viewModel.saveCard(draft) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Share Office Address")
                        Switch(checked = draft.shareAddress, onCheckedChange = { draft = draft.copy(shareAddress = it); viewModel.saveCard(draft) })
                    }

                    var bioEnabled by remember { mutableStateOf(BiometricLockHelper.isLockEnabled(context)) }
                    var customPin by remember { mutableStateOf(BiometricLockHelper.getAppPin(context)) }
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Biometric & PIN App Lock", fontWeight = FontWeight.Bold)
                                    Text("Auto-locks whenever you close or minimize CardLink", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(
                                    checked = bioEnabled,
                                    onCheckedChange = { enable ->
                                        bioEnabled = enable
                                        BiometricLockHelper.setLockEnabled(context, enable)
                                        Toast.makeText(
                                            context,
                                            if (enable) "App Lock Enabled!" else "App Lock Disabled",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                )
                            }
                            if (bioEnabled) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = customPin,
                                        onValueChange = { customPin = it },
                                        label = { Text("Backup App PIN") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(onClick = {
                                        BiometricLockHelper.setAppPin(context, customPin)
                                        Toast.makeText(context, "Backup PIN saved!", Toast.LENGTH_SHORT).show()
                                    }) { Text("Save PIN") }
                                }
                                OutlinedButton(
                                    onClick = onLockNow,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Lock, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Lock & Test Biometric Now")
                                }
                            }
                        }
                    }

                    BackupRestoreSection(viewModel = viewModel)

                    OutlinedButton(
                        onClick = { CardLinkTileService.requestAddTile(context) { Toast.makeText(context, it, Toast.LENGTH_LONG).show() } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Add Quick Settings Tile") }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.toggleTheme(false) }, modifier = Modifier.weight(1f)) { Text("Light") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(true) }, modifier = Modifier.weight(1f)) { Text("Dark") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(null) }, modifier = Modifier.weight(1f)) { Text("System") }
                    }
                }
            }
        }
    }
}
