package com.cardlink.app.util

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricLockHelper {
    private const val PREFS_NAME = "cardlink_security_prefs"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_lock_enabled"
    private const val KEY_FALLBACK_PIN = "cardlink_fallback_pin"

    fun isLockEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_BIOMETRIC_ENABLED, false)
    }

    fun setLockEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_BIOMETRIC_ENABLED, enabled)
            .apply()
    }

    fun getAppPin(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FALLBACK_PIN, "1234") ?: "1234"
    }

    fun setAppPin(context: Context, pin: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_FALLBACK_PIN, pin.trim().ifBlank { "1234" })
            .apply()
    }

    /**
     * Checks if device supports any Biometric (Strong/Weak) OR Device Screen Lock (PIN/Pattern/Password).
     */
    fun canAuthenticate(context: Context): Boolean {
        val manager = BiometricManager.from(context)
        val combined = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        } else {
            Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL
        }
        if (manager.canAuthenticate(combined) == BiometricManager.BIOMETRIC_SUCCESS) return true
        if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) return true
        if (manager.canAuthenticate(Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS) return true

        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return km?.isDeviceSecure == true
    }

    @Suppress("DEPRECATION")
    fun createDeviceCredentialIntent(context: Context): Intent? {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return if (km?.isDeviceSecure == true) {
            km.createConfirmDeviceCredentialIntent(
                "Unlock CardLink",
                "Enter your phone PIN, pattern, or password"
            )
        } else null
    }

    fun showPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onFallbackToDeviceCredential: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        onFallbackToDeviceCredential()
                    } else {
                        onError(errString.toString())
                    }
                }
            }
        )

        val manager = BiometricManager.from(activity)
        val rCombo = Authenticators.BIOMETRIC_STRONG or Authenticators.BIOMETRIC_WEAK or Authenticators.DEVICE_CREDENTIAL

        val promptInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                manager.canAuthenticate(rCombo) == BiometricManager.BIOMETRIC_SUCCESS
            ) {
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock CardLink")
                    .setSubtitle("Use Fingerprint, Face, or Phone Screen Lock")
                    .setAllowedAuthenticators(rCombo)
                    .build()
            } else if (manager.canAuthenticate(Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS) {
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock CardLink")
                    .setSubtitle("Touch the fingerprint sensor or use Face Unlock")
                    .setAllowedAuthenticators(Authenticators.BIOMETRIC_WEAK)
                    .setNegativeButtonText("Use Phone PIN")
                    .build()
            } else {
                @Suppress("DEPRECATION")
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock CardLink")
                    .setSubtitle("Authenticate to access your digital business cards")
                    .setDeviceCredentialAllowed(true)
                    .build()
            }
        } catch (e: Exception) {
            onFallbackToDeviceCredential()
            return
        }

        runCatching {
            prompt.authenticate(promptInfo)
        }.onFailure {
            onFallbackToDeviceCredential()
        }
    }
}
