package com.cardlink.app.util

import android.graphics.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.hypot

@Serializable
data class CardCropMetadata(
    val topLeftX: Float = 0.04f,
    val topLeftY: Float = 0.04f,
    val topRightX: Float = 0.96f,
    val topRightY: Float = 0.04f,
    val bottomRightX: Float = 0.96f,
    val bottomRightY: Float = 0.96f,
    val bottomLeftX: Float = 0.04f,
    val bottomLeftY: Float = 0.96f,
    val rotationDegrees: Int = 0,
    val enhanceReadability: Boolean = true,
    val isOriginalFullFrame: Boolean = false,
    val cropRevision: Int = 1,
    val updatedAtTimestamp: Long = 0L
) {
    companion object {
        private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

        fun fullOriginal(rotationDegrees: Int = 0, revision: Int = 1): CardCropMetadata = CardCropMetadata(
            topLeftX = 0f, topLeftY = 0f,
            topRightX = 1f, topRightY = 0f,
            bottomRightX = 1f, bottomRightY = 1f,
            bottomLeftX = 0f, bottomLeftY = 1f,
            rotationDegrees = ((rotationDegrees % 360) + 360) % 360,
            enhanceReadability = false,
            isOriginalFullFrame = true,
            cropRevision = revision,
            updatedAtTimestamp = System.currentTimeMillis()
        )

        fun toJson(meta: CardCropMetadata): String =
            runCatching { json.encodeToString(serializer(), meta) }.getOrDefault("")

        fun fromJson(raw: String?): CardCropMetadata? {
            if (raw.isNullOrBlank()) return null
            return runCatching { json.decodeFromString(serializer(), raw) }.getOrNull()
        }
    }
}

object SmartCardCropEngine {

    private const val MIN_QUAD_NORMALIZED_AREA = 0.02f

    /**
     * Pure-JVM geometric validator for normalized 4-point perspective quads.
     * Rejects NaN/Infinity, out-of-range points, zero-area quads, inverted winding,
     * and self-intersecting / crossing (bowtie) corners.
     */
    fun isValidQuad(meta: CardCropMetadata): Boolean {
        val coords = floatArrayOf(
            meta.topLeftX, meta.topLeftY,
            meta.topRightX, meta.topRightY,
            meta.bottomRightX, meta.bottomRightY,
            meta.bottomLeftX, meta.bottomLeftY
        )
        if (coords.any { it.isNaN() || it.isInfinite() || it < -0.001f || it > 1.001f }) return false

        val xs = floatArrayOf(meta.topLeftX, meta.topRightX, meta.bottomRightX, meta.bottomLeftX)
        val ys = floatArrayOf(meta.topLeftY, meta.topRightY, meta.bottomRightY, meta.bottomLeftY)

        // Shoelace signed area in screen coordinates (x right, y down -> clockwise quad has positive area)
        var area2 = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            area2 += (xs[i] * ys[j] - xs[j] * ys[i])
        }
        val area = area2 * 0.5f
        if (area < MIN_QUAD_NORMALIZED_AREA) return false

        // Convexity check: all 4 consecutive edge cross-products must be strictly positive (clockwise)
        for (i in 0 until 4) {
            val a = i
            val b = (i + 1) % 4
            val c = (i + 2) % 4
            val abx = xs[b] - xs[a]
            val aby = ys[b] - ys[a]
            val bcx = xs[c] - xs[b]
            val bcy = ys[c] - ys[b]
            val cross = abx * bcy - aby * bcx
            if (cross <= 0.0005f) return false
        }
        return true
    }

    /**
     * Sanitizes arbitrary or corrupted crop metadata into a guaranteed safe, convex, normalized quad.
     */
    fun sanitizeMetadata(meta: CardCropMetadata): CardCropMetadata {
        val normRot = ((meta.rotationDegrees % 360) + 360) % 360
        if (meta.isOriginalFullFrame) {
            return CardCropMetadata.fullOriginal(normRot, meta.cropRevision)
        }
        val clamped = meta.copy(
            topLeftX = if (meta.topLeftX.isFinite()) meta.topLeftX.coerceIn(0f, 1f) else 0.04f,
            topLeftY = if (meta.topLeftY.isFinite()) meta.topLeftY.coerceIn(0f, 1f) else 0.04f,
            topRightX = if (meta.topRightX.isFinite()) meta.topRightX.coerceIn(0f, 1f) else 0.96f,
            topRightY = if (meta.topRightY.isFinite()) meta.topRightY.coerceIn(0f, 1f) else 0.04f,
            bottomRightX = if (meta.bottomRightX.isFinite()) meta.bottomRightX.coerceIn(0f, 1f) else 0.96f,
            bottomRightY = if (meta.bottomRightY.isFinite()) meta.bottomRightY.coerceIn(0f, 1f) else 0.96f,
            bottomLeftX = if (meta.bottomLeftX.isFinite()) meta.bottomLeftX.coerceIn(0f, 1f) else 0.04f,
            bottomLeftY = if (meta.bottomLeftY.isFinite()) meta.bottomLeftY.coerceIn(0f, 1f) else 0.96f,
            rotationDegrees = normRot
        )
        return if (isValidQuad(clamped)) clamped else CardCropMetadata(rotationDegrees = normRot, cropRevision = meta.cropRevision)
    }

    /**
     * Automatically detects business-card boundaries using combined luminance & RGB color distance
     * from outer border patches (handles wood tables, white-on-white, dark surfaces, and glossy cards).
     */
    fun detectAutoCrop(source: Bitmap): CardCropMetadata {
        val w = source.width
        val h = source.height
        if (w < 80 || h < 80) return CardCropMetadata.fullOriginal()

        return runCatching {
            val sampleW = 160
            val sampleH = ((h.toFloat() / w.toFloat()) * sampleW).toInt().coerceIn(80, 260)
            val thumb = Bitmap.createScaledBitmap(source, sampleW, sampleH, true)

            var bgR = 0f; var bgG = 0f; var bgB = 0f; var bgCnt = 0
            fun sampleBg(x: Int, y: Int) {
                val c = thumb.getPixel(x.coerceIn(0, sampleW - 1), y.coerceIn(0, sampleH - 1))
                bgR += Color.red(c); bgG += Color.green(c); bgB += Color.blue(c); bgCnt++
            }
            for (dy in 0 until 6) {
                for (dx in 0 until 6) {
                    sampleBg(dx, dy)
                    sampleBg(sampleW - 1 - dx, dy)
                    sampleBg(dx, sampleH - 1 - dy)
                    sampleBg(sampleW - 1 - dx, sampleH - 1 - dy)
                }
            }
            bgR /= bgCnt.coerceAtLeast(1)
            bgG /= bgCnt.coerceAtLeast(1)
            bgB /= bgCnt.coerceAtLeast(1)

            fun colorDelta(x: Int, y: Int): Float {
                val c = thumb.getPixel(x.coerceIn(0, sampleW - 1), y.coerceIn(0, sampleH - 1))
                val dr = abs(Color.red(c) - bgR)
                val dg = abs(Color.green(c) - bgG)
                val db = abs(Color.blue(c) - bgB)
                return (dr + dg + db) / 3f
            }

            val threshold = 20f
            var left = 0
            for (x in 2 until (sampleW * 0.42f).toInt()) {
                var diffCount = 0
                for (y in (sampleH * 0.18f).toInt() until (sampleH * 0.82f).toInt() step 3) {
                    if (colorDelta(x, y) > threshold) diffCount++
                }
                if (diffCount > sampleH / 12) { left = x; break }
            }

            var right = sampleW - 1
            for (x in (sampleW - 3) downTo (sampleW * 0.58f).toInt()) {
                var diffCount = 0
                for (y in (sampleH * 0.18f).toInt() until (sampleH * 0.82f).toInt() step 3) {
                    if (colorDelta(x, y) > threshold) diffCount++
                }
                if (diffCount > sampleH / 12) { right = x; break }
            }

            var top = 0
            for (y in 2 until (sampleH * 0.42f).toInt()) {
                var diffCount = 0
                for (x in (sampleW * 0.18f).toInt() until (sampleW * 0.82f).toInt() step 3) {
                    if (colorDelta(x, y) > threshold) diffCount++
                }
                if (diffCount > sampleW / 12) { top = y; break }
            }

            var bottom = sampleH - 1
            for (y in (sampleH - 3) downTo (sampleH * 0.58f).toInt()) {
                var diffCount = 0
                for (x in (sampleW * 0.18f).toInt() until (sampleW * 0.82f).toInt() step 3) {
                    if (colorDelta(x, y) > threshold) diffCount++
                }
                if (diffCount > sampleW / 12) { bottom = y; break }
            }

            thumb.recycle()

            val lFrac = (left.toFloat() / sampleW).coerceIn(0.01f, 0.40f)
            val rFrac = (right.toFloat() / sampleW).coerceIn(0.60f, 0.99f)
            val tFrac = (top.toFloat() / sampleH).coerceIn(0.01f, 0.40f)
            val bFrac = (bottom.toFloat() / sampleH).coerceIn(0.60f, 0.99f)

            val candidate = CardCropMetadata(
                topLeftX = lFrac, topLeftY = tFrac,
                topRightX = rFrac, topRightY = tFrac,
                bottomRightX = rFrac, bottomRightY = bFrac,
                bottomLeftX = lFrac, bottomLeftY = bFrac,
                rotationDegrees = 0,
                enhanceReadability = true,
                isOriginalFullFrame = false
            )
            if ((rFrac - lFrac) < 0.25f || (bFrac - tFrac) < 0.25f || !isValidQuad(candidate)) {
                CardCropMetadata()
            } else {
                candidate
            }
        }.getOrDefault(CardCropMetadata())
    }

    /**
     * Applies non-destructive rotation, validated 4-point perspective rectification (Matrix.setPolyToPoly),
     * uniform aspect-preserving scaling (never squashes proportions), and mild readability normalization.
     */
    fun applyCropAndPerspective(source: Bitmap, rawMeta: CardCropMetadata, maxOutputEdgePx: Int = 1800): Bitmap {
        val meta = sanitizeMetadata(rawMeta)
        val rotated = if (meta.rotationDegrees != 0) {
            val m = Matrix().apply { postRotate(meta.rotationDegrees.toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, m, true)
        } else {
            source
        }

        if (meta.isOriginalFullFrame || !isValidQuad(meta)) {
            return rotated
        }

        val w = rotated.width.toFloat()
        val h = rotated.height.toFloat()

        val srcPts = floatArrayOf(
            meta.topLeftX * w, meta.topLeftY * h,
            meta.topRightX * w, meta.topRightY * h,
            meta.bottomRightX * w, meta.bottomRightY * h,
            meta.bottomLeftX * w, meta.bottomLeftY * h
        )

        val topWidth = hypot((srcPts[2] - srcPts[0]).toDouble(), (srcPts[3] - srcPts[1]).toDouble()).toFloat()
        val bottomWidth = hypot((srcPts[4] - srcPts[6]).toDouble(), (srcPts[5] - srcPts[7]).toDouble()).toFloat()
        val leftHeight = hypot((srcPts[6] - srcPts[0]).toDouble(), (srcPts[7] - srcPts[1]).toDouble()).toFloat()
        val rightHeight = hypot((srcPts[4] - srcPts[2]).toDouble(), (srcPts[5] - srcPts[3]).toDouble()).toFloat()

        val rawW = maxOf(topWidth, bottomWidth).coerceAtLeast(160f)
        val rawH = maxOf(leftHeight, rightHeight).coerceAtLeast(100f)

        // Uniform proportional scale preserves exact card aspect ratio without distortion
        val longest = maxOf(rawW, rawH)
        val scale = if (longest > maxOutputEdgePx.toFloat()) maxOutputEdgePx.toFloat() / longest else 1f
        val outW = (rawW * scale).toInt().coerceAtLeast(160)
        val outH = (rawH * scale).toInt().coerceAtLeast(100)

        val dstPts = floatArrayOf(
            0f, 0f,
            outW.toFloat(), 0f,
            outW.toFloat(), outH.toFloat(),
            0f, outH.toFloat()
        )

        val polyMatrix = Matrix()
        val mapped = polyMatrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)
        if (!mapped) {
            return rotated
        }

        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (meta.enhanceReadability) {
            val contrast = 1.07f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            paint.colorFilter = ColorMatrixColorFilter(
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        canvas.drawBitmap(rotated, polyMatrix, paint)
        if (rotated !== source) rotated.recycle()
        return output
    }
}
