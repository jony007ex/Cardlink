package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Menu -> Insights -> Expiry Center
 * Categorizes My IDs into Expired, Within 30 Days, Within 60 Days, Later, and No Expiry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpiryCenterScreen(
    idDocuments: List<IdDocumentEntity>,
    onReviewId: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    val categorized = remember(idDocuments) {
        val expired = mutableListOf<Pair<IdDocumentEntity, Long?>>()
        val within30 = mutableListOf<Pair<IdDocumentEntity, Long?>>()
        val within60 = mutableListOf<Pair<IdDocumentEntity, Long?>>()
        val later = mutableListOf<Pair<IdDocumentEntity, Long?>>()
        val noExpiry = mutableListOf<Pair<IdDocumentEntity, Long?>>()

        idDocuments.forEach { doc ->
            val days = IdExpiryHelper.daysUntilExpiry(doc.expiryDateIso)
            when {
                days == null -> noExpiry.add(doc to null)
                days < 0L -> expired.add(doc to days)
                days <= 30L -> within30.add(doc to days)
                days <= 60L -> within60.add(doc to days)
                else -> later.add(doc to days)
            }
        }
        listOf(
            Triple("Expired", Color(0xFFEF4444), expired.sortedBy { it.second }),
            Triple("Within 30 Days", Color(0xFFF59E0B), within30.sortedBy { it.second }),
            Triple("Within 60 Days", Color(0xFF38BDF8), within60.sortedBy { it.second }),
            Triple("Later", Color(0xFF10B981), later.sortedBy { it.second }),
            Triple("No Expiry", Color(0xFF94A3B8), noExpiry)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.expiry_center_title), fontWeight = FontWeight.Bold)
                        Text(
                            "${idDocuments.size} saved ID document(s)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (idDocuments.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Badge, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                        Text("No IDs Saved Yet", fontWeight = FontWeight.Bold)
                        Text("Add identification documents in Tools -> My IDs to track expiry reminders here.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                categorized.forEach { (sectionTitle, badgeColor, items) ->
                    if (items.isNotEmpty()) {
                        Text(
                            text = "$sectionTitle (${items.size})",
                            style = MaterialTheme.typography.labelLarge,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                        items.forEach { (doc, days) ->
                            val statusText = when {
                                days == null -> "No expiry date set"
                                days < 0L -> "Expired ${-days} day(s) ago"
                                days == 0L -> "Expires today"
                                else -> "Expires in $days day(s) • ${IdExpiryHelper.formatDisplayDate(doc.expiryDateIso)}"
                            }
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { onReviewId(doc.stableUuid) },
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(Icons.Default.Badge, null, tint = badgeColor, modifier = Modifier.size(22.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(doc.documentName, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(doc.documentType, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(statusText, style = MaterialTheme.typography.labelSmall, color = badgeColor, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        TextButton(onClick = { onReviewId(doc.stableUuid) }) {
                                            Text("Review / Renew ID", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                        if (days != null && days <= 60L) {
                                            TextButton(onClick = {
                                                IdExpiryReminderScheduler.rescheduleAll(context)
                                                Toast.makeText(context, "Reminder kept active for ${doc.documentName}", Toast.LENGTH_SHORT).show()
                                            }) {
                                                Text("Remind Later", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Android "Save to CardLink" Share Target + Local Document Inbox Confirmation.
 * Always requires explicit user review before saving any sensitive content.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareIntakeScreen(
    payload: IncomingSharePayload?,
    onSaveQrProject: (QrProjectEntity) -> Unit,
    onSaveSecureNote: (SecureNoteEntity) -> Unit,
    onSaveContact: (SavedContactEntity) -> Unit,
    onSaveIdDocument: (IdDocumentEntity, List<IdDocumentPageEntity>) -> Unit,
    onOpenQrStudio: () -> Unit,
    onOpenScanCard: () -> Unit,
    onOpenLoyaltyCards: () -> Unit,
    onFinished: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var docInboxName by remember { mutableStateOf("Imported Document") }
    var docSuggestedType by remember { mutableStateOf("Unknown Document") }
    var isSavingDoc by remember { mutableStateOf(false) }

    val idTypes = listOf("Passport", "National ID", "Driving Licence", "Office ID", "Unknown Document")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.save_to_cardlink_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onFinished) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (payload == null) {
                Text("No shared content was received.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onFinished, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_close)) }
                return@Column
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Detected Content: ${payload.kind.name}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    if (payload.text.isNotBlank()) {
                        Text(payload.text.take(280), style = MaterialTheme.typography.bodySmall)
                    }
                    if (payload.uris.isNotEmpty()) {
                        Text("${payload.uris.size} file(s) / image(s) attached", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            when (payload.kind) {
                IncomingShareKind.URL, IncomingShareKind.TEXT -> {
                    val isUrl = payload.kind == IncomingShareKind.URL
                    Button(
                        onClick = {
                            val qr = QrProjectEntity(
                                name = if (isUrl) "Shared Link" else "Shared Text",
                                qrType = if (isUrl) QrContentType.URL.name else QrContentType.TEXT.name,
                                payload = payload.text,
                                contentFieldsJson = QrPayloadBuilder.serializeFields(
                                    mapOf(if (isUrl) "url" else "text" to payload.text)
                                )
                            )
                            onSaveQrProject(qr)
                            Toast.makeText(context, "Saved to QR Code Studio!", Toast.LENGTH_SHORT).show()
                            onOpenQrStudio()
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(Icons.Default.QrCode2, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Create QR Code", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            onSaveSecureNote(
                                SecureNoteEntity(
                                    title = if (isUrl) "Saved Link" else "Saved Note",
                                    category = "Imported",
                                    content = payload.text
                                )
                            )
                            Toast.makeText(context, "Saved to Secure Notes!", Toast.LENGTH_SHORT).show()
                            onFinished()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.Lock, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Save as Secure Note")
                    }
                }

                IncomingShareKind.VCARD -> {
                    val contact = remember(payload.text) {
                        if (payload.text.isNotBlank()) CardShareHelper.parseVCardToContact(payload.text, "Android Share") else null
                    }
                    if (contact != null) {
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Preview Contact", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(contact.fullName, fontWeight = FontWeight.Bold)
                                if (contact.companyName.isNotBlank()) Text(contact.companyName, style = MaterialTheme.typography.bodySmall)
                                if (contact.phone.isNotBlank()) Text(contact.phone, style = MaterialTheme.typography.bodySmall)
                                if (contact.email.isNotBlank()) Text(contact.email, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(
                            onClick = {
                                onSaveContact(contact)
                                Toast.makeText(context, "Contact saved to CardLink!", Toast.LENGTH_SHORT).show()
                                onFinished()
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) { Text("Save to CardLink Contacts", fontWeight = FontWeight.Bold) }
                    }
                }

                IncomingShareKind.IMAGE, IncomingShareKind.PDF -> {
                    // Document Inbox Classification Confirmation
                    Text(stringResource(R.string.document_inbox_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "Confirm or change the document type before saving into your encrypted My IDs vault.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = docInboxName,
                        onValueChange = { docInboxName = it },
                        label = { Text("Document Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        idTypes.forEach { t ->
                            FilterChip(
                                selected = docSuggestedType == t,
                                onClick = { docSuggestedType = t },
                                label = { Text(t, fontSize = 11.5.sp) }
                            )
                        }
                    }

                    Button(
                        enabled = !isSavingDoc,
                        onClick = {
                            scope.launch {
                                isSavingDoc = true
                                val savedPageUris = withContext(Dispatchers.IO) {
                                    payload.uris.flatMap { uri -> IdShareHelper.importUriAsIdPageImages(context, uri) }
                                }
                                if (savedPageUris.isNotEmpty()) {
                                    val doc = IdDocumentEntity(
                                        documentName = docInboxName.trim().ifBlank { docSuggestedType },
                                        documentType = docSuggestedType
                                    )
                                    val pages = savedPageUris.mapIndexed { idx, uriStr ->
                                        IdDocumentPageEntity(
                                            documentUuid = doc.stableUuid,
                                            pageIndex = idx,
                                            pageLabel = "Page ${idx + 1}",
                                            imageUri = uriStr,
                                            mimeType = "image/jpeg"
                                        )
                                    }
                                    onSaveIdDocument(doc, pages)
                                    Toast.makeText(context, "Saved securely to My IDs (${pages.size} page(s))!", Toast.LENGTH_LONG).show()
                                    onFinished()
                                } else {
                                    Toast.makeText(context, "Could not read shared document.", Toast.LENGTH_LONG).show()
                                }
                                isSavingDoc = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Text(if (isSavingDoc) "Encrypting & Saving…" else "Confirm & Save to My IDs", fontWeight = FontWeight.Bold)
                    }

                    if (payload.kind == IncomingShareKind.IMAGE) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onOpenScanCard, modifier = Modifier.weight(1f)) { Text("Scan Card", fontSize = 12.sp) }
                            OutlinedButton(onClick = onOpenLoyaltyCards, modifier = Modifier.weight(1f)) { Text("Loyalty Cards", fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Smart Duplicate Center Dialog with Field-by-Field Merge (Keep Existing | Use New Value | Keep Both).
 * Never auto-merges or auto-deletes contacts.
 */
@Composable
fun SmartDuplicateCenterDialog(
    pairs: List<DuplicateContactPair>,
    onMergePair: (merged: SavedContactEntity, deleteDuplicate: SavedContactEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var reviewingPair by remember { mutableStateOf<DuplicateContactPair?>(null) }

    val activeReview = reviewingPair
    if (activeReview != null) {
        val a = activeReview.primary
        val b = activeReview.duplicate
        var chosenPhone by remember(activeReview) { mutableStateOf(a.phone.ifBlank { b.phone }) }
        var chosenEmail by remember(activeReview) { mutableStateOf(a.email.ifBlank { b.email }) }
        var chosenCompany by remember(activeReview) { mutableStateOf(a.companyName.ifBlank { b.companyName }) }
        var chosenNotes by remember(activeReview) {
            mutableStateOf(listOf(a.notes, b.notes).filter { it.isNotBlank() }.distinct().joinToString("\n"))
        }

        AlertDialog(
            onDismissRequest = { reviewingPair = null },
            title = { Text("Field-by-Field Merge", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Match signal: ${activeReview.matchReason}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    MergeFieldChoice("Phone", a.phone, b.phone, chosenPhone) { chosenPhone = it }
                    MergeFieldChoice("Email", a.email, b.email, chosenEmail) { chosenEmail = it }
                    MergeFieldChoice("Company", a.companyName, b.companyName, chosenCompany) { chosenCompany = it }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val merged = a.copy(
                        phone = chosenPhone,
                        email = chosenEmail,
                        companyName = chosenCompany,
                        notes = chosenNotes
                    )
                    onMergePair(merged, b)
                    reviewingPair = null
                }) { Text(stringResource(R.string.action_merge)) }
            },
            dismissButton = {
                TextButton(onClick = { reviewingPair = null }) { Text("Keep Both") }
            }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.duplicate_center_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (pairs.isEmpty()) {
                    Text("No possible duplicate contacts detected.", style = MaterialTheme.typography.bodySmall)
                } else {
                    pairs.forEach { pair ->
                        Card(shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(pair.matchReason, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                Text("Existing: ${pair.primary.fullName} (${pair.primary.companyName.ifBlank { pair.primary.phone }})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Text("Duplicate: ${pair.duplicate.fullName} (${pair.duplicate.companyName.ifBlank { pair.duplicate.phone }})", style = MaterialTheme.typography.bodySmall)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { reviewingPair = pair }) { Text("Review Fields & Merge", fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) } }
    )
}

@Composable
private fun MergeFieldChoice(
    label: String,
    existingVal: String,
    newVal: String,
    selectedVal: String,
    onSelect: (String) -> Unit
) {
    if (existingVal.isBlank() && newVal.isBlank()) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        if (existingVal.equals(newVal, true)) {
            Text("✓ Same: $existingVal", style = MaterialTheme.typography.labelSmall)
        } else {
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (existingVal.isNotBlank()) {
                    FilterChip(selected = selectedVal == existingVal, onClick = { onSelect(existingVal) }, label = { Text("Keep: $existingVal", fontSize = 11.sp) })
                }
                if (newVal.isNotBlank()) {
                    FilterChip(selected = selectedVal == newVal, onClick = { onSelect(newVal) }, label = { Text("Use: $newVal", fontSize = 11.sp) })
                }
            }
        }
    }
}
