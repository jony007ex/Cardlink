package com.cardlink.app.ui.screens

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.components.*
import com.cardlink.app.util.*
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.Executors

private fun ImageProxy.toUprightProfileBitmap(): Bitmap? {
    val buffer = planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rot = imageInfo.rotationDegrees
    if (rot == 0) return raw
    val m = Matrix().apply { postRotate(rot.toFloat()) }
    val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    if (rotated !== raw) raw.recycle()
    return rotated
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditBusinessCardScreen(
    activeCard: BusinessCardEntity,
    onSaveCard: (BusinessCardEntity) -> Unit,
    onOpenCustomizeTemplate: () -> Unit,
    onOpenManageSharingProfiles: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Canonical baseline draft (normalizes legacy single phone/whatsapp transparently without mutating saved state)
    val initialDraft = remember(activeCard) {
        val initPhones = BusinessCardProfileHelper.parsePhoneNumbers(activeCard)
        val initCreds = BusinessCardProfileHelper.parseCredentials(activeCard)
        BusinessCardProfileHelper.applyPhonesAndCredentials(
            card = activeCard,
            phones = initPhones,
            credentials = initCreds,
            showCredentialsOnCard = activeCard.showCredentialsOnCard,
            shareCredentials = activeCard.shareCredentials
        )
    }
    var draft by remember(initialDraft) { mutableStateOf(initialDraft) }
    var phones by remember(initialDraft) { mutableStateOf(BusinessCardProfileHelper.parsePhoneNumbers(initialDraft)) }
    var credentials by remember(initialDraft) { mutableStateOf(BusinessCardProfileHelper.parseCredentials(initialDraft)) }

    // Synchronize draft whenever phones or credentials list changes
    fun updateDraftWithLists(
        base: BusinessCardEntity = draft,
        newPhones: List<CardPhoneRecord> = phones,
        newCreds: List<CardCredentialRecord> = credentials,
        showCreds: Boolean = base.showCredentialsOnCard,
        shareCreds: Boolean = base.shareCredentials
    ) {
        val normPhones = BusinessCardProfileHelper.normalizePhoneListOrderAndPrimary(newPhones)
        val normCreds = BusinessCardProfileHelper.normalizeCredentialOrder(newCreds)
        phones = normPhones
        credentials = normCreds
        draft = BusinessCardProfileHelper.applyPhonesAndCredentials(
            card = base,
            phones = normPhones,
            credentials = normCreds,
            showCredentialsOnCard = showCreds,
            shareCredentials = shareCreds
        )
    }

    // Preview & Import Preview State
    var isPreviewFlipped by remember { mutableStateOf(false) }
    var importPreviewDraft by remember { mutableStateOf<BusinessCardEntity?>(null) }
    val displayedPreviewCard = importPreviewDraft ?: draft
    val hasUnsavedChanges = remember(draft, initialDraft) { draft != initialDraft }

    // Navigation & Unsaved Changes Protection (Section 2, 3, 52)
    var showUnsavedDialog by remember { mutableStateOf(false) }
    var validationErrors by remember { mutableStateOf<List<String>>(emptyList()) }
    var overflowWarnings by remember { mutableStateOf<List<String>>(emptyList()) }

    // Expandable Section Toggles (Section 24 — progressive disclosure!)
    var expandIdentity by remember { mutableStateOf(true) }
    var expandProfessional by remember { mutableStateOf(true) }
    var expandContact by remember { mutableStateOf(true) }
    var expandDigitalSharing by remember { mutableStateOf(false) }
    var expandQrBack by remember { mutableStateOf(false) }
    var expandAdvanced by remember { mutableStateOf(false) }

    // Sub-Dialogs & Sheets
    var showAddOrEditPhoneDialog by remember { mutableStateOf<CardPhoneRecord?>(null) }
    var isAddingNewPhone by remember { mutableStateOf(false) }
    var showAddCredentialDialog by remember { mutableStateOf(false) }
    var showFullDigitalLink by remember { mutableStateOf(false) }
    var showEditDigitalLinkDialog by remember { mutableStateOf(false) }
    var showPhotoSourceSheet by remember { mutableStateOf(false) }
    var showProfilePhotoCamera by remember { mutableStateOf(false) }

    // Card & QR Profile Import States (Sections 4-13)
    var showCardImportCamera by remember { mutableStateOf(false) }
    var cardImportSideIsBack by remember { mutableStateOf(false) }
    var pendingImportCropBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pendingImportCropConfidence by remember { mutableStateOf<CropConfidenceLevel?>(null) }
    var scannedFrontImportContact by remember { mutableStateOf<SavedContactEntity?>(null) }
    var showAskBackSideDialog by remember { mutableStateOf(false) }
    var showQrImportScanner by remember { mutableStateOf(false) }
    var isProcessingImport by remember { mutableStateOf(false) }
    var activeImportResult by remember { mutableStateOf<ExtractedProfileImport?>(null) }
    var activeMergeDiffs by remember { mutableStateOf<List<ProfileMergeDiffItem>>(emptyList()) }

    val activeSharingProfile = remember { SharingProfileManager.getActiveProfile(context) }

    // Media Pickers
    val profilePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) { ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "profile") }
                if (saved != null) draft = draft.copy(profilePhotoUri = saved)
            }
        }
    }
    val companyLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) { ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "logo") }
                if (saved != null) draft = draft.copy(companyLogoUri = saved)
            }
        }
    }
    val importCardGalleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2000) }
                if (bmp != null) {
                    cardImportSideIsBack = false
                    scannedFrontImportContact = null
                    routeImportBitmapToSmartCrop(bmp)
                } else {
                    Toast.makeText(context, context.getString(R.string.edit_import_img_error), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val editLocPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        GeoLocationHelper.getCurrentGpsCoordinates(context)?.let { gps ->
            draft = draft.copy(latitude = gps.first, longitude = gps.second)
            scope.launch {
                if (draft.officeAddress.isBlank()) {
                    GeoLocationHelper.reverseGeocode(context, gps.first, gps.second)?.let { addr ->
                        draft = draft.copy(officeAddress = addr)
                    }
                }
            }
            Toast.makeText(context, context.getString(R.string.edit_gps_pinned_toast), Toast.LENGTH_SHORT).show()
        }
    }

    fun launchMergeReview(imported: ExtractedProfileImport) {
        if (imported.rawWarning.isNotBlank()) {
            Toast.makeText(context, imported.rawWarning, Toast.LENGTH_LONG).show()
            return
        }
        val diffs = BusinessCardProfileHelper.computeMergeDiffs(draft, imported)
        if (diffs.isEmpty()) {
            Toast.makeText(context, context.getString(R.string.edit_import_no_new_fields), Toast.LENGTH_LONG).show()
            return
        }
        activeImportResult = imported
        activeMergeDiffs = diffs
    }

    fun processImportedCardBitmap(croppedBmp: Bitmap) {
        isProcessingImport = true
        scope.launch {
            val extractedContact = runCatching {
                val visionText = OcrEngineRegistry.recognizeBitmap(context, croppedBmp)
                CardOcrPipeline.extractContactWithConfidence(visionText).contact
            }.getOrNull()
            isProcessingImport = false
            if (extractedContact == null) {
                Toast.makeText(context, context.getString(R.string.edit_import_ocr_failed), Toast.LENGTH_LONG).show()
            } else if (!cardImportSideIsBack) {
                scannedFrontImportContact = extractedContact
                showAskBackSideDialog = true
            } else {
                val imported = BusinessCardProfileHelper.extractFromScannedContacts(
                    front = scannedFrontImportContact,
                    back = extractedContact,
                    sourceLabel = context.getString(R.string.edit_scan_existing_card)
                )
                scannedFrontImportContact = null
                cardImportSideIsBack = false
                launchMergeReview(imported)
            }
        }
    }

    fun routeImportBitmapToSmartCrop(rawBmp: Bitmap) {
        val sideLbl = if (cardImportSideIsBack) "BACK" else "FRONT"
        val smartEnabled = SmartCropPrefs.isSmartCropEnabled(context)
        val policy = SmartCropPrefs.getCropReviewPolicy(context)
        if (!smartEnabled) {
            processImportedCardBitmap(rawBmp)
            return
        }
        scope.launch {
            isProcessingImport = true
            val det = withContext(Dispatchers.Default) {
                SmartCardCropEngine.detectAutoCropWithConfidence(rawBmp, SmartCropFeatureType.MY_CARD_IMPORT, sideLbl)
            }
            val (shouldOpenDialog, _) = SmartCardCropEngine.decideReviewBehavior(true, policy, det.confidence)
            if (!shouldOpenDialog) {
                val corrected = withContext(Dispatchers.Default) {
                    SmartCardCropEngine.applyCropAndPerspective(rawBmp, det.metadata, SmartCropFeatureType.MY_CARD_IMPORT.maxOutputEdgePx)
                }
                isProcessingImport = false
                Toast.makeText(context, context.getString(R.string.crop_auto_corrected_toast), Toast.LENGTH_SHORT).show()
                processImportedCardBitmap(corrected)
            } else {
                isProcessingImport = false
                pendingImportCropConfidence = det.confidence
                pendingImportCropBitmap = rawBmp
            }
        }
    }

    fun attemptSaveAndExit(ignoreOverflowWarnings: Boolean = false) {
        val report = BusinessCardProfileHelper.validateDraft(draft)
        if (!report.isValid) {
            validationErrors = report.fieldErrors
            return
        }
        if (!ignoreOverflowWarnings && report.layoutWarnings.isNotEmpty()) {
            overflowWarnings = report.layoutWarnings
            return
        }
        onSaveCard(draft)
        onNavigateBack()
    }

    fun handleBackRequest() {
        when {
            importPreviewDraft != null -> {
                importPreviewDraft = null
            }
            hasUnsavedChanges -> {
                showUnsavedDialog = true
            }
            else -> onNavigateBack()
        }
    }

    // Identical protection for Android System Back & Toolbar Back (Section 52)
    BackHandler(enabled = true) {
        handleBackRequest()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.edit_card_title),
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { handleBackRequest() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // =================================================================
            // 1. LIVE FLIPPABLE PREVIEW (Sections 25-27)
            // =================================================================
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FlippableBusinessCardView(
                    card = displayedPreviewCard,
                    isFlippedExternal = isPreviewFlipped,
                    onFlipToggle = { isPreviewFlipped = !isPreviewFlipped }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                        Text(
                            text = stringResource(R.string.tpl_tap_to_flip_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (isPreviewFlipped) stringResource(R.string.card_side_back) else stringResource(R.string.card_side_front),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Temporary Import Preview Banner (Section 27)
            importPreviewDraft?.let { candidateDraft ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Preview, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = stringResource(R.string.edit_previewing_import_title),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    updateDraftWithLists(
                                        base = candidateDraft,
                                        newPhones = BusinessCardProfileHelper.parsePhoneNumbers(candidateDraft),
                                        newCreds = BusinessCardProfileHelper.parseCredentials(candidateDraft)
                                    )
                                    importPreviewDraft = null
                                    Toast.makeText(context, context.getString(R.string.edit_import_applied_toast), Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                            ) { Text(stringResource(R.string.edit_apply_changes_btn), fontWeight = FontWeight.Bold, fontSize = 12.5.sp) }
                            OutlinedButton(
                                onClick = { importPreviewDraft = null },
                                modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                            ) { Text(stringResource(R.string.edit_cancel_import_btn), fontSize = 12.5.sp) }
                        }
                    }
                }
            }

            if (isProcessingImport) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text(stringResource(R.string.edit_importing_processing), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // =================================================================
            // 2. IMPORT PROFILE DATA (Sections 4-9)
            // =================================================================
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.edit_import_section_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.edit_import_section_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                cardImportSideIsBack = false
                                scannedFrontImportContact = null
                                showCardImportCamera = true
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.edit_scan_existing_card), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(
                            onClick = { showQrImportScanner = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.edit_scan_existing_qr), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    TextButton(
                        onClick = {
                            importCardGalleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.edit_import_image_btn), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // =================================================================
            // 3. PROFILE IDENTITY (Name, Professional Credentials, Profile Photo)
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_sec_identity),
                icon = Icons.Default.Person,
                expanded = expandIdentity,
                onToggle = { expandIdentity = !expandIdentity }
            ) {
                OutlinedTextField(
                    value = draft.profileTitle,
                    onValueChange = { draft = draft.copy(profileTitle = it) },
                    label = { Text(stringResource(R.string.edit_profile_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.fullName,
                    onValueChange = { draft = draft.copy(fullName = it) },
                    label = { Text("${stringResource(R.string.edit_full_name)} *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                // Professional Degrees & Credentials (Sections 19-23, 43)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.edit_credentials_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.edit_credentials_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(
                        onClick = { showAddCredentialDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.edit_add_credential_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (credentials.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        credentials.forEachIndexed { idx, cred ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = cred.label,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                if (idx > 0) {
                                                    val mut = credentials.toMutableList()
                                                    val item = mut.removeAt(idx)
                                                    mut.add(idx - 1, item)
                                                    updateDraftWithLists(newCreds = mut.mapIndexed { i, c -> c.copy(displayOrder = i) })
                                                }
                                            },
                                            enabled = idx > 0,
                                            modifier = Modifier.size(36.dp)
                                        ) { Icon(Icons.Default.ArrowUpward, contentDescription = "Move up", modifier = Modifier.size(16.dp)) }
                                        IconButton(
                                            onClick = {
                                                if (idx < credentials.lastIndex) {
                                                    val mut = credentials.toMutableList()
                                                    val item = mut.removeAt(idx)
                                                    mut.add(idx + 1, item)
                                                    updateDraftWithLists(newCreds = mut.mapIndexed { i, c -> c.copy(displayOrder = i) })
                                                }
                                            },
                                            enabled = idx < credentials.lastIndex,
                                            modifier = Modifier.size(36.dp)
                                        ) { Icon(Icons.Default.ArrowDownward, contentDescription = "Move down", modifier = Modifier.size(16.dp)) }
                                        IconButton(
                                            onClick = {
                                                val remaining = credentials.filterNot { it.id == cred.id }
                                                updateDraftWithLists(newCreds = remaining)
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) { Icon(Icons.Default.Close, contentDescription = stringResource(R.string.qa_remove_btn), tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) }
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.edit_show_credentials_card), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = draft.showCredentialsOnCard,
                            onCheckedChange = { updateDraftWithLists(showCreds = it) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.edit_share_credentials_toggle), style = MaterialTheme.typography.bodySmall)
                        Switch(
                            checked = draft.shareCredentials,
                            onCheckedChange = { updateDraftWithLists(shareCreds = it) }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                // Profile Photo controls (Section 29: Camera | Photos | Remove Photo)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.edit_profile_photo_title), fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
                        Text(
                            text = if (draft.profilePhotoUri.isNullOrBlank()) stringResource(R.string.edit_no_photo_set) else stringResource(R.string.edit_photo_set_lbl),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(
                        onClick = { showPhotoSourceSheet = true },
                        modifier = Modifier.heightIn(min = 44.dp)
                    ) {
                        Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.edit_upload_photo), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // =================================================================
            // 4. PROFESSIONAL INFORMATION
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_sec_professional),
                icon = Icons.Default.Work,
                expanded = expandProfessional,
                onToggle = { expandProfessional = !expandProfessional }
            ) {
                OutlinedTextField(
                    value = draft.designation,
                    onValueChange = { draft = draft.copy(designation = it) },
                    label = { Text(stringResource(R.string.edit_designation)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.companyName,
                    onValueChange = { draft = draft.copy(companyName = it) },
                    label = { Text(stringResource(R.string.edit_company)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.department,
                    onValueChange = { draft = draft.copy(department = it) },
                    label = { Text(stringResource(R.string.edit_department)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // =================================================================
            // 5. CONTACT INFORMATION (Multiple Phone Numbers + Email + Website + Address)
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_sec_contact),
                icon = Icons.Default.Call,
                expanded = expandContact,
                onToggle = { expandContact = !expandContact }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.edit_phones_title),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedButton(
                        onClick = {
                            isAddingNewPhone = true
                            showAddOrEditPhoneDialog = CardPhoneRecord(
                                number = "",
                                type = if (phones.isEmpty()) CardPhoneType.MOBILE else CardPhoneType.OFFICE,
                                isPrimary = phones.isEmpty(),
                                displayOrder = phones.size
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.edit_add_phone_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (phones.isEmpty()) {
                    Text(
                        text = stringResource(R.string.edit_no_phones_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        phones.forEachIndexed { idx, rec ->
                            val primaryTag = stringResource(R.string.edit_phone_primary_badge)
                            val phoneA11y = "${rec.type.displayLabel} ${rec.number}" + if (rec.isPrimary) " ($primaryTag)" else ""
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                border = if (rec.isPrimary) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .semantics { contentDescription = phoneA11y }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                isAddingNewPhone = false
                                                showAddOrEditPhoneDialog = rec
                                            },
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = rec.type.displayLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            if (rec.isPrimary) {
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = MaterialTheme.colorScheme.primary
                                                ) {
                                                    Text(
                                                        text = primaryTag,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onPrimary,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                            if (rec.isWhatsAppEnabled && rec.type != CardPhoneType.WHATSAPP) {
                                                Text("• WhatsApp", fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                        Text(
                                            text = rec.number,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                if (idx > 0) {
                                                    val mut = phones.toMutableList()
                                                    val item = mut.removeAt(idx)
                                                    mut.add(idx - 1, item)
                                                    updateDraftWithLists(newPhones = mut.mapIndexed { i, p -> p.copy(displayOrder = i) })
                                                }
                                            },
                                            enabled = idx > 0,
                                            modifier = Modifier.size(34.dp)
                                        ) { Icon(Icons.Default.ArrowUpward, contentDescription = "Move phone up", modifier = Modifier.size(16.dp)) }
                                        IconButton(
                                            onClick = {
                                                if (idx < phones.lastIndex) {
                                                    val mut = phones.toMutableList()
                                                    val item = mut.removeAt(idx)
                                                    mut.add(idx + 1, item)
                                                    updateDraftWithLists(newPhones = mut.mapIndexed { i, p -> p.copy(displayOrder = i) })
                                                }
                                            },
                                            enabled = idx < phones.lastIndex,
                                            modifier = Modifier.size(34.dp)
                                        ) { Icon(Icons.Default.ArrowDownward, contentDescription = "Move phone down", modifier = Modifier.size(16.dp)) }
                                        IconButton(
                                            onClick = {
                                                isAddingNewPhone = false
                                                showAddOrEditPhoneDialog = rec
                                            },
                                            modifier = Modifier.size(34.dp)
                                        ) { Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.action_edit), modifier = Modifier.size(16.dp)) }
                                        IconButton(
                                            onClick = {
                                                val remaining = phones.filterNot { it.id == rec.id }
                                                updateDraftWithLists(newPhones = remaining)
                                            },
                                            modifier = Modifier.size(34.dp)
                                        ) { Icon(Icons.Default.DeleteOutline, contentDescription = stringResource(R.string.action_delete), tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp)) }
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                OutlinedTextField(
                    value = draft.email,
                    onValueChange = { draft = draft.copy(email = it) },
                    label = { Text(stringResource(R.string.edit_email)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.website,
                    onValueChange = { draft = draft.copy(website = it) },
                    label = { Text(stringResource(R.string.edit_website)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.officeAddress,
                    onValueChange = { draft = draft.copy(officeAddress = it) },
                    label = { Text(stringResource(R.string.edit_office_address)) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                GeoLocationHelper.geocodeAddress(context, draft.officeAddress)?.let {
                                    draft = draft.copy(latitude = it.first, longitude = it.second)
                                    Toast.makeText(context, context.getString(R.string.edit_address_pinned_toast), Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text(stringResource(R.string.edit_auto_pin), fontSize = 12.sp) }
                    OutlinedButton(
                        onClick = { editLocPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text(stringResource(R.string.edit_current_gps), fontSize = 12.sp) }
                }
            }

            // =================================================================
            // 6. DIGITAL SHARING (Shortened Digital Card Link + Sharing Profile + Socials)
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_sec_digital_sharing),
                icon = Icons.Default.Share,
                expanded = expandDigitalSharing,
                onToggle = { expandDigitalSharing = !expandDigitalSharing }
            ) {
                // Shortened Digital Card Link (Section 28)
                val fullLink = draft.publicCardUrl.trim()
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = stringResource(R.string.iphone_digital_card_link_lbl),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (fullLink.isBlank()) {
                                stringResource(R.string.detail_not_set)
                            } else if (showFullDigitalLink) {
                                fullLink
                            } else {
                                IphoneNfcShareHelper.shortenUrlForDisplay(fullLink)
                            },
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.5.sp,
                            maxLines = if (showFullDigitalLink) 4 else 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (fullLink.isNotBlank()) {
                                TextButton(
                                    onClick = { showFullDigitalLink = !showFullDigitalLink },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                ) {
                                    Text(
                                        text = if (showFullDigitalLink) stringResource(R.string.action_close) else stringResource(R.string.edit_view_full_link_btn),
                                        fontSize = 11.5.sp
                                    )
                                }
                                TextButton(
                                    onClick = {
                                        if (IphoneNfcShareHelper.validateDigitalCardUrlLocally(fullLink).isValid) {
                                            runCatching {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fullLink)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                            }
                                        } else {
                                            Toast.makeText(context, context.getString(R.string.nfc_iphone_url_invalid), Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                ) { Text(stringResource(R.string.iphone_test_link_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
                            }
                            TextButton(
                                onClick = { showEditDigitalLinkDialog = true },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                            ) { Text(stringResource(R.string.action_edit), fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }

                // Active Sharing Profile Integration (Section 35)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.iphone_sharing_profile_title), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(activeSharingProfile.label, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                    }
                    TextButton(onClick = onOpenManageSharingProfiles) {
                        Text(stringResource(R.string.iphone_manage_profiles_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = draft.linkedInUrl,
                    onValueChange = { draft = draft.copy(linkedInUrl = it) },
                    label = { Text(stringResource(R.string.edit_linkedin)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.facebookUrl,
                    onValueChange = { draft = draft.copy(facebookUrl = it) },
                    label = { Text(stringResource(R.string.cd_facebook_lbl)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // =================================================================
            // 7. QR BACK & LOGOS (Section 30)
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_qr_back_section),
                icon = Icons.Default.QrCode2,
                expanded = expandQrBack,
                onToggle = { expandQrBack = !expandQrBack }
            ) {
                Text(
                    text = stringResource(R.string.edit_company_qr_logo_explain),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { companyLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) {
                        Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.edit_company_qr_logo_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (!draft.companyLogoUri.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = { draft = draft.copy(companyLogoUri = null) },
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                OutlinedTextField(
                    value = draft.backHeading,
                    onValueChange = { draft = draft.copy(backHeading = it.take(60)) },
                    label = { Text(stringResource(R.string.edit_back_heading)) },
                    placeholder = { Text(draft.companyName.ifBlank { "CardLink" }) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.backMessage,
                    onValueChange = { draft = draft.copy(backMessage = it.take(180)) },
                    label = { Text("${stringResource(R.string.edit_back_message)} (${draft.backMessage.length} / 180)") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // =================================================================
            // 8. ADVANCED (Optional Bio + Save as New Profile)
            // =================================================================
            CollapsibleEditorSectionCard(
                title = stringResource(R.string.edit_sec_advanced),
                icon = Icons.Default.Tune,
                expanded = expandAdvanced,
                onToggle = { expandAdvanced = !expandAdvanced }
            ) {
                OutlinedTextField(
                    value = draft.bio,
                    onValueChange = { draft = draft.copy(bio = it.take(220)) },
                    label = { Text(stringResource(R.string.edit_bio_tagline_lbl)) },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = {
                        val report = BusinessCardProfileHelper.validateDraft(draft)
                        if (!report.isValid) {
                            validationErrors = report.fieldErrors
                        } else {
                            onSaveCard(draft.copy(id = 0L, profileTitle = draft.profileTitle.ifBlank { "New Profile" }, isDefault = true))
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                ) { Text(stringResource(R.string.action_save_as_new), fontWeight = FontWeight.SemiBold) }
            }

            Spacer(Modifier.height(4.dp))

            // =================================================================
            // 9. ONE CLEAR SAVE ACTION BAR (Section 31)
            // =================================================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { handleBackRequest() },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(0.9f).height(52.dp)
                ) {
                    Text(stringResource(R.string.action_cancel), fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { attemptSaveAndExit(ignoreOverflowWarnings = false) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1.4f).height(52.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.edit_save_business_card_btn), fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(18.dp))
        }
    }

    // =========================================================================
    // DIALOGS & SHEETS
    // =========================================================================

    // Unsaved Changes Protection Dialog (Section 3 & 52)
    if (showUnsavedDialog) {
        AlertDialog(
            onDismissRequest = { showUnsavedDialog = false },
            title = { Text(stringResource(R.string.edit_unsaved_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.edit_unsaved_msg)) },
            confirmButton = {
                Button(onClick = {
                    showUnsavedDialog = false
                    attemptSaveAndExit(ignoreOverflowWarnings = false)
                }) { Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { showUnsavedDialog = false }) { Text(stringResource(R.string.qa_keep_editing_btn)) }
                    TextButton(onClick = {
                        showUnsavedDialog = false
                        onNavigateBack()
                    }) { Text(stringResource(R.string.qa_discard_btn), color = MaterialTheme.colorScheme.error) }
                }
            }
        )
    }

    // Validation Errors Dialog (Section 33)
    if (validationErrors.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { validationErrors = emptyList() },
            title = { Text(stringResource(R.string.edit_validation_error_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    validationErrors.forEach { err ->
                        Text("• $err", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { validationErrors = emptyList() }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // Layout Overflow Warning Dialog (Section 34)
    if (overflowWarnings.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { overflowWarnings = emptyList() },
            title = { Text(stringResource(R.string.edit_layout_attention_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.edit_layout_attention_sub), style = MaterialTheme.typography.bodySmall)
                    overflowWarnings.forEach { w ->
                        Text("• $w", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    overflowWarnings = emptyList()
                    attemptSaveAndExit(ignoreOverflowWarnings = true)
                }) { Text(stringResource(R.string.edit_save_anyway_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { overflowWarnings = emptyList() }) { Text(stringResource(R.string.qa_review_btn)) }
                    TextButton(onClick = {
                        overflowWarnings = emptyList()
                        onSaveCard(draft)
                        onOpenCustomizeTemplate()
                    }) { Text(stringResource(R.string.edit_choose_template_btn)) }
                }
            }
        )
    }

    // Add / Edit Phone Number Dialog (Sections 14-18)
    showAddOrEditPhoneDialog?.let { editingPhone ->
        var numDraft by remember(editingPhone.id) { mutableStateOf(editingPhone.number) }
        var typeDraft by remember(editingPhone.id) { mutableStateOf(editingPhone.type) }
        var primaryDraft by remember(editingPhone.id) { mutableStateOf(editingPhone.isPrimary) }
        var waDraft by remember(editingPhone.id) { mutableStateOf(editingPhone.isWhatsAppEnabled || editingPhone.type == CardPhoneType.WHATSAPP) }
        val isNumValid = numDraft.isBlank() || BusinessCardProfileHelper.isValidPhoneNumber(numDraft)

        AlertDialog(
            onDismissRequest = { showAddOrEditPhoneDialog = null },
            title = {
                Text(
                    text = if (isAddingNewPhone) stringResource(R.string.edit_add_phone_btn) else stringResource(R.string.edit_edit_phone_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = numDraft,
                        onValueChange = { numDraft = it },
                        label = { Text(stringResource(R.string.detail_phone)) },
                        placeholder = { Text("+880 17XX-XXXXXX") },
                        isError = !isNumValid,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!isNumValid) {
                        Text(stringResource(R.string.edit_phone_invalid_hint), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CardPhoneType.values().forEach { pt ->
                            FilterChip(
                                selected = typeDraft == pt,
                                onClick = {
                                    typeDraft = pt
                                    if (pt == CardPhoneType.WHATSAPP) waDraft = true
                                },
                                label = { Text(pt.displayLabel, fontSize = 11.5.sp) }
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.edit_phone_set_primary), style = MaterialTheme.typography.bodySmall)
                        Switch(checked = primaryDraft, onCheckedChange = { primaryDraft = it })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.edit_phone_wa_enabled), style = MaterialTheme.typography.bodySmall)
                        Switch(checked = waDraft, onCheckedChange = { waDraft = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = numDraft.isNotBlank() && isNumValid,
                    onClick = {
                        val updatedRec = editingPhone.copy(
                            number = numDraft.trim(),
                            type = typeDraft,
                            isPrimary = primaryDraft,
                            isWhatsAppEnabled = waDraft || typeDraft == CardPhoneType.WHATSAPP
                        )
                        val normNew = BusinessCardProfileHelper.normalizePhoneForComparison(updatedRec.number)
                        val baseList = if (isAddingNewPhone) {
                            // Deduplicate if same formatted number already exists
                            phones.filterNot { BusinessCardProfileHelper.normalizePhoneForComparison(it.number) == normNew }
                        } else {
                            phones.filterNot { it.id == updatedRec.id }
                        }
                        val nextList = (baseList.map { if (updatedRec.isPrimary) it.copy(isPrimary = false) else it } + updatedRec)
                        updateDraftWithLists(newPhones = nextList)
                        showAddOrEditPhoneDialog = null
                    }
                ) { Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showAddOrEditPhoneDialog = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Add Professional Credential Dialog (Sections 19-20)
    if (showAddCredentialDialog) {
        var customCred by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddCredentialDialog = false },
            title = { Text(stringResource(R.string.edit_add_credential_btn), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = customCred,
                        onValueChange = { customCred = it.take(24) },
                        label = { Text(stringResource(R.string.edit_credential_input_lbl)) },
                        placeholder = { Text("MBA, CIPS, CFA, PhD…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(stringResource(R.string.edit_common_credentials_lbl), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BusinessCardProfileHelper.COMMON_CREDENTIALS.forEach { preset ->
                            val alreadyAdded = credentials.any { it.label.equals(preset, true) }
                            FilterChip(
                                selected = alreadyAdded,
                                onClick = {
                                    if (!alreadyAdded) {
                                        updateDraftWithLists(
                                            newCreds = credentials + CardCredentialRecord(
                                                id = UUID.randomUUID().toString(),
                                                label = preset,
                                                displayOrder = credentials.size
                                            )
                                        )
                                    }
                                },
                                label = { Text(preset, fontSize = 11.5.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = customCred.trim().isNotBlank(),
                    onClick = {
                        val clean = customCred.trim()
                        updateDraftWithLists(
                            newCreds = credentials + CardCredentialRecord(
                                id = UUID.randomUUID().toString(),
                                label = clean,
                                displayOrder = credentials.size
                            )
                        )
                        showAddCredentialDialog = false
                    }
                ) { Text(stringResource(R.string.loyalty_add_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showAddCredentialDialog = false }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // Edit Digital Card Link Dialog (Section 28)
    if (showEditDigitalLinkDialog) {
        var urlDraft by remember(draft.publicCardUrl) { mutableStateOf(draft.publicCardUrl) }
        val urlCheck = remember(urlDraft) {
            if (urlDraft.isBlank()) IphoneUrlValidationResult(true, true)
            else IphoneNfcShareHelper.validateDigitalCardUrlLocally(urlDraft)
        }
        AlertDialog(
            onDismissRequest = { showEditDigitalLinkDialog = false },
            title = { Text(stringResource(R.string.iphone_edit_link_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = urlDraft,
                        onValueChange = { urlDraft = it },
                        label = { Text(stringResource(R.string.nfc_iphone_url_lbl)) },
                        isError = !urlCheck.isValid,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!urlCheck.isValid) {
                        Text(urlCheck.errorMessage, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = urlCheck.isValid,
                    onClick = {
                        draft = draft.copy(publicCardUrl = urlDraft.trim())
                        showEditDigitalLinkDialog = false
                    }
                ) { Text(stringResource(R.string.iphone_save_changes_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showEditDigitalLinkDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Profile Photo Source Sheet (Camera | Photos | Remove Photo)
    if (showPhotoSourceSheet) {
        val actions = buildList {
            add(CardLinkSheetAction(Icons.Default.PhotoCamera, stringResource(R.string.edit_photo_camera)) {
                showProfilePhotoCamera = true
            })
            add(CardLinkSheetAction(Icons.Default.PhotoLibrary, stringResource(R.string.edit_photo_gallery)) {
                profilePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            })
            if (!draft.profilePhotoUri.isNullOrBlank()) {
                add(CardLinkSheetAction(Icons.Default.DeleteOutline, stringResource(R.string.edit_photo_remove), isDestructive = true) {
                    draft = draft.copy(profilePhotoUri = null)
                })
            }
        }
        CardLinkActionSheet(
            title = stringResource(R.string.edit_profile_photo_title),
            actions = actions,
            onDismiss = { showPhotoSourceSheet = false }
        )
    }

    if (showProfilePhotoCamera) {
        ProfileCameraCaptureDialog(
            isCardFrame = false,
            title = stringResource(R.string.edit_profile_photo_title),
            onCaptured = { bmp ->
                showProfilePhotoCamera = false
                scope.launch {
                    val saved = withContext(Dispatchers.IO) {
                        runCatching {
                            val longest = maxOf(bmp.width, bmp.height)
                            val scaled = if (longest > 800) {
                                val r = 800f / longest.toFloat()
                                Bitmap.createScaledBitmap(bmp, (bmp.width * r).toInt().coerceAtLeast(1), (bmp.height * r).toInt().coerceAtLeast(1), true)
                            } else bmp
                            val dir = File(context.filesDir, "profile_assets").apply { if (!exists()) mkdirs() }
                            val file = File(dir, "profile_${System.currentTimeMillis()}.jpg")
                            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                            if (scaled !== bmp) scaled.recycle()
                            Uri.fromFile(file).toString()
                        }.getOrNull()
                    }
                    bmp.recycle()
                    if (saved != null) draft = draft.copy(profilePhotoUri = saved)
                }
            },
            onDismiss = { showProfilePhotoCamera = false }
        )
    }

    // In-App Business Card Import Camera (reuses CardLinkCameraZoomState 0.5x/1x/3.5x + SmartCardCropDialog + OcrEngineRegistry!)
    if (showCardImportCamera) {
        ProfileCameraCaptureDialog(
            isCardFrame = true,
            title = if (cardImportSideIsBack) stringResource(R.string.card_side_back) else stringResource(R.string.edit_scan_existing_card),
            onCaptured = { rawBmp ->
                showCardImportCamera = false
                routeImportBitmapToSmartCrop(rawBmp)
            },
            onDismiss = { showCardImportCamera = false }
        )
    }

    pendingImportCropBitmap?.let { srcBmp ->
        SmartCardCropDialog(
            sourceBitmap = srcBmp,
            featureType = SmartCropFeatureType.MY_CARD_IMPORT,
            sideLabel = if (cardImportSideIsBack) "BACK" else "FRONT",
            initialConfidence = pendingImportCropConfidence,
            onRetake = { pendingImportCropBitmap = null; pendingImportCropConfidence = null; showCardImportCamera = true },
            onConfirm = { croppedBmp, _ ->
                pendingImportCropBitmap = null
                pendingImportCropConfidence = null
                processImportedCardBitmap(croppedBmp)
            },
            onDismiss = { pendingImportCropBitmap = null; pendingImportCropConfidence = null }
        )
    }

    // Dual-Side Import Prompt (Section 7: Add Back Side or Review Now)
    if (showAskBackSideDialog) {
        AlertDialog(
            onDismissRequest = { showAskBackSideDialog = false },
            title = { Text(stringResource(R.string.edit_import_front_done_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.edit_import_front_done_msg)) },
            confirmButton = {
                Button(onClick = {
                    showAskBackSideDialog = false
                    val imported = BusinessCardProfileHelper.extractFromScannedContacts(
                        front = scannedFrontImportContact,
                        back = null,
                        sourceLabel = context.getString(R.string.edit_scan_existing_card)
                    )
                    scannedFrontImportContact = null
                    launchMergeReview(imported)
                }) { Text(stringResource(R.string.qa_review_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    showAskBackSideDialog = false
                    cardImportSideIsBack = true
                    showCardImportCamera = true
                }) { Text(stringResource(R.string.edit_add_back_side_btn)) }
            }
        )
    }

    // In-App QR Import Scanner (Sections 8-9: Reuses ML Kit + UniversalQrParser; NEVER executes scanned URLs!)
    if (showQrImportScanner) {
        ProfileQrImportDialog(
            onQrDecoded = { rawPayload ->
                showQrImportScanner = false
                val imported = BusinessCardProfileHelper.extractFromQrPayload(rawPayload)
                launchMergeReview(imported)
            },
            onDismiss = { showQrImportScanner = false }
        )
    }

    // Field-by-Field Review Imported Information Sheet (Sections 10-12, 27)
    val importObj = activeImportResult
    if (importObj != null && activeMergeDiffs.isNotEmpty()) {
        val decisionMap = remember(activeMergeDiffs) {
            mutableStateMapOf<String, MergeFieldChoice>().apply {
                activeMergeDiffs.forEach { d -> put(d.fieldKey, d.defaultChoice) }
            }
        }
        ModalBottomSheet(
            onDismissRequest = { activeImportResult = null; activeMergeDiffs = emptyList() },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 580.dp)
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = stringResource(R.string.edit_review_import_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Quick Bulk Controls (Section 11)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            activeMergeDiffs.forEach { d ->
                                decisionMap[d.fieldKey] = if (d.supportsKeepBoth && d.currentValue.isNotBlank()) MergeFieldChoice.KEEP_BOTH else MergeFieldChoice.USE_SCANNED
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.edit_bulk_use_scanned), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    OutlinedButton(
                        onClick = {
                            activeMergeDiffs.forEach { d -> decisionMap[d.fieldKey] = MergeFieldChoice.KEEP_CURRENT }
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.edit_bulk_keep_existing), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }

                Column(
                    modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    activeMergeDiffs.forEach { diff ->
                        val choice = decisionMap[diff.fieldKey] ?: diff.defaultChoice
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(diff.label, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = "${stringResource(R.string.crop_diff_current)}: ${diff.currentValue.ifBlank { "—" }}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${stringResource(R.string.edit_diff_scanned)}: ${diff.scannedValue}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    FilterChip(
                                        selected = choice == MergeFieldChoice.KEEP_CURRENT,
                                        onClick = { decisionMap[diff.fieldKey] = MergeFieldChoice.KEEP_CURRENT },
                                        label = { Text(stringResource(R.string.crop_diff_keep_current), fontSize = 11.sp) }
                                    )
                                    FilterChip(
                                        selected = choice == MergeFieldChoice.USE_SCANNED,
                                        onClick = { decisionMap[diff.fieldKey] = MergeFieldChoice.USE_SCANNED },
                                        label = { Text(stringResource(R.string.edit_use_scanned_btn), fontSize = 11.sp) }
                                    )
                                    if (diff.supportsKeepBoth) {
                                        FilterChip(
                                            selected = choice == MergeFieldChoice.KEEP_BOTH,
                                            onClick = { decisionMap[diff.fieldKey] = MergeFieldChoice.KEEP_BOTH },
                                            label = { Text(stringResource(R.string.prod_keep_both_btn), fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            importPreviewDraft = BusinessCardProfileHelper.applyMergeDecisions(draft, importObj, decisionMap.toMap())
                            activeImportResult = null
                            activeMergeDiffs = emptyList()
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.qa_label_preview), fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = {
                            val merged = BusinessCardProfileHelper.applyMergeDecisions(draft, importObj, decisionMap.toMap())
                            updateDraftWithLists(
                                base = merged,
                                newPhones = BusinessCardProfileHelper.parsePhoneNumbers(merged),
                                newCreds = BusinessCardProfileHelper.parseCredentials(merged)
                            )
                            importPreviewDraft = null
                            activeImportResult = null
                            activeMergeDiffs = emptyList()
                            Toast.makeText(context, context.getString(R.string.edit_import_applied_toast), Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(stringResource(R.string.qa_apply_btn), fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun CollapsibleEditorSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .clickable(onClick = onToggle),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp, color = MaterialTheme.colorScheme.primary)
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun ProfileCameraCaptureDialog(
    isCardFrame: Boolean,
    title: String,
    onCaptured: (Bitmap) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPerm = granted
    }
    LaunchedEffect(Unit) { if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA) }

    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val zoomState = remember { CardLinkCameraZoomState() }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { runCatching { cameraRef?.cameraControl?.enableTorch(false) } }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply { this.attachTapToFocus(zoomState) }
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(
                                    lifecycleOwner,
                                    if (isCardFrame) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA,
                                    preview,
                                    imageCapture
                                )
                                cameraRef = cam
                                hasFlash = cam.cameraInfo.hasFlashUnit()
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                if (isCardFrame) {
                    val accent = MaterialTheme.colorScheme.primary
                    Canvas(modifier = Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
                        val cardW = size.width * 0.88f
                        val cardH = cardW / 1.586f
                        val left = (size.width - cardW) / 2f
                        val top = (size.height - cardH) / 2.2f
                        drawRect(color = Color.Black.copy(alpha = 0.55f))
                        drawRoundRect(color = Color.Transparent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), blendMode = BlendMode.Clear)
                        drawRoundRect(color = accent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(24f, 24f), style = Stroke(width = 5f))
                    }
                }

                ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 104.dp)
                )

                Row(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(Modifier.size(48.dp))
                    Button(
                        onClick = {
                            if (isCapturing) return@Button
                            isCapturing = true
                            imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                                override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                    val bmp = imageProxy.toUprightProfileBitmap()
                                    imageProxy.close()
                                    isCapturing = false
                                    if (bmp != null) onCaptured(bmp)
                                }
                                override fun onError(exc: ImageCaptureException) { isCapturing = false }
                            })
                        },
                        enabled = !isCapturing,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp)
                    ) {
                        if (isCapturing) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(26.dp), strokeWidth = 2.5.dp)
                        else Icon(Icons.Default.PhotoCamera, contentDescription = title, modifier = Modifier.size(28.dp))
                    }
                    if (hasFlash) {
                        IconButton(
                            onClick = { torchOn = !torchOn; runCatching { cameraRef?.cameraControl?.enableTorch(torchOn) } },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.16f), CircleShape)
                        ) {
                            Icon(if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff, contentDescription = stringResource(R.string.scanner_flashlight), tint = Color.White)
                        }
                    } else Spacer(Modifier.size(48.dp))
                }
            } else {
                Column(modifier = Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.65f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White) }
            }
        }
    }
}

@Composable
private fun ProfileQrImportDialog(
    onQrDecoded: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var hasPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> hasPerm = granted }
    val galleryQrLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val codes = LoyaltyCodeHelper.detectCodesFromUri(context, uri, mode = "QR")
                val raw = codes.firstOrNull()?.rawValue
                if (!raw.isNullOrBlank()) onQrDecoded(raw)
                else Toast.makeText(context, context.getString(R.string.edit_qr_not_found_toast), Toast.LENGTH_SHORT).show()
            }
        }
    }
    LaunchedEffect(Unit) { if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA) }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }
    val zoomState = remember { CardLinkCameraZoomState() }
    var delivered by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { scanner.close() }
            runCatching { cameraExecutor.shutdown() }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply { this.attachTapToFocus(zoomState) }
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                                    val mediaImg = imageProxy.image
                                    if (!delivered && mediaImg != null) {
                                        val input = InputImage.fromMediaImage(mediaImg, imageProxy.imageInfo.rotationDegrees)
                                        scanner.process(input)
                                            .addOnSuccessListener { list ->
                                                val raw = list.firstOrNull()?.rawValue?.trim()
                                                if (!delivered && !raw.isNullOrBlank()) {
                                                    delivered = true
                                                    onQrDecoded(raw)
                                                }
                                            }
                                            .addOnCompleteListener { imageProxy.close() }
                                    } else {
                                        imageProxy.close()
                                    }
                                }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )
                ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 92.dp)
                )
            } else {
                Column(modifier = Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.65f)) {
                    Text(stringResource(R.string.edit_scan_existing_qr), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White) }
            }

            OutlinedButton(
                onClick = { galleryQrLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.65f)),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp)
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.qr_gallery), fontWeight = FontWeight.Bold)
            }
        }
    }
}
