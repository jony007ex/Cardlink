package com.cardlink.app.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.cardlink.app.R
import com.cardlink.app.data.model.LoyaltyCardEntity
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkCameraZoomState
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.ui.components.FlippableContactCardViewer
import com.cardlink.app.ui.components.FullScreenContactCardDialog
import com.cardlink.app.ui.components.ScannerZoomPresetBar
import com.cardlink.app.ui.components.SmartCardCropDialog
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.ui.components.attachTapToFocus
import com.cardlink.app.ui.components.cardLinkPinchToZoom
import com.cardlink.app.util.*
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private enum class LoyaltySortOption(val labelRes: Int) {
    RECENTLY_USED(R.string.loyalty_sort_used),
    RECENTLY_ADDED(R.string.loyalty_sort_added),
    RECENTLY_UPDATED(R.string.loyalty_sort_updated),
    NAME_AZ(R.string.loyalty_sort_az)
}

private enum class LoyaltyFilterOption(val labelRes: Int) {
    ALL(R.string.loyalty_filter_all),
    FAVORITES(R.string.loyalty_filter_favorites),
    RECENT(R.string.loyalty_filter_recent),
    BARCODE(R.string.loyalty_filter_barcode),
    QR(R.string.loyalty_filter_qr)
}

private const val LOYALTY_UI_PREFS = "cardlink_loyalty_ux_prefs"
private const val KEY_FIRST_TIP_DISMISSED = "first_use_tip_dismissed"
private const val KEY_DISMISSED_FAV_CARDS = "dismissed_fav_card_uuids"

private tailrec fun Context.findLoyaltyActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findLoyaltyActivity()
    else -> null
}

private fun ImageProxy.toUprightLoyaltyBitmap(): Bitmap? {
    val buffer = planes.firstOrNull()?.buffer ?: return null
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    val rot = imageInfo.rotationDegrees
    if (rot == 0) return raw
    val m = Matrix().apply { postRotate(rot.toFloat()) }
    val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    if (rotated !== raw) raw.recycle()
    return rotated
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardWalletScreen(
    loyaltyCards: List<LoyaltyCardEntity>,
    onAddCardWithMode: (String) -> Unit,
    onOpenCard: (Long) -> Unit,
    onToggleFavorite: (LoyaltyCardEntity) -> Unit = {},
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showFilterPanel by remember { mutableStateOf(false) }
    var filterOption by remember { mutableStateOf(LoyaltyFilterOption.ALL) }
    var sortOption by remember { mutableStateOf(LoyaltySortOption.RECENTLY_USED) }
    var showAddMethodSheet by remember { mutableStateOf(false) }

    val prefs = remember { context.getSharedPreferences(LOYALTY_UI_PREFS, Context.MODE_PRIVATE) }
    var tipDismissed by remember { mutableStateOf(prefs.getBoolean(KEY_FIRST_TIP_DISMISSED, false)) }
    var dismissedFavSet by remember {
        mutableStateOf(prefs.getStringSet(KEY_DISMISSED_FAV_CARDS, emptySet())?.toSet() ?: emptySet())
    }

    val suggestedFavoriteCard = remember(loyaltyCards, dismissedFavSet) {
        loyaltyCards.firstOrNull { !it.isFavorite && it.usageCount >= 3 && it.stableUuid !in dismissedFavSet }
    }

    val displayedCards = remember(loyaltyCards, searchQuery, filterOption, sortOption) {
        val q = searchQuery.trim()
        val filtered = loyaltyCards.filter { c ->
            val matchesQuery = q.isBlank() ||
                c.brandName.contains(q, true) ||
                c.cardNickname.contains(q, true) ||
                c.cardNumber.contains(q, true) ||
                c.cardholderName.contains(q, true)
            val matchesFilter = when (filterOption) {
                LoyaltyFilterOption.ALL -> true
                LoyaltyFilterOption.FAVORITES -> c.isFavorite
                LoyaltyFilterOption.RECENT -> c.lastUsedTimestamp > 0L
                LoyaltyFilterOption.BARCODE -> c.barcodeValue.isNotBlank()
                LoyaltyFilterOption.QR -> c.qrPayload.isNotBlank()
            }
            matchesQuery && matchesFilter
        }
        when (sortOption) {
            LoyaltySortOption.RECENTLY_USED -> filtered.sortedWith(
                compareByDescending<LoyaltyCardEntity> { it.isFavorite }
                    .thenByDescending { it.lastUsedTimestamp }
                    .thenByDescending { it.createdAtTimestamp }
            )
            LoyaltySortOption.RECENTLY_ADDED -> filtered.sortedByDescending { it.createdAtTimestamp }
            LoyaltySortOption.RECENTLY_UPDATED -> filtered.sortedByDescending { it.updatedAtTimestamp }
            LoyaltySortOption.NAME_AZ -> filtered.sortedBy { it.brandName.lowercase(Locale.getDefault()) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.loyalty_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.loyalty_wallet_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (loyaltyCards.isNotEmpty()) {
                        IconButton(onClick = {
                            showSearchBar = !showSearchBar
                            if (!showSearchBar) searchQuery = ""
                        }) {
                            Icon(Icons.Default.Search, contentDescription = "Search Loyalty Cards")
                        }
                        IconButton(onClick = { showFilterPanel = !showFilterPanel }) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Filter & Sort",
                                tint = if (showFilterPanel || filterOption != LoyaltyFilterOption.ALL) MaterialTheme.colorScheme.primary else LocalContentColor.current
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            val addLabel = stringResource(R.string.loyalty_add_card)
            FloatingActionButton(
                onClick = { showAddMethodSheet = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier.semantics { contentDescription = addLabel }
            ) {
                Icon(Icons.Default.Add, contentDescription = addLabel)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (loyaltyCards.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.CardMembership, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(34.dp))
                                }
                            }
                            Text(
                                text = stringResource(R.string.loyalty_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.loyalty_empty_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = { showAddMethodSheet = true },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.loyalty_add_card), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                AnimatedVisibility(visible = showSearchBar) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(stringResource(R.string.loyalty_search_hint)) },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                AnimatedVisibility(visible = showFilterPanel) {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltyFilterOption.values().forEach { opt ->
                                    FilterChip(
                                        selected = filterOption == opt,
                                        onClick = { filterOption = opt },
                                        label = { Text(stringResource(opt.labelRes), fontSize = 11.5.sp) }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltySortOption.values().forEach { opt ->
                                    FilterChip(
                                        selected = sortOption == opt,
                                        onClick = { sortOption = opt },
                                        label = { Text(stringResource(opt.labelRes), fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                }

                if (!tipDismissed) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.TipsAndUpdates, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = stringResource(R.string.loyalty_first_tip),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    tipDismissed = true
                                    prefs.edit().putBoolean(KEY_FIRST_TIP_DISMISSED, true).apply()
                                },
                                modifier = Modifier.size(28.dp)
                            ) { Icon(Icons.Default.Close, contentDescription = "Dismiss tip", modifier = Modifier.size(16.dp)) }
                        }
                    }
                }

                if (suggestedFavoriteCard != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.StarOutline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = stringResource(R.string.loyalty_suggest_fav_msg, suggestedFavoriteCard.brandName),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                val next = dismissedFavSet + suggestedFavoriteCard.stableUuid
                                dismissedFavSet = next
                                prefs.edit().putStringSet(KEY_DISMISSED_FAV_CARDS, next).apply()
                            }) { Text(stringResource(R.string.qa_not_now_btn), fontSize = 11.sp) }
                            TextButton(onClick = { onToggleFavorite(suggestedFavoriteCard) }) {
                                Text(stringResource(R.string.loyalty_add_btn), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                if (displayedCards.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            stringResource(R.string.loyalty_no_matches),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 154.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 88.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedCards, key = { it.stableUuid.ifBlank { it.id.toString() } }) { card ->
                            LoyaltyCardGridTile(
                                card = card,
                                onToggleFavorite = { onToggleFavorite(card) },
                                onClick = { onOpenCard(card.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddMethodSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddMethodSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = stringResource(R.string.loyalty_add_card),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                AddMethodRow(Icons.Default.PhotoCamera, stringResource(R.string.loyalty_method_scan_card), stringResource(R.string.loyalty_method_scan_card_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("CAMERA")
                }
                AddMethodRow(Icons.Default.PhotoLibrary, stringResource(R.string.loyalty_method_choose_img), stringResource(R.string.loyalty_method_choose_img_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("GALLERY")
                }
                AddMethodRow(Icons.Default.QrCodeScanner, stringResource(R.string.loyalty_method_scan_code), stringResource(R.string.loyalty_method_scan_code_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("SCAN_CODE")
                }
                AddMethodRow(Icons.Default.Edit, stringResource(R.string.loyalty_method_manual), stringResource(R.string.loyalty_method_manual_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("MANUAL")
                }
            }
        }
    }
}

@Composable
private fun AddMethodRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(20.dp))
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LoyaltyCardGridTile(
    card: LoyaltyCardEntity,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()
    val previewUri = card.frontPhotoUri ?: card.backPhotoUri

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (card.isFavorite) 0.7f else 0.3f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (!previewUri.isNullOrBlank()) {
                    VaultImage(
                        uriString = previewUri,
                        contentDescription = card.brandName,
                        contentScale = ContentScale.Crop,
                        maxEdgePx = 420,
                        cacheBustKey = "${card.id}_${if (!card.frontPhotoUri.isNullOrBlank()) "front_${card.frontCropRevision}" else "back_${card.backCropRevision}"}",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Icon(Icons.Default.CardMembership, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Text(
                            text = card.brandName.ifBlank { "Card" }.take(18),
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.align(Alignment.TopStart).size(32.dp).padding(4.dp)
                ) {
                    Icon(
                        imageVector = if (card.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = if (card.isFavorite) "Favorite" else "Not favorite",
                        tint = if (card.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (hasBarcode || hasQr) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (hasBarcode) Icon(Icons.Default.ViewWeek, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                            if (hasQr) Icon(Icons.Default.QrCode2, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = card.brandName.ifBlank { "Loyalty Card" },
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val secondaryText = when {
                    card.cardNickname.isNotBlank() -> card.cardNickname
                    card.cardNumber.isNotBlank() -> LoyaltyCodeHelper.maskCardNumber(card.cardNumber)
                    else -> ""
                }
                if (secondaryText.isNotBlank()) {
                    Text(
                        text = secondaryText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardEditorScreen(
    existingCard: LoyaltyCardEntity?,
    defaultCardholderName: String,
    initialLaunchMode: String = "MANUAL",
    onSave: (LoyaltyCardEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEditing = existingCard != null

    var brandName by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.brandName.orEmpty()) }
    var cardNickname by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.cardNickname.orEmpty()) }
    var cardNumber by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.cardNumber.orEmpty()) }
    var cardholderName by rememberSaveable(existingCard?.id) {
        mutableStateOf(existingCard?.cardholderName?.ifBlank { defaultCardholderName } ?: defaultCardholderName)
    }
    var notes by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.notes.orEmpty()) }
    var expiryDateIso by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.expiryDateIso.orEmpty()) }
    var pointsBalance by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.pointsBalance.orEmpty()) }
    var membershipTier by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.membershipTier.orEmpty()) }

    var barcodeValue by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeValue.orEmpty()) }
    var barcodeFormat by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeFormat.orEmpty()) }
    var barcodeVerified by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeVerified ?: false) }
    var barcodeSource by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeSource.orEmpty()) }
    var qrPayload by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.qrPayload.orEmpty()) }
    var qrVerified by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.qrVerified ?: false) }
    var qrCodeType by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.qrCodeType.orEmpty()) }
    var membershipNumberSource by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.membershipNumberSource.orEmpty()) }

    var frontPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.frontPhotoUri) }
    var backPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.backPhotoUri) }
    var frontOriginalPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.frontOriginalPhotoUri) }
    var backOriginalPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.backOriginalPhotoUri) }
    var frontCropMetaJson by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.frontCropMetaJson.orEmpty()) }
    var backCropMetaJson by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.backCropMetaJson.orEmpty()) }
    var frontCropRevision by rememberSaveable(existingCard?.id) { mutableIntStateOf(existingCard?.frontCropRevision ?: 0) }
    var backCropRevision by rememberSaveable(existingCard?.id) { mutableIntStateOf(existingCard?.backCropRevision ?: 0) }

    var showMoreDetails by remember { mutableStateOf(isEditing) }
    var showManualCodeFields by remember { mutableStateOf(false) }

    // Scanner & Capture Dialog States (all in-app so Biometric Lock never interrupts capture!)
    var activeCodeScannerMode by remember { mutableStateOf<String?>(null) } // "AUTO", "BARCODE", "QR"
    var activePhotoCameraSide by remember { mutableStateOf<String?>(null) } // "front" or "back"
    var pendingCropPair by remember { mutableStateOf<Pair<Bitmap, String>?>(null) } // bitmap to side
    var pendingCropConfidence by remember { mutableStateOf<CropConfidenceLevel?>(null) }
    var promptScanBackSide by remember { mutableStateOf(false) }

    // Review & Explicit Confirmation Dialogs (Never silently save/overwrite!)
    var pendingMembershipReview by remember { mutableStateOf<String?>(null) }
    var showCreateDigitalBarcodeDialog by remember { mutableStateOf(false) }
    var showLinkedNumberChangedDialog by remember { mutableStateOf(false) }

    var pendingCopyPrompt by remember { mutableStateOf<String?>(null) }
    var processingStage by remember { mutableStateOf<String?>(null) }
    var autoDetectBanner by remember { mutableStateOf<String?>(null) }
    var imageErrorMessage by remember { mutableStateOf<String?>(null) }
    var galleryPickSide by rememberSaveable { mutableStateOf("front") }

    // Live generated & internally verified code previews right inside the editor
    val editorBarcodeState by produceState<Pair<Bitmap?, Boolean>>(initialValue = null to false, barcodeValue, barcodeFormat) {
        value = if (barcodeValue.isNotBlank() && barcodeFormat.isNotBlank()) {
            withContext(Dispatchers.Default) {
                val bmp = LoyaltyCodeHelper.generateBarcodeBitmap(barcodeValue, barcodeFormat, 760, 220)
                val ok = LoyaltyCodeHelper.verifyCodeBitmap(bmp, barcodeValue)
                bmp to ok
            }
        } else null to false
    }
    val editorBarcodeBmp = editorBarcodeState.first
    val editorBarcodeVerified = editorBarcodeState.second

    val editorQrState by produceState<Pair<Bitmap?, Boolean>>(initialValue = null to false, qrPayload) {
        value = if (qrPayload.isNotBlank()) {
            withContext(Dispatchers.Default) {
                val bmp = LoyaltyCodeHelper.generateQrBitmap(qrPayload, 360)
                val ok = LoyaltyCodeHelper.verifyCodeBitmap(bmp, qrPayload)
                bmp to ok
            }
        } else null to false
    }
    val editorQrBmp = editorQrState.first
    val editorQrVerified = editorQrState.second

    /**
     * Saves the cropped/upright card bitmap into CardLink's secure storage (without confusing crypto jargon)
     * AND automatically scans the photo for any printed Barcode, QR Code, Brand Name, or Card Number!
     */
    fun commitLoyaltySave(
        finalBarcodeVal: String = barcodeValue.trim(),
        finalBarcodeFmt: String = if (barcodeValue.isNotBlank()) barcodeFormat.ifBlank { "CODE_128" } else "",
        finalBarcodeVerified: Boolean = barcodeVerified || editorBarcodeVerified,
        finalBarcodeSource: String = barcodeSource
    ) {
        val trimmedBrand = brandName.trim()
        val now = System.currentTimeMillis()
        val entity = (existingCard ?: LoyaltyCardEntity(brandName = trimmedBrand)).copy(
            brandName = trimmedBrand,
            cardNickname = cardNickname.trim(),
            cardNumber = cardNumber.trim(),
            cardholderName = cardholderName.trim(),
            notes = notes.trim(),
            expiryDateIso = expiryDateIso.trim().takeIf { it.isNotBlank() },
            pointsBalance = pointsBalance.trim(),
            membershipTier = membershipTier.trim(),
            barcodeValue = finalBarcodeVal,
            barcodeFormat = finalBarcodeFmt,
            barcodeVerified = finalBarcodeVal.isNotBlank() && finalBarcodeVerified,
            barcodeSource = if (finalBarcodeVal.isNotBlank()) finalBarcodeSource.ifBlank { "MANUAL" } else "",
            qrPayload = qrPayload.trim(),
            qrVerified = qrPayload.isNotBlank() && (qrVerified || editorQrVerified),
            qrCodeType = if (qrPayload.isNotBlank()) qrCodeType.ifBlank { "TEXT" } else "",
            membershipNumberSource = if (cardNumber.isNotBlank()) membershipNumberSource.ifBlank { "MANUAL" } else "",
            frontPhotoUri = frontPhotoUri,
            backPhotoUri = backPhotoUri,
            frontOriginalPhotoUri = frontOriginalPhotoUri,
            backOriginalPhotoUri = backOriginalPhotoUri,
            frontCropMetaJson = frontCropMetaJson,
            backCropMetaJson = backCropMetaJson,
            frontCropRevision = frontCropRevision,
            backCropRevision = backCropRevision,
            updatedAtTimestamp = now
        )
        onSave(entity)
    }

    fun saveCroppedCardAndAutoDetect(origBmp: Bitmap, croppedBmp: Bitmap, cropMeta: CardCropMetadata, side: String, offerNextSide: Boolean) {
        scope.launch {
            imageErrorMessage = null
            autoDetectBanner = null

            // Step 1: Detect Physical Barcode / QR FIRST, then OCR & Membership Number Classification on full-clarity cropped source
            processingStage = context.getString(R.string.loyalty_detecting_code_from_photo)
            val hints = runCatching {
                LoyaltyCodeHelper.analyzeCardPhotoHints(
                    bitmap = croppedBmp,
                    runTextOcr = true
                )
            }.getOrNull()

            // Step 2: Adaptive Image Optimization (LOYALTY_CARD profile) gated by detected Barcode/QR preservation!
            processingStage = context.getString(R.string.loyalty_optimizing_photo)
            val optResult = runCatching {
                CardLinkImageOptimizationService.optimizeAndEncryptCard(
                    context = context,
                    croppedBitmap = croppedBmp,
                    profile = CardOptimizationProfile.LOYALTY_CARD,
                    prefix = "loyalty_$side",
                    expectedBarcodePayload = hints?.barcode?.rawValue.orEmpty(),
                    expectedQrPayload = hints?.qr?.rawValue.orEmpty()
                )
            }.getOrNull()
            processingStage = null

            if (optResult == null) {
                imageErrorMessage = "The selected image could not be opened or saved. Try another photo."
                return@launch
            }

            val savedUri = optResult.encryptedMasterUri
            val origSavedUri = withContext(Dispatchers.IO) {
                val existingOrig = if (side == "front") frontOriginalPhotoUri else backOriginalPhotoUri
                existingOrig ?: ScannedCardStorageHelper.saveEncryptedScannedCard(context, origBmp, "loyalty_${side}_orig")
            }
            val nextRev = (if (side == "front") frontCropRevision else backCropRevision) + 1
            val metaJson = CardCropMetadata.toJson(cropMeta.copy(cropRevision = nextRev, sideOrPage = side.uppercase()))
            if (side == "front") {
                VaultCryptoManager.evictFromCache(frontPhotoUri)
                frontPhotoUri = savedUri
                frontOriginalPhotoUri = origSavedUri
                frontCropMetaJson = metaJson
                frontCropRevision = nextRev
            } else {
                VaultCryptoManager.evictFromCache(backPhotoUri)
                backPhotoUri = savedUri
                backOriginalPhotoUri = origSavedUri
                backCropMetaJson = metaJson
                backCropRevision = nextRev
            }

            if (hints != null) {
                val foundItems = mutableListOf<String>()
                // Priority 1: Physical Barcode preserved with exact raw payload & symbology
                if (hints.barcode != null && barcodeValue.isBlank()) {
                    barcodeValue = hints.barcode.rawValue
                    barcodeFormat = hints.barcode.formatName
                    barcodeVerified = true
                    barcodeSource = "SCANNED"
                    foundItems.add(context.getString(R.string.loyalty_barcode_detected_badge))
                }
                // Priority 2: Physical QR preserved with exact payload & type
                if (hints.qr != null && qrPayload.isBlank()) {
                    qrPayload = hints.qr.rawValue
                    qrCodeType = hints.qrCodeType
                    qrVerified = true
                    foundItems.add(context.getString(R.string.loyalty_tab_qr))
                }
                // Priority 3 & 4: Intelligent Membership Number OCR — ALWAYS shown for explicit user confirmation!
                if (hints.suggestedNumber.isNotBlank() && cardNumber.isBlank()) {
                    pendingMembershipReview = hints.suggestedNumber
                    foundItems.add(context.getString(R.string.loyalty_membership_detected_title))
                }
                if (hints.suggestedBrand.isNotBlank() && brandName.isBlank()) {
                    brandName = hints.suggestedBrand
                    foundItems.add(hints.suggestedBrand)
                }
                if (hints.suggestedTier.isNotBlank() && membershipTier.isBlank()) {
                    membershipTier = hints.suggestedTier
                }
                if (hints.suggestedCardholder.isNotBlank() && cardholderName.isBlank()) {
                    cardholderName = hints.suggestedCardholder
                }
                if (foundItems.isNotEmpty()) {
                    autoDetectBanner = context.getString(R.string.loyalty_auto_detected_msg, foundItems.joinToString(", "))
                }
            }

            if (offerNextSide && side == "front" && backPhotoUri.isNullOrBlank()) {
                promptScanBackSide = true
            }
        }
    }

    fun routeLoyaltyBitmapToSmartCrop(rawBmp: Bitmap, side: String) {
        val smartEnabled = SmartCropPrefs.isSmartCropEnabled(context)
        val policy = SmartCropPrefs.getCropReviewPolicy(context)
        if (!smartEnabled) {
            val fullMeta = CardCropMetadata.fullOriginal(0, 1, SmartCropFeatureType.LOYALTY_CARD, side.uppercase())
            saveCroppedCardAndAutoDetect(rawBmp, rawBmp, fullMeta, side, offerNextSide = (side == "front"))
            return
        }
        scope.launch {
            processingStage = context.getString(R.string.crop_stage_detecting)
            val det = withContext(Dispatchers.Default) {
                SmartCardCropEngine.detectAutoCropWithConfidence(rawBmp, SmartCropFeatureType.LOYALTY_CARD, side.uppercase())
            }
            val (shouldOpenDialog, _) = SmartCardCropEngine.decideReviewBehavior(true, policy, det.confidence)
            if (!shouldOpenDialog) {
                processingStage = context.getString(R.string.crop_stage_correcting)
                val corrected = withContext(Dispatchers.Default) {
                    SmartCardCropEngine.applyCropAndPerspective(rawBmp, det.metadata, SmartCropFeatureType.LOYALTY_CARD.maxOutputEdgePx)
                }
                Toast.makeText(context, context.getString(R.string.crop_auto_corrected_toast), Toast.LENGTH_SHORT).show()
                saveCroppedCardAndAutoDetect(rawBmp, corrected, det.metadata, side, offerNextSide = (side == "front"))
            } else {
                processingStage = null
                pendingCropConfidence = det.confidence
                pendingCropPair = rawBmp to side
            }
        }
    }

    fun openGalleryPhotoForCrop(uri: Uri, side: String) {
        scope.launch {
            processingStage = context.getString(R.string.loyalty_preparing_photo)
            imageErrorMessage = null
            val bmp = withContext(Dispatchers.IO) { ScannedCardStorageHelper.decodeGalleryUri(context, uri, 2000) }
            processingStage = null
            if (bmp != null) {
                routeLoyaltyBitmapToSmartCrop(bmp, side)
            } else {
                imageErrorMessage = "The selected image could not be opened. Try another image."
            }
        }
    }

    fun reopenExistingPhotoForCrop(uriString: String, side: String) {
        scope.launch {
            processingStage = context.getString(R.string.loyalty_preparing_photo)
            val targetSrc = (if (side == "front") frontOriginalPhotoUri else backOriginalPhotoUri) ?: uriString
            val bmp = withContext(Dispatchers.IO) {
                VaultCryptoManager.decodeVaultBitmapUncached(context, targetSrc, 2000)
                    ?: ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(targetSrc), 2000)
            }
            processingStage = null
            if (bmp != null) {
                pendingCropPair = bmp to side
            }
        }
    }

    val galleryPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            openGalleryPhotoForCrop(uri, galleryPickSide)
        }
    }

    var initialActionTriggered by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialLaunchMode) {
        if (!isEditing && !initialActionTriggered) {
            initialActionTriggered = true
            when (initialLaunchMode) {
                "CAMERA" -> activePhotoCameraSide = "front"
                "GALLERY" -> {
                    galleryPickSide = "front"
                    galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                // AUTO mode detects BOTH 1D Barcodes AND QR codes (fixes previous bug where QR codes were rejected!)
                "SCAN_CODE" -> activeCodeScannerMode = "AUTO"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) stringResource(R.string.loyalty_edit_card) else stringResource(R.string.loyalty_add_card),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            processingStage?.let { stage ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text(stage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Medium)
                    }
                }
            }

            autoDetectBanner?.let { msg ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                        Text(msg, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { autoDetectBanner = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(15.dp))
                        }
                    }
                }
            }

            if (promptScanBackSide && backPhotoUri.isNullOrBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Flip, null, tint = MaterialTheme.colorScheme.primary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.loyalty_front_saved_prompt_title), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(stringResource(R.string.loyalty_front_saved_prompt_sub), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(onClick = {
                            promptScanBackSide = false
                            activePhotoCameraSide = "back"
                        }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(stringResource(R.string.loyalty_scan_back_btn), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            imageErrorMessage?.let { errMsg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.loyalty_img_open_err_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                        Text(errMsg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                imageErrorMessage = null
                                galleryPickSide = "front"
                                galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) { Text(stringResource(R.string.loyalty_replace_img_btn), fontSize = 12.sp) }
                            TextButton(onClick = { imageErrorMessage = null }) { Text(stringResource(R.string.loyalty_continue_btn), fontSize = 12.sp) }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = brandName,
                onValueChange = { brandName = it },
                label = { Text("${stringResource(R.string.loyalty_brand_name)} *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNickname,
                onValueChange = { cardNickname = it },
                label = { Text(stringResource(R.string.loyalty_nickname)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text(stringResource(R.string.loyalty_card_number)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 1. Barcode & QR Code Section (Camera + Gallery + Auto-Detect + Live Preview)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.loyalty_section_codes), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { activeCodeScannerMode = "BARCODE" }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.ViewWeek, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(stringResource(R.string.loyalty_scan_barcode), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(onClick = { activeCodeScannerMode = "QR" }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(stringResource(R.string.loyalty_scan_qr), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }

                    // Live Digital Barcode Preview inside Editor
                    if (barcodeValue.isNotBlank()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                editorBarcodeBmp?.let { bmp ->
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "Captured Barcode Preview",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxWidth().height(72.dp)
                                    )
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = (if (editorBarcodeVerified) "✓ ${stringResource(R.string.loyalty_barcode_verified)} • " else "") +
                                            "${LoyaltyCodeHelper.formatDisplayName(barcodeFormat.ifBlank { "CODE_128" })}: $barcodeValue",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (editorBarcodeVerified) Color(0xFF047857) else Color(0xFFB45309),
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { barcodeValue = ""; barcodeFormat = ""; barcodeVerified = false; barcodeSource = "" }, modifier = Modifier.size(26.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove Barcode", tint = Color.DarkGray, modifier = Modifier.size(15.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Live Digital QR Preview inside Editor
                    if (qrPayload.isNotBlank()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                editorQrBmp?.let { bmp ->
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "Captured QR Preview",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.size(64.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("✓ QR Code Captured", style = MaterialTheme.typography.labelSmall, color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                                    Text(qrPayload.take(64), style = MaterialTheme.typography.labelSmall, color = Color.DarkGray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { qrPayload = "" }, modifier = Modifier.size(26.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove QR", tint = Color.DarkGray, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }

                    if (barcodeValue.isBlank() && cardNumber.isNotBlank()) {
                        OutlinedButton(
                            onClick = { showCreateDigitalBarcodeDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.ViewWeek, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.loyalty_create_digital_barcode_btn), fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                    }

                    TextButton(
                        onClick = { showManualCodeFields = !showManualCodeFields },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            if (showManualCodeFields) "Hide Manual Code Entry" else "Enter Barcode / QR Manually",
                            fontSize = 12.sp
                        )
                    }

                    AnimatedVisibility(visible = showManualCodeFields) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = barcodeValue,
                                onValueChange = { barcodeValue = it; if (barcodeFormat.isBlank()) barcodeFormat = "CODE_128" },
                                label = { Text(stringResource(R.string.loyalty_barcode_val_lbl)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltyCodeHelper.SUPPORTED_1D_FORMATS.forEach { fmt ->
                                    FilterChip(
                                        selected = barcodeFormat.equals(fmt, true),
                                        onClick = { barcodeFormat = fmt },
                                        label = { Text(LoyaltyCodeHelper.formatDisplayName(fmt), fontSize = 11.sp) }
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = qrPayload,
                                onValueChange = { qrPayload = it },
                                label = { Text(stringResource(R.string.loyalty_qr_payload_lbl)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // 2. Always-Visible Front Side & Back Side Card Photos Section (with Smart Crop & Auto-Detect)
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.loyalty_section_photos), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)

                    LoyaltyPhotoSlot(
                        label = stringResource(R.string.loyalty_front_side),
                        photoUri = frontPhotoUri,
                        onTakePhoto = { activePhotoCameraSide = "front" },
                        onPickGallery = {
                            galleryPickSide = "front"
                            galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onAdjustCrop = { uri -> reopenExistingPhotoForCrop(uri, "front") },
                        onRemove = { frontPhotoUri = null }
                    )

                    HorizontalDivider()

                    // Back Side is ALWAYS visible (never hidden!) so users can scan Back first or independently
                    LoyaltyPhotoSlot(
                        label = stringResource(R.string.loyalty_add_back_side),
                        photoUri = backPhotoUri,
                        onTakePhoto = { activePhotoCameraSide = "back" },
                        onPickGallery = {
                            galleryPickSide = "back"
                            galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onAdjustCrop = { uri -> reopenExistingPhotoForCrop(uri, "back") },
                        onRemove = { backPhotoUri = null }
                    )
                }
            }

            OutlinedButton(
                onClick = { showMoreDetails = !showMoreDetails },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (showMoreDetails) "Hide More Details" else "More Details (Optional)")
                Spacer(Modifier.width(6.dp))
                Icon(if (showMoreDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }

            AnimatedVisibility(visible = showMoreDetails) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = cardholderName,
                        onValueChange = { cardholderName = it },
                        label = { Text(stringResource(R.string.loyalty_cardholder)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pointsBalance,
                            onValueChange = { pointsBalance = it },
                            label = { Text(stringResource(R.string.loyalty_points_lbl)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = membershipTier,
                            onValueChange = { membershipTier = it },
                            label = { Text(stringResource(R.string.loyalty_tier_lbl)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = expiryDateIso,
                        onValueChange = { expiryDateIso = it.take(10) },
                        label = { Text(stringResource(R.string.loyalty_expiry_lbl)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(stringResource(R.string.loyalty_notes)) },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Button(
                onClick = {
                    val trimmedBrand = brandName.trim()
                    if (trimmedBrand.isBlank()) {
                        Toast.makeText(context, context.getString(R.string.loyalty_brand_required), Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    // Sec 40: If editing a previously linked Membership Number, ask explicitly before regenerating Barcode!
                    val orig = existingCard
                    val newNum = cardNumber.trim()
                    val wasLinked = orig != null &&
                        orig.cardNumber.isNotBlank() &&
                        newNum.isNotBlank() &&
                        newNum != orig.cardNumber &&
                        barcodeValue.isNotBlank() &&
                        (orig.barcodeSource == "GENERATED_FROM_NUMBER" || orig.barcodeValue == orig.cardNumber) &&
                        barcodeValue.trim() == orig.barcodeValue
                    if (wasLinked) {
                        showLinkedNumberChangedDialog = true
                    } else {
                        commitLoyaltySave()
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    // In-App CameraX Loyalty Card Photo Capture (never leaves CardLink, supports Zoom + Torch + Gallery + Front/Back!)
    activePhotoCameraSide?.let { side ->
        LoyaltyCardPhotoCaptureDialog(
            side = side,
            onCaptured = { rawBmp ->
                activePhotoCameraSide = null
                routeLoyaltyBitmapToSmartCrop(rawBmp, side)
            },
            onPickedGalleryUri = { uri ->
                activePhotoCameraSide = null
                openGalleryPhotoForCrop(uri, side)
            },
            onDismiss = { activePhotoCameraSide = null }
        )
    }

    // Hybrid Smart Card Crop Dialog for Loyalty Card Photos
    pendingCropPair?.let { (srcBmp, side) ->
        val initMeta = CardCropMetadata.fromJson(if (side == "front") frontCropMetaJson else backCropMetaJson)
        SmartCardCropDialog(
            sourceBitmap = srcBmp,
            initialMetadata = initMeta,
            featureType = SmartCropFeatureType.LOYALTY_CARD,
            sideLabel = side.uppercase(),
            initialConfidence = pendingCropConfidence,
            expectedBarcodePayload = barcodeValue,
            expectedQrPayload = qrPayload,
            onRetake = { pendingCropPair = null; activePhotoCameraSide = side },
            onConfirm = { croppedBmp, newMeta ->
                pendingCropPair = null
                pendingCropConfidence = null
                saveCroppedCardAndAutoDetect(srcBmp, croppedBmp, newMeta, side, offerNextSide = (side == "front"))
            },
            onDismiss = { pendingCropPair = null; pendingCropConfidence = null }
        )
    }

    // Upgraded Loyalty Barcode & QR Scanner (supports AUTO, BARCODE, QR + Gallery Picker + Flashlight + Zoom!)
    activeCodeScannerMode?.let { mode ->
        LoyaltyCodeScannerDialog(
            initialMode = mode,
            onDetected = { rawValue, formatName ->
                if (formatName == "QR_CODE") {
                    qrPayload = rawValue
                    qrVerified = true
                    qrCodeType = runCatching { UniversalQrParser.parse(rawValue).type.name }.getOrDefault("TEXT")
                    Toast.makeText(context, "QR Code captured!", Toast.LENGTH_SHORT).show()
                } else {
                    barcodeValue = rawValue
                    barcodeFormat = formatName
                    barcodeVerified = true
                    barcodeSource = "SCANNED"
                    Toast.makeText(context, "Barcode captured (${LoyaltyCodeHelper.formatDisplayName(formatName)})", Toast.LENGTH_SHORT).show()
                    if (cardNumber.isBlank()) {
                        pendingCopyPrompt = rawValue
                    }
                }
                activeCodeScannerMode = null
            },
            onDismiss = { activeCodeScannerMode = null }
        )
    }

    pendingCopyPrompt?.let { candidate ->
        AlertDialog(
            onDismissRequest = { pendingCopyPrompt = null },
            title = { Text(stringResource(R.string.loyalty_copy_number_title), fontWeight = FontWeight.Bold) },
            text = { Text("${stringResource(R.string.loyalty_copy_number_msg)}\n\n$candidate") },
            confirmButton = {
                Button(onClick = {
                    cardNumber = candidate
                    pendingCopyPrompt = null
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingCopyPrompt = null }) { Text(stringResource(R.string.action_skip)) }
            }
        )
    }

    // Sec 7: Explicit Membership Number Detected Review Dialog (Confirm or Edit before saving)
    pendingMembershipReview?.let { detectedNum ->
        var editDraft by remember(detectedNum) { mutableStateOf(detectedNum) }
        var isEditingDraft by remember(detectedNum) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { pendingMembershipReview = null },
            title = { Text(stringResource(R.string.loyalty_membership_detected_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.loyalty_membership_detected_sub), style = MaterialTheme.typography.bodySmall)
                    if (!isEditingDraft) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = editDraft,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = editDraft,
                            onValueChange = { editDraft = it },
                            label = { Text(stringResource(R.string.loyalty_card_number)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val clean = editDraft.trim()
                    if (clean.isNotBlank()) {
                        cardNumber = clean
                        membershipNumberSource = "OCR_CONFIRMED"
                    }
                    pendingMembershipReview = null
                }) { Text(stringResource(R.string.action_confirm), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                if (!isEditingDraft) {
                    TextButton(onClick = { isEditingDraft = true }) { Text(stringResource(R.string.action_edit)) }
                } else {
                    TextButton(onClick = { pendingMembershipReview = null }) { Text(stringResource(R.string.action_cancel)) }
                }
            }
        )
    }

    // Sec 10: Safe "Create Digital Barcode" Format Selection & Verification Dialog (Never silently guesses!)
    if (showCreateDigitalBarcodeDialog) {
        val safeFormats = remember(cardNumber) { LoyaltyOcrClassifier.getSafeBarcodeFormatsForNumber(cardNumber) }
        var pickedFmt by remember(safeFormats) {
            mutableStateOf(safeFormats.firstOrNull { it.isRecommended }?.formatName ?: safeFormats.firstOrNull()?.formatName.orEmpty())
        }
        AlertDialog(
            onDismissRequest = { showCreateDigitalBarcodeDialog = false },
            title = { Text(stringResource(R.string.loyalty_create_digital_barcode_btn), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.loyalty_create_barcode_confirm_sub, cardNumber.trim()),
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (safeFormats.isEmpty()) {
                        Text(
                            text = stringResource(R.string.loyalty_no_safe_barcode_fmt),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else {
                        safeFormats.forEach { opt ->
                            val isSel = pickedFmt == opt.formatName
                            Surface(
                                onClick = { pickedFmt = opt.formatName },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(opt.displayLabel, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    if (isSel) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (safeFormats.isNotEmpty() && pickedFmt.isNotBlank()) {
                    Button(onClick = {
                        val payload = cardNumber.trim()
                        val fmt = pickedFmt
                        showCreateDigitalBarcodeDialog = false
                        scope.launch {
                            val verified = withContext(Dispatchers.Default) {
                                val bmp = LoyaltyCodeHelper.generateBarcodeBitmap(payload, fmt, 1000, 320)
                                val ok = LoyaltyCodeHelper.verifyCodeBitmap(bmp, payload)
                                bmp?.recycle()
                                ok
                            }
                            if (verified) {
                                barcodeValue = payload
                                barcodeFormat = fmt
                                barcodeVerified = true
                                barcodeSource = "GENERATED_FROM_NUMBER"
                                Toast.makeText(context, context.getString(R.string.loyalty_barcode_verified), Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, context.getString(R.string.loyalty_barcode_verify_failed_title), Toast.LENGTH_LONG).show()
                            }
                        }
                    }) { Text(stringResource(R.string.action_confirm), fontWeight = FontWeight.Bold) }
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDigitalBarcodeDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // Sec 40: Membership Number Changed — Ask explicitly before regenerating linked Barcode!
    if (showLinkedNumberChangedDialog) {
        AlertDialog(
            onDismissRequest = { showLinkedNumberChangedDialog = false },
            title = { Text(stringResource(R.string.loyalty_number_changed_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.loyalty_number_changed_msg)) },
            confirmButton = {
                Button(onClick = {
                    showLinkedNumberChangedDialog = false
                    val newPayload = cardNumber.trim()
                    val safeFmt = LoyaltyOcrClassifier.getSafeBarcodeFormatsForNumber(newPayload)
                        .firstOrNull { it.formatName == barcodeFormat }?.formatName
                        ?: LoyaltyOcrClassifier.getSafeBarcodeFormatsForNumber(newPayload).firstOrNull()?.formatName
                        ?: "CODE_128"
                    scope.launch {
                        val verified = withContext(Dispatchers.Default) {
                            val bmp = LoyaltyCodeHelper.generateBarcodeBitmap(newPayload, safeFmt, 1000, 320)
                            val ok = LoyaltyCodeHelper.verifyCodeBitmap(bmp, newPayload)
                            bmp?.recycle()
                            ok
                        }
                        commitLoyaltySave(
                            finalBarcodeVal = newPayload,
                            finalBarcodeFmt = safeFmt,
                            finalBarcodeVerified = verified,
                            finalBarcodeSource = "GENERATED_FROM_NUMBER"
                        )
                    }
                }) { Text(stringResource(R.string.loyalty_regenerate_btn), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showLinkedNumberChangedDialog = false
                    commitLoyaltySave()
                }) { Text(stringResource(R.string.loyalty_keep_existing_barcode_btn)) }
            }
        )
    }
}

@Composable
private fun LoyaltyPhotoSlot(
    label: String,
    photoUri: String?,
    onTakePhoto: () -> Unit,
    onPickGallery: () -> Unit,
    onAdjustCrop: (String) -> Unit,
    onRemove: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            if (!photoUri.isNullOrBlank()) {
                TextButton(
                    onClick = { onAdjustCrop(photoUri) },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.heightIn(min = 30.dp)
                ) {
                    Icon(Icons.Default.Crop, null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.crop_adjust_title), fontSize = 11.5.sp)
                }
            }
        }
        if (!photoUri.isNullOrBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            ) {
                VaultImage(
                    uriString = photoUri,
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    maxEdgePx = 800,
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color.Black.copy(alpha = 0.55f), CircleShape).size(32.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove photo", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onTakePhoto, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PhotoCamera, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(stringResource(R.string.loyalty_camera_btn), fontSize = 12.sp)
            }
            OutlinedButton(onClick = onPickGallery, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(stringResource(R.string.qr_gallery), fontSize = 12.sp)
            }
        }
    }
}

/**
 * In-App CameraX Guided Card Capture Dialog for Front/Back Loyalty Card Photos.
 * Prevents leaving CardLink (avoids Biometric Lock interruption) and includes Zoom, Torch & Gallery.
 */
@Composable
private fun LoyaltyCardPhotoCaptureDialog(
    side: String,
    onCaptured: (Bitmap) -> Unit,
    onPickedGalleryUri: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPerm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPerm = granted
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) onPickedGalleryUri(uri)
    }
    LaunchedEffect(Unit) {
        if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA)
    }

    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val zoomState = remember { CardLinkCameraZoomState() }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { runCatching { cameraRef?.cameraControl?.enableTorch(false) } }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply { this.attachTapToFocus(zoomState) }
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                                cameraRef = cam
                                hasFlash = cam.cameraInfo.hasFlashUnit()
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                val guideAccent = MaterialTheme.colorScheme.primary
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                ) {
                    val cardW = size.width * 0.88f
                    val cardH = cardW / 1.586f
                    val left = (size.width - cardW) / 2f
                    val top = (size.height - cardH) / 2.2f
                    drawRect(color = Color.Black.copy(alpha = 0.55f))
                    drawRoundRect(color = Color.Transparent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(22f, 22f), blendMode = BlendMode.Clear)
                    drawRoundRect(color = guideAccent, topLeft = Offset(left, top), size = Size(cardW, cardH), cornerRadius = CornerRadius(22f, 22f), style = Stroke(width = 5f))
                }

                ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 104.dp)
                )

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.qr_gallery), fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (isCapturing) return@Button
                            isCapturing = true
                            imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                                override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                    val bmp = imageProxy.toUprightLoyaltyBitmap()
                                    imageProxy.close()
                                    isCapturing = false
                                    if (bmp != null) {
                                        onCaptured(bmp)
                                    } else {
                                        Toast.makeText(context, "Could not capture card photo. Try again.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                override fun onError(exception: ImageCaptureException) {
                                    isCapturing = false
                                    Toast.makeText(context, "Camera capture failed. You can pick from Gallery instead.", Toast.LENGTH_SHORT).show()
                                }
                            })
                        },
                        enabled = !isCapturing,
                        shape = CircleShape,
                        modifier = Modifier.size(68.dp)
                    ) {
                        if (isCapturing) CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(26.dp), strokeWidth = 2.5.dp)
                        else Icon(Icons.Default.PhotoCamera, contentDescription = "Capture", modifier = Modifier.size(28.dp))
                    }

                    if (hasFlash) {
                        IconButton(
                            onClick = {
                                torchOn = !torchOn
                                runCatching { cameraRef?.cameraControl?.enableTorch(torchOn) }
                            },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.16f), CircleShape)
                        ) {
                            Icon(if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff, contentDescription = "Flashlight", tint = Color.White)
                        }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                }
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) { Text(stringResource(R.string.qr_grant_cam)) }
                    OutlinedButton(
                        onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) { Text(stringResource(R.string.loyalty_pick_from_gallery_btn)) }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.65f)) {
                    Text(
                        text = if (side == "front") stringResource(R.string.loyalty_front_side) else stringResource(R.string.loyalty_back_side_short),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.White)
                }
            }
        }
    }
}

/**
 * Upgraded Loyalty Barcode & QR Code Scanner:
 * - Supports AUTO (both Barcode & QR), BARCODE-only, and QR-only modes.
 * - Includes From Image (Gallery) multi-pass decoder, Flashlight toggle, and Hardware-Aware Zoom.
 */
@Composable
private fun LoyaltyCodeScannerDialog(
    initialMode: String,
    onDetected: (rawValue: String, formatName: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var activeMode by remember(initialMode) { mutableStateOf(initialMode) } // "AUTO", "BARCODE", "QR"
    var isScanningGallery by remember { mutableStateOf(false) }
    var hasPerm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPerm = granted
    }
    LaunchedEffect(Unit) {
        if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA)
    }

    val scanDone = remember { AtomicBoolean(false) }
    val zoomState = remember { CardLinkCameraZoomState() }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }

    val executor = remember { Executors.newSingleThreadExecutor() }
    val barcodeScanner = remember { BarcodeScanning.getClient() }

    val galleryCodeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isScanningGallery = true
                // Try requested mode first; if none found and not AUTO, fall back to AUTO so user is never stuck!
                var found = LoyaltyCodeHelper.detectCodesFromUri(context, uri, activeMode)
                if (found.isEmpty() && activeMode != "AUTO") {
                    found = LoyaltyCodeHelper.detectCodesFromUri(context, uri, "AUTO")
                }
                isScanningGallery = false
                val first = found.firstOrNull()
                if (first != null && scanDone.compareAndSet(false, true)) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onDetected(first.rawValue, first.formatName)
                } else {
                    Toast.makeText(context, context.getString(R.string.loyalty_no_code_in_image), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { cameraRef?.cameraControl?.enableTorch(false) }
            runCatching { barcodeScanner.close() }
            runCatching { executor.shutdown() }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            this.attachTapToFocus(zoomState)
                        }
                        val providerFuture = ProcessCameraProvider.getInstance(ctx)
                        providerFuture.addListener({
                            runCatching {
                                val provider = providerFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also { ia ->
                                        ia.setAnalyzer(executor) { proxy ->
                                            val img = proxy.image
                                            if (img != null && !scanDone.get()) {
                                                val inputImg = InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees)
                                                barcodeScanner.process(inputImg)
                                                    .addOnSuccessListener(ContextCompat.getMainExecutor(ctx)) { list ->
                                                        val match = list.firstOrNull { bc ->
                                                            val raw = bc.rawValue
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(bc.format)
                                                            !raw.isNullOrBlank() && fmtName != null && (
                                                                activeMode == "AUTO" ||
                                                                    (activeMode == "QR" && fmtName == "QR_CODE") ||
                                                                    (activeMode == "BARCODE" && fmtName != "QR_CODE")
                                                                )
                                                        }
                                                        val safeRaw = match?.rawValue
                                                        if (match != null && !safeRaw.isNullOrBlank() && scanDone.compareAndSet(false, true)) {
                                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(match.format) ?: "CODE_128"
                                                            onDetected(safeRaw, fmtName)
                                                        }
                                                    }
                                                    .addOnCompleteListener { proxy.close() }
                                            } else {
                                                proxy.close()
                                            }
                                        }
                                    }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                                cameraRef = cam
                                hasFlash = cam.cameraInfo.hasFlashUnit()
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.84f)
                        .height(if (activeMode == "BARCODE") 155.dp else 245.dp)
                        .border(2.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                )

                ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 96.dp)
                )

                // Bottom Bar: Flashlight + From Image (Gallery)
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasFlash) {
                        Button(
                            onClick = {
                                torchOn = !torchOn
                                runCatching { cameraRef?.cameraControl?.enableTorch(torchOn) }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (torchOn) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.65f),
                                contentColor = if (torchOn) MaterialTheme.colorScheme.onPrimary else Color.White
                            ),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.scanner_flashlight), fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Button(
                        onClick = {
                            galleryCodeLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        enabled = !isScanningGallery,
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        if (isScanningGallery) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.scanner_from_image), fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text(stringResource(R.string.qr_grant_cam))
                    }
                    OutlinedButton(
                        onClick = {
                            galleryCodeLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.scanner_from_image))
                    }
                }
            }

            // Top Header + Mode Switcher (Auto | Barcode | QR)
            Column(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when (activeMode) {
                            "QR" -> stringResource(R.string.loyalty_scan_qr)
                            "BARCODE" -> stringResource(R.string.loyalty_scan_barcode)
                            else -> stringResource(R.string.loyalty_method_scan_code)
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("AUTO" to "Auto", "BARCODE" to "Barcode", "QR" to "QR Code").forEach { (code, lbl) ->
                        FilterChip(
                            selected = activeMode == code,
                            onClick = { activeMode = code },
                            label = { Text(lbl, fontSize = 11.5.sp) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardDetailScreen(
    card: LoyaltyCardEntity,
    onEdit: () -> Unit,
    onUpdateCard: (LoyaltyCardEntity) -> Unit = {},
    onToggleFavorite: () -> Unit = {},
    onRecordUsed: () -> Unit = {},
    onDelete: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()

    var activeCodeTab by remember(card.id, hasBarcode, hasQr) {
        mutableStateOf(if (hasBarcode) "BARCODE" else "QR")
    }
    var showEnlargedCode by remember { mutableStateOf(false) }
    var revealFullCardNumber by remember(card.id) { mutableStateOf(false) }
    var showFullScreenPhoto by remember { mutableStateOf(false) }
    var showMoreSheet by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showRescanScanner by remember { mutableStateOf(false) }
    var pendingRescannedCode by remember { mutableStateOf<Pair<String, String>?>(null) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var isShowingBackSide by remember(card.id) { mutableStateOf(false) }
    var cropTargetSideIsBack by remember { mutableStateOf(false) }
    var showDetailCropActionsSheet by remember { mutableStateOf(false) }
    var detailCropSourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previousCropUndoCard by remember { mutableStateOf<LoyaltyCardEntity?>(null) }

    LaunchedEffect(card.id) {
        onRecordUsed()
    }

    // Part E (Sec 35-36): Safe Lazy Legacy Image Optimization (deferred 1.5s so visible card renders FIRST!)
    LaunchedEffect(card.id, card.frontPhotoUri, card.backPhotoUri) {
        kotlinx.coroutines.delay(1500L)
        val newFront = CardLinkImageOptimizationService.optimizeLegacyVaultAssetIfNeeded(
            context = context,
            existingUri = card.frontPhotoUri,
            profile = CardOptimizationProfile.LOYALTY_CARD,
            prefix = "loyalty_front",
            expectedBarcodePayload = card.barcodeValue,
            expectedQrPayload = card.qrPayload
        )
        val newBack = CardLinkImageOptimizationService.optimizeLegacyVaultAssetIfNeeded(
            context = context,
            existingUri = card.backPhotoUri,
            profile = CardOptimizationProfile.LOYALTY_CARD,
            prefix = "loyalty_back",
            expectedBarcodePayload = card.barcodeValue,
            expectedQrPayload = card.qrPayload
        )
        if (newFront != null || newBack != null) {
            val oldFront = card.frontPhotoUri
            val oldBack = card.backPhotoUri
            onUpdateCard(
                card.copy(
                    frontPhotoUri = newFront ?: card.frontPhotoUri,
                    backPhotoUri = newBack ?: card.backPhotoUri
                )
            )
            if (newFront != null && !oldFront.isNullOrBlank() && oldFront != newFront) {
                VaultCryptoManager.evictFromCache(oldFront)
                ScannedCardStorageHelper.deleteSavedCardImage(oldFront)
            }
            if (newBack != null && !oldBack.isNullOrBlank() && oldBack != newBack) {
                VaultCryptoManager.evictFromCache(oldBack)
                ScannedCardStorageHelper.deleteSavedCardImage(oldBack)
            }
        }
    }

    // Internal decode-verification of generated digital Barcode & QR
    val barcodeState by produceState<Triple<Boolean, Bitmap?, Boolean>>(
        initialValue = Triple(false, null, false),
        card.barcodeValue,
        card.barcodeFormat
    ) {
        value = if (hasBarcode) {
            withContext(Dispatchers.Default) {
                val bmp = LoyaltyCodeHelper.generateBarcodeBitmap(card.barcodeValue, card.barcodeFormat, 1000, 340)
                val verified = LoyaltyCodeHelper.verifyCodeBitmap(bmp, card.barcodeValue)
                Triple(true, bmp, verified)
            }
        } else Triple(true, null, false)
    }
    val qrState by produceState<Triple<Boolean, Bitmap?, Boolean>>(
        initialValue = Triple(false, null, false),
        card.qrPayload
    ) {
        value = if (hasQr) {
            withContext(Dispatchers.Default) {
                val bmp = LoyaltyCodeHelper.generateQrBitmap(card.qrPayload, 680)
                val verified = LoyaltyCodeHelper.verifyCodeBitmap(bmp, card.qrPayload)
                Triple(true, bmp, verified)
            }
        } else Triple(true, null, false)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(card.brandName.ifBlank { stringResource(R.string.loyalty_title) }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (card.cardNickname.isNotBlank()) {
                            Text(card.cardNickname, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (card.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = stringResource(R.string.contacts_favorite_toggle_desc),
                            tint = if (card.isFavorite) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showMoreSheet = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.action_more))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. DIGITAL CODE SECTION (Checkout-first: prominently above physical card image!)
            if (hasBarcode || hasQr) {
                val (isCodeReady, activeBmp, isVerified) = if (activeCodeTab == "BARCODE") barcodeState else qrState

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.loyalty_digital_code_header),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (hasBarcode && hasQr) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(
                                        selected = activeCodeTab == "BARCODE",
                                        onClick = { activeCodeTab = "BARCODE" },
                                        label = { Text(stringResource(R.string.loyalty_tab_barcode), fontSize = 11.5.sp) }
                                    )
                                    FilterChip(
                                        selected = activeCodeTab == "QR",
                                        onClick = { activeCodeTab = "QR" },
                                        label = { Text(stringResource(R.string.loyalty_tab_qr), fontSize = 11.5.sp) }
                                    )
                                }
                            }
                        }

                        if (!isCodeReady) {
                            Box(
                                modifier = Modifier.fillMaxWidth().height(120.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                            }
                        } else if (activeBmp != null && isVerified) {
                            // High-contrast black-on-white code with preserved quiet zone (NEVER themed!)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { showEnlargedCode = true },
                                color = Color.White,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Image(
                                        bitmap = activeBmp.asImageBitmap(),
                                        contentDescription = if (activeCodeTab == "BARCODE") {
                                            "Verified ${LoyaltyCodeHelper.formatDisplayName(card.barcodeFormat)} barcode for ${card.brandName}"
                                        } else {
                                            "Verified QR code for ${card.brandName}"
                                        },
                                        contentScale = ContentScale.Fit,
                                        modifier = if (activeCodeTab == "BARCODE") Modifier.fillMaxWidth().height(124.dp) else Modifier.size(204.dp)
                                    )
                                    // Sec 14: Show human-readable Membership Number below the digital Barcode
                                    if (card.cardNumber.isNotBlank()) {
                                        Text(
                                            text = card.cardNumber,
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp,
                                            letterSpacing = 1.2.sp
                                        )
                                    }
                                }
                            }

                            // Explicit Verified ✓ status (text + icon, not color-only) + Tap to Enlarge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "${stringResource(R.string.loyalty_verified_badge)} ✓",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF10B981)
                                    )
                                }
                                Text(
                                    text = stringResource(R.string.loyalty_tap_to_enlarge),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = { showEnlargedCode = true },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.ZoomOutMap, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.loyalty_show_card_btn), fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Sec 12: NEVER show a failed barcode as checkout-ready! Offer Re-scan Code & Review Number
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                        Text(
                                            text = stringResource(R.string.loyalty_barcode_verify_failed_title),
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.error,
                                            fontSize = 13.5.sp
                                        )
                                    }
                                    Text(
                                        text = stringResource(R.string.loyalty_barcode_verify_failed_sub),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { showRescanScanner = true },
                                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                                        ) { Text(stringResource(R.string.loyalty_rescan_code_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                        OutlinedButton(
                                            onClick = onEdit,
                                            modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                                        ) { Text(stringResource(R.string.loyalty_review_number_btn), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. LOYALTY CARD PHYSICAL PHOTO (Interactive Front/Back 3D Flip + Full Screen)
            if (!card.frontPhotoUri.isNullOrBlank() || !card.backPhotoUri.isNullOrBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = stringResource(R.string.loyalty_physical_card_header),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    FlippableContactCardViewer(
                        frontUri = card.frontPhotoUri,
                        backUri = card.backPhotoUri,
                        contactName = card.brandName.ifBlank { stringResource(R.string.loyalty_title) },
                        onOpenFullScreen = { showFullScreenPhoto = true },
                        onAdjustCrop = { isBack ->
                            cropTargetSideIsBack = isBack
                            showDetailCropActionsSheet = true
                        },
                        isShowingBackExternal = isShowingBackSide,
                        onToggleBackSide = { isShowingBackSide = !isShowingBackSide },
                        frontCacheKey = "${card.id}_front_${card.frontCropRevision}",
                        backCacheKey = "${card.id}_back_${card.backCropRevision}"
                    )
                }
            }

            // 3. MEMBERSHIP INFORMATION (Masked number + reveal/copy, Cardholder, Tier, Expiry, Points, Notes)
            val hasInfo = card.cardNumber.isNotBlank() ||
                card.cardholderName.isNotBlank() ||
                card.membershipTier.isNotBlank() ||
                card.pointsBalance.isNotBlank() ||
                !card.expiryDateIso.isNullOrBlank() ||
                card.notes.isNotBlank()

            if (hasInfo) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = stringResource(R.string.loyalty_membership_info_header),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        if (card.cardNumber.isNotBlank()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.loyalty_membership_number_lbl),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (revealFullCardNumber) card.cardNumber else LoyaltyCodeHelper.maskCardNumber(card.cardNumber),
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { revealFullCardNumber = !revealFullCardNumber },
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (revealFullCardNumber) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (revealFullCardNumber) "Hide full number" else "Show full number",
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { SecureClipboardHelper.copySensitive(context, card.brandName, card.cardNumber) },
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.qa_copy_btn), tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                                    }
                                }
                            }
                        }

                        if (card.cardholderName.isNotBlank()) {
                            Column {
                                Text(stringResource(R.string.loyalty_cardholder), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(card.cardholderName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (card.membershipTier.isNotBlank()) {
                            Column {
                                Text(stringResource(R.string.loyalty_tier_lbl), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(card.membershipTier, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (!card.expiryDateIso.isNullOrBlank()) {
                            Column {
                                Text(stringResource(R.string.loyalty_expiry_lbl), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(IdExpiryHelper.formatDisplayDate(card.expiryDateIso).ifBlank { card.expiryDateIso }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (card.pointsBalance.isNotBlank()) {
                            Column {
                                Text(stringResource(R.string.loyalty_points_lbl), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(card.pointsBalance, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (card.notes.isNotBlank()) {
                            Column {
                                Text(stringResource(R.string.loyalty_notes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(card.notes, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFullScreenPhoto) {
        FullScreenContactCardDialog(
            frontUri = card.frontPhotoUri,
            backUri = card.backPhotoUri,
            contactName = card.brandName.ifBlank { stringResource(R.string.loyalty_title) },
            initialShowBack = isShowingBackSide,
            frontCacheKey = "${card.id}_front_${card.frontCropRevision}",
            backCacheKey = "${card.id}_back_${card.backCropRevision}",
            onDismiss = { showFullScreenPhoto = false }
        )
    }

    if (showDetailCropActionsSheet) {
        val targetIsBack = cropTargetSideIsBack
        val sideText = if (targetIsBack) stringResource(R.string.card_side_back) else stringResource(R.string.card_side_front)
        val hasRecoverableOrig = if (targetIsBack) !card.backOriginalPhotoUri.isNullOrBlank() else !card.frontOriginalPhotoUri.isNullOrBlank()
        val sheetActions = buildList {
            add(CardLinkSheetAction(Icons.Default.Crop, stringResource(R.string.crop_adjust_manually_action)) {
                val srcUri = if (targetIsBack) (card.backOriginalPhotoUri ?: card.backPhotoUri) else (card.frontOriginalPhotoUri ?: card.frontPhotoUri)
                if (!srcUri.isNullOrBlank()) {
                    scope.launch {
                        val bmp = withContext(Dispatchers.IO) {
                            VaultCryptoManager.decodeVaultBitmapUncached(context, srcUri, 2000)
                                ?: ScannedCardStorageHelper.decodeGalleryUri(context, Uri.parse(srcUri), 2000)
                        }
                        if (bmp != null) detailCropSourceBitmap = bmp
                    }
                }
            })
            if (hasRecoverableOrig) {
                add(CardLinkSheetAction(Icons.Default.Restore, stringResource(R.string.crop_reset_original)) {
                    val orig = if (targetIsBack) card.backOriginalPhotoUri else card.frontOriginalPhotoUri
                    if (!orig.isNullOrBlank()) {
                        val undoBase = card
                        val nextRev = (if (targetIsBack) card.backCropRevision else card.frontCropRevision) + 1
                        val updated = if (targetIsBack) {
                            card.copy(backPhotoUri = orig, backCropMetaJson = "", backCropRevision = nextRev)
                        } else {
                            card.copy(frontPhotoUri = orig, frontCropMetaJson = "", frontCropRevision = nextRev)
                        }
                        VaultCryptoManager.evictFromCache(card.frontPhotoUri)
                        VaultCryptoManager.evictFromCache(card.backPhotoUri)
                        previousCropUndoCard = undoBase
                        onUpdateCard(updated)
                        scope.launch {
                            val res = snackbarHostState.showSnackbar(
                                message = context.getString(R.string.crop_reset_done_toast),
                                actionLabel = context.getString(R.string.action_undo),
                                duration = SnackbarDuration.Long
                            )
                            if (res == SnackbarResult.ActionPerformed) {
                                previousCropUndoCard?.let { prev ->
                                    onUpdateCard(
                                        if (targetIsBack) prev.copy(backCropRevision = updated.backCropRevision + 1)
                                        else prev.copy(frontCropRevision = updated.frontCropRevision + 1)
                                    )
                                }
                            }
                        }
                    }
                })
            }
        }
        CardLinkActionSheet(
            title = "${stringResource(R.string.crop_adjust_title)} ($sideText)",
            actions = sheetActions,
            onDismiss = { showDetailCropActionsSheet = false }
        )
    }

    detailCropSourceBitmap?.let { srcBmp ->
        val targetIsBack = cropTargetSideIsBack
        val initMeta = CardCropMetadata.fromJson(if (targetIsBack) card.backCropMetaJson else card.frontCropMetaJson)
        SmartCardCropDialog(
            sourceBitmap = srcBmp,
            initialMetadata = initMeta,
            startInManualAdjust = true,
            featureType = SmartCropFeatureType.LOYALTY_CARD,
            sideLabel = if (targetIsBack) "BACK" else "FRONT",
            expectedBarcodePayload = card.barcodeValue,
            expectedQrPayload = card.qrPayload,
            onConfirm = { croppedBmp, newMeta ->
                detailCropSourceBitmap = null
                val undoBase = card
                scope.launch {
                    val updated = withContext(Dispatchers.IO) {
                        val sideSlug = if (targetIsBack) "back" else "front"
                        val nextRev = (if (targetIsBack) undoBase.backCropRevision else undoBase.frontCropRevision) + 1
                        val existingOrig = if (targetIsBack) undoBase.backOriginalPhotoUri else undoBase.frontOriginalPhotoUri
                        val origUri = existingOrig ?: ScannedCardStorageHelper.saveEncryptedScannedCard(context, srcBmp, "loyalty_${sideSlug}_orig")
                        val optRes = CardLinkImageOptimizationService.optimizeAndEncryptCard(
                            context = context,
                            croppedBitmap = croppedBmp,
                            profile = CardOptimizationProfile.LOYALTY_CARD,
                            prefix = "loyalty_$sideSlug"
                        )
                        val newUri = optRes.encryptedMasterUri
                        VaultCryptoManager.evictFromCache(if (targetIsBack) undoBase.backPhotoUri else undoBase.frontPhotoUri)
                        VaultCryptoManager.evictFromCache(newUri)
                        val metaJson = CardCropMetadata.toJson(newMeta.copy(cropRevision = nextRev, sideOrPage = sideSlug.uppercase()))
                        if (targetIsBack) {
                            undoBase.copy(
                                backPhotoUri = newUri,
                                backOriginalPhotoUri = origUri,
                                backCropMetaJson = metaJson,
                                backCropRevision = nextRev
                            )
                        } else {
                            undoBase.copy(
                                frontPhotoUri = newUri,
                                frontOriginalPhotoUri = origUri,
                                frontCropMetaJson = metaJson,
                                frontCropRevision = nextRev
                            )
                        }
                    }
                    previousCropUndoCard = undoBase
                    onUpdateCard(updated)
                    val sbRes = snackbarHostState.showSnackbar(
                        message = context.getString(R.string.crop_updated_toast),
                        actionLabel = context.getString(R.string.action_undo),
                        duration = SnackbarDuration.Long
                    )
                    if (sbRes == SnackbarResult.ActionPerformed) {
                        previousCropUndoCard?.let { prev ->
                            onUpdateCard(
                                if (targetIsBack) prev.copy(backCropRevision = updated.backCropRevision + 1)
                                else prev.copy(frontCropRevision = updated.frontCropRevision + 1)
                            )
                        }
                    }
                }
            },
            onDismiss = { detailCropSourceBitmap = null }
        )
    }

    // Sec 15-16: Full-Screen Checkout Mode (Keep screen awake, temporary brightness restored on exit, zero clutter)
    if (showEnlargedCode) {
        DisposableEffect(Unit) {
            val window = context.findLoyaltyActivity()?.window
            val prevBrightness = window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window?.attributes = window?.attributes?.apply { screenBrightness = 0.95f }
            onDispose {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                window?.attributes = window?.attributes?.apply { screenBrightness = prevBrightness }
            }
        }

        val (_, enlargedBmp, _) = if (activeCodeTab == "BARCODE") barcodeState else qrState
        Dialog(
            onDismissRequest = { showEnlargedCode = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(24.dp)
            ) {
                IconButton(
                    onClick = { showEnlargedCode = false },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close), tint = Color.Black)
                }

                Column(
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text(card.brandName, color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (enlargedBmp != null) {
                        Image(
                            bitmap = enlargedBmp.asImageBitmap(),
                            contentDescription = "Checkout code for ${card.brandName}",
                            contentScale = ContentScale.Fit,
                            modifier = if (activeCodeTab == "BARCODE") Modifier.fillMaxWidth().height(184.dp) else Modifier.size(280.dp)
                        )
                    }
                    if (card.cardNumber.isNotBlank()) {
                        Text(
                            text = card.cardNumber,
                            color = Color.Black,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.4.sp
                        )
                    }
                }
            }
        }
    }

    // Sec 39: Re-scan Barcode / QR right from Detail ⋮ More (never overwrites without user confirmation!)
    if (showRescanScanner) {
        LoyaltyCodeScannerDialog(
            initialMode = "AUTO",
            onDetected = { rawValue, formatName ->
                showRescanScanner = false
                pendingRescannedCode = rawValue to formatName
            },
            onDismiss = { showRescanScanner = false }
        )
    }

    pendingRescannedCode?.let { (rawValue, formatName) ->
        val isQr = formatName == "QR_CODE"
        AlertDialog(
            onDismissRequest = { pendingRescannedCode = null },
            title = { Text(stringResource(R.string.loyalty_rescan_confirm_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (isQr) stringResource(R.string.loyalty_rescan_confirm_qr) else stringResource(R.string.loyalty_rescan_confirm_barcode, LoyaltyCodeHelper.formatDisplayName(formatName)),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                        Text(rawValue, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(10.dp))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val updated = if (isQr) {
                        val qType = runCatching { UniversalQrParser.parse(rawValue).type.name }.getOrDefault("TEXT")
                        card.copy(qrPayload = rawValue, qrVerified = true, qrCodeType = qType)
                    } else {
                        card.copy(barcodeValue = rawValue, barcodeFormat = formatName, barcodeVerified = true, barcodeSource = "SCANNED")
                    }
                    onUpdateCard(updated)
                    pendingRescannedCode = null
                    Toast.makeText(context, context.getString(R.string.loyalty_barcode_verified), Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.action_confirm), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingRescannedCode = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    if (showMoreSheet) {
        CardLinkActionSheet(
            title = card.brandName.ifBlank { stringResource(R.string.loyalty_title) },
            actions = listOf(
                CardLinkSheetAction(Icons.Default.Edit, stringResource(R.string.action_edit), onClick = onEdit),
                CardLinkSheetAction(Icons.Default.QrCodeScanner, stringResource(R.string.loyalty_rescan_code_menu)) {
                    showRescanScanner = true
                },
                CardLinkSheetAction(
                    if (card.isFavorite) Icons.Default.StarBorder else Icons.Default.Star,
                    if (card.isFavorite) stringResource(R.string.loyalty_remove_fav) else stringResource(R.string.loyalty_add_fav),
                    onClick = onToggleFavorite
                ),
                CardLinkSheetAction(Icons.Default.Share, stringResource(R.string.loyalty_share_summary)) {
                    val text = buildString {
                        appendLine(card.brandName)
                        if (card.cardNickname.isNotBlank()) appendLine(card.cardNickname)
                        if (card.cardNumber.isNotBlank()) appendLine("Card: ${LoyaltyCodeHelper.maskCardNumber(card.cardNumber)}")
                    }.trim()
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share Loyalty Card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                },
                CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) {
                    showDeleteConfirm = true
                }
            ),
            onDismiss = { showMoreSheet = false }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.loyalty_delete_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.loyalty_delete_msg)) },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirm = false; onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
