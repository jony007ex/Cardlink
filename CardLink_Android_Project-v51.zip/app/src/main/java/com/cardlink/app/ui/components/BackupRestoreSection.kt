package com.cardlink.app.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreSection(viewModel: CardLinkViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val myCards by viewModel.myCards.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val followUps by viewModel.followUps.collectAsState()
    val loyaltyCards by viewModel.loyaltyCards.collectAsState()
    val idDocuments by viewModel.idDocuments.collectAsState()

    val currentTotalRecords = myCards.size + allContacts.size + followUps.size + loyaltyCards.size + idDocuments.size
    val fmtTime = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    // Backup Center reactive state
    var refreshTick by remember { mutableIntStateOf(0) }
    val healthInfo = remember(currentTotalRecords, refreshTick) {
        BackupCenterPrefs.computeBackupHealth(context, currentTotalRecords)
    }
    val recentBackups = remember(refreshTick) { BackupCenterPrefs.loadRecentBackups(context) }
    var showCloudRemovalNotice by remember { mutableStateOf(BackupCenterPrefs.shouldShowCloudRemovalNotice(context)) }
    var defaultEncryptPref by remember { mutableStateOf(BackupCenterPrefs.isDefaultPasswordProtectionEnabled(context)) }
    var reminderDays by remember { mutableIntStateOf(BackupCenterPrefs.getReminderIntervalDays(context)) }
    var preRestoreAvailable by remember(refreshTick) {
        mutableStateOf(BackupCenterPrefs.getPreRestoreSnapshotPath(context) != null)
    }

    // Operation progress state
    var activeStageMessage by remember { mutableStateOf<String?>(null) }

    // Create Full Backup flow state
    var showCreateConfigDialog by remember { mutableStateOf(false) }
    var pendingBackupOptions by remember { mutableStateOf(BackupSelectionOptions(isComplete = true)) }
    var pendingBackupPassword by remember { mutableStateOf<CharArray?>(null) }
    var pendingBackupFileName by remember { mutableStateOf("") }
    var pendingBackupSummary by remember { mutableStateOf<BackupPreCreationSummary?>(null) }

    // Restore flow state
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingRestoreInspection by remember { mutableStateOf<BackupInspectionResult?>(null) }
    var restoreResultSummary by remember { mutableStateOf<DetailedRestoreResult?>(null) }

    // Verify Backup flow state
    var pendingVerifyUri by remember { mutableStateOf<Uri?>(null) }
    var pendingVerifyResult by remember { mutableStateOf<BackupInspectionResult?>(null) }
    var showVerifyPasswordPrompt by remember { mutableStateOf(false) }

    // Selective Contact Export (CSV / XLSX) dialog state
    var showSelectiveExportFor by remember { mutableStateOf<String?>(null) } // "CSV" or "XLSX"
    var pendingExportContacts by remember { mutableStateOf<List<SavedContactEntity>>(emptyList()) }
    var pendingExportFields by remember { mutableStateOf(ContactExportField.values().toList()) }

    // System File Pickers (Save As / Open File — supports Internal, Downloads, SD Card, USB, etc.)
    val saveBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                activeStageMessage = "Preparing Backup…"
                CardLinkBackupPackageManager.createBackupPackageToUri(
                    context = context,
                    destinationUri = uri,
                    fileName = pendingBackupFileName,
                    options = pendingBackupOptions,
                    passwordChars = pendingBackupPassword,
                    onStage = { activeStageMessage = it }
                ).onSuccess { entry ->
                    refreshTick++
                    Toast.makeText(
                        context,
                        "Backup saved (${BackupCenterPrefs.formatBytes(entry.sizeBytes)})",
                        Toast.LENGTH_LONG
                    ).show()
                }.onFailure { err ->
                    Toast.makeText(context, err.localizedMessage ?: "Backup failed", Toast.LENGTH_LONG).show()
                }
                pendingBackupPassword = null
                activeStageMessage = null
            }
        } else {
            pendingBackupPassword?.fill('\u0000')
            pendingBackupPassword = null
        }
    }

    val openRestoreFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                activeStageMessage = "Validating backup…"
                val inspection = CardLinkBackupPackageManager.inspectBackupUri(context, uri)
                pendingRestoreUri = uri
                pendingRestoreInspection = inspection
                activeStageMessage = null
            }
        }
    }

    val openVerifyFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                activeStageMessage = "Verifying backup…"
                val inspection = CardLinkBackupPackageManager.inspectBackupUri(context, uri)
                pendingVerifyUri = uri
                if (inspection.isEncrypted && inspection.verificationState == BackupVerificationState.VERIFIED) {
                    showVerifyPasswordPrompt = true
                } else {
                    pendingVerifyResult = inspection
                }
                activeStageMessage = null
            }
        }
    }

    val exportVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri ->
        if (uri != null) viewModel.exportBatchVcf(uri) { res ->
            res.onSuccess { Toast.makeText(context, "Exported $it contacts as VCF!", Toast.LENGTH_LONG).show() }
        }
    }

    val importVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importBatchVcf(uri) { res ->
            res.onSuccess { Toast.makeText(context, "Imported $it contacts from VCF!", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "VCF Import failed: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
        }
    }

    val exportCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            viewModel.exportContactsSelectiveCsv(uri, pendingExportContacts, pendingExportFields) { res ->
                res.onSuccess { Toast.makeText(context, "Exported $it contacts as CSV!", Toast.LENGTH_LONG).show() }
                    .onFailure { Toast.makeText(context, "CSV Export failed: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    val exportXlsxLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) {
            viewModel.exportContactsSelectiveXlsx(uri, pendingExportContacts, pendingExportFields) { res ->
                res.onSuccess { Toast.makeText(context, "Exported $it contacts as Excel (.xlsx)!", Toast.LENGTH_LONG).show() }
                    .onFailure { Toast.makeText(context, "Excel Export failed: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {

        // 0. One-Time Cloud Removal Notice (Only shown if user previously used legacy cloud backup)
        if (showCloudRemovalNotice) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF172A46)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.backup_cloud_removed_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        text = stringResource(R.string.backup_cloud_removed_msg),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.88f)
                    )
                    TextButton(
                        onClick = {
                            BackupCenterPrefs.dismissCloudRemovalNotice(context)
                            showCloudRemovalNotice = false
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) { Text(stringResource(R.string.action_close), color = MaterialTheme.colorScheme.primary) }
                }
            }
        }

        // Progress Indicator Banner during active backup / restore / verification
        activeStageMessage?.let { stageMsg ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stageMsg, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // 0.5 SINGLE-FILE INCREMENTAL MASTER BACKUP
        MasterBackupCard(onRestoredPreferences = { viewModel.refreshAppPreferencesFromDisk(); refreshTick++ })

        // 1. BACKUP HEALTH CARD
        BackupSectionLabel(stringResource(R.string.backup_health_section))
        val (healthLabel, healthColor, healthIcon) = when (healthInfo.status) {
            BackupHealthStatus.UP_TO_DATE -> Triple(stringResource(R.string.backup_health_up_to_date), Color(0xFF10B981), Icons.Default.VerifiedUser)
            BackupHealthStatus.BACKUP_RECOMMENDED -> Triple(stringResource(R.string.backup_health_recommended), Color(0xFFF59E0B), Icons.Default.WarningAmber)
            BackupHealthStatus.BACKUP_OVERDUE -> Triple(stringResource(R.string.backup_health_overdue), Color(0xFFEF4444), Icons.Default.ErrorOutline)
            BackupHealthStatus.NO_BACKUP_FOUND -> Triple(stringResource(R.string.backup_health_none), MaterialTheme.colorScheme.primary, Icons.Default.Shield)
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.2.dp, healthColor.copy(alpha = 0.65f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(44.dp),
                        shape = CircleShape,
                        color = healthColor.copy(alpha = 0.16f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(healthIcon, null, tint = healthColor, modifier = Modifier.size(24.dp))
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(healthLabel, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = healthColor)
                        Text(
                            text = "${stringResource(R.string.backup_last_complete)}: ${
                                healthInfo.lastBackupTimestamp?.let { fmtTime.format(Date(it)) }
                                    ?: stringResource(R.string.backup_never)
                            }",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (healthInfo.lastBackupTimestamp != null) {
                            Text(
                                text = "${stringResource(R.string.backup_changes_since, healthInfo.changesSinceBackup)} • ${
                                    if (healthInfo.lastBackupEncrypted) stringResource(R.string.backup_protected_yes)
                                    else stringResource(R.string.backup_protected_standard)
                                }",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                    }
                }

                Button(
                    onClick = { showCreateConfigDialog = true },
                    enabled = activeStageMessage == null,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Backup, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.backup_create_full), fontWeight = FontWeight.Bold)
                }

                if (preRestoreAvailable) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                activeStageMessage = "Restoring previous state…"
                                CardLinkBackupPackageManager.undoLastRestore(context) { activeStageMessage = it }
                                    .onSuccess {
                                        viewModel.refreshAppPreferencesFromDisk()
                                        refreshTick++
                                        Toast.makeText(context, "Previous CardLink state restored!", Toast.LENGTH_LONG).show()
                                    }
                                    .onFailure {
                                        Toast.makeText(context, it.localizedMessage ?: "Undo restore failed", Toast.LENGTH_LONG).show()
                                    }
                                activeStageMessage = null
                            }
                        },
                        enabled = activeStageMessage == null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Undo, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.backup_undo_restore), fontSize = 13.sp)
                    }
                }
            }
        }

        // Local-First Privacy Message
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Column {
                    Text(stringResource(R.string.backup_privacy_title), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        stringResource(R.string.backup_privacy_msg),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                    )
                }
            }
        }

        // 2. SECURE BACKUP SECTION
        BackupSectionLabel(stringResource(R.string.backup_secure_section))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BackupActionTile(
                icon = Icons.Default.Shield,
                title = stringResource(R.string.backup_create_full),
                subtitle = stringResource(R.string.backup_create_full_sub),
                enabled = activeStageMessage == null,
                onClick = { showCreateConfigDialog = true }
            )
            BackupActionTile(
                icon = Icons.Default.Restore,
                title = stringResource(R.string.backup_restore_title),
                subtitle = stringResource(R.string.backup_restore_sub),
                enabled = activeStageMessage == null,
                onClick = { openRestoreFileLauncher.launch(arrayOf("*/*")) }
            )
            BackupActionTile(
                icon = Icons.Default.Verified,
                title = stringResource(R.string.backup_verify_title),
                subtitle = stringResource(R.string.backup_verify_sub),
                enabled = activeStageMessage == null,
                onClick = { openVerifyFileLauncher.launch(arrayOf("*/*")) }
            )
        }

        // 3. BACKUP PREFERENCES SECTION
        BackupSectionLabel(stringResource(R.string.backup_preferences_section))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.backup_password_protection), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            stringResource(R.string.backup_password_pref_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                    Switch(
                        checked = defaultEncryptPref,
                        onCheckedChange = {
                            defaultEncryptPref = it
                            BackupCenterPrefs.setDefaultPasswordProtectionEnabled(context, it)
                        }
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.backup_reminder_title), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val opts = listOf(
                            0 to stringResource(R.string.backup_reminder_off),
                            7 to stringResource(R.string.backup_reminder_7d),
                            14 to stringResource(R.string.backup_reminder_14d),
                            30 to stringResource(R.string.backup_reminder_30d)
                        )
                        opts.forEach { (days, lbl) ->
                            FilterChip(
                                selected = reminderDays == days,
                                onClick = {
                                    reminderDays = days
                                    BackupCenterPrefs.setReminderIntervalDays(context, days)
                                    refreshTick++
                                },
                                label = { Text(lbl, fontSize = 12.sp) }
                            )
                        }
                    }
                }
            }
        }

        // 4. DATA EXPORT SECTION (Clearly separated from Full Disaster-Recovery Backup)
        BackupSectionLabel(stringResource(R.string.backup_data_export_section))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.backup_export_contacts_header), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                val stamp = remember { SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { exportVcfLauncher.launch("CardLink_Contacts_$stamp.vcf") },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.backup_export_vcf_btn), fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    OutlinedButton(
                        onClick = { importVcfLauncher.launch(arrayOf("text/x-vcard", "text/vcard", "*/*")) },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.backup_import_vcf_btn), fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }

                OutlinedButton(
                    onClick = { showSelectiveExportFor = "CSV" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.TableRows, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.backup_export_csv_clean))
                }

                OutlinedButton(
                    onClick = { showSelectiveExportFor = "XLSX" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.GridOn, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.backup_export_xlsx))
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Text(
                    text = stringResource(R.string.backup_export_docs_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                )
            }
        }

        // 5. RECENT BACKUPS SECTION
        BackupSectionLabel(stringResource(R.string.backup_recent_section))
        if (recentBackups.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Text(
                    text = stringResource(R.string.backup_recent_empty),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recentBackups.forEach { entry ->
                    val accessible = remember(entry.uriString, refreshTick) {
                        BackupCenterPrefs.isBackupUriAccessible(context, entry.uriString)
                    }
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(entry.fileName, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${fmtTime.format(Date(entry.createdAtTimestamp))} • ${BackupCenterPrefs.formatBytes(entry.sizeBytes)} • ${
                                    if (entry.isCompleteBackup) stringResource(R.string.backup_mode_complete)
                                    else stringResource(R.string.backup_mode_custom)
                                }",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (entry.isEncrypted) stringResource(R.string.backup_protected_yes) else stringResource(R.string.backup_protected_standard),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (accessible) stringResource(R.string.backup_status_verified) else stringResource(R.string.backup_file_inaccessible),
                                    fontSize = 11.sp,
                                    color = if (accessible) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // =========================================================================
    // DIALOG 1: CREATE FULL BACKUP (Complete vs Custom + Password + Real Summary)
    // =========================================================================
    if (showCreateConfigDialog) {
        CreateBackupConfigDialog(
            defaultEncrypt = defaultEncryptPref,
            onDismiss = { showCreateConfigDialog = false },
            onProceedToSummary = { opts, pwd ->
                pendingBackupOptions = opts
                pendingBackupPassword = pwd
                showCreateConfigDialog = false
                scope.launch {
                    pendingBackupSummary = CardLinkBackupPackageManager.computeBackupSummary(context, opts)
                }
            }
        )
    }

    val sum = pendingBackupSummary
    if (sum != null) {
        AlertDialog(
            onDismissRequest = {
                pendingBackupSummary = null
                pendingBackupPassword?.fill('\u0000')
                pendingBackupPassword = null
            },
            title = { Text(stringResource(R.string.backup_summary_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("My Card: ${sum.myCardsCount} profile(s)", style = MaterialTheme.typography.bodySmall)
                    Text("Contacts: ${sum.contactsCount}", style = MaterialTheme.typography.bodySmall)
                    Text("Follow-Ups: ${sum.followUpsCount}", style = MaterialTheme.typography.bodySmall)
                    Text("Loyalty Cards: ${sum.loyaltyCardsCount}", style = MaterialTheme.typography.bodySmall)
                    Text("My IDs: ${sum.myIdsCount}", style = MaterialTheme.typography.bodySmall)
                    Text("Images / Documents: ${sum.assetsCount}", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text("Estimated Size: ${BackupCenterPrefs.formatBytes(sum.estimatedSizeBytes)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Text(
                        "Password Protected: ${if (pendingBackupPassword != null) "Yes (AES-256-GCM)" else "No"}",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!sum.hasEnoughStorage) {
                        Text(
                            stringResource(R.string.backup_not_enough_storage),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = sum.hasEnoughStorage,
                    onClick = {
                        pendingBackupSummary = null
                        val ts = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())
                        val fname = "CardLink_Backup_$ts.cardlink"
                        pendingBackupFileName = fname
                        saveBackupLauncher.launch(fname)
                    }
                ) { Text(stringResource(R.string.backup_create_action)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingBackupSummary = null
                    pendingBackupPassword?.fill('\u0000')
                    pendingBackupPassword = null
                }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    // =========================================================================
    // DIALOG 2: RESTORE INSPECTION, MERGE/REPLACE & 2-STEP REPLACE CONFIRMATION
    // =========================================================================
    val restoreInsp = pendingRestoreInspection
    val restoreUriVal = pendingRestoreUri
    if (restoreInsp != null && restoreUriVal != null) {
        RestoreInspectionDialog(
            inspection = restoreInsp,
            fmtTime = fmtTime,
            onDismiss = {
                pendingRestoreInspection = null
                pendingRestoreUri = null
            },
            onExecuteRestore = { replaceMode, conflictPolicy, pwd ->
                val uri = restoreUriVal
                pendingRestoreInspection = null
                pendingRestoreUri = null
                scope.launch {
                    activeStageMessage = "Validating backup…"
                    CardLinkBackupPackageManager.restoreBackupUri(
                        context = context,
                        sourceUri = uri,
                        replaceExisting = replaceMode,
                        conflictPolicy = conflictPolicy,
                        passwordChars = pwd,
                        onStage = { activeStageMessage = it }
                    ).onSuccess { res ->
                        viewModel.refreshAppPreferencesFromDisk()
                        refreshTick++
                        restoreResultSummary = res
                    }.onFailure { err ->
                        Toast.makeText(context, err.localizedMessage ?: "Restore failed", Toast.LENGTH_LONG).show()
                    }
                    activeStageMessage = null
                }
            }
        )
    }

    // Restore Result Summary Dialog
    val r = restoreResultSummary
    if (r != null) {
        AlertDialog(
            onDismissRequest = { restoreResultSummary = null },
            title = { Text(stringResource(R.string.backup_restore_complete_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("My Card: ${r.myCardsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    Text("Contacts: ${r.contactsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    Text("Follow-Ups: ${r.followUpsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    Text("Loyalty Cards: ${r.loyaltyCardsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    Text("My IDs: ${r.myIdsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    Text("Images / Documents: ${r.assetsRestored} restored", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text("Conflicts resolved: ${r.conflictsResolved} • Skipped: ${r.skipped}", style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                Button(onClick = { restoreResultSummary = null }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // =========================================================================
    // DIALOG 3: VERIFY BACKUP WITHOUT RESTORING
    // =========================================================================
    if (showVerifyPasswordPrompt && pendingVerifyUri != null) {
        var pwdText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showVerifyPasswordPrompt = false; pendingVerifyUri = null },
            title = { Text(stringResource(R.string.backup_enter_password_title), fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = pwdText,
                    onValueChange = { pwdText = it },
                    label = { Text(stringResource(R.string.backup_password_label)) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    val uri = pendingVerifyUri ?: return@Button
                    val chars = pwdText.toCharArray()
                    showVerifyPasswordPrompt = false
                    scope.launch {
                        activeStageMessage = "Verifying backup…"
                        pendingVerifyResult = CardLinkBackupPackageManager.inspectBackupUri(context, uri, chars)
                        chars.fill('\u0000')
                        activeStageMessage = null
                    }
                }) { Text(stringResource(R.string.backup_verify_title)) }
            },
            dismissButton = {
                TextButton(onClick = { showVerifyPasswordPrompt = false; pendingVerifyUri = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    val v = pendingVerifyResult
    if (v != null) {
        val (badge, badgeColor) = when (v.verificationState) {
            BackupVerificationState.VERIFIED -> "✅ Backup Verified" to Color(0xFF10B981)
            BackupVerificationState.INCOMPLETE -> "⚠️ Incomplete Backup" to Color(0xFFF59E0B)
            BackupVerificationState.WRONG_PASSWORD -> "❌ Wrong Password" to Color(0xFFEF4444)
            BackupVerificationState.UNSUPPORTED_VERSION -> "⚠️ Unsupported Backup Version" to Color(0xFFF59E0B)
            BackupVerificationState.CORRUPTED -> "❌ Backup Corrupted" to Color(0xFFEF4444)
        }
        AlertDialog(
            onDismissRequest = { pendingVerifyResult = null; pendingVerifyUri = null },
            title = { Text(badge, fontWeight = FontWeight.Bold, color = badgeColor) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(v.detailMessage, style = MaterialTheme.typography.bodySmall)
                    if (v.backupFormatVersion > 0) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("Format: Version ${v.backupFormatVersion} (${v.appVersionName})", style = MaterialTheme.typography.labelSmall)
                        Text("Contacts: ${v.contactsCount} • Loyalty: ${v.loyaltyCardsCount} • My IDs: ${v.myIdsCount} • Assets: ${v.assetsCount}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { pendingVerifyResult = null; pendingVerifyUri = null }) { Text(stringResource(R.string.action_close)) }
            }
        )
    }

    // =========================================================================
    // DIALOG 4: SELECTIVE CONTACT EXPORT (CSV / EXCEL .xlsx)
    // =========================================================================
    val targetFormat = showSelectiveExportFor
    if (targetFormat != null) {
        SelectiveContactExportDialog(
            allContacts = allContacts,
            formatLabel = targetFormat,
            onDismiss = { showSelectiveExportFor = null },
            onExport = { filteredList, chosenFields ->
                pendingExportContacts = filteredList
                pendingExportFields = chosenFields
                showSelectiveExportFor = null
                val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                if (targetFormat == "CSV") exportCsvLauncher.launch("CardLink_Contacts_$stamp.csv")
                else exportXlsxLauncher.launch("CardLink_Contacts_$stamp.xlsx")
            }
        )
    }
}

@Composable
private fun BackupSectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp
    )
}

@Composable
private fun BackupActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f))
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
    }
}

@Composable
private fun CreateBackupConfigDialog(
    defaultEncrypt: Boolean,
    onDismiss: () -> Unit,
    onProceedToSummary: (BackupSelectionOptions, CharArray?) -> Unit
) {
    val context = LocalContext.current
    var isComplete by remember { mutableStateOf(true) }
    var incMyCards by remember { mutableStateOf(true) }
    var incContacts by remember { mutableStateOf(true) }
    var incFollowUps by remember { mutableStateOf(true) }
    var incLoyalty by remember { mutableStateOf(true) }
    var incMyIds by remember { mutableStateOf(true) }
    var incAssets by remember { mutableStateOf(true) }
    var incPrefs by remember { mutableStateOf(true) }

    var protectWithPassword by remember { mutableStateOf(defaultEncrypt) }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.backup_create_full), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isComplete,
                        onClick = { isComplete = true },
                        label = { Text(stringResource(R.string.backup_mode_complete), fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !isComplete,
                        onClick = { isComplete = false },
                        label = { Text(stringResource(R.string.backup_mode_custom), fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (!isComplete) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        CheckRow("My Card", incMyCards) { incMyCards = it }
                        CheckRow("Contacts", incContacts) { incContacts = it }
                        CheckRow("Follow-Ups", incFollowUps) { incFollowUps = it }
                        CheckRow("Loyalty Cards", incLoyalty) { incLoyalty = it }
                        CheckRow("My IDs", incMyIds) { incMyIds = it }
                        CheckRow("Images & Documents", incAssets) { incAssets = it }
                        CheckRow("Settings & Preferences", incPrefs) { incPrefs = it }
                    }
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.backup_protect_password_toggle), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Switch(checked = protectWithPassword, onCheckedChange = { protectWithPassword = it })
                }

                if (protectWithPassword) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text(stringResource(R.string.backup_password_label)) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text(stringResource(R.string.backup_confirm_password_label)) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = stringResource(R.string.backup_password_warning),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (protectWithPassword) {
                    if (password.length < 8) {
                        Toast.makeText(context, "Use a strong password (at least 8 characters).", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (password != confirmPassword) {
                        Toast.makeText(context, "Passwords do not match.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                }
                val opts = BackupSelectionOptions(
                    isComplete = isComplete,
                    includeMyCards = isComplete || incMyCards,
                    includeContacts = isComplete || incContacts,
                    includeFollowUps = isComplete || incFollowUps,
                    includeLoyaltyCards = isComplete || incLoyalty,
                    includeMyIds = isComplete || incMyIds,
                    includeAssets = isComplete || incAssets,
                    includePreferences = isComplete || incPrefs
                )
                val pwdChars = if (protectWithPassword) password.toCharArray() else null
                onProceedToSummary(opts, pwdChars)
            }) { Text(stringResource(R.string.action_confirm)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        }
    )
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun RestoreInspectionDialog(
    inspection: BackupInspectionResult,
    fmtTime: SimpleDateFormat,
    onDismiss: () -> Unit,
    onExecuteRestore: (replaceExisting: Boolean, conflictPolicy: RestoreConflictPolicy, password: CharArray?) -> Unit
) {
    val context = LocalContext.current
    var replaceMode by remember { mutableStateOf(false) }
    var conflictPolicy by remember { mutableStateOf(RestoreConflictPolicy.KEEP_EXISTING) }
    var password by remember { mutableStateOf("") }
    var replaceConfirmStep by remember { mutableIntStateOf(0) } // 0 = main, 1 = first confirm, 2 = second deliberate confirm

    val canRestore = inspection.verificationState == BackupVerificationState.VERIFIED ||
        inspection.verificationState == BackupVerificationState.INCOMPLETE

    if (replaceConfirmStep == 1) {
        AlertDialog(
            onDismissRequest = { replaceConfirmStep = 0 },
            title = { Text(stringResource(R.string.backup_replace_confirm_1_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = { Text(stringResource(R.string.backup_replace_confirm_1_msg)) },
            confirmButton = {
                Button(
                    onClick = { replaceConfirmStep = 2 },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = { TextButton(onClick = { replaceConfirmStep = 0 }) { Text(stringResource(R.string.action_cancel)) } }
        )
        return
    }

    if (replaceConfirmStep == 2) {
        AlertDialog(
            onDismissRequest = { replaceConfirmStep = 0 },
            title = { Text(stringResource(R.string.backup_replace_confirm_2_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = { Text(stringResource(R.string.backup_replace_confirm_2_msg)) },
            confirmButton = {
                Button(
                    onClick = {
                        replaceConfirmStep = 0
                        onExecuteRestore(true, RestoreConflictPolicy.USE_BACKUP, if (inspection.isEncrypted) password.toCharArray() else null)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.backup_mode_replace)) }
            },
            dismissButton = { TextButton(onClick = { replaceConfirmStep = 0 }) { Text(stringResource(R.string.action_cancel)) } }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.backup_details_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (inspection.createdAtTimestamp > 0L) {
                    Text("Created: ${fmtTime.format(Date(inspection.createdAtTimestamp))}", style = MaterialTheme.typography.bodySmall)
                }
                Text("CardLink Version: ${inspection.appVersionName} (Format v${inspection.backupFormatVersion})", style = MaterialTheme.typography.bodySmall)
                Text("Protection: ${if (inspection.isEncrypted) "Password Protected (AES-256-GCM)" else "Standard"}", style = MaterialTheme.typography.bodySmall)
                Text("Contacts: ${inspection.contactsCount} • Loyalty Cards: ${inspection.loyaltyCardsCount} • My IDs: ${inspection.myIdsCount}", style = MaterialTheme.typography.bodySmall)
                Text("Follow-Ups: ${inspection.followUpsCount} • Assets: ${inspection.assetsCount}", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "Integrity: ${inspection.detailMessage}",
                    color = if (canRestore) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )

                if (canRestore) {
                    HorizontalDivider()
                    if (inspection.isEncrypted) {
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text(stringResource(R.string.backup_password_label)) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Clear 2-mode Restore Selector (Merge default vs Replace)
                    Card(
                        onClick = { replaceMode = false },
                        shape = RoundedCornerShape(12.dp),
                        border = if (!replaceMode) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = !replaceMode, onClick = { replaceMode = false })
                            Column {
                                Text(stringResource(R.string.backup_mode_merge), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(stringResource(R.string.backup_mode_merge_sub), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    if (!replaceMode) {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(selected = conflictPolicy == RestoreConflictPolicy.KEEP_EXISTING, onClick = { conflictPolicy = RestoreConflictPolicy.KEEP_EXISTING }, label = { Text(stringResource(R.string.bk_keep_existing), fontSize = 11.sp) })
                            FilterChip(selected = conflictPolicy == RestoreConflictPolicy.USE_BACKUP, onClick = { conflictPolicy = RestoreConflictPolicy.USE_BACKUP }, label = { Text(stringResource(R.string.bk_use_backup), fontSize = 11.sp) })
                            FilterChip(selected = conflictPolicy == RestoreConflictPolicy.KEEP_BOTH, onClick = { conflictPolicy = RestoreConflictPolicy.KEEP_BOTH }, label = { Text(stringResource(R.string.prod_keep_both_btn), fontSize = 11.sp) })
                        }
                    }

                    Card(
                        onClick = { replaceMode = true },
                        shape = RoundedCornerShape(12.dp),
                        border = if (replaceMode) BorderStroke(1.5.dp, MaterialTheme.colorScheme.error) else null
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = replaceMode, onClick = { replaceMode = true })
                            Column {
                                Text(stringResource(R.string.backup_mode_replace), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(stringResource(R.string.backup_mode_replace_sub), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (canRestore) {
                Button(onClick = {
                    if (inspection.isEncrypted && password.isBlank()) {
                        Toast.makeText(context, "Please enter the backup password.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (replaceMode) {
                        replaceConfirmStep = 1
                    } else {
                        onExecuteRestore(false, conflictPolicy, if (inspection.isEncrypted) password.toCharArray() else null)
                    }
                }) { Text(stringResource(R.string.action_restore)) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@Composable
private fun SelectiveContactExportDialog(
    allContacts: List<SavedContactEntity>,
    formatLabel: String,
    onDismiss: () -> Unit,
    onExport: (List<SavedContactEntity>, List<ContactExportField>) -> Unit
) {
    var scopeKey by remember { mutableStateOf("ALL") } // ALL, RECENT, TAG
    val distinctTags = remember(allContacts) { allContacts.map { it.categoryTag }.filter { it.isNotBlank() }.distinct().sorted() }
    var selectedTag by remember(distinctTags) { mutableStateOf(distinctTags.firstOrNull().orEmpty()) }
    var selectedFields by remember { mutableStateOf(ContactExportField.values().toSet()) }

    val filtered = remember(allContacts, scopeKey, selectedTag) {
        when (scopeKey) {
            "RECENT" -> allContacts.sortedByDescending { it.savedAtTimestamp }.take(25)
            "TAG" -> if (selectedTag.isBlank()) allContacts else allContacts.filter { it.categoryTag.equals(selectedTag, true) }
            else -> allContacts
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export Contacts ($formatLabel)", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Scope (${filtered.size} contacts)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = scopeKey == "ALL", onClick = { scopeKey = "ALL" }, label = { Text(stringResource(R.string.qa_filter_all), fontSize = 11.sp) })
                    FilterChip(selected = scopeKey == "RECENT", onClick = { scopeKey = "RECENT" }, label = { Text(stringResource(R.string.bk_recent_25), fontSize = 11.sp) })
                    if (distinctTags.isNotEmpty()) {
                        FilterChip(selected = scopeKey == "TAG", onClick = { scopeKey = "TAG" }, label = { Text(stringResource(R.string.bk_by_tag), fontSize = 11.sp) })
                    }
                }
                if (scopeKey == "TAG" && distinctTags.isNotEmpty()) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        distinctTags.forEach { t ->
                            FilterChip(selected = selectedTag == t, onClick = { selectedTag = t }, label = { Text(t, fontSize = 11.sp) })
                        }
                    }
                }
                HorizontalDivider()
                Text(stringResource(R.string.bk_fields_lbl), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                ContactExportField.values().forEach { field ->
                    CheckRow(field.header, field in selectedFields) { checked ->
                        selectedFields = if (checked) selectedFields + field else (selectedFields - field).ifEmpty { setOf(ContactExportField.NAME) }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onExport(filtered, ContactExportField.values().filter { it in selectedFields }) }) {
                Text(stringResource(R.string.bk_export_btn))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}
