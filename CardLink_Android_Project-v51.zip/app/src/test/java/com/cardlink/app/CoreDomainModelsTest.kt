package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.util.CardCropMetadata
import com.cardlink.app.util.CardTemplateRegistry
import com.cardlink.app.util.IdExpiryHelper
import com.cardlink.app.util.LoyaltyCodeHelper
import org.junit.Assert.*
import org.junit.Test

class CoreDomainModelsTest {

    @Test
    fun cardTemplateRegistry_resolvesEveryEnumSafelyWithoutNullCrash() {
        for (tpl in CardTemplate.values()) {
            val resolved = CardTemplateRegistry.resolveForCard(
                BusinessCardEntity(template = tpl, selectedTemplateId = "")
            )
            assertTrue(resolved.id.isNotBlank())
        }
        val fallback = CardTemplateRegistry.resolveForCard(
            BusinessCardEntity(selectedTemplateId = "non_existent_id:v99")
        )
        assertTrue(fallback.id.isNotBlank())
    }

    @Test
    fun loyaltyCodeHelper_masksCardNumberSafely() {
        assertEquals("•••• 5678", LoyaltyCodeHelper.maskCardNumber("12345678"))
        assertEquals("1234", LoyaltyCodeHelper.maskCardNumber("1234"))
        assertEquals("Code 128", LoyaltyCodeHelper.formatDisplayName("CODE_128"))
    }

    @Test
    fun cardCropMetadata_roundTripsJsonCleanly() {
        val original = CardCropMetadata(
            topLeftX = 0.08f,
            topLeftY = 0.12f,
            topRightX = 0.91f,
            topRightY = 0.10f,
            bottomRightX = 0.93f,
            bottomRightY = 0.89f,
            bottomLeftX = 0.06f,
            bottomLeftY = 0.90f,
            rotationDegrees = 90,
            enhanceReadability = true
        )
        val encoded = CardCropMetadata.toJson(original)
        val decoded = CardCropMetadata.fromJson(encoded)
        assertNotNull(decoded)
        assertEquals(90, decoded?.rotationDegrees)
        assertEquals(0.08f, decoded?.topLeftX ?: 0f, 0.0001f)
    }

    @Test
    fun idExpiryHelper_parsesAndFormatsIsoDate() {
        val iso = IdExpiryHelper.toIsoDate(2028, 5, 9)
        assertEquals("2028-05-09", iso)
        val parsed = IdExpiryHelper.parseIsoDate(iso)
        assertNotNull(parsed)
        assertEquals(2028, parsed?.year)
        assertEquals(5, parsed?.monthValue)
        assertEquals(9, parsed?.dayOfMonth)
    }
}
