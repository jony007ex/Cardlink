package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ToolEntry(
    val id: String,
    val category: String,
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    val highlighted: Boolean = false,
    val onOpen: () -> Unit
)

@Composable
fun ToolsScreen(
    activeCard: BusinessCardEntity,
    eventMode: EventModeConfig,
    onOpenQrStudio: () -> Unit,
    onOpenQrScanner: () -> Unit,
    onOpenDualSideOcr: () -> Unit,
    onOpenLoyaltyCards: () -> Unit,
    onOpenMyIds: () -> Unit,
    onOpenSecureNotes: () -> Unit,
    onOpenEventMode: () -> Unit,
    onOpenMeetingBg: () -> Unit,
    onOpenQuickShare: () -> Unit,
    onLogShare: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showWallpaperConfirmDialog by remember { mutableStateOf(false) }
    var isApplyingWallpaper by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }
    var favoriteIds by remember { mutableStateOf(UxExperiencePrefs.getFavoriteToolIds(context)) }
    var recentIds by remember { mutableStateOf(UxExperiencePrefs.getRecentToolIds(context)) }
    val hideSensitive = remember { SecurityHardeningManager.isSensitiveAreaHidden(context) }

    fun openTool(id: String, action: () -> Unit) {
        UxExperiencePrefs.recordToolUsed(context, id)
        recentIds = UxExperiencePrefs.getRecentToolIds(context)
        action()
    }

    val allTools = listOfNotNull(
        // Scan & Create
        ToolEntry("qr_scanner", "Scan & Create", Icons.Default.QrCodeScanner, stringResource(R.string.tools_qr_scanner), stringResource(R.string.tools_qr_scanner_sub)) { openTool("qr_scanner", onOpenQrScanner) },
        ToolEntry("qr_studio", "Scan & Create", Icons.Default.QrCode2, stringResource(R.string.qr_studio_title), stringResource(R.string.qr_studio_tools_subtitle)) { openTool("qr_studio", onOpenQrStudio) },
        ToolEntry("scan_card", "Scan & Create", Icons.Default.DocumentScanner, stringResource(R.string.tools_dual_ocr), stringResource(R.string.tools_dual_ocr_sub)) { openTool("scan_card", onOpenDualSideOcr) },

        // Secure Wallet (Hidden during Panic Lock / Decoy Mode)
        if (!hideSensitive) ToolEntry("loyalty_cards", "Secure Wallet", Icons.Default.CardMembership, stringResource(R.string.loyalty_title), stringResource(R.string.loyalty_tools_subtitle)) { openTool("loyalty_cards", onOpenLoyaltyCards) } else null,
        if (!hideSensitive) ToolEntry("my_ids", "Secure Wallet", Icons.Default.Badge, stringResource(R.string.my_ids_title), stringResource(R.string.my_ids_tools_subtitle)) { openTool("my_ids", onOpenMyIds) } else null,
        if (!hideSensitive) ToolEntry("secure_notes", "Secure Wallet", Icons.Default.Lock, stringResource(R.string.secure_notes_title), stringResource(R.string.secure_notes_subtitle)) { openTool("secure_notes", onOpenSecureNotes) } else null,

        // Share & Personalize
        ToolEntry("event_mode", "Share & Personalize", Icons.Default.EventNote, if (eventMode.isActive) "${stringResource(R.string.home_event_mode_on)} ${eventMode.eventName}" else stringResource(R.string.tools_event_mode), stringResource(R.string.tools_event_mode_sub), highlighted = eventMode.isActive) { openTool("event_mode", onOpenEventMode) },
        ToolEntry("quick_share", "Share & Personalize", Icons.Default.Contactless, stringResource(R.string.tools_quick_nfc_qr), stringResource(R.string.tools_quick_nfc_qr_sub)) { openTool("quick_share", onOpenQuickShare) },
        ToolEntry("meeting_bg", "Share & Personalize", Icons.Default.VideoCameraFront, stringResource(R.string.tools_meeting_bg), stringResource(R.string.tools_meeting_bg_sub)) { openTool("meeting_bg", onOpenMeetingBg) },
        ToolEntry("print_pdf", "Share & Personalize", Icons.Default.Print, stringResource(R.string.tools_print_pdf), stringResource(R.string.tools_print_pdf_sub)) {
            openTool("print_pdf") {
                onLogShare("Print-Ready PDF (3.5x2)")
                CardShareHelper.sharePrintReadyPhysicalCardPdf(context, activeCard)
            }
        },
        ToolEntry("email_sig", "Share & Personalize", Icons.Default.Draw, stringResource(R.string.tools_email_sig), stringResource(R.string.tools_email_sig_sub)) {
            openTool("email_sig") { PremiumExtrasHelper.copyEmailSignatureToClipboard(context, activeCard) }
        }
    )

    val q = searchQuery.trim()
    val filteredTools = if (q.isBlank()) allTools else allTools.filter {
        it.title.contains(q, true) || it.subtitle.contains(q, true) || it.category.contains(q, true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(stringResource(R.string.tools_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.tools_subtitle), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }

        // Search Tools Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(stringResource(R.string.ux_search_tools_hint)) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = GoldAccent) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )

        // Favorites (Pinned 3-4 tools) & Recently Used (only when not searching)
        if (q.isBlank()) {
            val favTools = favoriteIds.mapNotNull { id -> allTools.firstOrNull { it.id == id } }
            if (favTools.isNotEmpty()) {
                ToolsSectionHeader(stringResource(R.string.ux_tools_favorites))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    favTools.forEach { t ->
                        AssistChip(
                            onClick = t.onOpen,
                            leadingIcon = { Icon(t.icon, null, tint = GoldAccent, modifier = Modifier.size(16.dp)) },
                            label = { Text(t.title, fontSize = 12.sp) }
                        )
                    }
                }
            }

            val recentTools = recentIds.mapNotNull { id -> allTools.firstOrNull { it.id == id } }
            if (recentTools.isNotEmpty()) {
                ToolsSectionHeader(stringResource(R.string.ux_tools_recent))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recentTools.forEach { t ->
                        AssistChip(
                            onClick = t.onOpen,
                            leadingIcon = { Icon(Icons.Default.History, null, tint = GoldAccent, modifier = Modifier.size(15.dp)) },
                            label = { Text(t.title, fontSize = 12.sp) }
                        )
                    }
                }
            }
        }

        // Categorized Tools
        val categories = listOf("Scan & Create", "Secure Wallet", "Share & Personalize")
        categories.forEach { cat ->
            val itemsInCat = filteredTools.filter { it.category == cat }
            if (itemsInCat.isNotEmpty()) {
                ToolsSectionHeader(cat)
                itemsInCat.forEach { tool ->
                    val isFav = tool.id in favoriteIds
                    ToolItemCard(
                        icon = tool.icon,
                        title = tool.title,
                        subtitle = tool.subtitle,
                        highlighted = tool.highlighted,
                        isFavorite = isFav,
                        onToggleFavorite = {
                            val (updated, ok) = UxExperiencePrefs.toggleFavoriteTool(context, tool.id)
                            favoriteIds = updated
                            if (!ok) {
                                Toast.makeText(context, "You can pin up to 4 favorite tools.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onClick = tool.onOpen
                    )
                }
            }
        }

        // Lock-Screen QR Wallpaper (Shown when not filtered out)
        if (q.isBlank() || "wallpaper".contains(q, true) || "qr".contains(q, true)) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Surface(modifier = Modifier.size(42.dp), shape = CircleShape, color = GoldAccent.copy(alpha = 0.16f)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Wallpaper, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(22.dp))
                            }
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.tools_lock_wallpaper), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(stringResource(R.string.tools_lock_wallpaper_sub), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = true },
                            enabled = !isApplyingWallpaper,
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.share_set_wallpaper), fontSize = 12.sp) }

                        OutlinedButton(
                            onClick = { PremiumExtrasHelper.shareLockScreenWallpaper(context, activeCard) },
                            modifier = Modifier.weight(1f)
                        ) { Text(stringResource(R.string.share_wallpaper), fontSize = 12.sp) }
                    }
                }
            }
        }
    }

    if (showWallpaperConfirmDialog) {
        AlertDialog(
            onDismissRequest = { if (!isApplyingWallpaper) showWallpaperConfirmDialog = false },
            title = { Text(stringResource(R.string.wallpaper_confirm_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.wallpaper_confirm_msg)) },
            confirmButton = {
                Button(
                    enabled = !isApplyingWallpaper,
                    onClick = {
                        if (isApplyingWallpaper) return@Button
                        isApplyingWallpaper = true
                        showWallpaperConfirmDialog = false
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) {
                                PremiumExtrasHelper.applyLockScreenWallpaper(context, activeCard)
                            }
                            isApplyingWallpaper = false
                            Toast.makeText(
                                context,
                                if (ok) context.getString(R.string.wallpaper_set_success)
                                else context.getString(R.string.wallpaper_set_failed),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                ) { Text(stringResource(R.string.wallpaper_confirm_action)) }
            },
            dismissButton = {
                TextButton(enabled = !isApplyingWallpaper, onClick = { showWallpaperConfirmDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun ToolsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = GoldAccent,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun ToolItemCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    highlighted: Boolean = false,
    isFavorite: Boolean = false,
    onToggleFavorite: () -> Unit = {},
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = if (highlighted) BorderStroke(1.2.dp, Color(0xFF00E5FF)) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = if (highlighted) Color(0xFF00E5FF).copy(alpha = 0.16f) else GoldAccent.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = if (highlighted) Color(0xFF00E5FF) else GoldAccent, modifier = Modifier.size(22.dp))
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }
            IconButton(onClick = onToggleFavorite, modifier = Modifier.size(34.dp)) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Pin favorite tool",
                    tint = if (isFavorite) GoldAccent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.size(18.dp)
                )
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
        }
    }
}
