package com.cardlink.app.data.local

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cardlink.app.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CardLinkDao {
    @Query("SELECT * FROM my_cards ORDER BY isDefault DESC, id ASC")
    fun getAllMyCards(): Flow<List<BusinessCardEntity>>

    @Query("SELECT * FROM my_cards ORDER BY id ASC")
    suspend fun getAllMyCardsSnapshot(): List<BusinessCardEntity>

    @Query("SELECT * FROM my_cards WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultCardSnapshot(): BusinessCardEntity?

    @Upsert
    suspend fun upsertMyCard(card: BusinessCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMyCardsBatch(cards: List<BusinessCardEntity>)

    @Query("UPDATE my_cards SET isDefault = CASE WHEN id = :cardId THEN 1 ELSE 0 END")
    suspend fun setActiveCard(cardId: Long)

    @Query("DELETE FROM my_cards")
    suspend fun clearAllMyCards()

    @Query("""
        SELECT * FROM saved_contacts
        WHERE fullName LIKE '%' || :query || '%'
           OR companyName LIKE '%' || :query || '%'
           OR designation LIKE '%' || :query || '%'
           OR phone LIKE '%' || :query || '%'
           OR whatsapp LIKE '%' || :query || '%'
           OR notes LIKE '%' || :query || '%'
        ORDER BY savedAtTimestamp DESC
    """)
    fun searchContacts(query: String): Flow<List<SavedContactEntity>>

    @Query("SELECT * FROM saved_contacts ORDER BY savedAtTimestamp DESC")
    fun getAllContactsFlow(): Flow<List<SavedContactEntity>>

    @Query("SELECT * FROM saved_contacts ORDER BY savedAtTimestamp DESC")
    suspend fun getAllContactsSnapshot(): List<SavedContactEntity>

    @Upsert
    suspend fun upsertContact(contact: SavedContactEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContactsBatch(contacts: List<SavedContactEntity>)

    @Delete
    suspend fun deleteContact(contact: SavedContactEntity)

    @Query("DELETE FROM saved_contacts")
    suspend fun clearAllContacts()

    @Insert
    suspend fun logShareEvent(event: ShareHistoryEntity)

    @Query("SELECT * FROM share_history ORDER BY timestamp DESC LIMIT 500")
    fun getShareHistory(): Flow<List<ShareHistoryEntity>>

    @Query("SELECT * FROM follow_up_items ORDER BY isCompleted ASC, dueAtTimestamp ASC")
    fun getAllFollowUpsFlow(): Flow<List<FollowUpEntity>>

    @Query("SELECT * FROM follow_up_items ORDER BY dueAtTimestamp ASC")
    suspend fun getAllFollowUpsSnapshot(): List<FollowUpEntity>

    @Query("SELECT * FROM follow_up_items WHERE id = :id LIMIT 1")
    suspend fun getFollowUpById(id: Long): FollowUpEntity?

    @Query("SELECT * FROM follow_up_items WHERE contactId = :contactId ORDER BY isCompleted ASC, dueAtTimestamp ASC")
    fun getFollowUpsForContactFlow(contactId: Long): Flow<List<FollowUpEntity>>

    @Query("SELECT * FROM follow_up_items WHERE contactId = :contactId AND channel = 'WHATSAPP' AND isCompleted = 0 AND status != 'CANCELLED'")
    suspend fun getPendingWhatsAppFollowUpsForContact(contactId: Long): List<FollowUpEntity>

    @Upsert
    suspend fun upsertFollowUp(item: FollowUpEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollowUpsBatch(items: List<FollowUpEntity>)

    @Delete
    suspend fun deleteFollowUp(item: FollowUpEntity)

    @Query("DELETE FROM follow_up_items")
    suspend fun clearAllFollowUps()
}

@Database(
    entities = [
        BusinessCardEntity::class,
        SavedContactEntity::class,
        ShareHistoryEntity::class,
        FollowUpEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class CardLinkDatabase : RoomDatabase() {
    abstract fun dao(): CardLinkDao

    companion object {
        @Volatile
        private var INSTANCE: CardLinkDatabase? = null

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE my_cards ADD COLUMN secondaryColorHex INTEGER NOT NULL DEFAULT ${0xFF112240}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN buttonColorHex INTEGER NOT NULL DEFAULT ${0xFFD4AF37}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN iconColorHex INTEGER NOT NULL DEFAULT ${0xFFD4AF37}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN cardGradientEndHex INTEGER NOT NULL DEFAULT ${0xFF172A46}")

                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN alarmEnabled INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN notificationEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN reminderOffsetMinutes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN channel TEXT NOT NULL DEFAULT 'GENERAL'")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappNumber TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappMessage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappMode TEXT NOT NULL DEFAULT 'REMINDER_TO_SEND'")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE saved_contacts ADD COLUMN backPhotoUri TEXT")
            }
        }

        fun getDatabase(context: Context): CardLinkDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CardLinkDatabase::class.java,
                    "cardlink.db"
                )
                    .addMigrations(MIGRATION_4_5, MIGRATION_5_6)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
