package com.cardlink.app.util

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

@Serializable
data class CloudSnapshotBundle(
    val schemaVersion: Int = 5,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val provider: String = "LOCAL",
    val checksumSha256: String = "",
    val cards: List<BusinessCardEntity> = emptyList(),
    val contacts: List<SavedContactEntity> = emptyList(),
    val followUps: List<FollowUpEntity> = emptyList(),
    val themeConfig: AppCustomThemeConfig = AppCustomThemeConfig(),
    val biometricLockEnabled: Boolean = false
)

data class CloudProviderState(
    val isConnected: Boolean = false,
    val accountLabel: String = "",
    val lastBackupTimestamp: Long? = null,
    val lastStatusMessage: String = "Not connected",
    val availableSnapshots: List<CloudSnapshotBundle> = emptyList()
)

object CloudBackupManager {
    private const val PREFS = "cardlink_cloud_prefs"
    private const val KEYSTORE_ALIAS = "cardlink_cloud_token_key"

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    fun isGoogleDriveOAuthConfigured(context: Context): Boolean {
        val resId = context.resources.getIdentifier("google_drive_web_client_id", "string", context.packageName)
        if (resId == 0) return false
        val valStr = runCatching { context.getString(resId) }.getOrNull().orEmpty()
        return valStr.isNotBlank() && !valStr.startsWith("REPLACE_WITH_")
    }

    fun isOneDriveOAuthConfigured(context: Context): Boolean {
        val resId = context.resources.getIdentifier("onedrive_client_id", "string", context.packageName)
        if (resId == 0) return false
        val valStr = runCatching { context.getString(resId) }.getOrNull().orEmpty()
        return valStr.isNotBlank() && !valStr.startsWith("REPLACE_WITH_")
    }

    fun loadProviderState(context: Context, providerKey: String): CloudProviderState {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val connected = p.getBoolean("${providerKey}_connected", false)
        val account = p.getString("${providerKey}_account", "").orEmpty()
        val lastTs = p.getLong("${providerKey}_last_ts", -1L).takeIf { it > 0L }
        val status = p.getString("${providerKey}_status", "Not connected") ?: "Not connected"
        return CloudProviderState(connected, account, lastTs, status, loadLocalCloudOutbox(context, providerKey))
    }

    fun saveConnectionState(
        context: Context, providerKey: String, connected: Boolean,
        accountLabel: String, statusMessage: String, rawToken: String? = null
    ) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        p.putBoolean("${providerKey}_connected", connected)
        p.putString("${providerKey}_account", accountLabel)
        p.putString("${providerKey}_status", statusMessage)
        if (rawToken != null) p.putString("${providerKey}_enc_token", encryptSecret(rawToken))
        else if (!connected) p.remove("${providerKey}_enc_token")
        p.apply()
    }

    fun disconnectProvider(context: Context, providerKey: String): CloudProviderState {
        saveConnectionState(context, providerKey, false, "", "Disconnected", null)
        return loadProviderState(context, providerKey)
    }

    fun computeChecksum(
        cards: List<BusinessCardEntity>,
        contacts: List<SavedContactEntity>,
        followUps: List<FollowUpEntity>
    ): String {
        val canonical = json.encodeToString(cards) + "|" + json.encodeToString(contacts) + "|" + json.encodeToString(followUps)
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyIntegrity(bundle: CloudSnapshotBundle): Boolean {
        if (bundle.schemaVersion > 5) return false
        if (bundle.checksumSha256.isBlank()) return true
        return computeChecksum(bundle.cards, bundle.contacts, bundle.followUps).equals(bundle.checksumSha256, ignoreCase = true)
    }

    suspend fun createCloudSnapshot(
        context: Context, providerKey: String,
        cards: List<BusinessCardEntity>, contacts: List<SavedContactEntity>, followUps: List<FollowUpEntity>
    ): Result<CloudSnapshotBundle> = withContext(Dispatchers.IO) {
        runCatching {
            val state = loadProviderState(context, providerKey)
            if (!state.isConnected) error("Please connect your account before running backup.")
            val bundle = CloudSnapshotBundle(
                schemaVersion = 5,
                createdAtTimestamp = System.currentTimeMillis(),
                provider = providerKey,
                checksumSha256 = computeChecksum(cards, contacts, followUps),
                cards = cards,
                contacts = contacts,
                followUps = followUps,
                themeConfig = ThemeContrastHelper.loadAppTheme(context),
                biometricLockEnabled = BiometricLockHelper.isLockEnabled(context)
            )
            val dir = File(context.filesDir, "cloud_snapshots/$providerKey").apply { mkdirs() }
            File(dir, "snapshot_${bundle.createdAtTimestamp}.json").writeText(json.encodeToString(bundle), Charsets.UTF_8)

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong("${providerKey}_last_ts", bundle.createdAtTimestamp)
                .putString("${providerKey}_status", "Snapshot saved (${cards.size} cards, ${contacts.size} contacts, ${followUps.size} follow-ups)")
                .apply()
            bundle
        }
    }

    suspend fun savePreReplaceRecoverySnapshot(
        context: Context, cards: List<BusinessCardEntity>, contacts: List<SavedContactEntity>, followUps: List<FollowUpEntity>
    ): File = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "recovery_snapshots").apply { mkdirs() }
        val file = File(dir, "pre_replace_${System.currentTimeMillis()}.json")
        val bundle = CloudSnapshotBundle(
            schemaVersion = 5, createdAtTimestamp = System.currentTimeMillis(), provider = "RECOVERY",
            checksumSha256 = computeChecksum(cards, contacts, followUps),
            cards = cards, contacts = contacts, followUps = followUps
        )
        file.writeText(json.encodeToString(bundle), Charsets.UTF_8)
        file
    }

    fun loadLocalCloudOutbox(context: Context, providerKey: String): List<CloudSnapshotBundle> {
        val dir = File(context.filesDir, "cloud_snapshots/$providerKey")
        if (!dir.exists()) return emptyList()
        return dir.listFiles { f -> f.isFile && f.extension == "json" }
            ?.sortedByDescending { it.lastModified() }
            ?.mapNotNull { file ->
                runCatching {
                    val b = json.decodeFromString<CloudSnapshotBundle>(file.readText(Charsets.UTF_8))
                    if (verifyIntegrity(b)) b else null
                }.getOrNull()
            } ?: emptyList()
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getEntry(KEYSTORE_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(KEYSTORE_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return kg.generateKey()
    }

    private fun encryptSecret(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val enc = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(1 + iv.size + enc.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(enc, 0, combined, 1 + iv.size, enc.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }
}
