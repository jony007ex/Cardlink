package com.cardlink.app.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.CloudBackupManager
import com.cardlink.app.util.CloudProviderState
import com.cardlink.app.util.CloudSnapshotBundle
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreSection(viewModel: CardLinkViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var replaceOnRestore by remember { mutableStateOf(false) }
    val dateStamp = remember { SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) }
    val fmtTime = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    var gdriveState by remember { mutableStateOf(CloudBackupManager.loadProviderState(context, "GOOGLE_DRIVE")) }
    var onedriveState by remember { mutableStateOf(CloudBackupManager.loadProviderState(context, "ONEDRIVE")) }
    var showConnectDialogFor by remember { mutableStateOf<String?>(null) }
    var pendingRestoreBundle by remember { mutableStateOf<Pair<CloudSnapshotBundle, Boolean>?>(null) }

    val exportJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) viewModel.exportFullJsonBackup(uri) { res -> res.onSuccess { Toast.makeText(context, "Exported $it items!", Toast.LENGTH_LONG).show() } }
    }
    val importJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importFullJsonBackup(uri, replaceOnRestore) { res ->
            res.onSuccess { Toast.makeText(context, "Restored ${it.profilesRestored} cards & ${it.contactsRestored} contacts!", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(context, "Restore failed: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
        }
    }
    val exportVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri: Uri? ->
        if (uri != null) viewModel.exportBatchVcf(uri) { res -> res.onSuccess { Toast.makeText(context, "Exported $it contacts!", Toast.LENGTH_LONG).show() } }
    }
    val exportCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) viewModel.exportContactsCsv(uri) { res -> res.onSuccess { Toast.makeText(context, "Exported $it contacts to CSV!", Toast.LENGTH_LONG).show() } }
    }
    val importVcfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importBatchVcf(uri) { res -> res.onSuccess { Toast.makeText(context, "Imported $it contacts!", Toast.LENGTH_LONG).show() } }
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Backup, null, tint = GoldAccent); Text("Local Backup & Export", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exportJsonLauncher.launch("CardLink_Backup_$dateStamp.json") }, modifier = Modifier.weight(1f)) { Text("Backup JSON") }
                    OutlinedButton(onClick = { importJsonLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Restore JSON") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Replace existing data on Restore (else Merge)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    Switch(checked = replaceOnRestore, onCheckedChange = { replaceOnRestore = it })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportVcfLauncher.launch("CardLink_Contacts_$dateStamp.vcf") }, modifier = Modifier.weight(1f)) { Text("Export .vcf") }
                    OutlinedButton(onClick = { importVcfLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Import .vcf") }
                }
                OutlinedButton(onClick = { exportCsvLauncher.launch("CardLink_Contacts_$dateStamp.csv") }, modifier = Modifier.fillMaxWidth()) { Text("Export Contacts to Excel (.csv)") }
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Cloud, null, tint = GoldAccent); Text("Cloud Backup & Restore (Drive & OneDrive)", fontWeight = FontWeight.Bold)
                }

                CloudProviderBlock(
                    "Google Drive", CloudBackupManager.isGoogleDriveOAuthConfigured(context),
                    "Requires Google Cloud OAuth Client ID (google_drive_web_client_id) for live remote Drive sync.",
                    gdriveState, fmtTime,
                    onConnectClick = { showConnectDialogFor = "GOOGLE_DRIVE" },
                    onDisconnectClick = { gdriveState = CloudBackupManager.disconnectProvider(context, "GOOGLE_DRIVE") },
                    onBackupNow = { scope.launch { viewModel.createCloudSnapshot(context, "GOOGLE_DRIVE").onSuccess { gdriveState = CloudBackupManager.loadProviderState(context, "GOOGLE_DRIVE"); Toast.makeText(context, "Google Drive snapshot saved", Toast.LENGTH_SHORT).show() } } },
                    onRestoreSnapshot = { pendingRestoreBundle = Pair(it, replaceOnRestore) }
                )

                HorizontalDivider()

                CloudProviderBlock(
                    "Microsoft OneDrive", CloudBackupManager.isOneDriveOAuthConfigured(context),
                    "Requires Microsoft Entra ID App Client ID (onedrive_client_id) for live remote OneDrive sync.",
                    onedriveState, fmtTime,
                    onConnectClick = { showConnectDialogFor = "ONEDRIVE" },
                    onDisconnectClick = { onedriveState = CloudBackupManager.disconnectProvider(context, "ONEDRIVE") },
                    onBackupNow = { scope.launch { viewModel.createCloudSnapshot(context, "ONEDRIVE").onSuccess { onedriveState = CloudBackupManager.loadProviderState(context, "ONEDRIVE"); Toast.makeText(context, "OneDrive snapshot saved", Toast.LENGTH_SHORT).show() } } },
                    onRestoreSnapshot = { pendingRestoreBundle = Pair(it, replaceOnRestore) }
                )
            }
        }
    }

    if (showConnectDialogFor != null) {
        val prov = showConnectDialogFor!!
        val labelName = if (prov == "GOOGLE_DRIVE") "Google Drive" else "Microsoft OneDrive"
        val configured = if (prov == "GOOGLE_DRIVE") CloudBackupManager.isGoogleDriveOAuthConfigured(context) else CloudBackupManager.isOneDriveOAuthConfigured(context)
        var accountEmail by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showConnectDialogFor = null },
            title = { Text("Connect $labelName", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!configured) Text("OAuth Client ID not configured yet; local encrypted staging snapshots will be used until OAuth credentials are added.", style = MaterialTheme.typography.bodySmall, color = GoldAccent)
                    OutlinedTextField(value = accountEmail, onValueChange = { accountEmail = it }, label = { Text("Account Email / Profile Label") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val acct = accountEmail.trim().ifBlank { "$labelName Account" }
                    CloudBackupManager.saveConnectionState(context, prov, true, acct, if (configured) "Connected (OAuth ready)" else "Connected (Local staging; OAuth ID pending)")
                    gdriveState = CloudBackupManager.loadProviderState(context, "GOOGLE_DRIVE")
                    onedriveState = CloudBackupManager.loadProviderState(context, "ONEDRIVE")
                    showConnectDialogFor = null
                }) { Text("Connect") }
            },
            dismissButton = { TextButton(onClick = { showConnectDialogFor = null }) { Text("Cancel") } }
        )
    }

    if (pendingRestoreBundle != null) {
        val (bundle, isReplace) = pendingRestoreBundle!!
        AlertDialog(
            onDismissRequest = { pendingRestoreBundle = null },
            title = { Text(if (isReplace) "Confirm Replace Restore" else "Confirm Merge Restore", fontWeight = FontWeight.Bold) },
            text = { Text(if (isReplace) "REPLACE current data with ${bundle.cards.size} cards, ${bundle.contacts.size} contacts, ${bundle.followUps.size} follow-ups? A recovery copy will be saved first." else "MERGE ${bundle.cards.size} cards, ${bundle.contacts.size} contacts, ${bundle.followUps.size} follow-ups?") },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        viewModel.restoreFromCloudSnapshot(context, bundle, isReplace)
                            .onSuccess { Toast.makeText(context, "Restore completed safely!", Toast.LENGTH_LONG).show() }
                            .onFailure { Toast.makeText(context, "Restore failed: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
                        pendingRestoreBundle = null
                    }
                }) { Text(if (isReplace) "Replace & Restore" else "Merge & Restore") }
            },
            dismissButton = { TextButton(onClick = { pendingRestoreBundle = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CloudProviderBlock(
    providerTitle: String, isOAuthConfigured: Boolean, setupNote: String, state: CloudProviderState, fmtTime: SimpleDateFormat,
    onConnectClick: () -> Unit, onDisconnectClick: () -> Unit, onBackupNow: () -> Unit, onRestoreSnapshot: (CloudSnapshotBundle) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(providerTitle, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(if (state.isConnected) "Account: ${state.accountLabel}" else "Status: Not connected", style = MaterialTheme.typography.bodySmall, color = if (state.isConnected) GoldAccent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            }
            if (!state.isConnected) Button(onClick = onConnectClick) { Text("Connect", fontSize = 12.sp) }
            else OutlinedButton(onClick = onDisconnectClick) { Text("Disconnect", fontSize = 12.sp) }
        }
        Text("Last backup: ${state.lastBackupTimestamp?.let { fmtTime.format(Date(it)) } ?: "Never"} • ${state.lastStatusMessage}", style = MaterialTheme.typography.labelSmall)
        if (!isOAuthConfigured) Text(setupNote, style = MaterialTheme.typography.labelSmall, color = GoldAccent)
        if (state.isConnected) Button(onClick = onBackupNow, modifier = Modifier.fillMaxWidth()) { Text("Backup Now") }
        state.availableSnapshots.take(3).forEach { snap ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("${fmtTime.format(Date(snap.createdAtTimestamp))} (${snap.contacts.size}c / ${snap.followUps.size}f)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { onRestoreSnapshot(snap) }) { Text("Restore") }
            }
        }
    }
}
