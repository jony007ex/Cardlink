package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.data.model.ShareHistoryEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.DashboardExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class TimeRange(val label: String, val days: Int?) {
    WEEK("This Week", 7), MONTH("This Month", 30), ALL("All Time", null)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    contacts: List<SavedContactEntity>,
    shareHistory: List<ShareHistoryEntity>,
    followUps: List<FollowUpEntity> = emptyList(),
    onExportLogged: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedRange by remember { mutableStateOf(TimeRange.WEEK) }
    val now = remember { System.currentTimeMillis() }
    val cutoff = selectedRange.days?.let { now - it * 24L * 3600_000L } ?: 0L

    val periodContacts = remember(contacts, cutoff) { contacts.filter { it.savedAtTimestamp >= cutoff } }
    val periodShares = remember(shareHistory, cutoff) { shareHistory.filter { it.timestamp >= cutoff } }
    val categoryOrder = listOf("Client", "Vendor", "VIP", "Colleague", "Event", "General")
    val categoryCounts = remember(contacts) { categoryOrder.map { cat -> cat to contacts.count { it.categoryTag.equals(cat, true) } } }
    val maxCategoryCount = (categoryCounts.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    val methodCounts = remember(periodShares) { periodShares.groupingBy { it.method }.eachCount().entries.sortedByDescending { it.value } }
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val hasAnyData = contacts.isNotEmpty() || periodShares.isNotEmpty() || followUps.isNotEmpty()

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Networking Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Your sharing & contact growth insights", style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.Analytics, null, tint = GoldAccent, modifier = Modifier.size(32.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeRange.entries.forEach { range ->
                FilterChip(selected = selectedRange == range, onClick = { selectedRange = range }, label = { Text(range.label) })
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Export & Share Report (${selectedRange.label})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (!hasAnyData) {
                    Text("No analytics data available yet to export.", style = MaterialTheme.typography.bodySmall)
                } else {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            DashboardExportHelper.exportAndSharePdf(context, selectedRange.label, periodContacts, contacts, periodShares, followUps)
                                .onSuccess { onExportLogged("Dashboard PDF Export"); Toast.makeText(context, "PDF report ready", Toast.LENGTH_SHORT).show() }
                        }, modifier = Modifier.weight(1f)) { Text("PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold) }

                        OutlinedButton(onClick = {
                            DashboardExportHelper.exportAndShareXlsx(context, selectedRange.label, periodContacts, contacts, periodShares, followUps)
                                .onSuccess { onExportLogged("Dashboard XLSX Export"); Toast.makeText(context, "Excel (.xlsx) ready", Toast.LENGTH_SHORT).show() }
                        }, modifier = Modifier.weight(1f)) { Text("Excel (.xlsx)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                        Button(onClick = {
                            DashboardExportHelper.exportAndSharePng(context, selectedRange.label, periodContacts, contacts, periodShares, followUps)
                                .onSuccess { onExportLogged("Dashboard PNG Export"); Toast.makeText(context, "PNG ready", Toast.LENGTH_SHORT).show() }
                        }, modifier = Modifier.weight(1f)) { Text("PNG", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiStatCard("Cards Shared", periodShares.size.toString(), selectedRange.label, Icons.Default.Share, Modifier.weight(1f))
            KpiStatCard("New Contacts", periodContacts.size.toString(), selectedRange.label, Icons.Default.PersonAdd, Modifier.weight(1f))
            KpiStatCard("Total Vault", contacts.size.toString(), "All Contacts", Icons.Default.Groups, Modifier.weight(1f))
        }

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Contacts by Category", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                categoryCounts.forEach { (category, count) ->
                    val fraction = (count.toFloat() / maxCategoryCount.toFloat()).coerceIn(0f, 1f)
                    val pct = if (contacts.isNotEmpty()) (count * 100 / contacts.size) else 0
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(category, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            Text("$count ($pct%)", fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
                        }
                        Box(modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))) {
                            Box(modifier = Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(if (count > 0) GoldAccent else Color.Transparent))
                        }
                    }
                }
            }
        }

        if (methodCounts.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sharing Channels (${selectedRange.label})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    methodCounts.forEach { (method, count) ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(method, fontSize = 14.sp)
                            Text("${count}×", color = GoldAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (shareHistory.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Recent Activity", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    shareHistory.take(8).forEach { event ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${event.method} • ${event.cardProfileTitle}", fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(dateFormat.format(Date(event.timestamp)), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiStatCard(title: String, value: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = NavyPrimary)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(title, color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp)
        }
    }
}
