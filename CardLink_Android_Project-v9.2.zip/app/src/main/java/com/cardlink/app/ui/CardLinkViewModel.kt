package com.cardlink.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardlink.app.data.local.CardLinkDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkGlanceWidget
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CardLinkViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CardLinkDatabase.getDatabase(application).dao()

    val myCards: StateFlow<List<BusinessCardEntity>> = dao.getAllMyCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeCard: StateFlow<BusinessCardEntity> = myCards.map { list ->
        val card = list.firstOrNull { it.isDefault } ?: list.firstOrNull() ?: defaultSeedCard()
        CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(card)
        CardLinkHceService.activeShareUrl = card.resolveNfcShareUrl()
        card
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), defaultSeedCard())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val contacts: StateFlow<List<SavedContactEntity>> = _searchQuery
        .flatMapLatest { q -> dao.searchContacts(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allContacts: StateFlow<List<SavedContactEntity>> = dao.getAllContactsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shareHistory: StateFlow<List<ShareHistoryEntity>> = dao.getShareHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val followUps: StateFlow<List<FollowUpEntity>> = dao.getAllFollowUpsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _appCustomTheme = MutableStateFlow(ThemeContrastHelper.loadAppTheme(application))
    val appCustomTheme: StateFlow<AppCustomThemeConfig> = _appCustomTheme

    private val _darkThemeOverride = MutableStateFlow<Boolean?>(null)
    val darkThemeOverride: StateFlow<Boolean?> = _darkThemeOverride

    private val _quickPrivacyMode = MutableStateFlow(false)
    val quickPrivacyMode: StateFlow<Boolean> = _quickPrivacyMode

    init {
        viewModelScope.launch {
            if (dao.getDefaultCardSnapshot() == null) dao.upsertMyCard(defaultSeedCard())
            FollowUpScheduler.rescheduleAllPending(getApplication())
        }
    }

    fun updateSearchQuery(q: String) { _searchQuery.value = q }

    fun saveCard(card: BusinessCardEntity) {
        viewModelScope.launch {
            var enriched = card
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val id = dao.upsertMyCard(enriched)
            if (enriched.isDefault) dao.setActiveCard(if (enriched.id == 0L) id else enriched.id)
            CardLinkHceService.activeShareUrl = enriched.resolveNfcShareUrl()
            CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(enriched)
            runCatching { CardLinkGlanceWidget().updateAll(getApplication()) }
        }
    }

    fun saveCardAndAppTheme(card: BusinessCardEntity, appTheme: AppCustomThemeConfig) {
        viewModelScope.launch {
            ThemeContrastHelper.saveAppTheme(getApplication(), appTheme)
            _appCustomTheme.value = appTheme
            saveCard(card)
        }
    }

    fun resetCardAndAppThemeToDefaults(): Pair<BusinessCardEntity, AppCustomThemeConfig> {
        val defApp = ThemeContrastHelper.resetAppTheme(getApplication())
        _appCustomTheme.value = defApp
        val defCard = activeCard.value.copy(
            template = CardTemplate.EXECUTIVE_NAVY, primaryColorHex = 0xFF0A192F, secondaryColorHex = 0xFF112240,
            accentColorHex = 0xFFD4AF37, textColorHex = 0xFFFFFFFF, buttonColorHex = 0xFFD4AF37,
            iconColorHex = 0xFFD4AF37, cardGradientEndHex = 0xFF172A46, fontFamilyName = "Serif"
        )
        saveCard(defCard)
        return Pair(defCard, defApp)
    }

    fun switchActiveProfile(cardId: Long) {
        viewModelScope.launch {
            dao.setActiveCard(cardId)
            runCatching { CardLinkGlanceWidget().updateAll(getApplication()) }
        }
    }

    fun saveReceivedContact(contact: SavedContactEntity, updatePendingWaNumberTo: String? = null) {
        viewModelScope.launch {
            var enriched = contact
            if (enriched.officeAddress.isNotBlank() && (enriched.latitude == null || enriched.longitude == null)) {
                GeoLocationHelper.geocodeAddress(getApplication(), enriched.officeAddress)?.let { (la, lo) ->
                    enriched = enriched.copy(latitude = la, longitude = lo)
                }
            }
            val savedId = dao.upsertContact(enriched)
            val targetId = if (enriched.id != 0L) enriched.id else savedId
            if (!updatePendingWaNumberTo.isNullOrBlank()) {
                dao.getPendingWhatsAppFollowUpsForContact(targetId).forEach { fu ->
                    val updatedFu = fu.copy(whatsappNumber = updatePendingWaNumberTo)
                    dao.upsertFollowUp(updatedFu)
                    FollowUpScheduler.scheduleForItem(getApplication(), updatedFu)
                }
            }
        }
    }

    fun deleteContact(contact: SavedContactEntity) {
        viewModelScope.launch { ScannedCardStorageHelper.deleteSavedCardImage(contact.profilePhotoUri); dao.deleteContact(contact) }
    }

    fun saveFollowUp(item: FollowUpEntity) {
        viewModelScope.launch {
            val id = dao.upsertFollowUp(item)
            FollowUpScheduler.scheduleForItem(getApplication(), item.copy(id = if (item.id == 0L) id else item.id))
        }
    }

    fun toggleFollowUpCompleted(item: FollowUpEntity) {
        viewModelScope.launch {
            val nextDone = !item.isCompleted
            val updated = item.copy(isCompleted = nextDone, status = if (nextDone) FollowUpStatus.COMPLETED.name else FollowUpStatus.PENDING.name)
            dao.upsertFollowUp(updated)
            if (nextDone) FollowUpScheduler.cancelForItem(getApplication(), updated.id) else FollowUpScheduler.scheduleForItem(getApplication(), updated)
        }
    }

    fun cancelFollowUp(item: FollowUpEntity) {
        viewModelScope.launch { FollowUpScheduler.cancelForItem(getApplication(), item.id); dao.upsertFollowUp(item.copy(status = FollowUpStatus.CANCELLED.name)) }
    }

    fun deleteFollowUp(item: FollowUpEntity) {
        viewModelScope.launch { FollowUpScheduler.cancelForItem(getApplication(), item.id); dao.deleteFollowUp(item) }
    }

    fun logShare(method: String, recipient: String = "External") {
        viewModelScope.launch { dao.logShareEvent(ShareHistoryEntity(cardProfileTitle = activeCard.value.profileTitle, method = method, recipientInfo = recipient)) }
    }

    fun toggleTheme(isDark: Boolean?) { _darkThemeOverride.value = isDark }
    fun toggleQuickPrivacyMode() { _quickPrivacyMode.value = !_quickPrivacyMode.value }

    fun exportFullJsonBackup(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportFullBackupToUri(getApplication(), uri, dao.getAllMyCardsSnapshot(), dao.getAllContactsSnapshot())) }
    }

    fun importFullJsonBackup(uri: Uri, replaceExisting: Boolean, onComplete: (Result<RestoreSummary>) -> Unit) {
        viewModelScope.launch {
            CardLinkBackupManager.importFullBackupFromUri(getApplication(), uri).onSuccess { (cards, cts) ->
                if (replaceExisting) {
                    CloudBackupManager.savePreReplaceRecoverySnapshot(getApplication(), dao.getAllMyCardsSnapshot(), dao.getAllContactsSnapshot(), dao.getAllFollowUpsSnapshot())
                    dao.clearAllMyCards(); dao.clearAllContacts()
                }
                if (cards.isNotEmpty()) dao.insertMyCardsBatch(cards)
                if (cts.isNotEmpty()) dao.insertContactsBatch(cts)
                onComplete(Result.success(RestoreSummary(cards.size, cts.size)))
            }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    suspend fun createCloudSnapshot(context: Context, providerKey: String): Result<CloudSnapshotBundle> =
        CloudBackupManager.createCloudSnapshot(context, providerKey, dao.getAllMyCardsSnapshot(), dao.getAllContactsSnapshot(), dao.getAllFollowUpsSnapshot())

    suspend fun restoreFromCloudSnapshot(context: Context, bundle: CloudSnapshotBundle, replaceExisting: Boolean): Result<Unit> = runCatching {
        if (!CloudBackupManager.verifyIntegrity(bundle)) error("Backup integrity check failed.")
        val existingFollowUps = dao.getAllFollowUpsSnapshot()
        existingFollowUps.forEach { FollowUpScheduler.cancelForItem(context, it.id) }
        if (replaceExisting) {
            CloudBackupManager.savePreReplaceRecoverySnapshot(context, dao.getAllMyCardsSnapshot(), dao.getAllContactsSnapshot(), existingFollowUps)
            dao.clearAllMyCards(); dao.clearAllContacts(); dao.clearAllFollowUps()
        }
        if (bundle.cards.isNotEmpty()) dao.insertMyCardsBatch(bundle.cards.map { it.copy(id = if (replaceExisting) it.id else 0L) })
        if (bundle.contacts.isNotEmpty()) dao.insertContactsBatch(bundle.contacts.map { it.copy(id = if (replaceExisting) it.id else 0L) })
        if (bundle.followUps.isNotEmpty()) {
            val deduped = bundle.followUps.filterNot { r -> !replaceExisting && existingFollowUps.any { ex -> ex.title == r.title && ex.dueAtTimestamp == r.dueAtTimestamp && ex.contactName == r.contactName } }.map { it.copy(id = 0L) }
            if (deduped.isNotEmpty()) dao.insertFollowUpsBatch(deduped)
        }
        ThemeContrastHelper.saveAppTheme(context, bundle.themeConfig); _appCustomTheme.value = bundle.themeConfig
        BiometricLockHelper.setLockEnabled(context, bundle.biometricLockEnabled)
        FollowUpScheduler.rescheduleAllPending(context)
    }

    fun exportContactsCsv(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportContactsToCsv(getApplication(), uri, dao.getAllContactsSnapshot())) }
    }
    fun exportBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch { onComplete(CardLinkBackupManager.exportContactsToBatchVcf(getApplication(), uri, dao.getAllContactsSnapshot())) }
    }
    fun importBatchVcf(uri: Uri, onComplete: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            CardLinkBackupManager.importContactsFromBatchVcf(getApplication(), uri).onSuccess { dao.insertContactsBatch(it); onComplete(Result.success(it.size)) }.onFailure { onComplete(Result.failure(it)) }
        }
    }

    private fun defaultSeedCard() = BusinessCardEntity(
        profileTitle = "Executive Profile", isDefault = true, fullName = "Md. Mazharul Islam",
        designation = "Head of Central Procurement", companyName = "Corporate Division", department = "Central Procurement",
        bio = "Driving strategic sourcing, agile procurement, and digital transformation.",
        phone = "+880 1700-000000", whatsapp = "+8801700000000", email = "contact@cardlink.app",
        officeAddress = "Motijheel C/A, Dhaka, Bangladesh", latitude = 23.7330, longitude = 90.4172,
        website = "https://cardlink.app", publicCardUrl = "https://drive.google.com/"
    )
}
