package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.AppCustomThemeConfig
import com.cardlink.app.util.ThemeContrastHelper

private val COLOR_SWATCHES = listOf(
    0xFF0A192FL, 0xFF112240L, 0xFF1E293BL, 0xFF064E3BL,
    0xFF3B0764L, 0xFF7F1D1DL, 0xFFD4AF37L, 0xFFFBBF24L,
    0xFF64FFDAL, 0xFF38BDF8L, 0xFFF8FAFCL, 0xFF0F172AL
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizeThemeScreen(
    activeCard: BusinessCardEntity,
    currentAppTheme: AppCustomThemeConfig,
    onSaveCardAndAppTheme: (BusinessCardEntity, AppCustomThemeConfig) -> Unit,
    onResetDefaults: () -> Pair<BusinessCardEntity, AppCustomThemeConfig>,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var modeTab by remember { mutableStateOf(0) }
    var cardDraft by remember(activeCard) { mutableStateOf(activeCard) }
    var appThemeDraft by remember(currentAppTheme) { mutableStateOf(currentAppTheme) }

    val cardPresets = listOf(
        Triple("Executive Navy & Gold", 0xFF0A192FL, 0xFFD4AF37L),
        Triple("Charcoal & Platinum", 0xFF1E293BL, 0xFFE2E8F0L),
        Triple("Royal Emerald & Gold", 0xFF064E3BL, 0xFFFBBF24L),
        Triple("Midnight Violet & Cyan", 0xFF3B0764L, 0xFF38BDF8L)
    )

    val cardContrastWarning = remember(cardDraft) {
        ThemeContrastHelper.lowContrastWarning(cardDraft.textColorHex, cardDraft.primaryColorHex, "Card Text")
            ?: ThemeContrastHelper.lowContrastWarning(cardDraft.accentColorHex, cardDraft.primaryColorHex, "Accent")
    }
    val appContrastWarning = remember(appThemeDraft) {
        ThemeContrastHelper.lowContrastWarning(appThemeDraft.textHex, appThemeDraft.backgroundHex, "App Text")
            ?: ThemeContrastHelper.lowContrastWarning(appThemeDraft.textHex, appThemeDraft.surfaceHex, "Surface Text")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Templates & Color Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            BusinessCardView(card = cardDraft)
            Text("Company logo appears strictly inside the QR code across all layouts.", style = MaterialTheme.typography.labelSmall, color = GoldAccent)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = modeTab == 0, onClick = { modeTab = 0 }, label = { Text("Card Layout & Colors") }, modifier = Modifier.weight(1f))
                FilterChip(selected = modeTab == 1, onClick = { modeTab = 1 }, label = { Text("App Theme Colors") }, modifier = Modifier.weight(1f))
            }

            if (modeTab == 0) {
                Text("Select Layout Template", fontWeight = FontWeight.Bold)
                val templates = listOf(
                    CardTemplate.EXECUTIVE_NAVY to "Executive",
                    CardTemplate.MINIMAL_IVORY to "Ivory",
                    CardTemplate.MODERN_SPLIT to "Split",
                    CardTemplate.MODERN_MINIMAL to "Modern Minimal",
                    CardTemplate.FUTURISTIC_PROFESSIONAL to "Futuristic Pro"
                )
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    templates.forEach { (tpl, label) ->
                        FilterChip(selected = cardDraft.template == tpl, onClick = { cardDraft = cardDraft.copy(template = tpl) }, label = { Text(label) })
                    }
                }

                Text("Preset Card Themes", fontWeight = FontWeight.Bold)
                cardPresets.forEach { (name, bg, acc) ->
                    OutlinedButton(onClick = {
                        cardDraft = cardDraft.copy(primaryColorHex = bg, secondaryColorHex = bg, cardGradientEndHex = bg, accentColorHex = acc, buttonColorHex = acc, iconColorHex = acc)
                    }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                }

                HexColorEditorRow("Card Background / Primary", cardDraft.primaryColorHex) { cardDraft = cardDraft.copy(primaryColorHex = it) }
                HexColorEditorRow("Card Secondary Color", cardDraft.secondaryColorHex) { cardDraft = cardDraft.copy(secondaryColorHex = it) }
                HexColorEditorRow("Card Gradient End", cardDraft.cardGradientEndHex) { cardDraft = cardDraft.copy(cardGradientEndHex = it) }
                HexColorEditorRow("Card Text Color", cardDraft.textColorHex) { cardDraft = cardDraft.copy(textColorHex = it) }
                HexColorEditorRow("Accent / Border Color", cardDraft.accentColorHex) { cardDraft = cardDraft.copy(accentColorHex = it, buttonColorHex = it) }
                HexColorEditorRow("Icon Color", cardDraft.iconColorHex) { cardDraft = cardDraft.copy(iconColorHex = it) }

                Text("Typography", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SansSerif", "Serif", "Monospace").forEach { font ->
                        FilterChip(selected = cardDraft.fontFamilyName == font, onClick = { cardDraft = cardDraft.copy(fontFamilyName = font) }, label = { Text(font) })
                    }
                }

                if (cardContrastWarning != null) ContrastWarningBanner(cardContrastWarning)
            } else {
                Text("App-Wide Theme Colors", fontWeight = FontWeight.Bold)
                HexColorEditorRow("App Primary", appThemeDraft.primaryHex) { appThemeDraft = appThemeDraft.copy(primaryHex = it) }
                HexColorEditorRow("App Secondary", appThemeDraft.secondaryHex) { appThemeDraft = appThemeDraft.copy(secondaryHex = it) }
                HexColorEditorRow("App Background", appThemeDraft.backgroundHex) { appThemeDraft = appThemeDraft.copy(backgroundHex = it) }
                HexColorEditorRow("App Surface", appThemeDraft.surfaceHex) { appThemeDraft = appThemeDraft.copy(surfaceHex = it) }
                HexColorEditorRow("App Text", appThemeDraft.textHex) { appThemeDraft = appThemeDraft.copy(textHex = it) }
                HexColorEditorRow("App Accent", appThemeDraft.accentHex) { appThemeDraft = appThemeDraft.copy(accentHex = it) }
                HexColorEditorRow("Button Color", appThemeDraft.buttonHex) { appThemeDraft = appThemeDraft.copy(buttonHex = it) }
                HexColorEditorRow("Icon Color", appThemeDraft.iconHex) { appThemeDraft = appThemeDraft.copy(iconHex = it) }
                if (appContrastWarning != null) ContrastWarningBanner(appContrastWarning)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    val (defCard, defApp) = onResetDefaults()
                    cardDraft = defCard; appThemeDraft = defApp
                    Toast.makeText(context, "Reset to default theme & template", Toast.LENGTH_SHORT).show()
                }, modifier = Modifier.weight(1f).height(50.dp)) { Text("Reset Default") }

                Button(onClick = {
                    onSaveCardAndAppTheme(cardDraft, appThemeDraft)
                    Toast.makeText(context, "Saved template & colors!", Toast.LENGTH_SHORT).show()
                    onNavigateBack()
                }, modifier = Modifier.weight(1f).height(50.dp)) { Text("Save Changes", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun HexColorEditorRow(label: String, currentHex: Long, onColorChanged: (Long) -> Unit) {
    var hexInput by remember(currentHex) { mutableStateOf(ThemeContrastHelper.formatHex(currentHex)) }
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(Color(currentHex.toInt())).border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), CircleShape))
            }
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                COLOR_SWATCHES.forEach { swatch ->
                    Box(
                        modifier = Modifier.size(26.dp).clip(CircleShape).background(Color(swatch.toInt()))
                            .border(if (swatch == currentHex) 2.5.dp else 1.dp, if (swatch == currentHex) GoldAccent else Color.Gray.copy(alpha = 0.5f), CircleShape)
                            .clickable { onColorChanged(swatch); hexInput = ThemeContrastHelper.formatHex(swatch) }
                    )
                }
            }
            OutlinedTextField(
                value = hexInput,
                onValueChange = { raw -> hexInput = raw; ThemeContrastHelper.parseHexColorOrNull(raw)?.let(onColorChanged) },
                label = { Text("HEX Color (e.g. #0A192F)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ContrastWarningBanner(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.WarningAmber, null, tint = MaterialTheme.colorScheme.error)
            Text(message, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
        }
    }
}
