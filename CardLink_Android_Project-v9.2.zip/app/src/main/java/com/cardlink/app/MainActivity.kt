package com.cardlink.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.nearby.BluetoothDiscoveryManager
import com.cardlink.app.nfc.CardLinkHceService
import com.cardlink.app.nfc.NfcReaderManager
import com.cardlink.app.nfc.NfcShareMode
import com.cardlink.app.tile.CardLinkTileService
import com.cardlink.app.ui.CardLinkViewModel
import com.cardlink.app.ui.components.BackupRestoreSection
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.components.FlippableBusinessCardView
import com.cardlink.app.ui.screens.*
import com.cardlink.app.ui.theme.*
import com.cardlink.app.util.*
import com.cardlink.app.widget.CardLinkGlanceWidget
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : FragmentActivity() {

    private val viewModel: CardLinkViewModel by viewModels()
    private lateinit var nfcReaderManager: NfcReaderManager
    private lateinit var bluetoothDiscoveryManager: BluetoothDiscoveryManager
    private var isAppUnlocked by mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FollowUpScheduler.ensureChannels(this)
        isAppUnlocked = !BiometricLockHelper.isLockEnabled(this)

        bluetoothDiscoveryManager = BluetoothDiscoveryManager(this)
        nfcReaderManager = NfcReaderManager(this) { vcfPayload ->
            val contact = CardShareHelper.parseVCardToContact(vcfPayload, "NFC Tap")
            viewModel.saveReceivedContact(contact, null)
            Toast.makeText(this, "Saved ${contact.fullName} via NFC!", Toast.LENGTH_LONG).show()
        }

        handleIncomingNfcIntent(intent)
        val initialRoute = if (intent?.action == NfcAdapter.ACTION_NDEF_DISCOVERED) {
            "contacts"
        } else {
            intent?.getStringExtra("open_route")
                ?: intent?.getStringExtra(CardLinkGlanceWidget.EXTRA_WIDGET_ROUTE)
                ?: "splash"
        }

        setContent {
            val darkOverride by viewModel.darkThemeOverride.collectAsState()
            val customAppTheme by viewModel.appCustomTheme.collectAsState()

            val keyguardLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
                if (res.resultCode == RESULT_OK) isAppUnlocked = true
            }

            fun triggerAuth() {
                BiometricLockHelper.showPrompt(
                    activity = this@MainActivity,
                    onSuccess = { isAppUnlocked = true },
                    onFallbackToDeviceCredential = {
                        BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity)?.let { keyguardLauncher.launch(it) }
                    },
                    onError = { msg -> Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
                )
            }

            CardLinkTheme(darkTheme = darkOverride ?: isSystemInDarkTheme(), customConfig = customAppTheme) {
                if (!isAppUnlocked) {
                    LaunchedEffect(Unit) { triggerAuth() }
                    Box(modifier = Modifier.fillMaxSize().background(Color(customAppTheme.backgroundHex.toInt())).padding(24.dp), contentAlignment = Alignment.Center) {
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(customAppTheme.surfaceHex.toInt()))) {
                            Column(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Icon(Icons.Default.Fingerprint, null, tint = Color(customAppTheme.iconHex.toInt()), modifier = Modifier.size(68.dp))
                                Text("Card Link Security Lock", color = Color(customAppTheme.textHex.toInt()), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("Unlock using Fingerprint, Face Unlock, or Device Screen Lock", color = Color(customAppTheme.textHex.toInt()).copy(alpha = 0.78f), fontSize = 13.sp)
                                Button(
                                    onClick = { triggerAuth() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(customAppTheme.buttonHex.toInt()), contentColor = NavyPrimary),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) { Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text("Unlock with Biometrics", fontWeight = FontWeight.Bold) }
                                val credIntent = remember { BiometricLockHelper.createDeviceCredentialIntent(this@MainActivity) }
                                if (credIntent != null) {
                                    OutlinedButton(onClick = { keyguardLauncher.launch(credIntent) }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Unlock with Device Lock", color = Color(customAppTheme.accentHex.toInt()))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    CardLinkAppScaffold(
                        viewModel = viewModel, nfcReaderManager = nfcReaderManager,
                        bluetoothDiscoveryManager = bluetoothDiscoveryManager, startRoute = initialRoute,
                        onLockNow = { isAppUnlocked = false }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIncomingNfcIntent(intent) }

    private fun handleIncomingNfcIntent(intent: Intent?) {
        if (intent?.action == NfcAdapter.ACTION_NDEF_DISCOVERED) {
            @Suppress("DEPRECATION")
            val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
            rawMsgs?.forEach { parcelable ->
                val ndefMsg = parcelable as? NdefMessage ?: return@forEach
                ndefMsg.records.forEach { record ->
                    val payloadText = String(record.payload, Charsets.UTF_8)
                    if (payloadText.contains("BEGIN:VCARD", ignoreCase = true)) {
                        val contact = CardShareHelper.parseVCardToContact(payloadText, "NFC vCard")
                        viewModel.saveReceivedContact(contact, null)
                        Toast.makeText(this, "Saved ${contact.fullName} via NFC vCard!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onPause() { super.onPause(); nfcReaderManager.disableReaderMode() }
    override fun onStop() { super.onStop(); if (BiometricLockHelper.isLockEnabled(this)) isAppUnlocked = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardLinkAppScaffold(
    viewModel: CardLinkViewModel,
    nfcReaderManager: NfcReaderManager,
    bluetoothDiscoveryManager: BluetoothDiscoveryManager,
    startRoute: String,
    onLockNow: () -> Unit = {}
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val activeCard by viewModel.activeCard.collectAsState()
    val myCards by viewModel.myCards.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val shareHistory by viewModel.shareHistory.collectAsState()
    val followUps by viewModel.followUps.collectAsState()
    val customAppTheme by viewModel.appCustomTheme.collectAsState()
    val scope = rememberCoroutineScope()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current

    val bottomNavRoutes = listOf("home", "contacts", "calendar", "analytics", "settings")

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomNavRoutes) {
                NavigationBar {
                    NavigationBarItem(selected = currentRoute == "home", onClick = { navController.navigate("home") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Badge, null) }, label = { Text("My Card") })
                    NavigationBarItem(selected = currentRoute == "contacts", onClick = { navController.navigate("contacts") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Contacts, null) }, label = { Text("Contacts") })
                    NavigationBarItem(selected = currentRoute == "calendar", onClick = { navController.navigate("calendar") { launchSingleTop = true } }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendar") })
                    NavigationBarItem(selected = currentRoute == "analytics", onClick = { navController.navigate("analytics") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Insights") })
                    NavigationBarItem(selected = currentRoute == "settings", onClick = { navController.navigate("settings") { launchSingleTop = true } }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        }
    ) { padding ->
        NavHost(navController = navController, startDestination = startRoute, modifier = Modifier.padding(padding)) {
            composable("splash") {
                val alphaAnim = remember { Animatable(0f) }
                val scaleAnim = remember { Animatable(0.94f) }

                LaunchedEffect(Unit) {
                    launch {
                        alphaAnim.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
                        )
                    }
                    launch {
                        scaleAnim.animateTo(
                            targetValue = 1f,
                            animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing)
                        )
                    }
                    delay(1450)
                    navController.navigate("home") {
                        popUpTo("splash") { inclusive = true }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0C1943))
                        .padding(horizontal = 36.dp, vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.cardlink_welcome_brand),
                        contentDescription = "CardLink — Connect Beyond Paper",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 360.dp)
                            .aspectRatio(1f)
                            .alpha(alphaAnim.value)
                            .scale(scaleAnim.value)
                    )
                }
            }

            composable("home") {
                val quickPrivacy by viewModel.quickPrivacyMode.collectAsState()
                val displayCard = remember(activeCard, quickPrivacy) {
                    if (quickPrivacy) activeCard.copy(sharePhone = false, shareAddress = false, shareEmail = false) else activeCard
                }
                val qrBitmap = remember(displayCard) { PremiumExtrasHelper.generateBrandedQrBitmap(context, displayCard, 480) }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column { Text("Card Link", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Active: ${activeCard.profileTitle}", style = MaterialTheme.typography.bodySmall) }
                        Row {
                            IconButton(onClick = { viewModel.toggleQuickPrivacyMode() }) { Icon(if (quickPrivacy) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Quick Privacy", tint = if (quickPrivacy) GoldAccent else LocalContentColor.current) }
                            IconButton(onClick = { navController.navigate("scan_ocr") }) { Icon(Icons.Default.DocumentScanner, "Scan Paper") }
                            IconButton(onClick = { navController.navigate("customize") }) { Icon(Icons.Default.Palette, "Customize") }
                            IconButton(onClick = { navController.navigate("edit_card") }) { Icon(Icons.Default.Edit, "Edit") }
                        }
                    }
                    if (myCards.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            myCards.forEach { profile -> FilterChip(selected = profile.id == activeCard.id, onClick = { viewModel.switchActiveProfile(profile.id) }, label = { Text(profile.profileTitle) }) }
                        }
                    }
                    FlippableBusinessCardView(card = displayCard)
                    Text(if (quickPrivacy) "Quick Privacy Mode ON • Tap card to flip" else "Tap card to flip 3D (Front & Branded QR Back)", style = MaterialTheme.typography.labelSmall, color = GoldAccent)
                    Button(onClick = { navController.navigate("share") }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Share My Card", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Instant Scan QR", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp))
                            Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(150.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                TextButton(onClick = { navController.navigate("qr_screen") }) { Text("Full QR") }
                                TextButton(onClick = { navController.navigate("scan_qr") }) { Text("Scan QR") }
                                TextButton(onClick = { navController.navigate("scan_ocr") }) { Text("Scan Paper") }
                            }
                        }
                    }
                }
            }

            composable("edit_card") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                val profilePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "profile")?.let { draft = draft.copy(profilePhotoUri = it) }
                }
                val companyLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) ScannedCardStorageHelper.saveProfileAssetLocally(context, uri, "logo")?.let { draft = draft.copy(companyLogoUri = it) }
                }
                val editLocPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    GeoLocationHelper.getCurrentGpsCoordinates(context)?.let { gps ->
                        draft = draft.copy(latitude = gps.first, longitude = gps.second)
                        scope.launch { if (draft.officeAddress.isBlank()) GeoLocationHelper.reverseGeocode(context, gps.first, gps.second)?.let { draft = draft.copy(officeAddress = it) } }
                        Toast.makeText(context, "Current GPS Pinned!", Toast.LENGTH_SHORT).show()
                    }
                }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Edit Business Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = draft)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { profilePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AccountCircle, null); Spacer(Modifier.width(6.dp)); Text("Upload Photo") }
                        OutlinedButton(onClick = { companyLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.QrCode2, null); Spacer(Modifier.width(6.dp)); Text("QR Logo") }
                    }
                    OutlinedTextField(value = draft.profileTitle, onValueChange = { draft = draft.copy(profileTitle = it) }, label = { Text("Profile Label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.fullName, onValueChange = { draft = draft.copy(fullName = it) }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.designation, onValueChange = { draft = draft.copy(designation = it) }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.companyName, onValueChange = { draft = draft.copy(companyName = it) }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.department, onValueChange = { draft = draft.copy(department = it) }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.publicCardUrl, onValueChange = { draft = draft.copy(publicCardUrl = it) }, label = { Text("NFC Public / Google Drive Card Link") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.phone, onValueChange = { draft = draft.copy(phone = it) }, label = { Text("Business Phone") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.whatsapp, onValueChange = { draft = draft.copy(whatsapp = it) }, label = { Text("WhatsApp Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.email, onValueChange = { draft = draft.copy(email = it) }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.officeAddress, onValueChange = { draft = draft.copy(officeAddress = it) }, label = { Text("Office Address") }, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { scope.launch { GeoLocationHelper.geocodeAddress(context, draft.officeAddress)?.let { draft = draft.copy(latitude = it.first, longitude = it.second); Toast.makeText(context, "Address Pinned!", Toast.LENGTH_SHORT).show() } } }, modifier = Modifier.weight(1f)) { Text("Auto-Pin Address", fontSize = 12.sp) }
                        OutlinedButton(onClick = { editLocPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }, modifier = Modifier.weight(1f)) { Text("Current GPS", fontSize = 12.sp) }
                    }
                    OutlinedTextField(value = draft.website, onValueChange = { draft = draft.copy(website = it) }, label = { Text("Company Website") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = draft.linkedInUrl, onValueChange = { draft = draft.copy(linkedInUrl = it) }, label = { Text("LinkedIn URL") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { viewModel.saveCard(draft.copy(id = 0, profileTitle = "New Profile", isDefault = true)); navController.popBackStack() }, modifier = Modifier.weight(1f)) { Text("Save as New") }
                        Button(onClick = { viewModel.saveCard(draft); navController.popBackStack() }, modifier = Modifier.weight(1f)) { Text("Save Changes") }
                    }
                }
            }

            composable("customize") {
                CustomizeThemeScreen(
                    activeCard = activeCard, currentAppTheme = customAppTheme,
                    onSaveCardAndAppTheme = { card, appCfg -> viewModel.saveCardAndAppTheme(card, appCfg) },
                    onResetDefaults = { viewModel.resetCardAndAppThemeToDefaults() },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("share") {
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Share My Card", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    BusinessCardView(card = activeCard)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("NFC Tap"); navController.navigate("nfc_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("NFC Tap") }
                        Button(onClick = { navController.navigate("nearby_share") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Bluetooth Search") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { viewModel.logShare("QR Code"); navController.navigate("qr_screen") }, modifier = Modifier.weight(1f).height(56.dp)) { Text("QR Code") }
                        Button(onClick = { viewModel.logShare("vCard (.vcf)"); CardShareHelper.shareVCardFile(context, activeCard) }, modifier = Modifier.weight(1f).height(56.dp)) { Text("Share via Apps") }
                    }
                    OutlinedButton(onClick = { viewModel.logShare("PNG Image"); CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as PNG Image") }
                    OutlinedButton(onClick = { viewModel.logShare("PDF Export"); CardShareHelper.shareCardAsPdf(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Export as PDF Document") }
                    OutlinedButton(onClick = { viewModel.logShare("WhatsApp / Text"); CardShareHelper.shareAsText(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share as Text / WhatsApp") }
                    HorizontalDivider(); Text("Premium Pro Tools", fontWeight = FontWeight.Bold, color = GoldAccent)
                    OutlinedButton(onClick = { viewModel.logShare("HTML Card"); PremiumExtrasHelper.shareClickableHtmlCard(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Export Clickable HTML Card (Google Drive)") }
                    OutlinedButton(onClick = { PremiumExtrasHelper.copyEmailSignatureToClipboard(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Copy Email Signature (Gmail / Outlook)") }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { val ok = PremiumExtrasHelper.applyLockScreenWallpaper(context, activeCard); Toast.makeText(context, if (ok) "Wallpaper applied!" else "Failed", Toast.LENGTH_LONG).show() }, modifier = Modifier.weight(1f)) { Text("Set Lock Wallpaper") }
                        OutlinedButton(onClick = { PremiumExtrasHelper.shareLockScreenWallpaper(context, activeCard) }, modifier = Modifier.weight(1f)) { Text("Share Wallpaper") }
                    }
                    Button(onClick = { navController.navigate("meeting_bg") }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Online Meeting Background (Zoom / Teams / Meet)") }
                }
            }

            composable("nfc_share") {
                var nfcShareMode by remember { mutableStateOf(CardLinkHceService.shareMode) }
                var isReceiveMode by remember { mutableStateOf(false) }
                var nfcLinkDraft by remember(activeCard) { mutableStateOf(activeCard.resolveNfcShareUrl()) }
                DisposableEffect(activeCard, nfcShareMode, nfcLinkDraft, isReceiveMode) {
                    CardLinkHceService.shareMode = nfcShareMode; CardLinkHceService.activeShareUrl = nfcLinkDraft; CardLinkHceService.activeVCardPayload = CardShareHelper.toVCardString(activeCard)
                    if (isReceiveMode) nfcReaderManager.enableReaderMode() else nfcReaderManager.disableReaderMode()
                    onDispose { nfcReaderManager.disableReaderMode() }
                }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Default.Contactless, null, tint = GoldAccent, modifier = Modifier.size(80.dp))
                    if (!nfcReaderManager.isNfcSupported()) Text("NFC is not supported on this phone.", fontWeight = FontWeight.Bold)
                    else if (!nfcReaderManager.isNfcEnabled()) { Text("NFC is disabled.", fontWeight = FontWeight.Bold); Button(onClick = { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Open NFC Settings") } }
                    else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = !isReceiveMode, onClick = { isReceiveMode = false }, label = { Text("Send My Card") })
                            FilterChip(selected = isReceiveMode, onClick = { isReceiveMode = true }, label = { Text("Receive Card") })
                        }
                        if (!isReceiveMode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = nfcShareMode == NfcShareMode.VCARD, onClick = { nfcShareMode = NfcShareMode.VCARD }, label = { Text("vCard") })
                                FilterChip(selected = nfcShareMode == NfcShareMode.LINK, onClick = { nfcShareMode = NfcShareMode.LINK }, label = { Text("Link") })
                            }
                            if (nfcShareMode == NfcShareMode.LINK) {
                                OutlinedTextField(value = nfcLinkDraft, onValueChange = { nfcLinkDraft = it }, label = { Text("NFC URL") }, modifier = Modifier.fillMaxWidth())
                                Button(onClick = { viewModel.saveCard(activeCard.copy(publicCardUrl = nfcLinkDraft)); Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show() }) { Text("Save NFC Link") }
                            }
                        }
                        BusinessCardView(card = activeCard)
                    }
                }
            }

            composable("nearby_share") {
                val pairedDevices by bluetoothDiscoveryManager.pairedDevices.collectAsState()
                val discoveredDevices by bluetoothDiscoveryManager.discoveredDevices.collectAsState()
                val isScanning by bluetoothDiscoveryManager.isScanning.collectAsState()
                val btPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { bluetoothDiscoveryManager.startDiscovery() }
                fun requestAndScan() {
                    val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) perms.addAll(listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE))
                    btPermLauncher.launch(perms.toTypedArray())
                }
                DisposableEffect(Unit) { requestAndScan(); onDispose { bluetoothDiscoveryManager.stopDiscovery() } }
                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Bluetooth Devices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Button(onClick = { if (!bluetoothDiscoveryManager.isBluetoothEnabled()) context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) else requestAndScan() }) { Text(if (isScanning) "Scanning..." else "Search") }
                    }
                    if (isScanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(discoveredDevices, key = { "d_${it.address}" }) { dev ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text(dev.address) }, trailingContent = {
                                    Button(onClick = { viewModel.logShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, activeCard) }) { Text("Send") }
                                })
                            }
                        }
                        items(pairedDevices, key = { "p_${it.address}" }) { dev ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                ListItem(headlineContent = { Text(dev.name, fontWeight = FontWeight.Bold) }, supportingContent = { Text("${dev.address} • Paired") }, trailingContent = {
                                    Button(onClick = { viewModel.logShare("Bluetooth", dev.name); CardShareHelper.sendVCardViaBluetooth(context, activeCard) }) { Text("Send") }
                                })
                            }
                        }
                    }
                }
            }

            composable("qr_screen") {
                val qr = remember(activeCard) { PremiumExtrasHelper.generateBrandedQrBitmap(context, activeCard, 750) }
                Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(activeCard.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp))
                    Image(bitmap = qr.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(260.dp)); Spacer(Modifier.height(20.dp))
                    Button(onClick = { CardShareHelper.shareCardAsPng(context, activeCard) }, modifier = Modifier.fillMaxWidth()) { Text("Share QR & Card Image") }
                }
            }

            composable("scan_qr") {
                var hasCam by remember { mutableStateOf(false) }
                var scannedRaw by remember { mutableStateOf<String?>(null) }
                var galleryCandidates by remember { mutableStateOf<List<String>>(emptyList()) }
                var scanErrorMessage by remember { mutableStateOf<String?>(null) }

                val camPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
                LaunchedEffect(Unit) { camPermLauncher.launch(Manifest.permission.CAMERA) }

                val galleryQrPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
                    if (uri != null) {
                        scanErrorMessage = null
                        scope.launch {
                            runCatching {
                                val bmp = ScannedCardStorageHelper.decodeGalleryUri(context, uri) ?: error("Could not read image.")
                                val values = BarcodeScanning.getClient().process(InputImage.fromBitmap(bmp, 0)).await().mapNotNull { it.rawValue?.trim() }.filter { it.isNotBlank() }.distinct()
                                when {
                                    values.isEmpty() -> scanErrorMessage = "No QR code found in the selected photo."
                                    values.size == 1 -> scannedRaw = values.first()
                                    else -> galleryCandidates = values
                                }
                            }.onFailure { scanErrorMessage = "Failed to decode QR: ${it.localizedMessage}" }
                        }
                    }
                }

                if (galleryCandidates.isNotEmpty() && scannedRaw == null) {
                    Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Multiple QR Codes Found", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = GoldAccent)
                        galleryCandidates.forEachIndexed { idx, candidate ->
                            Card(modifier = Modifier.fillMaxWidth().clickable { scannedRaw = candidate; galleryCandidates = emptyList() }) {
                                Column(modifier = Modifier.padding(14.dp)) { Text("QR #${idx + 1}", fontWeight = FontWeight.Bold, color = GoldAccent); Text(candidate, maxLines = 2, style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                        OutlinedButton(onClick = { galleryCandidates = emptyList() }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
                    }
                } else if (scannedRaw != null) {
                    val raw = scannedRaw!!
                    val isVCard = raw.contains("BEGIN:VCARD", true)
                    val isMeCard = raw.startsWith("MECARD:", true)
                    val isUrl = raw.startsWith("http://", true) || raw.startsWith("https://", true) || raw.startsWith("www.", true)
                    val parsedContact = remember(raw) {
                        when {
                            isVCard -> CardShareHelper.parseVCardToContact(raw, "QR Scan")
                            isMeCard -> CardShareHelper.parseMeCardToContact(raw, "QR Scan")
                            isUrl -> SavedContactEntity(fullName = "Scanned Web Card", website = raw, notes = "Scanned QR Link: $raw", receivedVia = "QR Link")
                            else -> SavedContactEntity(fullName = "Scanned QR Info", notes = raw, receivedVia = "QR Scan")
                        }
                    }
                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("QR Code Preview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = GoldAccent)
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (isVCard || isMeCard) {
                                    Text(parsedContact.fullName, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    if (parsedContact.designation.isNotBlank()) Text(parsedContact.designation, color = GoldAccent)
                                    if (parsedContact.companyName.isNotBlank()) Text(parsedContact.companyName)
                                    if (parsedContact.phone.isNotBlank()) Text("Phone: ${parsedContact.phone}")
                                    if (parsedContact.email.isNotBlank()) Text("Email: ${parsedContact.email}")
                                } else {
                                    Text(if (isUrl) "Link Detected (Confirm before opening)" else "QR Content", fontWeight = FontWeight.Bold)
                                    Text(raw, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                        if (isUrl || parsedContact.website.isNotBlank()) {
                            OutlinedButton(onClick = { ContactActionLauncher.launchExternalUrl(context, if (isUrl) raw else parsedContact.website) }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                                Icon(Icons.Default.OpenInBrowser, null); Spacer(Modifier.width(8.dp)); Text("Confirm & Open Link in Browser")
                            }
                        }
                        Button(onClick = { viewModel.saveReceivedContact(parsedContact, null); Toast.makeText(context, "Saved!", Toast.LENGTH_SHORT).show(); navController.navigate("contacts") { popUpTo("scan_qr") { inclusive = true } } }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                            Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Save to My Contacts")
                        }
                        OutlinedButton(onClick = { scannedRaw = null; scanErrorMessage = null }, modifier = Modifier.fillMaxWidth()) { Text("Scan Another QR") }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (hasCam) {
                            val lifecycleOwner = LocalLifecycleOwner.current
                            AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                                val pv = PreviewView(ctx)
                                ProcessCameraProvider.getInstance(ctx).also { fut ->
                                    fut.addListener({
                                        val prov = fut.get()
                                        val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                                        val scanner = BarcodeScanning.getClient()
                                        val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().apply {
                                            setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                                                @Suppress("UnsafeOptInUsageError")
                                                val img = proxy.image
                                                if (img != null && scannedRaw == null && galleryCandidates.isEmpty()) {
                                                    scanner.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                                                        .addOnSuccessListener { list -> list.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue?.let { scannedRaw = it } }
                                                        .addOnCompleteListener { proxy.close() }
                                                } else proxy.close()
                                            }
                                        }
                                        prov.unbindAll(); prov.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, prev, analysis)
                                    }, ContextCompat.getMainExecutor(ctx))
                                }
                                pv
                            })
                        } else {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Button(onClick = { camPermLauncher.launch(Manifest.permission.CAMERA) }) { Text("Grant Camera Permission") } }
                        }
                        Column(modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (scanErrorMessage != null) {
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Text(scanErrorMessage!!, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp)) }
                            }
                            Button(onClick = { galleryQrPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = NavyPrimary)) {
                                Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Scan from Gallery", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            composable("scan_ocr") {
                OcrCardScannerScreen(onContactSaved = { viewModel.saveReceivedContact(it, null); navController.navigate("contacts") { popUpTo("scan_ocr") { inclusive = true } } }, onNavigateBack = { navController.popBackStack() })
            }

            composable(CardLinkTileService.ROUTE_QUICK_SHARE) {
                QuickNfcQrShareScreen(activeCard = activeCard, nfcReaderManager = nfcReaderManager, onNavigateHome = { navController.navigate("home") })
            }

            composable("contacts") {
                var showDuplicateMergeDialog by remember { mutableStateOf(false) }
                var showPhoneImportSheet by remember { mutableStateOf(false) }
                val duplicatesMap = remember(contacts) {
                    val map = mutableMapOf<String, MutableList<SavedContactEntity>>()
                    contacts.forEach { c ->
                        val key = c.phone.filter { it.isDigit() }.takeLast(8).ifBlank { c.fullName.trim().lowercase() }
                        if (key.length >= 4) map.getOrPut(key) { mutableListOf() }.add(c)
                    }
                    map.values.filter { it.size > 1 }
                }
                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("My Contacts", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            if (duplicatesMap.isNotEmpty()) Text("${duplicatesMap.size} duplicate group(s) found", color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showPhoneImportSheet = true }) { Icon(Icons.Default.PersonSearch, "Import from Phone Contacts") }
                            if (duplicatesMap.isNotEmpty()) OutlinedButton(onClick = { showDuplicateMergeDialog = true }) { Text("Merge", fontSize = 12.sp) }
                            IconButton(onClick = { navController.navigate("scan_ocr") }) { Icon(Icons.Default.DocumentScanner, null) }
                            IconButton(onClick = { navController.navigate("scan_qr") }) { Icon(Icons.Default.QrCodeScanner, null) }
                        }
                    }

                    if (showPhoneImportSheet) {
                        PhoneContactsImportDialog(existingContacts = allContacts, onDismiss = { showPhoneImportSheet = false }) { contactToSave, existingDup, mode ->
                            when (mode) {
                                "SKIP" -> Unit
                                "MERGE" -> if (existingDup != null) {
                                    viewModel.saveReceivedContact(existingDup.copy(phone = existingDup.phone.ifBlank { contactToSave.phone }, whatsapp = existingDup.whatsapp.ifBlank { contactToSave.whatsapp }, email = existingDup.email.ifBlank { contactToSave.email }), null)
                                } else viewModel.saveReceivedContact(contactToSave, null)
                                else -> viewModel.saveReceivedContact(contactToSave, null)
                            }
                        }
                    }

                    if (showDuplicateMergeDialog && duplicatesMap.isNotEmpty()) {
                        AlertDialog(
                            onDismissRequest = { showDuplicateMergeDialog = false },
                            title = { Text("Merge Duplicate Contacts", fontWeight = FontWeight.Bold) },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    duplicatesMap.forEach { group ->
                                        val primary = group.first(); val dups = group.drop(1)
                                        Card(modifier = Modifier.fillMaxWidth()) {
                                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("Primary: ${primary.fullName}", fontWeight = FontWeight.Bold, color = GoldAccent)
                                                Button(onClick = {
                                                    val combinedNotes = (listOf(primary.notes) + dups.map { it.notes }).filter { it.isNotBlank() }.joinToString("\n---\n")
                                                    viewModel.saveReceivedContact(primary.copy(notes = combinedNotes), null)
                                                    dups.forEach { viewModel.deleteContact(it) }
                                                    showDuplicateMergeDialog = false
                                                }, modifier = Modifier.fillMaxWidth()) { Text("Merge Group") }
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = { TextButton(onClick = { showDuplicateMergeDialog = false }) { Text("Close") } }
                        )
                    }

                    var selectedFilterTag by remember { mutableStateOf("All") }
                    var myCurrentGps by remember { mutableStateOf(GeoLocationHelper.getCurrentGpsCoordinates(context)) }
                    val radarLocLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { myCurrentGps = GeoLocationHelper.getCurrentGpsCoordinates(context) }
                    val filterTags = listOf("All", "Nearby (<5 km)", "Client", "Vendor", "VIP", "Colleague", "Event", "General")
                    val filteredContacts = remember(contacts, selectedFilterTag, myCurrentGps) {
                        when (selectedFilterTag) {
                            "All" -> contacts
                            "Nearby (<5 km)" -> {
                                val u = myCurrentGps ?: (activeCard.latitude?.let { lat -> activeCard.longitude?.let { lng -> Pair(lat, lng) } })
                                if (u == null) contacts.filter { it.latitude != null && it.longitude != null }
                                else contacts.filter { c -> c.latitude != null && c.longitude != null && GeoLocationHelper.distanceInKm(u.first, u.second, c.latitude, c.longitude) <= 5.0 }
                            }
                            else -> contacts.filter { it.categoryTag.equals(selectedFilterTag, true) }
                        }
                    }

                    OutlinedTextField(value = searchQuery, onValueChange = viewModel::updateSearchQuery, placeholder = { Text("Search contacts...") }, modifier = Modifier.fillMaxWidth())
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        filterTags.forEach { tag ->
                            FilterChip(selected = selectedFilterTag == tag, onClick = {
                                selectedFilterTag = tag
                                if (tag == "Nearby (<5 km)") radarLocLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                            }, label = { Text(tag) })
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filteredContacts, key = { it.id }) { contact ->
                            Card(modifier = Modifier.fillMaxWidth().clickable { navController.navigate("contact_detail/${contact.id}") }) {
                                ListItem(
                                    leadingContent = {
                                        if (!contact.profilePhotoUri.isNullOrBlank()) AsyncImage(model = Uri.parse(contact.profilePhotoUri), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(56.dp, 36.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, GoldAccent, RoundedCornerShape(6.dp)))
                                        else Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = GoldAccent.copy(alpha = 0.2f)) { Box(contentAlignment = Alignment.Center) { Text(contact.fullName.take(2).uppercase(), color = GoldAccent, fontWeight = FontWeight.Bold) } }
                                    },
                                    headlineContent = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                                    supportingContent = { Text("${contact.designation} • ${contact.companyName}") },
                                    trailingContent = { AssistChip(onClick = {}, label = { Text(contact.receivedVia) }) }
                                )
                            }
                        }
                    }
                }
            }

            composable("contact_detail/{contactId}", arguments = listOf(navArgument("contactId") { type = NavType.LongType })) { entry ->
                val id = entry.arguments?.getLong("contactId") ?: 0L
                val contact = contacts.firstOrNull { it.id == id } ?: allContacts.firstOrNull { it.id == id }
                if (contact != null) {
                    ContactDetailScreen(
                        contact = contact, mySenderName = activeCard.fullName, mySenderCompany = activeCard.companyName,
                        contactFollowUps = remember(followUps, contact.id) { followUps.filter { it.contactId == contact.id } },
                        onSaveContact = { updated, newWa -> viewModel.saveReceivedContact(updated, newWa) },
                        onAddFollowUp = { viewModel.saveFollowUp(it) }, onToggleFollowUp = { viewModel.toggleFollowUpCompleted(it) },
                        onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                        onDeleteContact = { viewModel.deleteContact(contact); navController.popBackStack() },
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            composable("calendar") {
                FollowUpCalendarScreen(
                    followUps = followUps, contacts = allContacts,
                    onSaveFollowUp = { viewModel.saveFollowUp(it) }, onToggleCompleted = { viewModel.toggleFollowUpCompleted(it) },
                    onCancelFollowUp = { viewModel.cancelFollowUp(it) }, onDeleteFollowUp = { viewModel.deleteFollowUp(it) },
                    onOpenContact = { cId -> navController.navigate("contact_detail/$cId") }
                )
            }

            composable("analytics") {
                AnalyticsScreen(contacts = allContacts, shareHistory = shareHistory, followUps = followUps, onExportLogged = { viewModel.logShare(it) })
            }

            composable("meeting_bg") {
                MeetingBackgroundScreen(activeCard = activeCard, onExported = { viewModel.logShare("Meeting Background") }, onNavigateBack = { navController.popBackStack() })
            }

            composable("settings") {
                var draft by remember(activeCard) { mutableStateOf(activeCard) }
                var bioEnabled by remember { mutableStateOf(BiometricLockHelper.isLockEnabled(context)) }
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Settings & Privacy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Share Phone Number"); Switch(checked = draft.sharePhone, onCheckedChange = { draft = draft.copy(sharePhone = it); viewModel.saveCard(draft) }) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Share Email Address"); Switch(checked = draft.shareEmail, onCheckedChange = { draft = draft.copy(shareEmail = it); viewModel.saveCard(draft) }) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Share Office Address"); Switch(checked = draft.shareAddress, onCheckedChange = { draft = draft.copy(shareAddress = it); viewModel.saveCard(draft) }) }

                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) { Text("Biometric & Screen Lock", fontWeight = FontWeight.Bold); Text("Auto-locks when Card Link goes to background", style = MaterialTheme.typography.bodySmall) }
                                Switch(checked = bioEnabled, onCheckedChange = { enable -> bioEnabled = enable; BiometricLockHelper.setLockEnabled(context, enable) })
                            }
                            if (bioEnabled) OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(6.dp)); Text("Lock & Test Biometric Now") }
                        }
                    }

                    BackupRestoreSection(viewModel = viewModel)
                    OutlinedButton(onClick = { CardLinkTileService.requestAddTile(context) { Toast.makeText(context, it, Toast.LENGTH_LONG).show() } }, modifier = Modifier.fillMaxWidth()) { Text("Add Quick Settings Tile") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.toggleTheme(false) }, modifier = Modifier.weight(1f)) { Text("Light") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(true) }, modifier = Modifier.weight(1f)) { Text("Dark") }
                        OutlinedButton(onClick = { viewModel.toggleTheme(null) }, modifier = Modifier.weight(1f)) { Text("System") }
                    }

                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("About & Credits", fontWeight = FontWeight.Bold, color = GoldAccent)
                            Text("Concept & Development by", fontSize = 13.sp)
                            Text("Md. Mazharul Islam", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Email: jony007ex@gmail.com", color = GoldAccent, fontSize = 13.sp, modifier = Modifier.clickable {
                                runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:jony007ex@gmail.com")).apply { putExtra(Intent.EXTRA_EMAIL, arrayOf("jony007ex@gmail.com")) }) }
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneContactsImportDialog(
    existingContacts: List<SavedContactEntity>,
    onDismiss: () -> Unit,
    onImportContact: (SavedContactEntity, SavedContactEntity?, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var deviceContacts by remember { mutableStateOf<List<DevicePhoneContact>>(emptyList()) }
    var permissionDenied by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var primaryPhoneOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var whatsappOverride by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var showPreviewStep by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { permissionDenied = false; scope.launch { deviceContacts = PhoneContactsHelper.loadDeviceContacts(context) } }
        else permissionDenied = true
    }

    LaunchedEffect(Unit) {
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            deviceContacts = PhoneContactsHelper.loadDeviceContacts(context)
        } else permLauncher.launch(Manifest.permission.READ_CONTACTS)
    }

    val filtered = remember(deviceContacts, search) {
        deviceContacts.filter { search.isBlank() || it.displayName.contains(search, true) || it.phones.any { p -> p.contains(search, true) } }
    }
    val chosenList = remember(deviceContacts, selectedIds) { deviceContacts.filter { it.contactId in selectedIds } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (showPreviewStep) "Preview Import (${chosenList.size})" else "Import from Phone Contacts", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (permissionDenied) Text("Contacts permission denied. Use manual contact entry instead.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (!showPreviewStep) {
                    OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search phone contacts...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    filtered.take(30).forEach { dc ->
                        val isSel = dc.contactId in selectedIds
                        Card(modifier = Modifier.fillMaxWidth().clickable { selectedIds = if (isSel) selectedIds - dc.contactId else selectedIds + dc.contactId }) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = isSel, onCheckedChange = { selectedIds = if (it) selectedIds + dc.contactId else selectedIds - dc.contactId })
                                Column { Text(dc.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(dc.phones.firstOrNull().orEmpty(), style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                } else {
                    chosenList.forEach { dc ->
                        val chosenPhone = primaryPhoneOverride[dc.contactId] ?: dc.phones.firstOrNull().orEmpty()
                        val chosenEmail = dc.emails.firstOrNull().orEmpty()
                        val waVal = whatsappOverride[dc.contactId].orEmpty()
                        val dup = remember(dc, chosenPhone, chosenEmail, existingContacts) { PhoneContactsHelper.findDuplicateContact(existingContacts, dc.displayName, chosenPhone, chosenEmail) }
                        var dupAction by remember(dc.contactId) { mutableStateOf(if (dup != null) "MERGE" else "IMPORT") }
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(dc.displayName, fontWeight = FontWeight.Bold, color = GoldAccent)
                                if (dc.phones.size > 1) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        dc.phones.forEach { p -> FilterChip(selected = chosenPhone == p, onClick = { primaryPhoneOverride = primaryPhoneOverride + (dc.contactId to p) }, label = { Text(p, fontSize = 11.sp) }) }
                                    }
                                }
                                OutlinedTextField(value = waVal, onValueChange = { whatsappOverride = whatsappOverride + (dc.contactId to it) }, label = { Text("WhatsApp (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                if (dup != null) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("SKIP" to "Skip", "MERGE" to "Merge", "IMPORT" to "Separate").forEach { (k, l) -> FilterChip(selected = dupAction == k, onClick = { dupAction = k }, label = { Text(l, fontSize = 11.sp) }) }
                                    }
                                }
                                Button(onClick = {
                                    val entity = SavedContactEntity(
                                        fullName = dc.displayName, designation = dc.jobTitle, companyName = dc.organization,
                                        phone = if (chosenPhone.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(chosenPhone) else "",
                                        whatsapp = if (waVal.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(waVal) else "",
                                        email = chosenEmail, receivedVia = "Phone Contacts"
                                    )
                                    onImportContact(entity, dup, dupAction)
                                    selectedIds = selectedIds - dc.contactId
                                }, modifier = Modifier.fillMaxWidth()) { Text("Apply (${dupAction.lowercase()})") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!permissionDenied && selectedIds.isNotEmpty() && !showPreviewStep) Button(onClick = { showPreviewStep = true }) { Text("Preview (${selectedIds.size})") }
            else TextButton(onClick = onDismiss) { Text("Close") }
        },
        dismissButton = { if (showPreviewStep) TextButton(onClick = { showPreviewStep = false }) { Text("Back") } }
    )
}
