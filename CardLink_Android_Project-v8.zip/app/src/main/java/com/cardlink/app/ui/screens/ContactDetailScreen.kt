package com.cardlink.app.ui.screens

import android.Manifest
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cardlink.app.data.model.FollowUpEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.ui.theme.NavyPrimary
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(
    contact: SavedContactEntity,
    mySenderName: String,
    mySenderCompany: String = "",
    contactFollowUps: List<FollowUpEntity> = emptyList(),
    onSaveContact: (SavedContactEntity) -> Unit,
    onAddFollowUp: (FollowUpEntity) -> Unit = {},
    onToggleFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteFollowUp: (FollowUpEntity) -> Unit = {},
    onDeleteContact: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var notes by remember(contact) { mutableStateOf(contact.notes) }
    var selectedTag by remember(contact) { mutableStateOf(contact.categoryTag) }
    var currentLat by remember(contact) { mutableStateOf(contact.latitude) }
    var currentLng by remember(contact) { mutableStateOf(contact.longitude) }
    var userGps by remember { mutableStateOf<Pair<Double, Double>?>(null) }

    var showTemplateSheetFor by remember { mutableStateOf<String?>(null) } // "WA" or "EMAIL"
    var newActionTitle by remember { mutableStateOf("") }

    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val whatsAppTarget = contact.whatsapp.ifBlank { contact.phone }
    val tagOptions = listOf("General", "Client", "Vendor", "VIP", "Colleague", "Event")
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    val locPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
    }

    LaunchedEffect(contact.officeAddress) {
        userGps = GeoLocationHelper.getCurrentGpsCoordinates(context)
        if ((currentLat == null || currentLng == null) && contact.officeAddress.isNotBlank()) {
            val resolved = GeoLocationHelper.geocodeAddress(context, contact.officeAddress)
            if (resolved != null) {
                currentLat = resolved.first
                currentLng = resolved.second
                onSaveContact(contact.copy(latitude = resolved.first, longitude = resolved.second))
            }
        }
    }

    val distanceKm = remember(userGps, currentLat, currentLng) {
        val u = userGps
        val cLat = currentLat
        val cLng = currentLng
        if (u != null && cLat != null && cLng != null) {
            GeoLocationHelper.distanceInKm(u.first, u.second, cLat, cLng)
        } else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(contact.fullName, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { CardShareHelper.exportToAndroidContacts(context, contact) }) {
                        Icon(Icons.Default.PersonAdd, null)
                    }
                    IconButton(onClick = onDeleteContact) {
                        Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!contact.profilePhotoUri.isNullOrBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.586f)
                        .border(1.5.dp, GoldAccent, RoundedCornerShape(14.dp)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    AsyncImage(
                        model = Uri.parse(contact.profilePhotoUri),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Text("${contact.designation} • ${contact.companyName}", color = GoldAccent, fontWeight = FontWeight.SemiBold)

            // Contact Category Tag Selector
            Text("Category Tag", style = MaterialTheme.typography.labelMedium)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tagOptions.forEach { tag ->
                    FilterChip(
                        selected = selectedTag == tag,
                        onClick = {
                            selectedTag = tag
                            onSaveContact(contact.copy(categoryTag = tag, notes = notes, latitude = currentLat, longitude = currentLng))
                        },
                        label = { Text(tag) }
                    )
                }
            }

            // Direct Communication Bar
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ContactActionLauncher.launchDialer(context, primaryPhone) }, modifier = Modifier.weight(1f)) { Text("Call") }
                Button(onClick = { ContactActionLauncher.launchWhatsAppChat(context, whatsAppTarget, contact.fullName) }, modifier = Modifier.weight(1f)) { Text("WA") }
                Button(onClick = { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) }, modifier = Modifier.weight(1f)) { Text("Email") }
                Button(onClick = { ContactActionLauncher.launchGoogleMaps(context, contact.officeAddress, contact.companyName, currentLat, currentLng) }, modifier = Modifier.weight(1f)) { Text("Map") }
            }

            // ONE-TAP MESSAGE & EMAIL TEMPLATES
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.AutoAwesome, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                        Text("One-Tap Smart Follow-Up Templates", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showTemplateSheetFor = "WA" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Chat, null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("WA Templates", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { showTemplateSheetFor = "EMAIL" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.MarkEmailRead, null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Email Templates", fontSize = 12.sp)
                        }
                    }
                }
            }

            // GEO-LOCATION & OFFICE NAVIGATION CARD
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.LocationOn, null, tint = GoldAccent)
                            Text("Office Geo-Location & GPS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        if (distanceKm != null) {
                            Surface(shape = RoundedCornerShape(8.dp), color = GoldAccent.copy(alpha = 0.2f)) {
                                Text(
                                    text = "$distanceKm km away",
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    if (contact.officeAddress.isNotBlank()) {
                        Text(contact.officeAddress, style = MaterialTheme.typography.bodySmall)
                    }
                    if (currentLat != null && currentLng != null) {
                        Text(
                            text = "GPS Pin: ${GeoLocationHelper.formatCoordinates(currentLat, currentLng)}",
                            color = GoldAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        Text("No GPS coordinates pinned yet.", style = MaterialTheme.typography.bodySmall)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                ContactActionLauncher.launchTurnByTurnNavigation(context, currentLat, currentLng, contact.officeAddress)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Navigation, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Directions", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                scope.launch {
                                    val resolved = if (contact.officeAddress.isNotBlank()) {
                                        GeoLocationHelper.geocodeAddress(context, contact.officeAddress)
                                    } else null
                                    val coords = resolved ?: GeoLocationHelper.getCurrentGpsCoordinates(context)
                                    if (coords != null) {
                                        currentLat = coords.first
                                        currentLng = coords.second
                                        onSaveContact(contact.copy(latitude = coords.first, longitude = coords.second))
                                        Toast.makeText(context, "GPS Coordinates Pinned!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Could not resolve GPS coordinates", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Detect GPS Pin", fontSize = 12.sp)
                        }
                    }
                }
            }

            // IN-APP FOLLOW-UP CALENDAR & ACTION CHECKLIST
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.CalendarMonth, null, tint = GoldAccent)
                        Text("In-App Follow-Up Calendar & Tasks", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    // Quick 1-Tap Reminder Chips
                    Text("Quick Schedule Follow-Up:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "+24 Hours" to 24,
                            "+3 Days" to 72,
                            "Next Week" to 168
                        ).forEach { (label, hrs) ->
                            AssistChip(
                                onClick = {
                                    onAddFollowUp(
                                        FollowUpEntity(
                                            contactId = contact.id,
                                            contactName = contact.fullName,
                                            companyName = contact.companyName,
                                            title = "Follow up with ${contact.fullName}",
                                            notes = notes,
                                            dueAtTimestamp = System.currentTimeMillis() + hrs * 3600L * 1000L
                                        )
                                    )
                                    Toast.makeText(context, "Scheduled in Follow-Up Calendar ($label)!", Toast.LENGTH_SHORT).show()
                                },
                                label = { Text(label) },
                                leadingIcon = { Icon(Icons.Default.AddAlert, null, modifier = Modifier.size(15.dp)) }
                            )
                        }
                    }

                    // Add Custom Action Item / Meeting Checklist
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newActionTitle,
                            onValueChange = { newActionTitle = it },
                            label = { Text("Add meeting task / action item") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = {
                            if (newActionTitle.isNotBlank()) {
                                onAddFollowUp(
                                    FollowUpEntity(
                                        contactId = contact.id,
                                        contactName = contact.fullName,
                                        companyName = contact.companyName,
                                        title = newActionTitle.trim(),
                                        dueAtTimestamp = System.currentTimeMillis() + 24L * 3600L * 1000L
                                    )
                                )
                                newActionTitle = ""
                            }
                        }) { Text("Add") }
                    }

                    contactFollowUps.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(checked = item.isCompleted, onCheckedChange = { onToggleFollowUp(item) })
                                Column {
                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.sp,
                                        textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                    )
                                    Text(dateFmt.format(Date(item.dueAtTimestamp)), fontSize = 11.sp, color = GoldAccent)
                                }
                            }
                            IconButton(onClick = { onDeleteFollowUp(item) }) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { PremiumExtrasHelper.scheduleFollowUpMeeting(context, contact.copy(notes = notes)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Event, null, tint = GoldAccent)
                        Spacer(Modifier.width(8.dp))
                        Text("Sync to External Google Calendar")
                    }
                }
            }

            if (contact.phone.isNotBlank()) ListItem(headlineContent = { Text(contact.phone) }, overlineContent = { Text("Phone") }, modifier = Modifier.clickable { ContactActionLauncher.launchDialer(context, contact.phone) })
            if (contact.whatsapp.isNotBlank()) ListItem(headlineContent = { Text(contact.whatsapp) }, overlineContent = { Text("WhatsApp") }, modifier = Modifier.clickable { ContactActionLauncher.launchWhatsAppChat(context, contact.whatsapp, contact.fullName) })
            if (contact.email.isNotBlank()) ListItem(headlineContent = { Text(contact.email) }, overlineContent = { Text("Email") }, modifier = Modifier.clickable { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) })
            if (contact.website.isNotBlank()) ListItem(headlineContent = { Text(contact.website) }, overlineContent = { Text("Website / Link") }, modifier = Modifier.clickable { ContactActionLauncher.launchExternalUrl(context, contact.website) })

            val speechRecognizerLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == android.app.Activity.RESULT_OK) {
                    val spokenText = result.data?.getStringArrayListExtra(
                        android.speech.RecognizerIntent.EXTRA_RESULTS
                    )?.firstOrNull()
                    if (!spokenText.isNullOrBlank()) {
                        val timestampTag = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                        notes = if (notes.isBlank()) "[$timestampTag (Voice Note)] $spokenText" else "$notes
[$timestampTag (Voice Note)] $spokenText"
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Private Contact Notes & Voice Dictation") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                trailingIcon = {
                    IconButton(onClick = {
                        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak meeting notes or follow-up summary...")
                        }
                        runCatching {
                            speechRecognizerLauncher.launch(intent)
                        }.onFailure {
                            Toast.makeText(context, "Speech recognition not supported on this device", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice Dictation", tint = GoldAccent)
                    }
                }
            )

            Button(
                onClick = {
                    onSaveContact(contact.copy(notes = notes, categoryTag = selectedTag, latitude = currentLat, longitude = currentLng))
                    Toast.makeText(context, "Contact updated!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save Notes & Tag") }
        }
    }

    if (showTemplateSheetFor != null) {
        val mode = showTemplateSheetFor!!
        AlertDialog(
            onDismissRequest = { showTemplateSheetFor = null },
            title = {
                Text(
                    if (mode == "WA") "Select WhatsApp Follow-Up Template" else "Select Email Follow-Up Template",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MessageTemplateHelper.defaultTemplates.forEach { tmpl ->
                        val previewBody = tmpl.buildBody(contact, mySenderName, mySenderCompany)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (mode == "WA") {
                                        ContactActionLauncher.launchWhatsAppChat(
                                            context = context,
                                            rawNumber = whatsAppTarget,
                                            recipientName = contact.fullName,
                                            customMessage = previewBody
                                        )
                                    } else {
                                        ContactActionLauncher.launchEmailComposer(
                                            context = context,
                                            emailAddress = contact.email,
                                            recipientName = contact.fullName,
                                            senderName = mySenderName,
                                            customSubject = tmpl.buildSubject(contact, mySenderName, mySenderCompany),
                                            customBody = previewBody
                                        )
                                    }
                                    showTemplateSheetFor = null
                                },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(tmpl.title, fontWeight = FontWeight.Bold, color = GoldAccent, fontSize = 13.sp)
                                Text(previewBody, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplateSheetFor = null }) { Text("Close") }
            }
        )
    }
}
