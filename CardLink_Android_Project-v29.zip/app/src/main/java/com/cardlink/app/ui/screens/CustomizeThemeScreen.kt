package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.CardTemplate
import com.cardlink.app.ui.components.BusinessCardView
import com.cardlink.app.ui.theme.GoldAccent
import com.cardlink.app.util.ThemeContrastHelper

private val CARD_COLOR_SWATCHES = listOf(
    0xFF0A192FL, 0xFF112240L, 0xFF1E293BL, 0xFF064E3BL,
    0xFF3B0764L, 0xFF7F1D1DL, 0xFFD4AF37L, 0xFFFBBF24L,
    0xFF64FFDAL, 0xFF38BDF8L, 0xFFF8FAFCL, 0xFF0F172AL
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizeThemeScreen(
    activeCard: BusinessCardEntity,
    onSaveCardTheme: (BusinessCardEntity) -> Unit,
    onResetCardDefaults: () -> BusinessCardEntity,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var cardDraft by remember(activeCard) { mutableStateOf(activeCard) }

    val cardPresets = listOf(
        Triple("Executive Navy & Gold", 0xFF0A192FL, 0xFFD4AF37L),
        Triple("Charcoal & Platinum", 0xFF1E293BL, 0xFFE2E8F0L),
        Triple("Royal Emerald & Gold", 0xFF064E3BL, 0xFFFBBF24L),
        Triple("Midnight Violet & Cyan", 0xFF3B0764L, 0xFF38BDF8L)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.customize_card_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.customize_card_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BusinessCardView(card = cardDraft)

            Text(stringResource(R.string.customize_card_layout), fontWeight = FontWeight.Bold, color = GoldAccent)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CardTemplate.values().forEach { tpl ->
                    FilterChip(
                        selected = cardDraft.template == tpl,
                        onClick = { cardDraft = cardDraft.copy(template = tpl) },
                        label = { Text(tpl.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Text(stringResource(R.string.customize_card_presets), fontWeight = FontWeight.Bold, color = GoldAccent)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                cardPresets.forEach { (name, prim, acc) ->
                    AssistChip(
                        onClick = {
                            cardDraft = cardDraft.copy(
                                primaryColorHex = prim,
                                secondaryColorHex = prim,
                                cardGradientEndHex = prim,
                                accentColorHex = acc,
                                buttonColorHex = acc,
                                iconColorHex = acc
                            )
                        },
                        label = { Text(name, fontSize = 12.sp) }
                    )
                }
            }

            CardColorPickerRow("Card Background", cardDraft.primaryColorHex) {
                cardDraft = cardDraft.copy(primaryColorHex = it)
            }
            CardColorPickerRow("Gradient End", cardDraft.cardGradientEndHex) {
                cardDraft = cardDraft.copy(cardGradientEndHex = it)
            }
            CardColorPickerRow("Accent & Border", cardDraft.accentColorHex) {
                cardDraft = cardDraft.copy(accentColorHex = it, buttonColorHex = it, iconColorHex = it)
            }

            val contrastWarn = ThemeContrastHelper.lowContrastWarning(cardDraft.accentColorHex, cardDraft.primaryColorHex, "Card accent")
            if (contrastWarn != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF59E0B).copy(alpha = 0.14f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WarningAmber, null, tint = Color(0xFFF59E0B))
                        Text(contrastWarn, style = MaterialTheme.typography.labelSmall, color = Color(0xFFF59E0B))
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        cardDraft = onResetCardDefaults()
                        Toast.makeText(context, "Card design reset to default.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f).height(50.dp)
                ) { Text("Reset Card") }

                Button(
                    onClick = {
                        onSaveCardTheme(cardDraft)
                        Toast.makeText(context, "Card template & colors saved!", Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color(0xFF0A192F)),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) { Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CardColorPickerRow(
    label: String,
    currentHex: Long,
    onColorSelected: (Long) -> Unit
) {
    var hexInput by remember(currentHex) { mutableStateOf(ThemeContrastHelper.formatHex(currentHex)) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            OutlinedTextField(
                value = hexInput,
                onValueChange = { txt ->
                    hexInput = txt.take(7)
                    ThemeContrastHelper.parseHexColorOrNull(txt)?.let { onColorSelected(it) }
                },
                singleLine = true,
                modifier = Modifier.width(120.dp)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CARD_COLOR_SWATCHES.forEach { sw ->
                val isSel = sw == currentHex
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(sw.toInt()))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) GoldAccent else Color.Gray, CircleShape)
                        .clickable { onColorSelected(sw) }
                )
            }
        }
    }
}
