package com.cardlink.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.cardlink.app.util.AppCustomThemeConfig

val NavyPrimary = Color(0xFF0A192F)
val NavySurface = Color(0xFF112240)
val CharcoalDark = Color(0xFF1E293B)
val GoldAccent = Color(0xFFD4AF37)
val OffWhite = Color(0xFFF8FAFC)

fun resolveColorScheme(
    config: AppCustomThemeConfig?,
    darkTheme: Boolean
): ColorScheme {
    if (config == null) {
        return if (darkTheme) {
            darkColorScheme(
                primary = GoldAccent,
                onPrimary = NavyPrimary,
                secondary = Color(0xFF64FFDA),
                background = NavyPrimary,
                surface = NavySurface,
                onBackground = OffWhite,
                onSurface = OffWhite
            )
        } else {
            lightColorScheme(
                primary = NavyPrimary,
                onPrimary = Color.White,
                secondary = GoldAccent,
                background = OffWhite,
                surface = Color.White,
                onBackground = NavyPrimary,
                onSurface = CharcoalDark
            )
        }
    }

    return if (darkTheme) {
        darkColorScheme(
            primary = Color(config.buttonHex.toInt()),
            onPrimary = Color(config.onPrimaryHex.toInt()),
            secondary = Color(config.secondaryHex.toInt()),
            onSecondary = Color(config.onSecondaryHex.toInt()),
            background = Color(config.backgroundHex.toInt()),
            onBackground = Color(config.textHex.toInt()),
            surface = Color(config.surfaceHex.toInt()),
            onSurface = Color(config.textHex.toInt()),
            surfaceVariant = Color(config.surfaceVariantHex.toInt()),
            outline = Color(config.outlineHex.toInt()),
            error = Color(config.errorHex.toInt()),
            onError = Color(config.onErrorHex.toInt())
        )
    } else {
        lightColorScheme(
            primary = Color(config.lightPrimaryHex.toInt()),
            onPrimary = Color(config.lightOnPrimaryHex.toInt()),
            secondary = Color(config.lightSecondaryHex.toInt()),
            onSecondary = Color(config.lightOnSecondaryHex.toInt()),
            background = Color(config.lightBackgroundHex.toInt()),
            onBackground = Color(config.lightTextHex.toInt()),
            surface = Color(config.lightSurfaceHex.toInt()),
            onSurface = Color(config.lightTextHex.toInt()),
            surfaceVariant = Color(config.lightSurfaceVariantHex.toInt()),
            outline = Color(config.lightOutlineHex.toInt()),
            error = Color(config.errorHex.toInt()),
            onError = Color(config.onErrorHex.toInt())
        )
    }
}

@Composable
fun CardLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    customConfig: AppCustomThemeConfig? = null,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val scheme = if (customConfig?.useDeviceColors == true && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        resolveColorScheme(customConfig, darkTheme)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
