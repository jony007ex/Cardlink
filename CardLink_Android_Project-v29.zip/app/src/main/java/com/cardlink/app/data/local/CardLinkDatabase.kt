package com.cardlink.app.data.local

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cardlink.app.data.model.*
import com.cardlink.app.util.VaultCryptoManager
import kotlinx.coroutines.flow.Flow

@Dao
interface CardLinkDao {
    @Query("SELECT * FROM my_cards ORDER BY isDefault DESC, id ASC")
    fun getAllMyCards(): Flow<List<BusinessCardEntity>>

    @Query("SELECT * FROM my_cards ORDER BY id ASC")
    suspend fun getAllMyCardsSnapshot(): List<BusinessCardEntity>

    @Query("SELECT * FROM my_cards WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultCardSnapshot(): BusinessCardEntity?

    @Upsert
    suspend fun upsertMyCard(card: BusinessCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMyCardsBatch(cards: List<BusinessCardEntity>)

    @Query("UPDATE my_cards SET isDefault = CASE WHEN id = :cardId THEN 1 ELSE 0 END")
    suspend fun setActiveCard(cardId: Long)

    @Delete
    suspend fun deleteMyCard(card: BusinessCardEntity)

    @Query("DELETE FROM my_cards")
    suspend fun clearAllMyCards()

    @Query("""
        SELECT * FROM saved_contacts
        WHERE fullName LIKE '%' || :query || '%'
           OR companyName LIKE '%' || :query || '%'
           OR designation LIKE '%' || :query || '%'
           OR phone LIKE '%' || :query || '%'
           OR whatsapp LIKE '%' || :query || '%'
           OR notes LIKE '%' || :query || '%'
        ORDER BY savedAtTimestamp DESC
    """)
    fun searchContacts(query: String): Flow<List<SavedContactEntity>>

    @Query("SELECT * FROM saved_contacts ORDER BY savedAtTimestamp DESC")
    fun getAllContactsFlow(): Flow<List<SavedContactEntity>>

    @Query("SELECT * FROM saved_contacts ORDER BY savedAtTimestamp DESC")
    suspend fun getAllContactsSnapshot(): List<SavedContactEntity>

    @Upsert
    suspend fun upsertContact(contact: SavedContactEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContactsBatch(contacts: List<SavedContactEntity>)

    @Delete
    suspend fun deleteContact(contact: SavedContactEntity)

    @Query("DELETE FROM saved_contacts")
    suspend fun clearAllContacts()

    @Insert
    suspend fun logShareEvent(event: ShareHistoryEntity)

    @Query("SELECT * FROM share_history ORDER BY timestamp DESC LIMIT 500")
    fun getShareHistory(): Flow<List<ShareHistoryEntity>>

    @Query("SELECT * FROM follow_up_items ORDER BY isCompleted ASC, dueAtTimestamp ASC")
    fun getAllFollowUpsFlow(): Flow<List<FollowUpEntity>>

    @Query("SELECT * FROM follow_up_items ORDER BY dueAtTimestamp ASC")
    suspend fun getAllFollowUpsSnapshot(): List<FollowUpEntity>

    @Query("SELECT * FROM follow_up_items WHERE id = :id LIMIT 1")
    suspend fun getFollowUpById(id: Long): FollowUpEntity?

    @Query("SELECT * FROM follow_up_items WHERE contactId = :contactId ORDER BY isCompleted ASC, dueAtTimestamp ASC")
    fun getFollowUpsForContactFlow(contactId: Long): Flow<List<FollowUpEntity>>

    @Query("SELECT * FROM follow_up_items WHERE contactId = :contactId AND channel = 'WHATSAPP' AND isCompleted = 0 AND status != 'CANCELLED'")
    suspend fun getPendingWhatsAppFollowUpsForContact(contactId: Long): List<FollowUpEntity>

    @Upsert
    suspend fun upsertFollowUp(item: FollowUpEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollowUpsBatch(items: List<FollowUpEntity>)

    @Delete
    suspend fun deleteFollowUp(item: FollowUpEntity)

    @Query("DELETE FROM follow_up_items")
    suspend fun clearAllFollowUps()

    // Loyalty Card Wallet DAO
    @Query("SELECT * FROM loyalty_cards ORDER BY createdAtTimestamp DESC")
    fun getAllLoyaltyCardsFlow(): Flow<List<LoyaltyCardEntity>>

    @Query("SELECT * FROM loyalty_cards ORDER BY createdAtTimestamp DESC")
    suspend fun getAllLoyaltyCardsSnapshot(): List<LoyaltyCardEntity>

    @Query("SELECT * FROM loyalty_cards WHERE id = :id LIMIT 1")
    suspend fun getLoyaltyCardById(id: Long): LoyaltyCardEntity?

    @Upsert
    suspend fun upsertLoyaltyCard(card: LoyaltyCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoyaltyCardsBatch(cards: List<LoyaltyCardEntity>)

    @Delete
    suspend fun deleteLoyaltyCard(card: LoyaltyCardEntity)

    @Query("DELETE FROM loyalty_cards")
    suspend fun clearAllLoyaltyCards()

    // My IDs Wallet DAO (Scalable Document + Pages)
    @Query("SELECT * FROM my_id_documents ORDER BY updatedAtTimestamp DESC")
    fun getAllIdDocumentsFlow(): Flow<List<IdDocumentEntity>>

    @Query("SELECT * FROM my_id_documents ORDER BY updatedAtTimestamp DESC")
    suspend fun getAllIdDocumentsSnapshot(): List<IdDocumentEntity>

    @Query("SELECT * FROM my_id_documents WHERE stableUuid = :uuid LIMIT 1")
    suspend fun getIdDocumentByUuid(uuid: String): IdDocumentEntity?

    @Upsert
    suspend fun upsertIdDocument(doc: IdDocumentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdDocumentsBatch(docs: List<IdDocumentEntity>)

    @Delete
    suspend fun deleteIdDocument(doc: IdDocumentEntity)

    @Query("DELETE FROM my_id_documents")
    suspend fun clearAllIdDocuments()

    @Query("SELECT * FROM my_id_pages ORDER BY documentUuid ASC, pageIndex ASC")
    fun getAllIdPagesFlow(): Flow<List<IdDocumentPageEntity>>

    @Query("SELECT * FROM my_id_pages ORDER BY documentUuid ASC, pageIndex ASC")
    suspend fun getAllIdPagesSnapshot(): List<IdDocumentPageEntity>

    @Query("SELECT * FROM my_id_pages WHERE documentUuid = :docUuid ORDER BY pageIndex ASC")
    suspend fun getPagesForDocumentSnapshot(docUuid: String): List<IdDocumentPageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdPagesBatch(pages: List<IdDocumentPageEntity>)

    @Query("DELETE FROM my_id_pages WHERE documentUuid = :docUuid")
    suspend fun deletePagesForDocument(docUuid: String)

    @Query("DELETE FROM my_id_pages")
    suspend fun clearAllIdPages()

    // QR Code Studio DAO
    @Query("SELECT * FROM qr_studio_projects ORDER BY isFavorite DESC, updatedAtTimestamp DESC")
    fun getAllQrProjectsFlow(): Flow<List<QrProjectEntity>>

    @Query("SELECT * FROM qr_studio_projects ORDER BY updatedAtTimestamp DESC")
    suspend fun getAllQrProjectsSnapshot(): List<QrProjectEntity>

    @Upsert
    suspend fun upsertQrProject(project: QrProjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQrProjectsBatch(projects: List<QrProjectEntity>)

    @Delete
    suspend fun deleteQrProject(project: QrProjectEntity)

    @Query("DELETE FROM qr_studio_projects")
    suspend fun clearAllQrProjects()

    @Query("SELECT * FROM qr_design_presets ORDER BY createdAtTimestamp DESC")
    fun getAllQrDesignPresetsFlow(): Flow<List<QrDesignPresetEntity>>

    @Query("SELECT * FROM qr_design_presets ORDER BY createdAtTimestamp DESC")
    suspend fun getAllQrDesignPresetsSnapshot(): List<QrDesignPresetEntity>

    @Upsert
    suspend fun upsertQrDesignPreset(preset: QrDesignPresetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQrDesignPresetsBatch(presets: List<QrDesignPresetEntity>)

    @Delete
    suspend fun deleteQrDesignPreset(preset: QrDesignPresetEntity)

    @Query("DELETE FROM qr_design_presets")
    suspend fun clearAllQrDesignPresets()

    // Universal QR Scan History DAO
    @Query("SELECT * FROM qr_scan_history ORDER BY isFavorite DESC, scannedAtTimestamp DESC")
    fun getAllQrScanHistoryFlow(): Flow<List<QrScanHistoryEntity>>

    @Query("SELECT * FROM qr_scan_history WHERE payloadHash = :hash LIMIT 1")
    suspend fun getQrScanHistoryByHash(hash: String): QrScanHistoryEntity?

    @Upsert
    suspend fun upsertQrScanHistory(entry: QrScanHistoryEntity): Long

    @Delete
    suspend fun deleteQrScanHistory(entry: QrScanHistoryEntity)

    @Query("DELETE FROM qr_scan_history")
    suspend fun clearAllQrScanHistory()

    // Local Security Audit Log DAO (Encrypted in SQLCipher)
    @Query("SELECT * FROM security_audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getSecurityAuditLogsFlow(): Flow<List<SecurityAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSecurityAuditLog(entry: SecurityAuditLogEntity)

    @Query("DELETE FROM security_audit_logs WHERE timestamp < :cutoffTs")
    suspend fun pruneSecurityAuditLogsBefore(cutoffTs: Long)

    @Query("DELETE FROM security_audit_logs")
    suspend fun clearAllSecurityAuditLogs()

    // Secure Notes / Memo Vault DAO (Encrypted in SQLCipher)
    @Query("SELECT * FROM secure_notes ORDER BY isPinned DESC, updatedAtTimestamp DESC")
    fun getAllSecureNotesFlow(): Flow<List<SecureNoteEntity>>

    @Query("SELECT * FROM secure_notes ORDER BY updatedAtTimestamp DESC")
    suspend fun getAllSecureNotesSnapshot(): List<SecureNoteEntity>

    @Upsert
    suspend fun upsertSecureNote(note: SecureNoteEntity): Long

    @Delete
    suspend fun deleteSecureNote(note: SecureNoteEntity)

    @Query("DELETE FROM secure_notes")
    suspend fun clearAllSecureNotes()
}

@Database(
    entities = [
        BusinessCardEntity::class,
        SavedContactEntity::class,
        ShareHistoryEntity::class,
        FollowUpEntity::class,
        LoyaltyCardEntity::class,
        IdDocumentEntity::class,
        IdDocumentPageEntity::class,
        QrProjectEntity::class,
        QrDesignPresetEntity::class,
        QrScanHistoryEntity::class,
        SecurityAuditLogEntity::class,
        SecureNoteEntity::class
    ],
    version = 12,
    exportSchema = false
)
abstract class CardLinkDatabase : RoomDatabase() {
    abstract fun dao(): CardLinkDao

    companion object {
        @Volatile
        private var INSTANCE: CardLinkDatabase? = null

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE my_cards ADD COLUMN secondaryColorHex INTEGER NOT NULL DEFAULT ${0xFF112240}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN buttonColorHex INTEGER NOT NULL DEFAULT ${0xFFD4AF37}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN iconColorHex INTEGER NOT NULL DEFAULT ${0xFFD4AF37}")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN cardGradientEndHex INTEGER NOT NULL DEFAULT ${0xFF172A46}")

                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN alarmEnabled INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN notificationEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN reminderOffsetMinutes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN channel TEXT NOT NULL DEFAULT 'GENERAL'")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappNumber TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappMessage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN whatsappMode TEXT NOT NULL DEFAULT 'REMINDER_TO_SEND'")
                db.execSQL("ALTER TABLE follow_up_items ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE saved_contacts ADD COLUMN backPhotoUri TEXT")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS loyalty_cards (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        brandName TEXT NOT NULL,
                        cardNickname TEXT NOT NULL,
                        cardNumber TEXT NOT NULL,
                        cardholderName TEXT NOT NULL,
                        notes TEXT NOT NULL,
                        barcodeValue TEXT NOT NULL,
                        barcodeFormat TEXT NOT NULL,
                        qrPayload TEXT NOT NULL,
                        frontPhotoUri TEXT,
                        backPhotoUri TEXT,
                        createdAtTimestamp INTEGER NOT NULL,
                        updatedAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS my_id_documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        documentName TEXT NOT NULL,
                        documentType TEXT NOT NULL,
                        customTypeName TEXT NOT NULL,
                        extractedText TEXT NOT NULL,
                        notes TEXT NOT NULL,
                        expiryDateIso TEXT,
                        expiryRemindersEnabled INTEGER NOT NULL DEFAULT 1,
                        createdAtTimestamp INTEGER NOT NULL,
                        updatedAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS my_id_pages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        documentUuid TEXT NOT NULL,
                        pageIndex INTEGER NOT NULL,
                        pageLabel TEXT NOT NULL,
                        imageUri TEXT NOT NULL,
                        mimeType TEXT NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS qr_studio_projects (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        name TEXT NOT NULL,
                        qrType TEXT NOT NULL,
                        payload TEXT NOT NULL,
                        contentFieldsJson TEXT NOT NULL,
                        designConfigJson TEXT NOT NULL,
                        logoUri TEXT,
                        isFavorite INTEGER NOT NULL DEFAULT 0,
                        expiryReminderIso TEXT,
                        isDynamic INTEGER NOT NULL DEFAULT 0,
                        createdAtTimestamp INTEGER NOT NULL,
                        updatedAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS qr_design_presets (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        name TEXT NOT NULL,
                        designConfigJson TEXT NOT NULL,
                        createdAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS qr_scan_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        detectedType TEXT NOT NULL,
                        displayTitle TEXT NOT NULL,
                        rawPayload TEXT NOT NULL,
                        payloadHash TEXT NOT NULL,
                        isSensitive INTEGER NOT NULL DEFAULT 0,
                        isFavorite INTEGER NOT NULL DEFAULT 0,
                        scannedAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS security_audit_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        eventType TEXT NOT NULL,
                        featureTag TEXT NOT NULL,
                        success INTEGER NOT NULL DEFAULT 1,
                        safeDetail TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS secure_notes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        stableUuid TEXT NOT NULL,
                        title TEXT NOT NULL,
                        category TEXT NOT NULL,
                        content TEXT NOT NULL,
                        isPinned INTEGER NOT NULL DEFAULT 0,
                        createdAtTimestamp INTEGER NOT NULL,
                        updatedAtTimestamp INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE my_cards ADD COLUMN backHeading TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE my_cards ADD COLUMN backMessage TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context): CardLinkDatabase {
            return INSTANCE ?: synchronized(this) {
                val appCtx = context.applicationContext
                val encryptedFactory = VaultCryptoManager.prepareEncryptedFactory(appCtx, "cardlink.db")

                val builder = Room.databaseBuilder(
                    appCtx,
                    CardLinkDatabase::class.java,
                    "cardlink.db"
                )
                    .addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12)

                if (encryptedFactory != null) {
                    builder.openHelperFactory(encryptedFactory)
                }

                val instance = builder.build()
                INSTANCE = instance
                instance
            }
        }
    }
}
