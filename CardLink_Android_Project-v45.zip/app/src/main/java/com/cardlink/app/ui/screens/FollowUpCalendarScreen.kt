package com.cardlink.app.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.util.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class CalendarTimeFilter(val labelRes: Int) {
    UPCOMING(R.string.calendar_filter_upcoming),
    TODAY(R.string.calendar_filter_today),
    TOMORROW(R.string.calendar_filter_tomorrow),
    THIS_WEEK(R.string.calendar_filter_week)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FollowUpCalendarScreen(
    followUps: List<FollowUpEntity>,
    contacts: List<SavedContactEntity>,
    mySenderName: String = "",
    onSaveFollowUp: (FollowUpEntity) -> Unit,
    onToggleCompleted: (FollowUpEntity) -> Unit,
    onCancelFollowUp: (FollowUpEntity) -> Unit,
    onDeleteFollowUp: (FollowUpEntity) -> Unit,
    onOpenContact: (Long) -> Unit,
    onOpenSettings: () -> Unit = {},
    openCreateOnLaunch: Boolean = false
) {
    val context = LocalContext.current
    var timeFilter by remember { mutableStateOf(CalendarTimeFilter.UPCOMING) }
    var statusFilter by remember { mutableStateOf("ACTIVE") } // ACTIVE, OVERDUE, COMPLETED
    var typeFilter by remember { mutableStateOf("ALL") } // ALL, MEETING, CALL, WHATSAPP, EMAIL, SEND_DOCUMENT, GENERAL
    var showAdvancedFilterSheet by remember { mutableStateOf(false) }

    var editingItem by remember { mutableStateOf<FollowUpEntity?>(null) }
    var showEditorDialog by remember { mutableStateOf(openCreateOnLaunch) }
    var showNotifDisabledDialog by remember { mutableStateOf(false) }
    var moreSheetTarget by remember { mutableStateOf<FollowUpEntity?>(null) }
    var snoozeTarget by remember { mutableStateOf<FollowUpEntity?>(null) }
    var emailInviteTarget by remember { mutableStateOf<FollowUpEntity?>(null) }

    val now = System.currentTimeMillis()
    val todayStart = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val tomorrowStart = todayStart + 24L * 3600_000L
    val dayAfterTomorrowStart = tomorrowStart + 24L * 3600_000L
    val weekEnd = todayStart + 7L * 24L * 3600_000L
    val weekStart = todayStart - 7L * 24L * 3600_000L

    val activeItems = remember(followUps) {
        followUps.filter { !it.isCompleted && it.status != FollowUpStatus.CANCELLED.name }
    }
    val todayCount = remember(activeItems) { activeItems.count { it.dueAtTimestamp in todayStart until tomorrowStart } }
    val completedThisWeekCount = remember(followUps) {
        followUps.count { it.isCompleted && it.dueAtTimestamp >= weekStart }
    }

    val filteredList = remember(followUps, timeFilter, statusFilter, typeFilter, now) {
        val byStatus = when (statusFilter) {
            "OVERDUE" -> activeItems.filter { it.dueAtTimestamp < now }
            "COMPLETED" -> followUps.filter { it.isCompleted || it.status == FollowUpStatus.CANCELLED.name }
            else -> activeItems
        }
        val byTime = if (statusFilter == "COMPLETED" || statusFilter == "OVERDUE") {
            byStatus
        } else {
            when (timeFilter) {
                CalendarTimeFilter.UPCOMING -> byStatus
                CalendarTimeFilter.TODAY -> byStatus.filter { it.dueAtTimestamp in todayStart until tomorrowStart }
                CalendarTimeFilter.TOMORROW -> byStatus.filter { it.dueAtTimestamp in tomorrowStart until dayAfterTomorrowStart }
                CalendarTimeFilter.THIS_WEEK -> byStatus.filter { it.dueAtTimestamp in todayStart..weekEnd }
            }
        }
        if (typeFilter == "ALL") byTime else byTime.filter { it.followUpType.equals(typeFilter, true) }
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM • hh:mm a", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editingItem = null; showEditorDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.AddAlert, null) },
                text = { Text(stringResource(R.string.calendar_new_followup), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.calendar_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.calendar_subtitle), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showAdvancedFilterSheet = true }) {
                    Icon(
                        Icons.Default.Tune,
                        contentDescription = "Calendar Filters",
                        tint = if (statusFilter != "ACTIVE" || typeFilter != "ALL") MaterialTheme.colorScheme.primary else LocalContentColor.current
                    )
                }
            }

            // Always-Labeled Compact Summary Cards (Tappable to filter!)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CalendarSummaryCard(
                    title = stringResource(R.string.calendar_filter_upcoming),
                    count = activeItems.size,
                    subLabel = "Follow-Ups",
                    isSelected = statusFilter == "ACTIVE" && timeFilter == CalendarTimeFilter.UPCOMING,
                    onClick = { statusFilter = "ACTIVE"; timeFilter = CalendarTimeFilter.UPCOMING },
                    modifier = Modifier.weight(1f)
                )
                CalendarSummaryCard(
                    title = stringResource(R.string.calendar_filter_today),
                    count = todayCount,
                    subLabel = stringResource(R.string.calendar_due_today),
                    isSelected = statusFilter == "ACTIVE" && timeFilter == CalendarTimeFilter.TODAY,
                    onClick = { statusFilter = "ACTIVE"; timeFilter = CalendarTimeFilter.TODAY },
                    modifier = Modifier.weight(1f)
                )
                CalendarSummaryCard(
                    title = stringResource(R.string.calendar_completed),
                    count = completedThisWeekCount,
                    subLabel = stringResource(R.string.calendar_filter_week),
                    isSelected = statusFilter == "COMPLETED",
                    onClick = { statusFilter = "COMPLETED" },
                    modifier = Modifier.weight(1f)
                )
            }

            // 4 Clean Primary Time Filters
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CalendarTimeFilter.values().forEach { f ->
                    val isSel = statusFilter == "ACTIVE" && timeFilter == f
                    Surface(
                        onClick = { statusFilter = "ACTIVE"; timeFilter = f },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (isSel) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f).heightIn(min = 36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
                            Text(
                                text = stringResource(f.labelRes),
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (filteredList.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.EventAvailable, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                        Text(
                            text = if (statusFilter == "COMPLETED") stringResource(R.string.calendar_completed) else stringResource(timeFilter.labelRes),
                            fontWeight = FontWeight.Bold
                        )
                        Text(stringResource(R.string.calendar_empty_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 92.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredList, key = { it.id }) { item ->
                        val isOverdue = !item.isCompleted && item.dueAtTimestamp < now && item.status != FollowUpStatus.CANCELLED.name
                        val typeLabel = FollowUpTypeOption.values().firstOrNull { it.code == item.followUpType }?.label ?: "Follow-Up"
                        val methodLabel = if (item.followUpType == FollowUpTypeOption.MEETING.code) {
                            MeetingMethodOption.values().firstOrNull { it.code == item.meetingMethod }?.label.orEmpty()
                        } else ""

                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { if (item.contactId > 0L) onOpenContact(item.contactId) },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, if (isOverdue) MaterialTheme.colorScheme.error.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.22f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                // Type pill + Time + Overflow ⋮
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                                    ) {
                                        Text(
                                            text = if (methodLabel.isNotBlank()) "$typeLabel • $methodLabel" else typeLabel,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { moreSheetTarget = item },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.action_more))
                                    }
                                }

                                // Title + Contact Name & Company
                                Text(
                                    text = item.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                )
                                val whoLine = listOf(item.contactName, item.companyName).filter { it.isNotBlank() }.joinToString(" • ")
                                if (whoLine.isNotBlank()) {
                                    Text(whoLine, color = MaterialTheme.colorScheme.primary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                                }

                                // Date/Time + Reminder Summary
                                val remText = if (item.reminderOffsetMinutes > 0) " • Reminder: ${item.reminderOffsetMinutes} min before" else ""
                                Text(
                                    text = dateFormatter.format(Date(item.dueAtTimestamp)) + remText,
                                    fontSize = 12.sp,
                                    color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                                )

                                // Optional manual meeting link (opens in browser/app on tap)
                                if (item.meetingLink.isNotBlank()) {
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.meetingLink)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                            }
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(Icons.Default.Link, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                        Text(item.meetingLink, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }

                                // Simplified Quick Actions Row: Complete | Snooze
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { onToggleCompleted(item) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.weight(1f).height(38.dp)
                                    ) {
                                        Icon(if (item.isCompleted) Icons.Default.Undo else Icons.Default.Check, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text(if (item.isCompleted) "Reopen" else "Complete", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    if (!item.isCompleted) {
                                        OutlinedButton(
                                            onClick = { snoozeTarget = item },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                            modifier = Modifier.weight(1f).height(38.dp)
                                        ) {
                                            Icon(Icons.Default.Snooze, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(5.dp))
                                            Text("Snooze", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Advanced Filter Bottom Sheet (Status + Follow-Up Type)
    if (showAdvancedFilterSheet) {
        ModalBottomSheet(onDismissRequest = { showAdvancedFilterSheet = false }, shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Filter Schedule", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Status", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ACTIVE" to "Active", "OVERDUE" to "Overdue", "COMPLETED" to "Completed").forEach { (k, lbl) ->
                        FilterChip(selected = statusFilter == k, onClick = { statusFilter = k }, label = { Text(lbl, fontSize = 11.5.sp) })
                    }
                }
                Text("Type", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = typeFilter == "ALL", onClick = { typeFilter = "ALL" }, label = { Text("All", fontSize = 11.5.sp) })
                    FollowUpTypeOption.values().forEach { t ->
                        FilterChip(selected = typeFilter == t.code, onClick = { typeFilter = t.code }, label = { Text(t.label, fontSize = 11.5.sp) })
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { statusFilter = "ACTIVE"; typeFilter = "ALL"; timeFilter = CalendarTimeFilter.UPCOMING }, modifier = Modifier.weight(1f)) { Text("Reset") }
                    Button(onClick = { showAdvancedFilterSheet = false }, modifier = Modifier.weight(1f)) { Text("Apply", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }

    // Snooze Quick-Reschedule Dialog (Later Today | Tomorrow | In 3 Days | Next Week)
    snoozeTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { snoozeTarget = null },
            title = { Text("Snooze Follow-Up", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val options = listOf(
                        stringResource(R.string.snooze_later_today) to (System.currentTimeMillis() + 3L * 3600_000L),
                        "Tomorrow (9:00 AM)" to Calendar.getInstance().apply {
                            add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                        }.timeInMillis,
                        "In 3 Days" to (target.dueAtTimestamp.coerceAtLeast(System.currentTimeMillis()) + 3L * 24L * 3600_000L),
                        "Next Week" to (target.dueAtTimestamp.coerceAtLeast(System.currentTimeMillis()) + 7L * 24L * 3600_000L)
                    )
                    options.forEach { (lbl, newTs) ->
                        OutlinedButton(
                            onClick = {
                                val updated = target.copy(dueAtTimestamp = newTs)
                                onSaveFollowUp(updated)
                                FollowUpScheduler.scheduleForItem(context, updated)
                                Toast.makeText(context, "Snoozed: $lbl", Toast.LENGTH_SHORT).show()
                                snoozeTarget = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(lbl) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    editingItem = target
                    snoozeTarget = null
                    showEditorDialog = true
                }) { Text("Custom…") }
            },
            dismissButton = { TextButton(onClick = { snoozeTarget = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    // Follow-Up ⋮ More Action Sheet (Edit | Prepare Meeting Email / .ics | WhatsApp | Delete)
    moreSheetTarget?.let { item ->
        val actions = buildList {
            add(CardLinkSheetAction(Icons.Default.Edit, stringResource(R.string.action_edit)) {
                editingItem = item; showEditorDialog = true
            })
            add(CardLinkSheetAction(Icons.Default.Email, stringResource(R.string.meeting_prepare_email_btn)) {
                emailInviteTarget = item
            })
            if (item.whatsappNumber.isNotBlank()) {
                add(CardLinkSheetAction(Icons.Default.Chat, stringResource(R.string.calendar_open_wa_send)) {
                    ContactActionLauncher.launchWhatsAppChat(context, item.whatsappNumber, item.contactName, item.whatsappMessage.ifBlank { item.title })
                })
            }
            if (!item.isCompleted && item.status != FollowUpStatus.CANCELLED.name) {
                add(CardLinkSheetAction(Icons.Default.Block, "Cancel Reminder") { onCancelFollowUp(item) })
            }
            add(CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) {
                onDeleteFollowUp(item)
            })
        }
        CardLinkActionSheet(title = item.title, actions = actions, onDismiss = { moreSheetTarget = null })
    }

    // Prepare Meeting Email & .ics Invitation Dialog (User reviews before opening email app)
    emailInviteTarget?.let { target ->
        val linkedContact = contacts.firstOrNull { it.id == target.contactId }
        PrepareMeetingEmailDialog(
            followUp = target,
            recipientEmailInitial = linkedContact?.email.orEmpty(),
            organizerName = mySenderName,
            onDismiss = { emailInviteTarget = null }
        )
    }

    if (showEditorDialog) {
        FollowUpEditorDialog(
            initial = editingItem,
            myContacts = contacts,
            onDismiss = { showEditorDialog = false; editingItem = null },
            onSave = { savedItem ->
                onSaveFollowUp(savedItem)
                val statusMsg = FollowUpScheduler.scheduleForItem(context, savedItem)
                showEditorDialog = false; editingItem = null
                if ((savedItem.notificationEnabled || savedItem.alarmEnabled) && !FollowUpScheduler.isNotificationsEffectivelyEnabled(context)) {
                    showNotifDisabledDialog = true
                } else {
                    Toast.makeText(context, statusMsg, Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    if (showNotifDisabledDialog) {
        AlertDialog(
            onDismissRequest = { showNotifDisabledDialog = false },
            title = { Text(stringResource(R.string.calendar_notif_disabled_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.calendar_notif_disabled_msg)) },
            confirmButton = {
                Button(onClick = { showNotifDisabledDialog = false; onOpenSettings() }) { Text(stringResource(R.string.calendar_open_settings)) }
            },
            dismissButton = { TextButton(onClick = { showNotifDisabledDialog = false }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}

@Composable
private fun CalendarSummaryCard(
    title: String,
    count: Int,
    subLabel: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    val bgColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .semantics { contentDescription = "$title: $count $subLabel" }
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(count.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(subLabel, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun PrepareMeetingEmailDialog(
    followUp: FollowUpEntity,
    recipientEmailInitial: String,
    organizerName: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val (defSubject, defBody) = remember(followUp, organizerName) {
        MeetingInviteHelper.buildDefaultEmailDraft(followUp, organizerName)
    }
    var toEmail by remember(recipientEmailInitial) { mutableStateOf(recipientEmailInitial) }
    var subject by remember(defSubject) { mutableStateOf(defSubject) }
    var body by remember(defBody) { mutableStateOf(defBody) }
    var attachIcs by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.meeting_prepare_email_btn), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = toEmail, onValueChange = { toEmail = it }, label = { Text("Recipient Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Invitation Message") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Attach .ics Calendar Invite", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Works offline with Google Calendar, Outlook & Apple Calendar", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = attachIcs, onCheckedChange = { attachIcs = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                MeetingInviteHelper.launchEmailWithOptionalIcs(
                    context = context,
                    recipientEmail = toEmail,
                    subject = subject,
                    body = body,
                    followUp = followUp,
                    organizerName = organizerName,
                    attachIcs = attachIcs
                )
                onDismiss()
            }) { Text("Open Email App", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )
}

@Composable
private fun FollowUpEditorDialog(
    initial: FollowUpEntity?,
    myContacts: List<SavedContactEntity>,
    onDismiss: () -> Unit,
    onSave: (FollowUpEntity) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cal = remember(initial) { Calendar.getInstance().apply { timeInMillis = initial?.dueAtTimestamp ?: (System.currentTimeMillis() + 3600_000L) } }
    var year by remember(initial) { mutableIntStateOf(cal.get(Calendar.YEAR)) }
    var month by remember(initial) { mutableIntStateOf(cal.get(Calendar.MONTH)) }
    var day by remember(initial) { mutableIntStateOf(cal.get(Calendar.DAY_OF_MONTH)) }
    var hour by remember(initial) { mutableIntStateOf(cal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember(initial) { mutableIntStateOf(cal.get(Calendar.MINUTE)) }

    var followUpType by remember(initial) { mutableStateOf(initial?.followUpType ?: FollowUpTypeOption.MEETING.code) }
    var meetingMethod by remember(initial) { mutableStateOf(initial?.meetingMethod ?: MeetingMethodOption.IN_PERSON.code) }
    var meetingLink by remember(initial) { mutableStateOf(initial?.meetingLink ?: "") }
    var meetingAgenda by remember(initial) { mutableStateOf(initial?.meetingAgenda ?: "") }

    var contactSource by remember(initial) { mutableStateOf("MY_CONTACTS") }
    var selectedMyContact by remember(initial) { mutableStateOf(myContacts.firstOrNull { it.id == initial?.contactId } ?: myContacts.firstOrNull()) }
    var contactName by remember(initial) { mutableStateOf(initial?.contactName ?: selectedMyContact?.fullName ?: "") }
    var companyName by remember(initial) { mutableStateOf(initial?.companyName ?: selectedMyContact?.companyName ?: "") }
    var title by remember(initial) { mutableStateOf(initial?.title ?: "Follow-up Meeting") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
    var alarmEnabled by remember(initial) { mutableStateOf(initial?.alarmEnabled ?: false) }
    var notificationEnabled by remember(initial) { mutableStateOf(initial?.notificationEnabled ?: true) }
    var reminderOffsetMinutes by remember(initial) { mutableIntStateOf(initial?.reminderOffsetMinutes ?: 15) }
    var channel by remember(initial) { mutableStateOf(initial?.channel ?: FollowUpChannel.GENERAL.name) }
    var whatsappNumber by remember(initial) { mutableStateOf(initial?.whatsappNumber ?: selectedMyContact?.whatsapp?.ifBlank { selectedMyContact?.phone.orEmpty() }.orEmpty()) }
    var whatsappMessage by remember(initial) { mutableStateOf(initial?.whatsappMessage ?: "") }
    var whatsappMode by remember(initial) { mutableStateOf(initial?.whatsappMode ?: WhatsAppScheduleMode.REMINDER_TO_SEND.name) }
    var syncToDeviceCalendar by remember(initial) { mutableStateOf(initial?.deviceEventId != null) }
    var selectedDeviceCalId by remember(initial) { mutableStateOf(initial?.deviceCalendarId) }

    val calPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grantedMap ->
        val ok = grantedMap.values.all { it }
        syncToDeviceCalendar = ok
        if (ok) {
            selectedDeviceCalId = DeviceCalendarSyncManager.getWritableCalendars(context).firstOrNull()?.calendarId
        } else {
            Toast.makeText(context, "Calendar permission not granted — Follow-Up will stay inside CardLink.", Toast.LENGTH_LONG).show()
        }
    }

    var phoneContactsList by remember { mutableStateOf<List<DevicePhoneContact>>(emptyList()) }
    var phoneSearch by remember { mutableStateOf("") }
    var showPhonePickerList by remember { mutableStateOf(false) }
    var pendingMultiNumberContact by remember { mutableStateOf<DevicePhoneContact?>(null) }

    val readContactsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { phoneContactsList = PhoneContactsHelper.loadDeviceContacts(context); showPhonePickerList = true }
        else { contactSource = "MANUAL"; Toast.makeText(context, "Phone Contacts permission denied — use manual entry.", Toast.LENGTH_LONG).show() }
    }

    val dateTimeText = remember(year, month, day, hour, minute) {
        val c = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0) }
        SimpleDateFormat("EEE, dd MMM yyyy • hh:mm a", Locale.getDefault()).format(c.time)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) stringResource(R.string.calendar_schedule_title) else stringResource(R.string.calendar_edit_title), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Follow-Up Type Selector
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FollowUpTypeOption.values().forEach { t ->
                        FilterChip(
                            selected = followUpType == t.code,
                            onClick = {
                                followUpType = t.code
                                if (t == FollowUpTypeOption.WHATSAPP) channel = FollowUpChannel.WHATSAPP.name
                                else if (t != FollowUpTypeOption.GENERAL) channel = FollowUpChannel.GENERAL.name
                            },
                            label = { Text(t.label, fontSize = 11.5.sp) }
                        )
                    }
                }

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.calendar_title_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())

                // Meeting-specific fields (Method + Manual Link + Agenda — NO external cloud APIs!)
                if (followUpType == FollowUpTypeOption.MEETING.code) {
                    Text(stringResource(R.string.meeting_method_label), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MeetingMethodOption.values().forEach { m ->
                            FilterChip(selected = meetingMethod == m.code, onClick = { meetingMethod = m.code }, label = { Text(m.label, fontSize = 11.sp) })
                        }
                    }
                    val methodObj = MeetingMethodOption.values().firstOrNull { it.code == meetingMethod }
                    if (methodObj?.expectsOnlineLink == true) {
                        OutlinedTextField(
                            value = meetingLink,
                            onValueChange = { meetingLink = it },
                            label = { Text("Meeting Link (Optional HTTPS URL)") },
                            placeholder = { Text("https://teams.microsoft.com/… or zoom.us/…") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    OutlinedTextField(
                        value = meetingAgenda,
                        onValueChange = { meetingAgenda = it },
                        label = { Text("Agenda (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = contactSource == "MY_CONTACTS", onClick = { contactSource = "MY_CONTACTS"; showPhonePickerList = false }, label = { Text("My Contacts") })
                    FilterChip(selected = contactSource == "PHONE_CONTACTS", onClick = {
                        contactSource = "PHONE_CONTACTS"
                        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            scope.launch { phoneContactsList = PhoneContactsHelper.loadDeviceContacts(context); showPhonePickerList = true }
                        } else readContactsLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }, label = { Text("Phone") })
                    FilterChip(selected = contactSource == "MANUAL", onClick = { contactSource = "MANUAL"; showPhonePickerList = false }, label = { Text("Manual") })
                }

                if (contactSource == "MY_CONTACTS" && myContacts.isNotEmpty()) {
                    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        myContacts.forEach { c ->
                            FilterChip(selected = selectedMyContact?.id == c.id, onClick = {
                                selectedMyContact = c; contactName = c.fullName; companyName = c.companyName
                                if (whatsappNumber.isBlank()) whatsappNumber = c.whatsapp.ifBlank { c.phone }
                            }, label = { Text(c.fullName) })
                        }
                    }
                }

                if (contactSource == "PHONE_CONTACTS" && showPhonePickerList) {
                    OutlinedTextField(value = phoneSearch, onValueChange = { phoneSearch = it }, label = { Text("Search phone contacts...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    phoneContactsList.filter { phoneSearch.isBlank() || it.displayName.contains(phoneSearch, true) || it.phones.any { p -> p.contains(phoneSearch, true) } }.take(8).forEach { pc ->
                        Card(modifier = Modifier.fillMaxWidth().clickable {
                            contactName = pc.displayName; companyName = pc.organization
                            if (pc.phones.size > 1) pendingMultiNumberContact = pc else whatsappNumber = pc.phones.firstOrNull().orEmpty()
                            showPhonePickerList = false
                        }) { Column(modifier = Modifier.padding(8.dp)) { Text(pc.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(pc.phones.joinToString(", "), style = MaterialTheme.typography.bodySmall) } }
                    }
                }

                OutlinedTextField(value = contactName, onValueChange = { contactName = it }, label = { Text(stringResource(R.string.calendar_contact_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text(dateTimeText, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { DatePickerDialog(context, { _, y, m, d -> year = y; month = m; day = d }, year, month, day).show() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.calendar_pick_date)) }
                    OutlinedButton(onClick = { TimePickerDialog(context, { _, h, min -> hour = h; minute = min }, hour, minute, false).show() }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.calendar_pick_time)) }
                }

                // 5 min | 15 min (default) | 30 min | 1 hour | At Time
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("At Time" to 0, "5m" to 5, "15m" to 15, "30m" to 30, "1h" to 60).forEach { (lbl, mins) ->
                        FilterChip(selected = reminderOffsetMinutes == mins, onClick = { reminderOffsetMinutes = mins }, label = { Text(lbl) })
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.calendar_alarm_alert), fontSize = 13.sp); Switch(checked = alarmEnabled, onCheckedChange = { alarmEnabled = it }) }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.calendar_notif_reminder), fontSize = 13.sp); Switch(checked = notificationEnabled, onCheckedChange = { notificationEnabled = it }) }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.add_to_device_calendar_title), fontSize = 13.sp)
                        Text("Syncs meeting title & time only (keeps private notes inside CardLink)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = syncToDeviceCalendar, onCheckedChange = { want ->
                        if (want) {
                            if (DeviceCalendarSyncManager.hasCalendarPermission(context)) {
                                syncToDeviceCalendar = true
                                selectedDeviceCalId = DeviceCalendarSyncManager.getWritableCalendars(context).firstOrNull()?.calendarId
                            } else {
                                calPermLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
                            }
                        } else {
                            syncToDeviceCalendar = false
                        }
                    })
                }

                if (channel == FollowUpChannel.WHATSAPP.name) {
                    OutlinedTextField(value = whatsappNumber, onValueChange = { whatsappNumber = it }, label = { Text("WhatsApp (+88017...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = whatsappMessage, onValueChange = { whatsappMessage = it }, label = { Text(stringResource(R.string.calendar_wa_msg_label)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                }

                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(stringResource(R.string.calendar_notes_label)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (!MeetingInviteHelper.isValidMeetingUrl(meetingLink)) {
                    Toast.makeText(context, "Enter a valid meeting URL starting with https://", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                val chosenCal = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }
                val normalizedWa = if (channel == FollowUpChannel.WHATSAPP.name && whatsappNumber.isNotBlank()) PhoneContactsHelper.normalizeWithCountryCode(whatsappNumber) else whatsappNumber.trim()
                if (channel == FollowUpChannel.WHATSAPP.name && !PhoneContactsHelper.isValidInternationalOrLocalPhone(normalizedWa)) {
                    Toast.makeText(context, "Enter a valid WhatsApp number with country code.", Toast.LENGTH_SHORT).show(); return@Button
                }
                val finalName = contactName.trim().ifBlank { selectedMyContact?.fullName ?: "General Follow-Up" }
                val finalTitle = title.trim().ifBlank { "Follow-Up" }
                val baseEntity = FollowUpEntity(
                    id = initial?.id ?: 0L,
                    contactId = if (contactSource == "MY_CONTACTS") (selectedMyContact?.id ?: 0L) else (initial?.contactId ?: 0L),
                    contactName = finalName,
                    companyName = companyName.trim().ifBlank { selectedMyContact?.companyName.orEmpty() },
                    title = finalTitle,
                    notes = notes.trim(),
                    dueAtTimestamp = chosenCal.timeInMillis,
                    isCompleted = initial?.isCompleted ?: false,
                    createdAtTimestamp = initial?.createdAtTimestamp ?: System.currentTimeMillis(),
                    alarmEnabled = alarmEnabled,
                    notificationEnabled = notificationEnabled,
                    reminderOffsetMinutes = reminderOffsetMinutes,
                    channel = channel,
                    whatsappNumber = normalizedWa,
                    whatsappMessage = if (channel == FollowUpChannel.WHATSAPP.name) whatsappMessage.trim().ifBlank { "Hello $finalName, following up on: $finalTitle" } else "",
                    whatsappMode = whatsappMode,
                    status = FollowUpStatus.PENDING.name,
                    deviceCalendarId = initial?.deviceCalendarId,
                    deviceEventId = initial?.deviceEventId,
                    followUpType = followUpType,
                    meetingMethod = meetingMethod,
                    meetingLink = meetingLink.trim(),
                    meetingAgenda = meetingAgenda.trim()
                )
                val targetCalId = selectedDeviceCalId ?: DeviceCalendarSyncManager.getWritableCalendars(context).firstOrNull()?.calendarId
                val finalEntity = if (syncToDeviceCalendar && targetCalId != null) {
                    DeviceCalendarSyncManager.upsertFollowUpEvent(
                        context = context,
                        followUp = baseEntity,
                        calendarId = targetCalId,
                        reminderMinutesBefore = if (reminderOffsetMinutes > 0) reminderOffsetMinutes else 15
                    ).getOrDefault(baseEntity)
                } else baseEntity
                onSave(finalEntity)
            }) { Text(stringResource(R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } }
    )

    if (pendingMultiNumberContact != null) {
        val pc = pendingMultiNumberContact!!
        AlertDialog(
            onDismissRequest = { pendingMultiNumberContact = null },
            title = { Text("Select Number for ${pc.displayName}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { pc.phones.forEach { num -> OutlinedButton(onClick = { whatsappNumber = num; pendingMultiNumberContact = null }, modifier = Modifier.fillMaxWidth()) { Text(num) } } } },
            confirmButton = { TextButton(onClick = { pendingMultiNumberContact = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
