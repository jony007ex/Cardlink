package com.cardlink.app.ui.screens

import com.cardlink.app.ui.components.attachTapToFocus
import com.cardlink.app.ui.components.cardLinkPinchToZoom

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.cardlink.app.R
import com.cardlink.app.data.model.LoyaltyCardEntity
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.util.*
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private enum class LoyaltySortOption(val labelRes: Int) {
    RECENTLY_USED(R.string.loyalty_sort_used),
    RECENTLY_ADDED(R.string.loyalty_sort_added),
    RECENTLY_UPDATED(R.string.loyalty_sort_updated),
    NAME_AZ(R.string.loyalty_sort_az)
}

private enum class LoyaltyFilterOption(val labelRes: Int) {
    ALL(R.string.loyalty_filter_all),
    FAVORITES(R.string.loyalty_filter_favorites),
    RECENT(R.string.loyalty_filter_recent),
    BARCODE(R.string.loyalty_filter_barcode),
    QR(R.string.loyalty_filter_qr)
}

private const val LOYALTY_UI_PREFS = "cardlink_loyalty_ux_prefs"
private const val KEY_FIRST_TIP_DISMISSED = "first_use_tip_dismissed"
private const val KEY_DISMISSED_FAV_CARDS = "dismissed_fav_card_uuids"

private tailrec fun Context.findLoyaltyActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findLoyaltyActivity()
    else -> null
}

private fun createSafeTempCaptureUri(context: Context, prefix: String): Uri? = runCatching {
    val dir = File(context.cacheDir, "loyalty_capture").apply { if (!exists()) mkdirs() }
    val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}.getOrNull()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardWalletScreen(
    loyaltyCards: List<LoyaltyCardEntity>,
    onAddCardWithMode: (String) -> Unit,
    onOpenCard: (Long) -> Unit,
    onToggleFavorite: (LoyaltyCardEntity) -> Unit = {},
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showFilterPanel by remember { mutableStateOf(false) }
    var filterOption by remember { mutableStateOf(LoyaltyFilterOption.ALL) }
    var sortOption by remember { mutableStateOf(LoyaltySortOption.RECENTLY_USED) }
    var showAddMethodSheet by remember { mutableStateOf(false) }

    val prefs = remember { context.getSharedPreferences(LOYALTY_UI_PREFS, Context.MODE_PRIVATE) }
    var tipDismissed by remember { mutableStateOf(prefs.getBoolean(KEY_FIRST_TIP_DISMISSED, false)) }
    var dismissedFavSet by remember {
        mutableStateOf(prefs.getStringSet(KEY_DISMISSED_FAV_CARDS, emptySet())?.toSet() ?: emptySet())
    }

    val suggestedFavoriteCard = remember(loyaltyCards, dismissedFavSet) {
        loyaltyCards.firstOrNull { !it.isFavorite && it.usageCount >= 3 && it.stableUuid !in dismissedFavSet }
    }

    val displayedCards = remember(loyaltyCards, searchQuery, filterOption, sortOption) {
        val q = searchQuery.trim()
        val filtered = loyaltyCards.filter { c ->
            val matchesQuery = q.isBlank() ||
                c.brandName.contains(q, true) ||
                c.cardNickname.contains(q, true) ||
                c.cardNumber.contains(q, true) ||
                c.cardholderName.contains(q, true)
            val matchesFilter = when (filterOption) {
                LoyaltyFilterOption.ALL -> true
                LoyaltyFilterOption.FAVORITES -> c.isFavorite
                LoyaltyFilterOption.RECENT -> c.lastUsedTimestamp > 0L
                LoyaltyFilterOption.BARCODE -> c.barcodeValue.isNotBlank()
                LoyaltyFilterOption.QR -> c.qrPayload.isNotBlank()
            }
            matchesQuery && matchesFilter
        }
        when (sortOption) {
            LoyaltySortOption.RECENTLY_USED -> filtered.sortedWith(
                compareByDescending<LoyaltyCardEntity> { it.isFavorite }
                    .thenByDescending { it.lastUsedTimestamp }
                    .thenByDescending { it.createdAtTimestamp }
            )
            LoyaltySortOption.RECENTLY_ADDED -> filtered.sortedByDescending { it.createdAtTimestamp }
            LoyaltySortOption.RECENTLY_UPDATED -> filtered.sortedByDescending { it.updatedAtTimestamp }
            LoyaltySortOption.NAME_AZ -> filtered.sortedBy { it.brandName.lowercase(Locale.getDefault()) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.loyalty_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.loyalty_wallet_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (loyaltyCards.isNotEmpty()) {
                        IconButton(onClick = {
                            showSearchBar = !showSearchBar
                            if (!showSearchBar) searchQuery = ""
                        }) {
                            Icon(Icons.Default.Search, contentDescription = "Search Loyalty Cards")
                        }
                        IconButton(onClick = { showFilterPanel = !showFilterPanel }) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Filter & Sort",
                                tint = if (showFilterPanel || filterOption != LoyaltyFilterOption.ALL) MaterialTheme.colorScheme.primary else LocalContentColor.current
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            val addLabel = stringResource(R.string.loyalty_add_card)
            FloatingActionButton(
                onClick = { showAddMethodSheet = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier.semantics { contentDescription = addLabel }
            ) {
                Icon(Icons.Default.Add, contentDescription = addLabel)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (loyaltyCards.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.CardMembership, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(34.dp))
                                }
                            }
                            Text(
                                text = stringResource(R.string.loyalty_empty_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.loyalty_empty_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = { showAddMethodSheet = true },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.loyalty_add_card), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                AnimatedVisibility(visible = showSearchBar) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(stringResource(R.string.loyalty_search_hint)) },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear") }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                AnimatedVisibility(visible = showFilterPanel) {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltyFilterOption.values().forEach { opt ->
                                    FilterChip(
                                        selected = filterOption == opt,
                                        onClick = { filterOption = opt },
                                        label = { Text(stringResource(opt.labelRes), fontSize = 11.5.sp) }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltySortOption.values().forEach { opt ->
                                    FilterChip(
                                        selected = sortOption == opt,
                                        onClick = { sortOption = opt },
                                        label = { Text(stringResource(opt.labelRes), fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                }

                if (!tipDismissed) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.TipsAndUpdates, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text(
                                text = stringResource(R.string.loyalty_first_tip),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    tipDismissed = true
                                    prefs.edit().putBoolean(KEY_FIRST_TIP_DISMISSED, true).apply()
                                },
                                modifier = Modifier.size(28.dp)
                            ) { Icon(Icons.Default.Close, contentDescription = "Dismiss tip", modifier = Modifier.size(16.dp)) }
                        }
                    }
                }

                if (suggestedFavoriteCard != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.StarOutline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = stringResource(R.string.loyalty_suggest_fav_msg, suggestedFavoriteCard.brandName),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                val next = dismissedFavSet + suggestedFavoriteCard.stableUuid
                                dismissedFavSet = next
                                prefs.edit().putStringSet(KEY_DISMISSED_FAV_CARDS, next).apply()
                            }) { Text("Not Now", fontSize = 11.sp) }
                            TextButton(onClick = { onToggleFavorite(suggestedFavoriteCard) }) {
                                Text("Add", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                if (displayedCards.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            stringResource(R.string.loyalty_no_matches),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 154.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 88.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedCards, key = { it.stableUuid.ifBlank { it.id.toString() } }) { card ->
                            LoyaltyCardGridTile(
                                card = card,
                                onToggleFavorite = { onToggleFavorite(card) },
                                onClick = { onOpenCard(card.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddMethodSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddMethodSheet = false },
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = stringResource(R.string.loyalty_add_card),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                AddMethodRow(Icons.Default.PhotoCamera, stringResource(R.string.loyalty_method_scan_card), stringResource(R.string.loyalty_method_scan_card_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("CAMERA")
                }
                AddMethodRow(Icons.Default.PhotoLibrary, stringResource(R.string.loyalty_method_choose_img), stringResource(R.string.loyalty_method_choose_img_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("GALLERY")
                }
                AddMethodRow(Icons.Default.QrCodeScanner, stringResource(R.string.loyalty_method_scan_code), stringResource(R.string.loyalty_method_scan_code_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("SCAN_CODE")
                }
                AddMethodRow(Icons.Default.Edit, stringResource(R.string.loyalty_method_manual), stringResource(R.string.loyalty_method_manual_sub)) {
                    showAddMethodSheet = false; onAddCardWithMode("MANUAL")
                }
            }
        }
    }
}

@Composable
private fun AddMethodRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(modifier = Modifier.size(40.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(20.dp))
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LoyaltyCardGridTile(
    card: LoyaltyCardEntity,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (card.isFavorite) 0.7f else 0.3f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (!card.frontPhotoUri.isNullOrBlank()) {
                    VaultImage(
                        uriString = card.frontPhotoUri,
                        contentDescription = card.brandName,
                        contentScale = ContentScale.Crop,
                        maxEdgePx = 420,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Icon(Icons.Default.CardMembership, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Text(
                            text = card.brandName.ifBlank { "Card" }.take(18),
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.align(Alignment.TopStart).size(32.dp).padding(4.dp)
                ) {
                    Icon(
                        imageVector = if (card.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = if (card.isFavorite) "Favorite" else "Not favorite",
                        tint = if (card.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (hasBarcode || hasQr) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (hasBarcode) Icon(Icons.Default.ViewWeek, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                            if (hasQr) Icon(Icons.Default.QrCode2, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = card.brandName.ifBlank { "Loyalty Card" },
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val secondaryText = when {
                    card.cardNickname.isNotBlank() -> card.cardNickname
                    card.cardNumber.isNotBlank() -> LoyaltyCodeHelper.maskCardNumber(card.cardNumber)
                    else -> ""
                }
                if (secondaryText.isNotBlank()) {
                    Text(
                        text = secondaryText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardEditorScreen(
    existingCard: LoyaltyCardEntity?,
    defaultCardholderName: String,
    initialLaunchMode: String = "MANUAL",
    onSave: (LoyaltyCardEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEditing = existingCard != null

    var brandName by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.brandName.orEmpty()) }
    var cardNickname by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.cardNickname.orEmpty()) }
    var cardNumber by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.cardNumber.orEmpty()) }
    var cardholderName by rememberSaveable(existingCard?.id) {
        mutableStateOf(existingCard?.cardholderName?.ifBlank { defaultCardholderName } ?: defaultCardholderName)
    }
    var notes by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.notes.orEmpty()) }
    var expiryDateIso by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.expiryDateIso.orEmpty()) }
    var pointsBalance by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.pointsBalance.orEmpty()) }
    var membershipTier by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.membershipTier.orEmpty()) }

    var barcodeValue by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeValue.orEmpty()) }
    var barcodeFormat by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.barcodeFormat.orEmpty()) }
    var qrPayload by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.qrPayload.orEmpty()) }

    var frontPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.frontPhotoUri) }
    var backPhotoUri by rememberSaveable(existingCard?.id) { mutableStateOf(existingCard?.backPhotoUri) }

    var showMoreDetails by remember { mutableStateOf(isEditing) }
    var showManualCodeFields by remember { mutableStateOf(false) }
    var activeScannerMode by remember { mutableStateOf<String?>(null) }
    var pendingCopyPrompt by remember { mutableStateOf<String?>(null) }
    var processingStage by remember { mutableStateOf<String?>(null) }
    var imageErrorMessage by remember { mutableStateOf<String?>(null) }

    var pendingCaptureSide by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingCaptureUriStr by rememberSaveable { mutableStateOf<String?>(null) }
    var galleryPickSide by rememberSaveable { mutableStateOf("front") }

    fun savePhotoAsync(sourceUri: Uri, side: String) {
        scope.launch {
            processingStage = "Encrypting card photo…"
            imageErrorMessage = null
            val saved = withContext(Dispatchers.IO) {
                ScannedCardStorageHelper.saveLoyaltyPhotoFromUri(context, sourceUri, side)
            }
            processingStage = null
            if (saved != null) {
                if (side == "front") frontPhotoUri = saved else backPhotoUri = saved
            } else {
                imageErrorMessage = "The selected image could not be opened or decoded. Replace the image or continue without it."
            }
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uriStr = pendingCaptureUriStr
        val side = pendingCaptureSide
        if (success && !uriStr.isNullOrBlank() && side != null) {
            runCatching { Uri.parse(uriStr) }.getOrNull()?.let { savePhotoAsync(it, side) }
        }
    }

    val camPermForPhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val side = pendingCaptureSide
        if (granted && side != null) {
            val uri = createSafeTempCaptureUri(context, side)
            if (uri != null) {
                pendingCaptureUriStr = uri.toString()
                runCatching { takePictureLauncher.launch(uri) }.onFailure {
                    imageErrorMessage = "No camera app is available on this device. Choose an image from Gallery instead."
                }
            } else {
                imageErrorMessage = "Could not prepare temporary camera file."
            }
        } else {
            Toast.makeText(context, "Camera permission denied — you can pick from Gallery instead.", Toast.LENGTH_LONG).show()
        }
    }

    fun launchCameraForSide(side: String) {
        pendingCaptureSide = side
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            val uri = createSafeTempCaptureUri(context, side)
            if (uri != null) {
                pendingCaptureUriStr = uri.toString()
                runCatching { takePictureLauncher.launch(uri) }.onFailure {
                    imageErrorMessage = "Camera could not be launched. Choose an image from Gallery instead."
                }
            } else {
                imageErrorMessage = "Could not prepare camera storage."
            }
        } else {
            camPermForPhotoLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val galleryPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            savePhotoAsync(uri, galleryPickSide)
        }
    }

    var initialActionTriggered by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialLaunchMode) {
        if (!isEditing && !initialActionTriggered) {
            initialActionTriggered = true
            when (initialLaunchMode) {
                "CAMERA" -> launchCameraForSide("front")
                "GALLERY" -> {
                    galleryPickSide = "front"
                    galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                "SCAN_CODE" -> activeScannerMode = "BARCODE"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) stringResource(R.string.loyalty_edit_card) else stringResource(R.string.loyalty_add_card),
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            processingStage?.let { stage ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text(stage, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }

            imageErrorMessage?.let { errMsg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Card Image Could Not Be Opened", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                        Text(errMsg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                imageErrorMessage = null
                                galleryPickSide = "front"
                                galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) { Text("Replace Image", fontSize = 12.sp) }
                            TextButton(onClick = { imageErrorMessage = null }) { Text("Continue", fontSize = 12.sp) }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = brandName,
                onValueChange = { brandName = it },
                label = { Text("${stringResource(R.string.loyalty_brand_name)} *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNickname,
                onValueChange = { cardNickname = it },
                label = { Text(stringResource(R.string.loyalty_nickname)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text(stringResource(R.string.loyalty_card_number)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.loyalty_section_codes), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { activeScannerMode = "BARCODE" }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.ViewWeek, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(stringResource(R.string.loyalty_scan_barcode), fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { activeScannerMode = "QR" }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(stringResource(R.string.loyalty_scan_qr), fontSize = 12.sp)
                        }
                    }

                    if (barcodeValue.isNotBlank()) {
                        Text(
                            "✓ Barcode (${LoyaltyCodeHelper.formatDisplayName(barcodeFormat.ifBlank { "CODE_128" })}): $barcodeValue",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (qrPayload.isNotBlank()) {
                        Text(
                            "✓ QR Payload captured (${qrPayload.length} chars)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    TextButton(
                        onClick = { showManualCodeFields = !showManualCodeFields },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            if (showManualCodeFields) "Hide Manual Code Entry" else "Enter Barcode / QR Manually",
                            fontSize = 12.sp
                        )
                    }

                    AnimatedVisibility(visible = showManualCodeFields) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = barcodeValue,
                                onValueChange = { barcodeValue = it; if (barcodeFormat.isBlank()) barcodeFormat = "CODE_128" },
                                label = { Text("Barcode Value") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                LoyaltyCodeHelper.SUPPORTED_1D_FORMATS.forEach { fmt ->
                                    FilterChip(
                                        selected = barcodeFormat.equals(fmt, true),
                                        onClick = { barcodeFormat = fmt },
                                        label = { Text(LoyaltyCodeHelper.formatDisplayName(fmt), fontSize = 11.sp) }
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = qrPayload,
                                onValueChange = { qrPayload = it },
                                label = { Text("QR Payload") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.loyalty_section_photos), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                    LoyaltyPhotoSlot(
                        label = stringResource(R.string.loyalty_front_side),
                        photoUri = frontPhotoUri,
                        onTakePhoto = { launchCameraForSide("front") },
                        onPickGallery = {
                            galleryPickSide = "front"
                            galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onRemove = { frontPhotoUri = null }
                    )
                    if (!frontPhotoUri.isNullOrBlank() || !backPhotoUri.isNullOrBlank()) {
                        HorizontalDivider()
                        LoyaltyPhotoSlot(
                            label = stringResource(R.string.loyalty_add_back_side),
                            photoUri = backPhotoUri,
                            onTakePhoto = { launchCameraForSide("back") },
                            onPickGallery = {
                                galleryPickSide = "back"
                                galleryPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onRemove = { backPhotoUri = null }
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = { showMoreDetails = !showMoreDetails },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (showMoreDetails) "Hide More Details" else "More Details (Optional)")
                Spacer(Modifier.width(6.dp))
                Icon(if (showMoreDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }

            AnimatedVisibility(visible = showMoreDetails) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = cardholderName,
                        onValueChange = { cardholderName = it },
                        label = { Text(stringResource(R.string.loyalty_cardholder)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pointsBalance,
                            onValueChange = { pointsBalance = it },
                            label = { Text("Points Balance") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = membershipTier,
                            onValueChange = { membershipTier = it },
                            label = { Text("Tier (e.g. Gold)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = expiryDateIso,
                        onValueChange = { expiryDateIso = it.take(10) },
                        label = { Text("Expiry Date (YYYY-MM-DD, Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(stringResource(R.string.loyalty_notes)) },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Button(
                onClick = {
                    val trimmedBrand = brandName.trim()
                    if (trimmedBrand.isBlank()) {
                        Toast.makeText(context, context.getString(R.string.loyalty_brand_required), Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    val entity = (existingCard ?: LoyaltyCardEntity(brandName = trimmedBrand)).copy(
                        brandName = trimmedBrand,
                        cardNickname = cardNickname.trim(),
                        cardNumber = cardNumber.trim(),
                        cardholderName = cardholderName.trim(),
                        notes = notes.trim(),
                        expiryDateIso = expiryDateIso.trim().takeIf { it.isNotBlank() },
                        pointsBalance = pointsBalance.trim(),
                        membershipTier = membershipTier.trim(),
                        barcodeValue = barcodeValue.trim(),
                        barcodeFormat = if (barcodeValue.isNotBlank()) barcodeFormat.ifBlank { "CODE_128" } else "",
                        qrPayload = qrPayload.trim(),
                        frontPhotoUri = frontPhotoUri,
                        backPhotoUri = backPhotoUri,
                        updatedAtTimestamp = now
                    )
                    onSave(entity)
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_save), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    activeScannerMode?.let { mode ->
        LoyaltyCodeScannerDialog(
            mode = mode,
            onDetected = { rawValue, formatName ->
                if (mode == "QR") {
                    qrPayload = rawValue
                    Toast.makeText(context, "QR Code captured!", Toast.LENGTH_SHORT).show()
                } else {
                    barcodeValue = rawValue
                    barcodeFormat = formatName
                    Toast.makeText(context, "Barcode captured (${LoyaltyCodeHelper.formatDisplayName(formatName)})", Toast.LENGTH_SHORT).show()
                    if (cardNumber.isBlank()) {
                        pendingCopyPrompt = rawValue
                    }
                }
                activeScannerMode = null
            },
            onDismiss = { activeScannerMode = null }
        )
    }

    pendingCopyPrompt?.let { candidate ->
        AlertDialog(
            onDismissRequest = { pendingCopyPrompt = null },
            title = { Text(stringResource(R.string.loyalty_copy_number_title), fontWeight = FontWeight.Bold) },
            text = { Text("${stringResource(R.string.loyalty_copy_number_msg)}\n\n$candidate") },
            confirmButton = {
                Button(onClick = {
                    cardNumber = candidate
                    pendingCopyPrompt = null
                }) { Text(stringResource(R.string.action_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingCopyPrompt = null }) { Text(stringResource(R.string.action_skip)) }
            }
        )
    }
}

@Composable
private fun LoyaltyPhotoSlot(
    label: String,
    photoUri: String?,
    onTakePhoto: () -> Unit,
    onPickGallery: () -> Unit,
    onRemove: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        if (!photoUri.isNullOrBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.586f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            ) {
                VaultImage(
                    uriString = photoUri,
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    maxEdgePx = 800,
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color.Black.copy(alpha = 0.55f), CircleShape).size(32.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove photo", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onTakePhoto, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PhotoCamera, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text("Camera", fontSize = 12.sp)
            }
            OutlinedButton(onClick = onPickGallery, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text("Gallery", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LoyaltyCodeScannerDialog(
    mode: String,
    onDetected: (rawValue: String, formatName: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    var hasPerm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPerm = granted
    }
    LaunchedEffect(Unit) {
        if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA)
    }

    val scanDone = remember { AtomicBoolean(false) }
    val zoomState = remember { com.cardlink.app.ui.components.CardLinkCameraZoomState() }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val barcodeScanner = remember { BarcodeScanning.getClient() }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { barcodeScanner.close() }
            runCatching { executor.shutdown() }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            if (hasPerm) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().cardLinkPinchToZoom(zoomState),
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            this.attachTapToFocus(zoomState)
                        }
                        val providerFuture = ProcessCameraProvider.getInstance(ctx)
                        providerFuture.addListener({
                            runCatching {
                                val provider = providerFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also { ia ->
                                        ia.setAnalyzer(executor) { proxy ->
                                            val img = proxy.image
                                            if (img != null && !scanDone.get()) {
                                                val inputImg = InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees)
                                                barcodeScanner.process(inputImg)
                                                    .addOnSuccessListener(ContextCompat.getMainExecutor(ctx)) { list ->
                                                        val match = list.firstOrNull { bc ->
                                                            val raw = bc.rawValue
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(bc.format)
                                                            !raw.isNullOrBlank() && fmtName != null && (
                                                                (mode == "QR" && fmtName == "QR_CODE") ||
                                                                    (mode == "BARCODE" && fmtName != "QR_CODE")
                                                                )
                                                        }
                                                        val safeRaw = match?.rawValue
                                                        if (match != null && !safeRaw.isNullOrBlank() && scanDone.compareAndSet(false, true)) {
                                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                            val fmtName = LoyaltyCodeHelper.mlKitFormatToName(match.format) ?: "CODE_128"
                                                            onDetected(safeRaw, fmtName)
                                                        }
                                                    }
                                                    .addOnCompleteListener { proxy.close() }
                                            } else {
                                                proxy.close()
                                            }
                                        }
                                    }
                                provider.unbindAll()
                                val cam = provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                                zoomState.bindCamera(ctx, cam)
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    }
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.84f)
                        .height(if (mode == "QR") 250.dp else 150.dp)
                        .border(2.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                )

                com.cardlink.app.ui.components.ScannerZoomPresetBar(
                    zoomState = zoomState,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 36.dp)
                )
            } else {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.qr_cam_required), color = Color.White, fontWeight = FontWeight.Bold)
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }) {
                        Text(stringResource(R.string.qr_grant_cam))
                    }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (mode == "QR") stringResource(R.string.loyalty_scan_qr) else stringResource(R.string.loyalty_scan_barcode),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoyaltyCardDetailScreen(
    card: LoyaltyCardEntity,
    onEdit: () -> Unit,
    onToggleFavorite: () -> Unit = {},
    onRecordUsed: () -> Unit = {},
    onDelete: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val hasBarcode = card.barcodeValue.isNotBlank() && card.barcodeFormat.isNotBlank()
    val hasQr = card.qrPayload.isNotBlank()

    var activeCodeTab by remember(card.id, hasBarcode, hasQr) {
        mutableStateOf(if (hasBarcode) "BARCODE" else "QR")
    }
    var showEnlargedCode by remember { mutableStateOf(false) }
    var showBackPhoto by remember { mutableStateOf(false) }
    var showMoreSheet by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(card.id) {
        onRecordUsed()
    }

    val barcodeState by produceState<Pair<Bitmap?, Boolean>>(initialValue = null to false, card.barcodeValue, card.barcodeFormat) {
        value = withContext(Dispatchers.Default) {
            val bmp = LoyaltyCodeHelper.generateBarcodeBitmap(card.barcodeValue, card.barcodeFormat, 1000, 340)
            val verified = LoyaltyCodeHelper.verifyCodeBitmap(bmp, card.barcodeValue)
            bmp to verified
        }
    }
    val qrState by produceState<Pair<Bitmap?, Boolean>>(initialValue = null to false, card.qrPayload) {
        value = withContext(Dispatchers.Default) {
            val bmp = LoyaltyCodeHelper.generateQrBitmap(card.qrPayload, 680)
            val verified = LoyaltyCodeHelper.verifyCodeBitmap(bmp, card.qrPayload)
            bmp to verified
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(card.brandName.ifBlank { "Loyalty Card" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (card.cardNickname.isNotBlank()) {
                            Text(card.cardNickname, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (card.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (card.isFavorite) "Favorite" else "Not favorite",
                            tint = if (card.isFavorite) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showMoreSheet = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More actions")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (hasBarcode || hasQr) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (hasBarcode && hasQr) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = activeCodeTab == "BARCODE", onClick = { activeCodeTab = "BARCODE" }, label = { Text("Barcode") })
                                FilterChip(selected = activeCodeTab == "QR", onClick = { activeCodeTab = "QR" }, label = { Text("QR Code") })
                            }
                        }

                        val (activeBmp, isVerified) = if (activeCodeTab == "BARCODE") barcodeState else qrState

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { showEnlargedCode = true },
                            color = Color.White,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (activeBmp != null) {
                                    Image(
                                        bitmap = activeBmp.asImageBitmap(),
                                        contentDescription = if (activeCodeTab == "BARCODE") "Barcode for ${card.brandName}" else "QR code for ${card.brandName}",
                                        contentScale = ContentScale.Fit,
                                        modifier = if (activeCodeTab == "BARCODE") Modifier.fillMaxWidth().height(120.dp) else Modifier.size(200.dp)
                                    )
                                } else {
                                    Text(
                                        text = stringResource(R.string.loyalty_code_unverified),
                                        color = Color(0xFFB91C1C),
                                        style = MaterialTheme.typography.bodySmall,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        if (activeBmp != null && !isVerified) {
                            Text(
                                text = stringResource(R.string.loyalty_code_unverified),
                                color = Color(0xFFF59E0B),
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = TextAlign.Center
                            )
                        }

                        if (card.cardNumber.isNotBlank()) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { SecureClipboardHelper.copySensitive(context, card.brandName, card.cardNumber) }
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = LoyaltyCodeHelper.maskCardNumber(card.cardNumber),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy card number", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            }
                        }

                        Button(
                            onClick = { showEnlargedCode = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(Icons.Default.ZoomOutMap, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.loyalty_show_card_checkout), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            val hasFront = !card.frontPhotoUri.isNullOrBlank()
            val hasBack = !card.backPhotoUri.isNullOrBlank()
            if (hasFront || hasBack) {
                val activeUri = if (showBackPhoto && hasBack) card.backPhotoUri else card.frontPhotoUri ?: card.backPhotoUri
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.586f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = hasFront && hasBack) { showBackPhoto = !showBackPhoto }
                        ) {
                            VaultImage(
                                uriString = activeUri,
                                contentDescription = if (showBackPhoto) "Back of ${card.brandName}" else "Front of ${card.brandName}",
                                contentScale = ContentScale.Crop,
                                maxEdgePx = 1200,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        if (hasFront && hasBack) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.tpl_tap_to_flip_hint),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                TextButton(onClick = { showBackPhoto = !showBackPhoto }) {
                                    Text(if (showBackPhoto) stringResource(R.string.tpl_show_front) else stringResource(R.string.tpl_show_back), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            val details = buildList {
                if (card.cardholderName.isNotBlank()) add("Cardholder" to card.cardholderName)
                if (card.membershipTier.isNotBlank()) add("Tier" to card.membershipTier)
                if (card.pointsBalance.isNotBlank()) add("Points Balance" to card.pointsBalance)
                if (!card.expiryDateIso.isNullOrBlank()) add("Expiry Date" to IdExpiryHelper.formatDisplayDate(card.expiryDateIso).ifBlank { card.expiryDateIso })
                if (card.notes.isNotBlank()) add("Notes" to card.notes)
            }
            if (details.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        details.forEach { (k, v) ->
                            Column {
                                Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEnlargedCode) {
        DisposableEffect(Unit) {
            val window = context.findLoyaltyActivity()?.window
            val prevBrightness = window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window?.attributes = window?.attributes?.apply { screenBrightness = 0.95f }
            onDispose {
                window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                window?.attributes = window?.attributes?.apply { screenBrightness = prevBrightness }
            }
        }

        val (enlargedBmp, _) = if (activeCodeTab == "BARCODE") barcodeState else qrState
        Dialog(
            onDismissRequest = { showEnlargedCode = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
                    .padding(24.dp)
            ) {
                IconButton(
                    onClick = { showEnlargedCode = false },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close Checkout View", tint = Color.Black)
                }

                Column(
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text(card.brandName, color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (enlargedBmp != null) {
                        Image(
                            bitmap = enlargedBmp.asImageBitmap(),
                            contentDescription = "Checkout code",
                            contentScale = ContentScale.Fit,
                            modifier = if (activeCodeTab == "BARCODE") Modifier.fillMaxWidth().height(180.dp) else Modifier.size(280.dp)
                        )
                    }
                    if (card.cardNumber.isNotBlank()) {
                        Text(
                            text = LoyaltyCodeHelper.maskCardNumber(card.cardNumber),
                            color = Color.DarkGray,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }

    if (showMoreSheet) {
        CardLinkActionSheet(
            title = card.brandName.ifBlank { "Loyalty Card" },
            actions = listOf(
                CardLinkSheetAction(Icons.Default.Edit, stringResource(R.string.action_edit), onClick = onEdit),
                CardLinkSheetAction(
                    if (card.isFavorite) Icons.Default.StarBorder else Icons.Default.Star,
                    if (card.isFavorite) "Remove from Favorites" else "Add to Favorites",
                    onClick = onToggleFavorite
                ),
                CardLinkSheetAction(Icons.Default.Share, "Share Card Summary") {
                    val text = buildString {
                        appendLine(card.brandName)
                        if (card.cardNickname.isNotBlank()) appendLine(card.cardNickname)
                        if (card.cardNumber.isNotBlank()) appendLine("Card: ${LoyaltyCodeHelper.maskCardNumber(card.cardNumber)}")
                    }.trim()
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share Loyalty Card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                },
                CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) {
                    showDeleteConfirm = true
                }
            ),
            onDismiss = { showMoreSheet = false }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(stringResource(R.string.loyalty_delete_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.loyalty_delete_msg)) },
            confirmButton = {
                Button(
                    onClick = { showDeleteConfirm = false; onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
}
