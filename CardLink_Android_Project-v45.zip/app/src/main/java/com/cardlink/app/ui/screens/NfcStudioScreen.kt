package com.cardlink.app.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.NfcProjectEntity
import com.cardlink.app.data.model.QrProjectEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.cardlink.app.ui.components.CardLinkActionSheet
import com.cardlink.app.ui.components.CardLinkSheetAction
import com.cardlink.app.ui.components.SmartPrivacyPreviewCard
import com.cardlink.app.util.*

private tailrec fun Context.findNfcActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findNfcActivity()
    else -> null
}

private enum class NfcArmMode {
    NONE, READ, WRITE, TEST_TAG, CLEAR, LOCK_READ_ONLY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NfcStudioScreen(
    activeCard: BusinessCardEntity,
    savedProjects: List<NfcProjectEntity>,
    onSaveProject: (NfcProjectEntity) -> Unit,
    onDeleteProject: (NfcProjectEntity) -> Unit,
    onUpdateCardSharing: (BusinessCardEntity) -> Unit,
    onSaveContactFromNfc: (SavedContactEntity) -> Unit = {},
    onCreateQrFallback: (QrProjectEntity) -> Unit = {},
    onOpenQrStudio: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val activity = remember(context) { context.findNfcActivity() }
    val androidNfcAdapter = remember(context) { AndroidNfcPlatformAdapter(context) }
    val hardwareState = remember { NfcStudioEngine.checkHardwareState(context) }

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Read NFC, 1 = Write NFC, 2 = Saved Projects
    var selectedType by remember { mutableStateOf(NfcContentType.SHARING_PROFILE) }
    var sharingProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    var rawInput by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("") }
    var showMoreTypes by remember { mutableStateOf(false) }

    var armMode by remember { mutableStateOf(NfcArmMode.NONE) }
    var preparedMessage by remember { mutableStateOf<NdefMessage?>(null) }
    var lastOperationResult by remember { mutableStateOf<NfcOperationResult?>(null) }
    var lastInspection by remember { mutableStateOf<NfcTagInspection?>(null) }
    var showTechDetails by remember { mutableStateOf(false) }
    var showReadMoreSheet by remember { mutableStateOf(false) }
    var projectMoreTarget by remember { mutableStateOf<NfcProjectEntity?>(null) }

    var showClearConfirm by remember { mutableStateOf(false) }
    var showLockReadOnlyConfirm by remember { mutableStateOf(false) }
    var showSaveProjectDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    val projectedCard = remember(activeCard, sharingProfile) {
        SharingProfileManager.applyProfile(activeCard, sharingProfile)
    }

    // Debounced, lifecycle-aware Reader Mode (pauses automatically after each tag so one tag never spawns duplicate screens)
    DisposableEffect(armMode, preparedMessage) {
        val adapter = NfcAdapter.getDefaultAdapter(context)
        if (armMode != NfcArmMode.NONE && adapter != null && adapter.isEnabled && activity != null) {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS

            var handled = false
            adapter.enableReaderMode(activity, { tag ->
                if (handled) return@enableReaderMode
                handled = true
                val result = when (armMode) {
                    NfcArmMode.READ -> NfcOperationResult.ReadSuccess(NfcStudioEngine.inspectTag(tag))
                    NfcArmMode.WRITE -> {
                        val msg = preparedMessage
                        if (msg != null) NfcStudioEngine.writeAndVerifyTag(context, tag, msg)
                        else NfcOperationResult.Failure("No prepared NDEF message.")
                    }
                    NfcArmMode.TEST_TAG -> {
                        val msg = preparedMessage
                        if (msg != null) NfcStudioEngine.testTagAgainstExpected(tag, msg)
                        else NfcOperationResult.Failure("No expected message to test against.")
                    }
                    NfcArmMode.CLEAR -> NfcStudioEngine.clearTagAndVerify(context, tag)
                    NfcArmMode.LOCK_READ_ONLY -> NfcStudioEngine.makeTagReadOnly(context, tag)
                    NfcArmMode.NONE -> null
                }
                activity.runOnUiThread {
                    if (result != null) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        lastOperationResult = result
                        armMode = NfcArmMode.NONE
                        when (result) {
                            is NfcOperationResult.ReadSuccess -> lastInspection = result.inspection
                            is NfcOperationResult.WriteVerified -> lastInspection = result.inspection
                            is NfcOperationResult.TestTagResult -> lastInspection = result.inspection
                            is NfcOperationResult.ClearedVerified -> lastInspection = result.inspection
                            else -> Unit
                        }
                    }
                }
            }, flags, null)
        }
        onDispose {
            runCatching {
                if (activity != null) adapter?.disableReaderMode(activity)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.nfc_studio_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.nfc_studio_tools_sub),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (hardwareState == NfcHardwareState.READY) {
                        IconButton(onClick = { showReadMoreSheet = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Advanced NFC Actions")
                        }
                    }
                    IconButton(onClick = { showHelpDialog = true }) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "NFC Help & Compatibility")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Compact Hardware Status Banner
            when (hardwareState) {
                NfcHardwareState.UNSUPPORTED -> {
                    Card(modifier = Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(16.dp)) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                            Text("This device doesn't support NFC.", fontWeight = FontWeight.Bold)
                            Text(
                                "You can continue using CardLink QR Code Studio for contactless sharing.",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            Button(onClick = onOpenQrStudio, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                                Text(stringResource(R.string.nfc_create_qr_instead), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    return@Column
                }
                NfcHardwareState.DISABLED -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null, tint = Color(0xFFF59E0B))
                            Text(stringResource(R.string.nfc_status_off), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                runCatching { context.startActivity(Intent(Settings.ACTION_NFC_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }) { Text(stringResource(R.string.nfc_open_settings), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        }
                    }
                }
                NfcHardwareState.READY -> Unit
            }

            TabRow(selectedTabIndex = activeTab) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text(stringResource(R.string.nfc_read_short), fontSize = 12.5.sp, fontWeight = FontWeight.Bold) })
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text(stringResource(R.string.nfc_write_short), fontSize = 12.5.sp, fontWeight = FontWeight.Bold) })
                Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("Projects (${savedProjects.size})", fontSize = 12.5.sp, fontWeight = FontWeight.Bold) })
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Armed NFC Pulse Card
                if (armMode != NfcArmMode.NONE) {
                    val pulse = rememberInfiniteTransition(label = "nfc_pulse").animateFloat(
                        initialValue = 0.92f,
                        targetValue = 1.10f,
                        animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
                        label = "nfc_scale"
                    )
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Contactless,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(44.dp).scale(pulse.value)
                            )
                            Text(stringResource(R.string.nfc_hold_tag_near), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                text = when (armMode) {
                                    NfcArmMode.READ -> "Hold any compatible NFC tag near your phone"
                                    NfcArmMode.WRITE -> "Writing & verifying (${preparedMessage?.toByteArray()?.size ?: 0} bytes)…"
                                    NfcArmMode.TEST_TAG -> "Remove and tap the tag again to test verification"
                                    NfcArmMode.CLEAR -> "Hold writable NDEF tag to clear content"
                                    NfcArmMode.LOCK_READ_ONLY -> "Hold NDEF tag to permanently lock as Read-Only"
                                    NfcArmMode.NONE -> ""
                                },
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            TextButton(onClick = { armMode = NfcArmMode.NONE }) {
                                Text(stringResource(R.string.action_cancel), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Operation Result Banner (with Test Tag & Create QR Fallback when relevant)
                lastOperationResult?.let { res ->
                    when (res) {
                        is NfcOperationResult.WriteVerified -> {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.2.dp, Color(0xFF10B981))) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(stringResource(R.string.nfc_tag_ready), fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                    Text("Written and verified (${res.bytesWritten} / ${res.maxBytes} bytes).", style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { armMode = NfcArmMode.TEST_TAG }, modifier = Modifier.weight(1f)) {
                                            Text("Test Tag", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(onClick = { showSaveProjectDialog = true }, modifier = Modifier.weight(1f)) {
                                            Text("Save Project", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        is NfcOperationResult.TestTagResult -> {
                            val ok = res.matches
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.2.dp, if (ok) Color(0xFF10B981) else MaterialTheme.colorScheme.error)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = if (ok) "Verified — Exact Match" else "Content Does Not Match",
                                        fontWeight = FontWeight.Bold,
                                        color = if (ok) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = if (ok) "The tag was scanned again and matches your written content." else "Please rewrite the tag and hold it steady.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                        is NfcOperationResult.CapacityExceeded -> {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.error)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(stringResource(R.string.nfc_tag_too_small), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    Text("Prepared: ${res.neededBytes} bytes • Available: ${res.maxBytes} bytes. Use a shorter Sharing Profile, a URL, or create a QR code instead.", style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = {
                                        NfcStudioEngine.toQrProject(projectName, selectedType, rawInput, projectedCard, sharingProfile)?.let { qr ->
                                            onCreateQrFallback(qr)
                                        } ?: onOpenQrStudio()
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Text(stringResource(R.string.nfc_create_qr_instead), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        is NfcOperationResult.ClearedVerified -> {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF10B981))) {
                                Text("NFC Tag cleared and verified empty.", modifier = Modifier.padding(14.dp), color = Color(0xFF10B981), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        is NfcOperationResult.MadeReadOnly -> {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFF10B981))) {
                                Text("NFC Tag is now permanently Read-Only.", modifier = Modifier.padding(14.dp), color = Color(0xFF10B981), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        is NfcOperationResult.Failure -> {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(res.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                    if (preparedMessage != null) {
                                        TextButton(onClick = { armMode = NfcArmMode.WRITE }, contentPadding = PaddingValues(0.dp)) {
                                            Text("Try Again", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        is NfcOperationResult.ReadSuccess -> Unit
                    }
                }

                when (activeTab) {
                    // =========================================================
                    // TAB 0: READ NFC & TAG INSPECTOR
                    // =========================================================
                    0 -> {
                        Button(
                            onClick = {
                                lastOperationResult = null
                                armMode = NfcArmMode.READ
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Default.Contactless, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (lastInspection == null) stringResource(R.string.nfc_read_short) else "Scan Another Tag", fontWeight = FontWeight.Bold)
                        }

                        lastInspection?.let { insp ->
                            if (insp.tagState == NfcTagState.PROTECTED_ISO_DEP && insp.parsedRecords.isEmpty()) {
                                // Protected / Application-Specific Card (Payment / Access / Transit)
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(stringResource(R.string.nfc_protected_card_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text(
                                            "This card uses a secure or application-specific NFC protocol. CardLink will not attempt to bypass its protection.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            } else {
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(stringResource(R.string.nfc_tag_detected), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            Text(insp.classifiedType.label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                        if (insp.classifiedType == NfcClassifiedType.UNKNOWN_CONTENT) {
                                            Text("CardLink read this NFC tag, but the content type is not recognized.", style = MaterialTheme.typography.bodySmall)
                                        }
                                        if (insp.primaryPayload.isNotBlank()) {
                                            Text(insp.primaryPayload.take(300), style = MaterialTheme.typography.bodyMedium)
                                        } else {
                                            Text("Empty or non-NDEF tag (${insp.tagState.label}).", style = MaterialTheme.typography.bodySmall)
                                        }

                                        // Safe User-Initiated Actions (NEVER auto-executed!)
                                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (insp.classifiedType == NfcClassifiedType.WEBSITE || insp.classifiedType == NfcClassifiedType.SOCIAL_PROFILE) {
                                                Button(onClick = {
                                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(insp.primaryPayload)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                                }) { Text("Open Link", fontSize = 12.sp) }
                                            }
                                            if (insp.classifiedType == NfcClassifiedType.VCARD_CONTACT) {
                                                Button(onClick = {
                                                    val c = CardShareHelper.parseVCardToContact(insp.primaryPayload, "NFC Tag")
                                                    onSaveContactFromNfc(c)
                                                    Toast.makeText(context, "Saved ${c.fullName} to Contacts!", Toast.LENGTH_LONG).show()
                                                }) { Text("Save Contact", fontSize = 12.sp) }
                                            }
                                            if (insp.primaryPayload.isNotBlank()) {
                                                OutlinedButton(onClick = {
                                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                                    cm?.setPrimaryClip(ClipData.newPlainText("NFC Content", insp.primaryPayload))
                                                    Toast.makeText(context, "Copied!", Toast.LENGTH_SHORT).show()
                                                }) { Text("Copy", fontSize = 12.sp) }
                                            }
                                        }
                                    }
                                }
                            }

                            // Collapsible Technical Details / Tag Inspector
                            OutlinedButton(onClick = { showTechDetails = !showTechDetails }, modifier = Modifier.fillMaxWidth()) {
                                Text(stringResource(R.string.nfc_tech_details))
                                Spacer(Modifier.width(6.dp))
                                Icon(if (showTechDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                            }
                            AnimatedVisibility(visible = showTechDetails) {
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Forum Type: ${insp.nfcForumType}", style = MaterialTheme.typography.bodySmall)
                                        Text("State: ${insp.tagState.label} • Writable: ${if (insp.isWritable) "Yes" else "No"}", style = MaterialTheme.typography.bodySmall)
                                        Text("Technologies: ${insp.techList.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                                        Text("Capacity: ${insp.usedBytes} / ${insp.maxSizeBytes} bytes • Records: ${insp.recordCount}", style = MaterialTheme.typography.bodySmall)
                                        if (insp.rawUidHex.isNotBlank()) {
                                            Text("Technical UID (metadata only): ${insp.rawUidHex}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // =========================================================
                    // TAB 1: WRITE NFC
                    // =========================================================
                    1 -> {
                        Text("What would you like to write?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                        val primaryTypes = listOf(NfcContentType.SHARING_PROFILE, NfcContentType.URL, NfcContentType.VCARD, NfcContentType.TEXT)
                        val extraTypes = NfcContentType.values().filterNot { it in primaryTypes }

                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            primaryTypes.forEach { t ->
                                FilterChip(selected = selectedType == t, onClick = { selectedType = t }, label = { Text(t.label, fontSize = 11.5.sp) })
                            }
                            FilterChip(selected = showMoreTypes, onClick = { showMoreTypes = !showMoreTypes }, label = { Text("More", fontSize = 11.5.sp) })
                        }
                        AnimatedVisibility(visible = showMoreTypes) {
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                extraTypes.forEach { t ->
                                    FilterChip(selected = selectedType == t, onClick = { selectedType = t }, label = { Text(t.label, fontSize = 11.5.sp) })
                                }
                            }
                        }

                        if (selectedType == NfcContentType.SHARING_PROFILE || selectedType == NfcContentType.VCARD) {
                            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                SharingProfileType.values().forEach { p ->
                                    FilterChip(
                                        selected = sharingProfile == p,
                                        onClick = {
                                            sharingProfile = p
                                            SharingProfileManager.setActiveProfile(context, p)
                                        },
                                        label = { Text(p.label, fontSize = 11.5.sp) }
                                    )
                                }
                            }
                            SmartPrivacyPreviewCard(card = projectedCard, onUpdateSharingPreferences = onUpdateCardSharing)
                        } else {
                            OutlinedTextField(
                                value = rawInput,
                                onValueChange = { rawInput = it },
                                label = { Text("${selectedType.label} Content *") },
                                singleLine = selectedType != NfcContentType.TEXT,
                                minLines = if (selectedType == NfcContentType.TEXT) 3 else 1,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        val previewBuild = remember(selectedType, rawInput, projectedCard, sharingProfile) {
                            NfcStudioEngine.buildNdefMessage(selectedType, rawInput, projectedCard, sharingProfile)
                        }
                        val encodedBytes = previewBuild.getOrNull()?.toByteArray()?.size ?: 0
                        val compatTier = remember(selectedType, projectedCard) {
                            val hasHttps = projectedCard.resolveNfcShareUrl().startsWith("https://", true)
                            androidNfcAdapter.classifyInteroperability(selectedType, hasHttps)
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Devices, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "${stringResource(R.string.nfc_compat_label)}: ${stringResource(compatTier.labelRes)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        if (encodedBytes > 0) {
                            Text("Encoded NDEF Size: $encodedBytes bytes (UTF-8 + headers)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                previewBuild.onSuccess { msg ->
                                    preparedMessage = msg
                                    lastOperationResult = null
                                    armMode = NfcArmMode.WRITE
                                }.onFailure { err ->
                                    Toast.makeText(context, err.localizedMessage ?: "Enter valid content first.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Default.Nfc, null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.nfc_write_tab), fontWeight = FontWeight.Bold)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showSaveProjectDialog = true }, modifier = Modifier.weight(1f)) {
                                Text("Save Project", fontSize = 12.sp)
                            }
                            OutlinedButton(onClick = {
                                NfcStudioEngine.toQrProject(projectName, selectedType, rawInput, projectedCard, sharingProfile)?.let { qr ->
                                    onCreateQrFallback(qr)
                                } ?: onOpenQrStudio()
                            }, modifier = Modifier.weight(1f)) {
                                Text("Create QR", fontSize = 12.sp)
                            }
                        }
                    }

                    // =========================================================
                    // TAB 2: SAVED NFC PROJECTS
                    // =========================================================
                    else -> {
                        if (savedProjects.isEmpty()) {
                            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Nfc, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
                                    Text("No Saved NFC Projects Yet", fontWeight = FontWeight.Bold)
                                    Text("Save your business card, conference profile, or website links here to rewrite onto NFC tags anytime.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                                }
                            }
                        } else {
                            savedProjects.forEach { proj ->
                                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (proj.isFavorite) Icons.Default.Star else Icons.Default.Nfc,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(proj.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(proj.contentType, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        TextButton(onClick = {
                                            selectedType = runCatching { NfcContentType.valueOf(proj.contentType) }.getOrDefault(NfcContentType.URL)
                                            rawInput = proj.payload
                                            projectName = proj.name
                                            activeTab = 1
                                        }) { Text("Write", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                                        IconButton(onClick = { projectMoreTarget = proj }) {
                                            Icon(Icons.Default.MoreVert, contentDescription = "More project options")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Advanced NFC More Sheet (Clear Tag, Make Read-Only)
    if (showReadMoreSheet) {
        CardLinkActionSheet(
            title = "Advanced NFC Actions",
            actions = listOf(
                CardLinkSheetAction(Icons.Default.CleaningServices, "Clear NFC Tag") { showClearConfirm = true },
                CardLinkSheetAction(Icons.Default.Lock, "Make Tag Permanently Read-Only", isDestructive = true) { showLockReadOnlyConfirm = true }
            ),
            onDismiss = { showReadMoreSheet = false }
        )
    }

    // Saved NFC Project ⋮ More Sheet
    projectMoreTarget?.let { proj ->
        CardLinkActionSheet(
            title = proj.name,
            actions = listOf(
                CardLinkSheetAction(if (proj.isFavorite) Icons.Default.StarBorder else Icons.Default.Star, if (proj.isFavorite) "Remove Favorite" else "Favorite") {
                    onSaveProject(proj.copy(isFavorite = !proj.isFavorite, updatedAtTimestamp = System.currentTimeMillis()))
                },
                CardLinkSheetAction(Icons.Default.QrCode2, "Create QR from This Project") {
                    val t = runCatching { NfcContentType.valueOf(proj.contentType) }.getOrDefault(NfcContentType.URL)
                    NfcStudioEngine.toQrProject(proj.name, t, proj.payload, projectedCard, sharingProfile)?.let { onCreateQrFallback(it) }
                },
                CardLinkSheetAction(Icons.Default.ContentCopy, "Duplicate") {
                    onSaveProject(proj.copy(id = 0L, stableUuid = java.util.UUID.randomUUID().toString(), name = "${proj.name} (Copy)"))
                },
                CardLinkSheetAction(Icons.Default.Delete, stringResource(R.string.action_delete), isDestructive = true) {
                    onDeleteProject(proj)
                }
            ),
            onDismiss = { projectMoreTarget = null }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear NFC Tag?", fontWeight = FontWeight.Bold) },
            text = { Text("This will remove the current compatible NDEF content from the tag.") },
            confirmButton = { Button(onClick = { showClearConfirm = false; armMode = NfcArmMode.CLEAR }) { Text("Clear Tag") } },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showLockReadOnlyConfirm) {
        AlertDialog(
            onDismissRequest = { showLockReadOnlyConfirm = false },
            title = { Text("Make NFC Tag Permanently Read-Only?", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = { Text("This action may be permanent. You may not be able to edit this NFC tag again.") },
            confirmButton = {
                Button(
                    onClick = { showLockReadOnlyConfirm = false; armMode = NfcArmMode.LOCK_READ_ONLY },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Lock Permanently") }
            },
            dismissButton = { TextButton(onClick = { showLockReadOnlyConfirm = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showSaveProjectDialog) {
        var nameInput by remember(projectName) { mutableStateOf(projectName.ifBlank { selectedType.label }) }
        AlertDialog(
            onDismissRequest = { showSaveProjectDialog = false },
            title = { Text("Save NFC Project", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Project Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                Button(onClick = {
                    val trimmed = nameInput.trim().ifBlank { selectedType.label }
                    onSaveProject(NfcProjectEntity(name = trimmed, contentType = selectedType.name, payload = rawInput.trim(), sharingProfileId = sharingProfile.id))
                    showSaveProjectDialog = false
                    Toast.makeText(context, "NFC project saved!", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showSaveProjectDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("NFC Compatibility & Guidance", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• Supported Standards: NFC Forum NDEF (Types 1–5), NFC-A, NFC-B, NFC-F, NFC-V, and ISO-DEP detection.", style = MaterialTheme.typography.bodySmall)
                    Text("• Protected Cards: Bank, transit, and secure access cards use protected protocols. CardLink will not attempt to bypass or clone them.", style = MaterialTheme.typography.bodySmall)
                    Text("• Capacity: Actual usable space is smaller than marketing capacity due to NDEF headers and UTF-8 encoding.", style = MaterialTheme.typography.bodySmall)
                    Text("• Why NFC Differs on iPhone: Android and iPhone use different NFC frameworks (Android NFC vs Apple Core NFC). Standard HTTPS NDEF links provide the broadest cross-platform compatibility, while low-level or protected card protocols are restricted on iPhone.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showHelpDialog = false }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
