package com.cardlink.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.*
import com.cardlink.app.ui.components.SmartPrivacyPreviewCard
import com.cardlink.app.ui.components.VaultImage
import com.cardlink.app.util.*
import kotlinx.serialization.json.Json
import java.net.URLEncoder

@Composable
fun SendMyCardBackDialog(
    recipient: SavedContactEntity,
    activeCard: BusinessCardEntity,
    onUpdateSharingPreferences: (BusinessCardEntity) -> Unit,
    onSavePendingDraft: (PendingDraftEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var sharingProfile by remember { mutableStateOf(SharingProfileManager.getActiveProfile(context)) }
    val effectiveCard = remember(activeCard, sharingProfile) {
        SharingProfileManager.applyProfile(activeCard, sharingProfile)
    }

    val hasPhone = recipient.whatsapp.ifBlank { recipient.phone }.isNotBlank()
    val hasEmail = recipient.email.isNotBlank()

    var selectedChannel by remember {
        mutableStateOf(
            when {
                hasPhone -> "WHATSAPP"
                hasEmail -> "EMAIL"
                else -> "SHARESHEET"
            }
        )
    }
    var selectedFormat by remember { mutableStateOf("VCF") }
    var selectedTemplateIdx by remember { mutableIntStateOf(0) }
    val templates = MessageTemplateHelper.defaultTemplates
    val activeTemplate = templates[selectedTemplateIdx.coerceIn(0, templates.lastIndex)]

    var messageBody by remember(selectedTemplateIdx, recipient.fullName, effectiveCard.fullName) {
        mutableStateOf(activeTemplate.buildBody(recipient, effectiveCard.fullName, effectiveCard.companyName))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(stringResource(R.string.send_my_card_back_title), fontWeight = FontWeight.Bold)
                Text(
                    "To: ${recipient.fullName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Channel", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (hasPhone) {
                        FilterChip(selected = selectedChannel == "WHATSAPP", onClick = { selectedChannel = "WHATSAPP" }, label = { Text("WhatsApp", fontSize = 11.sp) })
                        FilterChip(selected = selectedChannel == "SMS", onClick = { selectedChannel = "SMS" }, label = { Text("SMS", fontSize = 11.sp) })
                    }
                    if (hasEmail) {
                        FilterChip(selected = selectedChannel == "EMAIL", onClick = { selectedChannel = "EMAIL" }, label = { Text("Email", fontSize = 11.sp) })
                    }
                    FilterChip(selected = selectedChannel == "SHARESHEET", onClick = { selectedChannel = "SHARESHEET" }, label = { Text("Other App", fontSize = 11.sp) })
                }

                Text("Card Format", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("VCF" to "Contact / VCF", "LINK" to "Digital Link", "IMAGE" to "Card Image", "PDF" to "PDF", "HTML" to "HTML Card").forEach { (code, lbl) ->
                        FilterChip(selected = selectedFormat == code, onClick = { selectedFormat = code }, label = { Text(lbl, fontSize = 11.sp) })
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    templates.forEachIndexed { idx, tpl ->
                        FilterChip(
                            selected = selectedTemplateIdx == idx,
                            onClick = { selectedTemplateIdx = idx },
                            label = { Text(tpl.title.substringAfter(". ").take(18), fontSize = 10.5.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = messageBody,
                    onValueChange = { messageBody = it },
                    label = { Text("Message Preview") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                SmartPrivacyPreviewCard(
                    card = effectiveCard,
                    onUpdateSharingPreferences = { updated ->
                        sharingProfile = SharingProfileType.CUSTOM
                        SharingProfileManager.setActiveProfile(context, SharingProfileType.CUSTOM)
                        onUpdateSharingPreferences(updated)
                    }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val targetPhone = recipient.whatsapp.ifBlank { recipient.phone }.filter { it.isDigit() || it == '+' }
                when (selectedFormat) {
                    "VCF" -> CardShareHelper.shareVCardFile(context, effectiveCard)
                    "IMAGE" -> CardShareHelper.shareCardAsPng(context, effectiveCard)
                    "PDF" -> CardShareHelper.shareCardAsPdf(context, effectiveCard)
                    "HTML" -> PremiumExtrasHelper.shareClickableHtmlCard(context, effectiveCard)
                    else -> {
                        val link = effectiveCard.resolveNfcShareUrl()
                        val fullMsg = if (link.isNotBlank()) "$messageBody\n\n$link" else messageBody
                        when (selectedChannel) {
                            "WHATSAPP" -> {
                                val waNum = targetPhone.trimStart('+')
                                val encoded = URLEncoder.encode(fullMsg, "UTF-8")
                                val uri = Uri.parse("https://wa.me/$waNum?text=$encoded")
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }
                            "EMAIL" -> {
                                val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${recipient.email}")).apply {
                                    putExtra(Intent.EXTRA_SUBJECT, activeTemplate.buildSubject(recipient, effectiveCard.fullName, effectiveCard.companyName))
                                    putExtra(Intent.EXTRA_TEXT, fullMsg)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                runCatching { context.startActivity(mail) }
                            }
                            "SMS" -> {
                                val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$targetPhone")).apply {
                                    putExtra("sms_body", fullMsg)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                runCatching { context.startActivity(sms) }
                            }
                            else -> {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, fullMsg)
                                }
                                runCatching { context.startActivity(Intent.createChooser(share, "Send My Card Back").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }
                        }
                    }
                }
                onDismiss()
            }) { Text(stringResource(R.string.send_my_card_back_title), fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    onSavePendingDraft(
                        PendingDraftEntity(
                            contactId = recipient.id,
                            contactName = recipient.fullName,
                            channel = selectedChannel,
                            recipientAddress = recipient.whatsapp.ifBlank { recipient.phone }.ifBlank { recipient.email },
                            subject = activeTemplate.buildSubject(recipient, effectiveCard.fullName, effectiveCard.companyName),
                            messageBody = messageBody,
                            attachmentFormat = selectedFormat
                        )
                    )
                    Toast.makeText(context, "Saved as Ready-to-Send draft!", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }) { Text("Save Draft", fontSize = 12.sp) }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConferenceReviewQueueScreen(
    queueItems: List<ConferenceQueueEntity>,
    activeCard: BusinessCardEntity,
    onBatchSaveReady: (List<ConferenceQueueEntity>) -> Unit,
    onSaveSingleQueueItem: (ConferenceQueueEntity, SavedContactEntity) -> Unit,
    onDeleteQueueItem: (ConferenceQueueEntity) -> Unit,
    onClearQueue: () -> Unit,
    onNavigateToScanner: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val json = remember { Json { ignoreUnknownKeys = true } }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var reviewingItem by remember { mutableStateOf<ConferenceQueueEntity?>(null) }

    val readyCount = queueItems.count { it.queueStatus == "READY" }
    val reviewCount = queueItems.count { it.queueStatus == "NEEDS_REVIEW" }
    val dupCount = queueItems.count { it.queueStatus == "POSSIBLE_DUPLICATE" }
    val failedCount = queueItems.count { it.queueStatus == "FAILED" }

    val filteredItems = remember(queueItems, selectedFilter) {
        if (selectedFilter == "ALL") queueItems else queueItems.filter { it.queueStatus == selectedFilter }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.conf_queue_title), fontWeight = FontWeight.Bold)
                        Text(
                            "${queueItems.size} card(s) in queue",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToScanner) {
                        Icon(Icons.Default.DocumentScanner, contentDescription = "Continue Scanning")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Event Summary", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Captured: ${queueItems.size}  •  Ready: $readyCount  •  Need Review: $reviewCount  •  Duplicates: $dupCount", style = MaterialTheme.typography.bodySmall)
                    if (readyCount > 0) {
                        Button(
                            onClick = {
                                val readyItems = queueItems.filter { it.queueStatus == "READY" }
                                onBatchSaveReady(readyItems)
                                Toast.makeText(context, "Saved $readyCount ready contact(s)!", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Ready Contacts ($readyCount)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "ALL" to "All (${queueItems.size})",
                    "READY" to "Ready ($readyCount)",
                    "NEEDS_REVIEW" to "Needs Review ($reviewCount)",
                    "POSSIBLE_DUPLICATE" to "Duplicates ($dupCount)",
                    "FAILED" to "Failed ($failedCount)"
                ).forEach { (key, lbl) ->
                    FilterChip(selected = selectedFilter == key, onClick = { selectedFilter = key }, label = { Text(lbl, fontSize = 11.sp) })
                }
            }

            if (filteredItems.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No cards in this queue filter.", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = onNavigateToScanner) { Text("Capture Business Cards") }
                    }
                }
            } else {
                filteredItems.forEach { item ->
                    val statusColor = when (item.queueStatus) {
                        "READY" -> Color(0xFF10B981)
                        "POSSIBLE_DUPLICATE", "NEEDS_REVIEW" -> Color(0xFFF59E0B)
                        "FAILED" -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.primary
                    }
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (item.encryptedFrontUri.isNotBlank()) {
                                VaultImage(
                                    uriString = item.encryptedFrontUri,
                                    contentDescription = "Card thumbnail",
                                    contentScale = ContentScale.Crop,
                                    maxEdgePx = 280,
                                    modifier = Modifier.size(width = 72.dp, height = 46.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.suggestedName.ifBlank { "Captured Card" }, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (item.suggestedCompany.isNotBlank()) {
                                    Text(item.suggestedCompany, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(item.queueStatus.replace('_', ' '), style = MaterialTheme.typography.labelSmall, color = statusColor, fontWeight = FontWeight.Bold)
                            }
                            TextButton(onClick = { reviewingItem = item }) { Text("Review", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            IconButton(onClick = { onDeleteQueueItem(item) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }

            if (queueItems.isNotEmpty()) {
                TextButton(
                    onClick = onClearQueue,
                    modifier = Modifier.align(Alignment.End)
                ) { Text("Finish Event & Clear Queue", color = MaterialTheme.colorScheme.error) }
            }
        }
    }

    reviewingItem?.let { item ->
        val initialContact = remember(item) {
            runCatching { json.decodeFromString(SavedContactEntity.serializer(), item.parsedContactJson) }
                .getOrElse { SavedContactEntity(fullName = item.suggestedName, companyName = item.suggestedCompany, profilePhotoUri = item.encryptedFrontUri, backPhotoUri = item.encryptedBackUri) }
        }
        var name by remember(item) { mutableStateOf(initialContact.fullName) }
        var designation by remember(item) { mutableStateOf(initialContact.designation) }
        var company by remember(item) { mutableStateOf(initialContact.companyName) }
        var phone by remember(item) { mutableStateOf(initialContact.phone) }
        var email by remember(item) { mutableStateOf(initialContact.email) }

        AlertDialog(
            onDismissRequest = { reviewingItem = null },
            title = { Text(stringResource(R.string.review_contact_title), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (item.duplicateReason.isNotBlank()) {
                        Text("⚠ ${item.duplicateReason}", color = Color(0xFFF59E0B), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = designation, onValueChange = { designation = it }, label = { Text("Designation") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Company") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile / Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val finalContact = initialContact.copy(
                        fullName = name.trim().ifBlank { "Scanned Contact" },
                        designation = designation.trim(),
                        companyName = company.trim(),
                        phone = phone.trim(),
                        email = email.trim(),
                        profilePhotoUri = item.encryptedFrontUri,
                        backPhotoUri = item.encryptedBackUri
                    )
                    onSaveSingleQueueItem(item, finalContact)
                    reviewingItem = null
                }) { Text(stringResource(R.string.ocr_save_contact)) }
            },
            dismissButton = { TextButton(onClick = { reviewingItem = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkingInboxScreen(
    contacts: List<SavedContactEntity>,
    followUps: List<FollowUpEntity>,
    queueItems: List<ConferenceQueueEntity>,
    pendingDrafts: List<PendingDraftEntity>,
    onOpenFollowUps: () -> Unit,
    onOpenConferenceQueue: () -> Unit,
    onOpenDataQuality: () -> Unit,
    onDeleteDraft: (PendingDraftEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val now = remember { System.currentTimeMillis() }
    val dueFollowUps = remember(followUps, now) { followUps.count { !it.isCompleted && it.dueAtTimestamp <= now + 24L * 3600_000L } }
    val dupCount = remember(contacts) { SmartDuplicateDetector.findDuplicatePairs(contacts).size }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Networking Inbox", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (queueItems.isNotEmpty()) {
                InboxSummaryCard(Icons.Default.Queue, "${queueItems.size} Conference Card(s) Awaiting Review", "Review Queue", onOpenConferenceQueue)
            }
            if (dueFollowUps > 0) {
                InboxSummaryCard(Icons.Default.Event, "$dueFollowUps Follow-Up(s) Due or Upcoming", "Review", onOpenFollowUps)
            }
            if (dupCount > 0) {
                InboxSummaryCard(Icons.Default.PeopleAlt, "$dupCount Possible Duplicate Contact Pair(s)", "Resolve", onOpenDataQuality)
            }

            if (pendingDrafts.isNotEmpty()) {
                Text("${pendingDrafts.size} Prepared Message(s) Ready to Send", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                pendingDrafts.forEach { draft ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("To: ${draft.contactName} (${draft.channel})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(stringResource(R.string.ready_to_send_badge), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Text(draft.messageBody.take(140), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { onDeleteDraft(draft) }) { Text("Remove", color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                                Button(onClick = {
                                    val share = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, draft.messageBody)
                                    }
                                    runCatching { context.startActivity(Intent.createChooser(share, "Send Prepared Message").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                }) { Text("Open & Send", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }

            if (queueItems.isEmpty() && dueFollowUps == 0 && dupCount == 0 && pendingDrafts.isEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF10B981), modifier = Modifier.size(40.dp))
                        Text("Your Networking Inbox is Clear", fontWeight = FontWeight.Bold)
                        Text("Scanned conference cards, pending Follow-Ups, and prepared return-card messages appear here.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun InboxSummaryCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, cta: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(cta, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
// =============================================================================
// 4. DEDICATED CONCISE MEETING BRIEF SCREEN (15-Min Pre-Meeting Context)
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeetingBriefScreen(
    contact: SavedContactEntity,
    followUps: List<FollowUpEntity>,
    mySenderName: String,
    onToggleFollowUp: (FollowUpEntity) -> Unit,
    onOpenScheduleMeeting: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val dateFmt = remember { java.text.SimpleDateFormat("EEE, dd MMM • hh:mm a", java.util.Locale.getDefault()) }
    val shortFmt = remember { java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()) }
    val upcoming = remember(followUps) { followUps.filterNot { it.isCompleted }.minByOrNull { it.dueAtTimestamp } }
    val primaryPhone = contact.phone.ifBlank { contact.whatsapp }
    val waTarget = contact.whatsapp.ifBlank { contact.phone }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.meeting_brief_title), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(contact.fullName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    val role = listOf(contact.designation, contact.companyName).filter { it.isNotBlank() }.joinToString(" • ")
                    if (role.isNotBlank()) Text(role, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Text("First Met: ${shortFmt.format(java.util.Date(contact.savedAtTimestamp))}", style = MaterialTheme.typography.bodySmall)
                    if (contact.meetingContext.isNotBlank()) Text("Context: ${contact.meetingContext}", style = MaterialTheme.typography.bodySmall)
                    if (contact.lastContactedTimestamp > 0L) Text("Last Contacted: ${shortFmt.format(java.util.Date(contact.lastContactedTimestamp))}", style = MaterialTheme.typography.bodySmall)
                }
            }

            if (upcoming != null) {
                val methodLbl = MeetingMethodOption.values().firstOrNull { it.code == upcoming.meetingMethod }?.label ?: "Meeting"
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Next Scheduled Follow-Up", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.5.sp)
                        Text(upcoming.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${dateFmt.format(java.util.Date(upcoming.dueAtTimestamp))} • $methodLbl", style = MaterialTheme.typography.bodySmall)
                        if (upcoming.meetingAgenda.isNotBlank()) Text("Agenda: ${upcoming.meetingAgenda}", style = MaterialTheme.typography.bodySmall)
                        if (upcoming.meetingLink.isNotBlank()) {
                            OutlinedButton(
                                onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(upcoming.meetingLink)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Open Meeting Link") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onToggleFollowUp(upcoming) }, modifier = Modifier.weight(1f)) { Text("Complete") }
                            OutlinedButton(onClick = onOpenScheduleMeeting, modifier = Modifier.weight(1f)) { Text("Reschedule") }
                        }
                    }
                }
            }

            if (contact.notes.isNotBlank()) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Latest Private Note", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        Text(contact.notes.take(280), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (primaryPhone.isNotBlank()) {
                    Button(onClick = { ContactActionLauncher.launchDialer(context, primaryPhone) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_call)) }
                }
                if (waTarget.isNotBlank()) {
                    Button(onClick = { ContactActionLauncher.launchWhatsAppChat(context, waTarget, contact.fullName) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_whatsapp_full)) }
                }
                if (contact.email.isNotBlank()) {
                    Button(onClick = { ContactActionLauncher.launchEmailComposer(context, contact.email, contact.fullName, mySenderName) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.detail_email)) }
                }
            }
        }
    }
}
