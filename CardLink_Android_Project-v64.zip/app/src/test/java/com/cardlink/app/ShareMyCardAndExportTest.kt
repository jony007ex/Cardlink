package com.cardlink.app

import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.util.*
import org.junit.Assert.*
import org.junit.Test

class ShareMyCardAndExportTest {

    @Test
    fun sharingPriorityOrder_matchesExactQrFirstHierarchy() {
        val ordered = ShareMethodPriority.values().sortedBy { it.orderIndex }
        assertEquals(
            listOf(
                ShareMethodPriority.QR_CODE,
                ShareMethodPriority.QUICK_SHARE,
                ShareMethodPriority.NEARBY_SWAP,
                ShareMethodPriority.NFC,
                ShareMethodPriority.CONTACT_VCF
            ),
            ordered
        )
    }

    @Test
    fun canonicalRenderCacheKey_invalidatesImmediatelyOnTemplateColorOrProfileChange() {
        val base = BusinessCardEntity(
            id = 1L,
            fullName = "Md. Mazharul Islam",
            selectedTemplateId = "executive_navy_gold:v1",
            primaryColorHex = 0xFF0A192F,
            accentColorHex = 0xFFD4AF37
        )
        val keyA = CardLinkCanonicalRenderer.computeRenderCacheKey(base, "FRONT", ExportQualityTier.STANDARD)
        val keyTemplateB = CardLinkCanonicalRenderer.computeRenderCacheKey(
            base.copy(selectedTemplateId = "minimal_white:v1"),
            "FRONT",
            ExportQualityTier.STANDARD
        )
        val keyColorChanged = CardLinkCanonicalRenderer.computeRenderCacheKey(
            base.copy(primaryColorHex = 0xFF1E3A8A),
            "FRONT",
            ExportQualityTier.STANDARD
        )
        val keyBackSide = CardLinkCanonicalRenderer.computeRenderCacheKey(base, "BACK", ExportQualityTier.STANDARD)
        val keyHighRes = CardLinkCanonicalRenderer.computeRenderCacheKey(base, "FRONT", ExportQualityTier.HIGH_QUALITY)

        assertNotEquals(keyA, keyTemplateB)
        assertNotEquals(keyA, keyColorChanged)
        assertNotEquals(keyA, keyBackSide)
        assertNotEquals(keyA, keyHighRes)
    }

    @Test
    fun interactiveHtmlAndSharePackage_reflectActiveCardColorsAndEnforcePrivacyProfiles() {
        val base = BusinessCardProfileHelper.applyPhonesAndCredentials(
            card = BusinessCardEntity(
                fullName = "Md. Mazharul Islam",
                designation = "AVP",
                companyName = "IFIC Bank PLC",
                email = "work@ificbank.com",
                officeAddress = "IFIC Tower, Purana Paltan, Dhaka",
                linkedInUrl = "https://linkedin.com/in/mazharul",
                primaryColorHex = 0xFF1E3A8A,
                cardGradientEndHex = 0xFF0F172A,
                accentColorHex = 0xFF38BDF8
            ),
            phones = listOf(
                CardPhoneRecord(number = "+8801700799353", type = CardPhoneType.MOBILE, isPrimary = true, isWhatsAppEnabled = true, displayOrder = 0),
                CardPhoneRecord(number = "+88029562020", type = CardPhoneType.OFFICE, isPrimary = false, displayOrder = 1)
            ),
            credentials = listOf(
                CardCredentialRecord(label = "MBA", displayOrder = 0),
                CardCredentialRecord(label = "CIPS", displayOrder = 1)
            ),
            showCredentialsOnCard = true,
            shareCredentials = true
        )

        // Business profile: includes active colors, both phones, credentials, address
        val bizPkg = CardLinkCanonicalRenderer.buildSharePackage(base, SharingProfileType.BUSINESS, SharePackageContentType.INTERACTIVE_HTML)
        assertTrue(bizPkg.primaryPayload.contains("#1E3A8A"))
        assertTrue(bizPkg.primaryPayload.contains("#38BDF8"))
        assertTrue(bizPkg.primaryPayload.contains("MBA, CIPS"))
        assertTrue(bizPkg.primaryPayload.contains("+8801700799353"))
        assertTrue(bizPkg.primaryPayload.contains("+88029562020"))
        assertTrue(bizPkg.primaryPayload.contains("IFIC Tower"))

        // Conference profile: hides Phone, WhatsApp & Address across HTML, VCF & Text!
        val confPkgHtml = CardLinkCanonicalRenderer.buildSharePackage(base, SharingProfileType.CONFERENCE, SharePackageContentType.INTERACTIVE_HTML)
        assertFalse(confPkgHtml.primaryPayload.contains("+8801700799353"))
        assertFalse(confPkgHtml.primaryPayload.contains("IFIC Tower"))
        assertTrue(confPkgHtml.primaryPayload.contains("work@ificbank.com"))

        val confPkgText = CardLinkCanonicalRenderer.buildSharePackage(base, SharingProfileType.CONFERENCE, SharePackageContentType.MESSAGE_TEXT)
        assertFalse(confPkgText.primaryPayload.contains("+8801700799353"))
        assertTrue(confPkgText.primaryPayload.contains("work@ificbank.com"))

        // Networking profile: excludes credentials
        val netPkgHtml = CardLinkCanonicalRenderer.buildSharePackage(base, SharingProfileType.NETWORKING, SharePackageContentType.INTERACTIVE_HTML)
        assertFalse(netPkgHtml.primaryPayload.contains("CIPS"))
        assertTrue(netPkgHtml.primaryPayload.contains("+8801700799353"))
    }

    @Test
    fun interactiveHtmlExporter_escapesSpecialCharactersAndHandlesMissingOptionalFields() {
        val sparse = BusinessCardEntity(
            fullName = "A & B <Directors>",
            profilePhotoUri = null,
            companyLogoUri = null,
            phone = "",
            email = ""
        )
        val html = CardLinkCanonicalRenderer.buildInteractiveHtmlString(null, sparse)
        assertTrue(html.contains("A &amp; B &lt;Directors&gt;"))
        assertFalse(html.contains("<Directors>"))
        assertTrue(html.contains("Save Contact (.vcf)"))
    }


    @Test
    fun universalQrParser_extractsCardLinkPayloadProfileFieldsSafely() {
        val raw = "cardlink://v1/profile?name=Md.%20Mazharul%20Islam&title=AVP&org=IFIC%20Bank%20PLC&phone=%2B8801700799353&email=work%40ificbank.com"
        val parsed = UniversalQrParser.parse(raw)
        assertEquals(UniversalQrType.CARDLINK_PAYLOAD, parsed.type)
        assertNotNull(parsed.parsedContact)
        assertEquals("Md. Mazharul Islam", parsed.parsedContact?.fullName)
        assertEquals("IFIC Bank PLC", parsed.parsedContact?.companyName)
        assertEquals("+8801700799353", parsed.parsedContact?.phone)
        assertEquals("work@ificbank.com", parsed.parsedContact?.email)

        // Feeding it into Edit Business Card QR Import must yield structured profile fields
        val imported = BusinessCardProfileHelper.extractFromQrPayload(raw)
        assertTrue(imported.rawWarning.isBlank())
        assertEquals("Md. Mazharul Islam", imported.fullName)
        assertEquals("IFIC Bank PLC", imported.companyName)
        assertEquals(1, imported.phones.size)
    }


    @Test
    fun canonicalSharePrivacy_excludesCredentialsOnNetworkingProfileAndPreservesOnBusiness() {
        val base = BusinessCardProfileHelper.applyPhonesAndCredentials(
            card = BusinessCardEntity(fullName = "Md. Mazharul Islam"),
            phones = listOf(CardPhoneRecord(number = "+8801700799353", isPrimary = true)),
            credentials = listOf(CardCredentialRecord(label = "MBA"), CardCredentialRecord(label = "CIPS")),
            showCredentialsOnCard = true,
            shareCredentials = true
        )
        val biz = SharingProfileManager.applyProfile(base, SharingProfileType.BUSINESS)
        val net = SharingProfileManager.applyProfile(base, SharingProfileType.NETWORKING)

        assertEquals("MBA, CIPS", BusinessCardProfileHelper.formatCredentialsSuffix(biz, forSharing = true))
        assertEquals("", BusinessCardProfileHelper.formatCredentialsSuffix(net, forSharing = true))
        assertEquals("Md. Mazharul Islam, MBA, CIPS", BusinessCardProfileHelper.formatFullNameWithCredentials(base, forSharing = false))
    }
}
