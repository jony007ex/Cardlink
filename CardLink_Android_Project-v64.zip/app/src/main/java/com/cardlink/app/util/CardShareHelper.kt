package com.cardlink.app.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.cardlink.app.R
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.provider.ContactsContract
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

object CardShareHelper {

    private fun escapeVCardValue(raw: String): String = raw
        .replace("\\", "\\\\")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
        .replace("\r", "\\n")
        .replace(";", "\\;")
        .replace(",", "\\,")

    private fun splitStructuredName(fullName: String): Pair<String, String> {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return when {
            parts.isEmpty() -> "" to ""
            parts.size == 1 -> "" to parts[0]
            else -> parts.last() to parts.dropLast(1).joinToString(" ")
        }
    }

    fun toVCardString(card: BusinessCardEntity): String {
        val clean = card.sanitizedForSharing()
        val rawName = clean.fullName.trim().ifBlank { "CardLink Contact" }
        val credSuffix = BusinessCardProfileHelper.formatCredentialsSuffix(clean, forSharing = true)
        val displayFn = if (credSuffix.isNotBlank()) "$rawName, $credSuffix" else rawName
        val (lastName, firstName) = splitStructuredName(rawName)
        val lines = mutableListOf<String>()
        lines += "BEGIN:VCARD"
        lines += "VERSION:3.0"
        lines += "FN:${escapeVCardValue(displayFn)}"
        lines += "N:${escapeVCardValue(lastName)};${escapeVCardValue(firstName)};;;${escapeVCardValue(credSuffix)}"
        if (clean.companyName.isNotBlank() || clean.department.isNotBlank()) {
            val org = escapeVCardValue(clean.companyName.trim())
            val dept = escapeVCardValue(clean.department.trim())
            lines += if (dept.isNotBlank()) "ORG:$org;$dept" else "ORG:$org"
        }
        if (clean.designation.isNotBlank()) {
            lines += "TITLE:${escapeVCardValue(clean.designation.trim())}"
        }
        val shareablePhones = BusinessCardProfileHelper.getShareablePhoneNumbers(clean)
        if (shareablePhones.isNotEmpty()) {
            val emitted = mutableSetOf<String>()
            for (rec in shareablePhones) {
                val key = BusinessCardProfileHelper.normalizePhoneForComparison(rec.number)
                if (key.isBlank() || !emitted.add(key)) continue
                val telType = when (rec.type) {
                    CardPhoneType.MOBILE -> "CELL,VOICE"
                    CardPhoneType.WORK, CardPhoneType.OFFICE -> "WORK,VOICE"
                    CardPhoneType.WHATSAPP -> "CELL"
                    CardPhoneType.PERSONAL -> "HOME,VOICE"
                    CardPhoneType.OTHER -> "VOICE"
                }
                lines += "TEL;TYPE=$telType:${escapeVCardValue(rec.number.trim())}"
            }
        } else {
            if (clean.phone.isNotBlank()) {
                lines += "TEL;TYPE=WORK,VOICE:${escapeVCardValue(clean.phone.trim())}"
            }
            if (clean.whatsapp.isNotBlank()) {
                lines += "TEL;TYPE=CELL:${escapeVCardValue(clean.whatsapp.trim())}"
            }
        }
        if (clean.email.isNotBlank()) {
            lines += "EMAIL;TYPE=WORK,INTERNET:${escapeVCardValue(clean.email.trim())}"
        }
        if (clean.officeAddress.isNotBlank()) {
            lines += "ADR;TYPE=WORK:;;${escapeVCardValue(clean.officeAddress.trim())};;;;"
        }
        if (clean.latitude != null && clean.longitude != null) {
            lines += "GEO:${clean.latitude};${clean.longitude}"
        }
        val bestUrl = clean.publicCardUrl.ifBlank { clean.website }.trim()
        if (bestUrl.isNotBlank()) {
            lines += "URL:${escapeVCardValue(bestUrl)}"
        }
        if (clean.linkedInUrl.isNotBlank()) {
            lines += "X-SOCIALPROFILE;TYPE=linkedin:${escapeVCardValue(clean.linkedInUrl.trim())}"
        }
        if (clean.facebookUrl.isNotBlank()) {
            lines += "X-SOCIALPROFILE;TYPE=facebook:${escapeVCardValue(clean.facebookUrl.trim())}"
        }
        if (clean.otherSocialUrl.isNotBlank()) {
            lines += "X-SOCIALPROFILE;TYPE=other:${escapeVCardValue(clean.otherSocialUrl.trim())}"
        }
        if (clean.bio.isNotBlank()) {
            lines += "NOTE:${escapeVCardValue(clean.bio.trim())}"
        }
        lines += "END:VCARD"
        return lines.joinToString("\r\n") + "\r\n"
    }

    fun savedContactToVCardString(contact: SavedContactEntity): String {
        val displayFn = contact.fullName.trim().ifBlank { "CardLink Contact" }
        val (lastName, firstName) = splitStructuredName(displayFn)
        val lines = mutableListOf<String>()
        lines += "BEGIN:VCARD"
        lines += "VERSION:3.0"
        lines += "FN:${escapeVCardValue(displayFn)}"
        lines += "N:${escapeVCardValue(lastName)};${escapeVCardValue(firstName)};;;"
        if (contact.companyName.isNotBlank() || contact.department.isNotBlank()) {
            val org = escapeVCardValue(contact.companyName.trim())
            val dept = escapeVCardValue(contact.department.trim())
            lines += if (dept.isNotBlank()) "ORG:$org;$dept" else "ORG:$org"
        }
        if (contact.designation.isNotBlank()) lines += "TITLE:${escapeVCardValue(contact.designation.trim())}"
        if (contact.phone.isNotBlank()) lines += "TEL;TYPE=WORK,VOICE:${escapeVCardValue(contact.phone.trim())}"
        if (contact.whatsapp.isNotBlank()) lines += "TEL;TYPE=CELL:${escapeVCardValue(contact.whatsapp.trim())}"
        if (contact.email.isNotBlank()) lines += "EMAIL;TYPE=WORK,INTERNET:${escapeVCardValue(contact.email.trim())}"
        if (contact.officeAddress.isNotBlank()) lines += "ADR;TYPE=WORK:;;${escapeVCardValue(contact.officeAddress.trim())};;;;"
        if (contact.website.isNotBlank()) lines += "URL:${escapeVCardValue(contact.website.trim())}"
        if (contact.linkedInUrl.isNotBlank()) lines += "X-SOCIALPROFILE;TYPE=linkedin:${escapeVCardValue(contact.linkedInUrl.trim())}"
        if (contact.notes.isNotBlank()) lines += "NOTE:${escapeVCardValue(contact.notes.trim())}"
        lines += "END:VCARD"
        return lines.joinToString("\r\n") + "\r\n"
    }

    fun parseVCardToContact(vcf: String, source: String): SavedContactEntity {
        var fn = ""
        var org = ""
        var dept = ""
        var title = ""
        var phone = ""
        var whatsapp = ""
        var email = ""
        var address = ""
        var website = ""
        var linkedin = ""
        var facebook = ""
        var otherSocial = ""
        var bio = ""
        var lat: Double? = null
        var lng: Double? = null

        vcf.lines().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                line.startsWith("FN:", true) -> fn = line.substringAfter(":")
                line.startsWith("ORG:", true) -> {
                    val parts = line.substringAfter(":").split(";")
                    org = parts.getOrNull(0).orEmpty()
                    dept = parts.getOrNull(1).orEmpty()
                }
                line.startsWith("TITLE:", true) -> title = line.substringAfter(":")
                line.startsWith("TEL", true) && line.contains("WHATSAPP", true) ->
                    whatsapp = line.substringAfter(":")
                line.startsWith("TEL", true) -> if (phone.isEmpty()) phone = line.substringAfter(":")
                line.startsWith("EMAIL", true) -> email = line.substringAfter(":")
                line.startsWith("ADR", true) -> address = line.substringAfter(":").replace(";", " ").trim()
                line.startsWith("GEO:", true) -> {
                    val coords = line.substringAfter(":").split(";", ",")
                    lat = coords.getOrNull(0)?.trim()?.toDoubleOrNull()
                    lng = coords.getOrNull(1)?.trim()?.toDoubleOrNull()
                }
                line.startsWith("URL:", true) -> website = line.substringAfter(":")
                line.contains("linkedin", true) -> linkedin = line.substringAfter(":")
                line.contains("facebook", true) -> facebook = line.substringAfter(":")
                line.startsWith("X-SOCIALPROFILE", true) -> otherSocial = line.substringAfter(":")
                line.startsWith("NOTE:", true) -> bio = line.substringAfter(":")
            }
        }

        return SavedContactEntity(
            fullName = fn.ifBlank { "Unknown Contact" },
            designation = title,
            companyName = org,
            department = dept,
            bio = bio,
            phone = phone,
            whatsapp = whatsapp,
            email = email,
            officeAddress = address,
            latitude = lat,
            longitude = lng,
            website = website,
            linkedInUrl = linkedin,
            facebookUrl = facebook,
            otherSocialUrl = otherSocial,
            receivedVia = source
        )
    }

    /** Parses MECARD:N:Name;ORG:Company;TEL:123;EMAIL:a@b.com;; format */
    fun parseMeCardToContact(mecard: String, source: String): SavedContactEntity {
        val body = mecard.removePrefix("MECARD:").removePrefix("mecard:")
        var name = ""
        var org = ""
        var phone = ""
        var email = ""
        var url = ""
        var adr = ""
        body.split(";").forEach { token ->
            when {
                token.startsWith("N:", true) -> name = token.substringAfter(":").replace(",", " ").trim()
                token.startsWith("ORG:", true) -> org = token.substringAfter(":")
                token.startsWith("TEL:", true) -> phone = token.substringAfter(":")
                token.startsWith("EMAIL:", true) -> email = token.substringAfter(":")
                token.startsWith("URL:", true) -> url = token.substringAfter(":")
                token.startsWith("ADR:", true) -> adr = token.substringAfter(":")
            }
        }
        return SavedContactEntity(
            fullName = name.ifBlank { "QR Contact" },
            companyName = org,
            phone = phone,
            email = email,
            website = url,
            officeAddress = adr,
            receivedVia = source
        )
    }

    fun generateQrCodeBitmap(
        content: String,
        sizePx: Int = 700,
        foregroundColor: Int = Color.parseColor("#0A192F"),
        backgroundColor: Int = Color.WHITE
    ): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 2
        )
        val safeContent = content.ifBlank { "CardLink" }
        val bitMatrix = QRCodeWriter().encode(safeContent, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        for (y in 0 until sizePx) {
            for (x in 0 until sizePx) {
                pixels[y * sizePx + x] = if (bitMatrix[x, y]) foregroundColor else backgroundColor
            }
        }
        return Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        }
    }

    fun renderCardToBitmap(card: BusinessCardEntity): Bitmap {
        val width = 1050
        val height = 600
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.primaryColorHex.toInt() }
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 40f, 40f, bgPaint)

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt() }
        canvas.drawRect(0f, 0f, 24f, height.toFloat(), accentPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.textColorHex.toInt()
            textSize = 52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.accentColorHex.toInt()
            textSize = 30f
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = card.textColorHex.toInt()
            textSize = 25f
        }

        val clean = card.sanitizedForSharing()
        canvas.drawText(BusinessCardProfileHelper.formatFullNameWithCredentials(clean, forSharing = true).ifBlank { "Your Name" }, 70f, 110f, titlePaint)
        canvas.drawText("${clean.designation} • ${clean.companyName}", 70f, 165f, subtitlePaint)

        var yPos = 245f
        if (clean.phone.isNotBlank()) { canvas.drawText("Tel: ${clean.phone}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.email.isNotBlank()) { canvas.drawText("Email: ${clean.email}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.website.isNotBlank()) { canvas.drawText("Web: ${clean.website}", 70f, yPos, bodyPaint); yPos += 45f }
        if (clean.officeAddress.isNotBlank()) { canvas.drawText(clean.officeAddress, 70f, yPos, bodyPaint) }

        val qrBitmap = generateQrCodeBitmap(toVCardString(clean), 250, Color.BLACK, Color.WHITE)
        canvas.drawBitmap(qrBitmap, width - 310f, height - 310f, null)

        return bitmap
    }

    private fun prepareAndValidateVcfUri(
        context: Context,
        displayName: String,
        vcfContent: String
    ): Pair<Uri, String>? {
        if (!vcfContent.contains("BEGIN:VCARD") ||
            !vcfContent.contains("VERSION:") ||
            !vcfContent.contains("FN:") ||
            !vcfContent.contains("END:VCARD")
        ) {
            return null
        }
        return runCatching {
            val baseSlug = displayName.trim()
                .replace(Regex("\\s+"), "_")
                .replace(Regex("[^a-zA-Z0-9_-]"), "")
                .trim('_')
                .ifBlank { "Contact" }
            val fileName = "CardLink_$baseSlug"
            val vcfFile = TempSecureExportVault.createNamedTempExportFile(context, fileName, "vcf")
            vcfFile.writeText(vcfContent, Charsets.UTF_8)
            val uri = TempSecureExportVault.toShareUri(context, vcfFile)

            // Pre-share read-back verification through ContentResolver
            val readBack = context.contentResolver.openInputStream(uri)?.use { inp ->
                inp.bufferedReader(Charsets.UTF_8).readText()
            }.orEmpty()
            require(readBack.contains("BEGIN:VCARD") && readBack.contains("END:VCARD")) {
                "Pre-share VCF verification failed"
            }
            uri to vcfFile.name
        }.getOrNull()
    }

    private fun launchVcfSharesheet(context: Context, uri: Uri, fileName: String, title: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/x-vcard"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            // Attach URI via ClipData so Android 10-15+ propagates FileProvider read permission reliably to WhatsApp & all targets
            clipData = ClipData.newRawUri(fileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, context.getString(R.string.share_vcf_chooser_title)).apply {
            clipData = ClipData.newRawUri(fileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching {
            context.startActivity(chooser)
        }.onFailure {
            Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show()
        }
    }

    /** Sends vCard (.vcf) directly over Android Bluetooth (OPP) or falls back to Sharesheet */
    fun sendVCardViaBluetooth(context: Context, card: BusinessCardEntity) {
        val vcf = toVCardString(card)
        val prepared = prepareAndValidateVcfUri(context, card.fullName, vcf)
        if (prepared == null) {
            Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show()
            return
        }
        val (uri, fileName) = prepared
        val btIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/x-vcard"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(fileName, uri)
            setPackage("com.android.bluetooth")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching {
            context.startActivity(btIntent)
        }.onFailure {
            launchVcfSharesheet(context, uri, fileName, card.fullName.ifBlank { "CardLink Contact" })
        }
    }

    /**
     * Launches Android System Quick Share (BLE + Wi-Fi Direct) directly for the verified .vcf file
     * when a Quick Share receiver activity is present, falling back seamlessly to Android Sharesheet.
     */
    fun shareViaQuickShare(context: Context, card: BusinessCardEntity) {
        val vcf = toVCardString(card)
        val prepared = prepareAndValidateVcfUri(context, card.fullName, vcf)
        if (prepared == null) {
            Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show()
            return
        }
        val (uri, fileName) = prepared
        val title = card.fullName.ifBlank { "CardLink Contact" }
        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/x-vcard"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            clipData = ClipData.newRawUri(fileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val pm = context.packageManager
        val candidates = pm.queryIntentActivities(baseIntent, 0)
        val quickShareTarget = candidates.firstOrNull { ri ->
            val pkg = ri.activityInfo?.packageName.orEmpty().lowercase()
            val cls = ri.activityInfo?.name.orEmpty().lowercase()
            val lbl = ri.loadLabel(pm).toString().lowercase()
            cls.contains("nearby.sharing") ||
                cls.contains("quickshare") ||
                pkg.contains("sharelive") ||
                lbl.contains("quick share") ||
                lbl.contains("nearby share")
        }

        if (quickShareTarget != null) {
            val directIntent = Intent(baseIntent).apply {
                setClassName(quickShareTarget.activityInfo.packageName, quickShareTarget.activityInfo.name)
            }
            val launched = runCatching { context.startActivity(directIntent) }.isSuccess
            if (launched) return
        }

        launchVcfSharesheet(context, uri, fileName, title)
    }

    fun shareVCardFile(context: Context, card: BusinessCardEntity) {
        val vcf = toVCardString(card)
        val prepared = prepareAndValidateVcfUri(context, card.fullName, vcf)
        if (prepared == null) {
            Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show()
            return
        }
        val (uri, fileName) = prepared
        launchVcfSharesheet(context, uri, fileName, card.fullName.ifBlank { "CardLink Contact" })
    }

    fun shareSavedContactVcf(context: Context, contact: SavedContactEntity) {
        val vcf = savedContactToVCardString(contact)
        val prepared = prepareAndValidateVcfUri(context, contact.fullName, vcf)
        if (prepared == null) {
            Toast.makeText(context, context.getString(R.string.share_vcf_failed_msg), Toast.LENGTH_LONG).show()
            return
        }
        val (uri, fileName) = prepared
        launchVcfSharesheet(context, uri, fileName, contact.fullName.ifBlank { "CardLink Contact" })
    }

    fun saveVCardToUri(context: Context, destinationUri: Uri, card: BusinessCardEntity): Result<Unit> = runCatching {
        val vcf = toVCardString(card)
        context.contentResolver.openOutputStream(destinationUri, "wt")?.use { out ->
            out.write(vcf.toByteArray(Charsets.UTF_8))
            out.flush()
        } ?: error("Could not open selected destination URI.")
    }

    fun shareCardAsPng(context: Context, card: BusinessCardEntity) {
        val bitmap = CardLinkCanonicalRenderer.renderFrontBitmap(context, card, ExportQualityTier.STANDARD)
        val safeName = card.fullName.trim().replace(Regex("\\s+"), "_").replace(Regex("[^a-zA-Z0-9_-]"), "").ifBlank { "CardLink" }
        val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Card", "png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

        val uri = TempSecureExportVault.toShareUri(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, buildTextSummary(card))
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Share Business Card Image").apply {
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun shareCardAsPdf(context: Context, card: BusinessCardEntity) {
        val bitmap = CardLinkCanonicalRenderer.renderFrontBitmap(context, card, ExportQualityTier.HIGH_QUALITY)
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)
        pdfDocument.finishPage(page)

        val safeName = card.fullName.trim().replace(Regex("\\s+"), "_").replace(Regex("[^a-zA-Z0-9_-]"), "").ifBlank { "CardLink" }
        val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_Card", "pdf")
        FileOutputStream(file).use { pdfDocument.writeTo(it) }
        pdfDocument.close()

        val uri = TempSecureExportVault.toShareUri(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Export Business Card PDF").apply {
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun shareAsText(context: Context, card: BusinessCardEntity) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, buildTextSummary(card))
        }
        context.startActivity(Intent.createChooser(intent, "Share Contact Details"))
    }

    fun buildTextSummary(card: BusinessCardEntity): String {
        val c = card.sanitizedForSharing()
        val fullNameLine = BusinessCardProfileHelper.formatFullNameWithCredentials(c, forSharing = true).ifBlank { c.fullName }
        val phones = BusinessCardProfileHelper.getShareablePhoneNumbers(c)
        return buildString {
            if (fullNameLine.isNotBlank()) appendLine(fullNameLine)
            val roleOrg = listOf(c.designation, c.companyName).filter { it.isNotBlank() }.joinToString(" | ")
            if (roleOrg.isNotBlank()) appendLine(roleOrg)
            if (phones.isNotEmpty()) {
                phones.forEach { p -> appendLine("${p.type.displayLabel}: ${p.number}") }
            } else if (c.phone.isNotBlank()) {
                appendLine("Phone: ${c.phone}")
            }
            if (c.email.isNotBlank()) appendLine("Email: ${c.email}")
            if (c.publicCardUrl.isNotBlank()) appendLine("Card Link: ${c.publicCardUrl}")
            if (c.website.isNotBlank()) appendLine("Web: ${c.website}")
            if (c.officeAddress.isNotBlank()) appendLine("Address: ${c.officeAddress}")
            if (c.linkedInUrl.isNotBlank()) appendLine("LinkedIn: ${c.linkedInUrl}")
        }.trim()
    }

    fun exportToAndroidContacts(context: Context, contact: SavedContactEntity) {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, contact.fullName)
            putExtra(ContactsContract.Intents.Insert.COMPANY, contact.companyName)
            putExtra(ContactsContract.Intents.Insert.JOB_TITLE, contact.designation)
            putExtra(ContactsContract.Intents.Insert.PHONE, contact.phone)
            putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, contact.whatsapp)
            putExtra(ContactsContract.Intents.Insert.EMAIL, contact.email)
            putExtra(ContactsContract.Intents.Insert.POSTAL, contact.officeAddress)
            putExtra(ContactsContract.Intents.Insert.NOTES, contact.bio + "\n" + contact.notes)
        }
        context.startActivity(intent)
    }

    /**
     * Generates a Print-Ready Physical Business Card PDF (Standard 3.5" x 2.0" trim size with 0.125" bleed & crop marks).
     * Page 1: Front Side (300 DPI, 1125x675 px with bleed) — Logo strictly omitted from front.
     * Page 2: Back Side (300 DPI, 1125x675 px with bleed) — High-contrast Branded Logo QR + Company/Bio.
     */
    fun sharePrintReadyPhysicalCardPdf(context: Context, card: BusinessCardEntity) {
        // 3.75" x 2.25" @ 300 DPI = 1125 x 675 px (includes 0.125" = 38px bleed on all 4 sides)
        val pageW = 1125
        val pageH = 675
        val bleed = 38f
        val trimRect = RectF(bleed, bleed, pageW - bleed, pageH - bleed)
        val bgColor = card.primaryColorHex.toInt()

        fun drawCropMarks(canvas: Canvas) {
            val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#94A3B8")
                strokeWidth = 2f
            }
            val gap = 6f
            canvas.drawLine(bleed, 0f, bleed, bleed - gap, markPaint)
            canvas.drawLine(0f, bleed, bleed - gap, bleed, markPaint)
            canvas.drawLine(pageW - bleed, 0f, pageW - bleed, bleed - gap, markPaint)
            canvas.drawLine(pageW - bleed + gap, bleed, pageW.toFloat(), bleed, markPaint)
            canvas.drawLine(bleed, pageH - bleed + gap, bleed, pageH.toFloat(), markPaint)
            canvas.drawLine(0f, pageH - bleed, bleed - gap, pageH - bleed, markPaint)
            canvas.drawLine(pageW - bleed, pageH - bleed + gap, pageW - bleed, pageH.toFloat(), markPaint)
            canvas.drawLine(pageW - bleed + gap, pageH - bleed, pageW.toFloat(), pageH - bleed, markPaint)
        }

        // Single Visual Source of Truth: render active template Front & Back at high resolution
        val frontBmp = CardLinkCanonicalRenderer.renderFrontBitmap(context, card, ExportQualityTier.HIGH_QUALITY)
        val backBmp = CardLinkCanonicalRenderer.renderBackBitmap(context, card, ExportQualityTier.HIGH_QUALITY)
        val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val pdfDocument = PdfDocument()

        val frontPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
        frontPage.canvas.drawColor(bgColor)
        frontPage.canvas.drawBitmap(frontBmp, null, trimRect, drawPaint)
        drawCropMarks(frontPage.canvas)
        pdfDocument.finishPage(frontPage)

        val backPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 2).create())
        backPage.canvas.drawColor(bgColor)
        backPage.canvas.drawBitmap(backBmp, null, trimRect, drawPaint)
        drawCropMarks(backPage.canvas)
        pdfDocument.finishPage(backPage)

        val safeName = card.fullName.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "CardLink" }
        val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeName}_PrintReady_3.5x2", "pdf")
        FileOutputStream(file).use { pdfDocument.writeTo(it) }
        pdfDocument.close()

        val uri = TempSecureExportVault.toShareUri(context, file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${card.fullName} — Print-Ready Business Card (3.5\" x 2\")")
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Export Print-Ready Card PDF (3.5\" × 2\")").apply {
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
