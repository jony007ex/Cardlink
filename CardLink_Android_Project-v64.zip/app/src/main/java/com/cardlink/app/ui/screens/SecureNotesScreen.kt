package com.cardlink.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.data.model.SecureNoteEntity
import com.cardlink.app.ui.components.ScreenPrivacyGuard
import com.cardlink.app.util.SecureClipboardHelper
import com.cardlink.app.util.SecurityHardeningManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecureNotesScreen(
    notes: List<SecureNoteEntity>,
    onSaveNote: (SecureNoteEntity) -> Unit,
    onDeleteNote: (SecureNoteEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var editingNote by remember { mutableStateOf<SecureNoteEntity?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<SecureNoteEntity?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    LaunchedEffect(Unit) {
        SecurityHardeningManager.logAuditEventAsync(context, "SECURE_NOTES_OPENED", "SecureNotes", true, "Secure Notes vault accessed")
    }

    ScreenPrivacyGuard {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(stringResource(R.string.secure_notes_title), fontWeight = FontWeight.Bold)
                            Text(
                                stringResource(R.string.secure_notes_subtitle),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { editingNote = null; showEditor = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Secure Note")
                }
            }
        ) { padding ->
            if (notes.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                            Text(stringResource(R.string.secure_notes_empty_title), fontWeight = FontWeight.Bold)
                            Text(
                                stringResource(R.string.secure_notes_empty_msg),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notes, key = { it.stableUuid }) { note ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { editingNote = note; showEditor = true },
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(note.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                    Text(note.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Text(
                                    text = "•••••••• (Tap to view/edit)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(fmt.format(Date(note.updatedAtTimestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    Row {
                                        TextButton(onClick = {
                                            SecureClipboardHelper.copySensitive(context, note.title, note.content)
                                        }) { Text(stringResource(R.string.qa_copy_btn), fontSize = 12.sp) }
                                        TextButton(onClick = { pendingDelete = note }) {
                                            Text(stringResource(R.string.action_delete), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        var title by remember(editingNote) { mutableStateOf(editingNote?.title.orEmpty()) }
        var category by remember(editingNote) { mutableStateOf(editingNote?.category ?: "TIN / BIN") }
        var content by remember(editingNote) { mutableStateOf(editingNote?.content.orEmpty()) }

        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editingNote == null) "New Secure Note" else "Edit Secure Note", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.sn_title_lbl)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text(stringResource(R.string.sn_category_lbl)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text(stringResource(R.string.sn_content_lbl)) }, minLines = 4, maxLines = 8, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (title.isBlank() || content.isBlank()) {
                        Toast.makeText(context, "Title and content are required.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val entity = (editingNote ?: SecureNoteEntity(title = title.trim())).copy(
                        title = title.trim(),
                        category = category.trim().ifBlank { "General" },
                        content = content.trim(),
                        updatedAtTimestamp = System.currentTimeMillis()
                    )
                    onSaveNote(entity)
                    showEditor = false
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }

    val target = pendingDelete
    if (target != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.sn_delete_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.notes_remove_confirm_msg, target.title)) },
            confirmButton = {
                Button(
                    onClick = { onDeleteNote(target); pendingDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}
