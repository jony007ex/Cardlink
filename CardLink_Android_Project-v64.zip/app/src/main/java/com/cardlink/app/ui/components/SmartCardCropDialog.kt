package com.cardlink.app.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cardlink.app.R
import com.cardlink.app.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun SmartCardCropDialog(
    sourceBitmap: Bitmap,
    initialMetadata: CardCropMetadata? = null,
    startInManualAdjust: Boolean = false,
    featureType: SmartCropFeatureType = SmartCropFeatureType.BUSINESS_CARD,
    sideLabel: String = "",
    initialConfidence: CropConfidenceLevel? = null,
    expectedBarcodePayload: String = "",
    expectedQrPayload: String = "",
    onRetake: (() -> Unit)? = null,
    onConfirm: (croppedBitmap: Bitmap, metadata: CardCropMetadata) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val sanitizedInitial = remember(sourceBitmap, initialMetadata) {
        initialMetadata?.let { SmartCardCropEngine.sanitizeMetadata(it) }
    }
    var detectedAutoMeta by remember(sourceBitmap) { mutableStateOf<CardCropMetadata?>(null) }
    var detectedConfidence by remember(sourceBitmap, initialConfidence) {
        mutableStateOf(initialConfidence ?: CropConfidenceLevel.MEDIUM)
    }
    var userTouchedCorners by remember(sourceBitmap) { mutableStateOf(false) }
    var meta by remember(sourceBitmap, sanitizedInitial) {
        mutableStateOf(
            sanitizedInitial ?: CardCropMetadata(
                enhanceReadability = featureType.defaultEnhanceReadability,
                featureType = featureType.id,
                sideOrPage = sideLabel.ifBlank { "FRONT" }
            )
        )
    }

    var isAdjustMode by remember(startInManualAdjust, initialConfidence) {
        mutableStateOf(startInManualAdjust || initialConfidence == CropConfidenceLevel.LOW)
    }
    var hasEnteredManualEdit by remember(startInManualAdjust, initialConfidence) {
        mutableStateOf(startInManualAdjust || initialConfidence == CropConfidenceLevel.LOW)
    }
    var previewShowOriginal by remember { mutableStateOf(false) }
    var stageProgressLabel by remember { mutableStateOf<String?>(null) }

    var zoomScale by remember(sourceBitmap, meta.rotationDegrees, isAdjustMode) { mutableFloatStateOf(1f) }
    var panOffset by remember(sourceBitmap, meta.rotationDegrees, isAdjustMode) { mutableStateOf(Offset.Zero) }
    var activeDragCorner by remember { mutableIntStateOf(-1) }
    var lastSnappedCorner by remember { mutableIntStateOf(-1) }

    var pendingSafetyWarning by remember { mutableStateOf<Triple<Bitmap, CardCropMetadata, CropContentSafetyReport>?>(null) }

    LaunchedEffect(sourceBitmap) {
        stageProgressLabel = context.getString(R.string.crop_stage_detecting)
        val result = withContext(Dispatchers.Default) {
            SmartCardCropEngine.detectAutoCropWithConfidence(sourceBitmap, featureType, sideLabel.ifBlank { "FRONT" })
        }
        detectedAutoMeta = result.metadata
        if (initialConfidence == null) {
            detectedConfidence = result.confidence
        }
        if (sanitizedInitial == null && !userTouchedCorners) {
            meta = result.metadata
            if (result.confidence == CropConfidenceLevel.LOW && !startInManualAdjust) {
                isAdjustMode = true
                hasEnteredManualEdit = true
            }
        }
        stageProgressLabel = null
    }

    val previewBitmap by produceState<Bitmap?>(initialValue = null, sourceBitmap, meta, isAdjustMode, previewShowOriginal) {
        if (!isAdjustMode && !previewShowOriginal) {
            value = withContext(Dispatchers.Default) {
                SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, meta, maxOutputEdgePx = featureType.maxOutputEdgePx.coerceAtMost(1600))
            }
        }
    }

    val rotatedSourceForManual by produceState<Bitmap?>(
        initialValue = if (((meta.rotationDegrees % 360) + 360) % 360 == 0) sourceBitmap else null,
        sourceBitmap,
        meta.rotationDegrees
    ) {
        val normRot = ((meta.rotationDegrees % 360) + 360) % 360
        value = if (normRot == 0) {
            sourceBitmap
        } else {
            withContext(Dispatchers.Default) {
                val m = android.graphics.Matrix().apply { postRotate(normRot.toFloat()) }
                Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.width, sourceBitmap.height, m, true)
            }
        }
    }

    val activeCornerNormalized: Pair<Float, Float>? = when (activeDragCorner) {
        0 -> meta.topLeftX to meta.topLeftY
        1 -> meta.topRightX to meta.topRightY
        2 -> meta.bottomRightX to meta.bottomRightY
        3 -> meta.bottomLeftX to meta.bottomLeftY
        else -> null
    }

    // Quantize loupe coordinates to ~1% steps to avoid per-pixel bitmap churn while dragging
    val quantizedLoupePoint = activeCornerNormalized?.let { (nx, ny) ->
        (nx * 80f).roundToInt() to (ny * 80f).roundToInt()
    }
    val loupeBitmap = remember(rotatedSourceForManual, quantizedLoupePoint) {
        val src = rotatedSourceForManual
        val qpt = quantizedLoupePoint
        if (src == null || qpt == null || src.isRecycled) null
        else runCatching {
            val patchSize = (minOf(src.width, src.height) * 0.20f).toInt().coerceIn(72, 240)
            val cx = ((qpt.first / 80f) * src.width).roundToInt()
            val cy = ((qpt.second / 80f) * src.height).roundToInt()
            val left = (cx - patchSize / 2).coerceIn(0, (src.width - patchSize).coerceAtLeast(0))
            val top = (cy - patchSize / 2).coerceIn(0, (src.height - patchSize).coerceAtLeast(0))
            val safeW = patchSize.coerceAtMost(src.width - left).coerceAtLeast(1)
            val safeH = patchSize.coerceAtMost(src.height - top).coerceAtLeast(1)
            Bitmap.createBitmap(src, left, top, safeW, safeH)
        }.getOrNull()
    }
    DisposableEffect(loupeBitmap) {
        onDispose {
            if (loupeBitmap != null && !loupeBitmap.isRecycled) {
                runCatching { loupeBitmap.recycle() }
            }
        }
    }

    fun executeValidateAndConfirm(skipSafetyCheck: Boolean = false) {
        scope.launch {
            stageProgressLabel = context.getString(R.string.crop_stage_correcting)
            val cleanMeta = SmartCardCropEngine.sanitizeMetadata(meta).copy(
                featureType = featureType.id,
                sideOrPage = sideLabel.ifBlank { "FRONT" },
                confidenceLevel = detectedConfidence.name,
                sourceWidth = sourceBitmap.width,
                sourceHeight = sourceBitmap.height,
                updatedAtTimestamp = System.currentTimeMillis()
            )
            val rendered = withContext(Dispatchers.Default) {
                SmartCardCropEngine.applyCropAndPerspective(sourceBitmap, cleanMeta, maxOutputEdgePx = featureType.maxOutputEdgePx)
            }

            if (!skipSafetyCheck && !cleanMeta.isOriginalFullFrame) {
                stageProgressLabel = context.getString(R.string.crop_stage_checking_text)
                val safety = SmartCardCropEngine.validateCroppedContentSafety(
                    context = context,
                    sourceBitmap = rotatedSourceForManual ?: sourceBitmap,
                    croppedBitmap = rendered,
                    meta = cleanMeta,
                    featureType = featureType,
                    expectedBarcodePayload = expectedBarcodePayload,
                    expectedQrPayload = expectedQrPayload
                )
                if (safety.hasAnyWarning) {
                    stageProgressLabel = null
                    pendingSafetyWarning = Triple(rendered, cleanMeta, safety)
                    return@launch
                }
            }

            stageProgressLabel = null
            onConfirm(rendered, cleanMeta)
        }
    }

    val headerTitleRes = when (featureType) {
        SmartCropFeatureType.BUSINESS_CARD,
        SmartCropFeatureType.MY_CARD_IMPORT,
        SmartCropFeatureType.CONFERENCE_QUEUE -> R.string.crop_header_business_card
        SmartCropFeatureType.LOYALTY_CARD -> R.string.crop_header_loyalty_card
        SmartCropFeatureType.ID_DOCUMENT -> R.string.crop_header_id_doc
        SmartCropFeatureType.BUSINESS_DOCUMENT -> R.string.crop_header_business_doc
    }

    val resolvedSideText = when (sideLabel.uppercase()) {
        "FRONT" -> stringResource(R.string.card_side_front)
        "BACK" -> stringResource(R.string.card_side_back)
        else -> sideLabel
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = when {
                                    isAdjustMode -> stringResource(headerTitleRes)
                                    hasEnteredManualEdit -> stringResource(R.string.crop_preview_title)
                                    detectedConfidence == CropConfidenceLevel.MEDIUM -> stringResource(R.string.crop_check_title)
                                    else -> stringResource(R.string.crop_detected_title)
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (resolvedSideText.isNotBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = resolvedSideText,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = when {
                                isAdjustMode && detectedConfidence == CropConfidenceLevel.LOW -> stringResource(R.string.crop_low_conf_sub)
                                isAdjustMode -> stringResource(R.string.crop_adjust_sub)
                                detectedConfidence == CropConfidenceLevel.MEDIUM -> stringResource(R.string.crop_medium_conf_sub)
                                else -> stringResource(R.string.crop_detected_sub)
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.action_close))
                    }
                }

                if (!isAdjustMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !previewShowOriginal,
                                onClick = { previewShowOriginal = false },
                                label = { Text(stringResource(R.string.crop_view_corrected), fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                            )
                            FilterChip(
                                selected = previewShowOriginal,
                                onClick = { previewShowOriginal = true },
                                label = { Text(stringResource(R.string.crop_reset_original_short), fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                            )
                        }
                    }
                }

                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.90f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isAdjustMode) {
                        val shownBmp = if (previewShowOriginal) rotatedSourceForManual else previewBitmap
                        if (shownBmp != null && !shownBmp.isRecycled) {
                            Image(
                                bitmap = shownBmp.asImageBitmap(),
                                contentDescription = stringResource(R.string.crop_preview_title),
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize().padding(14.dp)
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                Text(stringResource(R.string.crop_stage_preparing_preview), color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    } else {
                        val manualBmp = rotatedSourceForManual
                        if (manualBmp == null || manualBmp.isRecycled) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        } else {
                            val padDp = 16.dp
                            val availW = (maxWidth - padDp * 2).coerceAtLeast(80.dp)
                            val availH = (maxHeight - padDp * 2).coerceAtLeast(80.dp)
                            val imgRatio = (manualBmp.width.toFloat() / manualBmp.height.coerceAtLeast(1).toFloat())
                                .coerceIn(0.35f, 3.0f)
                            val boxRatio = availW.value / availH.value.coerceAtLeast(1f)
                            val fitW = if (imgRatio >= boxRatio) availW else availH * imgRatio
                            val fitH = if (imgRatio >= boxRatio) availW / imgRatio else availH

                            var boxSize by remember { mutableStateOf(IntSize.Zero) }
                            val handleColor = MaterialTheme.colorScheme.primary

                            Box(
                                modifier = Modifier
                                    .size(width = fitW, height = fitH)
                                    .onSizeChanged { boxSize = it }
                                    .pointerInput(meta.rotationDegrees, fitW, fitH) {
                                        awaitEachGesture {
                                            val firstDown = awaitFirstDown(requireUnconsumed = false)
                                            if (boxSize.width <= 0 || boxSize.height <= 0) return@awaitEachGesture
                                            val bw = boxSize.width.toFloat()
                                            val bh = boxSize.height.toFloat()

                                            val (normX, normY) = SmartCardCropEngine.screenToNormalizedImageCoord(
                                                firstDown.position.x, firstDown.position.y,
                                                bw, bh, zoomScale, panOffset.x, panOffset.y
                                            )
                                            val corners = listOf(
                                                meta.topLeftX to meta.topLeftY,
                                                meta.topRightX to meta.topRightY,
                                                meta.bottomRightX to meta.bottomRightY,
                                                meta.bottomLeftX to meta.bottomLeftY
                                            )
                                            val hitThresholdPx = 135f
                                            var bestIdx = -1
                                            var bestDistPx = hitThresholdPx
                                            corners.forEachIndexed { idx, (cx, cy) ->
                                                val distPx = hypot(((normX - cx) * bw * zoomScale).toDouble(), ((normY - cy) * bh * zoomScale).toDouble()).toFloat()
                                                if (distPx < bestDistPx) {
                                                    bestDistPx = distPx
                                                    bestIdx = idx
                                                }
                                            }
                                            activeDragCorner = bestIdx
                                            lastSnappedCorner = -1

                                            do {
                                                val event = awaitPointerEvent()
                                                val pressedCount = event.changes.count { it.pressed }
                                                if (pressedCount >= 2) {
                                                    activeDragCorner = -1
                                                    val zoomChange = event.calculateZoom()
                                                    val panChange = event.calculatePan()
                                                    val nextScale = (zoomScale * zoomChange).coerceIn(1f, 3.2f)
                                                    zoomScale = nextScale
                                                    if (nextScale <= 1.02f) {
                                                        panOffset = Offset.Zero
                                                    } else {
                                                        val maxPanX = (bw * (nextScale - 1f)) * 0.5f
                                                        val maxPanY = (bh * (nextScale - 1f)) * 0.5f
                                                        panOffset = Offset(
                                                            (panOffset.x + panChange.x).coerceIn(-maxPanX, maxPanX),
                                                            (panOffset.y + panChange.y).coerceIn(-maxPanY, maxPanY)
                                                        )
                                                    }
                                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                                } else if (activeDragCorner >= 0) {
                                                    val ch = event.changes.firstOrNull()
                                                    if (ch != null && ch.positionChanged()) {
                                                        ch.consume()
                                                        val (rawNx, rawNy) = SmartCardCropEngine.screenToNormalizedImageCoord(
                                                            ch.position.x, ch.position.y,
                                                            bw, bh, zoomScale, panOffset.x, panOffset.y
                                                        )
                                                        val (snappedX, snappedY, didSnap) = SmartCardCropEngine.snapCornerToDetectedEdge(
                                                            x = rawNx,
                                                            y = rawNy,
                                                            cornerIndex = activeDragCorner,
                                                            detectedEdgeMeta = detectedAutoMeta
                                                        )
                                                        if (didSnap && lastSnappedCorner != activeDragCorner) {
                                                            lastSnappedCorner = activeDragCorner
                                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                        } else if (!didSnap && lastSnappedCorner == activeDragCorner) {
                                                            lastSnappedCorner = -1
                                                        }

                                                        val candidate = when (activeDragCorner) {
                                                            0 -> meta.copy(topLeftX = snappedX.coerceIn(0f, 0.92f), topLeftY = snappedY.coerceIn(0f, 0.92f), isOriginalFullFrame = false)
                                                            1 -> meta.copy(topRightX = snappedX.coerceIn(0.08f, 1f), topRightY = snappedY.coerceIn(0f, 0.92f), isOriginalFullFrame = false)
                                                            2 -> meta.copy(bottomRightX = snappedX.coerceIn(0.08f, 1f), bottomRightY = snappedY.coerceIn(0.08f, 1f), isOriginalFullFrame = false)
                                                            3 -> meta.copy(bottomLeftX = snappedX.coerceIn(0f, 0.92f), bottomLeftY = snappedY.coerceIn(0.08f, 1f), isOriginalFullFrame = false)
                                                            else -> meta
                                                        }
                                                        if (SmartCardCropEngine.isValidQuad(candidate)) {
                                                            userTouchedCorners = true
                                                            meta = candidate
                                                        }
                                                    }
                                                } else if (zoomScale > 1.02f) {
                                                    val panChange = event.calculatePan()
                                                    val maxPanX = (bw * (zoomScale - 1f)) * 0.5f
                                                    val maxPanY = (bh * (zoomScale - 1f)) * 0.5f
                                                    panOffset = Offset(
                                                        (panOffset.x + panChange.x).coerceIn(-maxPanX, maxPanX),
                                                        (panOffset.y + panChange.y).coerceIn(-maxPanY, maxPanY)
                                                    )
                                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                                }
                                            } while (event.changes.any { it.pressed })

                                            activeDragCorner = -1
                                        }
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer {
                                            scaleX = zoomScale
                                            scaleY = zoomScale
                                            translationX = panOffset.x
                                            translationY = panOffset.y
                                        }
                                ) {
                                    Image(
                                        bitmap = manualBmp.asImageBitmap(),
                                        contentDescription = "Original card for crop adjustment",
                                        contentScale = ContentScale.FillBounds,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val autoGuide = detectedAutoMeta
                                        if (autoGuide != null && !autoGuide.isOriginalFullFrame && autoGuide.rotationDegrees == meta.rotationDegrees) {
                                            val g0 = Offset(autoGuide.topLeftX * size.width, autoGuide.topLeftY * size.height)
                                            val g1 = Offset(autoGuide.topRightX * size.width, autoGuide.topRightY * size.height)
                                            val g2 = Offset(autoGuide.bottomRightX * size.width, autoGuide.bottomRightY * size.height)
                                            val g3 = Offset(autoGuide.bottomLeftX * size.width, autoGuide.bottomLeftY * size.height)
                                            val guidePath = Path().apply {
                                                moveTo(g0.x, g0.y); lineTo(g1.x, g1.y); lineTo(g2.x, g2.y); lineTo(g3.x, g3.y); close()
                                            }
                                            drawPath(
                                                path = guidePath,
                                                color = Color.White.copy(alpha = 0.45f),
                                                style = Stroke(
                                                    width = 2.5f / zoomScale,
                                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
                                                )
                                            )
                                        }

                                        val p0 = Offset(meta.topLeftX * size.width, meta.topLeftY * size.height)
                                        val p1 = Offset(meta.topRightX * size.width, meta.topRightY * size.height)
                                        val p2 = Offset(meta.bottomRightX * size.width, meta.bottomRightY * size.height)
                                        val p3 = Offset(meta.bottomLeftX * size.width, meta.bottomLeftY * size.height)

                                        val path = Path().apply {
                                            moveTo(p0.x, p0.y); lineTo(p1.x, p1.y); lineTo(p2.x, p2.y); lineTo(p3.x, p3.y); close()
                                        }
                                        drawPath(path, color = Color.Black.copy(alpha = 0.55f), style = Stroke(width = 7f / zoomScale))
                                        drawPath(path, color = handleColor, style = Stroke(width = 4f / zoomScale))

                                        listOf(p0, p1, p2, p3).forEachIndexed { idx, pt ->
                                            val isActive = idx == activeDragCorner
                                            val rOuter = (if (isActive) 24f else 20f) / zoomScale
                                            val rWhite = (if (isActive) 20f else 17f) / zoomScale
                                            val rInner = (if (isActive) 13f else 11f) / zoomScale
                                            drawCircle(color = Color.Black.copy(alpha = 0.65f), radius = rOuter, center = pt)
                                            drawCircle(color = Color.White, radius = rWhite, center = pt)
                                            drawCircle(color = handleColor, radius = rInner, center = pt)
                                        }
                                    }
                                }
                            }

                            if (activeDragCorner >= 0 && loupeBitmap != null && !loupeBitmap.isRecycled) {
                                Surface(
                                    shape = CircleShape,
                                    shadowElevation = 8.dp,
                                    border = BorderStroke(2.5.dp, MaterialTheme.colorScheme.primary),
                                    modifier = Modifier
                                        .align(Alignment.TopCenter)
                                        .padding(top = 12.dp)
                                        .size(112.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        Image(
                                            bitmap = loupeBitmap.asImageBitmap(),
                                            contentDescription = "Corner Magnifier",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Canvas(modifier = Modifier.fillMaxSize()) {
                                            val cx = size.width / 2f
                                            val cy = size.height / 2f
                                            drawLine(Color.Black.copy(alpha = 0.7f), Offset(cx - 18f, cy), Offset(cx + 18f, cy), strokeWidth = 4f)
                                            drawLine(Color.Black.copy(alpha = 0.7f), Offset(cx, cy - 18f), Offset(cx, cy + 18f), strokeWidth = 4f)
                                            drawLine(Color.White, Offset(cx - 16f, cy), Offset(cx + 16f, cy), strokeWidth = 2f)
                                            drawLine(Color.White, Offset(cx, cy - 16f), Offset(cx, cy + 16f), strokeWidth = 2f)
                                        }
                                    }
                                }
                            }

                            if (zoomScale > 1.05f && activeDragCorner < 0) {
                                Surface(
                                    onClick = { zoomScale = 1f; panOffset = Offset.Zero },
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.Black.copy(alpha = 0.72f),
                                    modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                                ) {
                                    Text(
                                        text = "${String.format("%.1f", zoomScale)}× • ${stringResource(R.string.qa_reset_btn)}",
                                        color = Color.White,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    stageProgressLabel?.let { stageMsg ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Text(stageMsg, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                if (isAdjustMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val autoLbl = stringResource(R.string.crop_auto_short)
                        TextButton(
                            onClick = {
                                val targetBmp = rotatedSourceForManual ?: sourceBitmap
                                val curRot = meta.rotationDegrees
                                scope.launch {
                                    stageProgressLabel = context.getString(R.string.crop_stage_detecting)
                                    val detected = withContext(Dispatchers.Default) {
                                        SmartCardCropEngine.detectAutoCropWithConfidence(targetBmp, featureType, sideLabel.ifBlank { "FRONT" })
                                    }
                                    stageProgressLabel = null
                                    userTouchedCorners = true
                                    detectedAutoMeta = detected.metadata.copy(rotationDegrees = curRot)
                                    meta = detected.metadata.copy(rotationDegrees = curRot)
                                }
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = autoLbl }
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(autoLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val rotLbl = stringResource(R.string.crop_rotate_btn)
                        TextButton(
                            onClick = {
                                val nextRot = (meta.rotationDegrees + 90) % 360
                                zoomScale = 1f
                                panOffset = Offset.Zero
                                userTouchedCorners = true
                                scope.launch {
                                    stageProgressLabel = context.getString(R.string.crop_stage_detecting)
                                    val rotatedForDetect = withContext(Dispatchers.Default) {
                                        if (nextRot == 0) sourceBitmap
                                        else {
                                            val m = android.graphics.Matrix().apply { postRotate(nextRot.toFloat()) }
                                            Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.width, sourceBitmap.height, m, true)
                                        }
                                    }
                                    val detected = withContext(Dispatchers.Default) {
                                        SmartCardCropEngine.detectAutoCropWithConfidence(rotatedForDetect, featureType, sideLabel.ifBlank { "FRONT" })
                                    }
                                    if (rotatedForDetect !== sourceBitmap) rotatedForDetect.recycle()
                                    stageProgressLabel = null
                                    detectedAutoMeta = detected.metadata.copy(rotationDegrees = nextRot)
                                    meta = detected.metadata.copy(rotationDegrees = nextRot)
                                }
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = rotLbl }
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(rotLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val origLbl = stringResource(R.string.crop_reset_original_short)
                        TextButton(
                            onClick = {
                                userTouchedCorners = true
                                meta = CardCropMetadata.fullOriginal(meta.rotationDegrees, meta.cropRevision, featureType, sideLabel.ifBlank { "FRONT" })
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = origLbl }
                        ) {
                            Text(origLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val resetLbl = stringResource(R.string.qa_reset_btn)
                        TextButton(
                            onClick = {
                                zoomScale = 1f
                                panOffset = Offset.Zero
                                meta = sanitizedInitial ?: detectedAutoMeta ?: CardCropMetadata()
                            },
                            modifier = Modifier.heightIn(min = 48.dp).semantics { contentDescription = resetLbl }
                        ) {
                            Text(resetLbl, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!isAdjustMode) {
                        if (onRetake != null && !hasEnteredManualEdit) {
                            OutlinedButton(
                                onClick = onRetake,
                                enabled = stageProgressLabel == null,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text(stringResource(R.string.ocr_retake_btn), fontWeight = FontWeight.SemiBold, fontSize = 12.5.sp)
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                previewShowOriginal = false
                                isAdjustMode = true
                                hasEnteredManualEdit = true
                            },
                            enabled = stageProgressLabel == null,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Crop, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = if (hasEnteredManualEdit) stringResource(R.string.crop_continue_editing_btn) else stringResource(R.string.crop_adjust_btn),
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Button(
                            onClick = { executeValidateAndConfirm(skipSafetyCheck = false) },
                            enabled = stageProgressLabel == null,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Check, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = if (hasEnteredManualEdit) stringResource(R.string.crop_save_btn) else stringResource(R.string.crop_use_btn),
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                previewShowOriginal = false
                                hasEnteredManualEdit = true
                                isAdjustMode = false
                            },
                            enabled = stageProgressLabel == null,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text(stringResource(R.string.qa_label_preview), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { executeValidateAndConfirm(skipSafetyCheck = false) },
                            enabled = stageProgressLabel == null,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Default.Check, null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(stringResource(R.string.crop_save_btn), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    pendingSafetyWarning?.let { (renderedBmp, cleanMeta, report) ->
        val isCodeWarn = report.barcodeOrQrBroken
        AlertDialog(
            onDismissRequest = { pendingSafetyWarning = null },
            title = {
                Text(
                    text = if (isCodeWarn) stringResource(R.string.crop_code_warn_title) else stringResource(R.string.crop_check_title),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isCodeWarn) stringResource(R.string.crop_code_warn_msg) else stringResource(R.string.crop_text_outside_msg),
                    style = MaterialTheme.typography.bodySmall
                )
            },
            confirmButton = {
                Button(onClick = {
                    pendingSafetyWarning = null
                    isAdjustMode = true
                    hasEnteredManualEdit = true
                }) {
                    Text(stringResource(R.string.crop_adjust_title), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingSafetyWarning = null
                    onConfirm(renderedBmp, cleanMeta)
                }) {
                    Text(
                        text = if (isCodeWarn) stringResource(R.string.crop_keep_current_crop_btn) else stringResource(R.string.ocr_use_anyway_btn)
                    )
                }
            }
        )
    }
}
