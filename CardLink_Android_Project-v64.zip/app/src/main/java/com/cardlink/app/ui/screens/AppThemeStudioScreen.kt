package com.cardlink.app.ui.screens

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardlink.app.R
import com.cardlink.app.ui.theme.resolveColorScheme
import com.cardlink.app.util.*

private val STUDIO_SWATCHES = listOf(
    0xFF0A192FL, 0xFF0F172AL, 0xFF065F46L, 0xFF1E3A8AL,
    0xFF5B21B6L, 0xFF881337L, 0xFF18181BL, 0xFF000000L,
    0xFFD4AF37L, 0xFF38BDF8L, 0xFF34D399L, 0xFF22D3EEL,
    0xFFF4B6A8L, 0xFFF59E0BL, 0xFFF8FAFCL, 0xFFFFFFFFL
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppThemeStudioScreen(
    currentAppTheme: AppCustomThemeConfig,
    darkThemeOverride: Boolean?,
    onApplyAppTheme: (AppCustomThemeConfig) -> Unit,
    onSelectDisplayMode: (Boolean?) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

    var draftTheme by remember(currentAppTheme) { mutableStateOf(currentAppTheme) }
    var draftDisplayMode by remember(darkThemeOverride) { mutableStateOf(darkThemeOverride) }
    var customBuilderMode by remember { mutableIntStateOf(0) }
    var savedCustomThemes by remember { mutableStateOf(ThemeContrastHelper.loadSavedCustomThemes(context)) }
    var recentColors by remember { mutableStateOf(ThemeContrastHelper.loadRecentColors(context)) }

    var showDiscardDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showSaveCustomDialog by remember { mutableStateOf(false) }

    val hasUnsavedChanges = draftTheme != currentAppTheme || draftDisplayMode != darkThemeOverride
    val previewIsDark = draftDisplayMode ?: systemDark

    val accessibilityReport = remember(draftTheme, previewIsDark) {
        ThemeContrastHelper.evaluateAccessibility(draftTheme, previewIsDark)
    }

    fun attemptBack() {
        if (hasUnsavedChanges) showDiscardDialog = true
        else onNavigateBack()
    }

    BackHandler(enabled = hasUnsavedChanges) {
        showDiscardDialog = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.theme_studio_title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(R.string.theme_studio_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { attemptBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(stringResource(R.string.theme_studio_live_preview), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            LiveAppThemePreviewCard(config = draftTheme, isDark = previewIsDark)

            val (accLabel, accColor, accIcon) = when (accessibilityReport.level) {
                ThemeAccessibilityLevel.ACCESSIBLE -> Triple(stringResource(R.string.theme_studio_accessible), Color(0xFF10B981), Icons.Default.CheckCircle)
                ThemeAccessibilityLevel.NEEDS_ADJUSTMENT -> Triple(stringResource(R.string.theme_studio_needs_adjustment), Color(0xFFF59E0B), Icons.Default.WarningAmber)
                ThemeAccessibilityLevel.LOW_CONTRAST -> Triple(stringResource(R.string.theme_studio_low_contrast), Color(0xFFEF4444), Icons.Default.ErrorOutline)
            }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = accColor.copy(alpha = 0.12f)),
                border = BorderStroke(1.dp, accColor.copy(alpha = 0.55f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(accIcon, contentDescription = null, tint = accColor, modifier = Modifier.size(20.dp))
                        Text(accLabel, fontWeight = FontWeight.Bold, color = accColor, fontSize = 14.sp)
                    }
                    Text(accessibilityReport.summaryText, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = "Text/BG ${String.format("%.1f", accessibilityReport.textOnBgRatio)}:1 • " +
                            "Text/Surface ${String.format("%.1f", accessibilityReport.textOnSurfaceRatio)}:1 • " +
                            "Button ${String.format("%.1f", accessibilityReport.onPrimaryRatio)}:1",
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (accessibilityReport.level != ThemeAccessibilityLevel.ACCESSIBLE) {
                        OutlinedButton(
                            onClick = {
                                draftTheme = ThemeContrastHelper.autoFixContrast(draftTheme, previewIsDark)
                                Toast.makeText(context, "Contrast adjusted for readability. Review Live Preview.", Toast.LENGTH_SHORT).show()
                            },
                            border = BorderStroke(1.dp, accColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AutoFixHigh, null, tint = accColor, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.theme_studio_fix_contrast), color = accColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.settings_appearance), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = draftDisplayMode == false,
                            onClick = { draftDisplayMode = false },
                            label = { Text(stringResource(R.string.theme_light), fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = draftDisplayMode == true,
                            onClick = { draftDisplayMode = true },
                            label = { Text(stringResource(R.string.theme_dark), fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = draftDisplayMode == null,
                            onClick = { draftDisplayMode = null },
                            label = { Text(stringResource(R.string.theme_system), fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(stringResource(R.string.theme_use_device_colors), fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                Text(stringResource(R.string.theme_use_device_colors_sub),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                            Switch(
                                checked = draftTheme.useDeviceColors,
                                onCheckedChange = { enabled ->
                                    draftTheme = draftTheme.copy(
                                        useDeviceColors = enabled,
                                        themeName = if (enabled) "Device Dynamic Colors" else draftTheme.themeName
                                    )
                                }
                            )
                        }
                    }
                }
            }

            Text(stringResource(R.string.theme_studio_presets), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AppThemePresets.all.chunked(2).forEach { pair ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { preset ->
                            val isSelected = !draftTheme.useDeviceColors && draftTheme.presetId == preset.id
                            ThemePresetPreviewCard(
                                preset = preset,
                                isDark = previewIsDark,
                                isSelected = isSelected,
                                onSelect = { draftTheme = preset.config.copy(useDeviceColors = false) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            if (savedCustomThemes.isNotEmpty()) {
                Text(stringResource(R.string.theme_saved_custom_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    savedCustomThemes.forEach { ct ->
                        InputChip(
                            selected = !draftTheme.useDeviceColors && draftTheme.customThemeUuid == ct.customThemeUuid,
                            onClick = { draftTheme = ct.copy(useDeviceColors = false) },
                            label = { Text(ct.themeName, fontSize = 12.sp) },
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Delete custom theme",
                                    modifier = Modifier.size(14.dp).clickable {
                                        ct.customThemeUuid?.let { savedCustomThemes = ThemeContrastHelper.deleteCustomThemeFromList(context, it) }
                                    }
                                )
                            }
                        )
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.theme_studio_create_custom), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = customBuilderMode == 0,
                                onClick = { customBuilderMode = 0 },
                                label = { Text(stringResource(R.string.theme_studio_simple_mode), fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = customBuilderMode == 1,
                                onClick = { customBuilderMode = 1 },
                                label = { Text(stringResource(R.string.theme_studio_advanced_mode), fontSize = 11.sp) }
                            )
                        }
                    }

                    if (customBuilderMode == 0) {
                        StudioColorField(
                            label = "Main Color",
                            colorHex = draftTheme.primaryHex,
                            recentColors = recentColors,
                            onColorChanged = { main ->
                                ThemeContrastHelper.recordRecentColor(context, main)
                                recentColors = ThemeContrastHelper.loadRecentColors(context)
                                draftTheme = ThemeContrastHelper.generateSimplePalette(main, draftTheme.accentHex)
                            }
                        )
                        StudioColorField(
                            label = "Accent Color",
                            colorHex = draftTheme.accentHex,
                            recentColors = recentColors,
                            onColorChanged = { acc ->
                                ThemeContrastHelper.recordRecentColor(context, acc)
                                recentColors = ThemeContrastHelper.loadRecentColors(context)
                                draftTheme = ThemeContrastHelper.generateSimplePalette(draftTheme.primaryHex, acc)
                            }
                        )
                    } else {
                        StudioColorField("Primary / Button", if (previewIsDark) draftTheme.buttonHex else draftTheme.lightPrimaryHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, buttonHex = c, accentHex = c, onPrimaryHex = ThemeContrastHelper.bestOnColor(c))
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightPrimaryHex = c, lightOnPrimaryHex = ThemeContrastHelper.bestOnColor(c))
                        }
                        StudioColorField("Secondary", if (previewIsDark) draftTheme.secondaryHex else draftTheme.lightSecondaryHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, secondaryHex = c)
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightSecondaryHex = c)
                        }
                        StudioColorField("Background", if (previewIsDark) draftTheme.backgroundHex else draftTheme.lightBackgroundHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, backgroundHex = c)
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightBackgroundHex = c)
                        }
                        StudioColorField("Surface", if (previewIsDark) draftTheme.surfaceHex else draftTheme.lightSurfaceHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, surfaceHex = c)
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightSurfaceHex = c)
                        }
                        StudioColorField("Text / On-Surface", if (previewIsDark) draftTheme.textHex else draftTheme.lightTextHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, textHex = c)
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightTextHex = c)
                        }
                        StudioColorField("Outline", if (previewIsDark) draftTheme.outlineHex else draftTheme.lightOutlineHex, recentColors) { c ->
                            draftTheme = if (previewIsDark) draftTheme.copy(presetId = "custom", useDeviceColors = false, outlineHex = c)
                            else draftTheme.copy(presetId = "custom", useDeviceColors = false, lightOutlineHex = c)
                        }
                    }
                }
            }

            Button(
                onClick = {
                    onSelectDisplayMode(draftDisplayMode)
                    onApplyAppTheme(draftTheme)
                    Toast.makeText(context, "App Theme applied!", Toast.LENGTH_SHORT).show()
                    onNavigateBack()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Check, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.theme_studio_apply_btn), fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { showSaveCustomDialog = true },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text(stringResource(R.string.theme_studio_save_custom_btn), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }

                OutlinedButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text(stringResource(R.string.theme_studio_reset_btn), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (showDiscardDialog) {
        AlertDialog(
            onDismissRequest = { showDiscardDialog = false },
            title = { Text(stringResource(R.string.theme_discard_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.theme_discard_msg)) },
            confirmButton = {
                Button(onClick = { showDiscardDialog = false; onNavigateBack() }) { Text(stringResource(R.string.qa_discard_btn)) }
            },
            dismissButton = {
                TextButton(onClick = { showDiscardDialog = false }) { Text(stringResource(R.string.qa_keep_editing_btn)) }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text(stringResource(R.string.theme_reset_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.theme_reset_msg)) },
            confirmButton = {
                Button(onClick = {
                    val def = AppThemePresets.all.first().config
                    draftTheme = def
                    onApplyAppTheme(def)
                    showResetDialog = false
                    Toast.makeText(context, "Restored CardLink Navy & Gold default.", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.qa_reset_btn)) }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    if (showSaveCustomDialog) {
        var nameInput by remember { mutableStateOf(draftTheme.themeName) }
        AlertDialog(
            onDismissRequest = { showSaveCustomDialog = false },
            title = { Text(stringResource(R.string.theme_studio_save_custom_btn), fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text(stringResource(R.string.theme_custom_name_lbl)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    val trimmed = nameInput.trim().ifBlank { "My Custom Theme" }
                    val named = draftTheme.copy(themeName = trimmed, presetId = "custom", useDeviceColors = false)
                    savedCustomThemes = ThemeContrastHelper.saveCustomThemeToList(context, named)
                    draftTheme = named
                    showSaveCustomDialog = false
                    Toast.makeText(context, "Saved custom theme \"$trimmed\"", Toast.LENGTH_SHORT).show()
                }) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showSaveCustomDialog = false }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}

@Composable
private fun LiveAppThemePreviewCard(
    config: AppCustomThemeConfig,
    isDark: Boolean
) {
    val context = LocalContext.current
    val previewScheme = if (config.useDeviceColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        resolveColorScheme(config, isDark)
    }

    MaterialTheme(colorScheme = previewScheme) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.background,
            border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.theme_preview_title), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground)
                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.theme_preview_contact), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(stringResource(R.string.theme_preview_supporting_sample), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f))
                        }
                        Switch(checked = true, onCheckedChange = {})
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {},
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text(stringResource(R.string.theme_preview_primary_btn), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = {},
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text(stringResource(R.string.theme_preview_secondary_btn), fontSize = 11.sp) }
                }
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("My Card", "Contacts", "Calendar", "Tools", "Menu").forEachIndexed { idx, tab ->
                            Text(
                                text = tab,
                                fontSize = 10.sp,
                                fontWeight = if (idx == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (idx == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemePresetPreviewCard(
    preset: BuiltInAppThemePreset,
    isDark: Boolean,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = Color((if (isDark) preset.config.backgroundHex else preset.config.lightBackgroundHex).toInt())
    val surf = Color((if (isDark) preset.config.surfaceHex else preset.config.lightSurfaceHex).toInt())
    val prim = Color((if (isDark) preset.config.buttonHex else preset.config.lightPrimaryHex).toInt())
    val sec = Color((if (isDark) preset.config.secondaryHex else preset.config.lightSecondaryHex).toInt())
    val txt = Color((if (isDark) preset.config.textHex else preset.config.lightTextHex).toInt())

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .semantics { selected = isSelected }
            .clickable(role = Role.RadioButton, onClick = onSelect),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(if (isSelected) 2.2.dp else 1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(preset.name, color = txt, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (isSelected) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(surf).border(1.dp, txt.copy(alpha = 0.3f), CircleShape))
                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(prim))
                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(sec))
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(6.dp), color = prim) {
                    Text(stringResource(R.string.theme_preview_btn_short), color = Color((if (isDark) preset.config.onPrimaryHex else preset.config.lightOnPrimaryHex).toInt()), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun StudioColorField(
    label: String,
    colorHex: Long,
    recentColors: List<Long>,
    onColorChanged: (Long) -> Unit
) {
    var hexText by remember(colorHex) { mutableStateOf(ThemeContrastHelper.formatHex(colorHex)) }
    val validHex = ThemeContrastHelper.parseHexColorOrNull(hexText) != null

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier.size(24.dp).clip(CircleShape).background(Color(colorHex.toInt())).border(1.dp, Color.Gray, CircleShape)
                )
                Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            OutlinedTextField(
                value = hexText,
                onValueChange = { input ->
                    hexText = input.take(7)
                    ThemeContrastHelper.parseHexColorOrNull(input)?.let { onColorChanged(it) }
                },
                isError = !validHex,
                singleLine = true,
                modifier = Modifier.width(118.dp)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            (recentColors + STUDIO_SWATCHES).distinct().forEach { sw ->
                val isSel = sw == colorHex
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(sw.toInt()))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                        .clickable { onColorChanged(sw) }
                )
            }
        }
    }
}
