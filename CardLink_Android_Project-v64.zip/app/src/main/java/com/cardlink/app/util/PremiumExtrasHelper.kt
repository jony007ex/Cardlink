package com.cardlink.app.util

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.provider.CalendarContract
import android.widget.Toast
import androidx.core.content.FileProvider
import com.cardlink.app.data.model.BusinessCardEntity
import com.cardlink.app.data.model.SavedContactEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.io.FileOutputStream

object PremiumExtrasHelper {

    fun generateBrandedQrBitmap(
        context: Context,
        card: BusinessCardEntity,
        sizePx: Int = 720
    ): Bitmap {
        val vcf = CardShareHelper.toVCardString(card)
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 2
        )
        val fgColor = ThemeContrastHelper.safeQrForegroundInt(card.primaryColorHex)
        val bgColor = Color.WHITE
        val bitMatrix = QRCodeWriter().encode(vcf.ifBlank { "CardLink" }, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        for (y in 0 until sizePx) {
            for (x in 0 until sizePx) {
                pixels[y * sizePx + x] = if (bitMatrix[x, y]) fgColor else bgColor
            }
        }
        val qrBitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        }

        val logoUriStr = card.companyLogoUri
        if (!logoUriStr.isNullOrBlank()) {
            val logoBmp = runCatching {
                if (logoUriStr.endsWith(".clenc", ignoreCase = true)) {
                    VaultCryptoManager.decodeVaultBitmapUncached(context, logoUriStr, 256)
                } else {
                    val uri = Uri.parse(logoUriStr)
                    if (uri.scheme == "file") BitmapFactory.decodeFile(uri.path)
                    else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
            }.getOrNull()

            if (logoBmp != null) {
                val canvas = Canvas(qrBitmap)
                val badgeSize = (sizePx * 0.21f).toInt().coerceAtLeast(36)
                val left = (sizePx - badgeSize) / 2f
                val top = (sizePx - badgeSize) / 2f

                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
                val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = card.accentColorHex.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                }
                val rect = RectF(left, top, left + badgeSize, top + badgeSize)
                canvas.drawRoundRect(rect, 20f, 20f, bgPaint)
                canvas.drawRoundRect(rect, 20f, 20f, borderPaint)

                val pad = 10f
                val logoDest = RectF(left + pad, top + pad, left + badgeSize - pad, top + badgeSize - pad)
                canvas.drawBitmap(logoBmp, null, logoDest, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        }
        return qrBitmap
    }

    fun renderLockScreenWallpaper(context: Context, card: BusinessCardEntity): Bitmap {
        val w = 1080; val h = 2400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bgPaint = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), card.primaryColorHex.toInt(), card.cardGradientEndHex.toInt(), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt() }
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.textColorHex.toInt(); textSize = 68f; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt(); textSize = 38f; textAlign = Paint.Align.CENTER }
        val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1"); textSize = 30f; textAlign = Paint.Align.CENTER }

        val qrSize = 560; val qrLeft = (w - qrSize) / 2f; val qrTop = 980f
        val cardRect = RectF(qrLeft - 45f, qrTop - 45f, qrLeft + qrSize + 45f, qrTop + qrSize + 45f)
        canvas.drawRoundRect(cardRect, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        canvas.drawRoundRect(cardRect, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.accentColorHex.toInt(); style = Paint.Style.STROKE; strokeWidth = 8f })
        canvas.drawBitmap(generateBrandedQrBitmap(context, card, qrSize), qrLeft, qrTop, null)
        canvas.drawText(card.fullName.ifBlank { "Card Link User" }, w / 2f, 820f, namePaint)
        canvas.drawText(listOf(card.designation, card.companyName).filter { it.isNotBlank() }.joinToString(" • "), w / 2f, 885f, subPaint)
        canvas.drawRect(w / 2f - 140f, 915f, w / 2f + 140f, 921f, accentPaint)
        canvas.drawText("Scan QR to Save Contact • Powered by Card Link", w / 2f, qrTop + qrSize + 130f, hintPaint)
        return bmp
    }

    fun applyLockScreenWallpaper(context: Context, card: BusinessCardEntity): Boolean = runCatching {
        val bmp = renderLockScreenWallpaper(context, card)
        val wm = WallpaperManager.getInstance(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK) else wm.setBitmap(bmp)
        true
    }.getOrDefault(false)

    fun shareLockScreenWallpaper(context: Context, card: BusinessCardEntity) {
        val bmp = renderLockScreenWallpaper(context, card)
        val file = TempSecureExportVault.createNamedTempExportFile(context, "CardLink_Wallpaper_${System.currentTimeMillis()}", "png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
        val uri = TempSecureExportVault.toShareUri(context, file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri(file.name, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Save / Share Lock-Screen Wallpaper").apply {
            clipData = ClipData.newRawUri(file.name, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun shareClickableHtmlCard(context: Context, card: BusinessCardEntity) {
        val html = CardLinkCanonicalRenderer.buildInteractiveHtmlString(context, card)
        val safeBase = card.fullName.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "CardLink" }
        val file = TempSecureExportVault.createNamedTempExportFile(context, "${safeBase}_InteractiveCard", "html")
        file.writeText(html, Charsets.UTF_8)
        val uri = TempSecureExportVault.toShareUri(context, file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share Interactive HTML Card").apply {
            clipData = ClipData.newRawUri(file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun copyEmailSignatureToClipboard(context: Context, card: BusinessCardEntity) {
        val c = card.sanitizedForSharing()
        val plain = buildString {
            appendLine("--"); appendLine(c.fullName)
            if (c.designation.isNotBlank() || c.companyName.isNotBlank()) appendLine("${c.designation} | ${c.companyName}")
            if (c.department.isNotBlank()) appendLine(c.department)
            if (c.phone.isNotBlank()) appendLine("Tel: ${c.phone}")
            if (c.email.isNotBlank()) appendLine("Email: ${c.email}")
            if (c.website.isNotBlank()) appendLine("Web: ${c.website}")
            if (c.officeAddress.isNotBlank()) appendLine("Office: ${c.officeAddress}")
        }.trim()
        val html = """<table style="font-family:Arial,sans-serif;color:#0A192F;border-left:3px solid #D4AF37;padding-left:12px;"><tr><td style="font-size:16px;font-weight:bold;">${c.fullName}</td></tr><tr><td style="font-size:13px;color:#B8860B;font-weight:bold;">${c.designation} • ${c.companyName}</td></tr><tr><td style="font-size:12px;color:#334155;">${c.phone} | ${c.email}</td></tr><tr><td style="font-size:12px;color:#475569;">${c.officeAddress}</td></tr></table>"""
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newHtmlText("CardLink Email Signature", plain, html))
        Toast.makeText(context, "Professional Email Signature copied! Paste in Gmail/Outlook.", Toast.LENGTH_LONG).show()
    }

    fun scheduleFollowUpMeeting(context: Context, contact: SavedContactEntity) {
        val startMillis = System.currentTimeMillis() + 24L * 60 * 60 * 1000
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMillis + 30L * 60 * 1000)
            putExtra(CalendarContract.Events.TITLE, "Follow-up: ${contact.fullName} (${contact.companyName})")
            putExtra(CalendarContract.Events.DESCRIPTION, "Contact: ${contact.fullName}\nPhone: ${contact.phone}\nNotes: ${contact.notes}")
            if (contact.officeAddress.isNotBlank()) putExtra(CalendarContract.Events.EVENT_LOCATION, contact.officeAddress)
            if (contact.email.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, contact.email)
        }
        runCatching { context.startActivity(intent) }.onFailure { Toast.makeText(context, "No Calendar app found.", Toast.LENGTH_SHORT).show() }
    }

    fun renderMeetingBackgroundBitmap(context: Context, card: BusinessCardEntity): Bitmap {
        val w = 1920; val h = 1080
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), card.primaryColorHex.toInt(), card.cardGradientEndHex.toInt(), Shader.TileMode.CLAMP)
        })
        val accentColor = card.accentColorHex.toInt()
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
        canvas.drawRect(0f, 0f, w.toFloat(), 10f, accentPaint)
        canvas.drawRect(0f, h - 10f, w.toFloat(), h.toFloat(), accentPaint)
        canvas.drawRoundRect(RectF(36f, 36f, w - 36f, h - 36f), 28f, 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor; alpha = 55; style = Paint.Style.STROKE; strokeWidth = 3f })

        val clean = card.sanitizedForSharing()
        val textLeft = 78f
        canvas.drawText(clean.fullName.ifBlank { "Card Link User" }, textLeft, 118f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = card.textColorHex.toInt(); textSize = 54f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) })
        val roleLine = listOf(clean.designation, clean.companyName).filter { it.isNotBlank() }.joinToString(" • ")
        if (roleLine.isNotBlank()) canvas.drawText(roleLine, textLeft, 162f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor; textSize = 30f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) })
        val infoLine = listOf(clean.email, clean.website).filter { it.isNotBlank() }.joinToString("  |  ")
        if (infoLine.isNotBlank()) canvas.drawText(infoLine, textLeft, 202f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1"); textSize = 24f })

        val qrSize = 300; val pad = 24f; val badgeRight = w - 74f; val badgeTop = 64f
        val badgeLeft = badgeRight - qrSize - pad * 2; val badgeBottom = badgeTop + qrSize + pad * 2 + 44f
        val badgeRect = RectF(badgeLeft, badgeTop, badgeRight, badgeBottom)
        canvas.drawRoundRect(badgeRect, 28f, 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        canvas.drawRoundRect(badgeRect, 28f, 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor; style = Paint.Style.STROKE; strokeWidth = 6f })
        canvas.drawBitmap(generateBrandedQrBitmap(context, card, qrSize), badgeLeft + pad, badgeTop + pad, null)
        canvas.drawText("Scan to Save Contact", (badgeLeft + badgeRight) / 2f, badgeBottom - 18f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0A192F"); textSize = 23f; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) })
        canvas.drawText("Powered by Card Link", w - 74f, h - 54f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#94A3B8"); textSize = 22f; textAlign = Paint.Align.RIGHT })
        return bmp
    }

    fun shareMeetingBackground(context: Context, card: BusinessCardEntity) {
        val bmp = renderMeetingBackgroundBitmap(context, card)
        val file = TempSecureExportVault.createNamedTempExportFile(context, "CardLink_MeetingBG_${System.currentTimeMillis()}", "png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 96, it) }
        val uri = TempSecureExportVault.toShareUri(context, file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); clipData = ClipData.newRawUri(file.name, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Save / Share 16:9 Meeting Background").apply {
            clipData = ClipData.newRawUri(file.name, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
